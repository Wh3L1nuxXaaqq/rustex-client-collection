package com.Blood.Ware.settings;

import com.Blood.Ware.module.Module;
import java.util.ArrayList;

public class Setting
extends com.Blood.Ware.Castom.setting.Setting {
    public /* synthetic */ String name;
    public /* synthetic */ Module parent;
    public /* synthetic */ String mode;
    public /* synthetic */ String sval;
    public /* synthetic */ ArrayList<String> options;
    public /* synthetic */ boolean bval;
    public /* synthetic */ double dval;
    public /* synthetic */ double min;
    public /* synthetic */ double max;
    public /* synthetic */ boolean onlyint;

    public Setting(String string, Module module, String string2, ArrayList<String> arrayList) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.sval = string2;
        this.options = arrayList;
        this.mode = "Combo";
    }

    public Setting(String string, Module module, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.bval = bl;
        this.mode = "Check";
    }

    public Setting(String string, Module module, double d, double d2, double d3, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.dval = d;
        this.min = d2;
        this.max = d3;
        this.onlyint = bl;
        this.mode = "Slider";
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Module getParentMod() {
        return this.parent;
    }

    @Override
    public String getValString() {
        return this.sval;
    }

    @Override
    public void setValString(String string) {
        this.sval = string;
    }

    @Override
    public ArrayList<String> getOptions() {
        return this.options;
    }

    @Override
    public boolean getValBoolean() {
        return this.bval;
    }

    @Override
    public void setValBoolean(boolean bl) {
        this.bval = bl;
    }

    @Override
    public double getValDouble() {
        if (this.onlyint) {
            this.dval = (int)this.dval;
        }
        return this.dval;
    }

    @Override
    public void setValDouble(double d) {
        this.dval = d;
    }

    @Override
    public double getMin() {
        return this.min;
    }

    @Override
    public double getMax() {
        return this.max;
    }

    @Override
    public boolean isCombo() {
        return this.mode.equalsIgnoreCase("Combo");
    }

    @Override
    public boolean isCheck() {
        return this.mode.equalsIgnoreCase("Check");
    }

    @Override
    public boolean isSlider() {
        return this.mode.equalsIgnoreCase("Slider");
    }

    @Override
    public boolean onlyInt() {
        return this.onlyint;
    }
}
