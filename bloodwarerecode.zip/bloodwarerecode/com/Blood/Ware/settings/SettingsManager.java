package com.Blood.Ware.settings;

import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setteng;
import com.Blood.Ware.settings.Setting;
import java.util.ArrayList;

public class SettingsManager {
    public /* synthetic */ ArrayList<Setting> settings;

    public SettingsManager() {
        this.settings = new ArrayList();
    }

    public void rSetting(Setting setting) {
        this.settings.add(setting);
    }

    public void fSetting(Setting setting) {
        this.settings.add(setting);
    }

    public ArrayList<Setting> getSettings() {
        return this.settings;
    }

    public ArrayList<Setting> getSettingsByMod(Module module) {
        ArrayList<Setting> arrayList = new ArrayList<Setting>();
        for (Setting setting : this.getSettings()) {
            if (!setting.getParentMod().equals(module)) continue;
            arrayList.add(setting);
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return arrayList;
    }

    public Setting getSettingByName(String string, String string2) {
        for (Setting setting : this.getSettings()) {
            if (!setting.getName().equalsIgnoreCase(string)) continue;
            return setting;
        }
        System.out.println("Setting not found! (" + string + ").");
        return null;
    }

    public Setting getSettingByName(Module module, String string) {
        for (Setting setting : this.getSettings()) {
            if (!setting.getName().equalsIgnoreCase(string) || setting.getParentMod() != module) continue;
            return setting;
        }
        System.err.println("[Tutorial] Error Setting NOT found: '" + string + "'!");
        return null;
    }

    public <T> void rSetting(Setteng<T> setteng) {
    }
}
