package com.Blood.Ware.settings;

import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.function.Predicate;

public class Setteng<T> {
    public final /* synthetic */ String name;
    public final /* synthetic */ T defaultValue;
    public /* synthetic */ T value;
    public /* synthetic */ T plannedValue;
    public /* synthetic */ T min;
    public /* synthetic */ T max;
    public /* synthetic */ Setting parent;
    public /* synthetic */ boolean hasRestriction;
    public /* synthetic */ Predicate<T> visibility;
    public /* synthetic */ String description;
    public /* synthetic */ Module module;

    public Setteng(String string, T t) {
        this.parent = null;
        this.name = string;
        this.defaultValue = t;
        this.value = t;
        this.plannedValue = t;
        this.description = "";
    }

    public Setteng(String string, T t, T t2, T t3) {
        this.parent = null;
        this.name = string;
        this.defaultValue = t;
        this.value = t;
        this.min = t2;
        this.max = t3;
        this.plannedValue = t;
        this.description = "";
        this.hasRestriction = true;
    }

    public Setteng(String string, T t, T t2, T t3, Predicate<T> predicate) {
        this.parent = null;
        this.name = string;
        this.defaultValue = t;
        this.value = t;
        this.min = t2;
        this.max = t3;
        this.plannedValue = t;
        this.visibility = predicate;
        this.description = "";
        this.hasRestriction = true;
    }

    public Setteng(String string, T t, Predicate<T> predicate) {
        this.parent = null;
        this.name = string;
        this.defaultValue = t;
        this.value = t;
        this.visibility = predicate;
        this.plannedValue = t;
    }
}
