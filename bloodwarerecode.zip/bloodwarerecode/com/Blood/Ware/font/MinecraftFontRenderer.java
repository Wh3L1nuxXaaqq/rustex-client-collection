package com.Blood.Ware.font;

import com.Blood.Ware.font.CFont;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

public class MinecraftFontRenderer
extends CFont {
    public /* synthetic */ CFont.CharData[] boldChars;
    public /* synthetic */ CFont.CharData[] italicChars;
    public /* synthetic */ CFont.CharData[] boldItalicChars;
    public /* synthetic */ int[] colorCode;
    public /* synthetic */ String colorcodeIdentifiers;
    public /* synthetic */ DynamicTexture texBold;
    public /* synthetic */ DynamicTexture texItalic;
    public /* synthetic */ DynamicTexture texItalicBold;

    public MinecraftFontRenderer(Font font, boolean bl, boolean bl2) {
        super(font, bl, bl2);
        this.boldChars = new CFont.CharData[256];
        this.italicChars = new CFont.CharData[256];
        this.boldItalicChars = new CFont.CharData[256];
        this.colorCode = new int[32];
        this.colorcodeIdentifiers = "0123456789abcdefklmnor";
        this.setupMinecraftColorcodes();
        this.setupBoldItalicIDs();
    }

    public int drawStringWithShadow(String string, double d, float f, int n) {
        float f2 = this.drawString(string, d + (double)0.9f, (double)f + 0.5, n, true, 8.3f);
        return (int)Math.max(f2, this.drawString(string, d, f, n, false, 8.3f));
    }

    public int drawString(String string, double d, float f, int n) {
        return (int)this.drawString(string, d, f, n, false, 8.3f);
    }

    public int drawPassword(String string, double d, float f, int n) {
        return (int)this.drawString(string.replaceAll(".", "."), d, f, n, false, 8.0f);
    }

    public int drawNoBSString(String string, double d, float f, int n) {
        return (int)this.drawNoBSString(string, d, f, n, false);
    }

    public int drawSmoothString(String string, double d, float f, int n) {
        return (int)this.drawSmoothString(string, d, f, n, false);
    }

    public double getPasswordWidth(String string) {
        return this.getStringWidth(string.replaceAll(".", "."), 8.0f);
    }

    public float drawCenteredString(String string, float f, float f2, int n) {
        return this.drawString(string, f - (float)(this.getStringWidth(string) / 2.0), f2, n);
    }

    public float drawNoBSCenteredString(String string, float f, float f2, int n) {
        return this.drawNoBSString(string, f - (float)(this.getStringWidth(string) / 2.0), f2, n);
    }

    public float drawCenteredStringWithShadow(String string, float f, float f2, int n) {
        return this.drawStringWithShadow(string, f - (float)(this.getStringWidth(string) / 2.0), f2, n);
    }

    public float drawString(String string, double d, double d2, int n, boolean bl, float f) {
        d -= 1.0;
        if (string == null) {
            return 0.0f;
        }
        if (n == 0x20FFFFFF) {
            n = 0xFFFFFF;
        }
        if ((n & 0xFC000000) == 0) {
            n |= 0xFF000000;
        }
        if (bl) {
            n = (n & 0xFCFCFC) >> 2 | n & 0xFF000000;
        }
        CFont.CharData[] charDataArray = this.charData;
        float f2 = (float)(n >> 24 & 0xFF) / 255.0f;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        boolean bl6 = false;
        boolean bl7 = true;
        d *= 2.0;
        d2 = (d2 - 3.0) * 2.0;
        GL11.glPushMatrix();
        GlStateManager.func_179139_a((double)0.5, (double)0.5, (double)0.5);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b((int)770, (int)771);
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f2);
        GlStateManager.func_179098_w();
        GlStateManager.func_179144_i((int)this.tex.func_110552_b());
        GL11.glBindTexture((int)3553, (int)this.tex.func_110552_b());
        for (int i = 0; i < string.length(); i -= 9450) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                int n2 = 21;
                try {
                    n2 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                if (n2 < 16) {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                    if (n2 < 0) {
                        n2 = 15;
                    }
                    if (bl) {
                        n2 += 1100;
                        n2 -= 1084;
                    }
                    int n3 = this.colorCode[n2];
                    GlStateManager.func_179131_c((float)((float)(n3 >> 16 & 0xFF) / 255.0f), (float)((float)(n3 >> 8 & 0xFF) / 255.0f), (float)((float)(n3 & 0xFF) / 255.0f), (float)f2);
                } else if (n2 == 16) {
                    bl2 = true;
                } else if (n2 == 17) {
                    bl3 = true;
                    if (bl4) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texBold.func_110552_b());
                        charDataArray = this.boldChars;
                    }
                } else if (n2 == 18) {
                    bl5 = true;
                } else if (n2 == 19) {
                    bl6 = true;
                } else if (n2 == 20) {
                    bl4 = true;
                    if (bl3) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texItalic.func_110552_b());
                        charDataArray = this.italicChars;
                    }
                } else {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f2);
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                }
                i -= 20327;
                i += 20328;
            } else if (c < charDataArray.length) {
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl5) {
                    this.drawLine(d, d2 + (double)(charDataArray[c].height / 2), d + (double)charDataArray[c].width - 8.0, d2 + (double)(charDataArray[c].height / 2), 1.0f);
                }
                if (bl6) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)((float)charDataArray[c].width - f + (float)this.charOffset);
            }
            i += 9451;
        }
        GL11.glHint((int)3155, (int)4352);
        GL11.glPopMatrix();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        return (float)d / 2.0f;
    }

    public float drawSmoothString(String string, double d, double d2, int n, boolean bl) {
        d -= 1.0;
        if (string == null) {
            return 0.0f;
        }
        CFont.CharData[] charDataArray = this.charData;
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        boolean bl6 = false;
        boolean bl7 = true;
        d *= 2.0;
        d2 = (d2 - 3.0) * 2.0;
        GL11.glPushMatrix();
        GlStateManager.func_179139_a((double)0.5, (double)0.5, (double)0.5);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b((int)770, (int)771);
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
        GlStateManager.func_179098_w();
        GlStateManager.func_179144_i((int)this.tex.func_110552_b());
        GL11.glBindTexture((int)3553, (int)this.tex.func_110552_b());
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        for (int i = 0; i < string.length(); i += 19988) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                int n2 = 21;
                try {
                    n2 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                if (n2 < 16) {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                    if (n2 < 0) {
                        n2 = 15;
                    }
                    if (bl) {
                        n2 += 25854;
                        n2 -= 25838;
                    }
                    int n3 = this.colorCode[n2];
                    GlStateManager.func_179131_c((float)((float)(n3 >> 16 & 0xFF) / 255.0f), (float)((float)(n3 >> 8 & 0xFF) / 255.0f), (float)((float)(n3 & 0xFF) / 255.0f), (float)f);
                } else if (n2 == 16) {
                    bl2 = true;
                } else if (n2 == 17) {
                    bl3 = true;
                    if (bl4) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texBold.func_110552_b());
                        charDataArray = this.boldChars;
                    }
                } else if (n2 == 18) {
                    bl5 = true;
                } else if (n2 == 19) {
                    bl6 = true;
                } else if (n2 == 20) {
                    bl4 = true;
                    if (bl3) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texItalic.func_110552_b());
                        charDataArray = this.italicChars;
                    }
                } else {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                }
                i += 27599;
                i -= 27598;
            } else if (c < charDataArray.length) {
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl5) {
                    this.drawLine(d, d2 + (double)(charDataArray[c].height / 2), d + (double)charDataArray[c].width - 8.0, d2 + (double)(charDataArray[c].height / 2), 1.0f);
                }
                if (bl6) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)((float)charDataArray[c].width - 8.3f + (float)this.charOffset);
            }
            i -= 19987;
        }
        GL11.glHint((int)3155, (int)4352);
        GL11.glPopMatrix();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        return (float)d / 2.0f;
    }

    public float drawNoBSString(String string, double d, double d2, int n, boolean bl) {
        d -= 1.0;
        if (string == null) {
            return 0.0f;
        }
        CFont.CharData[] charDataArray = this.charData;
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        boolean bl6 = false;
        boolean bl7 = true;
        d *= 2.0;
        d2 = (d2 - 3.0) * 2.0;
        GL11.glPushMatrix();
        GlStateManager.func_179139_a((double)0.5, (double)0.5, (double)0.5);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b((int)770, (int)771);
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
        GlStateManager.func_179098_w();
        GlStateManager.func_179144_i((int)this.tex.func_110552_b());
        GL11.glBindTexture((int)3553, (int)this.tex.func_110552_b());
        GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
        for (int i = 0; i < string.length(); i += 31141) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                int n2 = 21;
                try {
                    n2 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                if (n2 < 16) {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                    if (n2 < 0) {
                        n2 = 15;
                    }
                    if (bl) {
                        n2 -= 31514;
                        n2 += 31530;
                    }
                    int n3 = this.colorCode[n2];
                    GlStateManager.func_179131_c((float)((float)(n3 >> 16 & 0xFF) / 255.0f), (float)((float)(n3 >> 8 & 0xFF) / 255.0f), (float)((float)(n3 & 0xFF) / 255.0f), (float)f);
                } else if (n2 == 16) {
                    bl2 = true;
                } else if (n2 == 17) {
                    bl3 = true;
                    if (bl4) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texBold.func_110552_b());
                        charDataArray = this.boldChars;
                    }
                } else if (n2 == 18) {
                    bl5 = true;
                } else if (n2 == 19) {
                    bl6 = true;
                } else if (n2 == 20) {
                    bl4 = true;
                    if (bl3) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texItalic.func_110552_b());
                        charDataArray = this.italicChars;
                    }
                } else {
                    bl3 = false;
                    bl4 = false;
                    bl2 = false;
                    bl6 = false;
                    bl5 = false;
                    GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                }
                i += 19293;
                i -= 19292;
            } else if (c < charDataArray.length) {
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl5) {
                    this.drawLine(d, d2 + (double)(charDataArray[c].height / 2), d + (double)charDataArray[c].width - 8.0, d2 + (double)(charDataArray[c].height / 2), 1.0f);
                }
                if (bl6) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)((float)charDataArray[c].width - 8.3f + (float)this.charOffset);
            }
            i -= 31140;
        }
        GL11.glHint((int)3155, (int)4352);
        GL11.glPopMatrix();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        return (float)d / 2.0f;
    }

    public double getStringWidth(String string) {
        if (string == null) {
            return 0.0;
        }
        float f = 0.0f;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        for (int i = 0; i < string.length(); i -= 21928) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                int n = "0123456789abcdefklmnor".indexOf(c);
                bl = false;
                bl2 = false;
                i += 25172;
                i -= 25171;
            } else if (c < charDataArray.length) {
                f += (float)charDataArray[c].width - 8.3f + (float)this.charOffset;
            }
            i += 21929;
        }
        return f / 2.0f;
    }

    public double getStringWidth(String string, float f) {
        if (string == null) {
            return 0.0;
        }
        float f2 = 0.0f;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        for (int i = 0; i < string.length(); i -= 24231) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                int n = "0123456789abcdefklmnor".indexOf(c);
                bl = false;
                bl2 = false;
                i += 24703;
                i -= 24702;
            } else if (c < charDataArray.length) {
                f2 += (float)charDataArray[c].width - f + (float)this.charOffset;
            }
            i += 24232;
        }
        return f2 / 2.0f;
    }

    public int getHeight() {
        return (this.fontHeight - 8) / 2;
    }

    @Override
    public void setFont(Font font) {
        super.setFont(font);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setAntiAlias(boolean bl) {
        super.setAntiAlias(bl);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setFractionalMetrics(boolean bl) {
        super.setFractionalMetrics(bl);
        this.setupBoldItalicIDs();
    }

    public void setupBoldItalicIDs() {
        this.texBold = this.setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
        this.texItalic = this.setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
        this.texItalicBold = this.setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
    }

    public void drawLine(double d, double d2, double d3, double d4, float f) {
        GL11.glDisable((int)3553);
        GL11.glLineWidth((float)f);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
    }

    public List<String> wrapWords(String string, double d) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (this.getStringWidth(string) > d) {
            String[] stringArray = string.split(" ");
            StringBuilder stringBuilder = new StringBuilder();
            char c = '\uffff';
            String[] stringArray2 = stringArray;
            int n = stringArray2.length;
            for (int i = 0; i < n; i += 27937) {
                String string2 = stringArray2[i];
                for (int j = 0; j < string2.toCharArray().length; j -= 18678) {
                    char c2 = string2.toCharArray()[j];
                    if (c2 == '\u00a7' && j < string2.toCharArray().length - 1) {
                        c = string2.toCharArray()[j + 1];
                    }
                    j += 18679;
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                if (this.getStringWidth(stringBuilder2.append((Object)stringBuilder).append(string2).append(" ").toString()) < d) {
                    stringBuilder.append(string2).append(" ");
                } else {
                    arrayList.add(stringBuilder.toString());
                    stringBuilder = new StringBuilder("\u00a7" + c + string2 + " ");
                }
                i -= 27936;
            }
            if (stringBuilder.length() > 0) {
                if (this.getStringWidth(stringBuilder.toString()) < d) {
                    arrayList.add("\u00a7" + c + stringBuilder + " ");
                    stringBuilder = new StringBuilder();
                } else {
                    arrayList.addAll(this.formatString(stringBuilder.toString(), d));
                }
            }
        } else {
            arrayList.add(string);
        }
        return arrayList;
    }

    public List<String> formatString(String string, double d) {
        ArrayList<String> arrayList = new ArrayList<String>();
        StringBuilder stringBuilder = new StringBuilder();
        char c = '\uffff';
        char[] cArray = string.toCharArray();
        for (int i = 0; i < cArray.length; i += 11674) {
            char c2 = cArray[i];
            if (c2 == '\u00a7' && i < cArray.length - 1) {
                c = cArray[i + 1];
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            if (this.getStringWidth(stringBuilder2.append(stringBuilder.toString()).append(c2).toString()) < d) {
                stringBuilder.append(c2);
            } else {
                arrayList.add(stringBuilder.toString());
                stringBuilder = new StringBuilder("\u00a7" + c + c2);
            }
            i -= 11673;
        }
        if (stringBuilder.length() > 0) {
            arrayList.add(stringBuilder.toString());
        }
        return arrayList;
    }

    public void setupMinecraftColorcodes() {
        for (int i = 0; i < 32; i += 29103) {
            int n = (i >> 3 & 1) * 85;
            int n2 = (i >> 2 & 1) * 170 + n;
            int n3 = (i >> 1 & 1) * 170 + n;
            int n4 = (i & 1) * 170 + n;
            if (i == 6) {
                n2 -= 7179;
                n2 += 7264;
            }
            if (i >= 16) {
                n2 /= 4;
                n3 /= 4;
                n4 /= 4;
            }
            this.colorCode[i] = (n2 & 0xFF) << 16 | (n3 & 0xFF) << 8 | n4 & 0xFF;
            i -= 29102;
        }
    }

    public String trimStringToWidth(String string, int n) {
        return this.trimStringToWidth(string, n, false);
    }

    public String trimStringToWidthPassword(String string, int n, boolean bl) {
        string = string.replaceAll(".", ".");
        return this.trimStringToWidth(string, n, bl);
    }

    public float getCharWidthFloat(char c) {
        if (c == '\u00a7') {
            return -1.0f;
        }
        if (c == ' ') {
            return 2.0f;
        }
        int n = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8\u00a3\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u00ae\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261\u00b1\u2265\u2264\u2320\u2321\u00f7\u2248\u00b0\u2219\u00b7\u221a\u207f\u00b2\u25a0\u0000".indexOf(c);
        if (c > '\u0000' && n != -1) {
            return (float)this.charData[n].width / 2.0f - 4.0f;
        }
        if ((float)this.charData[c].width / 2.0f - 4.0f != 0.0f) {
            int n2 = (int)((float)this.charData[c].width / 2.0f - 4.0f) >>> 4;
            int n3 = (int)((float)this.charData[c].width / 2.0f - 4.0f) & 0xF;
            n3 -= 21642;
            return ((n3 += 21643) - (n2 &= 0xF)) / 2 + 1;
        }
        return 0.0f;
    }

    public String trimStringToWidth(String string, int n, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        float f = 0.0f;
        int n2 = bl ? string.length() - 1 : 0;
        int n3 = bl ? -1 : 1;
        boolean bl2 = false;
        boolean bl3 = false;
        for (int i = n2; i >= 0 && i < string.length() && f < (float)n; i += n3) {
            char c = string.charAt(i);
            float f2 = this.getCharWidthFloat(c);
            if (bl2) {
                bl2 = false;
                if (c != 'l' && c != 'L') {
                    if (c == 'r' || c == 'R') {
                        bl3 = false;
                    }
                } else {
                    bl3 = true;
                }
            } else if (f2 < 0.0f) {
                bl2 = true;
            } else {
                f += f2;
                if (bl3) {
                    f += 1.0f;
                }
            }
            if (f > (float)n) break;
            if (bl) {
                stringBuilder.insert(0, c);
                continue;
            }
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }
}
