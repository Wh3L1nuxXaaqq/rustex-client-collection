package com.Blood.Ware.font;

import com.Blood.Ware.font.MinecraftFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class FontUtils {
    public static volatile /* synthetic */ int completed;
    public static /* synthetic */ MinecraftFontRenderer normal;
    public static /* synthetic */ Font normal_;

    public static Font getFont(Map<String, Font> map, String string, int n) {
        Font font = null;
        try {
            if (map.containsKey(string)) {
                font = map.get(string).deriveFont(0, n);
            } else {
                InputStream inputStream = Minecraft.func_71410_x().func_110442_L().func_110536_a(new ResourceLocation(string)).func_110527_b();
                font = Font.createFont(0, inputStream);
                map.put(string, font);
                font = font.deriveFont(0, n);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            font = new Font("default", 0, 10);
        }
        return font;
    }

    public static boolean hasLoaded() {
        return completed >= 3;
    }

    public static void bootstrap() {
        new Thread(() -> {
            HashMap<String, Font> hashMap = new HashMap<String, Font>();
            normal_ = FontUtils.getFont(hashMap, "font.otf", 30);
            ++completed;
        }).start();
        new Thread(() -> {
            HashMap hashMap = new HashMap();
            ++completed;
        }).start();
        new Thread(() -> {
            HashMap hashMap = new HashMap();
            ++completed;
        }).start();
        while (!FontUtils.hasLoaded()) {
            try {
                Thread.sleep(0x31402F9C7F73655CL ^ 0x31402F9C7F736559L);
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
        normal = new MinecraftFontRenderer(normal_, true, true);
    }
}
