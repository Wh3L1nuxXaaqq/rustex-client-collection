package com.Blood.Ware.manager;

import com.Blood.Ware.font.FontUtils;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.combat.AimAssist;
import com.Blood.Ware.module.combat.AimBot;
import com.Blood.Ware.module.combat.AimBot2;
import com.Blood.Ware.module.combat.AntiBot;
import com.Blood.Ware.module.combat.BAim;
import com.Blood.Ware.module.hud.ArmorHUD;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.module.hud.ModuleList;
import com.Blood.Ware.module.hud.Notifications;
import com.Blood.Ware.module.hud.WaterMark;
import com.Blood.Ware.module.misc.Africa;
import com.Blood.Ware.module.misc.AntiZoomSmooth;
import com.Blood.Ware.module.misc.AutoMine;
import com.Blood.Ware.module.misc.ChatCalc;
import com.Blood.Ware.module.misc.ChestStealer;
import com.Blood.Ware.module.misc.ClickPosInfo;
import com.Blood.Ware.module.misc.Crosshair;
import com.Blood.Ware.module.misc.DiscordRPC;
import com.Blood.Ware.module.misc.FogColor;
import com.Blood.Ware.module.misc.InvViewer;
import com.Blood.Ware.module.misc.JoinCheck;
import com.Blood.Ware.module.misc.Keystrokes;
import com.Blood.Ware.module.misc.MiddleClick;
import com.Blood.Ware.module.misc.SoundEsp;
import com.Blood.Ware.module.misc.Zoom;
import com.Blood.Ware.module.movement.GuiWalk;
import com.Blood.Ware.module.movement.NoClip;
import com.Blood.Ware.module.movement.NoPush;
import com.Blood.Ware.module.movement.Sprint;
import com.Blood.Ware.module.render.Arrows;
import com.Blood.Ware.module.render.BlockEsp;
import com.Blood.Ware.module.render.ChinaHat;
import com.Blood.Ware.module.render.ESP;
import com.Blood.Ware.module.render.FakePlayer;
import com.Blood.Ware.module.render.Freecam;
import com.Blood.Ware.module.render.FullBright;
import com.Blood.Ware.module.render.HouseEsp;
import com.Blood.Ware.module.render.ItemESP;
import com.Blood.Ware.module.render.NameTags;
import com.Blood.Ware.module.render.NoHurtCum;
import com.Blood.Ware.module.render.PenisESP;
import com.Blood.Ware.module.render.Tracers;
import com.Blood.Ware.module.render.Trails;
import com.Blood.Ware.module.render.ViewModel;
import com.Blood.Ware.module.render.WallHack;
import com.Blood.Ware.module.render.WallHackPlayer;
import com.google.common.reflect.ClassPath;
import das.ist.denger.natve.Native;
import java.util.ArrayList;

@Native
public class ModuleManager {
    public static /* synthetic */ ArrayList<Module> modules;

    public ModuleManager() {
        modules = new ArrayList();
        modules.clear();
        modules.add(new BlockEsp());
        modules.add(new BAim());
        modules.add(new AimBot());
        modules.add(new ClickGUI());
        modules.add(new ESP());
        modules.add(new AntiZoomSmooth());
        modules.add(new Arrows());
        modules.add(new ClickPosInfo());
        modules.add(new ChestStealer());
        modules.add(new JoinCheck());
        modules.add(new DiscordRPC());
        modules.add(new SoundEsp());
        modules.add(new AutoMine());
        modules.add(new ChatCalc());
        modules.add(new HouseEsp());
        modules.add(new Zoom());
        modules.add(new PenisESP());
        modules.add(new ItemESP());
        modules.add(new Tracers());
        modules.add(new Crosshair());
        modules.add(new GuiWalk());
        modules.add(new NoClip());
        modules.add(new FogColor());
        modules.add(new ArmorHUD());
        modules.add(new Keystrokes());
        modules.add(new Freecam());
        modules.add(new FullBright());
        modules.add(new InvViewer());
        modules.add(new NameTags());
        modules.add(new WallHackPlayer());
        modules.add(new NoHurtCum());
        modules.add(new ModuleList());
        modules.add(new ViewModel());
        modules.add(new Notifications());
        modules.add(new FakePlayer());
        modules.add(new Africa());
        modules.add(new MiddleClick());
        modules.add(new ChinaHat());
        modules.add(new Sprint());
        modules.add(new NoPush());
        modules.add(new AimAssist());
        modules.add(new AntiBot());
        modules.add(new WallHack());
        modules.add(new WaterMark());
        modules.add(new AimBot2());
        modules.add(new Trails());
        FontUtils.bootstrap();
        for (Module module : modules) {
        }
    }

    public static ArrayList<Class<?>> getClasses(String string) {
        ArrayList arrayList = new ArrayList();
        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            for (ClassPath.ClassInfo classInfo : ClassPath.from(classLoader).getAllClasses()) {
                if (!classInfo.getName().startsWith(string)) continue;
                arrayList.add(classInfo.load());
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return arrayList;
    }

    public Module getModule(String string) {
        for (Module module : modules) {
            if (!module.getName().equalsIgnoreCase(string)) continue;
            return module;
        }
        return null;
    }

    public <T extends Module> T getModuleByClass(Class<T> clazz) {
        for (Module module : modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)module;
        }
        return null;
    }

    public ArrayList<Module> getModuleList() {
        return modules;
    }

    public ArrayList<Module> getModulesInCategory(Category category) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        for (Module module : modules) {
            if (module.getCategory() != category) continue;
            arrayList.add(module);
        }
        return arrayList;
    }

    public ArrayList<Module> getModules(Category category) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        for (Module module : modules) {
            if (module.getCategory() != category) continue;
            arrayList.add(module);
        }
        return arrayList;
    }
}
