package com.Blood.Ware.manager;

import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.notifications.notifications;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;

public class FriendManager {
    public static /* synthetic */ List<String> FRIENDS;
    public static /* synthetic */ ArrayList friendsList;

    public static void removeFriend(String string) {
        if (friendsList.contains(string)) {
            friendsList.remove(string);
            notifications.add(String.valueOf(new StringBuilder().append(TextFormatting.RED).append(string)), "Remove from Friend list", Type.OK);
        }
    }

    public static void toggleFriend(String string) {
        if (FriendManager.isFriend(string)) {
            FRIENDS.remove(string);
            notifications.add(TextFormatting.RED + string, "Remove from Friend list", Type.OK);
        } else {
            FRIENDS.add(string);
            notifications.add(TextFormatting.GREEN + string, "add in Friends list", Type.OK);
        }
    }

    public static boolean isFriend(String string) {
        return FRIENDS.contains(string);
    }

    public static Entity ifFreand2(String string) {
        EntityPlayer.func_175147_b((String)string);
        return FriendManager.ifFreand2(string);
    }

    static {
        FRIENDS = new ArrayList<String>();
    }
}
