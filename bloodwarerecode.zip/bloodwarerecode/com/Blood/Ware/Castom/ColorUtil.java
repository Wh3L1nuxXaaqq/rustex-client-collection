package com.Blood.Ware.Castom;

import java.awt.Color;

public class ColorUtil {
    public static Color interpolate(Color color, Color color2, float f) {
        f = Math.min(1.0f, Math.max(0.0f, f));
        return new Color(ColorUtil.interpolateInt(color.getRed(), color2.getRed(), f), ColorUtil.interpolateInt(color.getGreen(), color2.getGreen(), f), ColorUtil.interpolateInt(color.getBlue(), color2.getBlue(), f), ColorUtil.interpolateInt(color.getAlpha(), color2.getAlpha(), f));
    }

    public static int interpolateInt(int n, int n2, float f) {
        return (int)((float)n + (float)(n2 - n) * f);
    }

    public static int getRGB(int n, int n2, int n3, int n4) {
        return (n4 & 0xFF) << 24 | (n & 0xFF) << 16 | (n2 & 0xFF) << 8 | n3 & 0xFF;
    }

    public static Color rainbow(int n, float f, float f2) {
        double d = Math.ceil((double)(System.currentTimeMillis() + (long)n) / 16.0);
        return Color.getHSBColor((float)((d %= 360.0) / 360.0), f, f2);
    }

    public static int getAlpha(int n) {
        return n >> 24 & 0xFF;
    }

    public static int getRed(int n) {
        return n >> 16 & 0xFF;
    }

    public static int getGreen(int n) {
        return n >> 8 & 0xFF;
    }

    public static int getBlue(int n) {
        return n & 0xFF;
    }
}
