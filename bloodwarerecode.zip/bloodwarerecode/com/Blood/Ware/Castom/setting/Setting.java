package com.Blood.Ware.Castom.setting;

import com.Blood.Ware.module.Module;
import java.util.ArrayList;

public class Setting {
    public /* synthetic */ String mode;
    public /* synthetic */ double min;
    public /* synthetic */ String sval;
    public /* synthetic */ double dval;
    public /* synthetic */ boolean bval;
    public /* synthetic */ double max;
    public /* synthetic */ ArrayList options;
    public /* synthetic */ Module parent;
    public /* synthetic */ String name;
    public /* synthetic */ boolean onlyint;

    public double getValDouble() {
        if (this.onlyint) {
            this.dval = (int)this.dval;
        }
        return this.dval;
    }

    public double getMin() {
        return this.min;
    }

    public String getValString() {
        return this.sval;
    }

    public boolean isSlider() {
        return this.mode.equalsIgnoreCase("Slider");
    }

    public boolean isCombo() {
        return this.mode.equalsIgnoreCase("Combo");
    }

    public String getName() {
        return this.name;
    }

    public Setting(String string, Module module, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.bval = bl;
        this.mode = "Check";
    }

    public boolean isCheck() {
        return this.mode.equalsIgnoreCase("Check");
    }

    public ArrayList getOptions() {
        return this.options;
    }

    public Setting(String string, Module module, double d, double d2, double d3, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.dval = d;
        this.min = d2;
        this.max = d3;
        this.onlyint = bl;
        this.mode = "Slider";
    }

    public boolean getValBoolean() {
        return this.bval;
    }

    public Module getParentMod() {
        return this.parent;
    }

    public void setValString(String string) {
        this.sval = string;
    }

    public Setting() {
        this.onlyint = false;
    }

    public void setValBoolean(boolean bl) {
        this.bval = bl;
    }

    public Setting(String string, Module module, String string2, ArrayList arrayList) {
        this.onlyint = false;
        this.name = string;
        this.parent = module;
        this.sval = string2;
        this.options = arrayList;
        this.mode = "Combo";
    }

    public double getMax() {
        return this.max;
    }

    public void setValDouble(double d) {
        this.dval = d;
    }

    public boolean onlyInt() {
        return this.onlyint;
    }
}
