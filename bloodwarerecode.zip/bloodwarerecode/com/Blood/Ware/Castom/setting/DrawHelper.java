package com.Blood.Ware.Castom.setting;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class DrawHelper {
    public static /* synthetic */ int test;
    public static /* synthetic */ float zLevel;
    public static /* synthetic */ int time;
    public static /* synthetic */ boolean anim;
    public static /* synthetic */ float alpheble;
    public static /* synthetic */ float animtest;
    public static final /* synthetic */ Frustum frustrum;
    public static /* synthetic */ Minecraft mc;

    public static boolean isInViewFrustrum(AxisAlignedBB axisAlignedBB) {
        Entity entity = Minecraft.func_71410_x().func_175606_aa();
        frustrum.func_78547_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
        return frustrum.func_78546_a(axisAlignedBB);
    }

    public static int toRGBA(float f, float f2, float f3, float f4) {
        return DrawHelper.toRGBA((int)(f * 255.0f), (int)(f2 * 255.0f), (int)(f3 * 255.0f), (int)(f4 * 255.0f));
    }

    public static int reAlpha(int n, float f) {
        Color color = new Color(n);
        return new Color(0.003921569f * (float)color.getRed(), 0.003921569f * (float)color.getGreen(), 0.003921569f * (float)color.getBlue(), f).getRGB();
    }

    public static void enableSmoothLine(float f) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)f);
    }

    public static void startSmooth() {
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2881);
        GL11.glEnable((int)2832);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glHint((int)3153, (int)4354);
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static Color getGradientOffset(Color color, Color color2, double d) {
        double d2;
        if (d > 1.0) {
            d2 = d % 1.0;
            d = (int)d % 2 == 0 ? d2 : 1.0 - d2;
        }
        d2 = 1.0 - d;
        return new Color((int)((double)color.getRed() * d2 + (double)color2.getRed() * d), (int)((double)color.getGreen() * d2 + (double)color2.getGreen() * d), (int)((double)color.getBlue() * d2 + (double)color2.getBlue() * d));
    }

    public static int getColor(int n, int n2, int n3) {
        return DrawHelper.getColor(n, n2, n3, 255);
    }

    public static int getColor(int n, int n2) {
        return DrawHelper.getColor(n, n, n, n2);
    }

    public static void drawRect2(double d, double d2, double d3, double d4, int n) {
        DrawHelper.drawRect(d, d2, d + d3, d2 + d4, n);
    }

    public static double interpolate(double d, double d2, double d3) {
        return d2 + (d - d2) * d3;
    }

    public static int getTeamColor(Entity entity) {
        return entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405cR\u043f\u0457\u0405f]\u043f\u0457\u0405c").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(255, 60, 60).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u04059B\u043f\u0457\u0405f]\u043f\u0457\u04059").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(60, 60, 255).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405eY\u043f\u0457\u0405f]\u043f\u0457\u0405e").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(255, 255, 60).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405aG\u043f\u0457\u0405f]\u043f\u0457\u0405a").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(60, 255, 60).getRGB()) : DrawHelper.getColor(new Color(255, 255, 255).getRGB()))));
    }

    public static void drawRect(double d, double d2, double d3, double d4, int n) {
        double d5;
        if (d < d3) {
            d5 = d;
            d = d3;
            d3 = d5;
        }
        if (d2 < d4) {
            d5 = d2;
            d2 = d4;
            d4 = d5;
        }
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179131_c((float)f2, (float)f3, (float)f4, (float)f);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(d, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d2, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static int getRandomColor() {
        char[] cArray = "012345678".toCharArray();
        String string = "0x";
        for (int i = 0; i < 6; i += 30893) {
            string = String.valueOf(new StringBuilder().append(string).append(cArray[new Random().nextInt(cArray.length)]));
            i -= 30892;
        }
        return Integer.decode(string);
    }

    public static void drawSelectionBoundingBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        tessellator.func_78381_a();
    }

    public static int astolfoColors5(float f, float f2, float f3, float f4) {
        float f5;
        float f6 = 1800.0f;
        for (f5 = (float)(System.currentTimeMillis() % (long)((int)f6)) + (f2 - f) * f4; f5 > f6; f5 -= f6) {
        }
        float f7 = f5 / f6;
        if ((double)f7 > 0.5) {
            f7 = 0.5f - (f7 - 0.5f);
        }
        return Color.HSBtoRGB(f7 + 0.5f, f3, 1.0f);
    }

    public static Color TwoColoreffect(Color color, Color color2, double d) {
        float f = MathHelper.func_76131_a((float)((float)Math.sin(Math.PI * 6 * (d / 4.0 % 1.0)) / 2.0f + 0.5f), (float)0.0f, (float)1.0f);
        return new Color(DrawHelper.lerp((float)color.getRed() / 255.0f, (float)color2.getRed() / 255.0f, f), DrawHelper.lerp((float)color.getGreen() / 255.0f, (float)color2.getGreen() / 255.0f, f), DrawHelper.lerp((float)color.getBlue() / 255.0f, (float)color2.getBlue() / 255.0f, f));
    }

    public static int[] getFractionIndicies(float[] fArray, float f) {
        int n;
        int[] nArray = new int[2];
        for (n = 0; n < fArray.length && fArray[n] <= f; n -= 11770) {
            n += 11771;
        }
        if (n >= fArray.length) {
            n = fArray.length - 1;
        }
        nArray[0] = n - 1;
        nArray[1] = n;
        return nArray;
    }

    public static Color rainbow2(int n, float f, float f2) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + (long)n) / (0xB6CA9FEC4BC30A94L ^ 0xB6CA9FEC4BC30A84L)) % 360.0 / 360.0), f, f2);
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4, int n5) {
        GL11.glPushMatrix();
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        DrawHelper.setColor(n5);
        mc.func_110434_K().func_110577_a(resourceLocation);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        GL11.glPopMatrix();
    }

    public static void prepareScissorBox(float f, float f2, float f3, float f4) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        int n = scaledResolution.func_78325_e();
        GL11.glScissor((int)((int)(f * (float)n)), (int)((int)(((float)scaledResolution.func_78328_b() - f4) * (float)n)), (int)((int)((f3 - f) * (float)n)), (int)((int)((f4 - f2) * (float)n)));
    }

    public static Color astolfoColor(int n, int n2) {
        float f;
        float f2 = 2900.0f;
        for (f = (float)(System.currentTimeMillis() % (long)((int)f2)) + (float)((n2 - n) * 9); f > f2; f -= f2) {
        }
        float f3 = f / f2;
        if ((double)f3 > 0.5) {
            f3 = 0.5f - (f3 - 0.5f);
        }
        return new Color(f3 + 0.5f, 0.5f, 1.0f);
    }

    public static void drawFilledBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void drawOutline(AxisAlignedBB axisAlignedBB, float f, Color color) {
        GL11.glPushMatrix();
        GL11.glLineWidth((float)f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        tessellator.func_78381_a();
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glPopMatrix();
    }

    public static int getColor(int n, int n2, int n3, int n4) {
        return 0 | n4 << 24 | n << 16 | n2 << 8 | n3;
    }

    public static int rainbow(int n, float f, float f2) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + (long)n) / (0x8C8FEE7EC24273B0L ^ 0x8C8FEE7EC24273A0L)) % 360.0 / 360.0), f, f2).getRGB();
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static Color getRainbow(int n, int n2) {
        return Color.getHSBColor((float)((System.currentTimeMillis() + (long)n) % (long)n2) / (float)n2, 0.7f, 1.0f);
    }

    public static float lerp(float f, float f2, float f3) {
        return f + f3 * (f2 - f);
    }

    public static void glColor(Color color, int n) {
        DrawHelper.glColor(color, (float)n / 255.0f);
    }

    public static void endSmooth() {
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2881);
        GL11.glEnable((int)2832);
    }

    public static void drawGradientSideways(double d, double d2, double d3, double d4, int n, int n2) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        float f5 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n2 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d, (double)d4);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glVertex2d((double)d3, (double)d2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawVGradientRect(float f, float f2, float f3, float f4, int n, int n2) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float)(n2 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)f3, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f4, 0.0).func_181666_a(f10, f11, f12, f9).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f4, 0.0).func_181666_a(f10, f11, f12, f9).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int getColor(int n) {
        return DrawHelper.getColor(n, n, n, 255);
    }

    public static Color blend(Color color, Color color2, double d) {
        float f = (float)d;
        float f2 = 1.0f - f;
        float[] fArray = new float[3];
        float[] fArray2 = new float[3];
        color.getColorComponents(fArray);
        color2.getColorComponents(fArray2);
        float f3 = fArray[0] * f + fArray2[0] * f2;
        float f4 = fArray[1] * f + fArray2[1] * f2;
        float f5 = fArray[2] * f + fArray2[2] * f2;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        } else if (f3 > 255.0f) {
            f3 = 255.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        } else if (f4 > 255.0f) {
            f4 = 255.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        } else if (f5 > 255.0f) {
            f5 = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(f3, f4, f5);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            NumberFormat.getNumberInstance();
        }
        return color3;
    }

    public static void drawNewRect(double d, double d2, double d3, double d4, int n) {
        double d5;
        if (d < d3) {
            d5 = d;
            d = d3;
            d3 = d5;
        }
        if (d2 < d4) {
            d5 = d2;
            d2 = d4;
            d4 = d5;
        }
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)f2, (float)f3, (float)f4, (float)f);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(d, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d2, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void glColor(Color color, float f) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)f);
    }

    public static Color fade(Color color, int n, int n2) {
        float[] fArray = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fArray);
        fArray[2] = (0.5f + 0.5f * Math.abs(((float)(System.currentTimeMillis() % (0xB0C3467738D93B60L ^ 0xB0C3467738D93CB0L)) / 1000.0f + (float)n / (float)n2 * 2.0f) % 2.0f - 1.0f)) % 2.0f;
        return new Color(Color.HSBtoRGB(fArray[0], fArray[1], fArray[2]));
    }

    public static int setColor(int n) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        GL11.glColor4f((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)(f == 0.0f ? 1.0f : f));
        return n;
    }

    public static Color getHealthColor(EntityLivingBase entityLivingBase) {
        float f = entityLivingBase.func_110143_aJ();
        float[] fArray = new float[]{0.0f, 0.15f, 0.55f, 0.7f, 0.9f};
        Color[] colorArray = new Color[]{new Color(133, 0, 0), Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        float f2 = f / entityLivingBase.func_110138_aP();
        return f >= 0.0f ? DrawHelper.blendColors(fArray, colorArray, f2).brighter() : colorArray[0];
    }

    public static void drawHead(ResourceLocation resourceLocation, int n, int n2, int n3, int n4) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        mc.func_110434_K().func_110577_a(resourceLocation);
        Gui.func_152125_a((int)n, (int)n2, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)n3, (int)n4, (float)64.0f, (float)64.0f);
    }

    public static void drawFilledCircle(int n, int n2, float f, Color color) {
        int n3 = 50;
        double d = 0.12566370614359174;
        GL11.glPushAttrib((int)8192);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        for (int i = 0; i < 50; i -= 14353) {
            float f2 = (float)((double)f * Math.sin((double)i * 0.12566370614359174));
            float f3 = (float)((double)f * Math.cos((double)i * 0.12566370614359174));
            GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            GL11.glVertex2f((float)((float)n + f2), (float)((float)n2 + f3));
            i += 14354;
        }
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glEnd();
        GL11.glPopAttrib();
    }

    public static void drawGradientRect(double d, double d2, double d3, double d4, int n, int n2) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        float f5 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n2 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(d3, d2, (double)zLevel).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, (double)zLevel).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(d, d4, (double)zLevel).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b(d3, d4, (double)zLevel).func_181666_a(f6, f7, f8, f5).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int astolfoColors4(float f, float f2, float f3) {
        float f4;
        float f5 = 1800.0f;
        for (f4 = (float)(System.currentTimeMillis() % (long)((int)f5)) + (f2 - f) * 12.0f; f4 > f5; f4 -= f5) {
        }
        float f6 = f4 / f5;
        if ((double)f6 > 0.5) {
            f6 = 0.5f - (f6 - 0.5f);
        }
        return Color.HSBtoRGB(f6 + 0.5f, f3, 1.0f);
    }

    public static Color setAlpha(Color color, int n) {
        n = MathHelper.func_76125_a((int)n, (int)0, (int)255);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
    }

    public static void drawPolygonPart(double d, double d2, int n, int n2, int n3, int n4) {
        float f = (float)(n3 >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n3 >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n3 >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n3 & 0xFF) / 255.0f;
        float f5 = (float)(n4 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n4 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n4 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n4 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(6, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181666_a(f2, f3, f4, f).func_181675_d();
        for (int i = n2 * 90; i <= n2 * 90 + 90; i += 17865) {
            double d3 = Math.PI * 2 * (double)i / 360.0 + Math.toRadians(180.0);
            bufferBuilder.func_181662_b(d + Math.sin(d3) * (double)n, d2 + Math.cos(d3) * (double)n, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
            i -= 17864;
        }
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static boolean isInViewFrustrum(Entity entity) {
        return DrawHelper.isInViewFrustrum(entity.func_174813_aQ()) || entity.field_70158_ak;
    }

    public static Color blendColors(float[] fArray, Color[] colorArray, float f) {
        if (fArray == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colorArray == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fArray.length != colorArray.length) {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        int[] nArray = DrawHelper.getFractionIndicies(fArray, f);
        float[] fArray2 = new float[]{fArray[nArray[0]], fArray[nArray[1]]};
        Color[] colorArray2 = new Color[]{colorArray[nArray[0]], colorArray[nArray[1]]};
        return DrawHelper.blend(colorArray2[0], colorArray2[1], 1.0f - (f - fArray2[0]) / (fArray2[1] - fArray2[0]));
    }

    public static int astolfoColors(int n, int n2) {
        float f;
        float f2;
        float f3 = 2900.0f;
        for (f2 = (float)(System.currentTimeMillis() % (long)((int)f3)) + (float)((n2 - n) * 9); f2 > f3; f2 -= f3) {
        }
        float f4 = f2 / f3;
        if ((double)f > 0.5) {
            f4 = 0.5f - (f4 - 0.5f);
        }
        return Color.HSBtoRGB(f4 + 0.5f, 0.5f, 1.0f);
    }

    public static final void drawSmoothRect(float f, float f2, float f3, float f4, int n) {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        DrawHelper.drawRect(f, f2, f3, f4, n);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        DrawHelper.drawRect(f * 2.0f - 1.0f, f2 * 2.0f, f * 2.0f, f4 * 2.0f - 1.0f, n);
        DrawHelper.drawRect(f * 2.0f, f2 * 2.0f - 1.0f, f3 * 2.0f, f2 * 2.0f, n);
        DrawHelper.drawRect(f3 * 2.0f, f2 * 2.0f, f3 * 2.0f + 1.0f, f4 * 2.0f - 1.0f, n);
        DrawHelper.drawRect(f * 2.0f, f4 * 2.0f - 1.0f, f3 * 2.0f, f4 * 2.0f, n);
        GL11.glDisable((int)3042);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
    }

    public static Color astolfoColors45(float f, float f2, float f3, float f4) {
        float f5;
        float f6 = 1800.0f;
        for (f5 = (float)(System.currentTimeMillis() % (long)((int)f6)) + (f2 - f) * f4; f5 > f6; f5 -= f6) {
        }
        float f7 = f5 / f6;
        if ((double)f7 > 0.5) {
            f7 = 0.5f - (f7 - 0.5f);
        }
        return Color.getHSBColor(f7 + 0.5f, f3, 1.0f);
    }

    public static int toRGBA(int n, int n2, int n3, int n4) {
        return (n << 16) + (n2 << 8) + (n3 << 0) + (n4 << 24);
    }

    public static final void color(double d, double d2, double d3, double d4) {
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)d4);
    }

    public static int color(int n, int n2, int n3, int n4) {
        n4 = 255;
        return new Color(n, n2, n3, n4).getRGB();
    }

    public static final void color(Color color) {
        if (color == null) {
            color = Color.white;
        }
        DrawHelper.color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static void drawGlow(double d, double d2, double d3, double d4, int n) {
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        DrawHelper.drawVGradientRect((int)d, (int)d2, (int)d3, (int)(d2 + (d4 - d2) / 2.0), DrawHelper.setAlpha(new Color(n), 0).getRGB(), n);
        DrawHelper.drawVGradientRect((int)d, (int)(d2 + (d4 - d2) / 2.0), (int)d3, (int)d4, n, DrawHelper.setAlpha(new Color(n), 0).getRGB());
        int n2 = (int)((d4 - d2) / 2.0);
        DrawHelper.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 0, n, DrawHelper.setAlpha(new Color(n), 0).getRGB());
        DrawHelper.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 1, n, DrawHelper.setAlpha(new Color(n), 0).getRGB());
        DrawHelper.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 2, n, DrawHelper.setAlpha(new Color(n), 0).getRGB());
        DrawHelper.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 3, n, DrawHelper.setAlpha(new Color(n), 0).getRGB());
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int astolfo(int n, float f) {
        float f2;
        float f3;
        float f4 = 3000.0f;
        for (f3 = Math.abs((float)(System.currentTimeMillis() % (long)n) + -f / 21.0f * 2.0f); f3 > f4; f3 -= f4) {
        }
        float f5 = f3 / f4;
        if ((double)f2 > 0.5) {
            f5 = 0.5f - (f5 - 0.5f);
        }
        return Color.HSBtoRGB(f5 + 0.5f, 0.5f, 1.0f);
    }

    static {
        mc = Minecraft.func_71410_x();
        frustrum = new Frustum();
    }

    public static class Colors {
        public static final /* synthetic */ int RED;
        public static final /* synthetic */ int BLUE;
        public static final /* synthetic */ int BLACK;
        public static final /* synthetic */ int GRAY;
        public static final /* synthetic */ int DARK_RED;
        public static final /* synthetic */ int PURPLE;
        public static final /* synthetic */ int ORANGE;
        public static final /* synthetic */ int WHITE;
        public static final /* synthetic */ int YELLOW;
        public static final /* synthetic */ int GREEN;

        static {
            WHITE = DrawHelper.toRGBA(255, 255, 255, 255);
            BLACK = DrawHelper.toRGBA(0, 0, 0, 255);
            RED = DrawHelper.toRGBA(255, 0, 0, 255);
            GREEN = DrawHelper.toRGBA(0, 255, 0, 255);
            BLUE = DrawHelper.toRGBA(0, 0, 255, 255);
            ORANGE = DrawHelper.toRGBA(255, 128, 0, 255);
            PURPLE = DrawHelper.toRGBA(163, 73, 163, 255);
            GRAY = DrawHelper.toRGBA(127, 127, 127, 255);
            DARK_RED = DrawHelper.toRGBA(64, 0, 0, 255);
            YELLOW = DrawHelper.toRGBA(255, 255, 0, 255);
        }
    }
}
