package com.Blood.Ware.Castom.setting;

import com.Blood.Ware.Castom.setting.DrawHelper;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class RenderHelper {
    public static void customScaledObject2D(float f, float f2, float f3, float f4, float f5, float f6) {
        GL11.glTranslated((double)(f3 / 2.0f), (double)(f4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-f * f5 + f + f3 / 2.0f * -f5), (double)(-f2 * f6 + f2 + f4 / 2.0f * -f6), (double)1.0);
        GL11.glScaled((double)f5, (double)f6, (double)0.0);
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawFullCircle(double d, double d2, double d3, int n) {
        d3 *= 2.0;
        d *= 2.0;
        d2 *= 2.0;
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        RenderHelper.enableGL2D();
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        GL11.glBegin((int)6);
        for (int i = 0; i <= 360; i += 12077) {
            GL11.glVertex2d((double)(d + Math.sin((double)i * Math.PI / 180.0) * d3), (double)(d2 + Math.cos((double)i * Math.PI / 180.0) * d3));
            i -= 12076;
        }
        GL11.glEnd();
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        RenderHelper.disableGL2D();
    }

    public static void customScaledObject2D(float f, float f2, float f3, float f4, float f5) {
        GL11.glTranslated((double)(f3 / 2.0f), (double)(f4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-f * f5 + f + f3 / 2.0f * -f5), (double)(-f2 * f5 + f2 + f4 / 2.0f * -f5), (double)1.0);
        GL11.glScaled((double)f5, (double)f5, (double)0.0);
    }

    public static void drawImage(ResourceLocation resourceLocation, float f, float f2, float f3, float f4, Color color) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        DrawHelper.setColor(color.getRGB());
        Gui.func_146110_a((int)((int)f), (int)((int)f2), (float)0.0f, (float)0.0f, (int)((int)f3), (int)((int)f4), (float)f3, (float)f4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }
}
