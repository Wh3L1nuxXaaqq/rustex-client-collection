package com.Blood.Ware.Castom;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.Castom.comp.CheckBox;
import com.Blood.Ware.Castom.comp.Combo;
import com.Blood.Ware.Castom.comp.Comp;
import com.Blood.Ware.Castom.comp.Slider;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.MathUtils;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Mouse;

public class CastomGui
extends GuiScreen {
    public /* synthetic */ float curAlpha;
    public /* synthetic */ Category selectedCategory;
    public static /* synthetic */ boolean binding;
    public /* synthetic */ double field_146294_l;
    public /* synthetic */ ArrayList comps;
    public static /* synthetic */ RenderItem itemRender;
    public /* synthetic */ float anim;
    public /* synthetic */ int modeIndex;
    public /* synthetic */ float globalAnimation;
    public /* synthetic */ float categoryHoverAnimation;
    public /* synthetic */ float moduleSlideAnimation;
    public /* synthetic */ float panelFadeAnimation;
    public /* synthetic */ HashMap<Category, Float> categoryAnimations;
    public /* synthetic */ HashMap<Module, Float> moduleAnimations;
    public /* synthetic */ float searchBarAnimation;
    public /* synthetic */ float logoRotation;
    public /* synthetic */ double dragX;
    public /* synthetic */ double x;
    public /* synthetic */ double posX;
    public /* synthetic */ double posY;
    public /* synthetic */ double field_146295_m;
    public /* synthetic */ double dragY;
    public /* synthetic */ boolean dragging;
    public /* synthetic */ double y;
    public /* synthetic */ boolean editing;
    public /* synthetic */ Module bindingModule;
    public /* synthetic */ Module selectedModule;
    public /* synthetic */ Module mod;

    public void setBinding(boolean bl) {
        binding = bl;
    }

    public void func_73864_a(int n, int n2, int n3) throws IOException {
        super.func_73864_a(n, n2, n3);
        if (this.isInside(n, n2, this.posX, this.posY - 10.0, this.field_146294_l, this.posY) && n3 == 0) {
            this.dragging = true;
            this.dragX = (double)n - this.posX;
            this.dragY = (double)n2 - this.posY;
        }
        int n4 = 0;
        Category[] categoryArray = Category.values();
        int n5 = categoryArray.length;
        for (int i = 0; i < n5; i -= 23127) {
            Category category = categoryArray[i];
            if (this.isInside(n, n2, this.posX, this.posY + 1.0 + (double)n4, this.posX + 60.0, this.posY + 15.0 + (double)n4) && n3 == 0) {
                this.selectedCategory = category;
            }
            n4 -= 12175;
            n4 += 12190;
            i += 23128;
        }
        int n6 = 0;
        for (Module module : BloodWare.moduleManager.getModules(this.selectedCategory)) {
            if (this.isInside(n, n2, this.posX + 65.0, this.posY + 1.0 + (double)n6, this.posX + 150.0, this.posY + 15.0 + (double)n6)) {
                if (n3 == 2) {
                    this.bindingModule = module;
                    this.setBinding(true);
                }
                n6 += 9186;
                n6 -= 9171;
                if (n3 == 0) {
                    module.toggle();
                }
                if (n3 == 1) {
                    this.selectedModule = module;
                    int n7 = 3;
                    this.comps.clear();
                    if (BloodWare.instance.settingsManager.getSettingsByMod(this.selectedModule) != null) {
                        for (Setting setting : BloodWare.instance.settingsManager.getSettingsByMod(this.selectedModule)) {
                            this.selectedModule = this.selectedModule;
                            this.setBinding(true);
                            if (setting.isCombo()) {
                                this.comps.add(new Combo(275.0, n7, this, this.selectedModule, setting));
                                n7 -= 1308;
                                n7 += 1323;
                            }
                            if (setting.isCheck()) {
                                this.comps.add(new CheckBox(275.0, n7, this, this.selectedModule, setting));
                                n7 -= 12217;
                                n7 += 12230;
                            }
                            if (!setting.isSlider()) continue;
                            this.comps.add(new Slider(275.0, n7, this, this.selectedModule, setting));
                            n7 += 2610;
                            n7 -= 2592;
                        }
                    }
                }
            }
            n6 -= 12419;
            n6 += 12434;
        }
        Iterator<Module> iterator = this.comps.iterator();
        while (iterator.hasNext()) {
            ((Comp)((Object)iterator.next())).mouseClicked(n, n2, n3);
        }
    }

    public boolean isInside(int n, int n2, double d, double d2, double d3, double d4) {
        return (double)n > d && (double)n < d3 && (double)n2 > d2 && (double)n2 < d4;
    }

    public void func_73866_w_() {
        super.func_73866_w_();
        this.anim = 0.0f;
        this.dragging = false;
    }

    public void setEditing(boolean bl) {
        this.editing = bl;
    }

    public void func_73863_a(int n, int n2, float f) {
        Object object;
        super.func_73863_a(n, n2, f);
        if (this.dragging) {
            this.posX = (double)n - this.dragX;
            this.posY = (double)n2 - this.dragY;
        }
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m = this.posY + 380.0;
        float f2 = 255.0f;
        boolean bl = true;
        if (this.curAlpha < 254.0f) {
            this.curAlpha += 1.0f;
        } else if (this.curAlpha > 254.0f && this.curAlpha != 255.0f) {
            this.curAlpha = 255.0f;
        } else if (this.curAlpha != 255.0f) {
            this.curAlpha = 255.0f;
        }
        this.anim = MathUtils.lerp(this.anim, 1.0f, 0.13f);
        RenderUtil.drawRect(this.posX - 1.0, this.posY - 6.0, this.field_146294_l + 1.0, this.field_146295_m + 1.0, ClickGUI.getColor());
        RenderUtil.drawRect(this.posX, this.posY, this.field_146294_l, this.field_146295_m, new Color(45, 45, 45, 249).getRGB());
        int n3 = 0;
        Category[] categoryArray = Category.values();
        int n4 = categoryArray.length;
        for (int i = 0; i < n4; i += 32566) {
            object = categoryArray[i];
            RenderUtil.drawRect(this.posX, this.posY + 1.0 + (double)n3, this.posX + 60.0, this.posY + 15.0 + (double)n3, object.equals((Object)this.selectedCategory) ? new Color(46, 85, 243, 156).getRGB() : new Color(28, 28, 28, 250).getRGB());
            CastomFontUtils.fr3.drawString(object.name(), (int)this.posX + 2, (int)(this.posY + 5.0) + n3, new Color(170, 170, 170).getRGB());
            n3 -= 30081;
            n3 += 30096;
            i -= 32565;
        }
        int n5 = 0;
        for (Module module : BloodWare.moduleManager.getModules(this.selectedCategory)) {
            RenderUtil.drawRect(this.posX + 65.0, this.posY + 1.0 + (double)n5, this.posX + 150.0, this.posY + 15.0 + (double)n5, module.isToggled() ? new Color(46, 85, 234, 155).getRGB() : new Color(28, 28, 28, 249).getRGB());
            object = module.getName();
            if (module == this.bindingModule) {
                object = "Binding...";
            }
            CastomFontUtils.fr3.drawString((String)object, (int)this.posX + 67, (int)(this.posY + 5.0) + n5, new Color(170, 170, 170).getRGB());
            n5 -= 14879;
            n5 += 14894;
        }
        Gui.func_73734_a((int)((int)(this.posX + 455.0)), (int)((int)(this.posY + 360.0)), (int)((int)(this.posX + 323.0)), (int)((int)(this.posY + 320.5)), (int)new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr.drawStringWithShadow("BloodWare", (float)(this.posX + 353.0), (float)(this.posY + 329.0), ClickGUI.getColor());
        Gui.func_73734_a((int)((int)(this.posX + 300.0)), (int)((int)(this.posY + 370.0)), (int)((int)(this.posX + 200.0)), (int)((int)(this.posY + 2.0)), (int)new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr.drawStringWithShadow("Name:" + this.field_146297_k.func_110432_I().func_111285_a(), (float)(this.posX + 353.0), (float)(this.posY + 339.5), Color.white.getRGB());
        try {
            this.field_146297_k.func_110434_K().func_110577_a(Objects.requireNonNull(this.field_146297_k.func_147114_u()).func_175102_a(this.field_146297_k.field_71439_g.func_110124_au()).func_178837_g());
            Gui.func_152125_a((int)((int)(this.posX + 328.0)), (int)((int)(this.posY + 330.0)), (float)8.0f, (float)8.0f, (int)8, (int)8, (int)22, (int)22, (float)64.0f, (float)64.0f);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        Iterator<Module> iterator = this.comps.iterator();
        while (iterator.hasNext()) {
            ((Comp)((Object)iterator.next())).drawScreen(n, n2);
        }
        this.drawinfo(n, n2);
        this.player();
    }

    public ScaledResolution getScaledRes() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    public boolean isEditing() {
        return this.editing;
    }

    public void player() {
        try {
            this.field_146297_k.func_110434_K().func_110577_a(Objects.requireNonNull(this.field_146297_k.func_147114_u()).func_175102_a(this.field_146297_k.field_71439_g.func_110124_au()).func_178837_g());
            RenderUtils.renderEntity((EntityLivingBase)this.field_146297_k.field_71439_g, 70, (int)(this.posX + 375.0), (int)(this.posY + 230.0));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void drawinfo(int n, int n2) {
        int n3 = (int)(this.posX + 511.0);
        int n4 = (int)(this.posY + 18.0);
        int n5 = 5;
        RenderUtil.drawRect(this.posX + 636.0, this.posY - 6.0, this.field_146294_l + 29.0, this.field_146295_m + 1.0, ClickGUI.getColor());
        RenderUtil.drawRect(this.posX + 635.0, this.posY, this.field_146294_l + 30.0, this.field_146295_m, new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr2.drawStringWithShadow("Freands", (float)(this.posX + 540.0), (float)(this.posY + 10.0), Color.white.getRGB());
        for (String string : FriendManager.FRIENDS) {
            int n6 = 0 + n3;
            int n7 = 100 + n3;
            int n8 = n5 + n4;
            int n9 = n5 + this.field_146289_q.field_78288_b + n4;
            if (n > n6 && n < n7 && n2 > n8 && n2 < n9) {
                CastomFontUtils.fr2.drawString(string, n3 + 50 - this.field_146289_q.func_78256_a(string) / 2, n5 + n4, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(string);
                    return;
                }
            } else {
                CastomFontUtils.fr2.drawString(string, n3 + 50 - this.field_146289_q.func_78256_a(string) / 2, n5 + n4, Color.white.getRGB());
            }
            n5 += this.field_146289_q.field_78288_b;
        }
    }

    public void func_146286_b(int n, int n2, int n3) {
        super.func_146286_b(n, n2, n3);
        this.dragging = false;
        Iterator iterator = this.comps.iterator();
        while (iterator.hasNext()) {
            ((Comp)iterator.next()).mouseReleased(n, n2, n3);
        }
    }

    public void func_73869_a(char c, int n) throws IOException {
        if (this.bindingModule != null) {
            if (n != 1) {
                this.bindingModule.setKey(n);
            }
            this.bindingModule = null;
            this.setBinding(false);
        }
        super.func_73869_a(c, n);
    }

    public CastomGui() {
        this.globalAnimation = 0.0f;
        this.categoryHoverAnimation = 0.0f;
        this.moduleSlideAnimation = 0.0f;
        this.panelFadeAnimation = 0.0f;
        this.categoryAnimations = new HashMap();
        this.moduleAnimations = new HashMap();
        this.searchBarAnimation = 0.0f;
        this.logoRotation = 0.0f;
        this.bindingModule = null;
        this.anim = 0.0f;
        this.comps = new ArrayList();
        this.dragging = false;
        this.posX = this.getScaledRes().func_78326_a() / 2 - 150;
        this.posY = this.getScaledRes().func_78328_b() / 2 - 100;
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m += 380.0;
        this.selectedCategory = Category.COMBAT;
        this.x = 100.0;
        this.y = 200.0;
    }

    static {
        itemRender = Minecraft.func_71410_x().func_175599_af();
    }
}
