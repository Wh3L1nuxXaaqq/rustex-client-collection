package com.Blood.Ware.Castom.comp;

import com.Blood.Ware.Castom.CastomGui;
import com.Blood.Ware.Castom.setting.Setting;
import com.Blood.Ware.module.Module;

public class Comp {
    public /* synthetic */ double y;
    public /* synthetic */ CastomGui parent;
    public /* synthetic */ Setting setting;
    public /* synthetic */ String displayString;
    public /* synthetic */ double x;
    public /* synthetic */ double y2;
    public /* synthetic */ double x2;
    public /* synthetic */ Module module;

    public void keyTyped(char c, int n) {
    }

    public void drawScreen(int n, int n2) {
    }

    public boolean isInside(int n, int n2, double d, double d2, double d3, double d4) {
        return (double)n > d && (double)n < d3 && (double)n2 > d2 && (double)n2 < d4;
    }

    public void mouseClicked(int n, int n2, int n3) {
    }

    public void mouseReleased(int n, int n2, int n3) {
    }
}
