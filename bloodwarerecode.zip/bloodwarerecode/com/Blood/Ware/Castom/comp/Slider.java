package com.Blood.Ware.Castom.comp;

import com.Blood.Ware.Castom.CastomGui;
import com.Blood.Ware.Castom.comp.Comp;
import com.Blood.Ware.Castom.setting.Setting;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Slider
extends Comp {
    public /* synthetic */ double renderWidth;
    public /* synthetic */ double renderWidth2;
    public /* synthetic */ boolean dragging;

    public double roundToPlace(double d, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(d).setScale(n, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        super.mouseClicked(n, n2, n3);
        if (this.isInside(n, n2, this.parent.posX + this.x - 70.0, this.parent.posY + this.y + 10.0, this.parent.posX + this.x - 70.0 + this.renderWidth2, this.parent.posY + this.y + 16.0) && n3 == 0) {
            this.dragging = true;
        }
    }

    @Override
    public void drawScreen(int n, int n2) {
        super.drawScreen(n, n2);
        double d = this.setting.getMin();
        double d2 = this.setting.getMax();
        double d3 = 90.0;
        this.renderWidth = 90.0 * (this.setting.getValDouble() - d) / (d2 - d);
        this.renderWidth2 = 90.0 * (this.setting.getMax() - d) / (d2 - d);
        double d4 = Math.min(90.0, Math.max(0.0, (double)n - (this.parent.posX + this.x - 70.0)));
        if (this.dragging) {
            if (d4 == 0.0) {
                this.setting.setValDouble(this.setting.getMin());
            } else {
                this.setting.setValDouble(this.roundToPlace(d4 / 90.0 * (d2 - d) + d, 1));
            }
        }
        RenderUtil.drawRect(this.parent.posX + this.x - 70.0, this.parent.posY + this.y + 10.0, this.parent.posX + this.x - 70.0 + this.renderWidth2, this.parent.posY + this.y + 16.0, new Color(10, 131, 230).darker().getRGB());
        RenderUtil.drawRect(this.parent.posX + this.x - 70.0, this.parent.posY + this.y + 10.0, this.parent.posX + this.x - 70.0 + this.renderWidth, this.parent.posY + this.y + 16.0, new Color(10, 164, 230).getRGB());
        CastomFontUtils.fr2.drawString(String.valueOf(new StringBuilder().append(this.setting.getName()).append(": ").append(this.setting.getValDouble())), (int)(this.parent.posX + this.x - 65.0), (int)(this.parent.posY + this.y + 4.0), -1);
    }

    @Override
    public void mouseReleased(int n, int n2, int n3) {
        super.mouseReleased(n, n2, n3);
        this.dragging = false;
    }

    public Slider(double d, double d2, CastomGui castomGui, Module module, Setting setting) {
        this.dragging = false;
        this.x = d;
        this.y = d2;
        this.parent = castomGui;
        this.module = module;
        this.setting = setting;
    }
}
