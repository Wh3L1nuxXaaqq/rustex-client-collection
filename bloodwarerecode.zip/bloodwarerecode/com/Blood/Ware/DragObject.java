package com.Blood.Ware;

import com.Blood.Ware.module.hud.HudModule;
import org.lwjgl.input.Mouse;

public class DragObject {
    public /* synthetic */ HudModule module;
    public /* synthetic */ boolean draging;
    public /* synthetic */ float dragX;
    public /* synthetic */ float dragY;

    public DragObject(HudModule hudModule) {
        this.draging = false;
        this.module = hudModule;
    }

    public void update(float f, float f2) {
        if (!Mouse.isButtonDown((int)0)) {
            this.draging = false;
        }
        if (this.draging) {
            this.module.setPosX(f - this.dragX);
            this.module.setPosY(f2 - this.dragY);
        }
    }

    public void drag(float f, float f2, int n) {
        this.draging = true;
        this.dragX = f - (float)this.module.getPosX();
        this.dragY = f2 - (float)this.module.getPosY();
    }

    public void start() {
        if (!this.module.isEnabled()) {
            this.module.onEnable();
        }
    }

    public void stop() {
        if (!this.module.isEnabled()) {
            this.module.onDisable();
        }
    }

    public boolean isHover(float f, float f2, float f3, float f4, float f5, float f6) {
        return f5 > f && f5 < f3 && f6 > f2 && f6 < f4;
    }
}
