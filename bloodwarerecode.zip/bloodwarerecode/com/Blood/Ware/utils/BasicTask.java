package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Task;

public abstract class BasicTask
implements Task {
    public /* synthetic */ String name;
    public /* synthetic */ int priority;
    public /* synthetic */ boolean online;

    public BasicTask(String string, int n) {
        this.name = string;
        this.priority = n;
    }

    @Override
    public boolean isOnline() {
        return this.online;
    }

    @Override
    public void setOnline(boolean bl) {
        this.online = bl;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String string) {
        this.name = string;
    }

    public int getPriority() {
        return this.priority;
    }

    public void setPriority(int n) {
        this.priority = n;
    }
}
