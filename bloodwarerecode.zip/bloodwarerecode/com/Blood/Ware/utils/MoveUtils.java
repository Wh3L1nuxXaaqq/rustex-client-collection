package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;

public class MoveUtils {
    public static void setSpeed(double d) {
        double d2 = Minecraft.func_71410_x().field_71439_g.field_71158_b.field_192832_b;
        double d3 = Minecraft.func_71410_x().field_71439_g.field_71158_b.field_78902_a;
        float f = Minecraft.func_71410_x().field_71439_g.field_70177_z;
        if (d2 == 0.0 && d3 == 0.0) {
            Minecraft.func_71410_x().field_71439_g.field_70159_w = 0.0;
            Minecraft.func_71410_x().field_71439_g.field_70179_y = 0.0;
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            Minecraft.func_71410_x().field_71439_g.field_70159_w = d2 * d * Math.cos(Math.toRadians(f + 90.0f)) + d3 * d * Math.sin(Math.toRadians(f + 90.0f));
            Minecraft.func_71410_x().field_71439_g.field_70179_y = d2 * d * Math.sin(Math.toRadians(f + 90.0f)) - d3 * d * Math.cos(Math.toRadians(f + 90.0f));
        }
    }

    public static void unsafeSetSpeed(double d) {
        double d2 = Minecraft.func_71410_x().field_71439_g.field_71158_b.field_78902_a;
        float f = Minecraft.func_71410_x().field_71439_g.field_70177_z;
        if (d2 == 0.0) {
            Minecraft.func_71410_x().field_71439_g.field_70159_w = 0.0;
            Minecraft.func_71410_x().field_71439_g.field_70179_y = 0.0;
        }
        Minecraft.func_71410_x().field_71439_g.field_70159_w = d * Math.cos(Math.toRadians(f + 90.0f)) + d2 * d * Math.sin(Math.toRadians(f + 90.0f));
        Minecraft.func_71410_x().field_71439_g.field_70179_y = d * Math.sin(Math.toRadians(f + 90.0f)) - d2 * d * Math.cos(Math.toRadians(f + 90.0f));
    }
}
