package com.Blood.Ware.utils;

import com.Blood.Ware.utils.DraggableComponent;
import java.awt.Color;
import net.minecraft.client.Minecraft;

public class DraggableModule {
    public /* synthetic */ DraggableComponent drag;
    public /* synthetic */ int x;
    public /* synthetic */ Minecraft mc;
    public /* synthetic */ String name;
    public /* synthetic */ int y;

    public String getName() {
        return this.name;
    }

    public void setX2(int n) {
        this.drag.setXPosition(n);
    }

    public int getX2() {
        return this.x;
    }

    public DraggableModule(String string, int n, int n2) {
        this.mc = Minecraft.func_71410_x();
        this.name = string;
        this.x = n;
        this.y = n2;
        this.drag = new DraggableComponent(this.x, this.y, this.getWidth(), this.getHeight(), new Color(255, 255, 255, 0).getRGB());
    }

    public int getX() {
        return this.drag.getXPosition();
    }

    public void render(int n, int n2) {
        this.drag.draw(n, n2);
    }

    public int getY() {
        return this.drag.getYPosition();
    }

    public void draw() {
    }

    public int getHeight() {
        return 50;
    }

    public void setY(int n) {
        this.y = n;
    }

    public int getY2() {
        return this.y;
    }

    public void setY2(int n) {
        this.drag.setYPosition(n);
    }

    public void setX(int n) {
        this.x = n;
    }

    public void setName(String string) {
        this.name = string;
    }

    public int getWidth() {
        return 50;
    }
}
