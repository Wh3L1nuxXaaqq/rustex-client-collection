package com.Blood.Ware.utils.animation;

import com.Blood.Ware.utils.animation.AnimationUtil;

public final class Translate {
    public /* synthetic */ double x;
    public /* synthetic */ double y;

    public Translate(float f, float f2) {
        this.x = f;
        this.y = f2;
    }

    public final void interpolate(double d, double d2, double d3) {
        this.x = AnimationUtil.animate(d, this.x, d3);
        this.y = AnimationUtil.animate(d2, this.y, d3);
    }

    public void animate(double d, double d2) {
        this.x = AnimationUtil.animate(this.x, d, 1.0);
        this.y = AnimationUtil.animate(this.y, d2, 1.0);
    }

    public double getX() {
        return this.x;
    }

    public void setX(double d) {
        this.x = d;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double d) {
        this.y = d;
    }
}
