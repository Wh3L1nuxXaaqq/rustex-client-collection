package com.Blood.Ware.utils.animation;

import net.minecraft.client.Minecraft;

public class AnimationUtil {
    public static /* synthetic */ float speedTarget;

    public static float animation(float f, float f2, float f3) {
        return AnimationUtil.animation(f, f2, speedTarget, f3);
    }

    public static float animation(float f, float f2, float f3, float f4) {
        float f5 = (f2 - f) / Math.max((float)Minecraft.func_175610_ah(), 5.0f) * 15.0f;
        if (f5 > 0.0f) {
            f5 = Math.max(f4, f5);
            f5 = Math.min(f2 - f, f5);
        } else if (f5 < 0.0f) {
            f5 = Math.min(-f4, f5);
            f5 = Math.max(f2 - f, f5);
        }
        return f + f5;
    }

    public static double animate(double d, double d2, double d3) {
        boolean bl = d > d2;
        boolean bl2 = bl;
        if (d3 < 0.0) {
            d3 = 0.0;
        } else if (d3 > 1.0) {
            d3 = 1.0;
        }
        double d4 = Math.max(d, d2) - Math.min(d, d2);
        double d5 = d4 * d3;
        if (d5 < 0.1) {
            d5 = 0.1;
        }
        d2 = bl ? (d2 = d2 + d5) : (d2 = d2 - d5);
        return d2;
    }

    static {
        speedTarget = 0.125f;
    }
}
