package com.Blood.Ware.utils.animation;

public final class Stopwatch {
    public /* synthetic */ long ms;

    public Stopwatch() {
        this.ms = this.getCurrentMS();
    }

    public long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public final long getElapsedTime() {
        return this.getCurrentMS() - this.ms;
    }

    public final boolean elapsed(long l) {
        return this.getCurrentMS() - this.ms > l;
    }

    public final void reset() {
        this.ms = this.getCurrentMS();
    }
}
