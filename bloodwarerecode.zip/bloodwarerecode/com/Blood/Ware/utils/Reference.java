package com.Blood.Ware.utils;

import das.ist.denger.natve.Native;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

@Native
public class Reference {
    public static final /* synthetic */ String Name = "BloodWare";
    public static final /* synthetic */ String Version = "V0.2";
    public static final /* synthetic */ String Moded = "15";

    public static String visitSiteText(String string) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        StringBuilder stringBuilder = new StringBuilder();
        try {
            Object object;
            URL uRL = new URL(string);
            URLConnection uRLConnection = uRL.openConnection();
            uRLConnection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            uRLConnection.connect();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnection.getInputStream(), "UTF-8"));
            while ((object = bufferedReader.readLine()) != null) {
                arrayList.add(object);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        for (Object e : arrayList) {
            stringBuilder.append(e);
        }
        return stringBuilder.toString();
    }

    public static String getHWID() {
        String string = System.getenv("COMPUTERNAME");
        String string2 = System.getenv("USERNAME");
        String string3 = System.getenv("PROCESSOR_IDENTIFIER");
        String string4 = System.getenv("PROCESSOR_LEVEL");
        String string5 = string + string2 + string3 + string4;
        return Reference.sha256(string5);
    }

    public static String sha256(String string) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] byArray = messageDigest.digest(string.getBytes(StandardCharsets.UTF_8));
            StringBuilder stringBuilder = new StringBuilder();
            byte[] byArray2 = byArray;
            int n = byArray2.length;
            for (int i = 0; i < n; i += 10313) {
                byte by = byArray2[i];
                String string2 = Integer.toHexString(0xFF & by);
                if (string2.length() == 1) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(string2);
                i -= 10312;
            }
            return stringBuilder.toString();
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new RuntimeException(noSuchAlgorithmException);
        }
    }
}
