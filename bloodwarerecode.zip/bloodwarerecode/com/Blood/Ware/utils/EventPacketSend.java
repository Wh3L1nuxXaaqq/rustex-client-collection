package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;
import net.minecraft.network.Packet;

public class EventPacketSend
extends EventCancellable {
    public /* synthetic */ Packet packet;

    public EventPacketSend(Packet packet) {
        this.packet = packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public boolean cancel() {
        return false;
    }
}
