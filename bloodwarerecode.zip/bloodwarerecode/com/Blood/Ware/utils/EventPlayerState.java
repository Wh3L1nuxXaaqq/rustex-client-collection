package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;

public class EventPlayerState
extends EventCancellable {
    public /* synthetic */ float yaw;
    public /* synthetic */ boolean onGround;
    public /* synthetic */ float pitch;
    public /* synthetic */ double x;
    public final /* synthetic */ boolean isPre;
    public /* synthetic */ double y;
    public /* synthetic */ double z;

    public void setOnGround(boolean bl) {
        this.onGround = bl;
    }

    public EventPlayerState(double d, double d2, double d3, float f, float f2, boolean bl) {
        this.y = d2;
        this.x = d;
        this.z = d3;
        this.isPre = true;
        this.yaw = f;
        this.pitch = f2;
        this.onGround = bl;
    }

    public boolean isPre() {
        return this.isPre;
    }

    public double getX() {
        return this.x;
    }

    public EventPlayerState() {
        this.isPre = false;
    }

    public void setZ(double d) {
        this.z = d;
    }

    public double getZ() {
        return this.z;
    }

    public void setYaw(float f) {
        this.yaw = f;
    }

    public double getY() {
        return this.y;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setY(double d) {
        this.y = d;
    }

    public void setPitch(float f) {
        this.pitch = f;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setX(double d) {
        this.x = d;
    }

    public boolean isPost() {
        return !this.isPre;
    }

    public boolean cancel() {
        return false;
    }

    public boolean isOnGround() {
        return this.onGround;
    }
}
