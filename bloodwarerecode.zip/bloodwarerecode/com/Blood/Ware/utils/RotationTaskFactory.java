package com.Blood.Ware.utils;

import com.Blood.Ware.utils.BasicTaskFactory;
import com.Blood.Ware.utils.RotationTask;

public final class RotationTaskFactory
extends BasicTaskFactory<RotationTask> {
}
