package com.Blood.Ware.utils;

import com.Blood.Ware.utils.BasicTask;
import java.util.List;

public interface TaskFactory<T extends BasicTask> {
    public void removeTask(String var1);

    public void removeTask(T var1);

    public List<T> getTasks();
}
