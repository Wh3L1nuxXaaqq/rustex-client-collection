package com.Blood.Ware.utils;

public class Counter {
    public /* synthetic */ long lastMS;

    public long getCurrentMS() {
        return System.nanoTime() / (0xFBD20339AC973B0AL ^ 0xFBD20339AC98794AL);
    }

    public long getLastMS() {
        return this.lastMS;
    }

    public long getValue() {
        return this.getCurrentMS() - this.lastMS;
    }

    public boolean hasReached(double d) {
        return (double)(this.getCurrentMS() - this.lastMS) >= d;
    }

    public boolean hasReached(int n) {
        return this.getCurrentMS() - this.lastMS >= (long)n;
    }

    public boolean hasReached(long l) {
        return this.getCurrentMS() - this.lastMS >= l;
    }

    public boolean hasReached(float f) {
        return (float)(this.getCurrentMS() - this.lastMS) >= f;
    }

    public boolean hasReached(Float f) {
        return (float)(this.getCurrentMS() - this.lastMS) >= f.floatValue();
    }

    public void reset() {
        this.lastMS = this.getCurrentMS();
    }

    public void setLastMS(long l) {
        this.lastMS = l;
    }
}
