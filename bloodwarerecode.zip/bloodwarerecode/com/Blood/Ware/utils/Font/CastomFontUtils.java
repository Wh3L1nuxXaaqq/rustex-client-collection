package com.Blood.Ware.utils.Font;

import com.Blood.Ware.utils.Font.CustomFontRenderer;
import java.awt.Font;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public final class CastomFontUtils {
    public static /* synthetic */ CustomFontRenderer fr;
    public static /* synthetic */ CustomFontRenderer fr2;
    public static /* synthetic */ CustomFontRenderer fr3;
    public static /* synthetic */ CustomFontRenderer fr4;
    public static /* synthetic */ CustomFontRenderer fr5;
    public static /* synthetic */ CustomFontRenderer fr6;

    public static Font getFontFromTTF(ResourceLocation resourceLocation, float f, int n) {
        try {
            Font font = Font.createFont(n, Minecraft.func_71410_x().func_110442_L().func_110536_a(resourceLocation).func_110527_b());
            font = font.deriveFont(f);
            return font;
        }
        catch (Exception exception) {
            return null;
        }
    }

    static {
        fr = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("font.otf"), 20.0f, 0), true, true);
        fr2 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("main.ttf"), 20.0f, 0), true, true);
        fr3 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("rerty.ttf"), 20.0f, 0), true, true);
        fr4 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("latoregular.ttf"), 20.0f, 0), true, true);
        fr5 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("blood.otf"), 20.0f, 0), true, true);
        fr6 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("nigga.otf"), 30.0f, 0), true, true);
    }
}
