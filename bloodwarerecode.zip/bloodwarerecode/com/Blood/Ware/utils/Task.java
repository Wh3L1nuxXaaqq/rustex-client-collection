package com.Blood.Ware.utils;

public interface Task {
    public boolean isOnline();

    public void setOnline(boolean var1);
}
