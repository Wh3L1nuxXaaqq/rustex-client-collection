package com.Blood.Ware.utils;

import com.Blood.Ware.events.event.Event;

public class EventMotionUpdate
extends Event {
    public final /* synthetic */ byte type;
    public /* synthetic */ double x;
    public /* synthetic */ double y;
    public /* synthetic */ double z;
    public /* synthetic */ boolean sprinting;
    public /* synthetic */ float yaw;
    public /* synthetic */ float pitch;
    public /* synthetic */ boolean onGround;
    public /* synthetic */ boolean sneaking;

    public EventMotionUpdate() {
        this.type = (byte)2;
    }

    public EventMotionUpdate(double d, double d2, double d3, float f, float f2, boolean bl, boolean bl2, boolean bl3) {
        this.type = 0;
        this.x = d;
        this.y = d2;
        this.z = d3;
        this.yaw = f;
        this.pitch = f2;
        this.sprinting = bl;
        this.sneaking = bl2;
        this.onGround = bl3;
    }
}
