package com.Blood.Ware.utils;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

public class UIRender {
    public static void drawRect(double d, double d2, double d3, double d4, int n) {
        double d5;
        if (d < d3) {
            d5 = d;
            d = d3;
            d3 = d5;
        }
        if (d2 < d4) {
            d5 = d2;
            d2 = d4;
            d4 = d5;
        }
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)f2, (float)f3, (float)f4, (float)f);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(d, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d2, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void bind(float f, float f2, float f3, float f4, float f5, int n) {
        GL11.glPushMatrix();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)f5);
        GlStateManager.func_179144_i((int)n);
        UIRender.a(f, f2, 0.0f, 0.0f, f3, f4, f3, f4);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GL11.glPopMatrix();
    }

    public static void a(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        float f9 = 1.0f / f7;
        float f10 = 1.0f / f8;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b((double)f, (double)(f2 + f6), 0.0).func_187315_a((double)(f3 * f9), (double)((f4 + f6) * f10)).func_181675_d();
        bufferBuilder.func_181662_b((double)(f + f5), (double)(f2 + f6), 0.0).func_187315_a((double)((f3 + f5) * f9), (double)((f4 + f6) * f10)).func_181675_d();
        bufferBuilder.func_181662_b((double)(f + f5), (double)f2, 0.0).func_187315_a((double)((f3 + f5) * f9), (double)(f4 * f10)).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_187315_a((double)(f3 * f9), (double)(f4 * f10)).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void bindTexture(int n, int n2, int n3, int n4, int n5) {
        GlStateManager.func_179121_F();
        GlStateManager.func_179144_i((int)n5);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GlStateManager.func_179084_k();
        GlStateManager.func_179094_E();
    }

    public static void setColor(int n) {
        GL11.glColor4ub((byte)((byte)(n >> 16 & 0xFF)), (byte)((byte)(n >> 8 & 0xFF)), (byte)((byte)(n & 0xFF)), (byte)((byte)(n >> 24 & 0xFF)));
    }

    public static void prepareScissorBox(int n, float f, float f2, float f3, float f4, float f5) {
        GL11.glScissor((int)((int)(f2 * (float)n)), (int)((int)((f - f5) * (float)n)), (int)((int)((f4 - f2) * (float)n)), (int)((int)((f5 - f3) * (float)n)));
    }

    public static void roundedBorder(float f, float f2, float f3, float f4, float f5, int n) {
        float f6 = f;
        float f7 = f2;
        float f8 = f4;
        float f9 = f3;
        UIRender.enableGL2D();
        UIRender.setColor(n);
        GlStateManager.func_187441_d((float)2.0f);
        GL11.glBegin((int)2);
        GL11.glVertex2d((double)f6, (double)(f7 + f5));
        GL11.glVertex2f((float)(f6 + f5), (float)f7);
        GL11.glVertex2f((float)(f9 - f5), (float)f7);
        GL11.glVertex2f((float)f9, (float)(f7 + f5));
        GL11.glVertex2f((float)f9, (float)(f8 - f5));
        GL11.glVertex2f((float)(f9 - f5), (float)f8);
        GL11.glVertex2f((float)(f6 + f5), (float)f8);
        GL11.glVertex2f((float)f6, (float)(f8 - f5));
        GL11.glEnd();
        UIRender.disableGL2D();
    }

    public static void roundedBorder(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        float f7 = f;
        float f8 = f2;
        float f9 = f4;
        float f10 = f3;
        UIRender.enableGL2D();
        UIRender.setColor(n);
        GlStateManager.func_187441_d((float)f6);
        GL11.glBegin((int)2);
        GL11.glVertex2d((double)f7, (double)(f8 + f5));
        GL11.glVertex2f((float)(f7 + f5), (float)f8);
        GL11.glVertex2f((float)(f10 - f5), (float)f8);
        GL11.glVertex2f((float)f10, (float)(f8 + f5));
        GL11.glVertex2f((float)f10, (float)(f9 - f5));
        GL11.glVertex2f((float)(f10 - f5), (float)f9);
        GL11.glVertex2f((float)(f7 + f5), (float)f9);
        GL11.glVertex2f((float)f7, (float)(f9 - f5));
        GL11.glEnd();
        UIRender.disableGL2D();
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawCircle(float f, float f2, float f3, float f4, float f5, boolean bl, Color color) {
        float f6;
        float f7;
        float f8;
        GlStateManager.func_179131_c((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        if (f3 > f4) {
            float f9 = f4;
            f4 = f3;
            f3 = f9;
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        UIRender.setColor(color.getRGB());
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)2.0f);
        GL11.glBegin((int)3);
        for (f8 = f4; f8 >= f3; f8 -= 4.0f) {
            f7 = (float)(Math.cos((double)f8 * Math.PI / 180.0) * (double)f5 * 1.0);
            f6 = (float)(Math.sin((double)f8 * Math.PI / 180.0) * (double)f5 * 1.0);
            GL11.glVertex2f((float)(f + f7), (float)(f2 + f6));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)(bl ? 6 : 3));
        for (f8 = f4; f8 >= f3; f8 -= 4.0f) {
            f7 = (float)Math.cos((double)f8 * Math.PI / 180.0) * f5;
            f6 = (float)Math.sin((double)f8 * Math.PI / 180.0) * f5;
            GL11.glVertex2f((float)(f + f7), (float)(f2 + f6));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }
}
