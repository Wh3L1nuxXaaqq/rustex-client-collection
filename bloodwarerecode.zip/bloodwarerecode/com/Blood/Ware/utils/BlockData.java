package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class BlockData {
    public final /* synthetic */ BlockPos position;
    public final /* synthetic */ EnumFacing face;

    public BlockData(BlockPos blockPos, EnumFacing enumFacing) {
        this.position = blockPos;
        this.face = enumFacing;
    }

    public static BlockData getBlockData(BlockPos blockPos) {
        if (Minecraft.func_71410_x().field_71441_e.func_180495_p(blockPos.func_177982_a(0, -1, 0)).func_177230_c() != Blocks.field_150350_a) {
            return new BlockData(blockPos.func_177982_a(0, -1, 0), EnumFacing.UP);
        }
        if (Minecraft.func_71410_x().field_71441_e.func_180495_p(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a) {
            return new BlockData(blockPos.func_177982_a(-1, 0, 0), EnumFacing.EAST);
        }
        if (Minecraft.func_71410_x().field_71441_e.func_180495_p(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a) {
            return new BlockData(blockPos.func_177982_a(1, 0, 0), EnumFacing.WEST);
        }
        if (Minecraft.func_71410_x().field_71441_e.func_180495_p(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a) {
            return new BlockData(blockPos.func_177982_a(0, 0, -1), EnumFacing.SOUTH);
        }
        if (Minecraft.func_71410_x().field_71441_e.func_180495_p(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a) {
            return new BlockData(blockPos.func_177982_a(0, 0, 1), EnumFacing.NORTH);
        }
        return null;
    }
}
