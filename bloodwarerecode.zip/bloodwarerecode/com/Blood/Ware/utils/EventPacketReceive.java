package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;
import net.minecraft.network.Packet;

public class EventPacketReceive
extends EventCancellable {
    public /* synthetic */ Packet packet;

    public EventPacketReceive(Packet packet) {
        this.packet = packet;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }

    public boolean cancel() {
        return false;
    }
}
