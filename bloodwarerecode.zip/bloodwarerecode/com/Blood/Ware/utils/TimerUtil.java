package com.Blood.Ware.utils;

public class TimerUtil {
    public static /* synthetic */ long ms;

    public static long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public static boolean hasReached(float f) {
        return (float)(TimerUtil.getCurrentMS() - ms) > f;
    }

    public static void reset() {
        ms = TimerUtil.getCurrentMS();
    }

    public static void strafe() {
    }

    public long getTime() {
        return TimerUtil.getCurrentMS() - ms;
    }

    static {
        ms = TimerUtil.getCurrentMS();
    }
}
