package com.Blood.Ware.utils;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

public class BlockUtil {
    public static boolean isCollidable(Block block) {
        return block != Blocks.field_150350_a && block != Blocks.field_185773_cZ && block != Blocks.field_150459_bM && block != Blocks.field_150330_I && block != Blocks.field_150398_cm && block != Blocks.field_150356_k && block != Blocks.field_150358_i && block != Blocks.field_150353_l && block != Blocks.field_150394_bc && block != Blocks.field_150388_bm && block != Blocks.field_150469_bN && block != Blocks.field_150393_bb && block != Blocks.field_150328_O && block != Blocks.field_150337_Q && block != Blocks.field_150429_aA && block != Blocks.field_150329_H && block != Blocks.field_150478_aa && block != Blocks.field_150437_az && block != Blocks.field_150327_N && block != Blocks.field_150395_bd && block != Blocks.field_150355_j && block != Blocks.field_150321_G && block != Blocks.field_150464_aj;
    }
}
