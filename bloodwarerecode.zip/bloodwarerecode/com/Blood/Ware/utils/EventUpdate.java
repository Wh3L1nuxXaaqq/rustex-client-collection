package com.Blood.Ware.utils;

import com.Blood.Ware.events.event.Event;

public class EventUpdate
extends Event {
    public /* synthetic */ double posZ;
    public static /* synthetic */ float pitch;
    public /* synthetic */ double posX;
    public /* synthetic */ float rotationYaw;
    public static /* synthetic */ float yaw;
    public /* synthetic */ double posY;
    public /* synthetic */ float rotationPitch;
    public /* synthetic */ boolean onGround;

    public EventUpdate(double d, double d2, double d3, float f, float f2, boolean bl, float f3, float f4) {
        this.posX = d;
        this.posY = d2;
        this.posZ = d3;
        this.rotationYaw = f;
        this.rotationPitch = f2;
        this.onGround = bl;
        yaw = f3;
        pitch = f4;
    }

    public float getRotationPitch() {
        return this.rotationPitch;
    }

    public static void setYaw(float f) {
        yaw = f;
    }

    public double getPosX() {
        return this.posX;
    }

    public double getPosY() {
        return this.posY;
    }

    public boolean isOnGround() {
        return this.onGround;
    }

    public float getRotationYaw() {
        return this.rotationYaw;
    }

    public void setPosX(double d) {
        this.posX = d;
    }

    public static void setPitch(float f) {
        pitch = f;
    }

    public void setPosY(double d) {
        this.posY = d;
    }

    public static void setOnGround(boolean bl) {
    }

    public static void setRotationYaw(float f) {
    }

    public void setPosZ(double d) {
        this.posZ = d;
    }

    public double getPosZ() {
        return this.posZ;
    }

    public static void setRotationPitch(float f) {
    }
}
