package com.Blood.Ware.utils;

import com.Blood.Ware.utils.DraggableModule;

public class IndicatorsComponent
extends DraggableModule {
    public /* synthetic */ float cooldownAnim;
    public /* synthetic */ float hurtAnim;

    public IndicatorsComponent() {
        super("IndicatorsComponent", 40, 220);
    }
}
