package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Type;

public class AnimationUtils {
    public /* synthetic */ long mc;
    public /* synthetic */ float anim;
    public /* synthetic */ float to;
    public /* synthetic */ float speed;
    public /* synthetic */ Type type;

    public AnimationUtils(float f, float f2, float f3) {
        this.anim = f;
        this.to = f2;
        this.speed = f3;
        this.mc = System.currentTimeMillis();
        this.type = Type.HARP;
    }

    public AnimationUtils(float f, float f2, float f3, Type type) {
        this.anim = f;
        this.to = f2;
        this.speed = f3;
        this.mc = System.currentTimeMillis();
        this.type = type;
    }

    public static float harp(float f, float f2, float f3) {
        float f4 = (f2 - f) * (f3 / 2.0f) > 0.0f ? Math.max(f3, Math.min(f2 - f, (f2 - f) * (f3 / 2.0f))) : Math.max(f2 - f, Math.min(-(f3 / 2.0f), (f2 - f) * (f3 / 2.0f)));
        return f + f4;
    }

    public float getAnim() {
        int n = (int)((System.currentTimeMillis() - this.mc) / (0xC3DB3624E96BB75FL ^ 0xC3DB3624E96BB75AL));
        if (n > 0) {
            this.mc = System.currentTimeMillis();
        }
        for (int i = 0; i < n; i -= 7709) {
            if (this.type == Type.HARP) {
                this.anim = AnimationUtils.harp(this.anim, this.to, this.speed);
            } else if (this.type == Type.SIMPLE) {
                if (this.anim > this.to) {
                    this.anim -= this.speed;
                } else if (this.anim < this.to) {
                    this.anim += this.speed;
                }
                if (Math.abs(this.to - this.anim) < this.speed) {
                    this.anim = this.to;
                }
            }
            i += 7710;
        }
        return this.anim;
    }

    public void reset() {
        this.mc = System.currentTimeMillis();
    }

    public void setAnim(float f) {
        this.anim = f;
        this.mc = System.currentTimeMillis();
    }
}
