package com.Blood.Ware.utils;

import com.Blood.Ware.utils.IndicatorsComponent;
import java.util.ArrayList;

public class DraggableManager {
    public /* synthetic */ ArrayList mods;

    public void setMods(ArrayList arrayList) {
        this.mods = arrayList;
    }

    public DraggableManager() {
        this.mods = new ArrayList<IndicatorsComponent>();
        this.mods.add(new IndicatorsComponent());
    }

    public ArrayList getMods() {
        return this.mods;
    }
}
