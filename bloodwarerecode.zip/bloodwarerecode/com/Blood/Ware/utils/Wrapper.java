package com.Blood.Ware.utils;

import com.Blood.Ware.BloodWare;
import net.minecraft.client.Minecraft;

public interface Wrapper {
    public static final /* synthetic */ Minecraft mc;

    default public boolean nullCheck() {
        return Wrapper.mc.field_71439_g != null || Wrapper.mc.field_71441_e != null;
    }

    default public BloodWare getCosmos() {
        return BloodWare.instance;
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
