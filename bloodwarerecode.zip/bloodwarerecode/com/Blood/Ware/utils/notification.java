package com.Blood.Ware.utils;

import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;

public class notification {
    public static void main(String string) throws Exception {
        if (SystemTray.isSupported()) {
            SystemTray systemTray = SystemTray.getSystemTray();
            Image image = Toolkit.getDefaultToolkit().getImage("images/bor.png");
            TrayIcon trayIcon = new TrayIcon(image);
            systemTray.add(trayIcon);
            trayIcon.displayMessage("BloodWare", string, TrayIcon.MessageType.INFO);
        }
    }
}
