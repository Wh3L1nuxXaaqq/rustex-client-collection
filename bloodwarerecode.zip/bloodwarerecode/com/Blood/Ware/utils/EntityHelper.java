package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class EntityHelper {
    public static /* synthetic */ Minecraft mc;

    public static int getPing(EntityPlayer entityPlayer) {
        return EntityHelper.mc.field_71439_g.field_71174_a.func_175102_a(entityPlayer.func_110124_au()).func_178853_c();
    }

    public static boolean checkArmor(Entity entity) {
        return ((EntityLivingBase)entity).func_70658_aO() < 6;
    }

    public static boolean isTeamWithYou(EntityLivingBase entityLivingBase) {
        return EntityHelper.mc.field_71439_g != null && entityLivingBase != null && EntityHelper.mc.field_71439_g.func_145748_c_() != null && entityLivingBase.func_145748_c_() != null && (EntityHelper.mc.field_71439_g.func_96124_cp() != null && entityLivingBase.func_96124_cp() != null && EntityHelper.mc.field_71439_g.func_96124_cp().func_142054_a(entityLivingBase.func_96124_cp()) || entityLivingBase.func_145748_c_().func_150254_d().replace("\u0412\u00a7r", "").startsWith(String.valueOf(new StringBuilder().append("\u0412\u00a7").append(EntityHelper.mc.field_71439_g.func_145748_c_().func_150254_d().replace("\u0412\u00a7r", "").charAt(1)))));
    }

    public static double getDistance(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d - d4;
        double d8 = d2 - d5;
        double d9 = d3 - d6;
        return Math.sqrt(d7 * d7 + d8 * d8 + d9 * d9);
    }

    public static double getDistanceOfEntityToBlock(Entity entity, BlockPos blockPos) {
        return EntityHelper.getDistance(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p());
    }

    public static double getDistance(double d, double d2, double d3, double d4) {
        return Math.hypot(d - d3, d2 - d4);
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
