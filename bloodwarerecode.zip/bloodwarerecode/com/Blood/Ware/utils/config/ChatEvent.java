package com.Blood.Ware.utils.config;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.utils.ChatUtils;
import das.ist.denger.natve.Native;
import java.util.HashSet;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Native
public class ChatEvent {
    public static /* synthetic */ HashSet Player;
    public static /* synthetic */ Minecraft mc;

    @SubscribeEvent
    public void ChatEvent(ClientChatEvent clientChatEvent) {
        clientChatEvent.getMessage();
        String string = clientChatEvent.getMessage().toLowerCase();
        if (string.startsWith("/aim")) {
            try {
                BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("AimBot"), "Predict").setValDouble(Float.parseFloat(string.split(" ")[1]));
            }
            catch (Throwable throwable) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        }
        if (string.startsWith("/smooth")) {
            try {
                BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("AimBot"), "Smooth").setValDouble(Float.parseFloat(string.split(" ")[1]));
            }
            catch (Throwable throwable) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        } else if (string.startsWith("/vaim")) {
            try {
                BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("AimBot"), "VPredict").setValDouble(Float.parseFloat(string.split(" ")[1]));
            }
            catch (Throwable throwable) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        } else if (string.startsWith("/range")) {
            try {
                BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("AimBot"), "Range").setValDouble(Float.parseFloat(string.split(" ")[1]));
            }
            catch (Throwable throwable) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        }
    }

    static {
        Player = new HashSet();
        mc = Minecraft.func_71410_x();
    }
}
