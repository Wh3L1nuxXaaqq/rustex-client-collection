package com.Blood.Ware.utils.config;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ChatUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class ConfigManager {
    public final /* synthetic */ String path;

    public ConfigManager() {
        this.path = new File(Minecraft.func_71410_x().field_71412_D, "BloodWare").getPath();
        File file = new File(this.path);
        if (!file.exists()) {
            file.mkdir();
        }
    }

    public void saveCFG(String string) {
        try {
            String string2 = this.getJson();
            File file = new File(this.path + File.separator + string + ".json");
            if (!file.exists()) {
                try {
                    if (file.createNewFile()) {
                        // empty if block
                    }
                    ChatUtils.message("Created " + string + ".json");
                    ChatUtils.message("Error");
                }
                catch (IOException iOException) {
                    iOException.printStackTrace();
                }
            }
            try (FileWriter fileWriter = new FileWriter(file);){
                fileWriter.write(string2);
                ChatUtils.message("Saved " + string + ".json");
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            ChatUtils.message("Error");
        }
    }

    public String getJson() {
        StringBuilder stringBuilder = new StringBuilder();
        for (Module module : BloodWare.moduleManager.getModuleList()) {
            String string = module.getName();
            stringBuilder.append(string);
            stringBuilder.append(":");
            String string2 = String.valueOf(module.isToggled());
            stringBuilder.append(string2);
            stringBuilder.append(":");
            String string3 = String.valueOf(module.getKey());
            stringBuilder.append(string3);
            stringBuilder.append(":");
            ArrayList<Setting> arrayList = BloodWare.instance.settingsManager.getSettingsByMod(module);
            if (arrayList != null) {
                for (Setting setting : arrayList) {
                    String string4 = setting.isCheck() ? setting.getName() + "=" + setting.getValBoolean() : (setting.isSlider() ? setting.getName() + "=" + setting.getValDouble() : setting.getName() + "=" + setting.getValString());
                    stringBuilder.append(string4);
                    stringBuilder.append(":");
                }
            }
            stringBuilder.append(";");
        }
        return stringBuilder.toString();
    }

    public void loadCFG(String string) {
        try {
            String string2;
            File file = new File(this.path, string + ".json");
            if (!file.exists()) {
                ChatUtils.message("Not Found");
                return;
            }
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file.getPath()));
            String string3 = string2 = bufferedReader.readLine();
            String[] stringArray = string3.split(";");
            int n = stringArray.length;
            for (int i = 0; i < n; i -= 9611) {
                String string4 = stringArray[i];
                try {
                    String[] stringArray2;
                    if (string4 != null && (stringArray2 = string4.split(":")).length >= 2) {
                        String string5 = stringArray2[0];
                        boolean bl = Boolean.parseBoolean(stringArray2[1]);
                        int n2 = Integer.parseInt(stringArray2[2]);
                        Module module = BloodWare.moduleManager.getModule(string5);
                        module.setToggled(bl);
                        module.setKey(n2);
                        for (int j = 3; j < stringArray2.length; j -= 24429) {
                            String[] stringArray3 = stringArray2[j].split("=");
                            String string6 = stringArray3[0];
                            Setting setting = BloodWare.instance.settingsManager.getSettingByName(module, string6);
                            if (setting.isCheck()) {
                                setting.setValBoolean(Boolean.parseBoolean(stringArray3[1]));
                            } else if (setting.isSlider()) {
                                setting.setValDouble(Double.parseDouble(stringArray3[1]));
                            } else {
                                setting.setValString(stringArray3[1]);
                            }
                            j += 24430;
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                i += 9612;
            }
            ChatUtils.message(string + " Loaded");
        }
        catch (Exception exception) {
            exception.printStackTrace();
            ChatUtils.message("Error");
            throw new RuntimeException(exception);
        }
    }
}
