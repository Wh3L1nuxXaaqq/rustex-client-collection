package com.Blood.Ware.utils.config;

import com.Blood.Ware.BloodWare;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;

public class CommandCfg
extends CommandBase {
    public String func_71517_b() {
        return "cfg";
    }

    public List<String> func_71514_a() {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("config");
        return arrayList;
    }

    public int func_82362_a() {
        return 0;
    }

    public String func_71518_a(ICommandSender iCommandSender) {
        return "/cfg <save/load> <name>";
    }

    public void func_184881_a(MinecraftServer minecraftServer, ICommandSender iCommandSender, String[] stringArray) throws CommandException {
        if (stringArray.length < 2) {
            throw new WrongUsageException(this.func_71518_a(iCommandSender), new Object[0]);
        }
        switch (stringArray[0]) {
            case "save": {
                BloodWare.instance.configManager.saveCFG(stringArray[1]);
                break;
            }
            case "load": {
                BloodWare.instance.configManager.loadCFG(stringArray[1]);
                break;
            }
            default: {
                throw new WrongUsageException(this.func_71518_a(iCommandSender), new Object[0]);
            }
        }
    }

    public List<String> func_184883_a(MinecraftServer minecraftServer, ICommandSender iCommandSender, String[] stringArray, @Nullable BlockPos blockPos) {
        if (stringArray.length == 1) {
            ArrayList<String> arrayList = new ArrayList<String>();
            arrayList.add("save");
            arrayList.add("load");
            return arrayList;
        }
        return Collections.emptyList();
    }
}
