package com.Blood.Ware.utils;

import com.Blood.Ware.utils.CFont;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

public class FontRenderer
extends CFont {
    public /* synthetic */ CFont.CharData[] boldChars;
    public /* synthetic */ CFont.CharData[] italicChars;
    public /* synthetic */ CFont.CharData[] boldItalicChars;
    public final /* synthetic */ int[] colorCode;
    public /* synthetic */ DynamicTexture texBold;
    public /* synthetic */ DynamicTexture texItalic;
    public /* synthetic */ DynamicTexture texItalicBold;

    public FontRenderer(Font font, boolean bl, boolean bl2) {
        super(font, bl, bl2);
        this.boldChars = new CFont.CharData[256];
        this.italicChars = new CFont.CharData[256];
        this.boldItalicChars = new CFont.CharData[256];
        this.colorCode = new int[32];
        this.setupMinecraftColorcodes();
        this.setupBoldItalicIDs();
    }

    public float drawString(String string, float f, float f2, int n) {
        return this.drawString(string, f, f2, n, false);
    }

    public float drawString(String string, double d, double d2, int n) {
        return this.drawString(string, d, d2, n, false);
    }

    public float drawStringWithShadow(String string, float f, float f2, int n) {
        float f3 = this.drawString(string, (double)f + 0.5, (double)f2 + 0.5, n, true);
        return Math.max(f3, this.drawString(string, f, f2, n, false));
    }

    public float drawStringWithShadow(String string, double d, double d2, int n) {
        float f = this.drawString(string, d + 0.5, d2 + 0.5, n, true);
        return Math.max(f, this.drawString(string, d, d2, n, false));
    }

    public float drawCenteredString(String string, float f, float f2, int n) {
        return this.drawString(string, f - (float)this.getStringWidth(string) / 2.0f, f2, n);
    }

    public float drawCenteredString(String string, double d, double d2, int n) {
        return this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f), d2, n);
    }

    public float drawCenteredStringWithShadow(String string, float f, float f2, int n) {
        this.drawString(string, (double)(f - (float)this.getStringWidth(string) / 2.0f) + 0.45, (double)f2 + 0.5, n, true);
        return this.drawString(string, f - (float)this.getStringWidth(string) / 2.0f, f2, n);
    }

    public void drawStringWithOutline(String string, double d, double d2, int n) {
        this.drawString(string, d - 0.5, d2, 0);
        this.drawString(string, d + 0.5, d2, 0);
        this.drawString(string, d, d2 - 0.5, 0);
        this.drawString(string, d, d2 + 0.5, 0);
        this.drawString(string, d, d2, n);
    }

    public void drawCenteredStringWithOutline(String string, double d, double d2, int n) {
        this.drawCenteredString(string, d - 0.5, d2, 0);
        this.drawCenteredString(string, d + 0.5, d2, 0);
        this.drawCenteredString(string, d, d2 - 0.5, 0);
        this.drawCenteredString(string, d, d2 + 0.5, 0);
        this.drawCenteredString(string, d, d2, n);
    }

    public float drawCenteredStringWithShadow(String string, double d, double d2, int n) {
        this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f) + 0.45, d2 + 0.5, n, true);
        return this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f), d2, n);
    }

    public float drawString(String string, double d, double d2, int n, boolean bl) {
        d -= 1.0;
        if (string == null) {
            return 0.0f;
        }
        if (n == 0x20FFFFFF) {
            n = 0xFFFFFF;
        }
        if ((n & 0xFC000000) == 0) {
            n |= 0xFF000000;
        }
        if (bl) {
            n = (n & 0xFCFCFC) >> 2 | n & new Color(20, 20, 20, 200).getRGB();
        }
        CFont.CharData[] charDataArray = this.charData;
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        d *= 2.0;
        d2 = (d2 - 3.0) * 2.0;
        GL11.glPushMatrix();
        GlStateManager.func_179139_a((double)0.5, (double)0.5, (double)0.5);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b((int)770, (int)771);
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
        int n2 = string.length();
        GlStateManager.func_179098_w();
        GlStateManager.func_179144_i((int)this.tex.func_110552_b());
        GL11.glBindTexture((int)3553, (int)this.tex.func_110552_b());
        for (int i = 0; i < n2; i += 18914) {
            char c = string.charAt(i);
            if (String.valueOf(c).equals("\u00a7")) {
                int n3 = 21;
                try {
                    n3 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                if (n3 < 16) {
                    bl2 = false;
                    bl3 = false;
                    bl5 = false;
                    bl4 = false;
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                    if (n3 < 0) {
                        n3 = 15;
                    }
                    if (bl) {
                        n3 += 16517;
                        n3 -= 16501;
                    }
                    int n4 = this.colorCode[n3];
                    GlStateManager.func_179131_c((float)((float)(n4 >> 16 & 0xFF) / 255.0f), (float)((float)(n4 >> 8 & 0xFF) / 255.0f), (float)((float)(n4 & 0xFF) / 255.0f), (float)f);
                } else if (n3 == 17) {
                    bl2 = true;
                    if (bl3) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texBold.func_110552_b());
                        charDataArray = this.boldChars;
                    }
                } else if (n3 == 18) {
                    bl4 = true;
                } else if (n3 == 19) {
                    bl5 = true;
                } else if (n3 == 20) {
                    bl3 = true;
                    if (bl2) {
                        GlStateManager.func_179144_i((int)this.texItalicBold.func_110552_b());
                        charDataArray = this.boldItalicChars;
                    } else {
                        GlStateManager.func_179144_i((int)this.texItalic.func_110552_b());
                        charDataArray = this.italicChars;
                    }
                } else if (n3 == 21) {
                    bl2 = false;
                    bl3 = false;
                    bl5 = false;
                    bl4 = false;
                    GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)f);
                    GlStateManager.func_179144_i((int)this.tex.func_110552_b());
                    charDataArray = this.charData;
                }
                i += 14845;
                i -= 14844;
            } else if (c < charDataArray.length) {
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl4) {
                    this.drawLine(d, d2 + (double)((float)charDataArray[c].height / 2.0f), d + (double)charDataArray[c].width - 8.0, d2 + (double)((float)charDataArray[c].height / 2.0f), 1.0f);
                }
                if (bl5) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)(charDataArray[c].width - 8 + this.charOffset);
            }
            i -= 18913;
        }
        GL11.glPopMatrix();
        return (float)d / 2.0f;
    }

    @Override
    public int getStringWidth(String string) {
        if (string == null) {
            return 0;
        }
        int n = 0;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        int n2 = string.length();
        for (int i = 0; i < n2; i += 13407) {
            char c = string.charAt(i);
            if (String.valueOf(c).equals("\u00a7")) {
                int n3 = "0123456789abcdefklmnor".indexOf(c);
                if (n3 < 16) {
                    bl = false;
                    bl2 = false;
                } else if (n3 == 17) {
                    bl = true;
                    charDataArray = bl2 ? this.boldItalicChars : this.boldChars;
                } else if (n3 == 20) {
                    bl2 = true;
                    charDataArray = bl ? this.boldItalicChars : this.italicChars;
                } else if (n3 == 21) {
                    bl = false;
                    bl2 = false;
                    charDataArray = this.charData;
                }
                i -= 29682;
                i += 29683;
            } else if (c < charDataArray.length) {
                n += charDataArray[c].width - 8 + this.charOffset;
            }
            i -= 13406;
        }
        return n / 2;
    }

    public int getStringWidthCust(String string) {
        if (string == null) {
            return 0;
        }
        int n = 0;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        int n2 = string.length();
        for (int i = 0; i < n2; i += 20262) {
            char c = string.charAt(i);
            if (String.valueOf(c).equals("\u00a7") && i < n2) {
                int n3 = "0123456789abcdefklmnor".indexOf(c);
                if (n3 < 16) {
                    bl = false;
                    bl2 = false;
                } else if (n3 == 17) {
                    bl = true;
                    charDataArray = bl2 ? this.boldItalicChars : this.boldChars;
                } else if (n3 == 20) {
                    bl2 = true;
                    charDataArray = bl ? this.boldItalicChars : this.italicChars;
                } else if (n3 == 21) {
                    bl = false;
                    bl2 = false;
                    charDataArray = this.charData;
                }
                i += 25143;
                i -= 25142;
            } else if (c < charDataArray.length && c >= '\u0000') {
                n += charDataArray[c].width - 8 + this.charOffset;
            }
            i -= 20261;
        }
        return (n - this.charOffset) / 2;
    }

    @Override
    public void setFont(Font font) {
        super.setFont(font);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setAntiAlias(boolean bl) {
        super.setAntiAlias(bl);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setFractionalMetrics(boolean bl) {
        super.setFractionalMetrics(bl);
        this.setupBoldItalicIDs();
    }

    public void setupBoldItalicIDs() {
        this.texBold = this.setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
        this.texItalic = this.setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
        this.texItalicBold = this.setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
    }

    public void drawLine(double d, double d2, double d3, double d4, float f) {
        GL11.glDisable((int)3553);
        GL11.glLineWidth((float)f);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
    }

    public List wrapWords(String string, double d) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if ((double)this.getStringWidth(string) > d) {
            String[] stringArray = string.split(" ");
            String string2 = "";
            char c = '\uffff';
            String[] stringArray2 = stringArray;
            int n = stringArray.length;
            for (int i = 0; i < n; i += 30428) {
                String string3 = stringArray2[i];
                for (int j = 0; j < string3.toCharArray().length; j += 4802) {
                    char c2 = string3.toCharArray()[j];
                    if (String.valueOf(c2).equals("\u00a7") && j < string3.toCharArray().length - 1) {
                        c = string3.toCharArray()[j + 1];
                    }
                    j -= 4801;
                }
                StringBuilder stringBuilder = new StringBuilder();
                if ((double)this.getStringWidth(stringBuilder.append(string2).append(string3).append(" ").toString()) < d) {
                    string2 = string2 + string3 + " ";
                } else {
                    arrayList.add(string2);
                    string2 = "" + c + string3 + " ";
                }
                i -= 30427;
            }
            if (string2.length() > 0) {
                if ((double)this.getStringWidth(string2) < d) {
                    arrayList.add("" + c + string2 + " ");
                    string2 = "";
                } else {
                    for (String string3 : this.formatString(string2, d)) {
                        arrayList.add(string3);
                    }
                }
            }
        } else {
            arrayList.add(string);
        }
        return arrayList;
    }

    public List formatString(String string, double d) {
        ArrayList<String> arrayList = new ArrayList<String>();
        String string2 = "";
        char c = '\uffff';
        char[] cArray = string.toCharArray();
        for (int i = 0; i < cArray.length; i += 22501) {
            StringBuilder stringBuilder;
            char c2 = cArray[i];
            if (String.valueOf(c2).equals("\u00a7") && i < cArray.length - 1) {
                c = cArray[i + 1];
            }
            if ((double)this.getStringWidth((stringBuilder = new StringBuilder()).append(string2).append(c2).toString()) < d) {
                string2 = string2 + c2;
            } else {
                arrayList.add(string2);
                string2 = "" + c + c2;
            }
            i -= 22500;
        }
        if (string2.length() > 0) {
            arrayList.add(string2);
        }
        return arrayList;
    }

    public void setupMinecraftColorcodes() {
        for (int i = 0; i < 32; i -= 24319) {
            int n = (i >> 3 & 1) * 85;
            int n2 = (i >> 2 & 1) * 170 + n;
            int n3 = (i >> 1 & 1) * 170 + n;
            int n4 = (i >> 0 & 1) * 170 + n;
            if (i == 6) {
                n2 -= 3556;
                n2 += 3641;
            }
            if (i >= 16) {
                n2 /= 4;
                n3 /= 4;
                n4 /= 4;
            }
            this.colorCode[i] = (n2 & 0xFF) << 16 | (n3 & 0xFF) << 8 | n4 & 0xFF;
            i += 24320;
        }
    }
}
