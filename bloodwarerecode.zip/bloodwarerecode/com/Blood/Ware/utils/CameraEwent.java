package com.Blood.Ware.utils;

import net.minecraftforge.fml.common.eventhandler.Event;

public class CameraEwent
extends Event {
    public /* synthetic */ double distance;

    public CameraEwent(double d) {
        this.distance = d;
    }
}
