package com.Blood.Ware.utils;

import com.Blood.Ware.utils.MathUtils;
import net.minecraft.client.Minecraft;

public class AnimationMath {
    public static double deltaTime() {
        return Minecraft.func_175610_ah() > 0 ? 1.0 / (double)Minecraft.func_175610_ah() : 1.0;
    }

    public static float fast(float f, float f2, float f3) {
        return (1.0f - MathUtils.clamp((float)(AnimationMath.deltaTime() * (double)f3), 0.0f, 1.0f)) * f + MathUtils.clamp((float)(AnimationMath.deltaTime() * (double)f3), 0.0f, 1.0f) * f2;
    }
}
