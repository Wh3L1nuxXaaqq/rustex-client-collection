package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;

public class EventStrafe
extends EventCancellable {
    public /* synthetic */ float yaw;
    public /* synthetic */ float forward;
    public /* synthetic */ float strafe;
    public /* synthetic */ float friction;

    public float getForward() {
        return this.forward;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setStrafe(float f) {
        this.strafe = f;
    }

    public void setYaw(float f) {
        this.yaw = f;
    }

    public void setFriction(float f) {
        this.friction = f;
    }

    public float getFriction() {
        return this.friction;
    }

    public void setForward(float f) {
        this.forward = f;
    }

    public boolean cancel() {
        return false;
    }

    public EventStrafe(float f, float f2, float f3, float f4) {
        this.yaw = f;
        this.strafe = f2;
        this.forward = f3;
        this.friction = f4;
    }

    public float getStrafe() {
        return this.strafe;
    }
}
