package com.Blood.Ware.utils;

import com.Blood.Ware.events.GetAmbientOcclusionLightValueEvent;
import com.Blood.Ware.events.GetLiquidCollisionBoundingBoxEvent;
import com.Blood.Ware.events.PlayerIsUserEvent;
import com.Blood.Ware.events.ReceivePacketEvent;
import com.Blood.Ware.events.RenderModelEvent;
import com.Blood.Ware.events.SendPacketEvent;
import com.Blood.Ware.events.SetOpaqueCubeEvent;
import com.Blood.Ware.events.ShouldSideBeRenderedEvent;
import com.Blood.Ware.events.UpdateWalkingPlayerEvent;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;

public class EventFactory {
    public static boolean setOpaqueCube() {
        SetOpaqueCubeEvent setOpaqueCubeEvent = new SetOpaqueCubeEvent();
        return MinecraftForge.EVENT_BUS.post((Event)setOpaqueCubeEvent);
    }

    public static Packet<?> onSendPacket(Packet<?> packet) {
        SendPacketEvent sendPacketEvent = new SendPacketEvent(packet);
        return MinecraftForge.EVENT_BUS.post((Event)sendPacketEvent) ? null : sendPacketEvent.getPacket();
    }

    public static Packet<?> onReceivePacket(Packet<?> packet) {
        ReceivePacketEvent receivePacketEvent = new ReceivePacketEvent(packet);
        return MinecraftForge.EVENT_BUS.post((Event)receivePacketEvent) ? null : receivePacketEvent.getPacket();
    }

    public static boolean renderBlock(IBlockState iBlockState) {
        return MinecraftForge.EVENT_BUS.post((Event)new RenderModelEvent(iBlockState));
    }

    public static boolean shouldSideBeRendered(IBlockState iBlockState, IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
        ShouldSideBeRenderedEvent shouldSideBeRenderedEvent = new ShouldSideBeRenderedEvent(iBlockState, iBlockState.func_177230_c().func_176225_a(iBlockState, iBlockAccess, blockPos, enumFacing));
        MinecraftForge.EVENT_BUS.post((Event)shouldSideBeRenderedEvent);
        return shouldSideBeRenderedEvent.getShouldBeRendered();
    }

    public static float getAmbientOcclusionLightValue(IBlockState iBlockState) {
        GetAmbientOcclusionLightValueEvent getAmbientOcclusionLightValueEvent = new GetAmbientOcclusionLightValueEvent(iBlockState);
        MinecraftForge.EVENT_BUS.post((Event)getAmbientOcclusionLightValueEvent);
        return getAmbientOcclusionLightValueEvent.getLightValue();
    }

    public static AxisAlignedBB getCollisionBoundingBox() {
        GetLiquidCollisionBoundingBoxEvent getLiquidCollisionBoundingBoxEvent = new GetLiquidCollisionBoundingBoxEvent();
        MinecraftForge.EVENT_BUS.post((Event)getLiquidCollisionBoundingBoxEvent);
        return getLiquidCollisionBoundingBoxEvent.getCollisionBoundingBox();
    }

    public static boolean isUser() {
        return !MinecraftForge.EVENT_BUS.post((Event)new PlayerIsUserEvent());
    }

    public static boolean onUpdateWalkingPlayer() {
        return MinecraftForge.EVENT_BUS.post((Event)new UpdateWalkingPlayerEvent());
    }
}
