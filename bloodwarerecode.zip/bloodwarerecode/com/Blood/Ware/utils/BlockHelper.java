package com.Blood.Ware.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStainedHardenedClay;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class BlockHelper {
    public static /* synthetic */ Minecraft mc;

    public static boolean IsValidBlockPoss(BlockPos blockPos) {
        return BlockHelper.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() instanceof BlockStainedHardenedClay && BlockHelper.mc.field_71441_e.func_180495_p(blockPos.func_177984_a()).func_177230_c() == Blocks.field_150350_a;
    }

    public static ArrayList getBlocks(int n, int n2, int n3) {
        return BlockHelper.getAllInBox(new BlockPos(BlockHelper.mc.field_71439_g.field_70165_t - (double)n, BlockHelper.mc.field_71439_g.field_70163_u - (double)n2, BlockHelper.mc.field_71439_g.field_70161_v - (double)n3), new BlockPos(BlockHelper.mc.field_71439_g.field_70165_t + (double)n, BlockHelper.mc.field_71439_g.field_70163_u + (double)n2, BlockHelper.mc.field_71439_g.field_70161_v + (double)n3));
    }

    public static List getSphere(BlockPos blockPos, float f, int n, boolean bl, boolean bl2) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        int n2 = blockPos.func_177958_n();
        int n3 = blockPos.func_177956_o();
        int n4 = blockPos.func_177952_p();
        for (float f2 = (float)n2 - f; f2 <= (float)n2 + f; f2 += 1.0f) {
            for (float f3 = (float)n4 - f; f3 <= (float)n4 + f; f3 += 1.0f) {
                float f4;
                float f5 = bl2 ? (float)n3 - f : (float)n3;
                float f6 = bl2 ? (float)n3 + f : (float)(n3 + n);
                if (!(f5 < f6) || !((f4 = ((float)n2 - f2) * ((float)n2 - f2) + ((float)n4 - f3) * ((float)n4 - f3) + (bl2 ? ((float)n3 - f5) * ((float)n3 - f5) : 0.0f)) < f * f) || bl && !(f4 >= f - 2.0f * (f - 2.0f))) continue;
                arrayList.add(new BlockPos((double)f2, (double)f5, (double)f3));
            }
        }
        return arrayList;
    }

    public static Block getBlock(BlockPos blockPos) {
        return BlockHelper.mc.field_71441_e.func_180495_p(blockPos).func_177230_c();
    }

    public static boolean IsValidBlockPos(Object object) {
        return BlockHelper.IsValidBlockPoss((BlockPos)object);
    }

    public static ArrayList getAllInBox(BlockPos blockPos, BlockPos blockPos2) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        BlockPos blockPos3 = new BlockPos(Math.min(blockPos.func_177958_n(), blockPos2.func_177958_n()), Math.min(blockPos.func_177956_o(), blockPos2.func_177956_o()), Math.min(blockPos.func_177952_p(), blockPos2.func_177952_p()));
        BlockPos blockPos4 = new BlockPos(Math.max(blockPos.func_177958_n(), blockPos2.func_177958_n()), Math.max(blockPos.func_177956_o(), blockPos2.func_177956_o()), Math.max(blockPos.func_177952_p(), blockPos2.func_177952_p()));
        for (int i = blockPos3.func_177958_n(); i <= blockPos4.func_177958_n(); i -= 4939) {
            for (int j = blockPos3.func_177956_o(); j <= blockPos4.func_177956_o(); j += 21660) {
                for (int k = blockPos3.func_177952_p(); k <= blockPos4.func_177952_p(); k += 19255) {
                    arrayList.add(new BlockPos(i, j, k));
                    k -= 19254;
                }
                j -= 21659;
            }
            i += 4940;
        }
        return arrayList;
    }

    public static BlockPos getPlayerPos() {
        return new BlockPos(BlockHelper.mc.field_71439_g.field_70165_t, BlockHelper.mc.field_71439_g.field_70163_u, BlockHelper.mc.field_71439_g.field_70161_v);
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
