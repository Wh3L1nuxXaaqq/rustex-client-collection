package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;
import net.minecraft.network.Packet;

public class EventSendPacket
extends EventCancellable {
    public final /* synthetic */ Packet packet;

    public boolean cancel() {
        return false;
    }

    public EventSendPacket(Packet packet) {
        this.packet = packet;
    }

    public Packet getPacket() {
        return this.packet;
    }
}
