package com.Blood.Ware.utils.search;

import das.ist.denger.natve.Native;

@Native
public class Blockinfo {
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int z;
    public /* synthetic */ float r;
    public /* synthetic */ float g;
    public /* synthetic */ float b;

    public Blockinfo(int n, int n2, int n3, float f, float f2, float f3) {
        this.x = n;
        this.y = n2;
        this.z = n3;
        this.r = f;
        this.g = f2;
        this.b = f3;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public float getR() {
        return this.r;
    }

    public float getG() {
        return this.g;
    }

    public float getB() {
        return this.b;
    }
}
