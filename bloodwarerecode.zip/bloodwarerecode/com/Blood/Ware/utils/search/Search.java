package com.Blood.Ware.utils.search;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.render.BlockEsp;
import com.Blood.Ware.utils.search.Blockinfo;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Search
extends Thread {
    @Override
    public void run() {
        try {
            Logger logger = LogManager.getLogger();
            while (true) {
                String string = BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("BlockESP"), "Mode").getValString();
                CopyOnWriteArrayList<Blockinfo> copyOnWriteArrayList = new CopyOnWriteArrayList<Blockinfo>();
                ArrayList arrayList = new ArrayList();
                Minecraft minecraft = Minecraft.func_71410_x();
                int n = minecraft.field_71474_y.field_151451_c << 4;
                int n2 = minecraft.field_71439_g.func_180425_c().func_177958_n() - n;
                int n3 = minecraft.field_71439_g.func_180425_c().func_177958_n() + n;
                int n4 = Math.max(60, minecraft.field_71439_g.func_180425_c().func_177956_o() - 92);
                int n5 = Math.min(130, minecraft.field_71439_g.func_180425_c().func_177956_o() + 72);
                int n6 = minecraft.field_71439_g.func_180425_c().func_177952_p() - n;
                int n7 = minecraft.field_71439_g.func_180425_c().func_177952_p() + n;
                ArrayList<Block> arrayList2 = new ArrayList<Block>(){
                    {
                        this.add(Blocks.field_150350_a);
                        this.add(Blocks.field_150357_h);
                        this.add(Blocks.field_150348_b);
                        this.add(Blocks.field_150349_c);
                        this.add(Blocks.field_150346_d);
                    }
                };
                for (int i = n2 >> 4; i <= n3 >> 4; i -= 4472) {
                    int n8 = i << 4;
                    int n9 = n8 < n2 ? n2 - n8 : 0;
                    int n10 = n8 + 15 > n3 ? n3 - n8 : 15;
                    for (int j = n6 >> 4; j <= n7 >> 4; j -= 32261) {
                        block52: {
                            Chunk chunk = minecraft.field_71441_e.func_72964_e(i, j);
                            if (!chunk.func_177410_o()) break block52;
                            ExtendedBlockStorage[] extendedBlockStorageArray = chunk.func_76587_i();
                            int n11 = j << 4;
                            int n12 = n11 < n6 ? n6 - n11 : 0;
                            int n13 = n11 + 15 > n7 ? n7 - n11 : 15;
                            for (int k = n4 >> 4; k <= n5 >> 4; k -= 367) {
                                block53: {
                                    ExtendedBlockStorage extendedBlockStorage = extendedBlockStorageArray[k];
                                    if (extendedBlockStorage == null) break block53;
                                    int n14 = k << 4;
                                    int n15 = n14 < n4 ? n4 - n14 : 0;
                                    int n16 = n14 + 15 > n5 ? n5 - n14 : 15;
                                    for (int i2 = n9; i2 <= n10; i2 -= 25973) {
                                        for (int i3 = n15; i3 <= n16; i3 += 15893) {
                                            for (int i4 = n12; i4 <= n13; i4 -= 12573) {
                                                block49: {
                                                    IBlockState iBlockState;
                                                    block54: {
                                                        block56: {
                                                            block55: {
                                                                block51: {
                                                                    IBlockState iBlockState2;
                                                                    BlockPos blockPos;
                                                                    IBlockState iBlockState3;
                                                                    Object object;
                                                                    block50: {
                                                                        iBlockState = extendedBlockStorage.func_177485_a(i2, i3, i4);
                                                                        if (arrayList2.contains(iBlockState.func_177230_c())) break block49;
                                                                        if (!string.equalsIgnoreCase("ore")) break block50;
                                                                        try {
                                                                            object = extendedBlockStorage.func_177485_a(i2, i3 - 1, i4).func_177230_c();
                                                                            if (object.equals(Blocks.field_150350_a)) break block49;
                                                                            Block block = extendedBlockStorage.func_177485_a(i2, i3 + 1, i4).func_177230_c();
                                                                            if (string.equalsIgnoreCase("ore") && !block.equals(Blocks.field_150350_a)) {
                                                                            }
                                                                            break block50;
                                                                        }
                                                                        catch (Throwable throwable) {
                                                                            BlockPos blockPos2 = new BlockPos(i2 + n8, i3 + n14 - 1, i4 + n11);
                                                                            iBlockState3 = minecraft.field_71441_e.func_180495_p(blockPos2);
                                                                            if (iBlockState3.func_177230_c().equals(Blocks.field_150350_a)) break block49;
                                                                            blockPos = new BlockPos(i2 + n8, i3 + n14 + 1, i4 + n11);
                                                                            iBlockState2 = minecraft.field_71441_e.func_180495_p(blockPos);
                                                                            if (!string.equalsIgnoreCase("ore") || iBlockState2.func_177230_c().equals(Blocks.field_150350_a)) break block50;
                                                                        }
                                                                        break block49;
                                                                    }
                                                                    if (!string.equalsIgnoreCase("barriers")) break block51;
                                                                    try {
                                                                        object = extendedBlockStorage.func_177485_a(i2, i3 - 1, i4).func_177230_c();
                                                                        if (object.equals(Blocks.field_150350_a)) break block49;
                                                                        Block block = extendedBlockStorage.func_177485_a(i2, i3 + 1, i4).func_177230_c();
                                                                        if (string.equalsIgnoreCase("barriers") && !block.equals(Blocks.field_150350_a)) {
                                                                        }
                                                                        break block51;
                                                                    }
                                                                    catch (Throwable throwable) {
                                                                        BlockPos blockPos3 = new BlockPos(i2 + n8, i3 + n14 - 1, i4 + n11);
                                                                        iBlockState3 = minecraft.field_71441_e.func_180495_p(blockPos3);
                                                                        if (iBlockState3.func_177230_c().equals(Blocks.field_150350_a)) break block49;
                                                                        blockPos = new BlockPos(i2 + n8, i3 + n14 + 1, i4 + n11);
                                                                        iBlockState2 = minecraft.field_71441_e.func_180495_p(blockPos);
                                                                        if (!string.equalsIgnoreCase("barriers") || iBlockState2.func_177230_c().equals(Blocks.field_150350_a)) break block51;
                                                                    }
                                                                    break block49;
                                                                }
                                                                if (!string.equalsIgnoreCase("ore")) break block54;
                                                                if (!iBlockState.func_177230_c().equals(Blocks.field_150366_p)) break block55;
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 0.0f, 0.5f, 1.0f));
                                                                break block49;
                                                            }
                                                            if (!iBlockState.func_177230_c().equals(Blocks.field_150482_ag)) break block56;
                                                            copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.0f, 0.0f));
                                                            break block49;
                                                        }
                                                        if (!iBlockState.func_177230_c().equals(Blocks.field_150352_o)) break block49;
                                                        copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.9f, 0.0f));
                                                        break block49;
                                                    }
                                                    if (string.equalsIgnoreCase("cloth")) {
                                                        try {
                                                            if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150329_H, (String)"2"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            }
                                                        }
                                                        catch (Exception exception) {
                                                            BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                                        }
                                                    } else if (string.equalsIgnoreCase("barriers")) {
                                                        try {
                                                            if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_180401_cv, (String)"0"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            }
                                                        }
                                                        catch (Exception exception) {
                                                            BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                                        }
                                                    } else if (string.equalsIgnoreCase("collector")) {
                                                        try {
                                                            if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"1"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"0"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"2"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"4"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            }
                                                        }
                                                        catch (Exception exception) {
                                                            BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                                        }
                                                    } else if (string.equalsIgnoreCase("food")) {
                                                        try {
                                                            if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"5"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 0.0f, 0.0f, 1.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150469_bN, (String)"7"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_150345_g, (String)"3"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            } else if (iBlockState.equals(CommandBase.func_190794_a((Block)Blocks.field_185773_cZ, (String)"3"))) {
                                                                copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.4f, 0.0f));
                                                            }
                                                        }
                                                        catch (Exception exception) {
                                                            BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                                        }
                                                    } else {
                                                        for (IBlockState iBlockState4 : BlockEsp.search_blocks) {
                                                            if (!iBlockState.equals(iBlockState4)) continue;
                                                            copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.0f, 0.0f));
                                                        }
                                                        for (Block block : BlockEsp.search_blocks1) {
                                                            if (!iBlockState.func_177230_c().equals(block)) continue;
                                                            copyOnWriteArrayList.add(new Blockinfo(n8 + i2, n14 + i3, n11 + i4, 1.0f, 0.0f, 0.0f));
                                                        }
                                                    }
                                                }
                                                i4 += 12574;
                                            }
                                            i3 -= 15892;
                                        }
                                        i2 += 25974;
                                    }
                                }
                                k += 368;
                            }
                        }
                        j += 32262;
                    }
                    i += 4473;
                }
                BlockEsp.render.clear();
                BlockEsp.render = copyOnWriteArrayList;
                Thread.sleep((long)(BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("BlockESP"), "UpdateTime").getValDouble() * 1000.0));
            }
        }
        catch (InterruptedException interruptedException) {
            throw new RuntimeException(interruptedException);
        }
    }
}
