package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class ChatUtils {
    public static final /* synthetic */ String prefix;

    public static void message(String string) {
        Minecraft.func_71410_x().field_71439_g.func_145747_a((ITextComponent)new TextComponentString(prefix + string));
    }

    public static void sendMessage(String string) {
        Minecraft.func_71410_x().field_71439_g.func_145747_a((ITextComponent)new TextComponentString(prefix + string));
    }

    public static void say(String string) {
        Minecraft.func_71410_x().field_71439_g.func_71165_d(string);
    }

    static {
        prefix = TextFormatting.GRAY + "[" + TextFormatting.BLUE + "BloodWare" + TextFormatting.GRAY + "]: " + TextFormatting.WHITE;
    }
}
