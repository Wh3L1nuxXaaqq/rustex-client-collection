package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Rotation;
import com.Blood.Ware.utils.Wrapper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AngleUtil
implements Wrapper {
    public static Rotation calculateAngles(Vec3d vec3d) {
        float f = (float)(Math.toDegrees(Math.atan2(vec3d.func_178788_d((Vec3d)AngleUtil.mc.field_71439_g.func_174824_e((float)1.0f)).field_72449_c, vec3d.func_178788_d((Vec3d)AngleUtil.mc.field_71439_g.func_174824_e((float)1.0f)).field_72450_a)) - 90.0);
        float f2 = (float)Math.toDegrees(-Math.atan2(vec3d.func_178788_d((Vec3d)AngleUtil.mc.field_71439_g.func_174824_e((float)1.0f)).field_72448_b, Math.hypot(vec3d.func_178788_d((Vec3d)AngleUtil.mc.field_71439_g.func_174824_e((float)1.0f)).field_72450_a, vec3d.func_178788_d((Vec3d)AngleUtil.mc.field_71439_g.func_174824_e((float)1.0f)).field_72449_c)));
        return new Rotation(MathHelper.func_76142_g((float)f), MathHelper.func_76142_g((float)f2));
    }

    public static Vec3d getVectorForRotation(Rotation rotation) {
        float f = MathHelper.func_76134_b((float)(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI));
        float f2 = MathHelper.func_76126_a((float)(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI));
        float f3 = -MathHelper.func_76134_b((float)(-rotation.getPitch() * ((float)Math.PI / 180)));
        float f4 = MathHelper.func_76126_a((float)(-rotation.getPitch() * ((float)Math.PI / 180)));
        return new Vec3d((double)(f2 * f3), (double)f4, (double)(f * f3));
    }
}
