package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Wrapper;
import net.minecraft.util.math.MathHelper;

public class Rotation
implements Wrapper {
    public /* synthetic */ float yaw;
    public /* synthetic */ float pitch;
    public final /* synthetic */ Rotate rotate;

    public Rotation(float f, float f2, Rotate rotate) {
        this.yaw = f;
        this.pitch = f2;
        this.rotate = rotate;
    }

    public Rotation(float f, float f2) {
        this(f, f2, Rotate.NONE);
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float f) {
        this.yaw = f;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float f) {
        this.pitch = f;
    }

    public Rotate getRotation() {
        return this.rotate;
    }

    public static float[] getNeededRotations(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d - d4;
        double d8 = d3 - d6;
        double d9 = d2 - d5;
        double d10 = MathHelper.func_76133_a((double)(d7 * d7 + d8 * d8));
        float f = (float)(Math.atan2(d8, d7) * 180.0 / Math.PI - 90.0);
        float f2 = (float)(-(Math.atan2(d9, d10) * 180.0 / Math.PI));
        f2 = MathHelper.func_76131_a((float)f2, (float)-90.0f, (float)90.0f);
        return new float[]{f, f2};
    }

    public boolean isValid() {
        return !Float.isNaN(this.getYaw()) && !Float.isNaN(this.getPitch());
    }

    public static enum Rotate {
        PACKET,
        CLIENT,
        NONE;

    }
}
