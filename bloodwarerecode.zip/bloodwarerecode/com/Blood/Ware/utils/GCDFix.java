package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;

public class GCDFix {
    public /* synthetic */ float yaw;
    public /* synthetic */ float pitch;
    public static /* synthetic */ Minecraft mc;

    public GCDFix(float f, float f2) {
        this.yaw = f;
        this.pitch = f2;
    }

    public static float getFixedRotation(float f) {
        return GCDFix.getDeltaMouse(f) * GCDFix.getGCDValue();
    }

    public static float getGCDValue() {
        return (float)((double)GCDFix.getGCD() * 0.15);
    }

    public static float getGCD() {
        float f = (float)((double)GCDFix.mc.field_71474_y.field_74341_c * 0.6 + 0.2);
        return f * f * f * 8.0f;
    }

    public static float getDeltaMouse(float f) {
        return Math.round(f / GCDFix.getGCDValue());
    }

    public final float getYaw() {
        return this.yaw;
    }

    public final void setYaw(float f) {
        this.yaw = f;
    }

    public final float getPitch() {
        return this.pitch;
    }

    public final void setPitch(float f) {
        this.pitch = f;
    }

    public String toString() {
        return "Rotation(yaw=" + this.yaw + ", pitch=" + this.pitch + ")";
    }

    public int hashCode() {
        return Float.hashCode(this.yaw) * 31 + Float.hashCode(this.pitch);
    }

    public boolean equals(Object object) {
        if (this != object) {
            if (object instanceof GCDFix) {
                GCDFix gCDFix = (GCDFix)object;
                return Float.compare(this.yaw, gCDFix.yaw) == 0 && Float.compare(this.pitch, gCDFix.pitch) == 0;
            }
            return false;
        }
        return true;
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
