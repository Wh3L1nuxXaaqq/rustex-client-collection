package com.Blood.Ware.utils;

public class TimerUtils {
    public /* synthetic */ long lastMS;
    public /* synthetic */ long prevMS;

    public TimerUtils() {
        this.lastMS = 0x1EF241893904F30FL ^ 0x1EF241893904F30EL;
        this.prevMS = 0x3EE57BBC90C2999FL ^ 0x3EE57BBC90C2999FL;
    }

    public boolean isDelay(long l) {
        return System.currentTimeMillis() - this.lastMS >= l;
    }

    public long getCurrentMS() {
        return System.nanoTime() / (0xECBD1CA54E65F28L ^ 0xECBD1CA54E91D68L);
    }

    public void setLastMS(long l) {
        this.lastMS = l;
    }

    public void setLastMS() {
        this.lastMS = System.currentTimeMillis();
    }

    public int convertToMS(int n) {
        return 1000 / n;
    }

    public boolean hasReached(float f) {
        return (float)(this.getCurrentMS() - this.lastMS) >= f;
    }

    public void reset() {
        this.lastMS = this.getCurrentMS();
    }

    public boolean delay(float f) {
        return (float)(this.getTime() - this.prevMS) >= f;
    }

    public long getTime() {
        return System.nanoTime() / (0x6A7E4E1B691F54D8L ^ 0x6A7E4E1B69101698L);
    }
}
