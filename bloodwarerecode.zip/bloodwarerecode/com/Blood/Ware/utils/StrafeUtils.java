package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Mc;
import net.minecraft.client.Minecraft;

public class StrafeUtils
implements Mc {
    public static float getPlayerDirection() {
        Minecraft minecraft = Minecraft.func_71410_x();
        float f = minecraft.field_71439_g.field_70177_z;
        float f2 = 45.0f;
        if (minecraft.field_71439_g.field_191988_bg < 0.0f) {
            f2 = -45.0f;
            f += 180.0f;
        }
        if (minecraft.field_71439_g.field_70702_br > 0.0f) {
            f -= f2;
            if (minecraft.field_71439_g.field_191988_bg == 0.0f) {
                f -= 45.0f;
            }
        } else if (minecraft.field_71439_g.field_70702_br < 0.0f) {
            f += f2;
            if (minecraft.field_71439_g.field_191988_bg == 0.0f) {
                f += 45.0f;
            }
        }
        return f;
    }
}
