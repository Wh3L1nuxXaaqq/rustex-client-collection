package com.Blood.Ware.utils;

public class EventType {
    public static final /* synthetic */ byte PRE = 0;
    public static final /* synthetic */ byte ON = 1;
    public static final /* synthetic */ byte POST = 2;
    public static final /* synthetic */ byte SEND = 3;
    public static final /* synthetic */ byte RECIEVE = 4;
}
