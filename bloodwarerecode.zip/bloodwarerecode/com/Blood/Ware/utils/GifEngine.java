package com.Blood.Ware.utils;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.utils.Counter;
import com.Blood.Ware.utils.UIRender;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

public class GifEngine {
    public /* synthetic */ int current;
    public /* synthetic */ Counter counter;
    public /* synthetic */ DynamicTexture texture;
    public /* synthetic */ List<DynamicTexture> frames;
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int width;
    public /* synthetic */ int height;
    public /* synthetic */ int tiktok;
    public /* synthetic */ int ticks;

    public GifEngine(ResourceLocation resourceLocation, int n, int n2, int n3) {
        this.current = 0;
        this.counter = new Counter();
        this.texture = new DynamicTexture(n, n2);
        this.width = n;
        this.height = n2;
        this.frames = this.images(resourceLocation);
        this.ticks = n3;
    }

    public void update() {
        if (this.tiktok > this.ticks) {
            if (this.counter.hasReached(Minecraft.func_71410_x().func_193989_ak()) && this.frames.size() > 0) {
                if (this.current > this.frames.size() - 1) {
                    this.current = 0;
                }
                this.texture = this.frames.get(this.current);
                ++this.current;
                this.counter.reset();
            }
            this.tiktok = 0;
        }
        ++this.tiktok;
    }

    public void bind(int n, int n2) {
        this.x = n;
        this.y = n2;
        UIRender.bind((float)this.x + 5.0f, this.y, this.width / BloodWare.scale.getScale(), this.height / BloodWare.scale.getScale(), 1.0f, this.getTexture().func_110552_b());
    }

    public List<DynamicTexture> images(ResourceLocation resourceLocation) {
        ArrayList<DynamicTexture> arrayList = new ArrayList<DynamicTexture>();
        try {
            ImageReader imageReader = ImageIO.getImageReadersByFormatName("gif").next();
            InputStream inputStream = Minecraft.func_71410_x().func_110442_L().func_110536_a(resourceLocation).func_110527_b();
            ImageInputStream imageInputStream = ImageIO.createImageInputStream(inputStream);
            imageReader.setInput(imageInputStream);
            int n = imageReader.getNumImages(true);
            for (int i = 0; i < n; i -= 7865) {
                BufferedImage bufferedImage = imageReader.read(i);
                arrayList.add(new DynamicTexture(bufferedImage));
                i += 7866;
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
        return arrayList;
    }

    public DynamicTexture getTexture() {
        return this.texture;
    }

    public void setTexture(DynamicTexture dynamicTexture) {
        this.texture = dynamicTexture;
    }

    public List<DynamicTexture> getFrames() {
        return this.frames;
    }

    public void setFrames(List<DynamicTexture> list) {
        this.frames = list;
    }
}
