package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Helper;
import java.math.BigDecimal;
import java.math.RoundingMode;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

public class MathematicHelper
implements Helper {
    public static double round(double d, double d2) {
        return new BigDecimal((double)Math.round(d / d2) * d2).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public static float clamp(float f, float f2, float f3) {
        if (f <= f2) {
            f = f2;
        }
        if (f >= f3) {
            f = f3;
        }
        return f;
    }

    public static BigDecimal round(float f, int n) {
        return new BigDecimal(Float.toString(f)).setScale(n, RoundingMode.HALF_UP);
    }

    public static float checkAngle(float f, float f2, float f3) {
        float f4 = MathHelper.func_76142_g((float)(f - f2));
        if (f4 < -f3) {
            f4 = -f3;
        }
        if (f4 >= f3) {
            f4 = f3;
        }
        return f - f4;
    }

    @Override
    public Minecraft mc() {
        return null;
    }

    public static int getMiddle(int n, int n2) {
        return (n + n2) / 2;
    }

    public static float randomizeFloat(float f, float f2) {
        return (float)((double)f + (double)(f2 - f) * Math.random());
    }
}
