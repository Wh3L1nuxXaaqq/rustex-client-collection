package com.Blood.Ware.utils;

import net.minecraft.util.math.BlockPos;

public class Location {
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int z;
    public /* synthetic */ int id;
    public /* synthetic */ BlockPos pos;

    public Location(int n, int n2, int n3, int n4) {
        this.pos = new BlockPos(n, n2, n3);
        this.id = n4;
    }

    public Location(BlockPos blockPos) {
        this(blockPos, -1);
    }

    public Location(BlockPos blockPos, int n) {
        this(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), n);
        this.pos = blockPos;
        this.id = n;
    }

    public int hashCode() {
        return (this.pos.func_177956_o() + this.pos.func_177952_p() * 859433) * 859433 + this.pos.func_177958_n();
    }

    public BlockPos getPos() {
        return this.pos;
    }

    public int getX() {
        return this.pos.func_177958_n();
    }

    public int getY() {
        return this.pos.func_177956_o();
    }

    public int getZ() {
        return this.pos.func_177952_p();
    }

    public int getId() {
        return this.id;
    }

    public static Location readBytes(byte[] byArray) {
        byte by = byArray[0];
        int n = byArray[1] & 0xFF | byArray[2] << 8 & Short.MAX_VALUE;
        if ((byArray[2] & 0x80) == 128) {
            n = -n;
        }
        int n2 = byArray[3] & 0xFF | byArray[4] << 8 & Short.MAX_VALUE;
        if ((byArray[4] & 0x80) == 128) {
            n2 = -n2;
        }
        int n3 = byArray[5] & 0xFF | byArray[6] << 8 & Short.MAX_VALUE;
        if ((byArray[6] & 0x80) == 128) {
            n3 = -n3;
        }
        return new Location(n, n2, n3, by);
    }

    public Location add(int n, int n2, int n3) {
        return new Location(new BlockPos(this.pos.func_177958_n() + n, this.pos.func_177956_o() + n2, this.pos.func_177952_p() + n3), this.id);
    }

    public void setPos(BlockPos blockPos) {
        this.pos = blockPos;
    }

    public byte[] toBytes() {
        byte[] byArray = new byte[7];
        int n = this.getX();
        int n2 = this.getY();
        int n3 = this.getZ();
        byArray[0] = (byte)(this.id & 0xFF);
        byArray[1] = (byte)(Math.abs(n) & 0xFF);
        byArray[2] = (byte)(Math.abs(n) >> 8 & 0xFF | (n < 0 ? 128 : 0));
        byArray[3] = (byte)(Math.abs(n2) & 0xFF);
        byArray[4] = (byte)(Math.abs(n2) >> 8 & 0x7F | (n2 < 0 ? 128 : 0));
        byArray[5] = (byte)(Math.abs(n3) & 0xFF);
        byArray[6] = (byte)(Math.abs(n3) >> 8 & 0x7F | (n3 < 0 ? 128 : 0));
        return byArray;
    }
}
