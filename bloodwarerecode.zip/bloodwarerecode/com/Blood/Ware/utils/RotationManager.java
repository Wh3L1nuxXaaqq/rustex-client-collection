package com.Blood.Ware.utils;

import com.Blood.Ware.utils.RotationTask;
import com.Blood.Ware.utils.RotationTaskFactory;
import net.minecraft.client.Minecraft;

public final class RotationManager {
    public final /* synthetic */ RotationTaskFactory factory;
    public /* synthetic */ float yaw;
    public /* synthetic */ float pitch;

    public RotationManager() {
        this.factory = new RotationTaskFactory();
    }

    public void addTask(RotationTask rotationTask) {
        this.factory.addTask(rotationTask);
    }

    public void removeTask(RotationTask rotationTask) {
        this.factory.removeTask(rotationTask);
    }

    public void removeTask(String string) {
        this.factory.removeTask(string);
    }

    public void startTask(RotationTask rotationTask) {
        this.factory.startTask(rotationTask);
    }

    public void finishTask(RotationTask rotationTask) {
        this.factory.finishTask(rotationTask);
    }

    public void updateRotations() {
        this.yaw = Minecraft.func_71410_x().field_71439_g.field_70177_z;
        this.pitch = Minecraft.func_71410_x().field_71439_g.field_70125_A;
    }

    public void restoreRotations() {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = this.yaw;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = this.yaw;
        Minecraft.func_71410_x().field_71439_g.field_70125_A = this.pitch;
    }

    public void setPlayerRotations(float f, float f2) {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = f;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = f;
        Minecraft.func_71410_x().field_71439_g.field_70125_A = f2;
    }

    public void setPlayerYaw(float f) {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = f;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = f;
    }

    public void setPlayerPitch(float f) {
        Minecraft.func_71410_x().field_71439_g.field_70125_A = f;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float f) {
        this.yaw = f;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float f) {
        this.pitch = f;
    }

    public RotationTaskFactory getFactory() {
        return this.factory;
    }
}
