package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventCancellable;

public class EventMove
extends EventCancellable {
    public /* synthetic */ double z;
    public /* synthetic */ double x;
    public /* synthetic */ double y;

    public void setZ(double d) {
        this.z = d;
    }

    public void setY(double d) {
        this.y = d;
    }

    public double getX() {
        return this.x;
    }

    public void setX(double d) {
        this.x = d;
    }

    public double getZ() {
        return this.z;
    }

    public boolean cancel() {
        return false;
    }

    public double getY() {
        return this.y;
    }

    public EventMove(double d, double d2, double d3) {
        this.x = d;
        this.y = d2;
        this.z = d3;
    }
}
