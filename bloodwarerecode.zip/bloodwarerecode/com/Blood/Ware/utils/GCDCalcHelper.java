package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Helper;
import com.Blood.Ware.utils.MinecraftHelper;
import net.minecraft.client.Minecraft;

public class GCDCalcHelper
implements Helper {
    public static float getGCDValue() {
        return (float)((double)GCDCalcHelper.getGCD() * 0.15);
    }

    public static float getFixedRotation(float f) {
        return GCDCalcHelper.getDeltaMouse(f) * GCDCalcHelper.getGCDValue();
    }

    public static float getGCD() {
        float f = (float)((double)MinecraftHelper.mc.field_71474_y.field_74341_c * 0.6 + 0.2);
        return f * f * f * 8.0f;
    }

    public static float getDeltaMouse(float f) {
        return Math.round(f / GCDCalcHelper.getGCDValue());
    }

    @Override
    public Minecraft mc() {
        return null;
    }
}
