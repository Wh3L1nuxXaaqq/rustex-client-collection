package com.Blood.Ware.utils.util;

public class NoStackTraceThrowable
extends RuntimeException {
    public NoStackTraceThrowable(String string) {
        super(string);
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public String toString() {
        return "V0.2";
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
