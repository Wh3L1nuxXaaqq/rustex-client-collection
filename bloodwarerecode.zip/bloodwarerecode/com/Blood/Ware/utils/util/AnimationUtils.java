package com.Blood.Ware.utils.util;

import net.minecraft.client.Minecraft;

public class AnimationUtils {
    public static /* synthetic */ int deltaTime;
    public static /* synthetic */ float speedTarget;

    public static float animation(float f, float f2, float f3) {
        return AnimationUtils.animation(f, f2, speedTarget, f3);
    }

    public static float animation(float f, float f2, float f3, float f4) {
        float f5 = (f2 - f) / Math.max((float)Minecraft.func_175610_ah(), 5.0f) * 15.0f;
        if (f5 > 0.0f) {
            f5 = Math.max(f4, f5);
            f5 = Math.min(f2 - f, f5);
        } else if (f5 < 0.0f) {
            f5 = Math.min(-f4, f5);
            f5 = Math.max(f2 - f, f5);
        }
        return f + f5;
    }

    public static double animate(double d, double d2, double d3) {
        boolean bl = d > d2;
        boolean bl2 = bl;
        if (d3 < 0.0) {
            d3 = 0.0;
        } else if (d3 > 1.0) {
            d3 = 1.0;
        }
        double d4 = Math.max(d, d2) - Math.min(d, d2);
        double d5 = d4 * d3;
        if (d5 < 0.1) {
            d5 = 0.1;
        }
        d2 = bl ? (d2 = d2 + d5) : (d2 = d2 - d5);
        return d2;
    }

    public static float calculateCompensation(float f, float f2, long l, double d) {
        float f3 = f2 - f;
        if (l < (0x82612E1910C345DCL ^ 0x82612E1910C345DDL)) {
            l = 0xC568BF815F688213L ^ 0xC568BF815F688212L;
        }
        if (l > (0x9F16EE56E635C73BL ^ 0x9F16EE56E635C4D3L)) {
            l = 0x601B8A9A5C89BE36L ^ 0x601B8A9A5C89BE26L;
        }
        if ((double)f3 > d) {
            double d2 = d * (double)l / 16.0 < 0.5 ? 0.5 : d * (double)l / 16.0;
            if ((f2 = (float)((double)f2 - d2)) < f) {
                f2 = f;
            }
        } else if ((double)f3 < -d) {
            double d3 = d * (double)l / 16.0 < 0.5 ? 0.5 : d * (double)l / 16.0;
            if ((f2 = (float)((double)f2 + d3)) > f) {
                f2 = f;
            }
        } else {
            f2 = f;
        }
        return f2;
    }

    static {
        speedTarget = 0.125f;
    }
}
