package com.Blood.Ware.utils.util;

import java.awt.Color;
import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;

public class ColorUtil {
    public static final /* synthetic */ Random r;
    public static final /* synthetic */ int a;
    public static final /* synthetic */ int b;
    public static final /* synthetic */ int c;
    public static final /* synthetic */ int d;
    public static final /* synthetic */ int e;
    public static final /* synthetic */ int f;
    public static final /* synthetic */ int g;
    public static final /* synthetic */ int h;
    public static final /* synthetic */ int i;
    public static final /* synthetic */ int j;
    public static final /* synthetic */ int k;
    public static final /* synthetic */ int l;
    public static final /* synthetic */ int m;
    public static final /* synthetic */ int n;
    public static final /* synthetic */ int o;
    public static final /* synthetic */ int p;
    public static final /* synthetic */ int q;

    public static void setColor(float f, float f2, float f3, float f4) {
        GlStateManager.func_179131_c((float)f, (float)f2, (float)f3, (float)f4);
    }

    public static void setColor(Color color) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
    }

    public static void setColor(int n) {
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)((float)(n >> 24 & 0xFF) / 255.0f));
    }

    public static int b(int n, float f) {
        float[] fArray = ColorUtil.a(n);
        int n2 = ColorUtil.a(fArray[0], fArray[1], fArray[2], f);
        return n2;
    }

    public static Color a(int n, long l, float f) {
        double d = Math.ceil(System.currentTimeMillis() + l + (long)n) / 15.0;
        Color color = ColorUtil.a((float)((d %= 360.0) / 360.0), f, 1.0f);
        return color;
    }

    public static Color a(float f, float f2, float f3) {
        return Color.getHSBColor(f, f2, f3);
    }

    public static int a(int n, int n2, float f) {
        float f2;
        float f3 = 1.0f;
        float f4 = 2900.0f;
        for (f2 = (float)(System.currentTimeMillis() % (long)((int)f4)) + (float)((n2 - n) * 9); f2 > f4; f2 -= f4) {
        }
        f2 /= f4;
        if ((double)f3 > 0.5) {
            f2 = 0.5f - (f2 - 0.5f);
        }
        return Color.HSBtoRGB(f2 += 0.5f, f, 1.0f);
    }

    public static float[] a(int n) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        return new float[]{f2, f3, f4, f};
    }

    public static int a(float f, float f2, float f3, float f4) {
        return new Color(f, f2, f3, f4).getRGB();
    }

    static {
        r = new Random();
        a = new Color(246, 7, 214, 255).getRGB();
        b = new Color(0, 255, 0, 255).getRGB();
        c = new Color(0, 0, 255, 255).getRGB();
        d = new Color(0, 0, 0, 255).getRGB();
        e = new Color(200, 200, 200, 255).getRGB();
        f = new Color(255, 255, 255, 155).getRGB();
        g = new Color(50, 50, 50, 255).getRGB();
        h = new Color(20, 20, 20, 255).getRGB();
        i = new Color(120, 120, 120, 200).getRGB();
        j = new Color(255, 255, 0, 255).getRGB();
        k = new Color(255, 165, 0, 255).getRGB();
        l = new Color(255, 0, 255, 255).getRGB();
        m = new Color(0, 255, 255, 255).getRGB();
        n = new Color(0, 155, 155, 255).getRGB();
        o = new Color(155, 20, 20, 255).getRGB();
        p = new Color(0, 175, 255, 255).getRGB();
        q = new Color(0, 0, 0, 0).getRGB();
    }
}
