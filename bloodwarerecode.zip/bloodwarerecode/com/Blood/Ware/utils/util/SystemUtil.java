package com.Blood.Ware.utils.util;

public class SystemUtil {
    public static String getSystemInfo() {
        return "CR3CK_BY_WH3L1NUXXAA";
    }
}
