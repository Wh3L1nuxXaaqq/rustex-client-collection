package com.Blood.Ware.utils.util;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

public class ColorUtility {
    public static float[] getRGBAf(int n) {
        return new float[]{(float)(n >> 16 & 0xFF) / 255.0f, (float)(n >> 8 & 0xFF) / 255.0f, (float)(n & 0xFF) / 255.0f, (float)(n >> 24 & 0xFF) / 255.0f};
    }

    public static void setColor(Color color) {
        if (color == null) {
            color = Color.WHITE;
        }
        ColorUtility.setColor((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static int setAlpha(int n, int n2) {
        Color color = new Color(n);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), n2).getRGB();
    }

    public static int setAlpha(int n, float f) {
        Color color = new Color(n);
        return new Color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, f).getRGB();
    }

    public static void setColor(double d, double d2, double d3, double d4) {
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)d4);
    }

    public static void setColor(int n) {
        ColorUtility.setColor(n, (float)(n >> 24 & 0xFF) / 255.0f);
    }

    public static void setColor(int n, float f) {
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        GlStateManager.func_179131_c((float)f2, (float)f3, (float)f4, (float)f);
    }

    public static int getRed(int n) {
        return n >> 16 & 0xFF;
    }

    public static int getGreen(int n) {
        return n >> 8 & 0xFF;
    }

    public static int getBlue(int n) {
        return n & 0xFF;
    }

    public static int getAlpha(int n) {
        return n >> 24 & 0xFF;
    }

    public static Double interpolate(double d, double d2, double d3) {
        return d + (d2 - d) * d3;
    }

    public static Color applyOpacity(Color color, float f) {
        f = Math.min(1.0f, Math.max(0.0f, f));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f));
    }

    public static int interpolateInt(int n, int n2, double d) {
        return ColorUtility.interpolate(n, n2, (float)d).intValue();
    }

    public static Color interpolateColorC(int n, int n2, float f) {
        f = Math.min(1.0f, Math.max(0.0f, f));
        return new Color(ColorUtility.interpolateInt(ColorUtility.getRed(n), ColorUtility.getRed(n2), f), ColorUtility.interpolateInt(ColorUtility.getGreen(n), ColorUtility.getGreen(n2), f), ColorUtility.interpolateInt(ColorUtility.getBlue(n), ColorUtility.getBlue(n2), f), ColorUtility.interpolateInt(ColorUtility.getAlpha(n), ColorUtility.getAlpha(n2), f));
    }

    public static Color gradient(int n, int n2, Color[] colorArray) {
        int n3 = (int)((System.currentTimeMillis() / (long)n + (long)n2) % (0xEC8C1896D832AAF0L ^ 0xEC8C1896D832AB98L));
        n3 = (n3 > 180 ? 360 - n3 : n3) + 180;
        int n4 = (int)((float)n3 / 360.0f * (float)colorArray.length);
        if (n4 == colorArray.length) {
            n4 += 19822;
            n4 -= 19823;
        }
        Color color = colorArray[n4];
        Color color2 = colorArray[n4 == colorArray.length - 1 ? 0 : n4 + 1];
        return ColorUtility.interpolateColorC(color.getRGB(), color2.getRGB(), (float)n3 / 360.0f * (float)colorArray.length - (float)n4);
    }

    public static Color fade(int n, int n2, Color color, float f) {
        float[] fArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        int n3 = (int)((System.currentTimeMillis() / (long)n + (long)n2) % (0xB82D3D49D0F42062L ^ 0xB82D3D49D0F4210AL));
        n3 = (n3 > 180 ? 360 - n3 : n3) + 180;
        Color color2 = new Color(Color.HSBtoRGB(fArray[0], fArray[1], (float)n3 / 360.0f));
        return new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), Math.max(0, Math.min(255, (int)(f * 255.0f))));
    }

    public static int HUEtoRGB(int n) {
        float f = (float)n / 360.0f;
        return Color.HSBtoRGB(f, 1.0f, 1.0f);
    }

    public static Color getColor(int n) {
        Color color = new Color(255, 255, 255);
        Color color2 = new Color(255, 0, 0);
        return color;
    }

    public static String getHealthStr(EntityLivingBase entityLivingBase) {
        String string = "";
        int n = (int)entityLivingBase.func_110143_aJ();
        if ((double)n <= (double)entityLivingBase.func_110138_aP() * 0.25) {
            string = "\u00a74";
        } else if ((double)n <= (double)entityLivingBase.func_110138_aP() * 0.5) {
            string = "\u00a76";
        } else if ((double)n <= (double)entityLivingBase.func_110138_aP() * 0.75) {
            string = "\u00a7e";
        } else if ((float)n <= entityLivingBase.func_110138_aP()) {
            string = "\u00a7a";
        }
        return string;
    }
}
