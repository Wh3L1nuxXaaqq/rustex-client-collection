package com.Blood.Ware.utils.util;

public enum AnimationState {
    RETRACTING,
    EXPANDING,
    STATIC;

}
