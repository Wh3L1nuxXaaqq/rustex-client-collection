package com.Blood.Ware.utils.util;

import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.utils.MathUtils;
import com.Blood.Ware.utils.MinecraftHelper;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class EntityUtil {
    public static Color getColor(Entity entity, int n, int n2, int n3, int n4, boolean bl) {
        Color color = new Color((float)n / 255.0f, (float)n2 / 255.0f, (float)n3 / 255.0f, (float)n4 / 255.0f);
        if (entity instanceof EntityPlayer && bl && FriendManager.isFriend(String.valueOf(entity))) {
            color = new Color(0.33333334f, 1.0f, 1.0f, (float)n4 / 255.0f);
        }
        return color;
    }

    public static float[] calculateLookAt(double d, double d2, double d3, EntityPlayer entityPlayer) {
        double d4 = entityPlayer.field_70165_t - d;
        double d5 = entityPlayer.field_70163_u - d2;
        double d6 = entityPlayer.field_70161_v - d3;
        double d7 = Math.sqrt(d4 * d4 + d5 * d5 + d6 * d6);
        return new float[]{(float)(Math.atan2(d6 / d7, d4 / d7) * 180.0 / Math.PI + 90.0), (float)(Math.asin(d5 / d7) * 180.0 / Math.PI)};
    }

    public static boolean isPassive(Entity entity) {
        return (!(entity instanceof EntityWolf) || !((EntityWolf)entity).func_70919_bu()) && (entity instanceof EntityAnimal || entity instanceof EntityAgeable || entity instanceof EntityTameable || entity instanceof EntityAmbientCreature || entity instanceof EntitySquid || entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null);
    }

    public static Vec3d getInterpolatedRenderPos(Entity entity, float f) {
        return EntityUtil.getInterpolatedPos(entity, f).func_178786_a(MinecraftHelper.mc.func_175598_ae().field_78730_l, MinecraftHelper.mc.func_175598_ae().field_78731_m, MinecraftHelper.mc.func_175598_ae().field_78728_n);
    }

    public static Vec3d getInterpolatedRenderPos(Vec3d vec3d) {
        return new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c).func_178786_a(MinecraftHelper.mc.func_175598_ae().field_78730_l, MinecraftHelper.mc.func_175598_ae().field_78731_m, MinecraftHelper.mc.func_175598_ae().field_78728_n);
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double d, double d2, double d3) {
        return new Vec3d((entity.field_70165_t - entity.field_70142_S) * d, (entity.field_70163_u - entity.field_70137_T) * d2, (entity.field_70161_v - entity.field_70136_U) * d3);
    }

    public static double GetDistanceOfEntityToBlock(Entity entity, BlockPos blockPos) {
        return EntityUtil.GetDistance(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p());
    }

    public static boolean isLiving(Entity entity) {
        return entity instanceof EntityLivingBase;
    }

    public static boolean stopSneaking(boolean bl) {
        if (bl && MinecraftHelper.mc.field_71439_g != null) {
            MinecraftHelper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)MinecraftHelper.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
        return false;
    }

    public static boolean isAnimal(Entity entity) {
        return entity instanceof EntityAgeable || entity instanceof EntityAmbientCreature || entity instanceof EntityWaterMob || entity instanceof EntityGolem;
    }

    public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec3d) {
        return EntityUtil.getInterpolatedAmount(entity, vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double d) {
        return EntityUtil.getInterpolatedAmount(entity, d, d, d);
    }

    public static Vec3d getInterpolatedPos(Entity entity, float f) {
        return MathUtils.interpolateVec3d(entity.func_174791_d(), new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U), f);
    }

    public static double GetDistance(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d - d4;
        double d8 = d2 - d5;
        double d9 = d3 - d6;
        return MathHelper.func_76133_a((double)(d7 * d7 + d8 * d8 + d9 * d9));
    }
}
