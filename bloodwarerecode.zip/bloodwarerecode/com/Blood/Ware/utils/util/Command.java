package com.Blood.Ware.utils.util;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public abstract class Command
extends Module {
    public static /* synthetic */ String prefix;
    public static final /* synthetic */ Minecraft mc;

    public Command(String string, Category category) {
        super(string, category);
    }

    public abstract void onClientCommand(String var1, String[] var2) throws Exception;

    public static void sendClientSideMessage(String string) {
        if (Command.mc.field_71439_g == null || Command.mc.field_71441_e == null) {
            return;
        }
        Command.mc.field_71439_g.func_145747_a((ITextComponent)new TextComponentString(String.valueOf(new StringBuilder().append(ChatFormatting.DARK_RED).append("[BloodWare] ").append(ChatFormatting.WHITE).append(string))));
    }

    public static String getClientPrefix() {
        return prefix;
    }

    public static void setClientPrefix(String string) {
        prefix = string;
    }

    public abstract String getClientSyntax();

    public abstract String[] getClientAlias();

    static {
        mc = Minecraft.func_71410_x();
        prefix = ".";
    }
}
