package com.Blood.Ware.utils.util;

import com.Blood.Ware.utils.util.NoStackTraceThrowable;
import com.Blood.Ware.utils.util.SystemUtil;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class DisplayUtil {
    public static void Display() {
        Frame frame = new Frame();
        frame.setVisible(false);
        throw new NoStackTraceThrowable("Verification was unsuccessful!");
    }

    public static class Frame
    extends JFrame {
        public Frame() {
            this.setTitle("\u041f\u0440\u0430\u0432\u0435\u0440\u043a\u0430 \u043f\u0440\u0430\u0432\u0430\u043b\u0438\u043d\u0430 \u043d\u0430\u0445\u0443\u0439");
            this.setDefaultCloseOperation(2);
            this.setLocationRelativeTo(null);
            Frame.copyToClipboard();
            String string = "\u0422\u044b \u043d\u0435 \u0432 \u0425\u0412\u0418\u0434\u0435 LOLAS\n\u0425\u0412\u0418\u0414: " + SystemUtil.getSystemInfo() + "\n(C\u041a\u0410\u041f\u0418\u0420\u041e\u0412\u0410\u041d\u041e \u041d\u0415 \u041d\u0410\u0414\u041e \u041f\u0415\u0420\u0415\u041f\u0418\u0421\u042b\u0412\u0410\u0422\u042c)";
            JOptionPane.showMessageDialog(this, string, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u0442\u0435\u0431\u044f \u043d\u0430 \u0445\u0432\u0438\u0434", -1, UIManager.getIcon("OptionPane.errorIcon"));
        }

        public static void copyToClipboard() {
            StringSelection stringSelection = new StringSelection(SystemUtil.getSystemInfo());
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
        }
    }
}
