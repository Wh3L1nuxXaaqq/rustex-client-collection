package com.Blood.Ware.utils.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class URLReader {
    public static List<String> readURL() {
        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            String string;
            URL uRL = new URL("https://pastebin.com/raw/wEGh7KLt");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRL.openStream()));
            while ((string = bufferedReader.readLine()) != null) {
                arrayList.add(string);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrayList;
    }
}
