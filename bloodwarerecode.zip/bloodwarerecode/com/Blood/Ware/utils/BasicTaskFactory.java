package com.Blood.Ware.utils;

import com.Blood.Ware.utils.BasicTask;
import com.Blood.Ware.utils.TaskFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public abstract class BasicTaskFactory<T extends BasicTask>
implements TaskFactory<T> {
    public final /* synthetic */ List<T> tasks;
    public /* synthetic */ BasicTask currentTask;

    public BasicTaskFactory() {
        this.tasks = new ArrayList<T>();
        this.currentTask = null;
    }

    public void addTask(T t) {
        this.tasks.add(t);
    }

    @Override
    public void removeTask(String string) {
        this.tasks.remove(this.getTask(string));
    }

    @Override
    public void removeTask(T t) {
        this.tasks.remove(t);
    }

    @Override
    public List<T> getTasks() {
        return this.tasks;
    }

    public boolean startTask(T t) {
        if (this.currentTask == t) {
            this.currentTask.setOnline(true);
            return true;
        }
        if (this.isCurrentlyTasking()) {
            if (this.currentTask.getPriority() < ((BasicTask)t).getPriority()) {
                this.currentTask.setOnline(false);
                this.currentTask = t;
                this.currentTask.setOnline(true);
                return true;
            }
            return false;
        }
        if (!this.isCurrentlyTasking()) {
            this.currentTask = t;
            this.currentTask.setOnline(true);
        }
        return true;
    }

    public void finishTask(T t) {
        if (this.currentTask == t) {
            this.currentTask.setOnline(false);
            this.currentTask = null;
        }
    }

    public T getTask(String string) {
        BasicTask basicTask = null;
        for (BasicTask basicTask2 : this.getTasks()) {
            if (!basicTask2.getName().equalsIgnoreCase(string)) continue;
            basicTask = basicTask2;
            break;
        }
        return (T)basicTask;
    }

    public boolean comparePriority(T t) {
        return ((BasicTask)t).getPriority() >= this.currentTask.getPriority();
    }

    public boolean isCurrentlyTasking() {
        return Objects.nonNull(this.currentTask);
    }
}
