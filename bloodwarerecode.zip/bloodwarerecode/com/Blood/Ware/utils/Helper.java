package com.Blood.Ware.utils;

import com.Blood.Ware.utils.MinecraftHelper;
import com.Blood.Ware.utils.TimerHelper;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.network.Packet;

public interface Helper {
    public static final /* synthetic */ Gui gui;
    public static final /* synthetic */ Random random;
    public static final /* synthetic */ ScaledResolution sr;
    public static final /* synthetic */ TimerHelper timerHelper;

    public Minecraft mc();

    default public void sendPacket(Packet packet) {
        MinecraftHelper.mc.field_71439_g.field_71174_a.func_147297_a(packet);
    }

    static {
        gui = new Gui();
        random = new Random();
        sr = new ScaledResolution(MinecraftHelper.mc);
        timerHelper = new TimerHelper();
    }
}
