package com.Blood.Ware.utils;

import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.notifications.notifications;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.util.text.ITextComponent;

public class NetHandlerPlayClientHook
extends NetHandlerPlayClient {
    public NetHandlerPlayClientHook(Minecraft minecraft, GuiScreen guiScreen, NetworkManager networkManager, GameProfile gameProfile) {
        super(minecraft, guiScreen, networkManager, gameProfile);
    }

    public void func_147297_a(Packet<?> packet) {
        notifications.add("rotation", "work", Type.OK);
        super.func_147297_a(packet);
    }

    public void func_147231_a(ITextComponent iTextComponent) {
        super.func_147231_a(iTextComponent);
    }
}
