package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class ScaleUtils {
    public /* synthetic */ int scale;

    public ScaleUtils(int n) {
        this.scale = n;
    }

    public void pushScale() {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        double d = (double)scaledResolution.func_78325_e() / Math.pow(scaledResolution.func_78325_e(), 2.0);
        GlStateManager.func_179094_E();
        GlStateManager.func_179139_a((double)(d * (double)this.scale), (double)(d * (double)this.scale), (double)(d * (double)this.scale));
    }

    public int calc(int n) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        return n * scaledResolution.func_78325_e() / this.scale;
    }

    public void popScale() {
        GlStateManager.func_179152_a((float)this.scale, (float)this.scale, (float)this.scale);
        GlStateManager.func_179121_F();
    }

    public int[] getMouse(int n, int n2, ScaledResolution scaledResolution) {
        return new int[]{n * scaledResolution.func_78325_e() / this.scale, n2 * scaledResolution.func_78325_e() / this.scale};
    }

    public int getScale() {
        return this.scale;
    }

    public void setScale(int n) {
        this.scale = n;
    }
}
