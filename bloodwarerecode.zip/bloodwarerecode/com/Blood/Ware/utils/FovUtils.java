package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class FovUtils {
    public static boolean isInAttackFOV(Entity entity, int n) {
        return FovUtils.getDistanceFromMouse(entity) <= n;
    }

    public static int getDistanceFromMouse(Entity entity) {
        float[] fArray = FovUtils.getNeededRotations(entity);
        float f = Minecraft.func_71410_x().field_71439_g.field_70177_z - fArray[0];
        float f2 = Minecraft.func_71410_x().field_71439_g.field_70125_A - fArray[1];
        float f3 = MathHelper.func_76129_c((float)(f * f + f2 * f2));
        return (int)f3;
    }

    public static float[] getNeededRotations(Entity entity) {
        Minecraft minecraft = Minecraft.func_71410_x();
        double d = entity.field_70165_t - minecraft.field_71439_g.field_70165_t;
        double d2 = entity.field_70163_u + 1.86 - (minecraft.field_71439_g.field_70163_u + (double)minecraft.field_71439_g.func_70047_e());
        double d3 = entity.field_70161_v - minecraft.field_71439_g.field_70161_v;
        double d4 = Math.sqrt(d * d + d3 * d3);
        double d5 = Math.toDegrees(Math.atan2(d3, d)) - 90.0;
        double d6 = -Math.toDegrees(Math.atan2(d2, d4));
        double d7 = (double)minecraft.field_71439_g.field_70177_z + MathHelper.func_76138_g((double)(d5 - (double)minecraft.field_71439_g.field_70177_z));
        double d8 = (double)minecraft.field_71439_g.field_70125_A + MathHelper.func_76138_g((double)(d6 - (double)minecraft.field_71439_g.field_70125_A));
        return new float[]{(float)d7, (float)d8};
    }
}
