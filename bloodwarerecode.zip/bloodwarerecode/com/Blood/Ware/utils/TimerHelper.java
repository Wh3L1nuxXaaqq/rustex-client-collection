package com.Blood.Ware.utils;

public class TimerHelper {
    public /* synthetic */ long previousTime;
    public /* synthetic */ long ms;

    public long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public TimerHelper() {
        this.previousTime = 0xF11CF49E30417CD3L ^ 0xEE30B61CFBE832CL;
        this.ms = this.getCurrentMS();
    }

    public long getCurrentTime() {
        return System.currentTimeMillis();
    }

    public short convert(float f) {
        return (short)(1000.0f / f);
    }

    public boolean check(float f) {
        return (float)(this.getCurrentTime() - this.previousTime) >= f;
    }

    public boolean hasReached(float f) {
        return (float)(this.getCurrentMS() - this.ms) > f;
    }

    public void reset() {
        this.previousTime = this.getCurrentTime();
    }

    public long getTime() {
        return System.currentTimeMillis() - this.previousTime;
    }

    public long get() {
        return this.previousTime;
    }
}
