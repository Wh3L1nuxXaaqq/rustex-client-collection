package com.Blood.Ware.utils;

import com.Blood.Ware.events.EventTarget;
import com.Blood.Ware.utils.EventPlayerState;
import com.Blood.Ware.utils.EventSendPacket;
import com.Blood.Ware.utils.GCDCalcHelper;
import com.Blood.Ware.utils.Helper;
import com.Blood.Ware.utils.MathematicHelper;
import com.Blood.Ware.utils.MinecraftHelper;
import com.Blood.Ware.utils.MovementHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationHelper
implements Helper {
    public static float[] getRotationVector(Vec3d vec3d, boolean bl, float f, float f2, float f3) {
        Vec3d vec3d2 = RotationHelper.getEyesPos();
        double d = vec3d.field_72450_a - vec3d2.field_72450_a;
        double d2 = vec3d.field_72448_b - (MinecraftHelper.mc.field_71439_g.field_70163_u + (double)MinecraftHelper.mc.field_71439_g.func_70047_e() + 0.5);
        double d3 = vec3d.field_72449_c - vec3d2.field_72449_c;
        double d4 = Math.sqrt(d * d + d3 * d3);
        float f4 = 0.0f;
        if (bl) {
            f4 = MathematicHelper.randomizeFloat(-f, f);
        }
        float f5 = 0.0f;
        if (bl) {
            f5 = MathematicHelper.randomizeFloat(-f2, f2);
        }
        return new float[]{RotationHelper.updateRotation(MinecraftHelper.mc.field_71439_g.field_70177_z, MinecraftHelper.mc.field_71439_g.field_70177_z + GCDCalcHelper.getFixedRotation(MathHelper.func_76142_g((float)((float)(Math.toDegrees(Math.atan2(d3, d)) - 90.0) + f4 - MinecraftHelper.mc.field_71439_g.field_70177_z))), f3), RotationHelper.updateRotation(MinecraftHelper.mc.field_71439_g.field_70125_A, MathHelper.func_76131_a((float)(MinecraftHelper.mc.field_71439_g.field_70125_A + GCDCalcHelper.getFixedRotation(MathHelper.func_76142_g((float)((float)(-Math.toDegrees(Math.atan2(d2, d4))) + f5 - MinecraftHelper.mc.field_71439_g.field_70125_A)))), (float)-90.0f, (float)90.0f), f3)};
    }

    public static float getAngleEntity(Entity entity) {
        float f = MinecraftHelper.mc.field_71439_g.field_70177_z;
        return f + MathHelper.func_76142_g((float)((float)(Math.atan2(entity.field_70161_v - MinecraftHelper.mc.field_71439_g.field_70161_v, entity.field_70165_t - MinecraftHelper.mc.field_71439_g.field_70165_t) * 180.0 / Math.PI - 90.0) - f));
    }

    public static float[] getFacePosRemote(EntityLivingBase entityLivingBase, Entity entity, boolean bl) {
        Vec3d vec3d = new Vec3d(entityLivingBase.field_70165_t, entityLivingBase.field_70163_u, entityLivingBase.field_70161_v);
        Vec3d vec3d2 = new Vec3d(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
        double d = vec3d2.field_72450_a - vec3d.field_72450_a;
        double d2 = vec3d2.field_72448_b - vec3d.field_72448_b;
        double d3 = vec3d2.field_72449_c - vec3d.field_72449_c;
        float f = 0.0f;
        if (bl) {
            f = MathematicHelper.randomizeFloat(-2.0f, 2.0f);
        }
        float f2 = 0.0f;
        if (bl) {
            f2 = MathematicHelper.randomizeFloat(-2.0f, 2.0f);
        }
        return new float[]{MathHelper.func_76142_g((float)((float)(Math.atan2(d3, d) * 180.0 / Math.PI) - 90.0f + f)), MathHelper.func_76142_g((float)((float)(-(Math.atan2(d2, MathHelper.func_76133_a((double)(d * d + d3 * d3))) * 180.0 / Math.PI)) + f2))};
    }

    @Override
    public Minecraft mc() {
        return null;
    }

    public static Vec3d getEyesPos() {
        return new Vec3d(MinecraftHelper.mc.field_71439_g.field_70165_t, MinecraftHelper.mc.field_71439_g.func_174813_aQ().field_72338_b + (double)MinecraftHelper.mc.field_71439_g.func_70047_e(), MinecraftHelper.mc.field_71439_g.field_70161_v);
    }

    public static float updateRotation(float f, float f2, float f3) {
        float f4 = MathHelper.func_76142_g((float)(f2 - f));
        if (f4 > f3) {
            f4 = f3;
        }
        if (f4 < -f3) {
            f4 = -f3;
        }
        return f + f4;
    }

    public static class Rotation {
        public static /* synthetic */ float lastRenderPacketYaw;
        public static /* synthetic */ float lastPacketPitch;
        public static /* synthetic */ float renderPacketYaw;
        public static /* synthetic */ int rotationCounter;
        public static /* synthetic */ boolean isAiming;
        public static /* synthetic */ boolean isReady;
        public static /* synthetic */ float packetPitch;
        public static /* synthetic */ float lastBodyYaw;
        public static /* synthetic */ float bodyYaw;
        public static /* synthetic */ float lastPacketYaw;
        public static /* synthetic */ float packetYaw;

        public static double calcMove() {
            return Math.hypot(MinecraftHelper.mc.field_71439_g.field_70165_t - MinecraftHelper.mc.field_71439_g.field_70169_q, MinecraftHelper.mc.field_71439_g.field_70161_v - MinecraftHelper.mc.field_71439_g.field_70166_s);
        }

        public static boolean isAiming() {
            return !isAiming;
        }

        @EventTarget
        public void onSendPacket(EventSendPacket eventSendPacket) {
            if (eventSendPacket.getPacket() instanceof CPacketAnimation) {
                rotationCounter = 10;
            }
        }

        @EventTarget
        public void onPlayerState(EventPlayerState eventPlayerState) {
            if (Rotation.isAiming() && eventPlayerState.isPre()) {
                isReady = true;
            } else if (Rotation.isAiming() && isReady && eventPlayerState.isPost()) {
                packetPitch = MinecraftHelper.mc.field_71439_g.field_70125_A;
                packetYaw = MinecraftHelper.mc.field_71439_g.field_70177_z;
                lastPacketPitch = MinecraftHelper.mc.field_71439_g.field_70125_A;
                lastPacketYaw = MinecraftHelper.mc.field_71439_g.field_70177_z;
                bodyYaw = MinecraftHelper.mc.field_71439_g.field_70761_aq;
                isReady = false;
            } else {
                isReady = false;
            }
            if (eventPlayerState.isPre()) {
                lastBodyYaw = bodyYaw;
                lastPacketPitch = packetPitch;
                lastPacketYaw = packetYaw;
                bodyYaw = MathematicHelper.clamp(bodyYaw, packetYaw, 50.0f);
                if (Rotation.calcMove() > 2.500000277905201E-7) {
                    bodyYaw = MathematicHelper.clamp(MovementHelper.getMoveDirection(), packetYaw, 50.0f);
                    rotationCounter = 0;
                } else if (rotationCounter > 0) {
                    --rotationCounter;
                    bodyYaw = MathematicHelper.checkAngle(packetYaw, bodyYaw, 10.0f);
                }
                lastRenderPacketYaw = renderPacketYaw;
                renderPacketYaw = packetYaw;
            }
        }

        static {
            isReady = false;
        }
    }
}
