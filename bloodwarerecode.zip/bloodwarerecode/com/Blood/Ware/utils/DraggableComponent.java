package com.Blood.Ware.utils;

import java.util.ArrayList;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class DraggableComponent {
    public final /* synthetic */ int height;
    public /* synthetic */ int x;
    public /* synthetic */ int lastX;
    public /* synthetic */ int color;
    public /* synthetic */ int lastY;
    public /* synthetic */ boolean canRender;
    public final /* synthetic */ int width;
    public static /* synthetic */ ArrayList draggableModules;
    public /* synthetic */ int y;
    public /* synthetic */ boolean dragging;

    public DraggableComponent(int n, int n2, int n3, int n4, int n5) {
        this.canRender = true;
        this.width = n3;
        this.height = n4;
        this.x = n;
        this.y = n2;
        this.color = n5;
    }

    public void draggingFix(int n, int n2) {
        if (this.dragging) {
            this.x = n + this.lastX;
            this.y = n2 + this.lastY;
            if (!Mouse.isButtonDown((int)0)) {
                this.dragging = false;
            }
        }
    }

    public void draw(int n, int n2) {
        if (this.canRender) {
            this.draggingFix(n, n2);
            Gui.func_73734_a((int)this.getXPosition(), (int)(this.getYPosition() - this.getHeight() / 4), (int)(this.getXPosition() + this.getWidth()), (int)(this.getYPosition() + this.getHeight()), (int)this.getColor());
            boolean bl = n >= this.getXPosition() && n <= this.getXPosition() + this.getWidth();
            boolean bl2 = false;
            if (n2 < this.getYPosition() - this.getHeight() / 4 || n2 > this.getYPosition() - this.getHeight() / 4 + this.getHeight()) {
                bl2 = false;
            }
            boolean bl3 = bl2;
            if (bl && bl3) {
                if (Mouse.isButtonDown((int)0)) {
                    if (!this.dragging && draggableModules.size() <= 1) {
                        this.lastX = this.x - n;
                        this.lastY = this.y - n2;
                        this.dragging = true;
                    }
                } else {
                    draggableModules.clear();
                }
            }
        }
    }

    public int getColor() {
        return this.color;
    }

    public void setXPosition(int n) {
        this.x = n;
    }

    public void setColor(int n) {
        this.color = n;
    }

    public boolean isCanRender() {
        return this.canRender;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getYPosition() {
        return this.y;
    }

    public void setYPosition(int n) {
        this.y = n;
    }

    public boolean isDragging() {
        return this.dragging;
    }

    public void setCanRender(boolean bl) {
        this.canRender = bl;
    }

    public boolean isHovered(int n, int n2) {
        return n >= this.getXPosition() && n <= this.getXPosition() + this.getWidth() && n2 >= this.getYPosition() - this.getHeight() / 4 && n2 <= this.getYPosition() - this.getHeight() / 4 + this.getHeight();
    }

    public int getXPosition() {
        return this.x;
    }

    static {
        draggableModules = new ArrayList();
    }
}
