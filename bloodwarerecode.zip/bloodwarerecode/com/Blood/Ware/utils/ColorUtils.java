package com.Blood.Ware.utils;

import com.Blood.Ware.utils.MathUtils;
import java.awt.Color;
import java.text.NumberFormat;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class ColorUtils {
    public static int getColor(Color color) {
        return ColorUtils.getColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int getColor() {
        return ColorUtils.TwoColoreffect(new Color(221, 0, 255), new Color(246, 246, 246), (double)Math.abs(System.currentTimeMillis() / (0x9CE10238ECC6A817L ^ 0x9CE10238ECC6A81DL)) / 100.0 + 0.16999999999999998).getRGB();
    }

    public static int getColor2() {
        return ColorUtils.TwoColoreffect(new Color(246, 246, 246), new Color(221, 0, 255), (double)Math.abs(System.currentTimeMillis() / (0xB98289C341031A20L ^ 0xB98289C341031A2AL)) / 100.0 + 0.16999999999999998).getRGB();
    }

    public static Color getColorWithOpacity(Color color, int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
    }

    public static int rainbow(int n, long l) {
        double d = Math.ceil(System.currentTimeMillis() + l + (long)n) / 15.0;
        return Color.getHSBColor((float)((d %= 360.0) / 360.0), 0.4f, 1.0f).getRGB();
    }

    public static Color fade(Color color) {
        return ColorUtils.fade(color, 2, 100);
    }

    public static int color(int n, int n2, int n3, int n4) {
        n4 = 255;
        return new Color(n, n2, n3, n4).getRGB();
    }

    public static int getRandomColor() {
        char[] cArray = "012345678".toCharArray();
        String string = "0x";
        for (int i = 0; i < 6; i += 14257) {
            string = string + cArray[new Random().nextInt(cArray.length)];
            i -= 14256;
        }
        return Integer.decode(string);
    }

    public static int reAlpha(int n, float f) {
        Color color = new Color(n);
        float f2 = 0.003921569f * (float)color.getRed();
        float f3 = 0.003921569f * (float)color.getGreen();
        float f4 = 0.003921569f * (float)color.getBlue();
        return new Color(f2, f3, f4, f).getRGB();
    }

    public static Color getGradientOffset(Color color, Color color2, double d) {
        int n;
        double d2;
        if (d > 1.0) {
            d2 = d % 1.0;
            n = (int)d;
            d = n % 2 == 0 ? d2 : 1.0 - d2;
        }
        d2 = 1.0 - d;
        n = (int)((double)color.getRed() * d2 + (double)color2.getRed() * d);
        int n2 = (int)((double)color.getGreen() * d2 + (double)color2.getGreen() * d);
        int n3 = (int)((double)color.getBlue() * d2 + (double)color2.getBlue() * d);
        return new Color(n, n2, n3);
    }

    public static int getColor1(int n) {
        return ColorUtils.getColor(n, n, n, 255);
    }

    public static int getColor(int n, int n2, int n3) {
        return ColorUtils.getColor(n, n2, n3, 255);
    }

    public static int getColor(int n, int n2, int n3, int n4) {
        int n5 = 0;
        n5 |= n4 << 24;
        n5 |= n << 16;
        n5 |= n2 << 8;
        return n5 |= n3;
    }

    public static int getColor(int n, int n2) {
        return ColorUtils.getColor(n, n, n, n2);
    }

    public static Color fade(Color color, int n, int n2) {
        float[] fArray = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fArray);
        float f = Math.abs(((float)(System.currentTimeMillis() % (0x7A7DB7B6555EB8AEL ^ 0x7A7DB7B6555EBF7EL)) / 1000.0f + (float)n / (float)n2 * 2.0f) % 2.0f - 1.0f);
        f = 0.5f + 0.5f * f;
        fArray[2] = f % 2.0f;
        return new Color(Color.HSBtoRGB(fArray[0], fArray[1], fArray[2]));
    }

    public static Color getHealthColor(EntityLivingBase entityLivingBase) {
        float f = entityLivingBase.func_110143_aJ();
        float[] fArray = new float[]{0.0f, 0.15f, 0.55f, 0.7f, 0.9f};
        Color[] colorArray = new Color[]{new Color(133, 0, 0), Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        float f2 = f / entityLivingBase.func_110138_aP();
        return f >= 0.0f ? ColorUtils.blendColors(fArray, colorArray, f2).brighter() : colorArray[0];
    }

    public static Color blendColors(float[] fArray, Color[] colorArray, float f) {
        if (fArray == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colorArray == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fArray.length != colorArray.length) {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        int[] nArray = ColorUtils.getFractionIndicies(fArray, f);
        float[] fArray2 = new float[]{fArray[nArray[0]], fArray[nArray[1]]};
        Color[] colorArray2 = new Color[]{colorArray[nArray[0]], colorArray[nArray[1]]};
        float f2 = fArray2[1] - fArray2[0];
        float f3 = f - fArray2[0];
        float f4 = f3 / f2;
        return ColorUtils.blend(colorArray2[0], colorArray2[1], 1.0f - f4);
    }

    public static int[] getFractionIndicies(float[] fArray, float f) {
        int n;
        int[] nArray = new int[2];
        for (n = 0; n < fArray.length && fArray[n] <= f; n += 29234) {
            n -= 29233;
        }
        if (n >= fArray.length) {
            n = fArray.length - 1;
        }
        nArray[0] = n - 1;
        nArray[1] = n;
        return nArray;
    }

    public static Color blend(Color color, Color color2, double d) {
        float f = (float)d;
        float f2 = 1.0f - f;
        float[] fArray = new float[3];
        float[] fArray2 = new float[3];
        color.getColorComponents(fArray);
        color2.getColorComponents(fArray2);
        float f3 = fArray[0] * f + fArray2[0] * f2;
        float f4 = fArray[1] * f + fArray2[1] * f2;
        float f5 = fArray[2] * f + fArray2[2] * f2;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        } else if (f3 > 255.0f) {
            f3 = 255.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        } else if (f4 > 255.0f) {
            f4 = 255.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        } else if (f5 > 255.0f) {
            f5 = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(f3, f4, f5);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            NumberFormat numberFormat = NumberFormat.getNumberInstance();
        }
        return color3;
    }

    public static int astolfo(int n, float f) {
        float f2;
        float f3;
        float f4 = 3000.0f;
        for (f3 = Math.abs((float)(System.currentTimeMillis() % (long)n) + -f / 21.0f * 2.0f); f3 > f4; f3 -= f4) {
        }
        f3 /= f4;
        if ((double)f2 > 0.5) {
            f3 = 0.5f - (f3 - 0.5f);
        }
        return Color.HSBtoRGB(f3 += 0.5f, 0.5f, 1.0f);
    }

    public static int Yellowastolfo(int n, float f) {
        float f2;
        float f3;
        float f4 = 2900.0f;
        for (f3 = (float)(System.currentTimeMillis() % (long)((int)f4)) + ((float)(-n) - f) * 9.0f; f3 > f4; f3 -= f4) {
        }
        f3 /= f4;
        if ((double)f2 > 0.6) {
            f3 = 0.6f - (f3 - 0.6f);
        }
        return Color.HSBtoRGB(f3 += 0.6f, 0.5f, 1.0f);
    }

    public static Color Yellowastolfo1(int n, float f) {
        float f2;
        float f3;
        float f4 = 2900.0f;
        for (f3 = (float)(System.currentTimeMillis() % (long)((int)f4)) + ((float)n - f) * 9.0f; f3 > f4; f3 -= f4) {
        }
        f3 /= f4;
        if ((double)f2 > 0.6) {
            f3 = 0.6f - (f3 - 0.6f);
        }
        return new Color(f3 += 0.6f, 0.5f, 1.0f);
    }

    public static Color TwoColoreffect(Color color, Color color2, double d) {
        double d2 = d / 4.0 % 1.0;
        float f = MathUtils.clamp((float)Math.sin(Math.PI * 6 * d2) / 2.0f + 0.5f, 0.0f, 1.0f);
        return new Color(MathUtils.lerp((float)color.getRed() / 255.0f, (float)color2.getRed() / 255.0f, f), MathUtils.lerp((float)color.getGreen() / 255.0f, (float)color2.getGreen() / 255.0f, f), MathUtils.lerp((float)color.getBlue() / 255.0f, (float)color2.getBlue() / 255.0f, f));
    }

    public static int astolfoColors(int n, int n2) {
        float f;
        float f2;
        float f3 = 2900.0f;
        for (f2 = (float)(System.currentTimeMillis() % (long)((int)f3)) + (float)((n2 - n) * 9); f2 > f3; f2 -= f3) {
        }
        f2 /= f3;
        if ((double)f > 0.5) {
            f2 = 0.5f - (f2 - 0.5f);
        }
        return Color.HSBtoRGB(f2 += 0.5f, 0.5f, 1.0f);
    }

    public static int getTeamColor(Entity entity) {
        int n = -1;
        n = entity.func_145748_c_().func_150260_c().equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405cR\u043f\u0457\u0405f]\u043f\u0457\u0405c" + entity.func_70005_c_()) ? ColorUtils.getColor(new Color(255, 60, 60)) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u04059B\u043f\u0457\u0405f]\u043f\u0457\u04059" + entity.func_70005_c_()) ? ColorUtils.getColor(new Color(60, 60, 255)) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405eY\u043f\u0457\u0405f]\u043f\u0457\u0405e" + entity.func_70005_c_()) ? ColorUtils.getColor(new Color(255, 255, 60)) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405aG\u043f\u0457\u0405f]\u043f\u0457\u0405a" + entity.func_70005_c_()) ? ColorUtils.getColor(new Color(60, 255, 60)) : ColorUtils.getColor(new Color(255, 255, 255)))));
        return n;
    }

    public static Color astolfoColors1(int n, int n2) {
        float f;
        float f2;
        float f3 = 2900.0f;
        for (f2 = (float)(System.currentTimeMillis() % (long)((int)f3)) + (float)((n2 - n) * 9); f2 > f3; f2 -= f3) {
        }
        f2 /= f3;
        if ((double)f > 0.5) {
            f2 = 0.5f - (f2 - 0.5f);
        }
        return new Color(f2 += 0.5f, 0.5f, 1.0f);
    }

    public static Color rainbowCol(int n, float f, float f2) {
        double d = Math.ceil((System.currentTimeMillis() + (long)n) / (0x3372BF64F2F28820L ^ 0x3372BF64F2F28830L));
        return Color.getHSBColor((float)((d %= 360.0) / 360.0), f, f2);
    }

    public static int rainbowNew(int n, float f, float f2) {
        double d = Math.ceil((System.currentTimeMillis() + (long)n) / (0x4C623B410302FA8EL ^ 0x4C623B410302FA9EL));
        return Color.getHSBColor((float)((d %= 360.0) / 360.0), f, f2).getRGB();
    }
}
