package com.Blood.Ware.utils;

import com.Blood.Ware.utils.EventMove;
import com.Blood.Ware.utils.EventStrafe;
import com.Blood.Ware.utils.Helper;
import com.Blood.Ware.utils.MinecraftHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;

public class MovementHelper
implements Helper {
    public static float getSpeed() {
        return (float)Math.sqrt(MinecraftHelper.mc.field_71439_g.field_70159_w * MinecraftHelper.mc.field_71439_g.field_70159_w + MinecraftHelper.mc.field_71439_g.field_70179_y * MinecraftHelper.mc.field_71439_g.field_70179_y);
    }

    public static boolean isBlockAboveHead() {
        return MinecraftHelper.mc.field_71441_e.func_184144_a((Entity)MinecraftHelper.mc.field_71439_g, new AxisAlignedBB(MinecraftHelper.mc.field_71439_g.field_70165_t - 0.3, MinecraftHelper.mc.field_71439_g.field_70163_u + (double)MinecraftHelper.mc.field_71439_g.func_70047_e(), MinecraftHelper.mc.field_71439_g.field_70161_v + 0.3, MinecraftHelper.mc.field_71439_g.field_70165_t + 0.3, MinecraftHelper.mc.field_71439_g.field_70163_u + (MinecraftHelper.mc.field_71439_g.field_70122_E ? 2.5 : 1.5), MinecraftHelper.mc.field_71439_g.field_70161_v - 0.3)).isEmpty();
    }

    public static void calculateSilentMove(EventStrafe eventStrafe, float f) {
        float f2;
        float f3;
        float f4 = eventStrafe.getStrafe();
        float f5 = eventStrafe.getForward();
        float f6 = eventStrafe.getFriction();
        int n = (int)((MathHelper.func_76142_g((float)(MinecraftHelper.mc.field_71439_g.field_70177_z - f - 23.5f - 135.0f)) + 180.0f) / 45.0f);
        float f7 = 0.0f;
        float f8 = 0.0f;
        switch (n) {
            case 0: {
                f7 = f5;
                f8 = f4;
                break;
            }
            case 1: {
                f3 = f7 + f5;
                f2 = f8 - f5;
                f7 = f3 + f4;
                f8 = f2 + f4;
                break;
            }
            case 2: {
                f7 = f4;
                f8 = -f5;
                break;
            }
            case 3: {
                f3 = f7 - f5;
                f2 = f8 - f5;
                f7 = f3 + f4;
                f8 = f2 - f4;
                break;
            }
            case 4: {
                f7 = -f5;
                f8 = -f4;
                break;
            }
            case 5: {
                f3 = f7 - f5;
                f2 = f8 + f5;
                f7 = f3 - f4;
                f8 = f2 - f4;
                break;
            }
            case 6: {
                f7 = -f4;
                f8 = f5;
                break;
            }
            case 7: {
                f3 = f7 + f5;
                f2 = f8 + f5;
                f7 = f3 - f4;
                f8 = f2 + f4;
                break;
            }
        }
        if (f7 > 1.0f || f7 < 0.9f && f7 > 0.3f || f7 < -1.0f || f7 > -0.9f && f7 < -0.3f) {
            f7 *= 0.5f;
        }
        if (f8 > 1.0f || f8 < 0.9f && f8 > 0.3f || f8 < -1.0f || f8 > -0.9f && f8 < -0.3f) {
            f8 *= 0.5f;
        }
        if ((f3 = f8 * f8 + f7 * f7) >= 1.0E-4f) {
            f2 = (float)((double)f6 / Math.max(1.0, Math.sqrt(f3)));
            float f9 = f8 * f2;
            float f10 = f7 * f2;
            float f11 = MathHelper.func_76126_a((float)((float)((double)f * Math.PI / 180.0)));
            float f12 = MathHelper.func_76134_b((float)((float)((double)f * Math.PI / 180.0)));
            EntityPlayerSP entityPlayerSP = MinecraftHelper.mc.field_71439_g;
            entityPlayerSP.field_70159_w += (double)(f9 * f12 - f10 * f11);
            EntityPlayerSP entityPlayerSP2 = MinecraftHelper.mc.field_71439_g;
            entityPlayerSP2.field_70179_y += (double)(f10 * f12 + f9 * f11);
        }
    }

    public static int getSpeedEffect() {
        if (MinecraftHelper.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            return MinecraftHelper.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c).func_76458_c() + 1;
        }
        return 0;
    }

    public static double getDirectionAll() {
        float f = MinecraftHelper.mc.field_71439_g.field_70177_z;
        float f2 = 1.0f;
        if (MinecraftHelper.mc.field_71439_g.field_191988_bg < 0.0f) {
            f += 180.0f;
        }
        if (MinecraftHelper.mc.field_71439_g.field_191988_bg < 0.0f) {
            f2 = -0.5f;
        } else if (MinecraftHelper.mc.field_71439_g.field_191988_bg > 0.0f) {
            f2 = 0.5f;
        }
        if (MinecraftHelper.mc.field_71439_g.field_70702_br > 0.0f) {
            f -= 90.0f * f2;
        }
        if (MinecraftHelper.mc.field_71439_g.field_70702_br < 0.0f) {
            f += 90.0f * f2;
        }
        return Math.toRadians(f);
    }

    public static boolean isMoving() {
        return MinecraftHelper.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || MinecraftHelper.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f;
    }

    public static void setEventSpeed(EventMove eventMove, double d) {
        double d2 = MinecraftHelper.mc.field_71439_g.field_71158_b.field_192832_b;
        double d3 = MinecraftHelper.mc.field_71439_g.field_71158_b.field_78902_a;
        float f = MinecraftHelper.mc.field_71439_g.field_70177_z;
        if (d2 == 0.0 && d3 == 0.0) {
            eventMove.setX(0.0);
            eventMove.setZ(0.0);
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            eventMove.setX(d2 * d * Math.cos(Math.toRadians(f + 90.0f)) + d3 * d * Math.sin(Math.toRadians(f + 90.0f)));
            eventMove.setZ(d2 * d * Math.sin(Math.toRadians(f + 90.0f)) - d3 * d * Math.cos(Math.toRadians(f + 90.0f)));
        }
    }

    @Override
    public Minecraft mc() {
        return null;
    }

    public static float getMoveDirection() {
        return -((float)(Math.atan2(MinecraftHelper.mc.field_71439_g.field_70159_w, MinecraftHelper.mc.field_71439_g.field_70179_y) / Math.PI * 180.0));
    }

    public static void setSpeed(float f) {
        float f2 = MinecraftHelper.mc.field_71439_g.field_70177_z;
        float f3 = MinecraftHelper.mc.field_71439_g.field_71158_b.field_192832_b;
        float f4 = MinecraftHelper.mc.field_71439_g.field_71158_b.field_78902_a;
        if (f3 != 0.0f) {
            if (f4 > 0.0f) {
                f2 += (float)(f3 > 0.0f ? -45 : 45);
            } else if (f4 < 0.0f) {
                f2 += (float)(f3 > 0.0f ? 45 : -45);
            }
            f4 = 0.0f;
            if (f3 > 0.0f) {
                f3 = 1.0f;
            } else if (f3 < 0.0f) {
                f3 = -1.0f;
            }
        }
        MinecraftHelper.mc.field_71439_g.field_70159_w = (double)(f3 * f) * Math.cos(Math.toRadians(f2 + 90.0f)) + (double)(f4 * f) * Math.sin(Math.toRadians(f2 + 90.0f));
        MinecraftHelper.mc.field_71439_g.field_70179_y = (double)(f3 * f) * Math.sin(Math.toRadians(f2 + 90.0f)) - (double)(f4 * f) * Math.cos(Math.toRadians(f2 + 90.0f));
    }

    public static float getBaseMoveSpeed() {
        float f = 0.2873f;
        if (MinecraftHelper.mc.field_71439_g != null && MinecraftHelper.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            f *= (float)(1.0 + 0.2 * (double)(MinecraftHelper.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c).func_76458_c() + 1));
        }
        return f;
    }

    public static void strafePlayer(float f) {
        double d = MovementHelper.getDirectionAll();
        float f2 = f == 0.0f ? MovementHelper.getSpeed() : f;
        MinecraftHelper.mc.field_71439_g.field_70159_w = -Math.sin(d) * (double)f2;
        MinecraftHelper.mc.field_71439_g.field_70179_y = Math.cos(d) * (double)f2;
    }
}
