package com.Blood.Ware.utils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class MathUtils {
    public static final /* synthetic */ float deg2Rad = (float)Math.PI / 180;
    public static final /* synthetic */ Random random;

    public static double[] directionSpeedNoForward(double d) {
        Minecraft minecraft = Minecraft.func_71410_x();
        float f = 1.0f;
        if (minecraft.field_71474_y.field_74370_x.func_151468_f() || minecraft.field_71474_y.field_74366_z.func_151468_f() || minecraft.field_71474_y.field_74368_y.func_151468_f() || minecraft.field_71474_y.field_74351_w.func_151468_f()) {
            f = minecraft.field_71439_g.field_71158_b.field_192832_b;
        }
        float f2 = minecraft.field_71439_g.field_71158_b.field_78902_a;
        float f3 = minecraft.field_71439_g.field_70126_B + (minecraft.field_71439_g.field_70177_z - minecraft.field_71439_g.field_70126_B) * minecraft.func_184121_ak();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        return new double[]{(double)f * d * d3 + (double)f2 * d * d2, (double)f * d * d2 - (double)f2 * d * d3};
    }

    public static boolean isInteger(Double d) {
        return d == Math.floor(d) && !Double.isInfinite(d);
    }

    public static double roundToPlace(double d, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(d).setScale(n, RoundingMode.HALF_UP).doubleValue();
    }

    public static double[] directionSpeed(double d) {
        Minecraft minecraft = Minecraft.func_71410_x();
        float f = minecraft.field_71439_g.field_71158_b.field_192832_b;
        float f2 = minecraft.field_71439_g.field_71158_b.field_78902_a;
        float f3 = minecraft.field_71439_g.field_70126_B + (minecraft.field_71439_g.field_70177_z - minecraft.field_71439_g.field_70126_B) * minecraft.func_184121_ak();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        return new double[]{(double)f * d * d3 + (double)f2 * d * d2, (double)f * d * d2 - (double)f2 * d * d3};
    }

    public static float lerp(float f, float f2, float f3) {
        return f + f3 * (f2 - f);
    }

    public static void drawUnfilledCircle(float f, float f2, float f3, float f4, int n) {
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        float f8 = (float)(n >> 24 & 0xFF) / 255.0f;
        GL11.glEnable((int)2848);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GlStateManager.func_179147_l();
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f8);
        GL11.glLineWidth((float)f4);
        GL11.glBegin((int)2);
        for (int i = 0; i <= 360; i -= 23117) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            i += 23118;
        }
        GL11.glEnd();
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
        GlStateManager.func_179084_k();
    }

    public static int getRandomInRange(int n, int n2) {
        return (int)((double)n2 + (double)(n - n2) * random.nextDouble());
    }

    public static BigDecimal round(float f, double d) {
        return new BigDecimal(Float.toString(f)).setScale((int)d, 4);
    }

    public static double[] getDirection(float f) {
        return new double[]{-Math.sin(Math.toRadians(f)), Math.cos(Math.toRadians(f))};
    }

    public static double randomize(double d, double d2) {
        double d3;
        double d4 = new Random().nextDouble() * (d2 - d);
        if (d4 > d2) {
            d4 = d2;
        }
        double d5 = d4 + d;
        if (d3 > d2) {
            d5 = d2;
        }
        return d5;
    }

    public static int randomize(int n, int n2) {
        return -n2 + (int)(Math.random() * (double)(n - -n2 + 1));
    }

    public static double random(double d, double d2) {
        return Math.random() * (d2 - d) + d;
    }

    public static float sqrt_double(double d) {
        return (float)Math.sqrt(d);
    }

    public static double roundToDecimalPlace(double d, double d2) {
        double d3 = d2 / 2.0;
        double d4 = Math.floor(d / d2) * d2;
        if (d >= d4 + d3) {
            return new BigDecimal(Math.ceil(d / d2) * d2, MathContext.DECIMAL64).stripTrailingZeros().doubleValue();
        }
        return new BigDecimal(d4, MathContext.DECIMAL64).stripTrailingZeros().doubleValue();
    }

    public static float clamp(float f, float f2, float f3) {
        if (f <= f2) {
            f = f2;
        }
        if (f >= f3) {
            f = f3;
        }
        return f;
    }

    public static double degToRad(double d) {
        return d * 0.01745329238474369;
    }

    public static Vec3d interpolateVec3d(Vec3d vec3d, Vec3d vec3d2, float f) {
        return vec3d.func_178788_d(vec3d2).func_186678_a((double)f).func_178787_e(vec3d2);
    }

    public static double preciseRound(double d, double d2) {
        double d3 = Math.pow(10.0, d2);
        return (double)Math.round(d * d3) / d3;
    }

    public static Vec3d direction(float f) {
        return new Vec3d(Math.cos(MathUtils.degToRad(f + 90.0f)), 0.0, Math.sin(MathUtils.degToRad(f + 90.0f)));
    }

    public static double randomNumber(double d, double d2) {
        return Math.random() * (d - d2) + d2;
    }

    public static float getRandomInRange(float f, float f2) {
        return (float)((double)f2 + (double)(f - f2) * random.nextDouble());
    }

    public static double getNormalDouble(double d) {
        return new BigDecimal(d).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
    }

    public static double getNormalDouble(double d, int n) {
        return new BigDecimal(d).setScale(n, RoundingMode.HALF_EVEN).doubleValue();
    }

    public static boolean isEven(int n) {
        return n % 2 == 0;
    }

    public static float wrapAngleTo180_float(float f) {
        if ((f %= 360.0f) >= 180.0f) {
            f -= 360.0f;
        }
        if (f < -180.0f) {
            f += 360.0f;
        }
        return f;
    }

    public static float random(float f, float f2) {
        return (float)(Math.random() * (double)(f2 - f) + (double)f);
    }

    public static Vec3d interpolateEntity(Entity entity) {
        double d = Minecraft.func_71410_x().func_184121_ak();
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * d, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * d, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * d);
    }

    public static float[] constrainAngle(float[] fArray) {
        fArray[0] = fArray[0] % 360.0f;
        fArray[1] = fArray[1] % 360.0f;
        while (fArray[0] <= -180.0f) {
            fArray[0] = fArray[0] + 360.0f;
        }
        while (fArray[1] <= -180.0f) {
            fArray[1] = fArray[1] + 360.0f;
        }
        while (fArray[0] > 180.0f) {
            fArray[0] = fArray[0] - 360.0f;
        }
        while (fArray[1] > 180.0f) {
            fArray[1] = fArray[1] - 360.0f;
        }
        return fArray;
    }

    public static double getIncremental(double d, double d2) {
        double d3 = 1.0 / d2;
        return (double)Math.round(d * d3) / d3;
    }

    static {
        random = new Random();
    }
}
