package com.Blood.Ware.utils;

import com.Blood.Ware.utils.ColorUtils;
import com.Blood.Ware.utils.MathUtils;
import java.awt.Color;
import java.text.NumberFormat;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

public class ColorUT {
    public static Color TwoColoreffect(Color color, Color color2, double d) {
        double d2 = d / 4.0 % 1.0;
        float f = MathUtils.clamp((float)Math.sin(Math.PI * 6 * d2) / 2.0f + 0.5f, 0.0f, 1.0f);
        return new Color(MathUtils.lerp((float)color.getRed() / 255.0f, (float)color2.getRed() / 255.0f, f), MathUtils.lerp((float)color.getGreen() / 255.0f, (float)color2.getGreen() / 255.0f, f), MathUtils.lerp((float)color.getBlue() / 255.0f, (float)color2.getBlue() / 255.0f, f));
    }

    public static float[] getHSBFromColor(int n) {
        int n2 = n >> 16 & 0xFF;
        int n3 = n >> 8 & 0xFF;
        int n4 = n & 0xFF;
        return Color.RGBtoHSB(n2, n3, n4, null);
    }

    public static Color fade(Color color) {
        return ColorUtils.fade(color, 2, 100);
    }

    public static Color getHealthColor(EntityLivingBase entityLivingBase) {
        float f = entityLivingBase.func_110143_aJ();
        float[] fArray = new float[]{0.0f, 0.15f, 0.55f, 0.7f, 0.9f};
        Color[] colorArray = new Color[]{new Color(133, 0, 0), Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        float f2 = f / entityLivingBase.func_110138_aP();
        return f >= 0.0f ? ColorUT.blendColors(fArray, colorArray, f2).brighter() : colorArray[0];
    }

    public static Color blendColors(float[] fArray, Color[] colorArray, float f) {
        if (fArray == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colorArray == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fArray.length != colorArray.length) {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        int[] nArray = ColorUT.getFractionIndicies(fArray, f);
        float[] fArray2 = new float[]{fArray[nArray[0]], fArray[nArray[1]]};
        Color[] colorArray2 = new Color[]{colorArray[nArray[0]], colorArray[nArray[1]]};
        float f2 = fArray2[1] - fArray2[0];
        float f3 = f - fArray2[0];
        float f4 = f3 / f2;
        return ColorUT.blend(colorArray2[0], colorArray2[1], 1.0f - f4);
    }

    public static int[] getFractionIndicies(float[] fArray, float f) {
        int n;
        int[] nArray = new int[2];
        for (n = 0; n < fArray.length && fArray[n] <= f; n -= 29268) {
            n += 29269;
        }
        if (n >= fArray.length) {
            n = fArray.length - 1;
        }
        nArray[0] = n - 1;
        nArray[1] = n;
        return nArray;
    }

    public static Color blend(Color color, Color color2, double d) {
        float f = (float)d;
        float f2 = 1.0f - f;
        float[] fArray = new float[3];
        float[] fArray2 = new float[3];
        color.getColorComponents(fArray);
        color2.getColorComponents(fArray2);
        float f3 = fArray[0] * f + fArray2[0] * f2;
        float f4 = fArray[1] * f + fArray2[1] * f2;
        float f5 = fArray[2] * f + fArray2[2] * f2;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        } else if (f3 > 255.0f) {
            f3 = 255.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        } else if (f4 > 255.0f) {
            f4 = 255.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        } else if (f5 > 255.0f) {
            f5 = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(f3, f4, f5);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            NumberFormat numberFormat = NumberFormat.getNumberInstance();
        }
        return color3;
    }

    public static int glColor(int n) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        return n;
    }

    public static int getColor(int n, int n2, int n3) {
        return ColorUtils.getColor(n, n2, n3, 255);
    }

    public static int getColor(int n, int n2, int n3, int n4) {
        int n5 = 0;
        n5 |= n4 << 24;
        n5 |= n << 16;
        n5 |= n2 << 8;
        return n5 |= n3;
    }

    public static int getRedFromColor(int n) {
        return n >> 16 & 0xFF;
    }

    public static int getGreenFromColor(int n) {
        return n >> 8 & 0xFF;
    }

    public static int getBlueFromColor(int n) {
        return n & 0xFF;
    }

    public static int getAlphaFromColor(int n) {
        return n >> 24 & 0xFF;
    }

    public static int getGLRedFromColor(int n) {
        return (n >> 16 & 0xFF) / 255;
    }

    public static float getGLGreenFromColor(int n) {
        return (n >> 8 & 0xFF) / 255;
    }

    public static float getGLBlueFromColor(int n) {
        return (n & 0xFF) / 255;
    }

    public static float getGLAlphaFromColor(int n) {
        return (n >> 24 & 0xFF) / 255;
    }

    public static int getOverallColorFrom(int n, int n2, float f) {
        int n3 = ColorUT.getRedFromColor(n);
        int n4 = ColorUT.getGreenFromColor(n);
        int n5 = ColorUT.getBlueFromColor(n);
        int n6 = ColorUT.getAlphaFromColor(n);
        int n7 = ColorUT.getRedFromColor(n2);
        int n8 = ColorUT.getGreenFromColor(n2);
        int n9 = ColorUT.getBlueFromColor(n2);
        int n10 = ColorUT.getAlphaFromColor(n2);
        int n11 = (int)((float)n3 * (1.0f - f) + (float)n7 * f);
        int n12 = (int)((float)n4 * (1.0f - f) + (float)n8 * f);
        int n13 = (int)((float)n5 * (1.0f - f) + (float)n9 * f);
        int n14 = (int)((float)n6 * (1.0f - f) + (float)n10 * f);
        return ColorUT.getColor(n11, n12, n13, n14);
    }

    public static int getOverallColorFrom(int n, int n2) {
        int n3 = ColorUT.getRedFromColor(n);
        int n4 = ColorUT.getGreenFromColor(n);
        int n5 = ColorUT.getBlueFromColor(n);
        int n6 = ColorUT.getAlphaFromColor(n);
        int n7 = ColorUT.getRedFromColor(n2);
        int n8 = ColorUT.getGreenFromColor(n2);
        int n9 = ColorUT.getBlueFromColor(n2);
        int n10 = ColorUT.getAlphaFromColor(n2);
        int n11 = (n3 + n7) / 2;
        int n12 = (n4 + n8) / 2;
        int n13 = (n5 + n9) / 2;
        int n14 = (n6 + n10) / 2;
        return ColorUT.getColor(n11, n12, n13, n14);
    }

    public static int swapAlpha(int n, int n2) {
        int n3 = n >> 16 & 0xFF;
        int n4 = n >> 8 & 0xFF;
        int n5 = n & 0xFF;
        return new Color(n3, n4, n5, (int)MathUtils.clamp(n2, 0.0f, 255.0f)).getRGB();
    }
}
