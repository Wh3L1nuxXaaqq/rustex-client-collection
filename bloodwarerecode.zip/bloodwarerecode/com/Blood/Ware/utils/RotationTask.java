package com.Blood.Ware.utils;

import com.Blood.Ware.utils.BasicTask;

public final class RotationTask
extends BasicTask {
    public RotationTask(String string, int n) {
        super(string, n);
    }
}
