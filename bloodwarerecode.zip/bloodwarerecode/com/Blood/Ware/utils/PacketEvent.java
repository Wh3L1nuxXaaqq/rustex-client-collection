package com.Blood.Ware.utils;

import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class PacketEvent
extends Event {
    public static /* synthetic */ Packet<?> packet;

    public PacketEvent(Packet<?> packet) {
        PacketEvent.packet = packet;
    }

    public static Packet getPacket() {
        return packet;
    }

    public final Packet<?> setPacket(Packet<?> packet) {
        PacketEvent.packet = packet;
        return PacketEvent.packet;
    }

    public static class Receive
    extends PacketEvent {
        public Receive(Packet<?> packet) {
            super(packet);
        }
    }

    public static class Send
    extends PacketEvent {
        public Send(Packet<?> packet) {
            super(packet);
        }

        public static class Post
        extends Send {
            public Post(Packet<?> packet) {
                super(packet);
            }
        }
    }
}
