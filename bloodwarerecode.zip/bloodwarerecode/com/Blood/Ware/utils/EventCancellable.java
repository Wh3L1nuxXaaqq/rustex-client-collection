package com.Blood.Ware.utils;

import akka.actor.Cancellable;
import com.Blood.Ware.events.event.Event;

public abstract class EventCancellable
extends Event
implements Cancellable {
    public /* synthetic */ boolean cancelled;
    public /* synthetic */ boolean canceled;

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCanceled(boolean bl) {
        this.canceled = bl;
    }

    @Override
    public void setCancelled(boolean bl) {
        this.cancelled = bl;
    }
}
