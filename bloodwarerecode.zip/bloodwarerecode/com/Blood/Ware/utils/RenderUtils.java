package com.Blood.Ware.utils;

import com.Blood.Ware.utils.ColorUT;
import com.Blood.Ware.utils.ColorUtils;
import com.Blood.Ware.utils.MinecraftHelper;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.Wrapper;
import com.Blood.Ware.utils.search.Blockinfo;
import com.Blood.Ware.utils.util.ColorHelper;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class RenderUtils {
    public static final /* synthetic */ Frustum frustrum;
    public static /* synthetic */ boolean click;
    public /* synthetic */ float spin;
    public /* synthetic */ float cumSize;
    public static final /* synthetic */ int GL_BLEND;
    public static final /* synthetic */ int GL_DEPTH_TEST;

    public static ResourceLocation drawPic(double d, double d2, double d3, double d4, ResourceLocation resourceLocation) {
        GlStateManager.func_179141_d();
        GlStateManager.func_179140_f();
        GlStateManager.func_179106_n();
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        bufferBuilder.func_181662_b(d, d2 + d4, 0.0).func_187315_a(0.0, 1.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        bufferBuilder.func_181662_b(d + d3, d2 + d4, 0.0).func_187315_a(1.0, 1.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        bufferBuilder.func_181662_b(d + d3, d2, 0.0).func_187315_a(1.0, 0.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, 0.0).func_187315_a(0.0, 0.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179118_c();
        return resourceLocation;
    }

    public static void drawThemeRect1(float f, float f2, float f3, float f4) {
        int n = new Color(255, 255, 255, 255).getRGB();
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(f, f2, f3, f4, 5.0f, 3.0f, n, n, n, n, false, true, true);
    }

    public static void drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4, boolean bl, boolean bl2, boolean bl3) {
        if (bl3) {
            RenderUtils.drawRoundedFullGradientShadow(f, f2, f3, f4, f5, f6, n, n2, n3, n4, bl);
        }
        if (bl2) {
            RenderUtils.drawRoundedFullGradientRectPro(f, f2, f3, f4, f5 * 2.0f, n, n2, n3, n4, bl);
        }
    }

    public static void drawRoundedFullGradientRectPro(float f, float f2, float f3, float f4, float f5, int n, int n2, int n3, int n4, boolean bl) {
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        RenderUtils.drawFullGradientRectPro(f + f5 / 2.0f, f2 + f5 / 2.0f, f3 - f5 / 2.0f, f4 - f5 / 2.0f, n4, n3, n2, n, bl);
        RenderUtils.drawPolygonParts(f + f5 / 2.0f, f2 + f5 / 2.0f, f5 / 2.0f, 0, n, n, bl);
        RenderUtils.drawPolygonParts(f + f5 / 2.0f, f4 - f5 / 2.0f, f5 / 2.0f, 5, n4, n4, bl);
        RenderUtils.drawPolygonParts(f3 - f5 / 2.0f, f2 + f5 / 2.0f, f5 / 2.0f, 7, n2, n2, bl);
        RenderUtils.drawPolygonParts(f3 - f5 / 2.0f, f4 - f5 / 2.0f, f5 / 2.0f, 6, n3, n3, bl);
        RenderUtils.drawBloomedFullGradientRect(f, f2 + f5 / 2.0f, f + f5 / 2.0f, f4 - f5 / 2.0f, n4, n4, n, n, bl);
        RenderUtils.drawBloomedFullGradientRect(f + f5 / 2.0f, f2, f3 - f5 / 2.0f, f2 + f5 / 2.0f, n, n2, n2, n, bl);
        RenderUtils.drawBloomedFullGradientRect(f3 - f5 / 2.0f, f2 + f5 / 2.0f, f3, f4 - f5 / 2.0f, n3, n3, n2, n2, bl);
        RenderUtils.drawBloomedFullGradientRect(f + f5 / 2.0f, f4 - f5 / 2.0f, f3 - f5 / 2.0f, f4, n4, n3, n3, n4, bl);
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
    }

    public static void drawBloomedFullGradientRect(float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, boolean bl) {
        float f5 = f;
        float f6 = f2;
        float f7 = f3 - f;
        float f8 = f4 - f2;
        int n5 = n;
        int n6 = n2;
        int n7 = n3;
        int n8 = n4;
        RenderUtils.drawFullGradientRectPro(f5, f6, f5 + f7, f6 + f8, n, n2, n3, n4, bl);
    }

    public static void drawFullGradientRectPro(float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, boolean bl) {
        GlStateManager.func_179147_l();
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179090_x();
        GL11.glShadeModel((int)7425);
        GL11.glDisable((int)3008);
        GL11.glBegin((int)7);
        ColorUT.glColor(n);
        GL11.glVertex2f((float)f, (float)f4);
        ColorUT.glColor(n2);
        GL11.glVertex2f((float)f3, (float)f4);
        ColorUT.glColor(n3);
        GL11.glVertex2f((float)f3, (float)f2);
        ColorUT.glColor(n4);
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glEnd();
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GL11.glEnable((int)3008);
        GL11.glShadeModel((int)7424);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179117_G();
    }

    public static void drawPolygonParts(double d, double d2, float f, int n, int n2, int n3, boolean bl) {
        float f2 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f3 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f4 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f5 = (float)(n2 & 0xFF) / 255.0f;
        float f6 = (float)(n3 >> 24 & 0xFF) / 255.0f;
        float f7 = (float)(n3 >> 16 & 0xFF) / 255.0f;
        float f8 = (float)(n3 >> 8 & 0xFF) / 255.0f;
        float f9 = (float)(n3 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        } else {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(6, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181666_a(f3, f4, f5, f2).func_181675_d();
        double d3 = Math.PI * 2;
        for (int i = n * 90; i <= n * 90 + 90; i += 3298) {
            double d4 = Math.PI * 2 * (double)i / 360.0 + Math.toRadians(180.0);
            bufferBuilder.func_181662_b(d + Math.sin(d4) * (double)f, d2 + Math.cos(d4) * (double)f, 0.0).func_181666_a(f7, f8, f9, f6).func_181675_d();
            i -= 3297;
        }
        tessellator.func_78381_a();
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawCroneShadow(double d, double d2, int n, int n2, float f, float f2, int n3, int n4, boolean bl) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179103_j((int)7425);
        GL11.glDisable((int)3008);
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ZERO, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE);
        }
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)5);
        for (int i = n; i <= n2; i -= 17604) {
            ColorUT.glColor(n3);
            GL11.glVertex2d((double)(d + Math.sin((double)i * Math.PI / 180.0) * (double)f), (double)(d2 + Math.cos((double)i * Math.PI / 180.0) * (double)f));
            ColorUT.glColor(n4);
            GL11.glVertex2d((double)(d + Math.sin((double)i * Math.PI / 180.0) * (double)(f + f2)), (double)(d2 + Math.cos((double)i * Math.PI / 180.0) * (double)(f + f2)));
            i += 17610;
        }
        GL11.glEnd();
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ZERO, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE);
        }
        GL11.glEnable((int)3008);
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawRoundedFullGradientShadow(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4, boolean bl) {
        f += f5;
        f3 -= f5;
        f2 += f5;
        f4 -= f5;
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        RenderUtils.drawCroneShadow(f, f2, -180, -90, f5, f6, n, bl ? 0 : ColorUT.swapAlpha(n, 0), bl);
        RenderUtils.drawFullGradientRectPro(f, f2 - f5 - f6, f3, f2 - f5, n, n2, bl ? 0 : ColorUT.swapAlpha(n2, 0), bl ? 0 : ColorUT.swapAlpha(n, 0), bl);
        RenderUtils.drawCroneShadow(f3, f2, 90, 180, f5, f6, n2, bl ? 0 : ColorUT.swapAlpha(n2, 0), bl);
        RenderUtils.drawFullGradientRectPro(f3 + f5, f2, f3 + f5 + f6, f4, n3, bl ? 0 : ColorUT.swapAlpha(n3, 0), bl ? 0 : ColorUT.swapAlpha(n2, 0), n2, bl);
        RenderUtils.drawCroneShadow(f3, f4, 0, 90, f5, f6, n3, bl ? 0 : ColorUT.swapAlpha(n3, 0), bl);
        RenderUtils.drawFullGradientRectPro(f, f4 + f5, f3, f4 + f5 + f6, bl ? 0 : ColorUT.swapAlpha(n4, 0), bl ? 0 : ColorUT.swapAlpha(n3, 0), n3, n4, bl);
        RenderUtils.drawCroneShadow(f, f4, -90, 0, f5, f6, n4, bl ? 0 : ColorUT.swapAlpha(n4, 0), bl);
        RenderUtils.drawFullGradientRectPro(f - f5 - f6, f2, f - f5, f4, bl ? 0 : ColorUT.swapAlpha(n4, 0), n4, n, bl ? 0 : ColorUT.swapAlpha(n, 0), bl);
        if (bl) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
    }

    public static void drawCircle228(float f, float f2, float f3, int n, int n2) {
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glLineWidth((float)2.5f);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n2; i += 32184) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            i -= 32183;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawRectStatic(int n, int n2, int n3, int n4, Color color) {
        Gui.func_73734_a((int)n, (int)n2, (int)n3, (int)n4, (int)color.getRGB());
    }

    public static void drawSector2(double d, double d2, int n, int n2, int n3) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)6);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)d, (double)d2);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        for (int i = n; i <= n2; i -= 8549) {
            GL11.glVertex2d((double)(d + Math.sin((double)i * Math.PI / 180.0) * (double)n3), (double)(d2 + Math.cos((double)i * Math.PI / 180.0) * (double)n3));
            i += 8550;
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawESP(Entity entity, float f, float f2, float f3, float f4, float f5) {
        try {
            double d = Wrapper.mc.func_175598_ae().field_78730_l;
            double d2 = Wrapper.mc.func_175598_ae().field_78731_m;
            double d3 = Wrapper.mc.func_175598_ae().field_78728_n;
            double d4 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)f5 - d;
            double d5 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)f5 + (double)(entity.field_70131_O / 2.0f) - d2;
            double d6 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)f5 - d3;
            float f6 = Wrapper.mc.func_175598_ae().field_78735_i;
            float f7 = Wrapper.mc.func_175598_ae().field_78732_j;
            boolean bl = Wrapper.mc.func_175598_ae().field_78733_k.field_74320_O == 2;
            GL11.glPushMatrix();
            GlStateManager.func_179137_b((double)d4, (double)d5, (double)d6);
            GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)(-f6), (float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)((float)(bl ? -1 : 1) * f7), (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2896);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glLineWidth((float)1.0f);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)f4);
            GL11.glBegin((int)1);
            GL11.glVertex3d((double)0.0, (double)1.0, (double)0.0);
            GL11.glVertex3d((double)-0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)1.0, (double)0.0);
            GL11.glVertex3d((double)0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
            GL11.glVertex3d((double)-0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
            GL11.glVertex3d((double)0.5, (double)0.5, (double)0.0);
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2896);
            GL11.glDisable((int)2848);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void setColor(Color color) {
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)((float)color.getAlpha() / 255.0f));
    }

    public static void drawRect(double d, double d2, double d3, double d4, int n) {
        double d5;
        if (d < d3) {
            d5 = d;
            d = d3;
            d3 = d5;
        }
        if (d2 < d4) {
            d5 = d2;
            d2 = d4;
            d4 = d5;
        }
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)f2, (float)f3, (float)f4, (float)f);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(d, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d4, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d3, d2, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void customScaledObject2D(float f, float f2, float f3, float f4, float f5, float f6) {
        GL11.glTranslated((double)(f3 / 2.0f), (double)(f4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-f * f5 + f + f3 / 2.0f * -f5), (double)(-f2 * f5 + f2 + f4 / 2.0f * -f5), (double)1.0);
        GL11.glScaled((double)f5, (double)f5, (double)0.0);
    }

    public static void drawDownShadow(float f, float f2, float f3, float f4) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)f3, (double)f4);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        GL11.glVertex2d((double)f3, (double)f2);
        GL11.glVertex2d((double)f, (double)f2);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)f, (double)f4);
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawShadowRect(double d, double d2, double d3, double d4, int n) {
        RenderUtils.drawGradientRect(d, d2 - (double)n, d3, d2, false, true, new Color(0, 0, 0, 150).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawGradientRect(d, d4, d3, d4 + (double)n, false, false, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawSector2(d3, d4, 0, 90, n);
        RenderUtils.drawSector2(d3, d2, 90, 180, n);
        RenderUtils.drawSector2(d, d2, 180, 270, n);
        RenderUtils.drawSector2(d, d4, 270, 360, n);
        RenderUtils.drawGradientRect(d - (double)n, d2, d, d4, true, true, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawGradientRect(d3, d2, d3 + (double)n, d4, true, false, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void drawGradientRect(double d, double d2, double d3, double d4, boolean bl, int n, int n2) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179103_j((int)7425);
        RenderUtils.glColor(n);
        GL11.glBegin((int)7);
        if (bl) {
            GL11.glVertex2d((double)d, (double)d2);
            GL11.glVertex2d((double)d, (double)d4);
            RenderUtils.glColor(n2);
            GL11.glVertex2d((double)d3, (double)d4);
            GL11.glVertex2d((double)d3, (double)d2);
        } else {
            GL11.glVertex2d((double)d, (double)d2);
            RenderUtils.glColor(n2);
            GL11.glVertex2d((double)d, (double)d4);
            GL11.glVertex2d((double)d3, (double)d4);
            RenderUtils.glColor(n);
            GL11.glVertex2d((double)d3, (double)d2);
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void renderItem(ItemStack itemStack, int n, int n2) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179126_j();
        RenderHelper.func_74520_c();
        MinecraftHelper.mc.func_175599_af().field_77023_b = -100.0f;
        MinecraftHelper.mc.func_175599_af().func_180450_b(itemStack, n, n2);
        MinecraftHelper.mc.func_175599_af().func_175030_a(MinecraftHelper.mc.field_71466_p, itemStack, n, n2);
        MinecraftHelper.mc.func_175599_af().field_77023_b = 0.0f;
        RenderHelper.func_74518_a();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.func_179097_i();
    }

    public static void drawRectSized(float f, float f2, float f3, float f4, int n) {
        RenderUtils.drawRect(f, f2, f + f3, f2 + f4, n);
    }

    public static double lerp(double d, double d2, double d3) {
        return (1.0 - d3) * d + d3 * d2;
    }

    public static void draw2DRect(int n, int n2, int n3, int n4, int n5) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b((double)n, (double)(n2 + n4), (double)n5).func_181675_d();
        bufferBuilder.func_181662_b((double)(n + n3), (double)(n2 + n4), (double)n5).func_181675_d();
        bufferBuilder.func_181662_b((double)(n + n3), (double)n2, (double)n5).func_181675_d();
        bufferBuilder.func_181662_b((double)n, (double)n2, (double)n5).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void setupColor(Color color, int n) {
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)((float)n / 255.0f));
    }

    public static void drawSmoothGradientRect(float f, float f2, float f3, float f4, int n, int n2) {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        RenderUtils.drawGradientRect1(f, f2, f3, f4, n, n2);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        RenderUtils.drawGradientRect1(f * 2.0f - 1.0f, f2 * 2.0f, f * 2.0f, f4 * 2.0f - 1.0f, n, n);
        RenderUtils.drawGradientRect1(f * 2.0f, f2 * 2.0f - 1.0f, f3 * 2.0f, f2 * 2.0f, n, n2);
        RenderUtils.drawGradientRect1(f3 * 2.0f, f2 * 2.0f, f3 * 2.0f + 1.0f, f4 * 2.0f - 1.0f, n, n2);
        RenderUtils.drawGradientRect1(f * 2.0f, f4 * 2.0f - 1.0f, f3 * 2.0f, f4 * 2.0f, n, n2);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
    }

    public static void drawGradientRect1(float f, float f2, float f3, float f4, int n, int n2) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float)(n2 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glVertex2d((double)f, (double)f2);
        GL11.glVertex2d((double)f, (double)f4);
        GL11.glColor4f((float)f10, (float)f11, (float)f12, (float)f9);
        GL11.glVertex2d((double)f3, (double)f4);
        GL11.glVertex2d((double)f3, (double)f2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
    }

    public static void drawCastomLitium(int n, int n2, int n3, int n4, int n5, int n6) {
        RenderUtils.drawSmoothGradientRect(n - n5, n2 - n5, n3 + n5, n4 + n5, ColorUtils.getColor(), ColorUtils.getColor2());
        RenderUtil.drawSmoothRect(n - n5, n2 - n5, n3 + n5, n4 + n5, new Color(0x51000000, true).hashCode());
        RenderUtils.drawSmoothGradientRect(n, n2, n3, n4, ColorUtils.getColor(), ColorUtils.getColor2());
        RenderUtil.drawSmoothRect(n + n5, n2 + n5, n3 - n5, n4 - n5, new Color(-771751936, true).hashCode());
    }

    public static void drawRoundedCorner(double d, double d2, double d3, double d4, boolean bl) {
        int n = 10;
        double d5 = 0.1;
        GL11.glBegin((int)3);
        if (bl) {
            GL11.glVertex3d((double)d, (double)d2, (double)0.0);
            for (int i = 0; i <= 10; i -= 12942) {
                double d6 = 1.5707963267948966 * (double)i / 10.0;
                double d7 = 0.1 * Math.cos(d6);
                double d8 = 0.1 * Math.sin(d6);
                GL11.glVertex3d((double)(d - d7), (double)(d3 + 0.1 + d8), (double)0.0);
                i += 12943;
            }
            GL11.glVertex3d((double)d4, (double)d3, (double)0.0);
        } else {
            GL11.glVertex3d((double)d, (double)d2, (double)0.0);
            for (int i = 0; i <= 10; i -= 15066) {
                double d9 = 1.5707963267948966 * (double)i / 10.0;
                double d10 = 0.1 * Math.sin(d9);
                double d11 = 0.1 * Math.cos(d9);
                GL11.glVertex3d((double)(d4 - 0.1 - d10), (double)(d3 + d11), (double)0.0);
                i += 15067;
            }
            GL11.glVertex3d((double)d4, (double)d3, (double)0.0);
        }
        GL11.glEnd();
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4, int n5) {
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.glColor(n5);
        MinecraftHelper.mc.func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GlStateManager.func_179084_k();
        GlStateManager.func_179126_j();
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawGradient(double d, double d2, double d3, double d4, int n, int n2) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        float f5 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n2 & 0xFF) / 255.0f;
        RenderUtil.glRenderStart();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        GL11.glVertex2d((double)d3, (double)d2);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glVertex2d((double)d, (double)d4);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
        GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
        RenderUtil.glRenderStop();
    }

    public static void drawGradientRect(double d, double d2, double d3, double d4, boolean bl, boolean bl2, int n, int n2) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(n);
        if (bl) {
            if (bl2) {
                GL11.glVertex2d((double)d3, (double)d4);
                GL11.glVertex2d((double)d3, (double)d2);
                RenderUtils.glColor(n2);
                GL11.glVertex2d((double)d, (double)d2);
                GL11.glVertex2d((double)d, (double)d4);
            } else {
                GL11.glVertex2d((double)d, (double)d2);
                GL11.glVertex2d((double)d, (double)d4);
                RenderUtils.glColor(n2);
                GL11.glVertex2d((double)d3, (double)d4);
                GL11.glVertex2d((double)d3, (double)d2);
            }
        } else if (bl2) {
            GL11.glVertex2d((double)d3, (double)d4);
            RenderUtils.glColor(n2);
            GL11.glVertex2d((double)d3, (double)d2);
            GL11.glVertex2d((double)d, (double)d2);
            RenderUtils.glColor(n);
            GL11.glVertex2d((double)d, (double)d4);
        } else {
            GL11.glVertex2d((double)d, (double)d2);
            RenderUtils.glColor(n2);
            GL11.glVertex2d((double)d, (double)d4);
            GL11.glVertex2d((double)d3, (double)d4);
            RenderUtils.glColor(n);
            GL11.glVertex2d((double)d3, (double)d2);
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void blockEspFrame(BlockPos blockPos, float f, float f2, float f3) {
        double d = (double)blockPos.func_177958_n() - MinecraftHelper.mc.func_175598_ae().field_78730_l;
        double d2 = (double)blockPos.func_177956_o() - MinecraftHelper.mc.func_175598_ae().field_78731_m;
        double d3 = (double)blockPos.func_177952_p() - MinecraftHelper.mc.func_175598_ae().field_78728_n;
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GlStateManager.func_179131_c((float)f, (float)f2, (float)f3, (float)1.0f);
        RenderUtil.drawSelectionBoundingBox(new AxisAlignedBB(d, d2, d3, d + 1.0, d2 + 1.0, d3 + 1.0));
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    public static void blockEspBox(BlockPos blockPos, double d, double d2, double d3) {
        double d4 = (double)blockPos.func_177958_n() - Minecraft.func_71410_x().func_175598_ae().field_78730_l;
        double d5 = (double)blockPos.func_177956_o() - Minecraft.func_71410_x().func_175598_ae().field_78731_m;
        double d6 = (double)blockPos.func_177952_p() - Minecraft.func_71410_x().func_175598_ae().field_78728_n;
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)0);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)0);
        GL11.glDisable((int)2896);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)0.15f);
        RenderUtil.drawColorBox(new AxisAlignedBB(d4, d5, d6, d4 + 1.0, d5 + 1.0, d6 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)0.15f);
        RenderUtil.drawColorBox(new AxisAlignedBB(d4, d5, d6, d4 + 1.0, d5 + 1.0, d6 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)0);
        GL11.glEnable((int)2896);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)0);
        GL11.glPopMatrix();
    }

    public static void trace(Minecraft minecraft, Entity entity, float f, int n) {
        if (minecraft.func_175598_ae().field_78734_h != null) {
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2896);
            GL11.glLineWidth((float)2.0f);
            GL11.glPushMatrix();
            GL11.glDepthMask((boolean)false);
            GL11.glColor4d((double)0.0, (double)(n == 1 ? 1.0 : 0.0), (double)0.0, (double)1.0);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)3553);
            GL11.glBegin((int)1);
            RenderManager renderManager = minecraft.func_175598_ae();
            Vec3d vec3d = new Vec3d(0.0, 0.0, 1.0).func_178789_a(-((float)Math.toRadians(minecraft.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians(minecraft.field_71439_g.field_70177_z)));
            GL11.glVertex3d((double)vec3d.field_72450_a, (double)((double)minecraft.field_71439_g.func_70047_e() + vec3d.field_72448_b), (double)vec3d.field_72449_c);
            GL11.glVertex3d((double)(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)f - renderManager.field_78730_l), (double)(entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)f - renderManager.field_78731_m + 0.25), (double)(entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)f - renderManager.field_78728_n));
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    public static void trace(Minecraft minecraft, Blockinfo blockinfo) {
        if (minecraft.func_175598_ae().field_78734_h != null) {
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2896);
            GL11.glLineWidth((float)2.0f);
            GL11.glPushMatrix();
            GL11.glDepthMask((boolean)false);
            GL11.glColor4d((double)blockinfo.getR(), (double)blockinfo.getG(), (double)blockinfo.getB(), (double)1.0);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)3553);
            GL11.glBegin((int)1);
            RenderManager renderManager = minecraft.func_175598_ae();
            Vec3d vec3d = new Vec3d(0.0, 0.0, 1.0).func_178789_a(-((float)Math.toRadians(minecraft.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians(minecraft.field_71439_g.field_70177_z)));
            GL11.glVertex3d((double)vec3d.field_72450_a, (double)((double)minecraft.field_71439_g.func_70047_e() + vec3d.field_72448_b), (double)vec3d.field_72449_c);
            GL11.glVertex3d((double)((double)blockinfo.getX() - renderManager.field_78730_l), (double)((double)blockinfo.getY() - renderManager.field_78731_m), (double)((double)blockinfo.getZ() - renderManager.field_78728_n));
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    public static void glColor(int n) {
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)((float)(n >> 24 & 0xFF) / 255.0f));
    }

    public static void drawBorderedRect(double d, double d2, double d3, double d4, float f, int n, int n2) {
        RenderUtils.drawRect((float)d, (float)d2, (float)d3, (float)d4, n2);
        float f2 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f4 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f5 = (float)(n & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)f3, (float)f4, (float)f5, (float)f2);
        GL11.glLineWidth((float)f);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d, (double)d4);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glVertex2d((double)d3, (double)d2);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d3, (double)d2);
        GL11.glVertex2d((double)d, (double)d4);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawEntityOnScreen(float f, float f2, float f3, EntityLivingBase entityLivingBase) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179142_g();
        GlStateManager.func_179109_b((float)f, (float)f2, (float)50.0f);
        GlStateManager.func_179152_a((float)(-f3), (float)f3, (float)f3);
        GlStateManager.func_179114_b((float)180.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GlStateManager.func_179114_b((float)135.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        RenderHelper.func_74519_b();
        GlStateManager.func_179114_b((float)-135.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)(-((float)Math.atan(entityLivingBase.field_70125_A / 40.0f)) * 20.0f), (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.func_179109_b((float)0.0f, (float)0.0f, (float)0.0f);
        RenderManager renderManager = Minecraft.func_71410_x().func_175598_ae();
        renderManager.func_178631_a(180.0f);
        renderManager.func_178633_a(false);
        renderManager.func_188391_a((Entity)entityLivingBase, 0.0, 0.0, 0.0, entityLivingBase.field_70177_z, 1.0f, false);
        renderManager.func_178633_a(true);
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77476_b);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GlStateManager.func_179097_i();
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77478_a);
        GlStateManager.func_179121_F();
    }

    public static void putVertex3d(Vec3d vec3d) {
        GL11.glVertex3d((double)vec3d.field_72450_a, (double)vec3d.field_72448_b, (double)vec3d.field_72449_c);
    }

    public static void drawRect(float f, float f2, float f3, float f4, int n) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glBegin((int)7);
        GL11.glVertex2d((double)f3, (double)f2);
        GL11.glVertex2d((double)f, (double)f2);
        GL11.glVertex2d((double)f, (double)f4);
        GL11.glVertex2d((double)f3, (double)f4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawRectWithGlow(double d, double d2, double d3, double d4, double d5, double d6, Color color) {
        RenderUtils.drawRoundedRect99(d, d2, d3, d4, color.getRGB());
        float f = 2.0f;
        while ((double)f < d5) {
            RenderUtils.drawRoundedRect99(d - (d5 - (double)f), d2 - (d5 - (double)f), d3 + (d5 - (double)f), d4 + (d5 - (double)f), ColorHelper.injectAlpha(color, (int)Math.round((double)f * d6)).getRGB());
            f += 0.5f;
        }
    }

    public static void drawRoundedRect(float f, float f2, float f3, float f4, int n, Color color) {
        Gui.func_73734_a((int)((int)f + n), (int)((int)f2), (int)((int)f3 - n), (int)((int)f4), (int)color.getRGB());
        Gui.func_73734_a((int)((int)f), (int)((int)f2 + n), (int)((int)f3), (int)((int)f4 - n), (int)color.getRGB());
        RenderUtil.drawFilledCircle((int)f + n, (int)f2 + n, n, color);
        RenderUtil.drawFilledCircle((int)f3 - n, (int)f2 + n, n, color);
        RenderUtil.drawFilledCircle((int)f3 - n, (int)f4 - n, n, color);
        RenderUtil.drawFilledCircle((int)f + n, (int)f4 - n, n, color);
    }

    public static void drawRoundedRect99(double d, double d2, double d3, double d4, int n) {
        Gui.func_73734_a((int)((int)(d + 0.5)), (int)((int)d2), (int)((int)(d3 - 0.5)), (int)((int)(d2 + 0.5)), (int)n);
        Gui.func_73734_a((int)((int)(d + 0.5)), (int)((int)(d4 - 0.5)), (int)((int)(d3 - 0.5)), (int)((int)d4), (int)n);
        Gui.func_73734_a((int)((int)d), (int)((int)(d2 + 0.5)), (int)((int)d3), (int)((int)(d4 - 0.5)), (int)n);
    }

    public static void drawUpShadow(float f, float f2, float f3, float f4) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)f, (double)f2);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        GL11.glVertex2d((double)f, (double)f4);
        GL11.glVertex2d((double)f3, (double)f4);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)f3, (double)f2);
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void enableSmoothLine(float f) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)f);
    }

    public static void FillLine(Entity entity, AxisAlignedBB axisAlignedBB) {
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB, (float)0.0f, (float)1.0f, (float)0.0f, (float)0.3f);
        RenderGlobal.func_189697_a((AxisAlignedBB)axisAlignedBB, (float)0.0f, (float)1.0f, (float)0.0f, (float)0.8f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    public static void glColor(Color color, float f) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)f);
    }

    public static void scissorRect(float f, float f2, float f3, double d) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        int n = scaledResolution.func_78325_e();
        GL11.glScissor((int)((int)(f * (float)n)), (int)((int)(((double)scaledResolution.func_78328_b() - d) * (double)n)), (int)((int)((f3 - f) * (float)n)), (int)((int)((d - (double)f2) * (double)n)));
    }

    public static Vec3d getRenderPos(double d, double d2, double d3) {
        return new Vec3d(d -= MinecraftHelper.mc.func_175598_ae().field_78730_l, d2 -= MinecraftHelper.mc.func_175598_ae().field_78731_m, d3 -= MinecraftHelper.mc.func_175598_ae().field_78728_n);
    }

    public static void renderEntity(EntityLivingBase entityLivingBase, int n, int n2, int n3) {
        GlStateManager.func_179098_w();
        GlStateManager.func_179132_a((boolean)true);
        GL11.glPushAttrib((int)524288);
        GL11.glDisable((int)3089);
        GlStateManager.func_179086_m((int)256);
        GL11.glPopAttrib();
        GlStateManager.func_179126_j();
        GlStateManager.func_179118_c();
        GlStateManager.func_179094_E();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GuiInventory.func_147046_a((int)n2, (int)n3, (int)n, (float)1.0f, (float)1.0f, (EntityLivingBase)entityLivingBase);
        GlStateManager.func_179121_F();
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a((boolean)false);
    }

    public static void drawEntityESP(Entity entity, Color color) {
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)0);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)0);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)0.15f);
        RenderManager renderManager = Minecraft.func_71410_x().func_175598_ae();
        RenderUtil.drawColorBox(new AxisAlignedBB(-0.05 - entity.field_70165_t + (entity.field_70165_t - renderManager.field_78730_l), -entity.field_70163_u + (entity.field_70163_u - renderManager.field_78731_m), -0.05 - entity.field_70161_v + (entity.field_70161_v - renderManager.field_78728_n), 0.05 - entity.field_70165_t + (entity.field_70165_t - renderManager.field_78730_l), 0.1 - entity.field_70163_u + (entity.field_70163_u - renderManager.field_78731_m), 0.05 - entity.field_70161_v + (entity.field_70161_v - renderManager.field_78728_n)), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glColor4d((double)0.0, (double)0.0, (double)0.0, (double)0.5);
        RenderUtil.drawSelectionBoundingBox(new AxisAlignedBB(-0.05 - entity.field_70165_t + (entity.field_70165_t - renderManager.field_78730_l), -entity.field_70163_u + (entity.field_70163_u - renderManager.field_78731_m), -0.05 - entity.field_70161_v + (entity.field_70161_v - renderManager.field_78728_n), 0.05 - entity.field_70165_t + (entity.field_70165_t - renderManager.field_78730_l), 0.1 - entity.field_70163_u + (entity.field_70163_u - renderManager.field_78731_m), 0.05 - entity.field_70161_v + (entity.field_70161_v - renderManager.field_78728_n)));
        GL11.glLineWidth((float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)0);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)0);
        GL11.glPopMatrix();
    }

    public static void drawboxESP5(BlockPos blockPos, Color color) {
        double d = blockPos.func_177958_n();
        double d2 = Wrapper.mc.func_175598_ae().field_78730_l;
        double d3 = Wrapper.mc.func_175598_ae().field_78731_m;
        double d4 = Wrapper.mc.func_175598_ae().field_78728_n;
        Minecraft.func_71410_x().func_175598_ae();
        double d5 = d - d2;
        double d6 = blockPos.func_177956_o();
        Minecraft.func_71410_x().func_175598_ae();
        double d7 = d6 - d3;
        double d8 = blockPos.func_177952_p();
        Minecraft.func_71410_x().func_175598_ae();
        double d9 = d8 - d4;
        GL11.glBlendFunc((int)770, (int)771);
        Tessellator.func_178181_a().func_178180_c();
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)0.25);
        Minecraft.func_71410_x().func_175598_ae();
        RenderUtil.drawColorBox(new AxisAlignedBB(d5, d7, d9, d5 + 1.0, d7 + 1.0, d9 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glColor4d((double)0.4f, (double)0.6f, (double)1.0, (double)1.0);
        GL11.glLineWidth((float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void customScaledObject2D(float f, float f2, float f3, float f4, float f5) {
        GL11.glTranslated((double)(f3 / 2.0f), (double)(f4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-f * f5 + f + f3 / 2.0f * -f5), (double)(-f2 * f5 + f2 + f4 / 2.0f * -f5), (double)1.0);
        GL11.glScaled((double)f5, (double)f5, (double)0.0);
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4) {
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GL11.glPopMatrix();
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawImage(ResourceLocation resourceLocation, float f, float f2, float f3, float f4, Color color) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.setColor(color.getRGB());
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)((int)f), (int)((int)f2), (float)0.0f, (float)0.0f, (int)((int)f3), (int)((int)f4), (float)f3, (float)f4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static void setColor(int n) {
        GL11.glColor4ub((byte)((byte)(n >> 16 & 0xFF)), (byte)((byte)(n >> 8 & 0xFF)), (byte)((byte)(n & 0xFF)), (byte)((byte)(n >> 24 & 0xFF)));
    }

    public static void drawImage(ResourceLocation resourceLocation, float f, float f2, float f3, float f4) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)0.6f, (float)0.6f, (float)0.6f, (float)1.0f);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)((int)f), (int)((int)f2), (float)0.0f, (float)0.0f, (int)((int)f3), (int)((int)f4), (float)f3, (float)f4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GlStateManager.func_179117_G();
    }

    public static void drawCircle(float f, float f2, float f3, float f4, float f5, boolean bl, Color color) {
        float f6;
        float f7;
        float f8;
        GlStateManager.func_179131_c((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        if (f3 > f4) {
            float f9 = f4;
            f4 = f3;
            f3 = f9;
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.setColor(color.getRGB());
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)2.0f);
        GL11.glBegin((int)3);
        for (f8 = f4; f8 >= f3; f8 -= 4.0f) {
            f7 = (float)(Math.cos((double)f8 * Math.PI / 180.0) * (double)f5 * 1.0);
            f6 = (float)(Math.sin((double)f8 * Math.PI / 180.0) * (double)f5 * 1.0);
            GL11.glVertex2f((float)(f + f7), (float)(f2 + f6));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)(bl ? 6 : 3));
        for (f8 = f4; f8 >= f3; f8 -= 4.0f) {
            f7 = (float)Math.cos((double)f8 * Math.PI / 180.0) * f5;
            f6 = (float)Math.sin((double)f8 * Math.PI / 180.0) * f5;
            GL11.glVertex2f((float)(f + f7), (float)(f2 + f6));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void drawGlow(double d, double d2, double d3, double d4, int n) {
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        RenderUtil.drawVGradientRect((int)d, (int)d2, (int)d3, (int)(d2 + (d4 - d2) / 2.0), ColorHelper.injectAlpha(new Color(n), 0).getRGB(), n);
        RenderUtil.drawVGradientRect((int)d, (int)(d2 + (d4 - d2) / 2.0), (int)d3, (int)d4, n, ColorHelper.injectAlpha(new Color(n), 0).getRGB());
        int n2 = (int)((d4 - d2) / 2.0);
        RenderUtil.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 0, n, ColorHelper.injectAlpha(new Color(n), 0).getRGB());
        RenderUtil.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 1, n, ColorHelper.injectAlpha(new Color(n), 0).getRGB());
        RenderUtil.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 2, n, ColorHelper.injectAlpha(new Color(n), 0).getRGB());
        RenderUtil.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 3, n, ColorHelper.injectAlpha(new Color(n), 0).getRGB());
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawVerticalGradientSmoothRect(float f, float f2, float f3, float f4, int n, int n2) {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        RenderUtils.drawGradientRect((int)f, (int)f2, (int)f3, (int)f4, n, n2);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        RenderUtils.drawGradientRect((int)(f * 2.0f - 1.0f), (int)(f2 * 2.0f), (int)(f * 2.0f), (int)(f4 * 2.0f - 1.0f), n, n2);
        RenderUtils.drawGradientRect((int)(f * 2.0f), (int)(f2 * 2.0f - 1.0f), (int)(f3 * 2.0f), (int)(f2 * 2.0f), n, n2);
        RenderUtils.drawGradientRect((int)(f3 * 2.0f), (int)(f2 * 2.0f), (int)(f3 * 2.0f + 1.0f), (int)(f4 * 2.0f - 1.0f), n, n2);
        RenderUtils.drawGradientRect((int)(f * 2.0f), (int)(f4 * 2.0f - 1.0f), (int)(f3 * 2.0f), (int)(f4 * 2.0f), n, n2);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
    }

    public static void glColor(Color color) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
    }

    public static void drawGradientRect(int n, int n2, int n3, int n4, int n5, int n6) {
    }

    static {
        GL_BLEND = 0;
        GL_DEPTH_TEST = 0;
        frustrum = new Frustum();
    }
}
