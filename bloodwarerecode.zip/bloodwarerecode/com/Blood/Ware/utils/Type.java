package com.Blood.Ware.utils;

public enum Type {
    HARP,
    SIMPLE;

}
