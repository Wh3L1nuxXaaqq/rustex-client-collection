package com.Blood.Ware.utils;

import com.Blood.Ware.utils.Mc;
import com.Blood.Ware.utils.MinecraftHelper;

public class NullCheck
implements Mc {
    public static boolean nullCheck() {
        return MinecraftHelper.mc.field_71439_g == null || MinecraftHelper.mc.field_71441_e == null;
    }
}
