package com.Blood.Ware.utils;

import java.util.Random;

public class GenerateNumber {
    public static final /* synthetic */ Random random;

    public static int generateInt(int n, int n2) {
        return random.nextInt(n2 - n + 1) + n;
    }

    public static float generateFloat(float f, float f2) {
        return (float)Math.min((double)f2, Math.random() * ((double)f2 * 1.1 - (double)f) + (double)f);
    }

    static {
        random = new Random();
    }
}
