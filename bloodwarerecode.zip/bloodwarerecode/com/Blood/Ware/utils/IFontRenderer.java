package com.Blood.Ware.utils;

public interface IFontRenderer {
    public int drawString(String var1, float var2, float var3, int var4);

    public int drawStringWithShadow(String var1, float var2, float var3, int var4);

    public int drawCenteredString(String var1, float var2, float var3, int var4);

    public float getStringWidth(String var1);

    public int getFontHeight();

    public float getStringHeight(String var1);
}
