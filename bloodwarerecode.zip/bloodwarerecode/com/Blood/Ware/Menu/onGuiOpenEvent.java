package com.Blood.Ware.Menu;

import com.Blood.Ware.Menu.BloodWare1;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class onGuiOpenEvent {
    @SideOnly(value=Side.CLIENT)
    @SubscribeEvent
    public void onGuiOpenEvent(GuiOpenEvent guiOpenEvent) {
        if (guiOpenEvent.getGui() instanceof GuiMainMenu) {
            guiOpenEvent.setGui((GuiScreen)new BloodWare1());
        }
    }
}
