package com.Blood.Ware.Menu;

import Caesium.SnowRenderer;
import com.Blood.Ware.Menu.Tools.changeUser;
import java.io.IOException;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;

public class BloodWare1
extends GuiScreen {
    public /* synthetic */ SnowRenderer snowRenderer;

    public BloodWare1() {
        this.snowRenderer = new SnowRenderer();
    }

    public void func_73866_w_() {
        int n = this.field_146295_m / 4 + 48;
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiButton(0, this.field_146294_l / 2 - 100, n + 72 + 12, 98, 20, "Options"));
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l / 2 + 2, n + 72 + 12, 98, 20, "Quit"));
        this.field_146292_n.add(new GuiButton(2, this.field_146294_l / 2 + -100, n + 72 - 12, 200, 20, "Change User"));
        this.field_146292_n.add(new GuiButton(4, this.field_146294_l / 2 - 100, n + 72 - 34, 200, 20, "Multiplayer"));
        this.field_146292_n.add(new GuiButton(5, this.field_146294_l / 2 - 100, n + 72 - 58, 200, 20, "Singleplayer"));
    }

    public void func_146284_a(GuiButton guiButton) throws IOException {
        if (guiButton.field_146127_k == 0) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiOptions((GuiScreen)this, this.field_146297_k.field_71474_y));
        }
        if (guiButton.field_146127_k == 1) {
            this.field_146297_k.func_71400_g();
        }
        if (guiButton.field_146127_k == 2) {
            this.field_146297_k.func_147108_a((GuiScreen)new changeUser());
        }
        if (guiButton.field_146127_k == 4) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayer((GuiScreen)this));
        }
        if (guiButton.field_146127_k == 5) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiWorldSelection((GuiScreen)this));
        }
        super.func_146284_a(guiButton);
    }

    public void func_73863_a(int n, int n2, float f) {
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.func_146276_q_();
        Gui.func_152125_a((int)0, (int)0, (float)0.0f, (float)0.0f, (int)this.field_146294_l, (int)this.field_146295_m, (int)this.field_146294_l, (int)this.field_146295_m, (float)this.field_146294_l, (float)this.field_146295_m);
        for (GuiButton guiButton : this.field_146292_n) {
            guiButton.func_191745_a(this.field_146297_k, n, n2, f);
        }
        super.func_73863_a(n, n2, f);
    }
}
