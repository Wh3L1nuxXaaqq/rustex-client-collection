package com.Blood.Ware.Menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class drawLogo {
    public static void drawString(double d, String string, float f, float f2, int n) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179139_a((double)d, (double)d, (double)d);
        Minecraft.func_71410_x().field_71466_p.func_175063_a(string, f, f2, n);
        GlStateManager.func_179121_F();
    }
}
