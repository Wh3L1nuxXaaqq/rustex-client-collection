package com.Blood.Ware.Menu.Tools;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.Menu.BloodWare1;
import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.awt.Color;
import java.io.IOException;
import java.net.Proxy;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.Session;
import org.lwjgl.opengl.GL11;

public class changeUser
extends GuiScreen {
    public /* synthetic */ GuiTextField inputField;

    public void func_73866_w_() {
        int n = this.field_146295_m / 4 + 48;
        this.field_146292_n.clear();
        this.inputField = new GuiTextField(1, this.field_146289_q, this.field_146294_l / 2 - 100, n + 72 - 12, 200, 20);
        this.inputField.func_146180_a("");
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l / 2 - 100, n + 72 + 12, 200, 20, "Login"));
    }

    public static void changeName(String string) {
        YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
        YggdrasilUserAuthentication yggdrasilUserAuthentication = (YggdrasilUserAuthentication)yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT);
        yggdrasilUserAuthentication.logOut();
        Session session = new Session(string, string, "0", "legacy");
        try {
            BloodWare.setSession(session);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void func_146284_a(GuiButton guiButton) throws IOException {
        if (guiButton.field_146127_k == 1) {
            changeUser.changeName(this.inputField.func_146179_b());
        }
    }

    public void func_73876_c() {
        this.inputField.func_146178_a();
    }

    public void func_73869_a(char c, int n) throws IOException {
        switch (n) {
            case 1: {
                this.field_146297_k.func_147108_a((GuiScreen)new BloodWare1());
                break;
            }
            default: {
                this.inputField.func_146201_a(c, n);
            }
        }
    }

    public void func_73864_a(int n, int n2, int n3) throws IOException {
        this.inputField.func_146192_a(n, n2, n3);
        super.func_73864_a(n, n2, n3);
    }

    public void func_73863_a(int n, int n2, float f) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.func_146276_q_();
        for (int i = 0; i < this.field_146292_n.size(); i += 29826) {
            ((GuiButton)this.field_146292_n.get(i)).func_191745_a(this.field_146297_k, n, n2, f);
            i -= 29825;
        }
        this.inputField.func_146194_f();
        this.field_146297_k.field_71466_p.func_175063_a("Your Username: " + this.field_146297_k.func_110432_I().func_111285_a(), (float)(this.field_146294_l / 2 - 100), (float)(this.field_146295_m / 4 + 48 + 110), Color.yellow.getRGB());
    }
}
