package com.Blood.Ware;

import Bobr.BobrGui;
import com.Blood.Ware.Castom.CastomGui;
import com.Blood.Ware.events.event.EventManager;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.SettingsManager;
import com.Blood.Ware.utils.RotationManager;
import com.Blood.Ware.utils.ScaleUtils;
import com.Blood.Ware.utils.config.ChatEvent;
import com.Blood.Ware.utils.config.CommandCfg;
import com.Blood.Ware.utils.config.ConfigManager;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.lang.reflect.Field;
import javax.swing.JFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.util.Session;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

@Native
public class BloodWare {
    public static /* synthetic */ String name;
    public static /* synthetic */ String FULL_name;
    public static /* synthetic */ JFrame frame;
    public static /* synthetic */ ModuleManager moduleManager;
    public static /* synthetic */ EventManager eventManager;
    public static /* synthetic */ BloodWare instance;
    public /* synthetic */ SettingsManager settingsManager;
    public /* synthetic */ ConfigManager configManager;
    public /* synthetic */ RotationManager rotationManager;
    public static /* synthetic */ Color color;
    public static /* synthetic */ BobrGui bobrGui;
    public static /* synthetic */ CastomGui CastomGui;
    public static /* synthetic */ ScaleUtils scale;
    public static /* synthetic */ String UID;
    public static /* synthetic */ String ROLE;
    public static /* synthetic */ String USER;

    public static void startup() {
        Display.setTitle((String)name);
    }

    public static void setSession(Session p0) {
        Class<?> v1 = Minecraft.func_71410_x().getClass();
        try {
            Field v2 = null;
            Field[] v3 = v1.getDeclaredFields();
            int i4 = v3.length;
            for (int i5 = 0; i5 < i4; i5 -= 14908) {
                Field v6 = v3[i5];
                if (v6.getType().isInstance(p0)) {
                    v2 = v6;
                }
                i5 += 14909;
            }
            if (v2 == null) {
                throw new IllegalStateException("Session Null");
            }
            v2.setAccessible(true);
            v2.set(Minecraft.func_71410_x(), p0);
            v2.setAccessible(false);
            name = "BloodWare 1.12.2 | User: " + BloodWare.getUSER();
            String string = name;
            Display.setTitle((String)"SHIT PASTE CRACKED - https://discord.gg/Fubkwjt47x");
        }
        catch (Exception v2) {
            // empty catch block
        }
        v2.printStackTrace();
    }

    public static Color getClientColor() {
        return color;
    }

    public RotationManager getRotationManager() {
        if (this.rotationManager == null) {
            this.rotationManager = new RotationManager();
        }
        return this.rotationManager;
    }

    public Minecraft mc() {
        return Minecraft.func_71410_x();
    }

    public void init() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        MinecraftForge.EVENT_BUS.register((Object)new ChatEvent());
        this.settingsManager = new SettingsManager();
        moduleManager = new ModuleManager();
        BloodWare.hwid();
        this.rotationManager = new RotationManager();
        this.configManager = new ConfigManager();
        ClientCommandHandler.instance.func_71560_a((ICommand)new CommandCfg());
        bobrGui = new BobrGui();
        CastomGui = new CastomGui();
    }

    public static String getUID() {
        return UID;
    }

    public static String getROLE() {
        return ROLE;
    }

    public static String getUSER() {
        return USER;
    }

    public static int hwid() {
        boolean cracked = true;
    }

    public static int getColor() {
        Color v0 = Color.RED;
        Color v1 = Color.WHITE;
        return new Color(207, 0, 255).getRGB();
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent p1) {
        if (Minecraft.func_71410_x().field_71441_e == null || Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        try {
            if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
                int i2 = Keyboard.getEventKey();
                if (i2 <= 0) {
                    return;
                }
                for (Module v4 : ModuleManager.modules) {
                    if (v4.getKey() != i2 || i2 <= 0) continue;
                    v4.toggle();
                }
            }
        }
        catch (Exception v2) {
            v2.printStackTrace();
        }
    }

    static {
        name = "CR3CK3D_BY_BDSYSTEM https://discord.gg/Fubkwjt47x";
        FULL_name = "CR3CK3D_BY_BDSYSTEM https://discord.gg/Fubkwjt47x";
        color = Color.red;
        scale = new ScaleUtils(2);
        UID = "Its Crack3d Bruh";
        ROLE = "CR3CK3D - https://discord.gg/Fubkwjt47x";
        USER = "AdminFucker";
    }
}
