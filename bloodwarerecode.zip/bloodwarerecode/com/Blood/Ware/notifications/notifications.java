package com.Blood.Ware.notifications;

import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class notifications {
    public static /* synthetic */ List<String> Names;
    public static /* synthetic */ List<String> Tests;
    public static /* synthetic */ List<Type> Types;
    public static /* synthetic */ List<Integer> Times;
    public /* synthetic */ int color;
    public static /* synthetic */ float height;
    public static /* synthetic */ float width;

    public notifications() {
        this.color = new Color(255, 255, 255).getRGB();
    }

    public static void add(String string, String string2, Type type) {
        Names.add(string);
        Tests.add(string2);
        Types.add(type);
        Times.add(0);
    }

    public static void drawnotif(int n, String string, String string2, Type type, int n2) {
        GlStateManager.func_179098_w();
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        GL11.glPushMatrix();
        if (n2 >= 110) {
            GL11.glTranslated((double)(scaledResolution.func_78326_a() - 110), (double)(scaledResolution.func_78328_b() - 30 * (n + 1)), (double)0.0);
        } else {
            GL11.glTranslated((double)(scaledResolution.func_78326_a() - n2), (double)(scaledResolution.func_78328_b() - 30 * (n + 1)), (double)0.0);
        }
        int n3 = new Color(255, 255, 255).getRGB();
        int n4 = new Color(63, 255, 0).getRGB();
        int n5 = new Color(255, 0, 0).getRGB();
        int n6 = (int)(230.0 - ((double)n2 - 7.6));
        if (n6 >= 0) {
            if (type == Type.Green) {
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, width, height, 4.0f, 3.0f, n3, n3, n3, n3, false, true, true);
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, 7.0f, height, 4.0f, 3.0f, n4, n4, n4, n4, false, true, true);
                CastomFontUtils.fr4.drawStringWithShadow(string, 10.0f, 2.0f, Color.GREEN.getRGB());
                CastomFontUtils.fr4.drawString(string2, 10.0f, 6 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(0, 255, 0, 255).getRGB());
            } else if (type == Type.Red) {
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, width, height, 4.0f, 3.0f, n3, n3, n3, n3, false, true, true);
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, 7.0f, height, 4.0f, 3.0f, n5, n5, n5, n5, false, true, true);
                CastomFontUtils.fr4.drawStringWithShadow(string, 10.0f, 2.0f, Color.red.getRGB());
                CastomFontUtils.fr4.drawString(string2, 10.0f, 6 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(255, 0, 0, 255).getRGB());
            } else if (type == Type.OK) {
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, width, height, 4.0f, 3.0f, n3, n3, n3, n3, false, true, true);
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(0.0f, 0.0f, 7.0f, height, 4.0f, 3.0f, n4, n4, n4, n4, false, true, true);
                CastomFontUtils.fr4.drawStringWithShadow(string, 10.0f, 2.0f, Color.red.getRGB());
                CastomFontUtils.fr4.drawString(string2, 10.0f, 6 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(0, 0, 255, n6).getRGB());
            }
        }
        GL11.glPopMatrix();
        GlStateManager.func_179090_x();
    }

    public static void show() {
        int n;
        for (n = 0; n < Names.size(); n -= 30336) {
            if (Times.get(n) != 690) {
                Times.set(n, Times.get(n) + 1);
            } else {
                Names.remove(n);
                Tests.remove(n);
                Types.remove(n);
                Times.remove(n);
            }
            n += 30337;
        }
        height = 22.0f;
        for (n = 0; n < Names.size(); n += 15841) {
            String string = Names.get(n);
            String string2 = Tests.get(n);
            Type type = Types.get(n);
            int n2 = Times.get(n);
            notifications.drawnotif(n, string, string2, type, n2);
            n -= 15840;
        }
    }

    static {
        Names = new ArrayList<String>();
        Tests = new ArrayList<String>();
        Types = new ArrayList<Type>();
        Times = new ArrayList<Integer>();
        height = 30.0f;
        width = 100.0f;
    }
}
