package com.Blood.Ware.module.movement;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class NoClip
extends Module {
    public NoClip() {
        super("NoClip", Category.MOVEMENT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Forward", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Up", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("UpSpeed", this, 0.2, 0.1, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Down", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("DownSpeed", this, 0.2, 0.1, 10.0, false));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Forward").getValBoolean();
        boolean bl2 = BloodWare.instance.settingsManager.getSettingByName(this, "Up").getValBoolean();
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "UpSpeed").getValDouble();
        boolean bl3 = BloodWare.instance.settingsManager.getSettingByName(this, "Down").getValBoolean();
        double d2 = BloodWare.instance.settingsManager.getSettingByName(this, "DownSpeed").getValDouble();
        if (NoClip.mc.field_71439_g.field_70123_F && bl && (NoClip.mc.field_71474_y.field_74351_w.func_151470_d() || NoClip.mc.field_71474_y.field_74366_z.func_151470_d() || NoClip.mc.field_71474_y.field_74370_x.func_151470_d() || NoClip.mc.field_71474_y.field_74368_y.func_151470_d())) {
            double d3 = NoClip.mc.field_71439_g.field_70165_t + Math.sin(Math.toRadians(NoClip.mc.field_71439_g.field_70177_z)) * 2.0;
            double d4 = NoClip.mc.field_71439_g.field_70161_v - Math.cos(Math.toRadians(NoClip.mc.field_71439_g.field_70177_z)) * 2.0;
            NoClip.mc.field_71439_g.func_70107_b(d3, NoClip.mc.field_71439_g.field_70163_u, d4);
        }
        if (bl2 && NoClip.mc.field_71474_y.field_74314_A.func_151470_d()) {
            NoClip.mc.field_71439_g.field_70145_X = true;
            NoClip.mc.field_71439_g.func_70107_b(NoClip.mc.field_71439_g.field_70165_t, NoClip.mc.field_71439_g.field_70163_u + d, NoClip.mc.field_71439_g.field_70161_v);
            NoClip.mc.field_71439_g.field_70145_X = false;
        }
        if (bl3 && NoClip.mc.field_71474_y.field_74311_E.func_151470_d()) {
            NoClip.mc.field_71439_g.field_70145_X = true;
            NoClip.mc.field_71439_g.func_70107_b(NoClip.mc.field_71439_g.field_70165_t, NoClip.mc.field_71439_g.field_70163_u - d2, NoClip.mc.field_71439_g.field_70161_v);
            NoClip.mc.field_71439_g.field_70145_X = false;
        }
    }
}
