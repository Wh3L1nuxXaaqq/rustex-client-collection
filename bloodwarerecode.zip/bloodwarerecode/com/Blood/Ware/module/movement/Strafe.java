package com.Blood.Ware.module.movement;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Strafe
extends Module {
    public static /* synthetic */ Minecraft mc;

    public Strafe() {
        super("Strafe", Category.MOVEMENT);
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    public static void strafe() {
        Strafe.strafe(Strafe.getSpeed());
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        Strafe.strafe();
    }

    public static double getDirection() {
        float f = Strafe.mc.field_71439_g.field_70177_z;
        if (Strafe.mc.field_71439_g.field_191988_bg < 0.0f) {
            f += 180.0f;
        }
        float f2 = 1.0f;
        if (Strafe.mc.field_71439_g.field_191988_bg < 0.0f) {
            f2 = -0.2f;
        } else if (Strafe.mc.field_71439_g.field_191988_bg > 0.0f) {
            f2 = 0.2f;
        }
        if (Strafe.mc.field_71439_g.field_70702_br > 0.0f) {
            f -= 90.0f * f2;
        }
        if (Strafe.mc.field_71439_g.field_70702_br < 0.0f) {
            f += 90.0f * f2;
        }
        return Math.toRadians(f);
    }

    public static void strafe(float f) {
        if (!Strafe.isMoving()) {
            return;
        }
        double d = Strafe.getDirection();
        Strafe.mc.field_71439_g.field_70159_w = -Math.sin(d) * (double)f;
        Strafe.mc.field_71439_g.field_70179_y = Math.cos(d) * (double)f;
    }

    public static float getSpeed() {
        return (float)Math.sqrt(Strafe.mc.field_71439_g.field_70159_w * Strafe.mc.field_71439_g.field_70159_w + Strafe.mc.field_71439_g.field_70179_y * Strafe.mc.field_71439_g.field_70179_y);
    }

    public static boolean isMoving() {
        return Strafe.mc.field_71439_g.field_191988_bg != 0.0f || Strafe.mc.field_71439_g.field_70702_br != 0.0f;
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
