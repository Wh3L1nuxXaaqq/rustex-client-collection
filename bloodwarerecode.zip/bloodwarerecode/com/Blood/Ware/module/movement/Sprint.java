package com.Blood.Ware.module.movement;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Sprint
extends Module {
    public Sprint() {
        super("Sprint", Category.MOVEMENT);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)true);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)false);
    }
}
