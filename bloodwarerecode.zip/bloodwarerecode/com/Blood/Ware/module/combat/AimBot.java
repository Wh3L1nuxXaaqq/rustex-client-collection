package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.FovUtils;
import com.Blood.Ware.utils.TimerUtils;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class AimBot
extends Module {
    public /* synthetic */ float[] facing;
    public /* synthetic */ String[] gunlist;
    public /* synthetic */ TimerUtils timer;
    public /* synthetic */ TimerUtils timer2;
    public /* synthetic */ float[] lastFacing;
    public /* synthetic */ double smoothFactor;
    public static /* synthetic */ Entity target;

    public AimBot() {
        super("AimBot", Category.COMBAT);
        this.gunlist = new String[]{""};
        this.timer = new TimerUtils();
        this.timer2 = new TimerUtils();
        BloodWare.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Predict", this, 6.1, 0.0, 7.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("VPredict", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("FOV", this, 48.0, 1.0, 360.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Wall", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Smooth", this, 5.0, 1.0, 100.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("InstantLock", this, false));
        this.smoothFactor = 2.0;
        this.lastFacing = new float[]{0.0f, 0.0f};
    }

    public float[] getPredict(Entity entity) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "VPredict").getValDouble();
        float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        float f3 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        double d = mc.func_184121_ak();
        double d2 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * d;
        double d3 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * d;
        double d4 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * d;
        double d5 = entity.field_70165_t - entity.field_70169_q;
        double d6 = entity.field_70161_v - entity.field_70166_s;
        float f4 = f2 + this.getDistance(entity) / f3;
        double d7 = d2 + d5 * (double)f4;
        double d8 = d4 + d6 * (double)f4;
        double d9 = f != 0.0f ? d3 + (double)(this.getDistance(entity) / f) : d3;
        return new float[]{(float)d7, (float)d8, (float)d9};
    }

    public static float[] faceHead(float f, float f2, float f3, float f4, float f5, boolean bl) {
        double d = (double)f - AimBot.mc.field_71439_g.field_70165_t;
        double d2 = (double)f2 + (!BloodWare.moduleManager.getModule("BAim").isToggled() ? 1.86 : 1.5) - (AimBot.mc.field_71439_g.field_70163_u + (double)AimBot.mc.field_71439_g.func_70047_e());
        double d3 = (double)f3 - AimBot.mc.field_71439_g.field_70161_v;
        double d4 = Math.sqrt(d * d + d3 * d3);
        double d5 = Math.toDegrees(Math.atan2(d3, d)) - 90.0;
        double d6 = -Math.toDegrees(Math.atan2(d2, d4));
        double d7 = (double)AimBot.mc.field_71439_g.field_70177_z + MathHelper.func_76138_g((double)(d5 - (double)AimBot.mc.field_71439_g.field_70177_z));
        double d8 = (double)AimBot.mc.field_71439_g.field_70125_A + MathHelper.func_76138_g((double)(d6 - (double)AimBot.mc.field_71439_g.field_70125_A));
        return new float[]{(float)d7, (float)d8};
    }

    public static float updateRotation(float f, float f2, float f3) {
        float f4 = MathHelper.func_76142_g((float)(f2 - f));
        if (f4 > f3) {
            f4 = f3;
        }
        if (f4 < -f3) {
            f4 = -f3;
        }
        return f + f4;
    }

    public boolean lambdagetTarget(Entity entity) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        return this.attackCheck(entity) && this.getDistance(entity) <= f;
    }

    public Entity getTarget() throws Throwable {
        if (AimBot.mc.field_71439_g != null && !AimBot.mc.field_71439_g.field_70128_L) {
            List list = AimBot.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity != AimBot.mc.field_71439_g).filter(entity -> !entity.field_70128_L).filter(this::lambdagetTarget).sorted(Comparator.comparing(entity -> Float.valueOf(AimBot.mc.field_71439_g.func_70032_d(entity)))).collect(Collectors.toList());
            return list.size() > 0 ? (Entity)list.get(0) : null;
        }
        return null;
    }

    public static int getSortEntities(EntityLivingBase entityLivingBase, EntityLivingBase entityLivingBase2) {
        return (int)(entityLivingBase.func_110143_aJ() - entityLivingBase2.func_110143_aJ());
    }

    public boolean attackCheck(Entity entity) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        if (bl) {
            return entity instanceof EntityPlayer && !FriendManager.FRIENDS.contains(entity.func_70005_c_());
        }
        return !bl && AimBot.mc.field_71439_g.func_70685_l(entity) && entity instanceof EntityPlayer && !FriendManager.FRIENDS.contains(entity.func_70005_c_());
    }

    public float lerp(float f, float f2, float f3) {
        return f + f3 * (f2 - f);
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent livingUpdateEvent) throws Throwable {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble();
        boolean bl2 = BloodWare.instance.settingsManager.getSettingByName(this, "InstantLock").getValBoolean();
        this.smoothFactor = BloodWare.instance.settingsManager.getSettingByName(this, "Smooth").getValDouble();
        EntityPlayer entityPlayer = (EntityPlayer)this.getTarget();
        if (entityPlayer != null && !FriendManager.FRIENDS.contains(entityPlayer.func_70005_c_()) && FovUtils.isInAttackFOV((Entity)entityPlayer, (int)d)) {
            this.facing = this.getPredict((Entity)entityPlayer);
            this.facing = AimBot.faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0f, 360.0f, false);
            if (!bl2) {
                AimBot.mc.field_71439_g.field_70177_z = (float)((double)AimBot.mc.field_71439_g.field_70177_z + (double)(this.facing[0] - AimBot.mc.field_71439_g.field_70177_z) / this.smoothFactor);
                AimBot.mc.field_71439_g.field_70125_A = (float)((double)AimBot.mc.field_71439_g.field_70125_A + (double)(this.facing[1] - AimBot.mc.field_71439_g.field_70125_A) / this.smoothFactor);
                this.lastFacing[0] = AimBot.mc.field_71439_g.field_70177_z;
                this.lastFacing[1] = AimBot.mc.field_71439_g.field_70125_A;
            } else {
                AimBot.mc.field_71439_g.field_70177_z = this.facing[0];
                AimBot.mc.field_71439_g.field_70125_A = this.facing[1];
            }
            AimBot.mc.field_71439_g.field_70177_z = MathHelper.func_76142_g((float)AimBot.mc.field_71439_g.field_70177_z);
            AimBot.mc.field_71439_g.field_70125_A = MathHelper.func_76142_g((float)AimBot.mc.field_71439_g.field_70125_A);
            this.timer2.setLastMS(0x11BD530AF64A6D21L ^ 0x11BD530AF64A6D21L);
        }
    }

    public float getDistance(Entity entity) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - entity.field_70165_t);
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - entity.field_70161_v);
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    public static float getDistance(BlockPos blockPos) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n());
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p());
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post post) {
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble() / (double)Minecraft.func_71410_x().field_71474_y.field_74334_X;
        ScaledResolution scaledResolution = post.getResolution();
        AimBot.drawCircle228(scaledResolution.func_78326_a() / 2, scaledResolution.func_78328_b() / 2, (int)(d * 485.0), Color.RED.getRGB(), 360, 0.5f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawCircle228(float f, float f2, float f3, int n, int n2, float f4) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glLineWidth((float)f4);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n2; i -= 14982) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            i += 14983;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }
}
