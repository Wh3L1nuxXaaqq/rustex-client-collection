package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AimAssist
extends Module {
    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Range", this, 3.0, 1.0, 10.0, true));
    }

    @SubscribeEvent
    public void onUpdate(RenderWorldLastEvent renderWorldLastEvent) {
        double d = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        EntityPlayer entityPlayer2 = AimAssist.mc.field_71441_e.field_73010_i.stream().filter(entityPlayer -> entityPlayer != AimAssist.mc.field_71439_g).min(Comparator.comparing(entityPlayer -> Float.valueOf(entityPlayer.func_70032_d((Entity)AimAssist.mc.field_71439_g)))).filter(entityPlayer -> (double)entityPlayer.func_70032_d((Entity)AimAssist.mc.field_71439_g) <= d).orElse(null);
        if (entityPlayer2 != null && AimAssist.mc.field_71439_g.func_70685_l((Entity)entityPlayer2) && !FriendManager.isFriend(this.getName())) {
            AimAssist.mc.field_71439_g.field_70177_z = this.rotations(entityPlayer2)[0];
            AimAssist.mc.field_71439_g.field_70125_A = this.rotations(entityPlayer2)[1];
        }
    }

    public float[] rotations(EntityPlayer entityPlayer) {
        double d = entityPlayer.field_70165_t - AimAssist.mc.field_71439_g.field_70165_t;
        double d2 = entityPlayer.field_70163_u - (AimAssist.mc.field_71439_g.field_70163_u + (double)AimAssist.mc.field_71439_g.func_70047_e()) + 1.5;
        double d3 = entityPlayer.field_70161_v - AimAssist.mc.field_71439_g.field_70161_v;
        double d4 = MathHelper.func_76133_a((double)(d * d + d3 * d3));
        float f = (float)(MathHelper.func_181159_b((double)d3, (double)d) * 57.29577951308232 - 90.0);
        float f2 = (float)(-MathHelper.func_181159_b((double)d2, (double)d4) * 57.29577951308232);
        return new float[]{f, f2};
    }
}
