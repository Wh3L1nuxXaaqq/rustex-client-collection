package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.combat.AimBot;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.FovUtils;
import com.Blood.Ware.utils.TimerUtils;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class AimBot2
extends Module {
    public /* synthetic */ float[] facing;
    public /* synthetic */ String[] gunlist;
    public /* synthetic */ TimerUtils timer;
    public /* synthetic */ TimerUtils timer2;

    public AimBot2() {
        super("AimBot2", Category.COMBAT);
        this.gunlist = new String[]{""};
        this.timer = new TimerUtils();
        this.timer2 = new TimerUtils();
        BloodWare.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Predict", this, 4.8f, 0.0, 7.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("VPredict", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("BAimDistance", this, 10.0, -1.0, 50.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("FOV", this, 90.0, 1.0, 360.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Wall", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Smooth", this, 5.0, 1.0, 20.0, false));
    }

    public float[] getPredict(Entity entity) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "VPredict").getValDouble();
        float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        float f3 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        double d = entity.field_70165_t - entity.field_70169_q;
        double d2 = entity.field_70161_v - entity.field_70166_s;
        float f4 = f2 + this.getDistance(entity) / f3;
        double d3 = entity.field_70165_t + d * (double)f4;
        double d4 = entity.field_70161_v + d2 * (double)f4;
        double d5 = f != 0.0f ? entity.field_70163_u - (double)entity.field_70143_R + (double)(this.getDistance(entity) / f) : entity.field_70163_u;
        return new float[]{(float)d3, (float)d4, (float)d5};
    }

    public float[] faceHead(float f, float f2, float f3, float f4, float f5, boolean bl) {
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "BAimDistance").getValDouble();
        double d2 = (double)f - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double d3 = (double)f3 - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double d4 = (double)f2 + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        if (d == -1.0) {
            d4 = (double)f2 + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        } else {
            float f6 = AimBot2.getDistance(new BlockPos((double)f, (double)f2, (double)f3));
            if ((double)f6 <= d) {
                d4 = (double)f2 + 1.1 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
            }
        }
        double d5 = MathHelper.func_76133_a((double)(d2 * d2 + d3 * d3));
        float f7 = (float)(Math.atan2(d3, d2) * 180.0 / Math.PI) - 90.0f;
        float f8 = (float)(-(Math.atan2(d4 - 0.15, d5) * 180.0 / Math.PI));
        float f9 = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        float f10 = f9 * f9 * f9 * 1.2f;
        float f11 = AimBot2.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70125_A, f8, f5);
        float f12 = AimBot2.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70177_z, f7, f4);
        f12 -= f12 % f10;
        f11 -= f11 % f10;
        return new float[]{f12, f11};
    }

    public static float updateRotation(float f, float f2, float f3) {
        float f4 = MathHelper.func_76142_g((float)(f2 - f));
        if (f4 > f3) {
            f4 = f3;
        }
        if (f4 < -f3) {
            f4 = -f3;
        }
        return f + f4;
    }

    public boolean lambdagetTarget(Entity entity) {
        return this.attackCheck(entity);
    }

    public Entity getTarget() {
        try {
            if (AimBot.mc.field_71439_g != null && !AimBot.mc.field_71439_g.field_70128_L) {
                List list = AimBot.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity != AimBot.mc.field_71439_g).filter(entity -> AimBot.mc.field_71439_g.func_70032_d(entity) <= 200.0f).filter(entity -> !entity.field_70128_L).filter(this::lambdagetTarget).sorted(Comparator.comparing(entity -> Float.valueOf(AimBot.mc.field_71439_g.func_70032_d(entity)))).collect(Collectors.toList());
                return list.size() > 0 ? (Entity)list.get(0) : null;
            }
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public boolean attackCheck(Entity entity) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        if (bl) {
            return entity instanceof EntityPlayer && !FriendManager.FRIENDS.contains(entity.func_70005_c_());
        }
        return !bl && AimBot.mc.field_71439_g.func_70685_l(entity) && entity instanceof EntityPlayer && !FriendManager.FRIENDS.contains(entity.func_70005_c_());
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent livingUpdateEvent) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Smooth").getValDouble();
        EntityPlayer entityPlayer = (EntityPlayer)this.getTarget();
        if (entityPlayer != null && !FriendManager.FRIENDS.contains(entityPlayer.func_70005_c_()) && FovUtils.isInAttackFOV((Entity)entityPlayer, (int)BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble())) {
            this.facing = this.getPredict((Entity)entityPlayer);
            this.facing = this.faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0f, 360.0f, false);
            float f3 = this.facing[0] - AimBot.mc.field_71439_g.field_70177_z;
            float f4 = this.facing[1] - AimBot.mc.field_71439_g.field_70125_A;
            f3 = MathHelper.func_76142_g((float)f3);
            f4 = MathHelper.func_76142_g((float)f4);
            AimBot.mc.field_71439_g.field_70177_z += f3 / f2;
            AimBot.mc.field_71439_g.field_70125_A += f4 / f2;
            AimBot.mc.field_71439_g.field_70177_z = MathHelper.func_76142_g((float)AimBot.mc.field_71439_g.field_70177_z);
            AimBot.mc.field_71439_g.field_70125_A = MathHelper.func_76131_a((float)AimBot.mc.field_71439_g.field_70125_A, (float)-90.0f, (float)90.0f);
            this.timer2.setLastMS();
        }
    }

    public float getDistance(Entity entity) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - entity.field_70165_t);
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - entity.field_70161_v);
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    public static float getDistance(BlockPos blockPos) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n());
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p());
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post post) {
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble() / (double)Minecraft.func_71410_x().field_71474_y.field_74334_X;
        ScaledResolution scaledResolution = post.getResolution();
        AimBot2.drawCircle228(scaledResolution.func_78326_a() / 2, scaledResolution.func_78328_b() / 2, (int)(d * 485.0), Color.RED.getRGB(), 360, 0.5f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawCircle228(float f, float f2, float f3, int n, int n2, float f4) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glLineWidth((float)f4);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n2; i += 26552) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            i -= 26551;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }
}
