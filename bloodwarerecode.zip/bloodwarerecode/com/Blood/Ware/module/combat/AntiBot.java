package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AntiBot
extends Module {
    public static /* synthetic */ List<String> BOTS;
    public static /* synthetic */ boolean toggle;

    public AntiBot() {
        super("AntiBot", Category.COMBAT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Remove", this, true));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        toggle = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        toggle = false;
        BOTS.clear();
    }

    public static boolean isBot(String string) {
        if (toggle) {
            for (String string2 : BOTS) {
                if (!string2.equalsIgnoreCase(string)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public static boolean isBlockMaterial(BlockPos blockPos, Block block) {
        return AntiBot.getBlock(blockPos) == Blocks.field_150350_a;
    }

    public static Block getBlock(BlockPos blockPos) {
        return AntiBot.getState(blockPos).func_177230_c();
    }

    public static IBlockState getState(BlockPos blockPos) {
        return AntiBot.mc.field_71441_e.func_180495_p(blockPos);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent playerTickEvent) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Remove").getValBoolean();
        for (Entity entity : AntiBot.mc.field_71441_e.field_72996_f) {
            if (entity == AntiBot.mc.field_71439_g || entity.field_70173_aa >= 5 || !(entity instanceof EntityOtherPlayerMP) || !(AntiBot.mc.field_71439_g.func_70068_e(entity) <= 15.0)) continue;
            if (AntiBot.isBlockMaterial(new BlockPos(entity).func_177977_b(), Blocks.field_150350_a)) {
                BOTS.add(entity.func_70005_c_());
                if (bl) {
                    AntiBot.mc.field_71441_e.func_72900_e(entity);
                }
            }
            if (!entity.func_82150_aj()) continue;
            BOTS.add(entity.func_70005_c_());
            if (!bl) continue;
            AntiBot.mc.field_71441_e.func_72900_e(entity);
        }
    }

    static {
        BOTS = new ArrayList<String>();
    }
}
