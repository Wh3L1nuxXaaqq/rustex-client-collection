package com.Blood.Ware.module.render;

import java.awt.Color;

public class ColorUtil {
    public static int RGBtoHex(int n, int n2, int n3) {
        return n << 16 | n2 << 8 | n3;
    }

    public static int toRGBA(float[] fArray) {
        if (fArray.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return ColorUtil.toRGBA(fArray[0], fArray[1], fArray[2], fArray[3]);
    }

    public static int toARGB(int n, int n2, int n3, int n4) {
        return new Color(n, n2, n3, n4).getRGB();
    }

    public static int toRGBA(int n, int n2, int n3) {
        return ColorUtil.toRGBA(n, n2, n3, 255);
    }

    public static int toRGBA(Color color) {
        return ColorUtil.toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int toRGBA(int n, int n2, int n3, int n4) {
        return (n << 16) + (n2 << 8) + n3 + (n4 << 24);
    }

    public static int[] getRainbow(int n, float f) {
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        float f2 = 6.0f * (float)((System.currentTimeMillis() - (long)Math.round(f * 1000.0f)) % (long)(n * 1000)) / (float)(n * 1000);
        int n5 = Math.round(255.0f * (f2 - (float)Math.floor(f2)));
        if (f2 < 1.0f) {
            n2 = 255;
            n3 = n5;
        } else if (f2 < 2.0f) {
            n2 = 255 - n5;
            n3 = 255;
        } else if (f2 < 3.0f) {
            n3 = 255;
            n4 = n5;
        } else if (f2 < 4.0f) {
            n3 = 255 - n5;
            n4 = 255;
        } else if (f2 < 5.0f) {
            n2 = n5;
            n4 = 255;
        } else if (f2 < 6.0f) {
            n2 = 255;
            n4 = 255 - n5;
        }
        return new int[]{n2, n3, n4};
    }

    public static int toRGBA(double[] dArray) {
        if (dArray.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return ColorUtil.toRGBA((float)dArray[0], (float)dArray[1], (float)dArray[2], (float)dArray[3]);
    }

    public static int toRGBA(float f, float f2, float f3, float f4) {
        return ColorUtil.toRGBA((int)(f * 255.0f), (int)(f2 * 255.0f), (int)(f3 * 255.0f), (int)(f4 * 255.0f));
    }
}
