package com.Blood.Ware.module.render;

import net.minecraft.util.math.Vec3d;

public class Circle {
    public final /* synthetic */ Vec3d vec;
    public final /* synthetic */ Vec3d color;
    public /* synthetic */ byte existed;

    public Vec3d position() {
        return this.vec;
    }

    public Circle(Vec3d vec3d, Vec3d vec3d2) {
        this.vec = vec3d;
        this.color = vec3d2;
    }

    public Vec3d color() {
        return this.color;
    }

    public boolean update() {
        byte by;
        this.existed = by = (byte)(this.existed + 1);
        return by > 20;
    }
}
