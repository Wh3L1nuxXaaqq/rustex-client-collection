package com.Blood.Ware.module.render;

import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Tracers
extends Module {
    public Tracers() {
        super("Tracers", Category.RENDER);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        Tracers.mc.field_71474_y.field_74336_f = false;
        GL11.glPushMatrix();
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glDepthMask((boolean)false);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        for (Entity entity : Tracers.mc.field_71441_e.field_72996_f) {
            if (entity == Tracers.mc.field_71439_g || !(entity instanceof EntityPlayer)) continue;
            assert (mc.func_175606_aa() != null);
            Tracers.mc.field_71439_g.func_70032_d(entity);
            double d = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) - Tracers.mc.func_175598_ae().field_78730_l;
            double d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) - Tracers.mc.func_175598_ae().field_78731_m;
            double d3 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) - Tracers.mc.func_175598_ae().field_78728_n;
            Vec3d vec3d = new Vec3d(0.0, 0.0, 1.0);
            vec3d = vec3d.func_178789_a(-((float)Math.toRadians(Tracers.mc.field_71439_g.field_70125_A)));
            Vec3d vec3d2 = vec3d.func_178785_b(-((float)Math.toRadians(Tracers.mc.field_71439_g.field_70177_z)));
            GL11.glBegin((int)2);
            if (FriendManager.isFriend(entity.func_70005_c_())) {
                RenderUtils.glColor(Color.GREEN);
            } else {
                RenderUtils.glColor(Color.white.getRGB());
            }
            GL11.glVertex3d((double)vec3d2.field_72450_a, (double)((double)Tracers.mc.field_71439_g.func_70047_e() + vec3d2.field_72448_b), (double)vec3d2.field_72449_c);
            GL11.glVertex3d((double)d, (double)(d2 + 1.1), (double)d3);
            GL11.glEnd();
        }
        GL11.glDisable((int)3042);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }
}
