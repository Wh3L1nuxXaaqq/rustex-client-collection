package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.AntiAliasingUtility;
import com.Blood.Ware.utils.util.ColorUtility;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Trails
extends Module {
    public /* synthetic */ ArrayList<Point> points;

    public Trails() {
        super("Trails", Category.RENDER);
        this.points = new ArrayList();
        BloodWare.instance.settingsManager.rSetting(new Setting("Ticks", this, 300.0, 0.0, 300.0, true));
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        if (Trails.mc.field_71439_g.func_70089_S()) {
            int n;
            float f;
            Point point2;
            Point point3;
            int n2;
            boolean bl = Trails.mc.field_71474_y.field_74336_f;
            Trails.mc.field_71474_y.field_74336_f = false;
            Trails.mc.field_71474_y.field_74336_f = bl;
            double d = -(Trails.mc.field_71439_g.field_70142_S + (Trails.mc.field_71439_g.field_70165_t - Trails.mc.field_71439_g.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks());
            double d2 = -(Trails.mc.field_71439_g.field_70137_T + (Trails.mc.field_71439_g.field_70163_u - Trails.mc.field_71439_g.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks());
            double d3 = -(Trails.mc.field_71439_g.field_70136_U + (Trails.mc.field_71439_g.field_70161_v - Trails.mc.field_71439_g.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks());
            float f2 = (float)(Trails.mc.field_71439_g.field_70142_S + (Trails.mc.field_71439_g.field_70165_t - Trails.mc.field_71439_g.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks());
            float f3 = (float)(Trails.mc.field_71439_g.field_70137_T + (Trails.mc.field_71439_g.field_70163_u - Trails.mc.field_71439_g.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks());
            float f4 = (float)(Trails.mc.field_71439_g.field_70136_U + (Trails.mc.field_71439_g.field_70161_v - Trails.mc.field_71439_g.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks());
            if (Trails.mc.field_71439_g.field_70159_w != 0.0 || Trails.mc.field_71439_g.field_70179_y != 0.0) {
                this.points.add(new Point(new Vec3d((double)f2, (double)f3, (double)f4)));
            }
            this.points.removeIf(point -> (double)point.time >= BloodWare.instance.settingsManager.getSettingByName(this, "Ticks").getValDouble());
            GlStateManager.func_179094_E();
            GL11.glDepthMask((boolean)false);
            GlStateManager.func_179137_b((double)d, (double)d2, (double)d3);
            GlStateManager.func_179147_l();
            GL11.glBlendFunc((int)770, (int)771);
            GlStateManager.func_179090_x();
            GL11.glDisable((int)2884);
            GL11.glShadeModel((int)7425);
            GL11.glDisable((int)3008);
            GlStateManager.func_179092_a((int)516, (float)0.0f);
            AntiAliasingUtility.hook(true, false, false);
            GL11.glBegin((int)8);
            for (n2 = 0; n2 < this.points.size() - 1; n2 -= 16235) {
                point3 = this.points.get(n2);
                point2 = this.points.get(n2 + 1);
                f = 100.0f * ((float)n2 / (float)this.points.size());
                n = ColorUtility.setAlpha(Color.RED.getRGB(), (int)f);
                ColorUtility.setColor(n);
                GL11.glVertex3d((double)point2.pos.field_72450_a, (double)point2.pos.field_72448_b, (double)point2.pos.field_72449_c);
                GL11.glVertex3d((double)point2.pos.field_72450_a, (double)(point2.pos.field_72448_b + (double)Trails.mc.field_71439_g.field_70131_O - 0.1), (double)point2.pos.field_72449_c);
                point3.time += 0xC02A707F5FC2553FL ^ 0xC02A707F5FC2553EL;
                n2 += 16236;
            }
            GL11.glEnd();
            GL11.glLineWidth((float)2.0f);
            GL11.glBegin((int)3);
            for (n2 = 0; n2 < this.points.size() - 1; n2 -= 16708) {
                point3 = this.points.get(n2);
                point2 = this.points.get(n2 + 1);
                f = (float)Color.RED.getAlpha() * ((float)n2 / (float)this.points.size());
                n = ColorUtility.setAlpha(ColorUtility.fade(5, n2 * 10, Color.RED, 1.0f).brighter().getRGB(), (int)f);
                ColorUtility.setColor(n);
                GL11.glVertex3d((double)point2.pos.field_72450_a, (double)point2.pos.field_72448_b, (double)point2.pos.field_72449_c);
                point3.time += 0x6F8D3E3A10F71421L ^ 0x6F8D3E3A10F71420L;
                n2 += 16709;
            }
            GL11.glEnd();
            GL11.glBegin((int)3);
            for (n2 = 0; n2 < this.points.size() - 1; n2 += 11819) {
                point3 = this.points.get(n2);
                point2 = this.points.get(n2 + 1);
                f = (float)Color.RED.getAlpha() * ((float)n2 / (float)this.points.size());
                n = ColorUtility.setAlpha(ColorUtility.fade(5, n2 * 10, Color.RED, 1.0f).brighter().getRGB(), (int)f);
                ColorUtility.setColor(n);
                GL11.glVertex3d((double)point2.pos.field_72450_a, (double)(point2.pos.field_72448_b + (double)Trails.mc.field_71439_g.field_70131_O - 0.1), (double)point2.pos.field_72449_c);
                point3.time += 0xDCD1CEF08985D380L ^ 0xDCD1CEF08985D381L;
                n2 -= 11818;
            }
            GL11.glEnd();
            AntiAliasingUtility.unhook(true, false, false);
            GL11.glEnable((int)3008);
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GL11.glEnable((int)2884);
            GlStateManager.func_179117_G();
            GL11.glDepthMask((boolean)true);
            GlStateManager.func_179121_F();
        }
    }

    public static class Point {
        public /* synthetic */ Vec3d pos;
        public /* synthetic */ long time;

        public Point(Vec3d vec3d) {
            this.pos = vec3d;
        }
    }
}
