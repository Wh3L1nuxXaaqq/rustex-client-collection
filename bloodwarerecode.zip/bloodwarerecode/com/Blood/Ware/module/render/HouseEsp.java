package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HouseEsp
extends Module {
    public HouseEsp() {
        super("HouseEsp", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("WH", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Glow", this, false));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity entity : HouseEsp.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || !entity.func_184202_aL()) continue;
            entity.func_184195_f(false);
        }
    }

    public void render(Entity entity, float f) {
        try {
            if (entity == null || entity == Minecraft.func_71410_x().field_71439_g) {
                return;
            }
            if (entity != Minecraft.func_71410_x().func_175606_aa() || Minecraft.func_71410_x().field_71474_y.field_74320_O == 0) {
                // empty if block
            }
            Minecraft.func_71410_x().func_175598_ae().func_188388_a(entity, f, true);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        GlStateManager.func_179086_m((int)256);
        RenderHelper.func_74519_b();
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "WH").getValBoolean();
        boolean bl2 = BloodWare.instance.settingsManager.getSettingByName(this, "Glow").getValBoolean();
        for (Entity entity : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || entity == Minecraft.func_71410_x().func_175606_aa()) continue;
            if (bl) {
                this.render(entity, renderWorldLastEvent.getPartialTicks());
            }
            if (!bl2 || entity.func_184202_aL()) continue;
            entity.func_184195_f(true);
        }
    }
}
