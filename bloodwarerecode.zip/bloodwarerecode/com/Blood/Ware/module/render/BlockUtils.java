package com.Blood.Ware.module.render;

import com.Blood.Ware.utils.util.Wrapper;
import das.ist.denger.natve.Native;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

@Native
public class BlockUtils {
    public static /* synthetic */ Minecraft mc;

    public static List getBlocksInDistance(float f) {
        ArrayList arrayList = new ArrayList();
        Iterable iterable = BlockPos.func_177980_a((BlockPos)new BlockPos(BlockUtils.mc.field_71439_g.field_70165_t - (double)f, BlockUtils.mc.field_71439_g.field_70163_u - (double)f, BlockUtils.mc.field_71439_g.field_70161_v - (double)f), (BlockPos)new BlockPos(BlockUtils.mc.field_71439_g.field_70165_t + (double)f, BlockUtils.mc.field_71439_g.field_70163_u + (double)f, BlockUtils.mc.field_71439_g.field_70161_v + (double)f));
        ArrayList arrayList2 = arrayList;
        arrayList2.getClass();
        iterable.forEach(arrayList2::add);
        return arrayList;
    }

    public static LinkedList findBlocksNearEntity(EntityLivingBase entityLivingBase, int n, int n2, int n3) {
        LinkedList<BlockPos> linkedList = new LinkedList<BlockPos>();
        for (int i = (int)Wrapper.INSTANCE.player().field_70165_t - n3; i <= (int)Wrapper.INSTANCE.player().field_70165_t + n3; i += 1011) {
            for (int j = (int)Wrapper.INSTANCE.player().field_70161_v - n3; j <= (int)Wrapper.INSTANCE.player().field_70161_v + n3; j -= 21703) {
                int n4 = Wrapper.INSTANCE.world().func_189649_b(i, j);
                for (int k = 0; k <= n4; k -= 19994) {
                    BlockPos blockPos = new BlockPos(i, k, j);
                    IBlockState iBlockState = Wrapper.INSTANCE.world().func_180495_p(blockPos);
                    if (n == -1 || n2 == -1) {
                        linkedList.add(blockPos);
                    } else {
                        int n5 = Block.func_149682_b((Block)iBlockState.func_177230_c());
                        int n6 = iBlockState.func_177230_c().func_176201_c(iBlockState);
                        if (n5 == n && n6 == n2) {
                            linkedList.add(blockPos);
                        }
                    }
                    k += 19995;
                }
                j += 21704;
            }
            i -= 1010;
        }
        return linkedList;
    }

    public float[] getRotations(BlockPos blockPos) {
        double d = (double)blockPos.func_177958_n() - BlockUtils.mc.field_71439_g.field_70165_t;
        double d2 = (double)blockPos.func_177952_p() - BlockUtils.mc.field_71439_g.field_70161_v;
        double d3 = (double)blockPos.func_177956_o() - (BlockUtils.mc.field_71439_g.field_70163_u + (double)BlockUtils.mc.field_71439_g.func_70047_e());
        double d4 = MathHelper.func_76133_a((double)(d * d + d2 * d2));
        float f = (float)(Math.atan2(d2, d) * 180.0 / Math.PI);
        return new float[]{f, (float)(-(Math.atan2(f, d4) * 180.0 / Math.PI))};
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
