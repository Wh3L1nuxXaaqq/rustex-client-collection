package com.Blood.Ware.module.render;

import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WallHackPlayer
extends Module {
    public WallHackPlayer() {
        super("WallHackPlayer", Category.RENDER);
    }

    public void render(Entity entity, float f) {
        try {
            if (entity == null || entity == Minecraft.func_71410_x().field_71439_g) {
                return;
            }
            if (entity == Minecraft.func_71410_x().func_175606_aa() && Minecraft.func_71410_x().field_71474_y.field_74320_O == 0) {
                return;
            }
            Minecraft.func_71410_x().field_71460_t.func_175072_h();
            Minecraft.func_71410_x().func_175598_ae().func_188388_a(entity, f, false);
            Minecraft.func_71410_x().field_71460_t.func_180436_i();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        GlStateManager.func_179086_m((int)256);
        RenderHelper.func_74519_b();
        for (Entity entity : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityPlayer) || entity == Minecraft.func_71410_x().func_175606_aa()) continue;
            if (FriendManager.isFriend(entity.func_70005_c_())) {
                this.render(entity, renderWorldLastEvent.getPartialTicks());
                continue;
            }
            this.render(entity, renderWorldLastEvent.getPartialTicks());
        }
    }
}
