package com.Blood.Ware.module.render;

import com.Blood.Ware.events.event.Event;

public class EventFogColor
extends Event {
    public /* synthetic */ float red;
    public /* synthetic */ int alpha;
    public /* synthetic */ float blue;
    public /* synthetic */ float green;

    public void setAlpha(int n) {
        this.alpha = n;
    }

    public int getAlpha() {
        return this.alpha;
    }

    public float getBlue() {
        return this.blue;
    }

    public float getGreen() {
        return this.green;
    }

    public static void setGreen(float f) {
    }

    public static void setRed(float f) {
    }

    public float getRed() {
        return this.red;
    }

    public static void setBlue(float f) {
    }

    public EventFogColor(float f, float f2, float f3, int n) {
        this.red = f;
        this.green = f2;
        this.blue = f3;
        this.alpha = n;
    }
}
