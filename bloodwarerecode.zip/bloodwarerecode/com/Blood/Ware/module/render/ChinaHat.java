package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.EnumDyeColor;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ChinaHat
extends Module {
    public /* synthetic */ float height;
    public /* synthetic */ EnumDyeColor onecolor;

    public ChinaHat() {
        super("ChinaHat", Category.RENDER);
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        if (ChinaHat.mc.field_71474_y.field_74320_O == 1 || ChinaHat.mc.field_71474_y.field_74320_O == 2) {
            GlStateManager.func_179094_E();
            GL11.glBlendFunc((int)770, (int)771);
            GlStateManager.func_179097_i();
            GlStateManager.func_179090_x();
            ChinaHat.enableSmoothLine(2.5f);
            GL11.glShadeModel((int)7425);
            GL11.glDisable((int)2884);
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2929);
            GL11.glTranslatef((float)0.0f, (float)(ChinaHat.mc.field_71439_g.field_70131_O + this.height), (float)0.0f);
            GL11.glRotatef((float)(-ChinaHat.mc.field_71439_g.field_70177_z), (float)0.0f, (float)1.0f, (float)0.0f);
            GL11.glBegin((int)6);
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)0.3137255f, (float)1.0f);
            GL11.glVertex3d((double)0.0, (double)0.3, (double)0.0);
            float f = 0.0f;
            while ((double)f < 360.5) {
                GlStateManager.func_179131_c((float)0.0f, (float)0.64705884f, (float)0.0f, (float)1.0f);
                GL11.glVertex3d((double)(Math.cos((double)f * Math.PI / 180.0) * 0.66), (double)0.0, (double)(Math.sin((double)f * Math.PI / 180.0) * 0.66));
                f += 1.0f;
            }
            GL11.glVertex3d((double)0.0, (double)0.3, (double)0.0);
            GL11.glEnd();
            GL11.glBegin((int)2);
            f = 0.0f;
            while ((double)f < 360.5) {
                GlStateManager.func_179131_c((float)0.3137255f, (float)1.0f, (float)0.3137255f, (float)1.0f);
                GL11.glVertex3d((double)(Math.cos((double)f * Math.PI / 180.0) * 0.66), (double)0.0, (double)(Math.sin((double)f * Math.PI / 180.0) * 0.66));
                f += 1.0f;
            }
            GL11.glEnd();
            GlStateManager.func_179141_d();
            ChinaHat.disableSmoothLine();
            GL11.glShadeModel((int)7424);
            GL11.glEnable((int)2884);
            GL11.glDisable((int)3042);
            GlStateManager.func_179098_w();
            GlStateManager.func_179126_j();
            GlStateManager.func_179117_G();
            GlStateManager.func_179121_F();
        }
    }

    public static void enableSmoothLine(float f) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)f);
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }
}
