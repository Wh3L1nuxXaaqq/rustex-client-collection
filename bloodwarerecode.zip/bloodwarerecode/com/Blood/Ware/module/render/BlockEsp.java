package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.RenderUtils;
import com.Blood.Ware.utils.search.Blockinfo;
import com.Blood.Ware.utils.search.Search;
import das.ist.denger.natve.Native;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Native
public class BlockEsp
extends Module {
    public static /* synthetic */ boolean trace;
    public static /* synthetic */ CopyOnWriteArrayList<Blockinfo> render;
    public static /* synthetic */ ArrayList<IBlockState> search_blocks;
    public static /* synthetic */ ArrayList<Block> search_blocks1;
    public /* synthetic */ Thread search;

    public BlockEsp() {
        super("BlockESP", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("UpdateTime", this, 2.0, 0.1, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Trace", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "ore", new ArrayList<String>(){
            {
                this.add("ore");
                this.add("cloth");
                this.add("barriers");
                this.add("food");
                this.add("collector");
            }
        }));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        render = new CopyOnWriteArrayList();
        this.search = new Search();
        this.search.start();
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        trace = BloodWare.instance.settingsManager.getSettingByName(this, "Trace").getValBoolean();
        try {
            ArrayList<Blockinfo> arrayList = new ArrayList<Blockinfo>(render);
            for (Blockinfo blockinfo : arrayList) {
                RenderUtils.blockEspFrame(new BlockPos(blockinfo.getX(), blockinfo.getY(), blockinfo.getZ()), blockinfo.getR(), blockinfo.getG(), blockinfo.getB());
                if (!trace) continue;
                RenderUtils.trace(mc, blockinfo);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.search.interrupt();
    }

    static {
        render = new CopyOnWriteArrayList();
        search_blocks = new ArrayList();
        search_blocks1 = new ArrayList();
    }
}
