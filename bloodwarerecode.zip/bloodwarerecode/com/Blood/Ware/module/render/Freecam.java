package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.events.SendPacketEvent;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import das.ist.denger.natve.Native;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Native
public class Freecam
extends Module {
    public /* synthetic */ int lastThirdPerson;
    public final /* synthetic */ Minecraft mc;
    public static final /* synthetic */ Freecam INSTANCE;
    public /* synthetic */ boolean activeThisSession;
    public /* synthetic */ EntityOtherPlayerMP camera;

    @Override
    public void onEnable() {
        super.onEnable();
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.activeThisSession = true;
        this.mc.field_71438_f.func_72712_a();
    }

    @SubscribeEvent
    public void onInput(InputUpdateEvent inputUpdateEvent) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "horizontalSpeed").getValDouble();
        float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "verticalSpeed").getValDouble();
        if (this.camera == null) {
            return;
        }
        MovementInput movementInput = inputUpdateEvent.getMovementInput();
        Vec3d vec3d = new Vec3d((double)((movementInput.field_187257_e ? f : 0.0f) - (movementInput.field_187258_f ? f : 0.0f)), (double)((movementInput.field_78901_c ? f2 : 0.0f) - (movementInput.field_78899_d ? f2 : 0.0f)), (double)((movementInput.field_187255_c ? f : 0.0f) - (movementInput.field_187256_d ? f : 0.0f))).func_178785_b((float)(-Math.toRadians(this.camera.field_70759_as)));
        this.camera.func_180426_a(this.camera.field_70165_t + vec3d.field_72450_a, this.camera.field_70163_u + vec3d.field_72448_b, this.camera.field_70161_v + vec3d.field_72449_c, this.camera.field_70759_as, this.camera.field_70125_A, 3, false);
        if (movementInput instanceof MovementInputFromOptions) {
            this.mc.field_71439_g.field_70701_bs = 0.0f;
            this.mc.field_71439_g.field_70702_br = 0.0f;
            this.mc.field_71439_g.field_191988_bg = 0.0f;
            this.mc.field_71439_g.func_70637_d(false);
        }
    }

    public Freecam() {
        super("Freecam", Category.OUTHER);
        this.mc = Minecraft.func_71410_x();
        this.activeThisSession = false;
        BloodWare.instance.settingsManager.rSetting(new Setting("verticalspeed", this, 3.5, 1.0, 12.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("horizontalspeed", this, 3.5, 1.0, 12.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("rotationspeed", this, 3.0, 1.0, 20.0, false));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        if (this.mc.field_71441_e == null || !this.mc.field_71441_e.field_72995_K) {
            this.camera = null;
            return;
        }
        if (this.camera == null) {
            this.lastThirdPerson = this.mc.field_71474_y.field_74320_O;
            this.camera = new EntityOtherPlayerMP((World)this.mc.field_71441_e, this.mc.func_110432_I().func_148256_e());
            this.mc.field_71441_e.func_73027_a(333393333, (Entity)this.camera);
            this.camera.func_82149_j((Entity)this.mc.field_71439_g);
            this.mc.func_175607_a((Entity)this.camera);
            this.camera.field_70145_X = true;
        }
        this.mc.field_71474_y.field_74320_O = 0;
        this.camera.field_71071_by = this.mc.field_71439_g.field_71071_by;
        this.camera.func_70606_j(this.mc.field_71439_g.func_110143_aJ());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        if (this.mc.field_71441_e != null && this.mc.field_71441_e.field_72995_K) {
            this.mc.func_175607_a((Entity)this.mc.field_71439_g);
            if (this.activeThisSession) {
                this.mc.field_71474_y.field_74320_O = this.lastThirdPerson;
                this.mc.field_71441_e.func_72900_e((Entity)this.camera);
            }
        }
        this.camera = null;
        this.activeThisSession = false;
    }

    @SubscribeEvent
    public void onKeyUpdate(InputUpdateEvent inputUpdateEvent) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "rotationspeed").getValDouble();
        if (Keyboard.isKeyDown((int)203)) {
            this.camera.field_70759_as -= f;
            this.camera.field_70177_z -= f;
        }
        if (Keyboard.isKeyDown((int)205)) {
            this.camera.field_70759_as += f;
            this.camera.field_70177_z += f;
        }
        if (Keyboard.isKeyDown((int)200)) {
            this.camera.field_70125_A -= f;
        }
        if (Keyboard.isKeyDown((int)208)) {
            this.camera.field_70125_A += f;
        }
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent sendPacketEvent) {
        if (sendPacketEvent.getPacket() instanceof CPacketUseEntity && ((CPacketUseEntity)sendPacketEvent.getPacket()).func_149564_a((World)this.mc.field_71441_e) == this.mc.field_71439_g) {
            sendPacketEvent.setCanceled(true);
        }
    }

    static {
        INSTANCE = new Freecam();
    }
}
