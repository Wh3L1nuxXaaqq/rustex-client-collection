package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@Native
public class ESP
extends Module {
    public static /* synthetic */ List listA;
    public static /* synthetic */ List Heal;
    public static /* synthetic */ List Modes;
    public /* synthetic */ Entity EntityArmorStand;

    public static void renderEntityBoundingBox(Entity entity, float f, float f2, float f3, float f4) {
        RenderManager renderManager = Minecraft.func_71410_x().func_175598_ae();
        Vec3d vec3d = ESP.interpolateEntity(entity);
        GlStateManager.func_187441_d((float)5.0f);
        RenderGlobal.func_189697_a((AxisAlignedBB)new AxisAlignedBB(vec3d.field_72450_a - (double)(entity.field_70130_N / 2.0f), vec3d.field_72448_b, vec3d.field_72449_c - (double)(entity.field_70130_N / 2.0f), vec3d.field_72450_a + (double)(entity.field_70130_N / 2.0f), vec3d.field_72448_b + (double)entity.field_70131_O, vec3d.field_72449_c + (double)(entity.field_70130_N / 2.0f)).func_72317_d(-renderManager.field_78730_l, -renderManager.field_78731_m, -renderManager.field_78728_n), (float)f, (float)f2, (float)f3, (float)f4);
        GlStateManager.func_187441_d((float)1.0f);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityPlayer) || !entity.func_184202_aL()) continue;
            entity.func_184195_f(false);
        }
    }

    public static void renderEntityFilledBoundingBox(Entity entity, float f, float f2, float f3, float f4) {
        RenderManager renderManager = Minecraft.func_71410_x().func_175598_ae();
        Vec3d vec3d = ESP.interpolateEntity(entity);
        RenderGlobal.func_189696_b((AxisAlignedBB)new AxisAlignedBB(vec3d.field_72450_a - (double)(entity.field_70130_N / 2.0f), vec3d.field_72448_b, vec3d.field_72449_c - (double)(entity.field_70130_N / 2.0f), vec3d.field_72450_a + (double)(entity.field_70130_N / 2.0f), vec3d.field_72448_b + (double)entity.field_70131_O, vec3d.field_72449_c + (double)(entity.field_70130_N / 2.0f)).func_72317_d(-renderManager.field_78730_l, -renderManager.field_78731_m, -renderManager.field_78728_n), (float)f, (float)f2, (float)f3, (float)f4);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    public static Vec3d interpolateEntity(Entity entity) {
        double d = Minecraft.func_71410_x().func_184121_ak();
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * d, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * d, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * d);
    }

    public ESP() {
        super("ESP", Category.RENDER);
        Modes.add("3D");
        Modes.add("NoneCode");
        Modes.add("Glowing");
        Modes.add("Corners");
        Modes.add("OnHeal");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "2D", (ArrayList<String>)((ArrayList)Modes)));
        BloodWare.instance.settingsManager.rSetting(new Setting("3DAlpha[3D]", this, 0.7, 0.0, 1.0, false));
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        block12: {
            double d;
            double d2;
            String string;
            block11: {
                Iterator iterator;
                string = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
                float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "3DAlpha[3D]").getValDouble();
                if (Objects.equals(string, "2D") && (iterator = ESP.mc.field_71441_e.field_72996_f.iterator()).hasNext()) {
                    Entity entity = (Entity)iterator.next();
                    for (Entity entity2 : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity2 instanceof EntityPlayer) || entity2 == ESP.mc.field_71441_e.field_72996_f) continue;
                        d2 = entity2.field_70142_S + (entity2.field_70165_t - entity2.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                        d = entity2.field_70137_T + (entity2.field_70163_u - entity2.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                        double d3 = entity2.field_70136_U + (entity2.field_70161_v - entity2.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glLineWidth((float)1.5f);
                        GL11.glTranslated((double)d2, (double)d, (double)d3);
                        GL11.glDisable((int)3553);
                        GL11.glDisable((int)2929);
                        GL11.glRotated((double)(-ESP.mc.func_175598_ae().field_78735_i), (double)0.0, (double)1.0, (double)0.0);
                    }
                }
                if (Objects.equals(string, "Glowing")) {
                    for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity instanceof EntityPlayer) || entity == ESP.mc.field_71439_g || entity.func_184202_aL()) continue;
                        entity.func_184195_f(true);
                    }
                } else if (Objects.equals(string, "3D")) {
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179118_c();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
                    GlStateManager.func_179097_i();
                    for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity instanceof EntityArmorStand) || entity == this.EntityArmorStand) continue;
                        ESP.renderEntityBoundingBox(entity, (float)Color.RED.getRed() / 255.0f, (float)Color.RED.getGreen() / 255.0f, (float)Color.RED.getBlue() / 255.0f, f);
                    }
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179098_w();
                    GlStateManager.func_179141_d();
                    GlStateManager.func_179121_F();
                }
                if (Objects.equals(string, "NoneCode")) {
                    for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity instanceof EntityPlayer) || entity == ESP.mc.field_71439_g && ESP.mc.field_71474_y.field_74320_O != 1) continue;
                        double d4 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78730_l;
                        d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78731_m;
                        d = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glDisable((int)2929);
                        GL11.glDisable((int)3553);
                        GL11.glTranslatef((float)((float)d4), (float)((float)d2), (float)((float)d));
                        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glRotatef((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glRotatef((float)ESP.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                        GL11.glLineWidth((float)5.0f);
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)((double)entity.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity.field_70130_N) - 0.1), (double)((double)entity.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity.field_70130_N) - 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glEnd();
                        GL11.glLineWidth((float)1.0f);
                        GL11.glColor3f((float)148.0f, (float)0.0f, (float)211.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)((double)entity.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity.field_70130_N) - 0.1), (double)((double)entity.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity.field_70130_N) - 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glEnd();
                        GL11.glEnable((int)2929);
                        GL11.glEnable((int)3553);
                        GL11.glColor3f((float)148.0f, (float)0.0f, (float)211.0f);
                        GL11.glPopMatrix();
                    }
                    return;
                }
                if (!Objects.equals(string, "Corners")) break block11;
                for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                    if (!(entity instanceof EntityPlayer) || entity == ESP.mc.field_71439_g) continue;
                    double d5 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                    d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                    d = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                    GL11.glPushMatrix();
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)3553);
                    GL11.glTranslated((double)d5, (double)d2, (double)d);
                    GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                    GL11.glRotatef((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                    GL11.glLineWidth((float)6.0f);
                    GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)0.2, (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)-0.3, (double)0.0);
                    GL11.glVertex3d((double)0.15, (double)-0.3, (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)0.2, (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)-0.3, (double)0.0);
                    GL11.glVertex3d((double)-0.15, (double)-0.3, (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)0.15, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)((double)entity.field_70131_O - 0.3), (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)-0.15, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)((double)entity.field_70131_O - 0.3), (double)0.0);
                    GL11.glEnd();
                    GL11.glLineWidth((float)1.0f);
                    GL11.glColor3f((float)Color.RED.darker().getRed(), (float)Color.RED.darker().getGreen(), (float)Color.RED.darker().getBlue());
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)0.2, (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)-0.3, (double)0.0);
                    GL11.glVertex3d((double)0.15, (double)-0.3, (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)0.2, (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)-0.3, (double)0.0);
                    GL11.glVertex3d((double)-0.15, (double)-0.3, (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)0.15, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)entity.field_70130_N, (double)((double)entity.field_70131_O - 0.3), (double)0.0);
                    GL11.glEnd();
                    GL11.glBegin((int)3);
                    GL11.glVertex3d((double)-0.15, (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)((double)entity.field_70131_O + 0.3), (double)0.0);
                    GL11.glVertex3d((double)(-entity.field_70130_N), (double)((double)entity.field_70131_O - 0.3), (double)0.0);
                    GL11.glEnd();
                    GL11.glColor3f((float)1.0f, (float)1.0f, (float)1.0f);
                    GL11.glDisable((int)2960);
                    GL11.glEnable((int)2929);
                    GL11.glEnable((int)3553);
                    GL11.glPopMatrix();
                }
                break block12;
            }
            if (!Objects.equals(string, "OnHeal")) break block12;
            for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityPlayer) || entity == ESP.mc.field_71439_g) continue;
                double d6 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                d = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                GL11.glPushMatrix();
                GL11.glDisable((int)2929);
                GL11.glDisable((int)3553);
                GL11.glTranslatef((float)((float)d6), (float)((float)d2), (float)((float)d));
                GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)ESP.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                GL11.glLineWidth((float)4.7f);
                GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                GL11.glBegin((int)3);
                GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                GL11.glVertex3f((float)0.4f, (float)entity.field_70131_O, (float)0.0f);
                GL11.glEnd();
                GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                GL11.glLineWidth((float)0.8f);
                GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                GL11.glBegin((int)3);
                GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                GL11.glVertex3f((float)0.4f, (float)entity.field_70131_O, (float)0.0f);
                GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                GL11.glEnd();
                GL11.glBegin((int)3);
                GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                GL11.glVertex3f((float)0.4f, (float)(((EntityPlayer)entity).func_110143_aJ() / ((EntityPlayer)entity).func_110138_aP() * entity.field_70131_O), (float)0.0f);
                GL11.glEnd();
                GL11.glEnable((int)3553);
                GL11.glEnable((int)2929);
                GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                GL11.glPopMatrix();
            }
        }
    }

    static {
        listA = new ArrayList();
        Modes = new ArrayList();
        Heal = new ArrayList();
    }
}
