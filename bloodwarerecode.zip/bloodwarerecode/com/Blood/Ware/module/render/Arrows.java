package com.Blood.Ware.module.render;

import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.RenderUtils;
import das.ist.denger.natve.Native;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@Native
public class Arrows
extends Module {
    public Arrows() {
        super("Arrows", Category.RENDER);
    }

    @SubscribeEvent
    public void onRender2D(RenderGameOverlayEvent.Text text) {
        if (Arrows.mc.field_71441_e == null || Arrows.mc.field_71439_g == null) {
            return;
        }
        for (Entity entity : Arrows.mc.field_71441_e.field_72996_f) {
            if (entity == Arrows.mc.field_71439_g || !(entity instanceof EntityPlayer)) continue;
            GlStateManager.func_179094_E();
            Color color = FriendManager.isFriend(entity.func_70005_c_()) ? Color.green : Color.red;
            double d = Math.toDegrees(Math.atan2(entity.field_70136_U - Arrows.mc.field_71439_g.field_70161_v, entity.field_70142_S - Arrows.mc.field_71439_g.field_70165_t)) - (double)Arrows.mc.field_71439_g.field_70177_z - 90.0;
            GL11.glTranslated((double)((double)new ScaledResolution(mc).func_78326_a() / 2.0 + 1.0), (double)((double)new ScaledResolution(mc).func_78328_b() / 2.0), (double)0.0);
            GL11.glTranslated((double)(Math.cos(Math.toRadians(d - 90.0)) * 20.0), (double)(Math.sin(Math.toRadians(d - 90.0)) * 20.0), (double)0.0);
            GL11.glRotated((double)d, (double)0.0, (double)0.0, (double)1.0);
            RenderUtils.drawImage(new ResourceLocation("triangle.png"), -9, 0, 17, 17, color.getRGB());
            GlStateManager.func_179121_F();
        }
    }
}
