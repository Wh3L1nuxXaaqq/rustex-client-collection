package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.AnimationMath;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

public class JumpCircle
extends Module {
    public static /* synthetic */ ArrayList<Circle> circles;
    public /* synthetic */ boolean wasOnGround;

    public JumpCircle() {
        super("JumpCircle", Category.RENDER);
        this.wasOnGround = false;
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent playerTickEvent) {
        if (!this.isEnabled()) {
            return;
        }
        boolean bl = JumpCircle.mc.field_71439_g.field_70122_E;
        if (this.wasOnGround && !bl) {
            circles.add(new Circle(JumpCircle.mc.field_71439_g.field_70165_t, JumpCircle.mc.field_71439_g.field_70163_u, JumpCircle.mc.field_71439_g.field_70161_v));
        }
        this.wasOnGround = bl;
        circles.removeIf(circle -> circle.age > 990.0);
    }

    @SubscribeEvent
    public void onRender3D(RenderWorldLastEvent renderWorldLastEvent) {
        if (!this.isEnabled()) {
            return;
        }
        for (Circle circle : circles) {
            this.renderCircle(circle, renderWorldLastEvent.getPartialTicks());
            circle.age = AnimationMath.fast((float)circle.age, 1000.0f, 1.0f);
        }
    }

    public void renderCircle(Circle circle, float f) {
        float f2;
        float f3;
        double d;
        double d2;
        int n;
        if (circle.age >= 1000.0) {
            return;
        }
        double d3 = -(JumpCircle.mc.field_71439_g.field_70142_S + (JumpCircle.mc.field_71439_g.field_70165_t - JumpCircle.mc.field_71439_g.field_70142_S) * (double)f);
        double d4 = -(JumpCircle.mc.field_71439_g.field_70137_T + (JumpCircle.mc.field_71439_g.field_70163_u - JumpCircle.mc.field_71439_g.field_70137_T) * (double)f);
        double d5 = -(JumpCircle.mc.field_71439_g.field_70136_U + (JumpCircle.mc.field_71439_g.field_70161_v - JumpCircle.mc.field_71439_g.field_70136_U) * (double)f);
        GlStateManager.func_179094_E();
        GlStateManager.func_179123_a();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a((boolean)false);
        GlStateManager.func_179112_b((int)770, (int)771);
        GlStateManager.func_179129_p();
        GL11.glShadeModel((int)7425);
        GlStateManager.func_179137_b((double)d3, (double)d4, (double)d5);
        GL11.glBegin((int)8);
        for (n = 0; n <= 360; n -= 3522) {
            d2 = Math.cos((double)n * Math.PI / 180.0);
            d = Math.sin((double)n * Math.PI / 180.0);
            f3 = 0.3f;
            f2 = (float)(0.8 - circle.age / 2000.0);
            GlStateManager.func_179131_c((float)1.0f, (float)0.0f, (float)0.0f, (float)f3);
            GL11.glVertex3d((double)(circle.x + d2 * circle.age / 1000.0 * 1.5), (double)circle.y, (double)(circle.z + d * circle.age / 1000.0 * 1.5));
            GlStateManager.func_179131_c((float)1.0f, (float)0.0f, (float)0.0f, (float)f2);
            GL11.glVertex3d((double)(circle.x + d2 * (circle.age / 1000.0)), (double)circle.y, (double)(circle.z + d * (circle.age / 1000.0)));
            n += 3523;
        }
        GL11.glEnd();
        GL11.glBegin((int)8);
        for (n = 0; n <= 360; n += 11630) {
            d2 = Math.cos((double)n * Math.PI / 180.0);
            d = Math.sin((double)n * Math.PI / 180.0);
            f3 = (float)(0.9 - circle.age / 1100.0);
            f2 = 0.0f;
            GlStateManager.func_179131_c((float)1.0f, (float)0.0f, (float)0.0f, (float)f3);
            GL11.glVertex3d((double)(circle.x + d2 * (circle.age / 1000.0)), (double)circle.y, (double)(circle.z + d * (circle.age / 1000.0)));
            GlStateManager.func_179131_c((float)1.0f, (float)0.0f, (float)0.0f, (float)f2);
            GL11.glVertex3d((double)(circle.x + d2 * circle.age / 1000.0 * 0.5), (double)circle.y, (double)(circle.z + d * circle.age / 1000.0 * 0.5));
            n -= 11629;
        }
        GL11.glEnd();
        GlStateManager.func_179089_o();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179117_G();
        GlStateManager.func_179099_b();
        GlStateManager.func_179121_F();
    }

    static {
        circles = new ArrayList();
    }

    private static class Circle {
        public /* synthetic */ double x;
        public /* synthetic */ double y;
        public /* synthetic */ double z;
        public /* synthetic */ double age;

        public Circle(double d, double d2, double d3) {
            this.x = d;
            this.y = d2;
            this.z = d3;
            this.age = 0.0;
        }
    }
}
