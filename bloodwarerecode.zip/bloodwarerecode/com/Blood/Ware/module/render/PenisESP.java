package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import das.ist.denger.natve.Native;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.glu.Sphere;

@Native
public class PenisESP
extends Module {
    public PenisESP() {
        super("PenisESP", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("Size", this, 0.1f, 1.0, 50.0, true));
    }

    public void esp(EntityPlayer entityPlayer, double d, double d2, double d3) {
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Size").getValDouble();
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)true);
        GL11.glLineWidth((float)1.0f);
        GL11.glTranslated((double)d, (double)d2, (double)d3);
        GL11.glRotatef((float)(-entityPlayer.field_70177_z), (float)0.0f, (float)entityPlayer.field_70131_O, (float)0.0f);
        GL11.glTranslated((double)(-d), (double)(-d2), (double)(-d3));
        GL11.glTranslated((double)d, (double)(d2 + (double)(entityPlayer.field_70131_O / 2.0f) - (double)0.225f), (double)d3);
        GL11.glColor4f((float)1.38f, (float)0.55f, (float)2.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.075f);
        Cylinder cylinder = new Cylinder();
        cylinder.setDrawStyle(100013);
        cylinder.draw(0.1f * f, 0.11f * f, 0.4f * f, 25, 20);
        GL11.glColor4f((float)1.38f, (float)0.85f, (float)1.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)-0.12500000298023223);
        GL11.glTranslated((double)(-0.09000000074505805 * (double)f), (double)0.0, (double)0.0);
        Sphere sphere = new Sphere();
        sphere.setDrawStyle(100013);
        sphere.draw(0.14f * f, 10, 20);
        GL11.glTranslated((double)(0.16000000149011612 * (double)f), (double)0.0, (double)0.0);
        Sphere sphere2 = new Sphere();
        sphere2.setDrawStyle(100013);
        sphere2.draw(0.14f * f, 10, 20);
        GL11.glColor4f((float)1.35f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)(-0.07000000074505806 * (double)f), (double)0.0, (double)(0.589999952316284 * (double)f));
        Sphere sphere3 = new Sphere();
        sphere3.setDrawStyle(100013);
        sphere3.draw(0.13f * f, 15, 20);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent renderWorldLastEvent) {
        for (Entity entity : PenisESP.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityPlayer)) continue;
            EntityPlayer entityPlayer = (EntityPlayer)entity;
            double d = renderWorldLastEvent.getPartialTicks();
            double d2 = entityPlayer.field_70142_S + (entityPlayer.field_70165_t - entityPlayer.field_70142_S) * d - PenisESP.mc.func_175598_ae().field_78730_l;
            double d3 = entityPlayer.field_70137_T + (entityPlayer.field_70163_u - entityPlayer.field_70137_T) * d - PenisESP.mc.func_175598_ae().field_78731_m;
            double d4 = entityPlayer.field_70136_U + (entityPlayer.field_70161_v - entityPlayer.field_70136_U) * d - PenisESP.mc.func_175598_ae().field_78728_n;
            GL11.glPushMatrix();
            RenderHelper.func_74518_a();
            this.esp(entityPlayer, d2, d3, d4);
            RenderHelper.func_74519_b();
            GL11.glPopMatrix();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }
}
