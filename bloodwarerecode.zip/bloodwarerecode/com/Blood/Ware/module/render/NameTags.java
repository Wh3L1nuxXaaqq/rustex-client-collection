package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import das.ist.denger.natve.Native;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@Native
public class NameTags
extends Module {
    public static /* synthetic */ List Modes;
    public /* synthetic */ FontRenderer fontRenderer;

    public NameTags() {
        super("NameTags", Category.RENDER);
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        for (Entity entity : NameTags.mc.field_71441_e.field_72996_f) {
            Object object2;
            if (!(entity instanceof EntityPlayer)) continue;
            if (entity == NameTags.mc.field_71439_g) continue;
            double d = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78730_l;
            double d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78731_m;
            double d3 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78728_n;
            GL11.glPushMatrix();
            GL11.glDisable((int)2929);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
            float f = Math.min(Math.max(1.2f * (NameTags.mc.field_71439_g.func_70032_d(entity) * 0.15f), 1.25f), 6.0f) * 0.015f;
            GL11.glTranslatef((float)((float)d), (float)((float)d2 + entity.field_70131_O + 0.6f), (float)((float)d3));
            GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)(-NameTags.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)NameTags.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glScalef((float)(-f), (float)(-f), (float)(-f));
            int n = (int)(((EntityPlayer)entity).func_110143_aJ() / ((EntityPlayer)entity).func_110138_aP() * 100.0f);
            String string = entity.func_145748_c_().func_150260_c().toLowerCase();
            float f2 = CastomFontUtils.fr4.getStringWidth(string) + 10;
            RenderUtils.drawShadowRect(-(f2 / 2.0f), 0.0, f2 / 2.0f, 15.0, 3);
            RenderUtils.drawCastomLitium((int)(-(f2 / 2.0f)), 0, (int)(f2 / 2.0f), 15, 1, -1);
            int n2 = (int)(f2 - 4.0f);
            double d4 = CastomFontUtils.fr4.getStringWidth(string) / 2;
            CastomFontUtils.fr4.drawString(string, -d4, (double)(7 - CastomFontUtils.fr4.getHeight() / 2), -1);
            ArrayList<ItemStack> arrayList = new ArrayList<ItemStack>();
            if (!(((EntityPlayer)entity).func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemAir)) {
                arrayList.add(((EntityPlayer)entity).func_184586_b(EnumHand.MAIN_HAND));
            }
            for (Object object2 : entity.func_184193_aE()) {
                if (object2.func_77973_b() instanceof ItemAir) continue;
                arrayList.add((ItemStack)object2);
            }
            if (!(((EntityPlayer)entity).func_184586_b(EnumHand.OFF_HAND).func_77973_b() instanceof ItemAir)) {
                arrayList.add(((EntityPlayer)entity).func_184586_b(EnumHand.OFF_HAND));
            }
            int n3 = -(arrayList.size() * 16 / 2);
            object2 = arrayList.iterator();
            while (object2.hasNext()) {
                ItemStack itemStack = (ItemStack)object2.next();
                RenderItem renderItem = mc.func_175599_af();
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                RenderHelper.func_74519_b();
                renderItem.field_77023_b = -100.0f;
                renderItem.func_175042_a(itemStack, n3, -20);
                renderItem.field_77023_b = 0.0f;
                RenderHelper.func_74518_a();
                GlStateManager.func_179141_d();
                GlStateManager.func_179084_k();
                GlStateManager.func_179140_f();
                GlStateManager.func_179121_F();
                GlStateManager.func_179094_E();
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                GlStateManager.func_179121_F();
                n3 += 10058;
                n3 -= 10042;
            }
            GL11.glEnable((int)2929);
            GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
            GL11.glEnable((int)2929);
            GL11.glPopMatrix();
        }
    }
}
