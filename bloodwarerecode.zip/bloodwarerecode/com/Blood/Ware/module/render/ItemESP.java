package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ItemESP
extends Module {
    public /* synthetic */ AxisAlignedBB box;

    public ItemESP() {
        super("ItemsESP", Category.RENDER);
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent renderWorldLastEvent) {
        for (Entity entity : ItemESP.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityItem)) continue;
            this.box = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + ((double)((float)((double)((float)entity.field_70142_S) + (entity.field_70165_t - entity.field_70142_S) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78730_l), entity.func_174813_aQ().field_72338_b - entity.field_70163_u + ((double)((float)((double)((float)entity.field_70137_T) + (entity.field_70163_u - entity.field_70137_T) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78731_m), entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + ((double)((float)((double)((float)entity.field_70136_U) + (entity.field_70161_v - entity.field_70136_U) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78728_n), entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + ((double)((float)((double)((float)entity.field_70142_S) + (entity.field_70165_t - entity.field_70142_S) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78730_l), entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + ((double)((float)((double)((float)entity.field_70137_T) + (entity.field_70163_u - entity.field_70137_T) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78731_m), entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + ((double)((float)((double)((float)entity.field_70136_U) + (entity.field_70161_v - entity.field_70136_U) * (double)Minecraft.func_71410_x().func_184121_ak())) - Minecraft.func_71410_x().func_175598_ae().field_78728_n));
            RenderUtils.FillLine(entity, this.box);
        }
    }
}
