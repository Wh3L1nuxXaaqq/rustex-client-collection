package com.Blood.Ware.module.hud;

import Caesium.Panel;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ColourUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;

public class ClickGUI
extends Module {
    public static /* synthetic */ int red;
    public static /* synthetic */ int green;
    public static /* synthetic */ int blue;
    public static /* synthetic */ int color;
    public static /* synthetic */ List<String> Modes;

    public ClickGUI() {
        super("ClickGUI", Category.HUD);
        this.setKey(54);
        Modes.add("New");
        Modes.add("Castom");
        BloodWare.instance.settingsManager.rSetting(new Setting("Gui", (Module)this, "New", (ArrayList<String>)((ArrayList)Modes)));
        BloodWare.instance.settingsManager.rSetting(new Setting("Rainbow", this, true));
    }

    public static int getColor() {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] fArray = new float[]{(float)(System.currentTimeMillis() % (0xF3F6FE6794AC026BL ^ 0xF3F6FE6794AC2F6BL)) / 11520.0f};
        int n = Color.HSBtoRGB(fArray[0], 1.0f, 1.0f);
        int n2 = ColourUtils.toRGBA(red, green, blue, 255);
        int n3 = bl ? ColourUtils.genRainbow() : n2;
        return n3;
    }

    public static int getColor2() {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] fArray = new float[]{(float)(System.currentTimeMillis() % (0xC5AE80B048F9787L ^ 0xC5AE80B048FBA87L)) / 11520.0f};
        int n = Color.HSBtoRGB(fArray[0], 1.0f, 1.0f);
        int n2 = ColourUtils.toRGBA(red, green, blue, 195);
        int n3 = bl ? ColourUtils.genRainbowShadow() : n2;
        return n3;
    }

    public static float getColor3() {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] fArray = new float[]{(float)(System.currentTimeMillis() % (0xC347F5B80AFBB85FL ^ 0xC347F5B80AFB955FL)) / 11520.0f};
        float f = Color.HSBtoRGB(fArray[0], 1.0f, 1.0f);
        int n = ColourUtils.toRGBA((float)red, (float)green, (float)blue, 255.0f);
        float f2 = bl ? (float)ColourUtils.genRainbowShadow() : (float)n;
        return f2;
    }

    @Override
    public void onEnable() {
        String string;
        switch (string = BloodWare.instance.settingsManager.getSettingByName(this, "Gui").getValString()) {
            case "New": {
                mc.func_147108_a((GuiScreen)new Panel("Caesium", 22));
                break;
            }
            case "Old": {
                mc.func_147108_a((GuiScreen)BloodWare.bobrGui);
                break;
            }
            case "Castom": {
                mc.func_147108_a((GuiScreen)BloodWare.CastomGui);
            }
        }
        super.onEnable();
        this.setToggled(false);
    }

    static {
        Modes = new ArrayList<String>();
    }
}
