package com.Blood.Ware.module.hud;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import das.ist.denger.natve.Native;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Native
public class ArmorHUD
extends Module {
    public static /* synthetic */ RenderItem itemRender;

    public ArmorHUD() {
        super("ArmorHUD", Category.HUD);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text text) {
        GlStateManager.func_179098_w();
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n = scaledResolution.func_78326_a() / 2;
        int n2 = 0;
        int n3 = scaledResolution.func_78328_b() - 55 - 10;
        for (ItemStack itemStack : ArmorHUD.mc.field_71439_g.field_71071_by.field_70460_b) {
            n2 += 19882;
            n2 -= 19881;
            if (itemStack.func_190926_b()) continue;
            int n4 = n - 90 + (9 - n2) * 20 + 2;
            GlStateManager.func_179126_j();
            ArmorHUD.itemRender.field_77023_b = 200.0f;
            itemRender.func_180450_b(itemStack, n4, n3);
            itemRender.func_180453_a(ArmorHUD.mc.field_71466_p, itemStack, n4, n3, "");
            ArmorHUD.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            String string = itemStack.func_190916_E() > 1 ? itemStack.func_190916_E() + "" : "";
            ArmorHUD.mc.field_71466_p.func_175063_a(string, (float)(n4 + 19 - 2 - ArmorHUD.mc.field_71466_p.func_78256_a(string)), (float)(n3 + 9), 0xFFFFFF);
            float f = ((float)itemStack.func_77958_k() - (float)itemStack.func_77952_i()) / (float)itemStack.func_77958_k();
            float f2 = 1.0f - f;
            int n5 = 100 - (int)(f2 * 100.0f);
            ArmorHUD.mc.field_71466_p.func_175063_a(n5 + "", (float)(n4 + 8 - ArmorHUD.mc.field_71466_p.func_78256_a(n5 + "") / 2), (float)(n3 - 11), ArmorHUD.toHex((int)(f2 * 255.0f), (int)(f * 255.0f), 0));
        }
        GlStateManager.func_179126_j();
        GlStateManager.func_179140_f();
    }

    public static int toHex(int n, int n2, int n3) {
        return 0xFF000000 | (n & 0xFF) << 16 | (n2 & 0xFF) << 8 | n3 & 0xFF;
    }

    static {
        itemRender = Minecraft.func_71410_x().func_175599_af();
    }
}
