package com.Blood.Ware.module.hud;

import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.misc.Panic;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleList
extends Module {
    public /* synthetic */ ArrayList<Module> modules;

    public ModuleList() {
        super("ModuleList", Category.HUD);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post post) {
        switch (post.getType()) {
            case TEXT: {
                if (Panic.isPanic) break;
                int n = 0;
                int[] nArray = new int[]{0};
                int n2 = new Color(221, 0, 255, 255).getRGB();
                int n3 = this.rainbowGlow(0.0f);
                Minecraft minecraft = Minecraft.func_71410_x();
                FontRenderer fontRenderer = minecraft.field_71466_p;
                ScaledResolution scaledResolution = new ScaledResolution(minecraft);
                ArrayList<Module> arrayList = new ArrayList<Module>();
                for (Module module3 : ModuleManager.modules) {
                    if (!module3.isToggled()) continue;
                    arrayList.add(module3);
                }
                arrayList.sort((module, module2) -> CastomFontUtils.fr4.getStringWidth(module2.getName()) - CastomFontUtils.fr4.getStringWidth(module.getName()));
                for (Module module3 : arrayList) {
                    Gui.func_73734_a((int)(scaledResolution.func_78326_a() - 3), (int)n, (int)(scaledResolution.func_78326_a() - CastomFontUtils.fr4.getStringWidth(module3.getName()) - 12), (int)(n + 17), (int)ModuleList.rainbow1(0));
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(scaledResolution.func_78326_a() - 6, n - 4, scaledResolution.func_78326_a() - 2, n + 17, 3.0f, 3.0f, n2, n2, n2, n2, false, true, true);
                    CastomFontUtils.fr4.drawString(module3.getName(), scaledResolution.func_78326_a() - CastomFontUtils.fr4.getStringWidth(module3.getName()) - 10, n + 4, ModuleList.rainbow2(0));
                    n -= 22598;
                    n += 22615;
                    nArray[0] = nArray[0] + 1;
                }
                break;
            }
        }
    }

    public static int rainbow(int n) {
        double d = Math.ceil((System.currentTimeMillis() + (long)n) / (0x142765F930C5DE40L ^ 0x142765F930C458E0L));
        d %= 360.0;
        return Color.MAGENTA.getRGB();
    }

    public static int rainbow2(int n) {
        double d = Math.ceil((System.currentTimeMillis() + (long)n) / (0x5D67F65AC69040B2L ^ 0x5D67F65AC691C612L));
        d %= 360.0;
        return Color.MAGENTA.getRGB();
    }

    public static int rainbow1(int n) {
        double d = Math.ceil((System.currentTimeMillis() + (long)n) / (0xC4BFF8627DC57328L ^ 0xC4BFF8627DC4F588L));
        d %= 360.0;
        return Color.white.getRGB();
    }

    public int rainbowGlow(float f) {
        float f2 = (float)(System.currentTimeMillis() % (0x24B85CC294475A3DL ^ 0x24B85CC2944749B5L)) / 5000.0f + f;
        int n = Color.getHSBColor(f2, 1.0f, 1.0f).getRGB();
        return n;
    }
}
