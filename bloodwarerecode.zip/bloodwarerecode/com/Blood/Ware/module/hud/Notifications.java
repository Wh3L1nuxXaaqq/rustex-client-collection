package com.Blood.Ware.module.hud;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.notifications.notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Notifications
extends Module {
    public static /* synthetic */ RenderItem itemRender;
    public /* synthetic */ Entity target;

    public Notifications() {
        super("Notifications", Category.HUD);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text text) {
        if (text.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
            return;
        }
        notifications.show();
    }
}
