package com.Blood.Ware.module.hud;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.hud.HudModule;
import com.Blood.Ware.utils.AnimationUtils;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import com.Blood.Ware.utils.StencilUtil;
import com.Blood.Ware.utils.TimerUtils;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WaterMark
extends HudModule {
    public /* synthetic */ AnimationUtils anim;
    public /* synthetic */ TimerUtils timer;
    public /* synthetic */ WaterType waterType;
    public /* synthetic */ int typingIndex;
    public /* synthetic */ long lastTypeTime;
    public static final /* synthetic */ long TYPE_DELAY = 300L;
    public /* synthetic */ boolean isForward;

    public WaterMark() {
        super("WaterMark", Category.HUD, 100.0f, 15.0f);
        this.anim = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.timer = new TimerUtils();
        this.waterType = WaterType.LETTER;
        this.typingIndex = 0;
        this.lastTypeTime = 0xF7DE9071C4ADE7DBL ^ 0xF7DE9071C4ADE7DBL;
        this.isForward = true;
        this.setPosX(10.0f);
        this.setPosY(10.0f);
        this.setEnabled(true);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post p1) {
        if (p1.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        String v2 = "BloodWare  | FPS " + Minecraft.func_175610_ah();
        String v3 = "RECODE | UID: " + BloodWare.getUID();
        this.setSizeY(25.0f);
        this.setSizeX(CastomFontUtils.fr4.getStringWidth(v2.substring(1, v2.length())) + 15);
        float f4 = this.getPosX();
        float f5 = this.getPosY();
        RenderUtils.drawThemeRect1(f4, f5, f4 + this.getSizeX(), f5 + this.getSizeY());
        int i6 = Color.RED.getRGB();
        int i7 = Color.RED.getRGB();
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(f4, f5, f4 + 10.0f, f5 + this.getSizeY(), 5.0f, 3.0f, i6, i6, i7, i7, false, true, true);
        StencilUtil.initStencilToWrite();
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(f4, f5, f4 + 10.0f, f5 + this.getSizeY(), 5.0f, 3.0f, i6, i6, i7, i7, false, true, true);
        StencilUtil.readStencilBuffer(1);
        if (this.waterType == WaterType.LETTER) {
            CastomFontUtils.fr4.drawCenteredString(v2.substring(0, 1), f4 + 5.0f, f5 + 7.5f + this.anim.getAnim() - (float)(CastomFontUtils.fr4.getHeight() / 2), Color.white.getRGB());
        }
        StencilUtil.uninitStencilBuffer();
        CastomFontUtils.fr4.drawString(v2.substring(1, v2.length()), f4 + 12.0f, f5 + 7.5f - (float)(CastomFontUtils.fr4.getHeight() / 2), Color.pink.getRGB());
        float f8 = f4 + 13.0f;
        float f9 = f5 + 15.0f;
        long j10 = System.currentTimeMillis();
        if (j10 - this.lastTypeTime > (0x556ABB14544F0016L ^ 0x556ABB14544F013AL)) {
            if (this.isForward) {
                if (this.typingIndex < v3.length()) {
                    ++this.typingIndex;
                } else {
                    this.isForward = false;
                }
            } else if (this.typingIndex > 0) {
                --this.typingIndex;
            } else {
                this.isForward = true;
            }
            this.lastTypeTime = j10;
        }
        String v12 = v3.substring(0, Math.min(this.typingIndex, v3.length()));
        CastomFontUtils.fr4.drawString(v12, f8, f9, Color.PINK.getRGB());
    }

    public static enum WaterType {
        LETTER,
        LOGO;

    }
}
