package com.Blood.Ware.module.hud;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;

public class HudModule
extends Module {
    public /* synthetic */ float posX;
    public /* synthetic */ float posY;
    public /* synthetic */ float sizeX;
    public /* synthetic */ float sizeY;

    public HudModule(String string, Category category, float f, float f2) {
        super(string, category);
        this.sizeX = f;
        this.sizeY = f2;
    }

    @Override
    public int getPosX() {
        return (int)this.posX;
    }

    @Override
    public int getPosY() {
        return (int)this.posY;
    }

    public float getSizeX() {
        return this.sizeX;
    }

    public float getSizeY() {
        return this.sizeY;
    }

    public void setSizeX(float f) {
        this.sizeX = f;
    }

    public void setSizeY(float f) {
        this.sizeY = f;
    }

    public void setPosX(float f) {
        this.posX = f;
    }

    public void setPosY(float f) {
        this.posY = f;
    }
}
