package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.GenerateNumber;
import com.Blood.Ware.utils.NullCheck;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Africa
extends Module {
    public /* synthetic */ int africaColor;
    public /* synthetic */ short tickTimer;
    public /* synthetic */ int colorAlpha;

    public Africa() {
        super("Africa", Category.OUTHER);
        this.africaColor = new Color(255, 0, 0, 76).hashCode();
        this.tickTimer = 0;
        this.colorAlpha = 76;
    }

    @Override
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent clientTickEvent) {
        if (NullCheck.nullCheck()) {
            return;
        }
        Africa.mc.field_71439_g.func_70015_d(1);
    }

    @SubscribeEvent
    public void onGuiRender(RenderGameOverlayEvent renderGameOverlayEvent) {
        if (renderGameOverlayEvent.getType() == RenderGameOverlayEvent.ElementType.ALL) {
            Gui.func_73734_a((int)0, (int)0, (int)renderGameOverlayEvent.getResolution().func_78326_a(), (int)renderGameOverlayEvent.getResolution().func_78328_b(), (int)this.africaColor);
            this.tickTimer = (short)(this.tickTimer + 1);
            if (this.tickTimer > 15) {
                int n = (int)((float)this.colorAlpha * GenerateNumber.generateFloat(0.94f, 1.05f));
                if (n > 110) {
                    n = 110;
                } else if (n < 50) {
                    n = 50;
                }
                this.colorAlpha = n;
                this.africaColor = new Color(255, 101, 0, n).hashCode();
                this.tickTimer = 0;
            }
        }
    }
}
