package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import org.lwjgl.opengl.Display;

public class Panic
extends Module {
    public static /* synthetic */ boolean isPanic;

    public Panic() {
        super("Panic", Category.OUTHER);
    }

    @Override
    public void onEnable() {
        isPanic = true;
        Display.setTitle((String)"Minecraft 1.12.2");
        for (Module module : ModuleManager.modules) {
            if (module == this) continue;
            module.setToggled(false);
        }
    }

    @Override
    public void onDisable() {
        isPanic = false;
        Display.setTitle((String)BloodWare.name);
    }

    static {
        isPanic = false;
    }
}
