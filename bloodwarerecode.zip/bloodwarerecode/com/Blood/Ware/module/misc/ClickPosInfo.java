package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.ChatUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickPosInfo
extends Module {
    public ClickPosInfo() {
        super("ClickPosInfo", Category.OUTHER);
    }

    @SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock rightClickBlock) {
        BlockPos blockPos = rightClickBlock.getPos();
        ChatUtils.sendMessage((double)blockPos.func_177958_n() + " " + (double)blockPos.func_177956_o() + " " + (double)blockPos.func_177952_p());
        ChatUtils.sendMessage(String.valueOf(ClickPosInfo.mc.field_71441_e.func_180495_p(blockPos).func_177230_c()));
    }
}
