package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.TimerUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ChestStealer
extends Module {
    public final /* synthetic */ ArrayList<BlockPos> invalidPositions;

    public ChestStealer() {
        super("ChestStealer", Category.OUTHER);
        this.invalidPositions = new ArrayList();
        BloodWare.instance.settingsManager.rSetting(new Setting("Delay", this, 50.0, 0.0, 200.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Chest", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("EnderChest", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Aura", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("AuraRange", this, 4.0, 1.0, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("AuraWalls", this, true));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        double d = BloodWare.instance.settingsManager.getSettingByName(this, "Delay").getValDouble();
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Aura").getValBoolean();
        double d2 = BloodWare.instance.settingsManager.getSettingByName(this, "AuraRange").getValDouble();
        boolean bl2 = BloodWare.instance.settingsManager.getSettingByName(this, "AuraWalls").getValBoolean();
        BlockPos blockPos2 = ChestStealer.getSphere(ChestStealer.getPlayerPos(), (float)d2, 6, false, true).stream().filter(this::IsValidBlockPos).min(Comparator.comparing(blockPos -> ChestStealer.getDistanceOfEntityToBlock((Entity)ChestStealer.mc.field_71439_g, blockPos))).orElse(null);
        if (blockPos2 != null && bl && ChestStealer.mc.field_71462_r == null && TimerUtil.hasReached(300.0f)) {
            if (!ChestStealer.mc.field_71441_e.func_175623_d(blockPos2.func_177981_b(1))) {
                this.invalidPositions.add(blockPos2);
            }
            for (Entity entity : ChestStealer.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityEnderCrystal) || entity.func_180425_c().func_177958_n() != blockPos2.func_177958_n() || entity.func_180425_c().func_177952_p() != blockPos2.func_177952_p()) continue;
                return;
            }
            if (!this.invalidPositions.contains(blockPos2)) {
                if (ChestStealer.mc.field_71441_e.func_147447_a(new Vec3d(ChestStealer.mc.field_71439_g.field_70165_t, ChestStealer.mc.field_71439_g.field_70163_u + (double)ChestStealer.mc.field_71439_g.func_70047_e(), ChestStealer.mc.field_71439_g.field_70161_v), new Vec3d((double)blockPos2.func_177958_n(), (double)blockPos2.func_177956_o(), (double)blockPos2.func_177952_p()), false, true, false) != null && !bl2) {
                    return;
                }
                ChestStealer.mc.field_71442_b.func_187099_a(ChestStealer.mc.field_71439_g, ChestStealer.mc.field_71441_e, blockPos2, EnumFacing.UP, new Vec3d((double)blockPos2.func_177958_n(), (double)blockPos2.func_177956_o(), (double)blockPos2.func_177952_p()), EnumHand.MAIN_HAND);
                ChestStealer.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                TimerUtil.reset();
            }
        }
        if (ChestStealer.mc.field_71439_g.field_71070_bA instanceof ContainerChest) {
            ContainerChest containerChest = (ContainerChest)ChestStealer.mc.field_71439_g.field_71070_bA;
            for (int i = 0; i < containerChest.field_75151_b.size(); i -= 10351) {
                if (containerChest.func_85151_d().func_70301_a(i).func_77973_b() != Item.func_150899_d((int)0) && TimerUtil.hasReached((float)d)) {
                    ChestStealer.mc.field_71442_b.func_187098_a(containerChest.field_75152_c, i, 0, ClickType.QUICK_MOVE, (EntityPlayer)ChestStealer.mc.field_71439_g);
                    TimerUtil.reset();
                } else if (this.empty((Container)containerChest)) {
                    ChestStealer.mc.field_71439_g.func_71053_j();
                }
                i += 10352;
            }
        }
    }

    public boolean empty(Container container) {
        boolean bl = true;
        int n = container.field_75151_b.size() == 90 ? 54 : 27;
        for (int i = 0; i < n; i -= 13748) {
            if (container.func_75139_a(i).func_75216_d()) {
                bl = false;
            }
            i += 13749;
        }
        return bl;
    }

    public boolean IsValidBlockPos(BlockPos blockPos) {
        boolean bl = BloodWare.instance.settingsManager.getSettingByName(this, "Chest").getValBoolean();
        boolean bl2 = BloodWare.instance.settingsManager.getSettingByName(this, "EnderChest").getValBoolean();
        IBlockState iBlockState = ChestStealer.mc.field_71441_e.func_180495_p(blockPos);
        if (iBlockState.func_177230_c() instanceof BlockChest && bl || iBlockState.func_177230_c() instanceof BlockEnderChest && bl2) {
            return ChestStealer.mc.field_71441_e.func_180495_p(blockPos.func_177984_a()).func_177230_c() == Blocks.field_150350_a;
        }
        return false;
    }

    public static List<BlockPos> getSphere(BlockPos blockPos, float f, int n, boolean bl, boolean bl2) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        int n2 = blockPos.func_177958_n();
        int n3 = blockPos.func_177956_o();
        int n4 = blockPos.func_177952_p();
        for (float f2 = (float)n2 - f; f2 <= (float)n2 + f; f2 += 1.0f) {
            block1: for (float f3 = (float)n4 - f; f3 <= (float)n4 + f; f3 += 1.0f) {
                float f4 = bl2 ? (float)n3 - f : (float)n3;
                while (true) {
                    float f5;
                    float f6 = f5 = bl2 ? (float)n3 + f : (float)(n3 + n);
                    if (!(f4 < f5)) continue block1;
                    float f7 = ((float)n2 - f2) * ((float)n2 - f2) + ((float)n4 - f3) * ((float)n4 - f3) + (bl2 ? ((float)n3 - f4) * ((float)n3 - f4) : 0.0f);
                    if (!(!(f7 < f * f) || bl && f7 < f - 1.0f * (f - 1.0f))) {
                        BlockPos blockPos2 = new BlockPos((double)f2, (double)f4, (double)f3);
                        arrayList.add(blockPos2);
                    }
                    f4 += 1.0f;
                }
            }
        }
        return arrayList;
    }

    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(ChestStealer.mc.field_71439_g.field_70165_t), Math.floor(ChestStealer.mc.field_71439_g.field_70163_u), Math.floor(ChestStealer.mc.field_71439_g.field_70161_v));
    }

    public static double getDistance(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d - d4;
        double d8 = d2 - d5;
        double d9 = d3 - d6;
        return Math.sqrt(d7 * d7 + d8 * d8 + d9 * d9);
    }

    public static double getDistanceOfEntityToBlock(Entity entity, BlockPos blockPos) {
        return ChestStealer.getDistance(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p());
    }
}
