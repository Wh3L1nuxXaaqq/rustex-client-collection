package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import das.ist.denger.natve.Native;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Native
public class JoinCheck
extends Module {
    public /* synthetic */ List<String> knownPlayers;

    public JoinCheck() {
        super("JoinCheck", Category.OUTHER);
        this.knownPlayers = new ArrayList<String>();
        BloodWare.instance.settingsManager.rSetting(new Setting("Show Offline", this, false));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.knownPlayers.clear();
        if (JoinCheck.mc.field_71439_g != null && JoinCheck.mc.field_71439_g.field_71174_a != null) {
            Collection collection = JoinCheck.mc.field_71439_g.field_71174_a.func_175106_d();
            for (NetworkPlayerInfo networkPlayerInfo : collection) {
                if (networkPlayerInfo.func_178845_a() == null) continue;
                this.knownPlayers.add(networkPlayerInfo.func_178845_a().getName());
            }
        }
    }

    @Override
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent clientTickEvent) {
        String string;
        if (!this.isToggled() || JoinCheck.mc.field_71439_g == null || JoinCheck.mc.field_71439_g.field_71174_a == null) {
            return;
        }
        if (clientTickEvent.phase != TickEvent.Phase.START) {
            return;
        }
        Collection collection = JoinCheck.mc.field_71439_g.field_71174_a.func_175106_d();
        ArrayList<String> arrayList = new ArrayList<String>();
        for (NetworkPlayerInfo object : collection) {
            if (object.func_178845_a() == null) continue;
            string = object.func_178845_a().getName();
            arrayList.add(string);
            if (this.knownPlayers.contains(string)) continue;
            String string2 = "\u00a77[\u00a7cBloodWare\u00a77] \u00a7f" + string + " \u00a7a\u0437\u0430\u0448\u0435\u043b \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440";
            JoinCheck.mc.field_71439_g.func_145747_a((ITextComponent)new TextComponentString(string2));
            this.knownPlayers.add(string);
        }
        if (BloodWare.instance.settingsManager.getSettingByName(this, "Show Offline").getValBoolean()) {
            for (String string3 : new ArrayList<String>(this.knownPlayers)) {
                if (arrayList.contains(string3)) continue;
                string = "\u00a77[\u00a7cBloodWare\u00a77] \u00a7f" + string3 + " \u00a74\u0432\u044b\u0448\u0435\u043b \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430";
                JoinCheck.mc.field_71439_g.func_145747_a((ITextComponent)new TextComponentString(string));
                this.knownPlayers.remove(string3);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.knownPlayers.clear();
    }
}
