package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.RenderUtils;
import com.Blood.Ware.utils.Rotation;
import com.Blood.Ware.utils.TimerUtils;
import das.ist.denger.natve.Native;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Native
public class AutoMine
extends Module {
    public /* synthetic */ TimerUtils timer;
    public /* synthetic */ BlockPos blockPos;

    public AutoMine() {
        super("AutoMine", Category.OUTHER);
        this.timer = new TimerUtils();
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        if (this.blockPos != null) {
            RenderUtils.blockEspFrame(this.blockPos, 0.0f, 0.0f, 255.0f);
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent clientTickEvent) {
        if (AutoMine.mc.field_71441_e == null || AutoMine.mc.field_71439_g == null) {
            return;
        }
        for (Entity entity : AutoMine.mc.field_71441_e.field_72996_f) {
            if (!(entity.func_70032_d((Entity)AutoMine.mc.field_71439_g) <= 4.0f) || !(entity instanceof EntityArmorStand)) continue;
            ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
            int n = (int)entity.field_70165_t;
            int n2 = (int)entity.field_70161_v;
            for (int i = -2; i < 2; i += 27991) {
                for (int j = -2; j < 2; j += 30791) {
                    Block block = AutoMine.mc.field_71441_e.func_180495_p(new BlockPos((double)(n + i), entity.field_70163_u, (double)(n2 + j))).func_177230_c();
                    if (block != Blocks.field_150350_a && (block == Blocks.field_150406_ce || block == Blocks.field_150482_ag || block == Blocks.field_150352_o || block == Blocks.field_150366_p || block == Blocks.field_150364_r || block == Blocks.field_150363_s)) {
                        arrayList.add(new BlockPos((double)(n + i), entity.field_70163_u, (double)(n2 + j)));
                    }
                    j -= 30790;
                }
                i -= 27990;
            }
            arrayList.sort(Comparator.comparingDouble(blockPos -> entity.func_174818_b(blockPos)));
            if (arrayList.isEmpty()) continue;
            this.blockPos = (BlockPos)arrayList.get(0);
            if (this.blockPos == null) continue;
            float[] fArray = Rotation.getNeededRotations(entity.field_70165_t, entity.field_70163_u + (double)0.37f, entity.field_70161_v, (float)AutoMine.mc.field_71439_g.field_70165_t, (float)AutoMine.mc.field_71439_g.field_70163_u + AutoMine.mc.field_71439_g.func_70047_e(), (float)AutoMine.mc.field_71439_g.field_70161_v);
            AutoMine.mc.field_71439_g.field_70177_z += (fArray[0] - AutoMine.mc.field_71439_g.field_70177_z) * 0.75f;
            AutoMine.mc.field_71439_g.field_70125_A += (fArray[1] - AutoMine.mc.field_71439_g.field_70125_A) * 0.75f;
            if (!this.timer.hasReached(250.0f)) continue;
            AutoMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.blockPos, EnumFacing.DOWN));
            AutoMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            this.timer.reset();
        }
    }
}
