package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AntiZoomSmooth
extends Module {
    public AntiZoomSmooth() {
        super("AntiZoomSmooth", Category.RENDER);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent playerTickEvent) {
        AntiZoomSmooth.mc.field_71474_y.field_74326_T = false;
    }
}
