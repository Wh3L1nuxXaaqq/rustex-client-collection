package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Keystrokes
extends Module {
    public /* synthetic */ int color;
    public /* synthetic */ int color1;

    public Keystrokes() {
        super("Keystrokes", Category.HUD);
        this.color = new Color(255, 255, 255).getRGB();
        this.color1 = new Color(0, 0, 0).getRGB();
        BloodWare.instance.settingsManager.rSetting(new Setting("keyX", this, 1.0, 1.0, 897.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("keyY", this, 1.0, -105.0, 340.0, true));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text text) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "keyX").getValDouble();
            float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "keyY").getValDouble();
            int n = 0;
            int n2 = 0;
            GlStateManager.func_179094_E();
            if (!Keystrokes.mc.field_71474_y.field_74330_P) {
                n = (int)f;
                n2 = (int)f2;
                this.color = Color.white.getRGB();
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 20, n2 + 111, n + 41, n2 + 130, 4.0f, 4.0f, this.color, this.color, this.color, this.color, false, true, true);
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 1, n2 + 130, n + 61, n2 + 150, 4.0f, 4.0f, this.color, this.color, this.color, this.color, false, true, true);
                RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 1, n2 + 155, n + 61, n2 + 170, 4.0f, 4.0f, this.color, this.color, this.color, this.color, false, true, true);
                if (Keystrokes.mc.field_71474_y.field_74351_w.func_151470_d()) {
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 21, n2 + 112, n + 40, n2 + 130, 4.0f, 4.0f, this.color1, this.color1, this.color1, this.color1, false, true, false);
                }
                if (Keystrokes.mc.field_71474_y.field_74368_y.func_151470_d()) {
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 21, n2 + 131, n + 40, n2 + 149, 4.0f, 4.0f, this.color1, this.color1, this.color1, this.color1, false, true, false);
                }
                if (Keystrokes.mc.field_71474_y.field_74370_x.func_151470_d()) {
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 2, n2 + 131, n + 20, n2 + 149, 4.0f, 4.0f, this.color1, this.color1, this.color1, this.color1, false, true, false);
                }
                if (Keystrokes.mc.field_71474_y.field_74366_z.func_151470_d()) {
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 41, n2 + 131, n + 60, n2 + 149, 4.0f, 4.0f, this.color1, this.color1, this.color1, this.color1, false, true, false);
                }
                if (Keystrokes.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n + 2, n2 + 156, n + 60, n2 + 169, 4.0f, 4.0f, this.color1, this.color1, this.color1, this.color1, false, true, false);
                }
                CastomFontUtils.fr6.drawString("W", n + 28, n2 + 117, Color.pink.getRGB());
                CastomFontUtils.fr6.drawString("A", n + 8, n2 + 136, Color.pink.getRGB());
                CastomFontUtils.fr6.drawString("S", n + 28, n2 + 136, Color.pink.getRGB());
                CastomFontUtils.fr6.drawString("D", n + 48, n2 + 136, Color.pink.getRGB());
                float f3 = CastomFontUtils.fr6.getStringWidth("SPACE");
                float f4 = (float)(n + 2) + (58.0f - f3) / 2.0f;
                CastomFontUtils.fr4.drawString("SPACE", f4, n2 + 160, Color.pink.getRGB());
            }
            GlStateManager.func_179121_F();
        }
    }
}
