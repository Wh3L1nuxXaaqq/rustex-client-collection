package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.util.Colors;
import das.ist.denger.natve.Native;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Native
public class Crosshair
extends Module {
    @SubscribeEvent
    public void onUpdate(RenderGameOverlayEvent renderGameOverlayEvent) {
        if (renderGameOverlayEvent.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
            renderGameOverlayEvent.setCanceled(true);
        }
    }

    public boolean isMoving() {
        return BloodWare.instance.settingsManager.getSettingByName(this, "DYNAMIC").getValBoolean() && !Crosshair.mc.field_71439_g.field_70123_F && !Crosshair.mc.field_71439_g.func_70093_af() && (Crosshair.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || Crosshair.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f);
    }

    @SubscribeEvent
    public void Crosshair(RenderGameOverlayEvent.Text text) {
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "red").getValDouble();
            float f2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "green").getValDouble();
            float f3 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "blue").getValDouble();
            float f4 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "GAP").getValDouble();
            float f5 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "WIDTH").getValDouble();
            float f6 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "SIZE").getValDouble();
            int n = (int)f;
            int n2 = (int)f2;
            int n3 = (int)f3;
            int n4 = 255;
            double d = f4;
            double d2 = f5;
            double d3 = f6;
            ScaledResolution scaledResolution = new ScaledResolution(mc);
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - d2, (double)(scaledResolution.func_78328_b() / 2) - d - d3 - (double)(this.isMoving() ? 2 : 0), (double)((float)(scaledResolution.func_78326_a() / 2) + 1.0f) + d2, (double)(scaledResolution.func_78328_b() / 2) - d - (double)(this.isMoving() ? 2 : 0), 0.5, Colors.getColor(n, n2, n3, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - d2, (double)(scaledResolution.func_78328_b() / 2) + d + 1.0 + (double)(this.isMoving() ? 2 : 0) - 0.15, (double)((float)(scaledResolution.func_78326_a() / 2) + 1.0f) + d2, (double)(scaledResolution.func_78328_b() / 2 + 1) + d + d3 + (double)(this.isMoving() ? 2 : 0) - 0.15, 0.5, Colors.getColor(n, n2, n3, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - d - d3 - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)(scaledResolution.func_78328_b() / 2) - d2, (double)(scaledResolution.func_78326_a() / 2) - d - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)((float)(scaledResolution.func_78328_b() / 2) + 1.0f) + d2, 0.5, Colors.getColor(n, n2, n3, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2 + 1) + d + (double)(this.isMoving() ? 2 : 0), (double)(scaledResolution.func_78328_b() / 2) - d2, (double)(scaledResolution.func_78326_a() / 2) + d3 + d + 1.0 + (double)(this.isMoving() ? 2 : 0), (double)((float)(scaledResolution.func_78328_b() / 2) + 1.0f) + d2, 0.5, Colors.getColor(n, n2, n3, 255), new Color(0, 0, 0, 255).getRGB());
        }
    }

    public Crosshair() {
        super("Crosshair", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("red", this, 255.0, 1.0, 255.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("green", this, 255.0, 1.0, 255.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("blue", this, 255.0, 1.0, 255.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("DYNAMIC", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("GAP", this, 0.25, 0.0, 15.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("WIDTH", this, 0.25, 0.0, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("SIZE", this, 1.0, 0.0, 15.0, false));
    }
}
