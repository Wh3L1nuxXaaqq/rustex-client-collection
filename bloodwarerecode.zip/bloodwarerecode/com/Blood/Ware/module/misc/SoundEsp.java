package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Native
public class SoundEsp
extends Module {
    public final /* synthetic */ Minecraft mc;
    public final /* synthetic */ Map<Vec3d, SoundInfo> soundPositions;
    public final /* synthetic */ int DISPLAY_TIME = 5000;

    public SoundEsp() {
        super("SoundESP", Category.OUTHER);
        this.mc = Minecraft.func_71410_x();
        this.soundPositions = new ConcurrentHashMap<Vec3d, SoundInfo>();
        this.DISPLAY_TIME = 5000;
    }

    @SubscribeEvent
    public void onSound(PlaySoundEvent playSoundEvent) {
        if (this.mc.field_71441_e == null || this.mc.field_71439_g == null || !this.isToggled()) {
            return;
        }
        Vec3d vec3d = new Vec3d(playSoundEvent.getSound().func_147649_g(), playSoundEvent.getSound().func_147654_h(), playSoundEvent.getSound().func_147651_i());
        this.soundPositions.put(vec3d, new SoundInfo(playSoundEvent.getName()));
    }

    @SubscribeEvent
    public void onRender3D(RenderWorldLastEvent renderWorldLastEvent) {
        if (this.mc.func_175598_ae() == null || this.mc.func_175598_ae().field_78733_k == null || !this.isToggled()) {
            return;
        }
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a((boolean)false);
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        long l = System.currentTimeMillis();
        this.soundPositions.entrySet().removeIf(entry -> l - ((SoundInfo)entry.getValue()).timestamp > (0x80557DB1F6250F41L ^ 0x80557DB1F6251CC9L));
        for (Map.Entry<Vec3d, SoundInfo> entry2 : this.soundPositions.entrySet()) {
            Vec3d vec3d = entry2.getKey();
            SoundInfo soundInfo = entry2.getValue();
            float f = (float)(l - soundInfo.timestamp) / 5000.0f;
            soundInfo.alpha = Math.max(0.0f, 1.0f - f);
            double d = vec3d.x - this.mc.func_175598_ae().field_78730_l;
            double d2 = vec3d.y - this.mc.func_175598_ae().field_78731_m;
            double d3 = vec3d.z - this.mc.func_175598_ae().field_78728_n;
            double d4 = Math.sqrt(d * d + d2 * d2 + d3 * d3);
            float f2 = (float)Math.max((double)0.025f, Math.min((double)0.06f, d4 * (double)0.0025f));
            GlStateManager.func_179094_E();
            GlStateManager.func_179137_b((double)d, (double)d2, (double)d3);
            GlStateManager.func_179129_p();
            GlStateManager.func_179114_b((float)(-this.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)((float)(this.mc.field_71474_y.field_74320_O == 2 ? -1 : 1) * this.mc.func_175598_ae().field_78732_j), (float)1.0f, (float)0.0f, (float)0.0f);
            GlStateManager.func_179152_a((float)(-f2), (float)(-f2), (float)f2);
            float f3 = CastomFontUtils.fr4.getStringWidth(soundInfo.name) + 4;
            float f4 = 15.0f;
            int n = (int)(soundInfo.alpha * 255.0f);
            int n2 = new Color(255, 255, 255).getRGB();
            RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(-f3 / 2.0f, -2.0f, f3 / 2.0f, f4, 4.0f, 4.0f, n2, n2, n2, n2, false, true, true);
            CastomFontUtils.fr4.drawString(soundInfo.name, -(CastomFontUtils.fr4.getStringWidth(soundInfo.name) / 2), 2.0f, new Color(221, 0, 255).getRGB());
            GlStateManager.func_179121_F();
        }
        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.soundPositions.clear();
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.soundPositions.clear();
    }

    private static class Vec3d {
        public /* synthetic */ double x;
        public /* synthetic */ double y;
        public /* synthetic */ double z;

        public Vec3d(double d, double d2, double d3) {
            this.x = d;
            this.y = d2;
            this.z = d3;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof Vec3d)) {
                return false;
            }
            Vec3d vec3d = (Vec3d)object;
            return Double.compare(vec3d.x, this.x) == 0 && Double.compare(vec3d.y, this.y) == 0 && Double.compare(vec3d.z, this.z) == 0;
        }

        public int hashCode() {
            int n = 17;
            long l = Double.doubleToLongBits(this.x);
            long l2 = Double.doubleToLongBits(this.y);
            long l3 = Double.doubleToLongBits(this.z);
            n = 31 * n + (int)(l ^ l >>> 32);
            n = 31 * n + (int)(l2 ^ l2 >>> 32);
            n = 31 * n + (int)(l3 ^ l3 >>> 32);
            return n;
        }
    }

    private static class SoundInfo {
        public /* synthetic */ String name;
        public /* synthetic */ long timestamp;
        public /* synthetic */ float alpha;

        public SoundInfo(String string) {
            this.name = string;
            this.timestamp = System.currentTimeMillis();
            this.alpha = 1.0f;
        }
    }
}
