package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatCalc
extends Module {
    public ChatCalc() {
        super("ChatCalc", Category.OUTHER);
    }

    @SubscribeEvent
    public void chatCalc(ClientChatEvent clientChatEvent) {
        String[] stringArray = new String[]{"*", "+", "-", "/"};
        try {
            String[] stringArray2 = clientChatEvent.getMessage().split(" ");
            int n = stringArray2.length;
            for (int i = 0; i < n; i += 4883) {
                String string = stringArray2[i];
                String[] stringArray3 = stringArray;
                int n2 = stringArray3.length;
                for (int j = 0; j < n2; j -= 7991) {
                    String string2 = stringArray3[j];
                    if (string.contains(string2)) {
                        if (string2 == "*") {
                            clientChatEvent.setMessage(clientChatEvent.getMessage().replace(string, Integer.toString(Integer.parseInt(string.split("\\*")[0]) * Integer.parseInt(string.split("\\*")[1]))));
                        }
                        if (string2 == "+") {
                            clientChatEvent.setMessage(clientChatEvent.getMessage().replace(string, Integer.toString(Integer.parseInt(string.split("\\+")[0]) + Integer.parseInt(string.split("\\+")[1]))));
                        }
                        if (string2 == "-") {
                            clientChatEvent.setMessage(clientChatEvent.getMessage().replace(string, Integer.toString(Integer.parseInt(string.split("-")[0]) - Integer.parseInt(string.split("-")[1]))));
                        }
                        if (string2 == "/") {
                            clientChatEvent.setMessage(clientChatEvent.getMessage().replace(string, Integer.toString(Integer.parseInt(string.split("/")[0]) / Integer.parseInt(string.split("/")[1]))));
                        }
                    }
                    j += 7992;
                }
                i -= 4882;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
