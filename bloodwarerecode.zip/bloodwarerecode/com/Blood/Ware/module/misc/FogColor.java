package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FogColor
extends Module {
    public static /* synthetic */ List Modes;
    public /* synthetic */ long spin;

    public FogColor() {
        super("FogColor", Category.OUTHER);
        this.spin = 0xF6BDA4846424DC72L ^ 0xF6BDA4846424DC72L;
        Modes.add("Spin");
        Modes.add("Day");
        Modes.add("Night");
        Modes.add("Morning");
        Modes.add("Sunset");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "Day", (ArrayList<String>)((ArrayList)Modes)));
        BloodWare.instance.settingsManager.rSetting(new Setting("TimeSpin Speed", this, 2.0, 1.0, 10.0, false));
    }

    @SubscribeEvent
    public void onUpdate(EntityViewRenderEvent.FogColors fogColors) {
        String string = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        float f = (float)BloodWare.instance.settingsManager.getSettingByName(this, "TimeSpin Speed").getValDouble();
        if (string.equalsIgnoreCase("Spin")) {
            FogColor.mc.field_71441_e.func_72877_b(this.spin);
            this.spin += (long)(f * 100.0f);
        } else if (string.equalsIgnoreCase("Day")) {
            FogColor.mc.field_71441_e.func_72877_b(0xE72195FBC6E04AB4L ^ 0xE72195FBC6E0593CL);
        } else if (string.equalsIgnoreCase("Night")) {
            FogColor.mc.field_71441_e.func_72877_b(0x35FC1CEB49C241BBL ^ 0x35FC1CEB49C203D3L);
        } else if (string.equalsIgnoreCase("Morning")) {
            FogColor.mc.field_71441_e.func_72877_b(0x71884B2297C3E7A9L ^ 0x71884B2297C3E7A9L);
        } else if (string.equalsIgnoreCase("Sunset")) {
            FogColor.mc.field_71441_e.func_72877_b(0xCD4D1EBA4531FC17L ^ 0xCD4D1EBA4531CEDFL);
        }
    }

    @SubscribeEvent
    public void onFogColorRender(EntityViewRenderEvent.FogColors fogColors) {
        Color color = Color.getHSBColor((float)(Math.ceil(System.currentTimeMillis() + (0x8FE4226CDD679B1AL ^ 0x8FE4226CDD679A36L) + (0x5180CA4708117FD6L ^ 0x5180CA4708117EFAL)) / 15.0 % 360.0 / 360.0), 0.4f, 1.0f);
        fogColors.setRed((float)color.getRed() / 255.0f);
        fogColors.setGreen((float)color.getGreen() / 255.0f);
        fogColors.setBlue((float)color.getBlue() / 255.0f);
    }

    static {
        Modes = new ArrayList();
    }
}
