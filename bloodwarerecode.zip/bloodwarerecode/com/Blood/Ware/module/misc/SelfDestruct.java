package com.Blood.Ware.module.misc;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class SelfDestruct
extends Module {
    public static /* synthetic */ boolean self;

    public SelfDestruct() {
        super("SelfDestruct", Category.OUTHER);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        mc.func_147108_a(null);
        for (Module module : BloodWare.moduleManager.getModuleList()) {
            if (module.getName() == "SelfDestruct") continue;
        }
        self = true;
        SelfDestruct.mc.field_71439_g.field_70177_z = 0.0f;
        SelfDestruct.mc.field_71439_g.field_70125_A = 0.0f;
    }

    static {
        self = false;
    }
}
