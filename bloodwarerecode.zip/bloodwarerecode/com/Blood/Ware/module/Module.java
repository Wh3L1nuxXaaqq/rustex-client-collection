package com.Blood.Ware.module;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.misc.SelfDestruct;
import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.notifications.notifications;
import com.Blood.Ware.settings.Setting;
import das.ist.denger.natve.Native;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Native
public abstract class Module {
    public static /* synthetic */ Minecraft mc;
    public /* synthetic */ String name;
    public /* synthetic */ String description;
    public /* synthetic */ int key;
    public /* synthetic */ Category category;
    public /* synthetic */ boolean toggled;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ boolean visible;
    public /* synthetic */ boolean hud;
    public /* synthetic */ boolean enabled;
    public /* synthetic */ Setting parent;

    public Module(String string, Category category) {
        this.visible = true;
        this.enabled = false;
        this.parent = null;
        this.name = string;
        this.description = this.description;
        this.key = 0;
        this.category = category;
        this.toggled = false;
    }

    public int getPosY() {
        return this.posY;
    }

    public int getPosX() {
        return this.posX;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String string) {
        this.description = string;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int n) {
        this.key = n;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public void setEnabled(boolean bl) {
        this.enabled = bl;
        if (this.isEnabled()) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void setToggled(boolean bl) {
        if (this.toggled == bl) {
            return;
        }
        this.toggled = bl;
        if (!SelfDestruct.self) {
            if (this.toggled) {
                this.onEnable();
            } else {
                this.onDisable();
            }
        }
    }

    public void toggle() {
        boolean bl = this.toggled = !this.toggled;
        if (!SelfDestruct.self) {
            if (this.toggled) {
                this.onEnableR();
            } else {
                this.onDisableR();
            }
        }
    }

    public void onEnable() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        notifications.add(this.name, "Enable!", Type.Green);
    }

    public boolean onEnableR() {
        this.onEnable();
        return false;
    }

    public void onDisableR() {
        this.onDisable();
    }

    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        notifications.add(this.name, "Disable!", Type.Red);
    }

    public void onClientTick(TickEvent.ClientTickEvent clientTickEvent) {
    }

    public String getName() {
        return this.name;
    }

    public Category getCategory() {
        return this.category;
    }

    public void onCameraSetup(EntityViewRenderEvent.CameraSetup cameraSetup) {
    }

    public boolean isToggler() {
        return this.toggled;
    }

    public boolean isHud() {
        return this.hud;
    }

    public void setHud(boolean bl) {
        this.hud = bl;
    }

    static {
        mc = Minecraft.func_71410_x();
    }
}
