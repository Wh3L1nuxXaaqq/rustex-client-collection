package com.Blood.Ware.miscs;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.miscs.discordhelper.DiscordEventHandlers;
import com.Blood.Ware.miscs.discordhelper.DiscordRPC;
import com.Blood.Ware.miscs.discordhelper.DiscordRichPresence;
import das.ist.denger.natve.Native;

@Native
public class Discord {
    public static /* synthetic */ String discordID;
    public static /* synthetic */ DiscordRichPresence discordRichP;
    public static /* synthetic */ DiscordRPC discordRPC;

    public static void startRPC() {
        DiscordEventHandlers v0 = new DiscordEventHandlers();
        v0.disconnected = (p0, p1) -> System.out.println("Discord RPC disconnected, var1:" + p0 + ", var2: " + p1);
        discordRPC.Discord_Initialize(discordID, v0, true, null);
        Discord.discordRichP.startTimestamp = System.currentTimeMillis() / (0x438C6746E5B1C15CL ^ 0x438C6746E5B1C2B4L);
        Discord.discordRichP.details = "User: " + BloodWare.getUSER() + " | Build: Beta";
        DiscordRichPresence discordRichPresence = discordRichP;
        ((DiscordRichPresence)((Object)"https://i.imgur.com/OPAoihs.gif")).largeImageKey = "bdsys";
        Discord.discordRichP.largeImageText = "bdsys";
        Discord.discordRichP.state = "UID: " + BloodWare.getUID() + " | Role: " + BloodWare.getROLE();
        discordRPC.Discord_UpdatePresence(discordRichP);
    }

    public static void stopRPC() {
        discordRPC.Discord_Shutdown();
        discordRPC.Discord_ClearPresence();
    }

    static {
        String string = "1292514930138021910";
        discordID = "1312730472299626508";
        discordRichP = new DiscordRichPresence();
        discordRPC = DiscordRPC.INSTANCE;
    }
}
