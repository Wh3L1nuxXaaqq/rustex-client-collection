package com.Blood.Ware.miscs.discordhelper;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class DiscordUser
extends Structure {
    public static final /* synthetic */ List<String> FIELD_ORDER;
    public /* synthetic */ String userId;
    public /* synthetic */ String username;
    public /* synthetic */ String discriminator;
    public /* synthetic */ String avatar;

    public DiscordUser(String string) {
        this.setStringEncoding(string);
    }

    public DiscordUser() {
        this("UTF-8");
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof DiscordUser)) {
            return false;
        }
        DiscordUser discordUser = (DiscordUser)((Object)object);
        return Objects.equals(this.userId, discordUser.userId) && Objects.equals(this.username, discordUser.username) && Objects.equals(this.discriminator, discordUser.discriminator) && Objects.equals(this.avatar, discordUser.avatar);
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.username, this.discriminator, this.avatar);
    }

    public List<String> getFieldOrder() {
        return FIELD_ORDER;
    }

    static {
        FIELD_ORDER = Collections.unmodifiableList(Arrays.asList("userId", "username", "discriminator", "avatar"));
    }
}
