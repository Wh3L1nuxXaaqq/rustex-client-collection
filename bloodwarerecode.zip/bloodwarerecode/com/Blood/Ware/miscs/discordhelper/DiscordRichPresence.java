package com.Blood.Ware.miscs.discordhelper;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class DiscordRichPresence
extends Structure {
    public static final /* synthetic */ List<String> FIELD_ORDER;
    public /* synthetic */ String state;
    public /* synthetic */ String details;
    public /* synthetic */ long startTimestamp;
    public /* synthetic */ long endTimestamp;
    public /* synthetic */ String largeImageKey;
    public /* synthetic */ String largeImageText;
    public /* synthetic */ String smallImageKey;
    public /* synthetic */ String smallImageText;
    public /* synthetic */ String partyId;
    public /* synthetic */ int partySize;
    public /* synthetic */ int partyMax;
    public /* synthetic */ String matchSecret;
    public /* synthetic */ String joinSecret;
    public /* synthetic */ String spectateSecret;
    public /* synthetic */ byte instance;

    public DiscordRichPresence(String string) {
        this.setStringEncoding(string);
    }

    public DiscordRichPresence() {
        this("UTF-8");
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof DiscordRichPresence)) {
            return false;
        }
        DiscordRichPresence discordRichPresence = (DiscordRichPresence)((Object)object);
        return this.startTimestamp == discordRichPresence.startTimestamp && this.endTimestamp == discordRichPresence.endTimestamp && this.partySize == discordRichPresence.partySize && this.partyMax == discordRichPresence.partyMax && this.instance == discordRichPresence.instance && Objects.equals(this.state, discordRichPresence.state) && Objects.equals(this.details, discordRichPresence.details) && Objects.equals(this.largeImageKey, discordRichPresence.largeImageKey) && Objects.equals(this.largeImageText, discordRichPresence.largeImageText) && Objects.equals(this.smallImageKey, discordRichPresence.smallImageKey) && Objects.equals(this.smallImageText, discordRichPresence.smallImageText) && Objects.equals(this.partyId, discordRichPresence.partyId) && Objects.equals(this.matchSecret, discordRichPresence.matchSecret) && Objects.equals(this.joinSecret, discordRichPresence.joinSecret) && Objects.equals(this.spectateSecret, discordRichPresence.spectateSecret);
    }

    public int hashCode() {
        return Objects.hash(this.state, this.details, this.startTimestamp, this.endTimestamp, this.largeImageKey, this.largeImageText, this.smallImageKey, this.smallImageText, this.partyId, this.partySize, this.partyMax, this.matchSecret, this.joinSecret, this.spectateSecret, this.instance);
    }

    public List<String> getFieldOrder() {
        return FIELD_ORDER;
    }

    static {
        FIELD_ORDER = Collections.unmodifiableList(Arrays.asList("state", "details", "startTimestamp", "endTimestamp", "largeImageKey", "largeImageText", "smallImageKey", "smallImageText", "partyId", "partySize", "partyMax", "matchSecret", "joinSecret", "spectateSecret", "instance"));
    }
}
