package com.Blood.Ware.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderModelEvent
extends Event {
    public final /* synthetic */ IBlockState state;

    public RenderModelEvent(IBlockState iBlockState) {
        this.state = iBlockState;
    }

    public IBlockState getState() {
        return this.state;
    }
}
