package com.Blood.Ware.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Event;

public class ShouldSideBeRenderedEvent
extends Event {
    public final /* synthetic */ IBlockState blockState;
    public /* synthetic */ boolean shouldBeRendered;

    public ShouldSideBeRenderedEvent(IBlockState iBlockState, boolean bl) {
        this.blockState = iBlockState;
        this.shouldBeRendered = bl;
    }

    public IBlockState getBlockState() {
        return this.blockState;
    }

    public boolean getShouldBeRendered() {
        return this.shouldBeRendered;
    }

    public void setShouldBeRendered(boolean bl) {
        this.shouldBeRendered = bl;
    }
}
