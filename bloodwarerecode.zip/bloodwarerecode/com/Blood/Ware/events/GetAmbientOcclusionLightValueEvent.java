package com.Blood.Ware.events;

import das.ist.denger.natve.Native;
import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Event;

@Native
public class GetAmbientOcclusionLightValueEvent
extends Event {
    public /* synthetic */ float lightValue;

    public GetAmbientOcclusionLightValueEvent(IBlockState iBlockState) {
        this.lightValue = iBlockState.func_177230_c().func_185485_f(iBlockState);
    }

    public float getLightValue() {
        return this.lightValue;
    }

    public void setLightValue(float f) {
        this.lightValue = f;
    }
}
