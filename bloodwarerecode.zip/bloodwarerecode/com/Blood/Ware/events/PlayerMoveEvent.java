package com.Blood.Ware.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class PlayerMoveEvent
extends Event {
    public /* synthetic */ double x;
    public /* synthetic */ double y;
    public /* synthetic */ double z;

    public PlayerMoveEvent(double d, double d2, double d3) {
        this.x = d;
        this.y = d2;
        this.z = d3;
    }
}
