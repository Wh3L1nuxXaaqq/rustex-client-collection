package com.Blood.Ware.events;

import net.minecraft.block.Block;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GetLiquidCollisionBoundingBoxEvent
extends Event {
    public /* synthetic */ AxisAlignedBB collisionBoundingBox;

    public GetLiquidCollisionBoundingBoxEvent() {
        this.collisionBoundingBox = Block.field_185506_k;
    }

    public AxisAlignedBB getCollisionBoundingBox() {
        return this.collisionBoundingBox;
    }

    public void setCollisionBoundingBox(AxisAlignedBB axisAlignedBB) {
        this.collisionBoundingBox = axisAlignedBB;
    }
}
