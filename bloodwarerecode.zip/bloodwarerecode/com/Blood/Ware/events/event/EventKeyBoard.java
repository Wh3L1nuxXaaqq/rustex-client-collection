package com.Blood.Ware.events.event;

import com.Blood.Ware.events.event.Event;

public class EventKeyBoard
extends Event {
    public /* synthetic */ int key;

    public EventKeyBoard(int n) {
        this.key = n;
    }

    public int getKey() {
        return this.key;
    }
}
