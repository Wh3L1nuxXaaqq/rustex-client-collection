package com.Blood.Ware.events.event;

import com.Blood.Ware.events.event.Event;

public class EventRender2D
extends Event {
    public /* synthetic */ float partialTicks;

    public EventRender2D(float f) {
        this.partialTicks = f;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}
