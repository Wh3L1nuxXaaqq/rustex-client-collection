package com.Blood.Ware.events.event;

public class Priority {
    public static final /* synthetic */ byte FIRST = 0;
    public static final /* synthetic */ byte SECOND = 1;
    public static final /* synthetic */ byte THIRD = 2;
    public static final /* synthetic */ byte FOURTH = 3;
    public static final /* synthetic */ byte FIFTH = 4;
    public static final /* synthetic */ byte[] VALUE_ARRAY;

    static {
        VALUE_ARRAY = new byte[]{0, 1, 2, 3, 4};
    }
}
