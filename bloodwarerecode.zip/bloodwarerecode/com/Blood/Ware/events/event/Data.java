package com.Blood.Ware.events.event;

import java.lang.reflect.Method;

public class Data {
    public final /* synthetic */ Object source;
    public final /* synthetic */ Method target;
    public final /* synthetic */ byte priority;

    public Data(Object object, Method method, byte by) {
        this.source = object;
        this.target = method;
        this.priority = by;
    }
}
