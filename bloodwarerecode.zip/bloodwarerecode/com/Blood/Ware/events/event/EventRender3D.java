package com.Blood.Ware.events.event;

import com.Blood.Ware.events.event.Event;

public class EventRender3D
extends Event {
    public /* synthetic */ float partialTicks;

    public EventRender3D(float f) {
        this.partialTicks = f;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}
