package com.Blood.Ware.events.event;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.events.event.ArrayHelper;
import com.Blood.Ware.events.event.Data;
import com.Blood.Ware.events.event.EventManager;
import java.lang.reflect.InvocationTargetException;

public abstract class Event {
    public /* synthetic */ boolean cancelled;

    public Event call() {
        this.cancelled = false;
        Event.call(this);
        return this;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean bl) {
        this.cancelled = bl;
    }

    public static void call(Event event) {
        EventManager eventManager = BloodWare.eventManager;
        ArrayHelper<Data> arrayHelper = EventManager.get(event.getClass());
        if (arrayHelper != null) {
            for (Data data : arrayHelper) {
                try {
                    data.target.invoke(data.source, event);
                }
                catch (IllegalAccessException illegalAccessException) {
                    illegalAccessException.printStackTrace();
                }
                catch (InvocationTargetException invocationTargetException) {
                    invocationTargetException.printStackTrace();
                }
            }
        }
    }
}
