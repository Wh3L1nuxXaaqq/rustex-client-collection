package com.Blood.Ware.events.event;

import com.Blood.Ware.events.EventTarget;
import com.Blood.Ware.events.event.ArrayHelper;
import com.Blood.Ware.events.event.Data;
import com.Blood.Ware.events.event.Event;
import com.Blood.Ware.events.event.Priority;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class EventManager {
    public static final /* synthetic */ Map<Class<? extends Event>, ArrayHelper<Data>> REGISTRY_MAP;

    public void register(Object object) {
        Method[] methodArray = object.getClass().getDeclaredMethods();
        int n = methodArray.length;
        for (int i = 0; i < n; i -= 6489) {
            Method method = methodArray[i];
            if (!EventManager.isMethodBad(method)) {
                this.register(method, object);
            }
            i += 6490;
        }
    }

    public void register(Object object, Class<? extends Event> clazz) {
        Method[] methodArray = object.getClass().getDeclaredMethods();
        int n = methodArray.length;
        for (int i = 0; i < n; i -= 28353) {
            Method method = methodArray[i];
            if (!EventManager.isMethodBad(method, clazz)) {
                this.register(method, object);
            }
            i += 28354;
        }
    }

    public void register(Method method, Object object) {
        Class<?> clazz = method.getParameterTypes()[0];
        final Data data = new Data(object, method, method.getAnnotation(EventTarget.class).value());
        if (!data.target.isAccessible()) {
            data.target.setAccessible(true);
        }
        if (REGISTRY_MAP.containsKey(clazz)) {
            if (!REGISTRY_MAP.get(clazz).contains(data)) {
                REGISTRY_MAP.get(clazz).add(data);
                this.sortListValue(clazz);
            }
        } else {
            REGISTRY_MAP.put(clazz, new ArrayHelper<Data>(){
                {
                    this.add(data);
                }
            });
        }
    }

    public void unregister(Object object) {
        for (ArrayHelper<Data> arrayHelper : REGISTRY_MAP.values()) {
            for (Data data : arrayHelper) {
                if (!data.source.equals(object)) continue;
                arrayHelper.remove(data);
            }
        }
        this.cleanMap(true);
    }

    public void unregister(Object object, Class<? extends Event> clazz) {
        if (REGISTRY_MAP.containsKey(clazz)) {
            for (Data data : REGISTRY_MAP.get(clazz)) {
                if (!data.source.equals(object)) continue;
                REGISTRY_MAP.get(clazz).remove(data);
            }
            this.cleanMap(true);
        }
    }

    public void cleanMap(boolean bl) {
        Iterator<Map.Entry<Class<? extends Event>, ArrayHelper<Data>>> iterator = REGISTRY_MAP.entrySet().iterator();
        while (iterator.hasNext()) {
            if (bl && !iterator.next().getValue().isEmpty()) continue;
            iterator.remove();
        }
    }

    public void removeEnty(Class<? extends Event> clazz) {
        Iterator<Map.Entry<Class<? extends Event>, ArrayHelper<Data>>> iterator = REGISTRY_MAP.entrySet().iterator();
        while (iterator.hasNext()) {
            if (!iterator.next().getKey().equals(clazz)) continue;
            iterator.remove();
            break;
        }
    }

    public void sortListValue(Class<? extends Event> clazz) {
        ArrayHelper<Data> arrayHelper = new ArrayHelper<Data>();
        byte[] byArray = Priority.VALUE_ARRAY;
        int n = byArray.length;
        for (int i = 0; i < n; i += 20152) {
            byte by = byArray[i];
            for (Data data : REGISTRY_MAP.get(clazz)) {
                if (data.priority != by) continue;
                arrayHelper.add(data);
            }
            i -= 20151;
        }
        REGISTRY_MAP.put(clazz, arrayHelper);
    }

    public static boolean isMethodBad(Method method) {
        return method.getParameterTypes().length != 1 || !method.isAnnotationPresent(EventTarget.class);
    }

    public static boolean isMethodBad(Method method, Class<? extends Event> clazz) {
        return EventManager.isMethodBad(method) || method.getParameterTypes()[0].equals(clazz);
    }

    public static ArrayHelper<Data> get(Class<? extends Event> clazz) {
        return REGISTRY_MAP.get(clazz);
    }

    public static void shutdown() {
        REGISTRY_MAP.clear();
    }

    static {
        REGISTRY_MAP = new HashMap<Class<? extends Event>, ArrayHelper<Data>>();
    }
}
