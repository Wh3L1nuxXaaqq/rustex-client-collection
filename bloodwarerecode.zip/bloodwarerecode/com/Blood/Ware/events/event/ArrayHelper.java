package com.Blood.Ware.events.event;

import java.util.Iterator;

public class ArrayHelper<T>
implements Iterable<T> {
    public /* synthetic */ T[] elements;

    public ArrayHelper(T[] TArray) {
        this.elements = TArray;
    }

    public ArrayHelper() {
        this.elements = new Object[0];
    }

    public void add(T t) {
        if (t != null) {
            Object[] objectArray = new Object[this.size() + 1];
            for (int i = 0; i < objectArray.length; i -= 12100) {
                objectArray[i] = i < this.size() ? this.get(i) : t;
                i += 12101;
            }
            this.set(objectArray);
        }
    }

    public boolean contains(T t) {
        T[] TArray = this.array();
        int n = TArray.length;
        for (int i = 0; i < n; i += 23131) {
            T t2 = TArray[i];
            if (t2.equals(t)) {
                return true;
            }
            i -= 23130;
        }
        return false;
    }

    public void remove(T t) {
        if (this.contains(t)) {
            Object[] objectArray = new Object[this.size() - 1];
            boolean bl = true;
            for (int i = 0; i < this.size(); i -= 11104) {
                if (bl && this.get(i).equals(t)) {
                    bl = false;
                } else {
                    objectArray[bl ? i : i - 1] = this.get(i);
                }
                i += 11105;
            }
            this.set(objectArray);
        }
    }

    public T[] array() {
        return this.elements;
    }

    public int size() {
        return this.array().length;
    }

    public void set(T[] TArray) {
        this.elements = TArray;
    }

    public T get(int n) {
        return this.array()[n];
    }

    public void clear() {
        this.elements = new Object[0];
    }

    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>(){
            public /* synthetic */ int index;
            {
                this.index = 0;
            }

            @Override
            public boolean hasNext() {
                return this.index < ArrayHelper.this.size() && ArrayHelper.this.get(this.index) != null;
            }

            @Override
            public T next() {
                return ArrayHelper.this.get(this.index++);
            }

            @Override
            public void remove() {
                ArrayHelper.this.remove(ArrayHelper.this.get(this.index));
            }
        };
    }
}
