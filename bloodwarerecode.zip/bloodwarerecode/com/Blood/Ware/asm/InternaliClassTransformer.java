package com.Blood.Ware.asm;

import com.Blood.Ware.asm.visitors.BlockLiquidVisitor;
import com.Blood.Ware.asm.visitors.BlockRendererDispatcherVisitor;
import com.Blood.Ware.asm.visitors.BlockStateContainerVisitor;
import com.Blood.Ware.asm.visitors.EntityPlayerSPVisitor;
import com.Blood.Ware.asm.visitors.EntityRendererVisitor;
import com.Blood.Ware.asm.visitors.NetworkManagerVisitor;
import com.Blood.Ware.asm.visitors.VisGraphVisitor;
import java.util.Arrays;
import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;

public class InternaliClassTransformer
implements IClassTransformer {
    public static final /* synthetic */ String[] transformedClasses;

    public byte[] transform(String string, String string2, byte[] byArray) {
        boolean bl = !string.equals(string2);
        int n = Arrays.asList(transformedClasses).indexOf(string2);
        return n != -1 ? this.transform(n, byArray, bl) : byArray;
    }

    public byte[] transform(int n, byte[] byArray, boolean bl) {
        System.out.println("Transforming " + transformedClasses[n]);
        try {
            ClassVisitor classVisitor;
            ClassReader classReader = new ClassReader(byArray);
            ClassWriter classWriter = new ClassWriter(3);
            switch (n) {
                case 0: {
                    classVisitor = new VisGraphVisitor(classWriter, bl);
                    break;
                }
                case 1: {
                    classVisitor = new EntityRendererVisitor(classWriter, bl);
                    break;
                }
                case 2: {
                    classVisitor = new NetworkManagerVisitor(classWriter, bl);
                    break;
                }
                case 3: {
                    classVisitor = new BlockRendererDispatcherVisitor(classWriter, bl);
                    break;
                }
                case 4: {
                    classVisitor = new BlockStateContainerVisitor(classWriter, bl);
                    break;
                }
                case 5: {
                    classVisitor = new BlockLiquidVisitor(classWriter, bl);
                    break;
                }
                case 6: {
                    classVisitor = new EntityPlayerSPVisitor(classWriter, bl);
                    break;
                }
                default: {
                    classVisitor = new ClassVisitor(327680, classWriter){};
                }
            }
            classReader.accept(classVisitor, 0);
            return classWriter.toByteArray();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return byArray;
        }
    }

    static {
        transformedClasses = new String[]{"net.minecraft.client.renderer.chunk.VisGraph", "net.minecraft.client.renderer.EntityRenderer", "net.minecraft.network.NetworkManager", "net.minecraft.client.renderer.BlockRendererDispatcher", "net.minecraft.block.state.BlockStateContainer$StateImplementation", "net.minecraft.block.BlockLiquid", "net.minecraft.client.entity.EntityPlayerSP"};
    }
}
