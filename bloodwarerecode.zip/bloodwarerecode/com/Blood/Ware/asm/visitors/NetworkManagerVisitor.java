package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class NetworkManagerVisitor
extends ClassVisitor {
    public final /* synthetic */ String SEND_PACKET;
    public final /* synthetic */ String SEND_PACKET_DESCRIPTOR;
    public final /* synthetic */ String SEND_PACKET_DESCRIPTOR2;
    public final /* synthetic */ String CHANNEL_READ_0;
    public final /* synthetic */ String CHANNEL_READ_0_DESCRIPTOR;

    public NetworkManagerVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.SEND_PACKET = bl ? "a" : "sendPacket";
        this.SEND_PACKET_DESCRIPTOR = bl ? "(Lht;)V" : "(Lnet/minecraft/network/Packet;)V";
        this.SEND_PACKET_DESCRIPTOR2 = bl ? "(Lht;Lio/netty/util/concurrent/GenericFutureListener;[Lio/netty/util/concurrent/GenericFutureListener;)V" : "(Lnet/minecraft/network/Packet;Lio/netty/util/concurrent/GenericFutureListener;[Lio/netty/util/concurrent/GenericFutureListener;)V";
        this.CHANNEL_READ_0 = bl ? "a" : "channelRead0";
        this.CHANNEL_READ_0_DESCRIPTOR = bl ? "(Lio/netty/channel/ChannelHandlerContext;Lht;)V" : "(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/Packet;)V";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = this.cv.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.SEND_PACKET) && (string2.equals(this.SEND_PACKET_DESCRIPTOR) || string2.equals(this.SEND_PACKET_DESCRIPTOR2))) {
            methodVisitor = new SendPacketVisitor(methodVisitor);
            System.out.println("Method " + this.SEND_PACKET + " transformed");
        } else if (string.equals(this.CHANNEL_READ_0) && string2.equals(this.CHANNEL_READ_0_DESCRIPTOR)) {
            methodVisitor = new ChannelRead0Visitor(methodVisitor);
        }
        return methodVisitor;
    }

    public static class ChannelRead0Visitor
    extends MethodVisitor {
        public ChannelRead0Visitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            super.visitCode();
            this.mv.visitVarInsn(25, 2);
            this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "onReceivePacket", "(Lnet/minecraft/network/Packet;)Lnet/minecraft/network/Packet;", false);
            this.mv.visitVarInsn(58, 2);
            this.mv.visitVarInsn(25, 2);
            Label label = new Label();
            this.mv.visitJumpInsn(199, label);
            this.mv.visitInsn(177);
            this.mv.visitLabel(label);
            this.mv.visitFrame(3, 0, null, 0, null);
        }
    }

    public static class SendPacketVisitor
    extends MethodVisitor {
        public SendPacketVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            super.visitCode();
            this.mv.visitVarInsn(25, 1);
            this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "onSendPacket", "(Lnet/minecraft/network/Packet;)Lnet/minecraft/network/Packet;", false);
            this.mv.visitVarInsn(58, 1);
            this.mv.visitVarInsn(25, 1);
            Label label = new Label();
            this.mv.visitJumpInsn(199, label);
            this.mv.visitInsn(177);
            this.mv.visitLabel(label);
            this.mv.visitFrame(3, 0, null, 0, null);
        }
    }
}
