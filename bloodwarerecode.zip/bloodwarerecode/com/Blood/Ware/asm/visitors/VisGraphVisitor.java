package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class VisGraphVisitor
extends ClassVisitor {
    public final /* synthetic */ String SET_OPAQUE;
    public final /* synthetic */ String SET_OPAQUE_DESCRIPTOR;

    public VisGraphVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.SET_OPAQUE = bl ? "a" : "setOpaqueCube";
        this.SET_OPAQUE_DESCRIPTOR = bl ? "(Let;)V" : "(Lnet/minecraft/util/math/BlockPos;)V";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = this.cv.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.SET_OPAQUE) && string2.equals(this.SET_OPAQUE_DESCRIPTOR)) {
            methodVisitor = new SetOpaqueCubeVisitor(methodVisitor);
            System.out.println("Method " + this.SET_OPAQUE + " transformed");
        }
        return methodVisitor;
    }

    public static class SetOpaqueCubeVisitor
    extends MethodVisitor {
        public SetOpaqueCubeVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            super.visitCode();
            Label label = new Label();
            this.mv.visitLabel(label);
            this.mv.visitLineNumber(29, label);
            this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "setOpaqueCube", "()Z", false);
            Label label2 = new Label();
            this.mv.visitJumpInsn(153, label2);
            Label label3 = new Label();
            this.mv.visitLabel(label3);
            this.mv.visitLineNumber(30, label3);
            this.mv.visitInsn(177);
            this.mv.visitLabel(label2);
            this.mv.visitLineNumber(32, label2);
            this.mv.visitFrame(3, 0, null, 0, null);
        }
    }
}
