package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

public class BlockStateContainerVisitor
extends ClassVisitor {
    public final /* synthetic */ String SHOULD_SIDE;
    public final /* synthetic */ String SHOULD_SIDE_DESCRIPTOR;
    public final /* synthetic */ String GET_LIGHT;
    public final /* synthetic */ String GET_LIGHT_DESCRIPTOR;

    public BlockStateContainerVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.SHOULD_SIDE = bl ? "c" : "shouldSideBeRendered";
        this.SHOULD_SIDE_DESCRIPTOR = bl ? "(Lamy;Let;Lfa;)Z" : "(Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z";
        this.GET_LIGHT = bl ? "j" : "getAmbientOcclusionLightValue";
        this.GET_LIGHT_DESCRIPTOR = "()F";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.SHOULD_SIDE) && string2.equals(this.SHOULD_SIDE_DESCRIPTOR)) {
            methodVisitor = new ShouldSideBeRenderedVisitor(methodVisitor);
            System.out.println("Method " + string + " transformed");
        } else if (string.equals(this.GET_LIGHT) && string2.equals(this.GET_LIGHT_DESCRIPTOR)) {
            methodVisitor = new GetAmbientOcclusionLightValueVisitor(methodVisitor);
            System.out.println("Method " + string + " transformed");
        }
        return methodVisitor;
    }

    public static class GetAmbientOcclusionLightValueVisitor
    extends MethodVisitor {
        public GetAmbientOcclusionLightValueVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitInsn(int n) {
            if (n == 174) {
                this.mv.visitVarInsn(25, 0);
                this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "getAmbientOcclusionLightValue", "(Lnet/minecraft/block/state/IBlockState;)F", false);
            }
            super.visitInsn(n);
        }
    }

    public static class ShouldSideBeRenderedVisitor
    extends MethodVisitor {
        public ShouldSideBeRenderedVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitInsn(int n) {
            if (n == 172) {
                this.mv.visitVarInsn(25, 0);
                this.mv.visitVarInsn(25, 1);
                this.mv.visitVarInsn(25, 2);
                this.mv.visitVarInsn(25, 3);
                this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "shouldSideBeRendered", "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z", false);
            }
            super.visitInsn(n);
        }
    }
}
