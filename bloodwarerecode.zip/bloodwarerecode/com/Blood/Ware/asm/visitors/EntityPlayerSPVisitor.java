package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class EntityPlayerSPVisitor
extends ClassVisitor {
    public final /* synthetic */ String IS_USER;
    public final /* synthetic */ String IS_USER_DESC;
    public final /* synthetic */ String MOVE;
    public final /* synthetic */ String MOVE_DESC;
    public final /* synthetic */ String ON_UPDATE_WALKING_PLAYER;
    public final /* synthetic */ String ON_UPDATE_WALKING_PLAYER_DESC;

    public EntityPlayerSPVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.IS_USER = bl ? "cZ" : "isUser";
        this.IS_USER_DESC = "()Z";
        this.MOVE = bl ? "a" : "move";
        this.MOVE_DESC = bl ? "(Lvv;DDD)V" : "(Lnet/minecraft/entity/MoverType;DDD)V";
        this.ON_UPDATE_WALKING_PLAYER = bl ? "N" : "onUpdateWalkingPlayer";
        this.ON_UPDATE_WALKING_PLAYER_DESC = "()V";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.IS_USER) && string2.equals(this.IS_USER_DESC)) {
            System.out.println("Method " + string + " transformed");
            methodVisitor = new IsUserVisitor(methodVisitor);
        } else if (string.equals(this.MOVE) && string2.equals(this.MOVE_DESC)) {
            System.out.println("Method " + string + " transformed");
            methodVisitor = new MoveVisitor(methodVisitor);
        } else if (string.equals(this.ON_UPDATE_WALKING_PLAYER) && string2.equals(this.ON_UPDATE_WALKING_PLAYER_DESC)) {
            System.out.println("Method " + string + " transformed");
            methodVisitor = new OnUpdateWalkingPlayer(methodVisitor);
        }
        return methodVisitor;
    }

    public static class OnUpdateWalkingPlayer
    extends MethodVisitor {
        public OnUpdateWalkingPlayer(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            super.visitCode();
            this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "onUpdateWalkingPlayer", "()Z", false);
            Label label = new Label();
            this.mv.visitJumpInsn(153, label);
            this.mv.visitInsn(177);
            this.mv.visitLabel(label);
        }
    }

    public static class MoveVisitor
    extends MethodVisitor {
        public MoveVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            this.mv.visitTypeInsn(187, "ru/terrar/bobr/events/PlayerMoveEvent");
            this.mv.visitInsn(89);
            this.mv.visitVarInsn(24, 2);
            this.mv.visitVarInsn(24, 4);
            this.mv.visitVarInsn(24, 6);
            this.mv.visitMethodInsn(183, "ru/internali/events/PlayerMoveEvent", "<init>", "(DDD)V", false);
            this.mv.visitVarInsn(58, 8);
            this.mv.visitFieldInsn(178, "net/minecraftforge/common/MinecraftForge", "EVENT_BUS", "Lnet/minecraftforge/fml/common/eventhandler/EventBus;");
            this.mv.visitVarInsn(25, 8);
            this.mv.visitMethodInsn(182, "net/minecraftforge/fml/common/eventhandler/EventBus", "post", "(Lnet/minecraftforge/fml/common/eventhandler/Event;)Z", false);
            Label label = new Label();
            this.mv.visitJumpInsn(153, label);
            this.mv.visitInsn(177);
            this.mv.visitLabel(label);
            this.mv.visitFrame(1, 1, new Object[]{"ru/internali/events/PlayerMoveEvent"}, 0, null);
            this.mv.visitVarInsn(25, 8);
            this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "x", "D");
            this.mv.visitVarInsn(57, 2);
            this.mv.visitVarInsn(25, 8);
            this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "y", "D");
            this.mv.visitVarInsn(57, 4);
            this.mv.visitVarInsn(25, 8);
            this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "z", "D");
            this.mv.visitVarInsn(57, 6);
            super.visitCode();
        }
    }

    public static class IsUserVisitor
    extends MethodVisitor {
        public IsUserVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitInsn(int n) {
            if (n == 172) {
                this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "isUser", "()Z", false);
            }
            super.visitInsn(n);
        }
    }
}
