package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class BlockRendererDispatcherVisitor
extends ClassVisitor {
    public final /* synthetic */ String RENDER_MODEL_FLAT;
    public final /* synthetic */ String RENDER_BLOCK_DESCRIPTOR;

    public BlockRendererDispatcherVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.RENDER_MODEL_FLAT = bl ? "a" : "renderBlock";
        this.RENDER_BLOCK_DESCRIPTOR = bl ? "(Lawt;Let;Lamy;Lbuk;)Z" : "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/client/renderer/BufferBuilder;)Z";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.RENDER_MODEL_FLAT) && string2.equals(this.RENDER_BLOCK_DESCRIPTOR)) {
            System.out.println("Method " + string + " transformed");
            methodVisitor = new RenderBlockVisitor(methodVisitor);
        }
        return methodVisitor;
    }

    public static class RenderBlockVisitor
    extends MethodVisitor {
        public RenderBlockVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitCode() {
            super.visitCode();
            this.mv.visitVarInsn(25, 1);
            this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "renderBlock", "(Lnet/minecraft/block/state/IBlockState;)Z", false);
            Label label = new Label();
            this.mv.visitJumpInsn(153, label);
            Label label2 = new Label();
            this.mv.visitLabel(label2);
            this.mv.visitLineNumber(17, label2);
            this.mv.visitInsn(3);
            this.mv.visitInsn(172);
            this.mv.visitLabel(label);
            this.mv.visitLineNumber(19, label);
            this.mv.visitFrame(3, 0, null, 0, null);
        }
    }
}
