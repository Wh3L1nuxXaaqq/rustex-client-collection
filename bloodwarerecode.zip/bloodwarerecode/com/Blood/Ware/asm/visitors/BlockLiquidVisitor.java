package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

public class BlockLiquidVisitor
extends ClassVisitor {
    public final /* synthetic */ String GET_COLLISION;
    public final /* synthetic */ String GET_COLLISION_DESC;

    public BlockLiquidVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.GET_COLLISION = bl ? "a" : "getCollisionBoundingBox";
        this.GET_COLLISION_DESC = bl ? "(Lawt;Lamy;Let;)Lbhb;" : "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB;";
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.GET_COLLISION) && string2.equals(this.GET_COLLISION_DESC)) {
            System.out.println("Method " + string + " transformed");
            methodVisitor = new GetCollisionBoundingBoxVisitor(methodVisitor);
        }
        return methodVisitor;
    }

    public static class GetCollisionBoundingBoxVisitor
    extends MethodVisitor {
        public GetCollisionBoundingBoxVisitor(MethodVisitor methodVisitor) {
            super(327680, methodVisitor);
        }

        @Override
        public void visitInsn(int n) {
            if (n == 176) {
                this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "getCollisionBoundingBox", "()Lnet/minecraft/util/math/AxisAlignedBB;", false);
            }
            super.visitInsn(n);
        }
    }
}
