package com.Blood.Ware.asm.visitors;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class EntityRendererVisitor
extends ClassVisitor {
    public final /* synthetic */ String UPDATE_CAMERA;
    public final /* synthetic */ String UPDATE_CAMERA_DESCRIPTOR;
    public /* synthetic */ boolean isObfuscated;

    public EntityRendererVisitor(ClassVisitor classVisitor, boolean bl) {
        super(327680, classVisitor);
        this.UPDATE_CAMERA = bl ? "a" : "updateCameraAndRender";
        this.UPDATE_CAMERA_DESCRIPTOR = bl ? "(FJ)V" : "(FJ)V";
        this.isObfuscated = bl;
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
        if (string.equals(this.UPDATE_CAMERA) && string2.equals(this.UPDATE_CAMERA_DESCRIPTOR)) {
            methodVisitor = new UpdateCameraAndRendererVisitor(methodVisitor, this.isObfuscated);
            System.out.println("Method " + this.UPDATE_CAMERA + " transformed");
        }
        return methodVisitor;
    }

    public static class UpdateCameraAndRendererVisitor
    extends MethodVisitor {
        public /* synthetic */ boolean line1033;
        public /* synthetic */ boolean line1039;
        public /* synthetic */ boolean isObfuscated;

        public UpdateCameraAndRendererVisitor(MethodVisitor methodVisitor, boolean bl) {
            super(327680, methodVisitor);
            this.isObfuscated = bl;
        }

        @Override
        public void visitLineNumber(int n, Label label) {
            super.visitLineNumber(n, label);
            this.line1033 = n == 1033;
            this.line1039 = n == 1039;
        }

        @Override
        public void visitFieldInsn(int n, String string, String string2, String string3) {
            if ((this.line1033 || this.line1039) && string.equals(this.isObfuscated ? "bib" : "net/minecraft/client/Minecraft")) {
                this.mv.visitMethodInsn(182, this.isObfuscated ? "bib" : "net/minecraft/client/Minecraft", this.isObfuscated ? "aa" : "getRenderViewEntity", this.isObfuscated ? "()Lvg;" : "()Lnet/minecraft/entity/Entity;", false);
            } else {
                super.visitFieldInsn(n, string, string2, string3);
            }
        }

        @Override
        public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
            if (this.line1033 || this.line1039) {
                this.mv.visitMethodInsn(182, this.isObfuscated ? "vg" : "net/minecraft/entity/Entity", this.isObfuscated ? "c" : "turn", "(FF)V", false);
            } else {
                super.visitMethodInsn(n, string, string2, string3, bl);
            }
        }
    }
}
