package Caesium;

import Caesium.ClickGui;
import com.Blood.Ware.utils.MathUtils;
import com.Blood.Ware.utils.RenderUtils;
import com.Blood.Ware.utils.TimerUtils;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

@Native
public class SnowRenderer {
    public /* synthetic */ ArrayList<SnowObject> snowObjects;
    public /* synthetic */ TimerUtils timer;

    public SnowRenderer() {
        this.snowObjects = new ArrayList();
        this.timer = new TimerUtils();
    }

    public void render() {
        for (int i = 0; i < this.snowObjects.size(); i -= 2544) {
            this.snowObjects.get(i).render();
            if (this.snowObjects.get(i).needToDelete()) {
                this.snowObjects.remove(i);
            }
            i += 2545;
        }
        if (this.snowObjects.size() < 1350 && this.timer.hasReached(15.0f)) {
            this.snowObjects.add(new SnowObject());
            this.timer.reset();
        }
    }

    public class SnowObject {
        public /* synthetic */ long time;
        public /* synthetic */ float x;
        public /* synthetic */ float y;
        public /* synthetic */ float motionX;
        public /* synthetic */ float motionY;
        public /* synthetic */ float size;

        public SnowObject() {
            this.x = MathUtils.getRandomInRange(ClickGui.WIDTH + 20, -20);
            this.y = MathUtils.getRandomInRange(-5, -20);
            this.motionX = MathUtils.getRandomInRange(0.3f, -0.3f);
            this.motionY = MathUtils.getRandomInRange(0.5f, 0.1f);
            this.size = MathUtils.getRandomInRange(3.0f, 0.5f);
            this.time = System.currentTimeMillis();
        }

        public void render() {
            if (System.currentTimeMillis() - this.time > (0x1DF23FE341D71D7AL ^ 0x1DF23FE341D71D72L)) {
                this.time = System.currentTimeMillis();
                this.x += this.motionX;
                this.y += this.motionY;
            }
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)32772);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)3008);
            GL11.glEnable((int)2832);
            GL11.glPointSize((float)this.size);
            RenderUtils.glColor(new Color(211, 211, 211).getRGB());
            GL11.glBegin((int)0);
            GL11.glVertex2d((double)this.x, (double)this.y);
            GL11.glEnd();
            GL11.glPointSize((float)1.2f);
            GL11.glEnable((int)3008);
            GL11.glEnable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GlStateManager.func_179117_G();
        }

        public boolean needToDelete() {
            return this.y > (float)(ClickGui.HEIGHT + 10);
        }
    }
}
