package Caesium;

import Caesium.Panel;
import Caesium.SnowRenderer;
import Caesium.components.Frame;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class ClickGui
extends GuiScreen {
    public static /* synthetic */ int compID;
    public /* synthetic */ ArrayList<Frame> frames;
    public final /* synthetic */ FontRenderer fr;
    public static /* synthetic */ int WIDTH;
    public static /* synthetic */ int HEIGHT;
    public /* synthetic */ SnowRenderer snowRenderer;

    public ClickGui() {
        this.frames = new ArrayList();
        this.fr = Minecraft.func_71410_x().field_71466_p;
        compID = 0;
        this.snowRenderer = new SnowRenderer();
    }

    public void addFrame(Frame frame) {
        if (!this.frames.contains(frame)) {
            this.frames.add(frame);
        }
    }

    public ArrayList<Frame> getFrames() {
        return this.frames;
    }

    public void func_73866_w_() {
        for (Frame frame : this.frames) {
            frame.initialize();
        }
    }

    public void func_73864_a(int n, int n2, int n3) throws IOException {
        for (Frame frame : this.frames) {
            frame.mouseClicked(n, n2, n3);
        }
    }

    public void func_73869_a(char c, int n) throws IOException {
        super.func_73869_a(c, n);
        for (Frame frame : this.frames) {
            frame.keyTyped(n, c);
        }
    }

    public void drawinfo(int n, int n2) {
        int n3 = 600;
        int n4 = 280;
        int n5 = 0;
        CastomFontUtils.fr4.drawStringWithShadow("Friends", n3 + CastomFontUtils.fr4.getStringWidth("Friends") / 2, n4 - CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawRect(n3, n4, n3 + 100, n4 + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), new Color(50, 50, 50, 190).getRGB());
        RenderUtil.drawNewRect(n3 - 1, n4, n3, n4 + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawNewRect(n3 + 100 - 1, n4, n3 + 100, n4 + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawGlow(n3, n4 - 1, n3 + 100, n4, ClickGUI.getColor(), 250.0);
        RenderUtil.drawGlow(n3, n4 + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight() - 1, n3 + 100, n4 + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor(), 250.0);
        for (String string : FriendManager.FRIENDS) {
            int n6 = 0 + n3;
            int n7 = 100 + n3;
            int n8 = n5 + n4;
            int n9 = n5 + this.field_146289_q.field_78288_b + n4;
            if (n > n6 && n < n7 && n2 > n8 && n2 < n9) {
                CastomFontUtils.fr4.drawString(string, n3 + 50 - CastomFontUtils.fr4.getStringWidth(string) / 2, n5 + n4, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(string);
                    return;
                }
            } else {
                CastomFontUtils.fr4.drawString(string, n3 + 50 - CastomFontUtils.fr4.getStringWidth(string) / 2, n5 + n4, Color.white.getRGB());
            }
            n5 += CastomFontUtils.fr4.getHeight();
        }
    }

    public void func_73863_a(int n, int n2, float f) {
        ScaledResolution scaledResolution = new ScaledResolution(this.field_146297_k);
        this.snowRenderer.render();
        Gui.func_73734_a((int)64, (int)556, (int)0, (int)524, (int)new Color(37, 37, 37, 255).getRGB());
        Gui.func_73734_a((int)0, (int)525, (int)64, (int)527, (int)ClickGUI.getColor());
        CastomFontUtils.fr4.drawString("By FlipsTer", 4.0f, 529.0f, Panel.fontColor);
        for (Frame frame : this.frames) {
            frame.render(n, n2);
            this.drawinfo(n, n2);
        }
    }

    static {
        compID = 0;
        WIDTH = 1900;
        HEIGHT = 1000;
    }
}
