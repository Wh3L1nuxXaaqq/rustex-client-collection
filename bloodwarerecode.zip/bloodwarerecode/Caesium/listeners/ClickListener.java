package Caesium.listeners;

import Caesium.components.GuiButton;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClickListener
implements ActionListener {
    public /* synthetic */ GuiButton button;

    public ClickListener(GuiButton guiButton) {
        this.button = guiButton;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        Module module = BloodWare.moduleManager.getModule(this.button.getText());
        module.toggle();
    }
}
