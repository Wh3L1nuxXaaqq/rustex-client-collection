package Caesium.listeners;

import Caesium.components.GuiButton;
import Caesium.components.GuiComboBox;
import Caesium.components.GuiComponent;
import Caesium.components.GuiGetKey;
import Caesium.components.GuiLabel;
import Caesium.components.GuiSlider;
import Caesium.components.GuiToggleButton;
import Caesium.components.listeners.ComboListener;
import Caesium.components.listeners.ComponentListener;
import Caesium.components.listeners.KeyListener;
import Caesium.components.listeners.ValueListener;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ComponentsListener
extends ComponentListener {
    public /* synthetic */ GuiButton button;

    public ComponentsListener(GuiButton guiButton) {
        this.button = guiButton;
    }

    @Override
    public void addComponents() {
        this.add(new GuiLabel("< Settings >"));
        final Module module = BloodWare.moduleManager.getModule(this.button.getText());
        if (BloodWare.instance.settingsManager.getSettingsByMod(module) != null) {
            for (final Setting object2 : BloodWare.instance.settingsManager.getSettingsByMod(module)) {
                GuiComponent guiComponent;
                if (object2.isSlider()) {
                    guiComponent = new GuiSlider(object2.getName(), (float)object2.getMin(), (float)object2.getMax(), (float)object2.getValDouble(), object2.onlyInt() ? 0 : 2);
                    ((GuiSlider)guiComponent).addValueListener(new ValueListener(){

                        @Override
                        public void valueUpdated(float f) {
                            object2.setValDouble(f);
                        }

                        @Override
                        public void valueChanged(float f) {
                            object2.setValDouble(f);
                            new Thread(() -> {}).start();
                        }
                    });
                    this.add(guiComponent);
                }
                if (object2.isCheck()) {
                    guiComponent = new GuiToggleButton(object2.getName());
                    ((GuiToggleButton)guiComponent).setToggled(object2.getValBoolean());
                    ((GuiToggleButton)guiComponent).addClickListener(new ActionListener((GuiToggleButton)guiComponent){
                        public final /* synthetic */ GuiToggleButton val$toggleButton;
                        {
                            this.val$toggleButton = guiToggleButton;
                        }

                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            object2.setValBoolean(this.val$toggleButton.isToggled());
                        }
                    });
                    this.add(guiComponent);
                }
                if (!object2.isCombo()) continue;
                guiComponent = new GuiComboBox(object2);
                ((GuiComboBox)guiComponent).addComboListener(new ComboListener(){

                    @Override
                    public void comboChanged(String string) {
                    }
                });
                this.add(guiComponent);
            }
        }
        GuiGetKey guiGetKey = new GuiGetKey("KeyBind", module.getKey());
        guiGetKey.addKeyListener(new KeyListener(){

            @Override
            public void keyChanged(int n) {
                module.setKey(n);
                new Thread(() -> {}).start();
            }
        });
        this.add(guiGetKey);
        final GuiToggleButton guiToggleButton = new GuiToggleButton("Visible");
        guiToggleButton.setToggled(module.visible);
        guiToggleButton.addClickListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                module.visible = guiToggleButton.isToggled();
            }
        });
        this.add(guiToggleButton);
    }
}
