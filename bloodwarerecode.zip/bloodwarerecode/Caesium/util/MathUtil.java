package Caesium.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MathUtil {
    public static float round(float f, int n) {
        return new BigDecimal(f).setScale(n, RoundingMode.HALF_EVEN).floatValue();
    }

    public static double round(double d, int n) {
        return new BigDecimal(d).setScale(n, RoundingMode.HALF_EVEN).doubleValue();
    }
}
