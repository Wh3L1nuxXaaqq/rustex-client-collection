package Caesium.util;

public class FramePosition {
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ boolean isExpanded;

    public FramePosition(int n, int n2, boolean bl) {
        this.posX = n;
        this.posY = n2;
        this.isExpanded = bl;
    }

    public int getPosX() {
        return this.posX;
    }

    public void setPosX(int n) {
        this.posX = n;
    }

    public int getPosY() {
        return this.posY;
    }

    public void setPosY(int n) {
        this.posY = n;
    }

    public boolean isExpanded() {
        return this.isExpanded;
    }

    public void setExpanded(boolean bl) {
        this.isExpanded = bl;
    }
}
