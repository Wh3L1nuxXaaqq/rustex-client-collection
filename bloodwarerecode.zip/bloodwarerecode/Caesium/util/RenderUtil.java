package Caesium.util;

import net.minecraft.client.gui.Gui;

public final class RenderUtil {
    public static void drawRect(int n, int n2, int n3, int n4, int n5) {
        Gui.func_73734_a((int)n, (int)n2, (int)n3, (int)n4, (int)n5);
    }

    public static void drawHorizontalLine(int n, int n2, int n3, int n4) {
        if (n2 < n) {
            int n5 = n;
            n = n2;
            n2 = n5;
        }
        RenderUtil.drawRect(n, n3, n2 + 1, n3 + 1, n4);
    }

    public static void drawVerticalLine(int n, int n2, int n3, int n4) {
        if (n3 < n2) {
            int n5 = n2;
            n2 = n3;
            n3 = n5;
        }
        RenderUtil.drawRect(n, n2 + 1, n + 1, n3, n4);
    }

    public static boolean isHovered(int n, int n2, int n3, int n4, int n5, int n6) {
        return n5 >= n && n5 <= n + n3 && n6 >= n2 && n6 < n2 + n4;
    }
}
