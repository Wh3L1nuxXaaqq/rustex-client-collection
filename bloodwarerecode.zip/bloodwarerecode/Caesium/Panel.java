package Caesium;

import Caesium.ClickGui;
import Caesium.components.Frame;
import Caesium.components.GuiButton;
import Caesium.components.GuiFrame;
import Caesium.listeners.ClickListener;
import Caesium.listeners.ComponentsListener;
import Caesium.util.FramePosition;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import java.awt.Color;
import java.util.HashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class Panel
extends ClickGui {
    public static /* synthetic */ HashMap<String, FramePosition> framePositions;
    public static /* synthetic */ FontRenderer fR;
    public static /* synthetic */ String theme;
    public static /* synthetic */ int FRAME_WIDTH;
    public static /* synthetic */ int color;
    public static /* synthetic */ int fontColor;
    public static /* synthetic */ int grey40_240;
    public static /* synthetic */ int black195;
    public static /* synthetic */ int black100;
    public static /* synthetic */ int black101;

    public Panel(String string, int n) {
        theme = string;
    }

    public void ref(Category category, int n) {
        GuiFrame guiFrame = new GuiFrame(category.name(), n, 50, true);
        for (Module module : ModuleManager.modules) {
            if (category != module.getCategory() || !module.visible) continue;
            GuiButton guiButton = new GuiButton(module.getName());
            guiButton.addClickListener(new ClickListener(guiButton));
            guiButton.addExtendListener(new ComponentsListener(guiButton));
            guiFrame.addButton(guiButton);
        }
        this.addFrame(guiFrame);
    }

    @Override
    public void func_73866_w_() {
        int n = 25;
        this.ref(Category.COMBAT, n);
        n -= 5475;
        this.ref(Category.MOVEMENT, n += 5610);
        n += 693;
        this.ref(Category.RENDER, n -= 558);
        n -= 19635;
        this.ref(Category.OUTHER, n += 19770);
        n -= 31966;
        this.ref(Category.HUD, n += 32101);
        super.func_73866_w_();
    }

    public void func_146281_b() {
        if (!this.getFrames().isEmpty()) {
            for (Frame frame : this.getFrames()) {
                GuiFrame guiFrame = (GuiFrame)frame;
                framePositions.put(guiFrame.getTitle(), new FramePosition(guiFrame.getPosX(), guiFrame.getPosY(), guiFrame.isExpaned()));
            }
        }
    }

    static {
        framePositions = new HashMap();
        fR = Minecraft.func_71410_x().field_71466_p;
        FRAME_WIDTH = 100;
        color = ClickGUI.getColor();
        fontColor = Color.white.getRGB();
        grey40_240 = new Color(40, 40, 40, 100).getRGB();
        black195 = new Color(255, 255, 255, 100).getRGB();
        black100 = new Color(0, 0, 0, 255).getRGB();
        black101 = new Color(0, 0, 0, 255).getRGB();
    }
}
