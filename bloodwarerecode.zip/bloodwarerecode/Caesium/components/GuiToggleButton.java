package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import Caesium.util.RenderUtil;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GuiToggleButton
implements GuiComponent {
    public /* synthetic */ String text;
    public /* synthetic */ boolean toggled;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ ArrayList<ActionListener> clickListeners;

    public GuiToggleButton(String string) {
        this.clickListeners = new ArrayList();
        this.text = string;
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        this.posX = n;
        this.posY = n2;
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium(n, n2);
            }
        }
    }

    public void renderCaesium(int n, int n2) {
        RenderUtil.drawRect(n + 2, n2 + 1, n + 14, n2 + 13, Color.red.getRGB());
        if (!this.toggled) {
            RenderUtil.drawRect(n + 3, n2 + 2, n + 13, n2 + 12, Color.gray.getRGB());
        }
        CastomFontUtils.fr4.drawStringWithShadow(this.text, n + 17, n2 + 3, Panel.fontColor);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        int n4 = CastomFontUtils.fr4.getStringWidth(this.text) + 10;
        if (RenderUtil.isHovered(this.posX, this.posY + 2, n4, this.getHeight(), n, n2)) {
            this.toggled = !this.toggled;
            for (ActionListener actionListener : this.clickListeners) {
                actionListener.actionPerformed(new ActionEvent(this, this.hashCode(), "click", System.currentTimeMillis(), 0));
            }
        }
    }

    @Override
    public void keyTyped(int n, char c) {
    }

    @Override
    public int getWidth() {
        return CastomFontUtils.fr4.getStringWidth(this.text) + 20;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 5;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public void setToggled(boolean bl) {
        this.toggled = bl;
    }

    public void addClickListener(ActionListener actionListener) {
        this.clickListeners.add(actionListener);
    }
}
