package Caesium.components;

import Caesium.ClickGui;
import Caesium.Panel;
import Caesium.components.Frame;
import Caesium.components.GuiButton;
import Caesium.components.GuiComponent;
import Caesium.util.RenderUtil;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.util.ArrayList;
import org.lwjgl.input.Mouse;

@Native
public class GuiFrame
implements Frame {
    public /* synthetic */ ArrayList<GuiButton> buttons;
    public /* synthetic */ boolean isExpaned;
    public /* synthetic */ boolean isDragging;
    public /* synthetic */ int id;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ int prevPosX;
    public /* synthetic */ int prevPosY;
    public /* synthetic */ int scrollHeight;
    public static /* synthetic */ int dragID;
    public /* synthetic */ String title;
    public /* synthetic */ int color2;

    public GuiFrame(String string, int n, int n2, boolean bl) {
        this.buttons = new ArrayList();
        this.color2 = new Color(200, 0, 255).getRGB();
        this.title = string;
        this.posX = n;
        this.posY = n2;
        this.isExpaned = bl;
        this.id = ++ClickGui.compID;
        this.scrollHeight = 0;
    }

    @Override
    public void render(int n, int n2) {
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium(n, n2);
            }
        }
    }

    public int getExpandedHeight() {
        int n = 0;
        for (GuiButton guiButton : this.buttons) {
            ArrayList<GuiComponent> arrayList;
            n += guiButton.getHeight();
            if (guiButton.getButtonID() != GuiButton.expandedID || (arrayList = guiButton.getComponents()).isEmpty()) continue;
            for (GuiComponent guiComponent : arrayList) {
                n += guiComponent.getHeight();
            }
        }
        return n;
    }

    public void renderCaesium(int n, int n2) {
        int n3 = ClickGUI.getColor();
        int n4 = new Color(0, 0, 0, 255).getRGB();
        int n5 = Panel.fontColor;
        int n6 = Math.max(Panel.FRAME_WIDTH, CastomFontUtils.fr4.getStringWidth(this.title) + 15);
        if (this.isDragging && Mouse.isButtonDown((int)0)) {
            this.posX = n - this.prevPosX;
            this.posY = n2 - this.prevPosY;
            dragID = this.id;
        } else {
            this.isDragging = false;
            dragID = -1;
        }
        for (GuiButton object : this.buttons) {
            n6 = Math.max(n6, object.getWidth() + 15);
        }
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(this.posX + 1, this.posY - 5, this.posX + n6, this.posY + 12, 4.0f, 6.0f, n3, n3, n3, n3, false, true, true);
        CastomFontUtils.fr4.drawStringWithShadow(this.title, this.posX + n6 / 2 - CastomFontUtils.fr4.getStringWidth(this.title) / 2, this.posY, n5);
        CastomFontUtils.fr4.drawStringWithShadow(this.isExpaned ? "-" : "+", this.posX + n6 - CastomFontUtils.fr4.getStringWidth(this.isExpaned ? "-" : "+") - 4, this.posY, n5);
        if (this.isExpaned) {
            int n7 = 0;
            RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(this.posX + 1, this.posY + 12, this.posX + n6, this.posY + this.getExpandedHeight() + 12, 3.0f, 3.0f, this.color2, this.color2, this.color2, this.color2, false, true, true);
            for (GuiButton guiButton : this.buttons) {
                ArrayList<GuiComponent> arrayList;
                guiButton.render(this.posX + 1, this.posY + n7 + 12, n6, n, n2, 0);
                if (guiButton.getButtonID() == GuiButton.expandedID && !(arrayList = guiButton.getComponents()).isEmpty()) {
                    int n8 = 0;
                    for (GuiComponent guiComponent : arrayList) {
                        guiComponent.render(this.posX + 1, this.posY + n7 + guiButton.getHeight() + n8 + 12, n6, n, n2, 0);
                        n8 += guiComponent.getHeight();
                    }
                    n7 += n8;
                }
                n7 += guiButton.getHeight();
            }
        }
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        int n4 = Panel.FRAME_WIDTH;
        if (this.isExpaned) {
            for (GuiButton guiButton : this.buttons) {
                n4 = Math.max(n4, guiButton.getWidth());
                guiButton.mouseClicked(n, n2, n3);
            }
        }
        if (RenderUtil.isHovered(this.posX, this.posY, n4, 13, n, n2)) {
            if (n3 == 0) {
                this.prevPosX = n - this.posX;
                this.prevPosY = n2 - this.posY;
                this.isDragging = true;
                dragID = this.id;
            } else if (n3 == 1) {
                this.isExpaned = !this.isExpaned;
                this.scrollHeight = 0;
                this.isDragging = false;
                dragID = -1;
            }
        }
    }

    @Override
    public void keyTyped(int n, char c) {
        if (this.isExpaned) {
            for (GuiButton guiButton : this.buttons) {
                guiButton.keyTyped(n, c);
            }
        }
    }

    @Override
    public void initialize() {
    }

    public void addButton(GuiButton guiButton) {
        if (!this.buttons.contains(guiButton)) {
            this.buttons.add(guiButton);
        }
    }

    public int getButtonID() {
        return this.id;
    }

    public boolean isExpaned() {
        return this.isExpaned;
    }

    public int getPosX() {
        return this.posX;
    }

    public int getPosY() {
        return this.posY;
    }

    public String getTitle() {
        return this.title;
    }
}
