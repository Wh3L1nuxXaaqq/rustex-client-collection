package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import com.Blood.Ware.utils.Font.CastomFontUtils;

public class GuiLabel
implements GuiComponent {
    public /* synthetic */ String text;

    public GuiLabel(String string) {
        this.text = string;
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        CastomFontUtils.fr4.drawStringWithShadow(this.text, n + n3 / 2 - CastomFontUtils.fr4.getStringWidth(this.text) / 2, n2 + 2, Panel.fontColor);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
    }

    @Override
    public void keyTyped(int n, char c) {
    }

    @Override
    public int getWidth() {
        return CastomFontUtils.fr4.getStringWidth(this.text) + 4;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 2;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }
}
