package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import Caesium.components.listeners.KeyListener;
import Caesium.util.RenderUtil;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import java.util.ArrayList;
import org.lwjgl.input.Keyboard;

public class GuiGetKey
implements GuiComponent {
    public /* synthetic */ boolean wasChanged;
    public /* synthetic */ boolean allowChange;
    public /* synthetic */ int key;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ int width;
    public /* synthetic */ String text;
    public /* synthetic */ ArrayList<KeyListener> keylisteners;

    public GuiGetKey(String string, int n) {
        this.keylisteners = new ArrayList();
        this.text = string;
        this.key = n;
        if (n < 0) {
            this.key = 0;
        }
    }

    public void addKeyListener(KeyListener keyListener) {
        this.keylisteners.add(keyListener);
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        this.posX = n;
        this.posY = n2;
        this.width = n3;
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium(n, n2);
            }
        }
    }

    public void renderCaesium(int n, int n2) {
        String string = Keyboard.getKeyName((int)this.key);
        this.wasChanged = this.allowChange ? !this.wasChanged : true;
        CastomFontUtils.fr4.drawStringWithShadow(this.text + ":", n + 3, n2 + 3, Panel.fontColor);
        if (this.wasChanged) {
            CastomFontUtils.fr4.drawStringWithShadow(string, n + this.width - CastomFontUtils.fr4.getStringWidth(string) - 3, n2 + 3, Panel.fontColor);
        } else {
            CastomFontUtils.fr4.drawString(string, n + this.width - CastomFontUtils.fr4.getStringWidth(string) - 3, n2 + 3, Panel.fontColor);
        }
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        String string = Keyboard.getKeyName((int)this.key);
        int n4 = CastomFontUtils.fr4.getStringWidth(this.text);
        this.allowChange = RenderUtil.isHovered(this.posX, this.posY, this.width, 11, n, n2);
    }

    @Override
    public void keyTyped(int n, char c) {
        if (this.allowChange) {
            for (KeyListener keyListener : this.keylisteners) {
                keyListener.keyChanged(n);
            }
            this.key = n;
            this.allowChange = false;
        }
    }

    @Override
    public int getWidth() {
        return CastomFontUtils.fr4.getStringWidth(this.text + Keyboard.getKeyName((int)this.key)) + 15;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 4;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }
}
