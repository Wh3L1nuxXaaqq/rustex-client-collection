package Caesium.components;

import Caesium.ClickGui;
import Caesium.components.GuiComponent;
import Caesium.components.GuiFrame;
import Caesium.components.listeners.ComponentListener;
import Caesium.util.RenderUtil;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtils;
import das.ist.denger.natve.Native;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

@Native
public class GuiButton
implements GuiComponent {
    public static /* synthetic */ int expandedID;
    public /* synthetic */ int id;
    public /* synthetic */ String text;
    public /* synthetic */ ArrayList<ActionListener> clickListeners;
    public /* synthetic */ ArrayList<GuiComponent> guiComponents;
    public /* synthetic */ int width;
    public /* synthetic */ int textWidth;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ int color;

    public GuiButton(String string) {
        this.clickListeners = new ArrayList();
        this.guiComponents = new ArrayList();
        this.color = new Color(255, 255, 255).getRGB();
        this.text = string;
        this.textWidth = CastomFontUtils.fr4.getStringWidth(string);
        this.id = ++ClickGui.compID;
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        this.posX = n;
        this.posY = n2;
        this.width = n3;
        int n7 = this.getHeight();
        this.renderCaesium(n, n2, n3, n7);
    }

    public void renderCaesium(int n, int n2, int n3, int n4) {
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(n, n2, n + n3 - 1, n2 + n4, 2.0f, 3.0f, this.color, this.color, this.color, this.color, false, true, true);
        int n5 = new Color(200, 0, 255).getRGB();
        if (BloodWare.moduleManager.getModule(this.getText()).isToggled()) {
            n5 = Color.red.getRGB();
        }
        CastomFontUtils.fr4.drawString(this.getText(), n + n3 / 2 - CastomFontUtils.fr4.getStringWidth(this.getText()) / 2, n2 + 2, n5);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        if (GuiFrame.dragID == -1 && RenderUtil.isHovered(this.posX, this.posY, this.width, this.getHeight(), n, n2)) {
            if (n3 == 1) {
                expandedID = expandedID != this.id ? this.id : -1;
            } else if (n3 == 0) {
                for (ActionListener object : this.clickListeners) {
                    object.actionPerformed(new ActionEvent(this, this.id, "click", System.currentTimeMillis(), 0));
                }
            }
        }
        if (expandedID == this.id) {
            for (GuiComponent guiComponent : this.guiComponents) {
                guiComponent.mouseClicked(n, n2, n3);
            }
        }
    }

    @Override
    public void keyTyped(int n, char c) {
        if (expandedID == this.id) {
            for (GuiComponent guiComponent : this.guiComponents) {
                guiComponent.keyTyped(n, c);
            }
        }
    }

    @Override
    public int getWidth() {
        return 5 + this.textWidth;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 3;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }

    public String getText() {
        return this.text;
    }

    public int getButtonID() {
        return this.id;
    }

    public ArrayList<GuiComponent> getComponents() {
        return this.guiComponents;
    }

    public void addClickListener(ActionListener actionListener) {
        this.clickListeners.add(actionListener);
    }

    public void addExtendListener(ComponentListener componentListener) {
        componentListener.addComponents();
        this.guiComponents.addAll(componentListener.getComponents());
    }

    static {
        expandedID = -1;
    }
}
