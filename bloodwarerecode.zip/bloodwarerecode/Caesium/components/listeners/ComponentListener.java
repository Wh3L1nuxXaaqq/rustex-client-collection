package Caesium.components.listeners;

import Caesium.components.GuiComponent;
import java.util.ArrayList;

public abstract class ComponentListener {
    public final /* synthetic */ ArrayList<GuiComponent> components;

    public ComponentListener() {
        this.components = new ArrayList();
    }

    public void add(GuiComponent guiComponent) {
        this.components.add(guiComponent);
    }

    public void clearComponents() {
        this.components.clear();
    }

    public ArrayList<GuiComponent> getComponents() {
        return this.components;
    }

    public abstract void addComponents();
}
