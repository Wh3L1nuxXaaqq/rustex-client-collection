package Caesium.components.listeners;

public interface TextListener {
    public void keyTyped(char var1, String var2);

    public void keyEntered(String var1);
}
