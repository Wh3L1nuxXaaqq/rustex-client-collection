package Caesium.components.listeners;

public interface KeyListener {
    public void keyChanged(int var1);
}
