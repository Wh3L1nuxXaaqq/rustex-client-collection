package Caesium.components.listeners;

public interface ValueListener {
    public void valueUpdated(float var1);

    public void valueChanged(float var1);
}
