package Caesium.components.listeners;

public interface ComboListener {
    public void comboChanged(String var1);
}
