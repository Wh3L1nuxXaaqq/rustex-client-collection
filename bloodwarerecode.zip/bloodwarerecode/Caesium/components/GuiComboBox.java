package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import Caesium.components.listeners.ComboListener;
import Caesium.util.RenderUtil;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import java.awt.Color;
import java.util.ArrayList;

public class GuiComboBox
implements GuiComponent {
    public /* synthetic */ Setting setting;
    public /* synthetic */ boolean extended;
    public /* synthetic */ int height;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ int width;
    public /* synthetic */ ArrayList<ComboListener> comboListeners;

    public GuiComboBox(Setting setting) {
        this.comboListeners = new ArrayList();
        this.setting = setting;
    }

    public void addComboListener(ComboListener comboListener) {
        this.comboListeners.add(comboListener);
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        this.posX = n;
        this.posY = n2;
        this.width = n3;
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium();
            }
        }
    }

    public void renderCaesium() {
        if (this.extended) {
            RenderUtil.drawRect(this.posX, this.posY, this.posX + this.width, this.posY + CastomFontUtils.fr4.getHeight() + 2, Panel.grey40_240);
            RenderUtil.drawHorizontalLine(this.posX, this.posX + this.width, this.posY, Panel.black195);
            RenderUtil.drawHorizontalLine(this.posX, this.posX + this.width, this.posY + CastomFontUtils.fr4.getHeight() + 2, new Color(255, 255, 255, 255).getRGB());
            CastomFontUtils.fr4.drawStringWithShadow(this.setting.getName() + "  -", this.posX + this.width / 2 - CastomFontUtils.fr4.getStringWidth(this.setting.getName() + "  -") / 2, this.posY + 2, Panel.fontColor);
            int n = CastomFontUtils.fr4.getHeight() + 5;
            for (String string : this.setting.getOptions()) {
                if (this.setting.getValString().equalsIgnoreCase(string)) {
                    CastomFontUtils.fr4.drawStringWithShadow(string, this.posX + 10, this.posY + n, Color.red.getRGB());
                } else {
                    CastomFontUtils.fr4.drawStringWithShadow(string, this.posX + 5, this.posY + n, Panel.fontColor);
                }
                n += CastomFontUtils.fr4.getHeight() + 2;
            }
            this.height = n + 2;
        } else {
            RenderUtil.drawRect(this.posX, this.posY, this.posX + this.width, this.posY + CastomFontUtils.fr4.getHeight() + 2, Panel.grey40_240);
            RenderUtil.drawHorizontalLine(this.posX, this.posX + this.width, this.posY, Panel.black195);
            RenderUtil.drawHorizontalLine(this.posX, this.posX + this.width, this.posY + CastomFontUtils.fr4.getHeight() + 2, Panel.black195);
            CastomFontUtils.fr4.drawStringWithShadow(this.setting.getName() + "  +", this.posX + this.width / 2 - CastomFontUtils.fr4.getStringWidth(this.setting.getName() + "  +") / 2, this.posY + 2, Panel.fontColor);
            this.height = CastomFontUtils.fr4.getHeight() + 4;
        }
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        int n4;
        if (RenderUtil.isHovered(this.posX, this.posY, this.width, CastomFontUtils.fr4.getHeight() + 2, n, n2)) {
            this.extended = !this.extended ? 1 : 0;
            n4 = this.extended;
        }
        if (this.extended && RenderUtil.isHovered(this.posX, this.posY + CastomFontUtils.fr4.getHeight() + 2, this.width, (CastomFontUtils.fr4.getHeight() + 2) * this.setting.getOptions().size(), n, n2) && n3 == 0) {
            n4 = CastomFontUtils.fr4.getHeight() + 2;
            for (int i = 1; i <= this.setting.getOptions().size() + 1; i += 21976) {
                if (RenderUtil.isHovered(this.posX, this.posY + n4 * i, this.width, n4 * i, n, n2)) {
                    this.setting.setValString(this.setting.getOptions().get(i - 1));
                }
                i -= 21975;
            }
            for (ComboListener comboListener : this.comboListeners) {
                comboListener.comboChanged(this.setting.getValString());
            }
        }
    }

    @Override
    public void keyTyped(int n, char c) {
    }

    @Override
    public int getWidth() {
        return 0;
    }

    @Override
    public int getHeight() {
        return this.height;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }

    public Setting getSetting() {
        return this.setting;
    }

    public void setSetting(Setting setting) {
        this.setting = setting;
    }
}
