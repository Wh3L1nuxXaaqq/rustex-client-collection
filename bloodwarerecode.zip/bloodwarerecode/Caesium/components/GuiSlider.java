package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import Caesium.components.listeners.ValueListener;
import Caesium.util.MathUtil;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class GuiSlider
implements GuiComponent {
    public static /* synthetic */ int dragId;
    public /* synthetic */ int round;
    public /* synthetic */ int id;
    public /* synthetic */ int width;
    public /* synthetic */ int posX;
    public /* synthetic */ int posY;
    public /* synthetic */ float min;
    public /* synthetic */ float max;
    public /* synthetic */ float current;
    public /* synthetic */ double c;
    public /* synthetic */ boolean wasSliding;
    public /* synthetic */ boolean hovered;
    public /* synthetic */ String text;
    public /* synthetic */ ArrayList<ValueListener> valueListeners;

    public GuiSlider(String string, float f, float f2, float f3, int n) {
        this.valueListeners = new ArrayList();
        this.text = string;
        this.min = f;
        this.max = f2;
        this.current = f3;
        this.c = f3 / f2;
        this.round = n;
        this.id = ++Panel.compID;
    }

    public void addValueListener(ValueListener valueListener) {
        this.valueListeners.add(valueListener);
    }

    public static float clamp(float f, float f2, float f3) {
        return Math.max(f2, Math.min(f3, f));
    }

    @Override
    public void render(int n, int n2, int n3, int n4, int n5, int n6) {
        double d;
        double d2;
        this.posX = n;
        this.posY = n2;
        this.width = n3;
        this.hovered = Caesium.util.RenderUtil.isHovered(n, n2, n3, this.getHeight(), n4, n5);
        if (this.hovered && n6 != 0) {
            d2 = this.min < 0.0f ? (double)Math.abs(this.min - this.max) : (double)(this.max - this.min);
            d = n6 / 15;
            float f = this.current = this.round == 0 ? (float)((int)GuiSlider.clamp((float)((double)this.current + d), this.min, this.max)) : GuiSlider.clamp((float)((double)this.current + (d *= d2 / 100.0)), this.min, this.max);
        }
        if (Mouse.isButtonDown((int)0) && (dragId == this.id || dragId == -1) && this.hovered) {
            if (n4 < n + 2) {
                this.current = this.min;
            } else if (n4 > n + n3) {
                this.current = this.max;
            } else {
                d2 = this.max - this.min;
                d = (double)this.min + (double)GuiSlider.clamp((float)((double)(n4 - n + 3) / (double)n3), 0.0f, 1.0f) * d2;
                this.current = this.round == 0 ? (float)((int)d) : (float)d;
            }
            dragId = this.id;
            for (ValueListener valueListener : this.valueListeners) {
                valueListener.valueUpdated(this.current);
            }
            this.wasSliding = true;
        } else if (!Mouse.isButtonDown((int)0) && this.wasSliding) {
            for (ValueListener valueListener : this.valueListeners) {
                valueListener.valueChanged(this.current);
            }
            dragId = -1;
            this.wasSliding = false;
        }
        double d3 = (this.current - this.min) / (this.max - this.min);
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium(d3);
            }
        }
    }

    public void renderCaesium(double d) {
        String string = this.round == 0 ? "" + Math.round(this.current) : "" + MathUtil.round(this.current, this.round);
        Color color = new Color(255, 0, 0);
        CastomFontUtils.fr4.drawStringWithShadow(this.text + ":", this.posX + 3, this.posY + 3, Panel.fontColor);
        CastomFontUtils.fr4.drawStringWithShadow(string, this.posX + this.width - CastomFontUtils.fr4.getStringWidth(string) - 3, this.posY + 3, Panel.fontColor);
        Gui.func_73734_a((int)this.posX, (int)(this.posY + CastomFontUtils.fr4.getHeight() + 3), (int)(this.posX + this.width - 2), (int)(this.posY + CastomFontUtils.fr4.getHeight() + 5), (int)Color.black.getRGB());
        RenderUtil.drawVGradientRect(this.posX, this.posY + CastomFontUtils.fr4.getHeight() + 3, (int)(d * (double)this.width - 2.0) + this.posX, this.posY + CastomFontUtils.fr4.getHeight() + 5, Color.red.getRGB(), Color.red.getRGB());
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
    }

    @Override
    public void keyTyped(int n, char c) {
    }

    @Override
    public int getWidth() {
        return CastomFontUtils.fr4.getStringWidth(this.text + (this.round == 0 ? (float)Math.round(this.current) : MathUtil.round(this.current, this.round))) + 68;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 6;
    }

    @Override
    public boolean allowScroll() {
        return !this.hovered;
    }

    static {
        dragId = -1;
    }
}
