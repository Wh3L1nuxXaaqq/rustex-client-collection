package Bobr.buttons;

import Bobr.buttons.CSButton;
import Bobr.buttons.CSModButton;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import java.io.IOException;
import java.util.ArrayList;

public class CSCategoryButton
extends CSButton {
    public static /* synthetic */ boolean binding;
    public /* synthetic */ Category category;
    public /* synthetic */ CSModButton currentMod;
    public /* synthetic */ ArrayList<CSModButton> buttons;

    public CSCategoryButton(int n, int n2, int n3, int n4, int n5, String string, Category category) {
        super(n, n2, n3, n4, n5, string);
        this.buttons = new ArrayList();
        this.category = category;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void drawScreen(int var1_1, int var2_2, float var3_3) {
        if (this.isHovered(var1_1, var2_2)) ** GOTO lbl-1000
        if (BloodWare.bobrGui.currentCategory == this) lbl-1000:
        // 2 sources

        {
            v0 = ClickGUI.getColor();
        } else {
            v0 = this.color;
        }
        var4_4 = v0;
        this.fr.func_78276_b(this.displayString, this.x, this.y, var4_4);
        for (CSModButton var6_6 : this.buttons) {
            if (BloodWare.bobrGui.currentCategory != this) continue;
            var6_6.drawScreen(var1_1, var2_2, var3_3);
        }
        super.drawScreen(var1_1, var2_2, var3_3);
    }

    @Override
    public void onKeyPress(int n, int n2) {
    }

    public boolean isHovered(int n, int n2) {
        boolean bl = n > this.x && n < this.x + this.width;
        boolean bl2 = n2 > this.y && n2 < this.y + this.height;
        return bl && bl2;
    }

    public void setBinding(boolean bl) {
        binding = bl;
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) throws IOException {
        for (CSModButton cSModButton : this.buttons) {
            cSModButton.mouseClicked(n, n2, n3);
            if (n3 == 1 && cSModButton.isHovered(n, n2)) {
                this.currentMod = cSModButton;
            }
            if (n3 != 2 || !cSModButton.isHovered(n, n2)) continue;
            this.setBinding(true);
        }
        super.mouseClicked(n, n2, n3);
    }

    @Override
    public void initButton() {
        this.buttons.clear();
        int n = this.x + 65;
        int n2 = 110;
        int n3 = 0;
        while (true) {
            if (n3 >= ModuleManager.modules.size()) break;
            Module module = ModuleManager.modules.get(n3);
            if (module.getCategory() == this.category) {
                CSModButton cSModButton = new CSModButton(n, n2, this.fr.func_78256_a(module.getName()), this.fr.field_78288_b, -1, module.getName(), module);
                this.buttons.add(cSModButton);
                n2 += 6456;
                n2 -= 6446;
            }
            n3 += 14113;
            n3 -= 14112;
        }
        super.initButton();
    }

    public boolean isCurrentPanel() {
        return BloodWare.bobrGui.currentCategory == this;
    }
}
