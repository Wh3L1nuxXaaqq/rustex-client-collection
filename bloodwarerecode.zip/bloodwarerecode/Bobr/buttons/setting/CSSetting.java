package Bobr.buttons.setting;

import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class CSSetting {
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int width;
    public /* synthetic */ int height;
    public /* synthetic */ Setting set;
    public /* synthetic */ Module mod;
    public /* synthetic */ String displayString;
    public /* synthetic */ Minecraft mc;
    public /* synthetic */ FontRenderer fr;

    public CSSetting(int n, int n2, int n3, int n4, Setting setting) {
        this.mc = Minecraft.func_71410_x();
        this.fr = this.mc.field_71466_p;
        this.x = n;
        this.y = n2;
        this.width = n3;
        this.height = n4;
        this.set = setting;
        this.displayString = setting.getName();
    }

    public CSSetting(int n, int n2, int n3, int n4, Module module) {
        this.mc = Minecraft.func_71410_x();
        this.fr = this.mc.field_71466_p;
        this.x = n;
        this.y = n2;
        this.width = n3;
        this.height = n4;
        this.mod = module;
        this.displayString = module.getName();
    }

    public void drawScreen(int n, int n2, float f) {
    }

    public void keyTyped(char c, int n) throws IOException {
    }

    public void onKeyPress(int n, int n2) {
    }

    public void mouseClicked(int n, int n2, int n3) throws IOException {
    }

    public void mouseReleased(int n, int n2, int n3) {
    }

    public void initButton() {
    }
}
