package Bobr.buttons.setting.settings;

import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

public class CSSettingComboValue {
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int width;
    public /* synthetic */ int height;
    public /* synthetic */ String displayString;
    public /* synthetic */ Minecraft mc;
    public /* synthetic */ FontRenderer fr;
    public /* synthetic */ ArrayList<String> values;
    public /* synthetic */ Setting set;

    public CSSettingComboValue(int n, int n2, int n3, int n4, Setting setting, String string) {
        this.mc = Minecraft.func_71410_x();
        this.fr = this.mc.field_71466_p;
        this.x = n;
        this.y = n2;
        this.width = n3;
        this.height = n4;
        this.displayString = string;
        this.set = setting;
        this.values = setting.getOptions();
    }

    public void mouseClicked(int n, int n2, int n3) throws IOException {
        if (this.isHovered(n, n2)) {
            this.set.setValString(this.displayString);
        }
    }

    public void drawScreen(int n, int n2) {
        Gui.func_73734_a((int)this.x, (int)this.y, (int)(this.x + this.width), (int)(this.y + this.height), (int)Integer.MIN_VALUE);
        Gui.func_73734_a((int)this.x, (int)this.y, (int)(this.x + this.width), (int)(this.y + this.height), (int)Integer.MIN_VALUE);
        int n3 = this.set.getValString().equalsIgnoreCase(this.displayString) ? ClickGUI.getColor() : Integer.MAX_VALUE;
        this.fr.func_78276_b(this.displayString, this.x + this.width / 2 - this.fr.func_78256_a(this.displayString) / 2, this.y + 1, n3);
    }

    public boolean isHovered(int n, int n2) {
        boolean bl = n > this.x && n < this.x + this.width;
        boolean bl2 = n2 > this.y && n2 < this.y + this.height;
        return bl && bl2;
    }
}
