package Bobr.buttons.setting.settings;

import Bobr.buttons.setting.CSSetting;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import java.io.IOException;
import org.lwjgl.input.Keyboard;

public class CSSettingDouble
extends CSSetting {
    public CSSettingDouble(int n, int n2, int n3, int n4, Setting setting) {
        super(n, n2, n3, n4, setting);
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        double d = this.set.getValDouble();
        double d2 = d * 100.0;
        double d3 = Math.round(d2);
        double d4 = d3 / 100.0;
        this.mc.field_71466_p.func_78276_b("<", this.x + 1, this.y + 1, this.isHoveredLeft(n, n2) ? ClickGUI.getColor() : Integer.MAX_VALUE);
        this.mc.field_71466_p.func_78276_b(">", this.x + 1 + this.fr.func_78256_a(this.set.getName() + " " + d4) + 15, this.y + 1, this.isHoveredRight(n, n2) ? ClickGUI.getColor() : Integer.MAX_VALUE);
        this.mc.field_71466_p.func_78276_b(this.set.getName() + " " + d4, this.x + 10, this.y + 1, Integer.MAX_VALUE);
        super.drawScreen(n, n2, f);
    }

    public boolean isHoveredLeft(int n, int n2) {
        boolean bl = n > this.x + 1 && n < this.x + 1 + 5;
        boolean bl2 = n2 > this.y + 1 && n2 < this.y + this.mc.field_71466_p.field_78288_b;
        return bl && bl2;
    }

    public boolean isHoveredRight(int n, int n2) {
        double d = Math.round(this.set.getValDouble() * 10.0) / (0xF1A8F0BB82F29C34L ^ 0xF1A8F0BB82F29C3EL);
        boolean bl = n > this.x + 1 + this.fr.func_78256_a(this.set.getName() + " " + d) + 15 && n < this.x + 1 + this.fr.func_78256_a(this.set.getName() + " " + d) + 20;
        boolean bl2 = n2 > this.y + 1 && n2 < this.y + this.mc.field_71466_p.field_78288_b;
        return bl && bl2;
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) throws IOException {
        Setting setting = this.set;
        if (n3 == 0) {
            if (this.isHoveredLeft(n, n2)) {
                boolean bl = Keyboard.isKeyDown((int)42);
                double d = 0.0;
                if (!Keyboard.isKeyDown((int)42) && !Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 1.0 : 0.1;
                } else if (Keyboard.isKeyDown((int)42) && !Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 10.0 : 1.0;
                } else if (Keyboard.isKeyDown((int)42) && Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 1.0 : 0.01;
                } else if (!Keyboard.isKeyDown((int)42) && Keyboard.isKeyDown((int)29)) {
                    d = 0.0;
                    setting.setValDouble(setting.getMin());
                }
                if (setting.getValDouble() - d < setting.getMin() || setting.getValDouble() - d == setting.getMin()) {
                    setting.setValDouble(setting.getMin());
                } else if (setting.getValDouble() - d > setting.getMin()) {
                    setting.setValDouble(setting.getValDouble() - d);
                }
                if (Keyboard.isKeyDown((int)29)) {
                    setting.setValDouble(setting.getMin());
                }
            } else if (this.isHoveredRight(n, n2)) {
                double d = 0.0;
                if (!Keyboard.isKeyDown((int)42) && !Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 1.0 : 0.1;
                } else if (Keyboard.isKeyDown((int)42) && !Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 10.0 : 1.0;
                } else if (Keyboard.isKeyDown((int)42) && Keyboard.isKeyDown((int)29)) {
                    d = setting.onlyInt() ? 1.0 : 0.01;
                } else if (!Keyboard.isKeyDown((int)42) && Keyboard.isKeyDown((int)29)) {
                    d = 0.0;
                    setting.setValDouble(setting.getMax());
                }
                if (setting.getValDouble() + d > setting.getMax() || setting.getValDouble() + d == setting.getMax()) {
                    setting.setValDouble(setting.getMax());
                } else if (setting.getValDouble() + d < setting.getMax()) {
                    setting.setValDouble(setting.getValDouble() + d);
                }
            }
        }
        super.mouseClicked(n, n2, n3);
    }
}
