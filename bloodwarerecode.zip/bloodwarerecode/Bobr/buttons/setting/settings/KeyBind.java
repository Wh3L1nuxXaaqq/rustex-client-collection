package Bobr.buttons.setting.settings;

import Bobr.buttons.setting.CSSetting;
import com.Blood.Ware.module.Module;
import java.io.IOException;
import org.lwjgl.input.Keyboard;

public class KeyBind
extends CSSetting {
    public /* synthetic */ boolean binding;

    public KeyBind(int n, int n2, int n3, int n4, Module module) {
        super(n, n2, n3, n4, module);
    }

    @Override
    public void keyTyped(char c, int n) throws IOException {
        super.keyTyped(c, n);
    }

    public void setBinding(boolean bl) {
        this.binding = bl;
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        String string = "KeyBind: " + Keyboard.getKeyName((int)this.mod.getKey());
        if (this.binding) {
            string = "Listen... ";
            this.fr.func_78276_b(string, this.x, this.y, Integer.MAX_VALUE);
        }
        this.fr.func_78276_b(string, this.x, this.y, Integer.MAX_VALUE);
        int n3 = this.fr.func_78256_a(string);
        if (this.binding && Keyboard.getEventKey() != 0 && Keyboard.getEventKeyState()) {
            this.mod.setKey(Keyboard.getEventKey());
            this.binding = false;
        }
        super.drawScreen(n, n2, f);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) throws IOException {
        if (this.isHovered(n, n2) && n3 == 0) {
            this.setBinding(true);
        }
        super.mouseClicked(n, n2, n3);
    }

    public boolean isHovered(int n, int n2) {
        int n3 = this.fr.func_78256_a(this.displayString);
        boolean bl = n > this.x + 15 && n < this.x + n3 + 35;
        boolean bl2 = n2 > this.y && n2 < this.y + 10;
        return bl && bl2;
    }
}
