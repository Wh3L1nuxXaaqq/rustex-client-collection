package Bobr.buttons.setting.settings;

import Bobr.buttons.setting.CSSetting;
import Bobr.util.RenderHelper;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.gui.Gui;

public class CSSettingCheck
extends CSSetting {
    public /* synthetic */ int animation;

    public CSSettingCheck(int n, int n2, int n3, int n4, Setting setting) {
        super(n, n2, n3, n4, setting);
        this.animation = 20;
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.fr.func_78276_b(this.displayString, this.x, this.y, Integer.MAX_VALUE);
        int n3 = this.fr.func_78256_a(this.displayString);
        Gui.func_73734_a((int)(this.x + n3 + 20), (int)this.y, (int)(this.x + n3 + 30), (int)(this.y + 10), (int)Color.black.getRGB());
        RenderHelper.drawFullCircle(this.x + n3 + 20, this.y + 5, 5.0, Color.black.getRGB());
        RenderHelper.drawFullCircle(this.x + n3 + 30, this.y + 5, 5.0, Color.black.getRGB());
        if (this.set.getValBoolean()) {
            RenderHelper.drawFullCircle(this.x + n3 + this.animation, this.y + 5, 5.0, ClickGUI.getColor());
        } else {
            RenderHelper.drawFullCircle(this.x + n3 + this.animation, this.y + 5, 5.0, -2);
        }
        if (this.set.getValBoolean()) {
            if (this.animation < 30) {
                ++this.animation;
            }
        } else if (this.animation > 20) {
            --this.animation;
        }
        super.drawScreen(n, n2, f);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) throws IOException {
        if (this.isHovered(n, n2) && n3 == 0) {
            this.set.setValBoolean(!this.set.getValBoolean());
        }
        super.mouseClicked(n, n2, n3);
    }

    public boolean isHovered(int n, int n2) {
        int n3 = this.fr.func_78256_a(this.displayString);
        boolean bl = n > this.x + n3 + 15 && n < this.x + n3 + 35;
        boolean bl2 = n2 > this.y && n2 < this.y + 10;
        return bl && bl2;
    }
}
