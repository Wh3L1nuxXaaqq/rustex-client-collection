package Bobr.buttons.setting.settings;

import Bobr.buttons.setting.CSSetting;
import Bobr.buttons.setting.settings.CSSettingComboValue;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.RenderUtil;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.gui.Gui;

public class CSSettingCombo
extends CSSetting {
    public /* synthetic */ ArrayList<CSSettingComboValue> values;

    public CSSettingCombo(int n, int n2, int n3, int n4, Setting setting) {
        super(n, n2, n3, n4, setting);
        this.values = new ArrayList();
        this.initValues();
    }

    public void initValues() {
        int n = this.x;
        int n2 = this.y + this.height;
        for (String string : this.set.getOptions()) {
            CSSettingComboValue cSSettingComboValue = new CSSettingComboValue(n, n2, 70, this.mc.field_71466_p.field_78288_b + 2, this.set, string);
            this.values.add(cSSettingComboValue);
            n2 += this.mc.field_71466_p.field_78288_b + 2;
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        RenderUtil.drawGlow(this.x, this.y, this.x + this.width, this.y + this.height, ClickGUI.getColor(), 230.0);
        Gui.func_73734_a((int)this.x, (int)this.y, (int)(this.x + this.width), (int)(this.y + this.height), (int)Integer.MIN_VALUE);
        this.fr.func_78276_b(this.displayString, this.x + this.width / 2 - this.fr.func_78256_a(this.displayString) / 2, this.y + 1, Integer.MAX_VALUE);
        for (CSSettingComboValue cSSettingComboValue : this.values) {
            cSSettingComboValue.drawScreen(n, n2);
        }
        super.drawScreen(n, n2, f);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) throws IOException {
        for (CSSettingComboValue cSSettingComboValue : this.values) {
            cSSettingComboValue.mouseClicked(n, n2, n3);
        }
        super.mouseClicked(n, n2, n3);
    }
}
