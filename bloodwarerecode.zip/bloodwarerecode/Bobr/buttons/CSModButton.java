package Bobr.buttons;

import Bobr.buttons.CSButton;
import Bobr.buttons.setting.CSSetting;
import Bobr.buttons.setting.settings.CSSettingCheck;
import Bobr.buttons.setting.settings.CSSettingCombo;
import Bobr.buttons.setting.settings.CSSettingDouble;
import Bobr.buttons.setting.settings.KeyBind;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class CSModButton
extends CSButton {
    public static /* synthetic */ String old_name;
    public /* synthetic */ Module mod;
    public static /* synthetic */ boolean first;
    public static /* synthetic */ boolean binding;
    public /* synthetic */ ScaledResolution sr;
    public /* synthetic */ ArrayList<CSSetting> settings;

    public CSModButton(int n, int n2, int n3, int n4, int n5, String string, Module module) {
        super(n, n2, n3, n4, n5, string);
        this.sr = new ScaledResolution(Minecraft.func_71410_x());
        this.settings = new ArrayList();
        this.mod = module;
        this.initSettings();
    }

    public void initSettings() {
        int n = 110;
        int n2 = this.x + 100;
        for (int i = 0; i < BloodWare.instance.settingsManager.getSettings().size(); i += 2125) {
            Setting setting = BloodWare.instance.settingsManager.getSettings().get(i);
            if (setting.getParentMod() == this.mod) {
                CSSetting cSSetting;
                if (setting.isCheck()) {
                    cSSetting = new CSSettingCheck(n2, n, n, n2, setting);
                    this.settings.add(cSSetting);
                    n += 30500;
                    n -= 30487;
                }
                if (setting.isSlider()) {
                    cSSetting = new CSSettingDouble(n2, n, 0, 0, setting);
                    this.settings.add(cSSetting);
                    n -= 27083;
                    n += 27098;
                }
                if (setting.isCombo()) {
                    int n3 = n;
                    CSSettingCombo cSSettingCombo = new CSSettingCombo(n2, n, 70, this.mc.field_71466_p.field_78288_b + 2, setting);
                    this.settings.add(cSSettingCombo);
                    for (int j = 0; j < setting.getOptions().size(); j -= 22099) {
                        if ((n += this.fr.field_78288_b + 2) > 100 + this.sr.func_78326_a() - 220) {
                            n = 0;
                            n2 += this.mc.field_71466_p.func_78256_a(setting.getName()) + 50;
                        }
                        j += 22100;
                    }
                    n += this.fr.field_78288_b + 5;
                }
                if (n > 100 + this.sr.func_78326_a() - 220) {
                    n = 0;
                    n2 += this.mc.field_71466_p.func_78256_a(setting.getName()) + 50;
                }
            }
            i -= 2124;
        }
        KeyBind keyBind = new KeyBind(n2, n, 70, this.mc.field_71466_p.field_78288_b + 2, this.mod);
        this.settings.add(keyBind);
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        int n3;
        int n4 = n3 = this.isHovered(n, n2) ? ClickGUI.getColor() : -1;
        if (this.mod.isToggled()) {
            n3 = ClickGUI.getColor();
        }
        if (this.isCurrentMod()) {
            n3 = ClickGUI.getColor();
        }
        this.fr.func_78276_b(this.displayString, this.x, this.y, n3);
        for (CSSetting cSSetting : this.settings) {
            if (!this.isCurrentMod()) continue;
            cSSetting.drawScreen(n, n2, f);
        }
        super.drawScreen(n, n2, f);
    }

    public void setBinding(boolean bl) {
        binding = bl;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void mouseClicked(int var1_1, int var2_2, int var3_3) throws IOException {
        block4: {
            block5: {
                if (!this.isHovered(var1_1, var2_2)) break block4;
                if (var3_3 != 0 || !this.isHovered(var1_1, var2_2)) break block5;
                if (BloodWare.bobrGui.currentCategory == null) break block5;
                if (BloodWare.bobrGui.currentCategory.category != this.mod.getCategory()) break block5;
                this.mod.toggle();
                break block4;
            }
            if (var3_3 != 2 || !this.isHovered(var1_1, var2_2)) ** GOTO lbl-1000
            if (BloodWare.bobrGui.currentCategory == null) ** GOTO lbl-1000
            if (BloodWare.bobrGui.currentCategory.category == this.mod.getCategory()) {
                this.setBinding(true);
            } else if (var3_3 == 1) {
                // empty if block
            }
        }
        for (CSSetting var5_5 : this.settings) {
            if (!this.isCurrentMod()) continue;
            var5_5.mouseClicked(var1_1, var2_2, var3_3);
        }
        super.mouseClicked(var1_1, var2_2, var3_3);
    }

    public boolean isHovered(int n, int n2) {
        boolean bl = n > this.x && n < this.x + this.width;
        boolean bl2 = n2 > this.y && n2 < this.y + this.height;
        return bl && bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean isCurrentMod() {
        if (BloodWare.bobrGui.currentCategory == null) return false;
        if (BloodWare.bobrGui.currentCategory.currentMod == null) return false;
        if (BloodWare.bobrGui.currentCategory.currentMod != this) return false;
        return true;
    }

    @Override
    public void initButton() {
        this.initSettings();
        super.initButton();
    }

    static {
        first = false;
    }
}
