package Bobr.buttons;

import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

public abstract class CSButton
extends Gui {
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int width;
    public /* synthetic */ int height;
    public /* synthetic */ int color;
    public /* synthetic */ String displayString;
    public /* synthetic */ Minecraft mc;
    public /* synthetic */ FontRenderer fr;

    public CSButton(int n, int n2, int n3, int n4, int n5, String string) {
        this.mc = Minecraft.func_71410_x();
        this.fr = this.mc.field_71466_p;
        this.x = n;
        this.y = n2;
        this.width = n3;
        this.height = n4;
        this.color = n5;
        this.displayString = string;
    }

    public void drawScreen(int n, int n2, float f) {
    }

    public void keyTyped(char c, int n) throws IOException {
    }

    public void onKeyPress(int n, int n2) {
    }

    public void mouseClicked(int n, int n2, int n3) throws IOException {
    }

    public void mouseReleased(int n, int n2, int n3) {
    }

    public void initButton() {
    }
}
