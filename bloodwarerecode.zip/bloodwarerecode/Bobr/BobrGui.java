package Bobr;

import Bobr.buttons.CSCategoryButton;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class BobrGui
extends GuiScreen {
    public /* synthetic */ float curAlpha;
    public /* synthetic */ float anim;
    public /* synthetic */ ArrayList<CSCategoryButton> buttons;
    public /* synthetic */ CSCategoryButton currentCategory;
    public /* synthetic */ int x;
    public /* synthetic */ int y;
    public /* synthetic */ int field_146294_l;
    public /* synthetic */ int field_146295_m;
    public /* synthetic */ ScaledResolution sr;

    public BobrGui() {
        this.buttons = new ArrayList();
        this.sr = new ScaledResolution(Minecraft.func_71410_x());
        this.x = 100;
        this.y = 100;
        this.field_146294_l = this.sr.func_78326_a() - 100;
        this.field_146295_m = this.sr.func_78328_b() - 100;
        this.x = 100;
        this.y = 100;
        this.field_146294_l = this.sr.func_78326_a() - 100;
        this.field_146295_m = this.sr.func_78328_b() - 100;
    }

    public void initButtons() {
        this.buttons.clear();
        int n = 110;
        int n2 = 110;
        Category[] categoryArray = Category.values();
        int n3 = categoryArray.length;
        for (int i = 0; i < n3; i += 5065) {
            Category category = categoryArray[i];
            String string = category.name().substring(0, 1).toUpperCase() + category.name().substring(1, category.name().length()).toLowerCase();
            CSCategoryButton cSCategoryButton = new CSCategoryButton(n, n2, this.field_146297_k.field_71466_p.func_78256_a(string), this.field_146297_k.field_71466_p.field_78288_b, -1, string, category);
            this.buttons.add(cSCategoryButton);
            n2 -= 29748;
            n2 += 29763;
            i -= 5064;
        }
    }

    public ScaledResolution getScaledRes() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    public void func_73863_a(int n, int n2, float f) {
        this.func_146276_q_();
        this.anim -= 1.0f;
        float f2 = 150.0f;
        int n3 = (int)(f2 / 100.0f);
        if (this.curAlpha < f2 - (float)n3) {
            this.curAlpha += (float)n3;
        } else if (this.curAlpha > f2 - (float)n3 && this.curAlpha != f2) {
            this.curAlpha = (int)f2;
        } else if (this.curAlpha != f2) {
            this.curAlpha = (int)f2;
        }
        Color color = new Color(0, 0, 0, 0);
        this.func_73733_a(0, 0, this.getScaledRes().func_78326_a(), this.getScaledRes().func_78328_b(), new Color(0, 0, 0, 0).getRGB(), ClickGUI.getColor());
        RenderUtils.drawImage(new ResourceLocation("kuriyama.png"), (float)this.sr.func_78326_a() + 200.0f, (float)this.sr.func_78328_b() - 75.0f, 345.0f, 380.0f);
        RenderUtil.drawNewRect(this.x, this.field_146295_m, this.field_146294_l, (double)this.field_146295_m + 0.5, ClickGUI.getColor());
        RenderUtil.drawNewRect(this.field_146294_l, this.y - this.field_146289_q.field_78288_b * 2, (double)this.field_146294_l + 0.5, this.field_146295_m, ClickGUI.getColor());
        Gui.func_73734_a((int)this.x, (int)(this.y - this.field_146289_q.field_78288_b * 2), (int)this.field_146294_l, (int)this.field_146295_m, (int)new Color(50, 50, 50, 190).getRGB());
        this.field_146289_q.func_175063_a("BloodWare Client V0.2", (float)(this.x + 3), (float)(this.y - this.field_146289_q.field_78288_b - 3), Color.white.getRGB());
        RenderUtil.drawGlow(this.x + 3, this.y - this.field_146289_q.field_78288_b - 3, this.x + 3 + this.field_146289_q.func_78256_a("BloodWare Client V0.2") + 3, this.y + this.field_146289_q.field_78288_b, ClickGUI.getColor(), 70.0);
        for (CSCategoryButton cSCategoryButton : this.buttons) {
            cSCategoryButton.drawScreen(n, n2, f);
        }
        Gui.func_73734_a((int)(this.x + 65), (int)this.y, (int)(this.x + 67), (int)this.field_146295_m, (int)ClickGUI.getColor());
        Gui.func_73734_a((int)(this.x + 165), (int)this.y, (int)(this.x + 167), (int)this.field_146295_m, (int)ClickGUI.getColor());
        this.drawinfo(n, n2);
        super.func_73863_a(n, n2, f);
    }

    public boolean func_73868_f() {
        return false;
    }

    public void func_73869_a(char c, int n) throws IOException {
        for (CSCategoryButton cSCategoryButton : this.buttons) {
            cSCategoryButton.keyTyped(c, n);
        }
        super.func_73869_a(c, n);
    }

    public void drawinfo(int n, int n2) {
        int n3 = 600;
        int n4 = 100;
        int n5 = 0;
        this.field_146289_q.func_175063_a("Friends", (float)(n3 + this.field_146289_q.func_78256_a("Friends") / 2), (float)(n4 - this.field_146289_q.field_78288_b), ClickGUI.getColor());
        RenderUtil.drawRect(n3, n4, n3 + 100, n4 + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, new Color(50, 50, 50, 190).getRGB());
        RenderUtil.drawNewRect(n3 - 1, n4, n3, n4 + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor());
        RenderUtil.drawNewRect(n3 + 100 - 1, n4, n3 + 100, n4 + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor());
        RenderUtil.drawGlow(n3, n4 - 1, n3 + 100, n4, ClickGUI.getColor(), 250.0);
        RenderUtil.drawGlow(n3, n4 + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b - 1, n3 + 100, n4 + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor(), 250.0);
        for (String string : FriendManager.FRIENDS) {
            int n6 = 0 + n3;
            int n7 = 100 + n3;
            int n8 = n5 + n4;
            int n9 = n5 + this.field_146289_q.field_78288_b + n4;
            if (n > n6 && n < n7 && n2 > n8 && n2 < n9) {
                this.field_146289_q.func_78276_b(string, n3 + 50 - this.field_146289_q.func_78256_a(string) / 2, n5 + n4, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(string);
                    return;
                }
            } else {
                this.field_146289_q.func_78276_b(string, n3 + 50 - this.field_146289_q.func_78256_a(string) / 2, n5 + n4, Color.white.getRGB());
            }
            n5 += this.field_146289_q.field_78288_b;
        }
    }

    public void func_73864_a(int n, int n2, int n3) throws IOException {
        boolean bl = true;
        for (CSCategoryButton cSCategoryButton : this.buttons) {
            if (cSCategoryButton.isHovered(n, n2) && n3 == 0) {
                bl = true;
                this.currentCategory = cSCategoryButton;
            }
            cSCategoryButton.mouseClicked(n, n2, n3);
        }
        super.func_73864_a(n, n2, n3);
    }

    public void func_146286_b(int n, int n2, int n3) {
        for (CSCategoryButton cSCategoryButton : this.buttons) {
            cSCategoryButton.mouseReleased(n, n2, n3);
        }
        super.func_146286_b(n, n2, n3);
    }

    public void func_73866_w_() {
        this.initButtons();
        this.anim = 0.0f;
        this.x = 100;
        this.y = 100;
        this.field_146294_l = 500;
        this.field_146295_m = 350;
        for (CSCategoryButton cSCategoryButton : this.buttons) {
            cSCategoryButton.initButton();
        }
        super.func_73866_w_();
    }
}
