package Bobr.setting;

import com.Blood.Ware.module.Module;
import java.util.ArrayList;

public class Setting {
    public /* synthetic */ String name;
    public /* synthetic */ Module parent;
    public /* synthetic */ String displayName;
    public /* synthetic */ String mode;
    public /* synthetic */ String sval;
    public /* synthetic */ ArrayList<String> options;
    public /* synthetic */ String standardsval;
    public /* synthetic */ boolean bval;
    public /* synthetic */ boolean standardbval;
    public /* synthetic */ double dval;
    public /* synthetic */ double min;
    public /* synthetic */ double max;
    public /* synthetic */ double standarddval;
    public /* synthetic */ boolean onlyint;

    public Setting(String string, String string2, Module module, String string3, ArrayList<String> arrayList) {
        this.onlyint = false;
        this.name = string;
        this.displayName = string2;
        this.parent = module;
        this.sval = string3;
        this.standardsval = string3;
        this.options = arrayList;
        this.mode = "Combo";
    }

    public Setting(String string, String string2, Module module, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.displayName = string2;
        this.standardbval = bl;
        this.parent = module;
        this.bval = bl;
        this.mode = "Check";
    }

    public Setting(String string, String string2, Module module, double d, double d2, double d3, boolean bl) {
        this.onlyint = false;
        this.name = string;
        this.displayName = string2;
        this.parent = module;
        this.dval = d;
        this.standarddval = d;
        this.min = d2;
        this.max = d3;
        this.onlyint = bl;
        this.mode = "Slider";
    }

    public String getName() {
        return this.name;
    }

    public Module getParentMod() {
        return this.parent;
    }

    public String getValString() {
        return this.sval;
    }

    public void setValString(String string) {
        this.sval = string;
    }

    public ArrayList<String> getOptions() {
        return this.options;
    }

    public boolean getValBoolean() {
        return this.bval;
    }

    public void setValBoolean(boolean bl) {
        this.bval = bl;
    }

    public double getValDouble() {
        if (this.onlyint) {
            this.dval = (int)this.dval;
        }
        return this.dval;
    }

    public void setValDouble(double d) {
        this.dval = d;
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public boolean isCombo() {
        return this.mode.equalsIgnoreCase("Combo");
    }

    public boolean isCheck() {
        return this.mode.equalsIgnoreCase("Check");
    }

    public boolean isSlider() {
        return this.mode.equalsIgnoreCase("Slider");
    }

    public boolean onlyInt() {
        return this.onlyint;
    }
}
