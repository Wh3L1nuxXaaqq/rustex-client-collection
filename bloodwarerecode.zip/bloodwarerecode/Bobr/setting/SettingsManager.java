package Bobr.setting;

import Bobr.setting.Setting;
import com.Blood.Ware.module.Module;
import java.util.ArrayList;

public class SettingsManager {
    public /* synthetic */ ArrayList<Setting> settings;

    public SettingsManager() {
        this.settings = new ArrayList();
    }

    public void rSetting(Setting setting) {
        this.settings.add(setting);
    }

    public ArrayList<Setting> getSettings() {
        return this.settings;
    }

    public ArrayList<Setting> getSettingsByMod(Module module) {
        ArrayList<Setting> arrayList = new ArrayList<Setting>();
        for (Setting setting : this.getSettings()) {
            if (!setting.getParentMod().equals(module)) continue;
            arrayList.add(setting);
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return arrayList;
    }

    public Setting getSettingByName(String string) {
        for (Setting setting : this.getSettings()) {
            if (!setting.getName().equalsIgnoreCase(string)) continue;
            return setting;
        }
        return null;
    }
}
