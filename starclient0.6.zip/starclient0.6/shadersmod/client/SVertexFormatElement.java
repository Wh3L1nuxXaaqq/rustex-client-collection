package shadersmod.client;

import net.minecraft.client.renderer.vertex.VertexFormatElement;

public class SVertexFormatElement
extends VertexFormatElement {
    int sUsage;

    public SVertexFormatElement(int n, VertexFormatElement.EnumType enumType, int n2) {
        super(0, enumType, VertexFormatElement.EnumUsage.PADDING, n2);
        this.sUsage = n;
    }
}
