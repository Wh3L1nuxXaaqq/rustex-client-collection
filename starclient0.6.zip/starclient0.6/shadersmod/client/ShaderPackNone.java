package shadersmod.client;

import java.io.InputStream;
import shadersmod.client.IShaderPack;
import shadersmod.client.Shaders;

public class ShaderPackNone
implements IShaderPack {
    @Override
    public void close() {
    }

    @Override
    public InputStream getResourceAsStream(String string) {
        return null;
    }

    @Override
    public boolean hasDirectory(String string) {
        return false;
    }

    @Override
    public String getName() {
        return Shaders.packNameNone;
    }
}
