package shadersmod.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.math.MathHelper;
import optifine.Config;
import optifine.GuiScreenOF;
import optifine.Lang;
import optifine.StrUtils;
import shadersmod.client.GuiButtonShaderOption;
import shadersmod.client.GuiSliderShaderOption;
import shadersmod.client.ShaderOption;
import shadersmod.client.ShaderOptionProfile;
import shadersmod.client.ShaderOptionScreen;
import shadersmod.client.Shaders;

public class GuiShaderOptions
extends GuiScreenOF {
    private GuiScreen prevScreen;
    protected String title = "Shader Options";
    private GameSettings settings;
    private int lastMouseX = 0;
    private int lastMouseY = 0;
    private long mouseStillTime = 0L;
    private String screenName = null;
    private String screenText = null;
    private boolean changed = false;
    public static final String OPTION_PROFILE = "<profile>";
    public static final String OPTION_EMPTY = "<empty>";
    public static final String OPTION_REST = "*";

    public GuiShaderOptions(GuiScreen guiScreen, GameSettings gameSettings) {
        this.prevScreen = guiScreen;
        this.settings = gameSettings;
    }

    public GuiShaderOptions(GuiScreen guiScreen, GameSettings gameSettings, String string) {
        this(guiScreen, gameSettings);
        this.screenName = string;
        if (string != null) {
            this.screenText = Shaders.translate("screen." + string, string);
        }
    }

    @Override
    public void initGui() {
        this.title = I18n.format("of.options.shaderOptionsTitle", new Object[0]);
        int n = 100;
        int n2 = 0;
        int n3 = 30;
        int n4 = 20;
        int n5 = this.width - 130;
        int n6 = 120;
        int n7 = 20;
        int n8 = Shaders.getShaderPackColumns(this.screenName, 2);
        ShaderOption[] shaderOptionArray = Shaders.getShaderPackOptions(this.screenName);
        if (shaderOptionArray != null) {
            int n9 = MathHelper.ceil((double)shaderOptionArray.length / 9.0);
            if (n8 < n9) {
                n8 = n9;
            }
            for (int i = 0; i < shaderOptionArray.length; ++i) {
                ShaderOption shaderOption = shaderOptionArray[i];
                if (shaderOption == null || !shaderOption.isVisible()) continue;
                int n10 = i % n8;
                int n11 = i / n8;
                int n12 = Math.min(this.width / n8, 200);
                n2 = (this.width - n12 * n8) / 2;
                int n13 = n10 * n12 + 5 + n2;
                int n14 = n3 + n11 * n4;
                int n15 = n12 - 10;
                String string = GuiShaderOptions.getButtonText(shaderOption, n15);
                GuiButtonShaderOption guiButtonShaderOption = Shaders.isShaderPackOptionSlider(shaderOption.getName()) ? new GuiSliderShaderOption(n + i, n13, n14, n15, n7, shaderOption, string) : new GuiButtonShaderOption(n + i, n13, n14, n15, n7, shaderOption, string);
                guiButtonShaderOption.enabled = shaderOption.isEnabled();
                this.buttonList.add(guiButtonShaderOption);
            }
        }
        this.buttonList.add(new GuiButton(201, this.width / 2 - n6 - 20, this.height / 6 + 168 + 11, n6, n7, I18n.format("controls.reset", new Object[0])));
        this.buttonList.add(new GuiButton(200, this.width / 2 + 20, this.height / 6 + 168 + 11, n6, n7, I18n.format("gui.done", new Object[0])));
    }

    public static String getButtonText(ShaderOption shaderOption, int n) {
        String string = shaderOption.getNameText();
        if (shaderOption instanceof ShaderOptionScreen) {
            ShaderOptionScreen shaderOptionScreen = (ShaderOptionScreen)shaderOption;
            return string + "...";
        }
        FontRenderer fontRenderer = Config.getMinecraft().fontRendererObj;
        int n2 = fontRenderer.getStringWidth(": " + Lang.getOff()) + 5;
        while (fontRenderer.getStringWidth(string) + n2 >= n && string.length() > 0) {
            string = string.substring(0, string.length() - 1);
        }
        String string2 = shaderOption.isChanged() ? shaderOption.getValueColor(shaderOption.getValue()) : "";
        String string3 = shaderOption.getValueText(shaderOption.getValue());
        return string + ": " + string2 + string3;
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) {
        if (guiButton.enabled) {
            ShaderOption[] shaderOptionArray;
            if (guiButton.id < 200 && guiButton instanceof GuiButtonShaderOption) {
                shaderOptionArray = (ShaderOption[])guiButton;
                ShaderOption shaderOption = shaderOptionArray.getShaderOption();
                if (shaderOption instanceof ShaderOptionScreen) {
                    String string = shaderOption.getName();
                    GuiShaderOptions guiShaderOptions = new GuiShaderOptions(this, this.settings, string);
                    mc.displayGuiScreen(guiShaderOptions);
                    return;
                }
                if (GuiShaderOptions.isShiftKeyDown()) {
                    shaderOption.resetValue();
                } else {
                    shaderOption.nextValue();
                }
                this.updateAllButtons();
                this.changed = true;
            }
            if (guiButton.id == 201) {
                shaderOptionArray = Shaders.getChangedOptions(Shaders.getShaderPackOptions());
                for (int i = 0; i < shaderOptionArray.length; ++i) {
                    ShaderOption shaderOption = shaderOptionArray[i];
                    shaderOption.resetValue();
                    this.changed = true;
                }
                this.updateAllButtons();
            }
            if (guiButton.id == 200) {
                if (this.changed) {
                    Shaders.saveShaderPackOptions();
                    this.changed = false;
                    Shaders.uninit();
                }
                mc.displayGuiScreen(this.prevScreen);
            }
        }
    }

    @Override
    protected void actionPerformedRightClick(GuiButton guiButton) {
        if (guiButton instanceof GuiButtonShaderOption) {
            GuiButtonShaderOption guiButtonShaderOption = (GuiButtonShaderOption)guiButton;
            ShaderOption shaderOption = guiButtonShaderOption.getShaderOption();
            if (GuiShaderOptions.isShiftKeyDown()) {
                shaderOption.resetValue();
            } else {
                shaderOption.prevValue();
            }
            this.updateAllButtons();
            this.changed = true;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        if (this.changed) {
            Shaders.saveShaderPackOptions();
            this.changed = false;
            Shaders.uninit();
        }
    }

    private void updateAllButtons() {
        for (GuiButton guiButton : this.buttonList) {
            if (!(guiButton instanceof GuiButtonShaderOption)) continue;
            GuiButtonShaderOption guiButtonShaderOption = (GuiButtonShaderOption)guiButton;
            ShaderOption shaderOption = guiButtonShaderOption.getShaderOption();
            if (shaderOption instanceof ShaderOptionProfile) {
                ShaderOptionProfile shaderOptionProfile = (ShaderOptionProfile)shaderOption;
                shaderOptionProfile.updateProfile();
            }
            guiButtonShaderOption.displayString = GuiShaderOptions.getButtonText(shaderOption, guiButtonShaderOption.getButtonWidth());
            guiButtonShaderOption.valueChanged();
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        if (this.screenText != null) {
            this.drawCenteredString(this.fontRendererObj, this.screenText, this.width / 2, 15, 0xFFFFFF);
        } else {
            this.drawCenteredString(this.fontRendererObj, this.title, this.width / 2, 15, 0xFFFFFF);
        }
        super.drawScreen(n, n2, f);
        if (Math.abs(n - this.lastMouseX) <= 5 && Math.abs(n2 - this.lastMouseY) <= 5) {
            this.drawTooltips(n, n2, this.buttonList);
        } else {
            this.lastMouseX = n;
            this.lastMouseY = n2;
            this.mouseStillTime = System.currentTimeMillis();
        }
    }

    private void drawTooltips(int n, int n2, List list) {
        int n3 = 700;
        if (System.currentTimeMillis() >= this.mouseStillTime + (long)n3) {
            int n4 = this.width / 2 - 150;
            int n5 = this.height / 6 - 7;
            if (n2 <= n5 + 98) {
                n5 += 105;
            }
            int n6 = n4 + 150 + 150;
            int n7 = n5 + 84 + 10;
            GuiButton guiButton = GuiShaderOptions.getSelectedButton(list, n, n2);
            if (guiButton instanceof GuiButtonShaderOption) {
                GuiButtonShaderOption guiButtonShaderOption = (GuiButtonShaderOption)guiButton;
                ShaderOption shaderOption = guiButtonShaderOption.getShaderOption();
                String[] stringArray = this.makeTooltipLines(shaderOption, n6 - n4);
                if (stringArray == null) {
                    return;
                }
                this.drawGradientRect(n4, n5, n6, n7, -536870912, -536870912);
                for (int i = 0; i < stringArray.length; ++i) {
                    String string = stringArray[i];
                    int n8 = 0xDDDDDD;
                    if (string.endsWith("!")) {
                        n8 = 0xFF2020;
                    }
                    this.fontRendererObj.drawStringWithShadow(string, n4 + 5, n5 + 5 + i * 11, n8);
                }
            }
        }
    }

    private String[] makeTooltipLines(ShaderOption shaderOption, int n) {
        Object object;
        if (shaderOption instanceof ShaderOptionProfile) {
            return null;
        }
        String string = shaderOption.getNameText();
        String string2 = Config.normalize(shaderOption.getDescriptionText()).trim();
        String[] stringArray = this.splitDescription(string2);
        String string3 = null;
        if (!string.equals(shaderOption.getName()) && this.settings.advancedItemTooltips) {
            string3 = "\u00a78" + Lang.get("of.general.id") + ": " + shaderOption.getName();
        }
        String string4 = null;
        if (shaderOption.getPaths() != null && this.settings.advancedItemTooltips) {
            string4 = "\u00a78" + Lang.get("of.general.from") + ": " + Config.arrayToString(shaderOption.getPaths());
        }
        String string5 = null;
        if (shaderOption.getValueDefault() != null && this.settings.advancedItemTooltips) {
            object = shaderOption.isEnabled() ? shaderOption.getValueText(shaderOption.getValueDefault()) : Lang.get("of.general.ambiguous");
            string5 = "\u00a78" + Lang.getDefault() + ": " + (String)object;
        }
        object = new ArrayList<String>();
        object.add(string);
        object.addAll(Arrays.asList(stringArray));
        if (string3 != null) {
            object.add(string3);
        }
        if (string4 != null) {
            object.add(string4);
        }
        if (string5 != null) {
            object.add(string5);
        }
        String[] stringArray2 = this.makeTooltipLines(n, (List<String>)object);
        return stringArray2;
    }

    private String[] splitDescription(String string) {
        if (string.length() <= 0) {
            return new String[0];
        }
        string = StrUtils.removePrefix(string, "//");
        String[] stringArray = string.split("\\. ");
        for (int i = 0; i < stringArray.length; ++i) {
            stringArray[i] = "- " + stringArray[i].trim();
            stringArray[i] = StrUtils.removeSuffix(stringArray[i], ".");
        }
        return stringArray;
    }

    private String[] makeTooltipLines(int n, List<String> list) {
        FontRenderer fontRenderer = Config.getMinecraft().fontRendererObj;
        ArrayList<String> arrayList = new ArrayList<String>();
        for (int i = 0; i < list.size(); ++i) {
            String string = list.get(i);
            if (string == null || string.length() <= 0) continue;
            for (String string2 : fontRenderer.listFormattedStringToWidth(string, n)) {
                arrayList.add(string2);
            }
        }
        String[] stringArray = arrayList.toArray(new String[arrayList.size()]);
        return stringArray;
    }
}
