package shadersmod.client;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.ViewFrustum;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import shadersmod.client.IteratorRenderChunks;
import shadersmod.client.Shaders;

public class ShadowUtils {
    public static Iterator<RenderChunk> makeShadowChunkIterator(WorldClient worldClient, double d, Entity entity, int n, ViewFrustum viewFrustum) {
        float f = Shaders.getShadowRenderDistance();
        if (f > 0.0f && f < (float)((n - 1) * 16)) {
            int n2 = MathHelper.ceil(f / 16.0f) + 1;
            float f2 = worldClient.getCelestialAngleRadians((float)d);
            float f3 = Shaders.sunPathRotation * ((float)Math.PI / 180);
            float f4 = f2 > 1.5707964f && f2 < 4.712389f ? f2 + (float)Math.PI : f2;
            float f5 = -MathHelper.sin(f4);
            float f6 = MathHelper.cos(f4) * MathHelper.cos(f3);
            float f7 = -MathHelper.cos(f4) * MathHelper.sin(f3);
            BlockPos blockPos = new BlockPos(MathHelper.floor(entity.posX) >> 4, MathHelper.floor(entity.posY) >> 4, MathHelper.floor(entity.posZ) >> 4);
            BlockPos blockPos2 = blockPos.add(-f5 * (float)n2, -f6 * (float)n2, -f7 * (float)n2);
            BlockPos blockPos3 = blockPos.add(f5 * (float)n, f6 * (float)n, f7 * (float)n);
            IteratorRenderChunks iteratorRenderChunks = new IteratorRenderChunks(viewFrustum, blockPos2, blockPos3, n2, n2);
            return iteratorRenderChunks;
        }
        List<RenderChunk> list = Arrays.asList(viewFrustum.renderChunks);
        Iterator<RenderChunk> iterator = list.iterator();
        return iterator;
    }
}
