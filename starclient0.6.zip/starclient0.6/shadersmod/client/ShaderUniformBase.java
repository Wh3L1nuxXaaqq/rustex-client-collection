package shadersmod.client;

import org.lwjgl.opengl.ARBShaderObjects;

public abstract class ShaderUniformBase {
    private String name;
    private int program = -1;
    private int location = -1;

    public ShaderUniformBase(String string) {
        this.name = string;
    }

    public void setProgram(int n) {
        if (this.program != n) {
            this.program = n;
            this.location = ARBShaderObjects.glGetUniformLocationARB((int)n, (CharSequence)this.name);
            this.onProgramChanged();
        }
    }

    protected abstract void onProgramChanged();

    public String getName() {
        return this.name;
    }

    public int getProgram() {
        return this.program;
    }

    public int getLocation() {
        return this.location;
    }

    public boolean isDefined() {
        return this.location >= 0;
    }
}
