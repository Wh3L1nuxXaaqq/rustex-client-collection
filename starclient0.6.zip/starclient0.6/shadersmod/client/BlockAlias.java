package shadersmod.client;

import optifine.MatchBlock;

public class BlockAlias {
    private int blockId;
    private MatchBlock[] matchBlocks;

    public BlockAlias(int n, MatchBlock[] matchBlockArray) {
        this.blockId = n;
        this.matchBlocks = matchBlockArray;
    }

    public int getBlockId() {
        return this.blockId;
    }

    public boolean matches(int n, int n2) {
        for (int i = 0; i < this.matchBlocks.length; ++i) {
            MatchBlock matchBlock = this.matchBlocks[i];
            if (!matchBlock.matches(n, n2)) continue;
            return true;
        }
        return false;
    }

    public int[] getMatchBlockIds() {
        int[] nArray = new int[this.matchBlocks.length];
        for (int i = 0; i < nArray.length; ++i) {
            nArray[i] = this.matchBlocks[i].getBlockId();
        }
        return nArray;
    }
}
