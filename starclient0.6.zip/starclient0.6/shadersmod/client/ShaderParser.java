package shadersmod.client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import shadersmod.client.ShaderLine;

public class ShaderParser {
    public static Pattern PATTERN_UNIFORM = Pattern.compile("\\s*uniform\\s+\\w+\\s+(\\w+).*");
    public static Pattern PATTERN_COMMENT = Pattern.compile("\\s*/\\*\\s+([A-Z]+):(\\S+)\\s+\\*/.*");
    public static Pattern PATTERN_CONST_INT = Pattern.compile("\\s*const\\s+int\\s+(\\w+)\\s*=\\s*([-+.\\w]+)\\s*;.*");
    public static Pattern PATTERN_CONST_FLOAT = Pattern.compile("\\s*const\\s+float\\s+(\\w+)\\s*=\\s*([-+.\\w]+)\\s*;.*");
    public static Pattern PATTERN_CONST_BOOL = Pattern.compile("\\s*const\\s+bool\\s+(\\w+)\\s*=\\s*(\\w+)\\s*;.*");
    public static Pattern PATTERN_COMPOSITE_FSH = Pattern.compile(".*composite[0-9]?\\.fsh");
    public static Pattern PATTERN_FINAL_FSH = Pattern.compile(".*final\\.fsh");
    public static Pattern PATTERN_DRAW_BUFFERS = Pattern.compile("[0-7N]*");

    public static ShaderLine parseLine(String string) {
        Matcher matcher = PATTERN_UNIFORM.matcher(string);
        if (matcher.matches()) {
            return new ShaderLine(1, matcher.group(1), "", string);
        }
        Matcher matcher2 = PATTERN_COMMENT.matcher(string);
        if (matcher2.matches()) {
            return new ShaderLine(2, matcher2.group(1), matcher2.group(2), string);
        }
        Matcher matcher3 = PATTERN_CONST_INT.matcher(string);
        if (matcher3.matches()) {
            return new ShaderLine(3, matcher3.group(1), matcher3.group(2), string);
        }
        Matcher matcher4 = PATTERN_CONST_FLOAT.matcher(string);
        if (matcher4.matches()) {
            return new ShaderLine(4, matcher4.group(1), matcher4.group(2), string);
        }
        Matcher matcher5 = PATTERN_CONST_BOOL.matcher(string);
        return matcher5.matches() ? new ShaderLine(5, matcher5.group(1), matcher5.group(2), string) : null;
    }

    public static int getIndex(String string, String string2, int n, int n2) {
        if (string.length() != string2.length() + 1) {
            return -1;
        }
        if (!string.startsWith(string2)) {
            return -1;
        }
        int n3 = string.charAt(string2.length()) - 48;
        return n3 >= n && n3 <= n2 ? n3 : -1;
    }

    public static int getShadowDepthIndex(String string) {
        int n = -1;
        switch (string.hashCode()) {
            case -903579360: {
                if (!string.equals("shadow")) break;
                n = 0;
                break;
            }
            case 1235669239: {
                if (!string.equals("watershadow")) break;
                n = 1;
            }
        }
        switch (n) {
            case 0: {
                return 0;
            }
            case 1: {
                return 1;
            }
        }
        return ShaderParser.getIndex(string, "shadowtex", 0, 1);
    }

    public static int getShadowColorIndex(String string) {
        int n = -1;
        switch (string.hashCode()) {
            case -1560188349: {
                if (!string.equals("shadowcolor")) break;
                n = 0;
            }
        }
        switch (n) {
            case 0: {
                return 0;
            }
        }
        return ShaderParser.getIndex(string, "shadowcolor", 0, 1);
    }

    public static int getDepthIndex(String string) {
        return ShaderParser.getIndex(string, "depthtex", 0, 2);
    }

    public static int getColorIndex(String string) {
        int n = ShaderParser.getIndex(string, "gaux", 1, 4);
        return n > 0 ? n + 3 : ShaderParser.getIndex(string, "colortex", 4, 7);
    }

    public static boolean isComposite(String string) {
        return PATTERN_COMPOSITE_FSH.matcher(string).matches();
    }

    public static boolean isFinal(String string) {
        return PATTERN_FINAL_FSH.matcher(string).matches();
    }

    public static boolean isValidDrawBuffers(String string) {
        return PATTERN_DRAW_BUFFERS.matcher(string).matches();
    }
}
