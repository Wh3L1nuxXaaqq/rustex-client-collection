package shadersmod.client;

import org.lwjgl.opengl.ARBShaderObjects;
import shadersmod.client.ShaderUniformBase;
import shadersmod.client.Shaders;

public class ShaderUniformInt
extends ShaderUniformBase {
    private int value = -1;

    public ShaderUniformInt(String string) {
        super(string);
    }

    @Override
    protected void onProgramChanged() {
        this.value = -1;
    }

    public void setValue(int n) {
        if (this.getLocation() >= 0 && this.value != n) {
            ARBShaderObjects.glUniform1iARB((int)this.getLocation(), (int)n);
            Shaders.checkGLError(this.getName());
            this.value = n;
        }
    }

    public int getValue() {
        return this.value;
    }
}
