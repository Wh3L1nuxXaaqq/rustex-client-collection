package shadersmod.client;

import net.minecraft.client.gui.GuiButton;
import shadersmod.client.ShaderOption;

public class GuiButtonShaderOption
extends GuiButton {
    private ShaderOption shaderOption = null;

    public GuiButtonShaderOption(int n, int n2, int n3, int n4, int n5, ShaderOption shaderOption, String string) {
        super(n, n2, n3, n4, n5, string);
        this.shaderOption = shaderOption;
    }

    public ShaderOption getShaderOption() {
        return this.shaderOption;
    }

    public void valueChanged() {
    }
}
