package shadersmod.client;

import java.io.InputStream;
import shadersmod.client.IShaderPack;
import shadersmod.client.Shaders;

public class ShaderPackDefault
implements IShaderPack {
    @Override
    public void close() {
    }

    @Override
    public InputStream getResourceAsStream(String string) {
        return ShaderPackDefault.class.getResourceAsStream(string);
    }

    @Override
    public String getName() {
        return Shaders.packNameDefault;
    }

    @Override
    public boolean hasDirectory(String string) {
        return false;
    }
}
