package shadersmod.client;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;
import optifine.Config;
import optifine.StrUtils;
import shadersmod.client.IShaderPack;
import shadersmod.client.ScreenShaderOptions;
import shadersmod.client.ShaderMacros;
import shadersmod.client.ShaderOption;
import shadersmod.client.ShaderOptionProfile;
import shadersmod.client.ShaderOptionRest;
import shadersmod.client.ShaderOptionScreen;
import shadersmod.client.ShaderOptionSwitch;
import shadersmod.client.ShaderOptionSwitchConst;
import shadersmod.client.ShaderOptionVariable;
import shadersmod.client.ShaderOptionVariableConst;
import shadersmod.client.ShaderProfile;
import shadersmod.client.ShaderUtils;
import shadersmod.client.Shaders;

public class ShaderPackParser {
    private static final Pattern PATTERN_VERSION = Pattern.compile("^\\s*#version\\s+.*$");
    private static final Pattern PATTERN_INCLUDE = Pattern.compile("^\\s*#include\\s+\"([A-Za-z0-9_/\\.]+)\".*$");
    private static final Set<String> setConstNames = ShaderPackParser.makeSetConstNames();

    public static ShaderOption[] parseShaderPackOptions(IShaderPack iShaderPack, String[] stringArray, List<Integer> list) {
        String string;
        if (iShaderPack == null) {
            return new ShaderOption[0];
        }
        HashMap<String, ShaderOption> hashMap = new HashMap<String, ShaderOption>();
        ShaderPackParser.collectShaderOptions(iShaderPack, "/shaders", stringArray, hashMap);
        for (int n : list) {
            string = "/shaders/world" + n;
            ShaderPackParser.collectShaderOptions(iShaderPack, string, stringArray, hashMap);
        }
        Collection collection = hashMap.values();
        string = collection.toArray(new ShaderOption[collection.size()]);
        Comparator<ShaderOption> comparator = new Comparator<ShaderOption>(){

            @Override
            public int compare(ShaderOption shaderOption, ShaderOption shaderOption2) {
                return shaderOption.getName().compareToIgnoreCase(shaderOption2.getName());
            }
        };
        Arrays.sort(string, comparator);
        return string;
    }

    private static void collectShaderOptions(IShaderPack iShaderPack, String string, String[] stringArray, Map<String, ShaderOption> map) {
        for (int i = 0; i < stringArray.length; ++i) {
            String string2 = stringArray[i];
            if (string2.equals("")) continue;
            String string3 = string + "/" + string2 + ".vsh";
            String string4 = string + "/" + string2 + ".fsh";
            ShaderPackParser.collectShaderOptions(iShaderPack, string3, map);
            ShaderPackParser.collectShaderOptions(iShaderPack, string4, map);
        }
    }

    private static void collectShaderOptions(IShaderPack iShaderPack, String string, Map<String, ShaderOption> map) {
        String[] stringArray = ShaderPackParser.getLines(iShaderPack, string);
        for (int i = 0; i < stringArray.length; ++i) {
            String string2 = stringArray[i];
            ShaderOption shaderOption = ShaderPackParser.getShaderOption(string2, string);
            if (shaderOption == null || shaderOption.getName().startsWith(ShaderMacros.getPrefixMacro()) || shaderOption.checkUsed() && !ShaderPackParser.isOptionUsed(shaderOption, stringArray)) continue;
            String string3 = shaderOption.getName();
            ShaderOption shaderOption2 = map.get(string3);
            if (shaderOption2 != null) {
                if (!Config.equals(shaderOption2.getValueDefault(), shaderOption.getValueDefault())) {
                    Config.warn("Ambiguous shader option: " + shaderOption.getName());
                    Config.warn(" - in " + Config.arrayToString(shaderOption2.getPaths()) + ": " + shaderOption2.getValueDefault());
                    Config.warn(" - in " + Config.arrayToString(shaderOption.getPaths()) + ": " + shaderOption.getValueDefault());
                    shaderOption2.setEnabled(false);
                }
                if (shaderOption2.getDescription() == null || shaderOption2.getDescription().length() <= 0) {
                    shaderOption2.setDescription(shaderOption.getDescription());
                }
                shaderOption2.addPaths(shaderOption.getPaths());
                continue;
            }
            map.put(string3, shaderOption);
        }
    }

    private static boolean isOptionUsed(ShaderOption shaderOption, String[] stringArray) {
        for (int i = 0; i < stringArray.length; ++i) {
            String string = stringArray[i];
            if (!shaderOption.isUsedInLine(string)) continue;
            return true;
        }
        return false;
    }

    private static String[] getLines(IShaderPack iShaderPack, String string) {
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            String string2 = ShaderPackParser.loadFile(string, iShaderPack, 0, arrayList, 0);
            if (string2 == null) {
                return new String[0];
            }
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(string2.getBytes());
            String[] stringArray = Config.readLines(byteArrayInputStream);
            return stringArray;
        }
        catch (IOException iOException) {
            Config.dbg(iOException.getClass().getName() + ": " + iOException.getMessage());
            return new String[0];
        }
    }

    private static ShaderOption getShaderOption(String string, String string2) {
        ShaderOption shaderOption = null;
        if (shaderOption == null) {
            shaderOption = ShaderOptionSwitch.parseOption(string, string2);
        }
        if (shaderOption == null) {
            shaderOption = ShaderOptionVariable.parseOption(string, string2);
        }
        if (shaderOption != null) {
            return shaderOption;
        }
        if (shaderOption == null) {
            shaderOption = ShaderOptionSwitchConst.parseOption(string, string2);
        }
        if (shaderOption == null) {
            shaderOption = ShaderOptionVariableConst.parseOption(string, string2);
        }
        return shaderOption != null && setConstNames.contains(shaderOption.getName()) ? shaderOption : null;
    }

    private static Set<String> makeSetConstNames() {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add("shadowMapResolution");
        hashSet.add("shadowMapFov");
        hashSet.add("shadowDistance");
        hashSet.add("shadowDistanceRenderMul");
        hashSet.add("shadowIntervalSize");
        hashSet.add("generateShadowMipmap");
        hashSet.add("generateShadowColorMipmap");
        hashSet.add("shadowHardwareFiltering");
        hashSet.add("shadowHardwareFiltering0");
        hashSet.add("shadowHardwareFiltering1");
        hashSet.add("shadowtex0Mipmap");
        hashSet.add("shadowtexMipmap");
        hashSet.add("shadowtex1Mipmap");
        hashSet.add("shadowcolor0Mipmap");
        hashSet.add("shadowColor0Mipmap");
        hashSet.add("shadowcolor1Mipmap");
        hashSet.add("shadowColor1Mipmap");
        hashSet.add("shadowtex0Nearest");
        hashSet.add("shadowtexNearest");
        hashSet.add("shadow0MinMagNearest");
        hashSet.add("shadowtex1Nearest");
        hashSet.add("shadow1MinMagNearest");
        hashSet.add("shadowcolor0Nearest");
        hashSet.add("shadowColor0Nearest");
        hashSet.add("shadowColor0MinMagNearest");
        hashSet.add("shadowcolor1Nearest");
        hashSet.add("shadowColor1Nearest");
        hashSet.add("shadowColor1MinMagNearest");
        hashSet.add("wetnessHalflife");
        hashSet.add("drynessHalflife");
        hashSet.add("eyeBrightnessHalflife");
        hashSet.add("centerDepthHalflife");
        hashSet.add("sunPathRotation");
        hashSet.add("ambientOcclusionLevel");
        hashSet.add("superSamplingLevel");
        hashSet.add("noiseTextureResolution");
        return hashSet;
    }

    public static ShaderProfile[] parseProfiles(Properties properties, ShaderOption[] shaderOptionArray) {
        String string = "profile.";
        ArrayList<ShaderProfile> arrayList = new ArrayList<ShaderProfile>();
        for (Object object : properties.keySet()) {
            String string2 = (String)object;
            if (!string2.startsWith(string)) continue;
            String string3 = string2.substring(string.length());
            properties.getProperty(string2);
            HashSet<String> hashSet = new HashSet<String>();
            ShaderProfile shaderProfile = ShaderPackParser.parseProfile(string3, properties, hashSet, shaderOptionArray);
            if (shaderProfile == null) continue;
            arrayList.add(shaderProfile);
        }
        if (arrayList.size() <= 0) {
            return null;
        }
        ShaderProfile[] shaderProfileArray = arrayList.toArray(new ShaderProfile[arrayList.size()]);
        return shaderProfileArray;
    }

    public static Set<String> parseOptionSliders(Properties properties, ShaderOption[] shaderOptionArray) {
        HashSet<String> hashSet = new HashSet<String>();
        String string = properties.getProperty("sliders");
        if (string == null) {
            return hashSet;
        }
        String[] stringArray = Config.tokenize(string, " ");
        for (int i = 0; i < stringArray.length; ++i) {
            String string2 = stringArray[i];
            ShaderOption shaderOption = ShaderUtils.getShaderOption(string2, shaderOptionArray);
            if (shaderOption == null) {
                Config.warn("Invalid shader option: " + string2);
                continue;
            }
            hashSet.add(string2);
        }
        return hashSet;
    }

    private static ShaderProfile parseProfile(String string, Properties properties, Set<String> set, ShaderOption[] shaderOptionArray) {
        String string2 = "profile.";
        String string3 = string2 + string;
        if (set.contains(string3)) {
            Config.warn("[Shaders] Profile already parsed: " + string);
            return null;
        }
        set.add(string);
        ShaderProfile shaderProfile = new ShaderProfile(string);
        String string4 = properties.getProperty(string3);
        String[] stringArray = Config.tokenize(string4, " ");
        for (int i = 0; i < stringArray.length; ++i) {
            Object object;
            Object object2;
            Object object3;
            String string5 = stringArray[i];
            if (string5.startsWith(string2)) {
                object3 = string5.substring(string2.length());
                object2 = ShaderPackParser.parseProfile((String)object3, properties, set, shaderOptionArray);
                if (shaderProfile == null) continue;
                shaderProfile.addOptionValues((ShaderProfile)object2);
                shaderProfile.addDisabledPrograms(((ShaderProfile)object2).getDisabledPrograms());
                continue;
            }
            object3 = Config.tokenize(string5, ":=");
            if (((String[])object3).length == 1) {
                Object object4;
                object2 = object3[0];
                boolean bl = true;
                if (((String)object2).startsWith("!")) {
                    bl = false;
                    object2 = ((String)object2).substring(1);
                }
                object = "program.";
                if (!bl && ((String)object2).startsWith("program.")) {
                    object4 = ((String)object2).substring(((String)object).length());
                    if (!Shaders.isProgramPath((String)object4)) {
                        Config.warn("Invalid program: " + (String)object4 + " in profile: " + shaderProfile.getName());
                        continue;
                    }
                    shaderProfile.addDisabledProgram((String)object4);
                    continue;
                }
                object4 = ShaderUtils.getShaderOption((String)object2, shaderOptionArray);
                if (!(object4 instanceof ShaderOptionSwitch)) {
                    Config.warn("[Shaders] Invalid option: " + (String)object2);
                    continue;
                }
                shaderProfile.addOptionValue((String)object2, String.valueOf(bl));
                ((ShaderOption)object4).setVisible(true);
                continue;
            }
            if (((String[])object3).length != 2) {
                Config.warn("[Shaders] Invalid option value: " + string5);
                continue;
            }
            object2 = object3[0];
            String string6 = object3[1];
            object = ShaderUtils.getShaderOption((String)object2, shaderOptionArray);
            if (object == null) {
                Config.warn("[Shaders] Invalid option: " + string5);
                continue;
            }
            if (!((ShaderOption)object).isValidValue(string6)) {
                Config.warn("[Shaders] Invalid value: " + string5);
                continue;
            }
            ((ShaderOption)object).setVisible(true);
            shaderProfile.addOptionValue((String)object2, string6);
        }
        return shaderProfile;
    }

    public static Map<String, ScreenShaderOptions> parseGuiScreens(Properties properties, ShaderProfile[] shaderProfileArray, ShaderOption[] shaderOptionArray) {
        HashMap<String, ScreenShaderOptions> hashMap = new HashMap<String, ScreenShaderOptions>();
        ShaderPackParser.parseGuiScreen("screen", properties, hashMap, shaderProfileArray, shaderOptionArray);
        return hashMap.isEmpty() ? null : hashMap;
    }

    private static boolean parseGuiScreen(String string, Properties properties, Map<String, ScreenShaderOptions> map, ShaderProfile[] shaderProfileArray, ShaderOption[] shaderOptionArray) {
        Object object;
        String string2;
        String string3 = properties.getProperty(string);
        if (string3 == null) {
            return false;
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        HashSet<String> hashSet = new HashSet<String>();
        String[] stringArray = Config.tokenize(string3, " ");
        for (int i = 0; i < stringArray.length; ++i) {
            Object object2;
            string2 = stringArray[i];
            if (string2.equals("<empty>")) {
                arrayList.add(null);
                continue;
            }
            if (hashSet.contains(string2)) {
                Config.warn("[Shaders] Duplicate option: " + string2 + ", key: " + string);
                continue;
            }
            hashSet.add(string2);
            if (string2.equals("<profile>")) {
                if (shaderProfileArray == null) {
                    Config.warn("[Shaders] Option profile can not be used, no profiles defined: " + string2 + ", key: " + string);
                    continue;
                }
                object2 = new ShaderOptionProfile(shaderProfileArray, shaderOptionArray);
                arrayList.add(object2);
                continue;
            }
            if (string2.equals("*")) {
                object2 = new ShaderOptionRest("<rest>");
                arrayList.add(object2);
                continue;
            }
            if (string2.startsWith("[") && string2.endsWith("]")) {
                object2 = StrUtils.removePrefixSuffix(string2, "[", "]");
                if (!((String)object2).matches("^[a-zA-Z0-9_]+$")) {
                    Config.warn("[Shaders] Invalid screen: " + string2 + ", key: " + string);
                    continue;
                }
                if (!ShaderPackParser.parseGuiScreen("screen." + (String)object2, properties, map, shaderProfileArray, shaderOptionArray)) {
                    Config.warn("[Shaders] Invalid screen: " + string2 + ", key: " + string);
                    continue;
                }
                object = new ShaderOptionScreen((String)object2);
                arrayList.add(object);
                continue;
            }
            object2 = ShaderUtils.getShaderOption(string2, shaderOptionArray);
            if (object2 == null) {
                Config.warn("[Shaders] Invalid option: " + string2 + ", key: " + string);
                arrayList.add(null);
                continue;
            }
            ((ShaderOption)object2).setVisible(true);
            arrayList.add(object2);
        }
        ShaderOption[] shaderOptionArray2 = arrayList.toArray(new ShaderOption[arrayList.size()]);
        string2 = properties.getProperty(string + ".columns");
        int n = Config.parseInt(string2, 2);
        object = new ScreenShaderOptions(string, shaderOptionArray2, n);
        map.put(string, (ScreenShaderOptions)object);
        return true;
    }

    public static BufferedReader resolveIncludes(BufferedReader bufferedReader, String string, IShaderPack iShaderPack, int n, List<String> list, int n2) throws IOException {
        String string2 = "/";
        int n3 = string.lastIndexOf("/");
        if (n3 >= 0) {
            string2 = string.substring(0, n3);
        }
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        int n4 = -1;
        LinkedHashSet<Object> linkedHashSet = new LinkedHashSet<Object>();
        int n5 = 1;
        while (true) {
            Object object5;
            Object object2;
            Object object3;
            Object object4;
            if ((object4 = bufferedReader.readLine()) == null) {
                object3 = charArrayWriter.toCharArray();
                if (n4 >= 0 && linkedHashSet.size() > 0) {
                    object2 = new StringBuilder();
                    for (Object object5 : linkedHashSet) {
                        object2.append("#define ");
                        object2.append((String)object5);
                        object2.append("\n");
                    }
                    String string3 = object2.toString();
                    object5 = new StringBuilder(new String((char[])object3));
                    ((StringBuilder)object5).insert(n4, string3);
                    String string4 = ((StringBuilder)object5).toString();
                    object3 = string4.toCharArray();
                }
                object2 = new CharArrayReader((char[])object3);
                return new BufferedReader((Reader)object2);
            }
            if (n4 < 0 && (object3 = (Object)PATTERN_VERSION.matcher((CharSequence)object4)).matches()) {
                object2 = ShaderMacros.getMacroLines();
                String string5 = (String)object4 + "\n" + (String)object2;
                object5 = "#line " + (n5 + 1) + " " + n;
                object4 = string5 + (String)object5;
                n4 = charArrayWriter.size() + string5.length();
            }
            if ((object3 = (Object)PATTERN_INCLUDE.matcher((CharSequence)object4)).matches()) {
                int n6;
                object2 = object3.group(1);
                boolean bl = object2.startsWith("/");
                Object object6 = object5 = bl ? "/shaders" + (String)object2 : string2 + "/" + (String)object2;
                if (!list.contains(object5)) {
                    list.add((String)object5);
                }
                if ((object4 = ShaderPackParser.loadFile((String)object5, iShaderPack, n6 = list.indexOf(object5) + 1, list, n2)) == null) {
                    throw new IOException("Included file not found: " + string);
                }
                if (((String)object4).endsWith("\n")) {
                    object4 = ((String)object4).substring(0, ((String)object4).length() - 1);
                }
                object4 = "#line 1 " + n6 + "\n" + (String)object4 + "\n#line " + (n5 + 1) + " " + n;
            }
            if (n4 >= 0 && ((String)object4).contains(ShaderMacros.getPrefixMacro())) {
                object2 = ShaderPackParser.findExtensions((String)object4, ShaderMacros.getExtensions());
                for (int i = 0; i < ((String[])object2).length; ++i) {
                    object5 = object2[i];
                    linkedHashSet.add(object5);
                }
            }
            charArrayWriter.write((String)object4);
            charArrayWriter.write("\n");
            ++n5;
        }
    }

    private static String[] findExtensions(String string, String[] stringArray) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (int i = 0; i < stringArray.length; ++i) {
            String string2 = stringArray[i];
            if (!string.contains(string2)) continue;
            arrayList.add(string2);
        }
        String[] stringArray2 = arrayList.toArray(new String[arrayList.size()]);
        return stringArray2;
    }

    private static String loadFile(String string, IShaderPack iShaderPack, int n, List<String> list, int n2) throws IOException {
        if (n2 >= 10) {
            throw new IOException("#include depth exceeded: " + n2 + ", file: " + string);
        }
        ++n2;
        InputStream inputStream = iShaderPack.getResourceAsStream(string);
        if (inputStream == null) {
            return null;
        }
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ASCII");
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        bufferedReader = ShaderPackParser.resolveIncludes(bufferedReader, string, iShaderPack, n, list, n2);
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        String string2;
        while ((string2 = bufferedReader.readLine()) != null) {
            charArrayWriter.write(string2);
            charArrayWriter.write("\n");
        }
        return charArrayWriter.toString();
    }
}
