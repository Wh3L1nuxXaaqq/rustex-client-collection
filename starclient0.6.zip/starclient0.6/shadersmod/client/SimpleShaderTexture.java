package shadersmod.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.data.AnimationMetadataSection;
import net.minecraft.client.resources.data.AnimationMetadataSectionSerializer;
import net.minecraft.client.resources.data.FontMetadataSection;
import net.minecraft.client.resources.data.FontMetadataSectionSerializer;
import net.minecraft.client.resources.data.LanguageMetadataSection;
import net.minecraft.client.resources.data.LanguageMetadataSectionSerializer;
import net.minecraft.client.resources.data.MetadataSerializer;
import net.minecraft.client.resources.data.PackMetadataSection;
import net.minecraft.client.resources.data.PackMetadataSectionSerializer;
import net.minecraft.client.resources.data.TextureMetadataSection;
import net.minecraft.client.resources.data.TextureMetadataSectionSerializer;
import org.apache.commons.io.IOUtils;
import shadersmod.client.Shaders;
import shadersmod.common.SMCLog;

public class SimpleShaderTexture
extends AbstractTexture {
    private String texturePath;
    private static final MetadataSerializer METADATA_SERIALIZER = SimpleShaderTexture.makeMetadataSerializer();

    public SimpleShaderTexture(String string) {
        this.texturePath = string;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void loadTexture(IResourceManager iResourceManager) throws IOException {
        this.deleteGlTexture();
        InputStream inputStream = Shaders.getShaderPackResourceStream(this.texturePath);
        if (inputStream == null) {
            throw new FileNotFoundException("Shader texture not found: " + this.texturePath);
        }
        try {
            BufferedImage bufferedImage = TextureUtil.readBufferedImage(inputStream);
            TextureMetadataSection textureMetadataSection = this.loadTextureMetadataSection();
            TextureUtil.uploadTextureImageAllocate(this.getGlTextureId(), bufferedImage, textureMetadataSection.getTextureBlur(), textureMetadataSection.getTextureClamp());
        }
        finally {
            IOUtils.closeQuietly((InputStream)inputStream);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private TextureMetadataSection loadTextureMetadataSection() {
        String string = this.texturePath + ".mcmeta";
        String string2 = "texture";
        InputStream inputStream = Shaders.getShaderPackResourceStream(string);
        if (inputStream != null) {
            TextureMetadataSection textureMetadataSection;
            TextureMetadataSection textureMetadataSection2;
            MetadataSerializer metadataSerializer = METADATA_SERIALIZER;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            try {
                JsonObject jsonObject = new JsonParser().parse(bufferedReader).getAsJsonObject();
                textureMetadataSection2 = (TextureMetadataSection)metadataSerializer.parseMetadataSection(string2, jsonObject);
                if (textureMetadataSection2 == null) {
                    TextureMetadataSection textureMetadataSection3 = new TextureMetadataSection(false, false);
                    return textureMetadataSection3;
                }
                textureMetadataSection = textureMetadataSection2;
            }
            catch (RuntimeException runtimeException) {
                SMCLog.warning("Error reading metadata: " + string);
                SMCLog.warning(runtimeException.getClass().getName() + ": " + runtimeException.getMessage());
                textureMetadataSection2 = new TextureMetadataSection(false, false);
                return textureMetadataSection2;
            }
            finally {
                IOUtils.closeQuietly((Reader)bufferedReader);
                IOUtils.closeQuietly((InputStream)inputStream);
            }
            return textureMetadataSection;
        }
        return new TextureMetadataSection(false, false);
    }

    private static MetadataSerializer makeMetadataSerializer() {
        MetadataSerializer metadataSerializer = new MetadataSerializer();
        metadataSerializer.registerMetadataSectionType(new TextureMetadataSectionSerializer(), TextureMetadataSection.class);
        metadataSerializer.registerMetadataSectionType(new FontMetadataSectionSerializer(), FontMetadataSection.class);
        metadataSerializer.registerMetadataSectionType(new AnimationMetadataSectionSerializer(), AnimationMetadataSection.class);
        metadataSerializer.registerMetadataSectionType(new PackMetadataSectionSerializer(), PackMetadataSection.class);
        metadataSerializer.registerMetadataSectionType(new LanguageMetadataSectionSerializer(), LanguageMetadataSection.class);
        return metadataSerializer;
    }
}
