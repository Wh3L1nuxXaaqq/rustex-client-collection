package shadersmod.client;

import org.lwjgl.opengl.ARBShaderObjects;
import shadersmod.client.ShaderUniformBase;
import shadersmod.client.Shaders;

public class ShaderUniformFloat4
extends ShaderUniformBase {
    private float[] values = new float[4];

    public ShaderUniformFloat4(String string) {
        super(string);
    }

    @Override
    protected void onProgramChanged() {
        this.values[0] = 0.0f;
        this.values[1] = 0.0f;
        this.values[2] = 0.0f;
        this.values[3] = 0.0f;
    }

    public void setValue(float f, float f2, float f3, float f4) {
        if (this.getLocation() >= 0 && (this.values[0] != f || this.values[1] != f2 || this.values[2] != f3 || this.values[3] != f4)) {
            ARBShaderObjects.glUniform4fARB((int)this.getLocation(), (float)f, (float)f2, (float)f3, (float)f4);
            Shaders.checkGLError(this.getName());
            this.values[0] = f;
            this.values[1] = f2;
            this.values[2] = f3;
            this.values[3] = f4;
        }
    }

    public float[] getValues() {
        return this.values;
    }
}
