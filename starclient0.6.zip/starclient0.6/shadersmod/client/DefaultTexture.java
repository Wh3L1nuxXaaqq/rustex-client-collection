package shadersmod.client;

import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.resources.IResourceManager;
import shadersmod.client.ShadersTex;

public class DefaultTexture
extends AbstractTexture {
    public DefaultTexture() {
        this.loadTexture(null);
    }

    @Override
    public void loadTexture(IResourceManager iResourceManager) {
        int[] nArray = ShadersTex.createAIntImage(1, -1);
        ShadersTex.setupTexture(this.getMultiTexID(), nArray, 1, 1, false, false);
    }
}
