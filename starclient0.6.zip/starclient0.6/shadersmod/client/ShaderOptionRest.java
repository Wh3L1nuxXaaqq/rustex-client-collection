package shadersmod.client;

import shadersmod.client.ShaderOption;

public class ShaderOptionRest
extends ShaderOption {
    public ShaderOptionRest(String string) {
        super(string, string, null, new String[]{null}, null, null);
    }
}
