package shadersmod.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import optifine.Config;
import optifine.ConnectedParser;
import optifine.MatchBlock;
import optifine.PropertiesOrdered;
import optifine.StrUtils;
import shadersmod.client.BlockAlias;
import shadersmod.client.IShaderPack;

public class BlockAliases {
    private static BlockAlias[][] blockAliases = null;

    public static int getMappedBlockId(int n, int n2) {
        if (blockAliases == null) {
            return n;
        }
        if (n >= 0 && n < blockAliases.length) {
            BlockAlias[] blockAliasArray = blockAliases[n];
            if (blockAliasArray == null) {
                return n;
            }
            for (int i = 0; i < blockAliasArray.length; ++i) {
                BlockAlias blockAlias = blockAliasArray[i];
                if (!blockAlias.matches(n, n2)) continue;
                return blockAlias.getBlockId();
            }
            return n;
        }
        return n;
    }

    public static void update(IShaderPack iShaderPack) {
        BlockAliases.reset();
        String string = "/shaders/block.properties";
        try {
            InputStream inputStream = iShaderPack.getResourceAsStream(string);
            if (inputStream == null) {
                return;
            }
            PropertiesOrdered propertiesOrdered = new PropertiesOrdered();
            propertiesOrdered.load(inputStream);
            inputStream.close();
            Config.dbg("[Shaders] Parsing block mappings: " + string);
            ArrayList<List<BlockAlias>> arrayList = new ArrayList<List<BlockAlias>>();
            ConnectedParser connectedParser = new ConnectedParser("Shaders");
            for (Object object : ((Properties)propertiesOrdered).keySet()) {
                String string2 = (String)object;
                String string3 = propertiesOrdered.getProperty(string2);
                String string4 = "block.";
                if (!string2.startsWith(string4)) {
                    Config.warn("[Shaders] Invalid block ID: " + string2);
                    continue;
                }
                String string5 = StrUtils.removePrefix(string2, string4);
                int n = Config.parseInt(string5, -1);
                if (n < 0) {
                    Config.warn("[Shaders] Invalid block ID: " + string2);
                    continue;
                }
                MatchBlock[] matchBlockArray = connectedParser.parseMatchBlocks(string3);
                if (matchBlockArray != null && matchBlockArray.length >= 1) {
                    BlockAlias blockAlias = new BlockAlias(n, matchBlockArray);
                    BlockAliases.addToList(arrayList, blockAlias);
                    continue;
                }
                Config.warn("[Shaders] Invalid block ID mapping: " + string2 + "=" + string3);
            }
            if (arrayList.size() <= 0) {
                return;
            }
            blockAliases = BlockAliases.toArrays(arrayList);
        }
        catch (IOException iOException) {
            Config.warn("[Shaders] Error reading: " + string);
        }
    }

    private static void addToList(List<List<BlockAlias>> list, BlockAlias blockAlias) {
        int[] nArray = blockAlias.getMatchBlockIds();
        for (int i = 0; i < nArray.length; ++i) {
            int n = nArray[i];
            while (n >= list.size()) {
                list.add(null);
            }
            List<BlockAlias> list2 = list.get(n);
            if (list2 == null) {
                list2 = new ArrayList<BlockAlias>();
                list.set(n, list2);
            }
            list2.add(blockAlias);
        }
    }

    private static BlockAlias[][] toArrays(List<List<BlockAlias>> list) {
        BlockAlias[][] blockAliasArray = new BlockAlias[list.size()][];
        for (int i = 0; i < blockAliasArray.length; ++i) {
            List<BlockAlias> list2 = list.get(i);
            if (list2 == null) continue;
            blockAliasArray[i] = list2.toArray(new BlockAlias[list2.size()]);
        }
        return blockAliasArray;
    }

    public static void reset() {
        blockAliases = null;
    }
}
