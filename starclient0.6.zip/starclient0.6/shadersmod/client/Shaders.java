package shadersmod.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import optifine.Config;
import optifine.CustomColors;
import optifine.EntityUtils;
import optifine.Lang;
import optifine.PropertiesOrdered;
import optifine.Reflector;
import optifine.StrUtils;
import org.apache.commons.io.IOUtils;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.ARBVertexShader;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.GLU;
import shadersmod.client.BlockAliases;
import shadersmod.client.CustomTexture;
import shadersmod.client.EnumShaderOption;
import shadersmod.client.HFNoiseTexture;
import shadersmod.client.ICustomTexture;
import shadersmod.client.IShaderPack;
import shadersmod.client.PropertyDefaultFastFancyOff;
import shadersmod.client.PropertyDefaultTrueFalse;
import shadersmod.client.SMath;
import shadersmod.client.ScreenShaderOptions;
import shadersmod.client.ShaderLine;
import shadersmod.client.ShaderOption;
import shadersmod.client.ShaderOptionProfile;
import shadersmod.client.ShaderOptionRest;
import shadersmod.client.ShaderPackDefault;
import shadersmod.client.ShaderPackFolder;
import shadersmod.client.ShaderPackNone;
import shadersmod.client.ShaderPackParser;
import shadersmod.client.ShaderPackZip;
import shadersmod.client.ShaderParser;
import shadersmod.client.ShaderProfile;
import shadersmod.client.ShaderUniformFloat4;
import shadersmod.client.ShaderUniformInt;
import shadersmod.client.ShaderUtils;
import shadersmod.client.ShadersRender;
import shadersmod.client.ShadersTex;
import shadersmod.client.SimpleShaderTexture;
import shadersmod.common.SMCLog;

public class Shaders {
    static Minecraft mc;
    static EntityRenderer entityRenderer;
    public static boolean isInitializedOnce;
    public static boolean isShaderPackInitialized;
    public static ContextCapabilities capabilities;
    public static String glVersionString;
    public static String glVendorString;
    public static String glRendererString;
    public static boolean hasGlGenMipmap;
    public static boolean hasForge;
    public static int numberResetDisplayList;
    static boolean needResetModels;
    private static int renderDisplayWidth;
    private static int renderDisplayHeight;
    public static int renderWidth;
    public static int renderHeight;
    public static boolean isRenderingWorld;
    public static boolean isRenderingSky;
    public static boolean isCompositeRendered;
    public static boolean isRenderingDfb;
    public static boolean isShadowPass;
    public static boolean isSleeping;
    private static boolean isRenderingFirstPersonHand;
    private static boolean isHandRenderedMain;
    private static boolean isHandRenderedOff;
    private static boolean skipRenderHandMain;
    private static boolean skipRenderHandOff;
    public static boolean renderItemKeepDepthMask;
    public static boolean itemToRenderMainTranslucent;
    public static boolean itemToRenderOffTranslucent;
    static float[] sunPosition;
    static float[] moonPosition;
    static float[] shadowLightPosition;
    static float[] upPosition;
    static float[] shadowLightPositionVector;
    static float[] upPosModelView;
    static float[] sunPosModelView;
    static float[] moonPosModelView;
    private static float[] tempMat;
    static float clearColorR;
    static float clearColorG;
    static float clearColorB;
    static float skyColorR;
    static float skyColorG;
    static float skyColorB;
    static long worldTime;
    static long lastWorldTime;
    static long diffWorldTime;
    static float celestialAngle;
    static float sunAngle;
    static float shadowAngle;
    static int moonPhase;
    static long systemTime;
    static long lastSystemTime;
    static long diffSystemTime;
    static int frameCounter;
    static float frameTime;
    static float frameTimeCounter;
    static int systemTimeInt32;
    static float rainStrength;
    static float wetness;
    public static float wetnessHalfLife;
    public static float drynessHalfLife;
    public static float eyeBrightnessHalflife;
    static boolean usewetness;
    static int isEyeInWater;
    static int eyeBrightness;
    static float eyeBrightnessFadeX;
    static float eyeBrightnessFadeY;
    static float eyePosY;
    static float centerDepth;
    static float centerDepthSmooth;
    static float centerDepthSmoothHalflife;
    static boolean centerDepthSmoothEnabled;
    static int superSamplingLevel;
    static float nightVision;
    static float blindness;
    static boolean updateChunksErrorRecorded;
    static boolean lightmapEnabled;
    static boolean fogEnabled;
    public static int entityAttrib;
    public static int midTexCoordAttrib;
    public static int tangentAttrib;
    public static boolean useEntityAttrib;
    public static boolean useMidTexCoordAttrib;
    public static boolean useMultiTexCoord3Attrib;
    public static boolean useTangentAttrib;
    public static boolean progUseEntityAttrib;
    public static boolean progUseMidTexCoordAttrib;
    public static boolean progUseTangentAttrib;
    public static int atlasSizeX;
    public static int atlasSizeY;
    public static ShaderUniformFloat4 uniformEntityColor;
    public static ShaderUniformInt uniformEntityId;
    public static ShaderUniformInt uniformBlockEntityId;
    static double previousCameraPositionX;
    static double previousCameraPositionY;
    static double previousCameraPositionZ;
    static double cameraPositionX;
    static double cameraPositionY;
    static double cameraPositionZ;
    static int shadowPassInterval;
    public static boolean needResizeShadow;
    static int shadowMapWidth;
    static int shadowMapHeight;
    static int spShadowMapWidth;
    static int spShadowMapHeight;
    static float shadowMapFOV;
    static float shadowMapHalfPlane;
    static boolean shadowMapIsOrtho;
    static float shadowDistanceRenderMul;
    static int shadowPassCounter;
    static int preShadowPassThirdPersonView;
    public static boolean shouldSkipDefaultShadow;
    static boolean waterShadowEnabled;
    static final int MaxDrawBuffers = 8;
    static final int MaxColorBuffers = 8;
    static final int MaxDepthBuffers = 3;
    static final int MaxShadowColorBuffers = 8;
    static final int MaxShadowDepthBuffers = 2;
    static int usedColorBuffers;
    static int usedDepthBuffers;
    static int usedShadowColorBuffers;
    static int usedShadowDepthBuffers;
    static int usedColorAttachs;
    static int usedDrawBuffers;
    static int dfb;
    static int sfb;
    private static int[] gbuffersFormat;
    private static boolean[] gbuffersClear;
    public static int activeProgram;
    public static final int ProgramNone = 0;
    public static final int ProgramBasic = 1;
    public static final int ProgramTextured = 2;
    public static final int ProgramTexturedLit = 3;
    public static final int ProgramSkyBasic = 4;
    public static final int ProgramSkyTextured = 5;
    public static final int ProgramClouds = 6;
    public static final int ProgramTerrain = 7;
    public static final int ProgramTerrainSolid = 8;
    public static final int ProgramTerrainCutoutMip = 9;
    public static final int ProgramTerrainCutout = 10;
    public static final int ProgramDamagedBlock = 11;
    public static final int ProgramWater = 12;
    public static final int ProgramBlock = 13;
    public static final int ProgramBeaconBeam = 14;
    public static final int ProgramItem = 15;
    public static final int ProgramEntities = 16;
    public static final int ProgramArmorGlint = 17;
    public static final int ProgramSpiderEyes = 18;
    public static final int ProgramHand = 19;
    public static final int ProgramWeather = 20;
    public static final int ProgramComposite = 21;
    public static final int ProgramComposite1 = 22;
    public static final int ProgramComposite2 = 23;
    public static final int ProgramComposite3 = 24;
    public static final int ProgramComposite4 = 25;
    public static final int ProgramComposite5 = 26;
    public static final int ProgramComposite6 = 27;
    public static final int ProgramComposite7 = 28;
    public static final int ProgramFinal = 29;
    public static final int ProgramShadow = 30;
    public static final int ProgramShadowSolid = 31;
    public static final int ProgramShadowCutout = 32;
    public static final int ProgramCount = 33;
    public static final int MaxCompositePasses = 8;
    private static final String[] programNames;
    private static final int[] programBackups;
    static int[] programsID;
    private static int[] programsRef;
    private static int programIDCopyDepth;
    private static String[] programsDrawBufSettings;
    private static String newDrawBufSetting;
    static IntBuffer[] programsDrawBuffers;
    static IntBuffer activeDrawBuffers;
    private static String[] programsColorAtmSettings;
    private static String newColorAtmSetting;
    private static String activeColorAtmSettings;
    private static int[] programsCompositeMipmapSetting;
    private static int newCompositeMipmapSetting;
    private static int activeCompositeMipmapSetting;
    public static Properties loadedShaders;
    public static Properties shadersConfig;
    public static ITextureObject defaultTexture;
    public static boolean normalMapEnabled;
    public static boolean[] shadowHardwareFilteringEnabled;
    public static boolean[] shadowMipmapEnabled;
    public static boolean[] shadowFilterNearest;
    public static boolean[] shadowColorMipmapEnabled;
    public static boolean[] shadowColorFilterNearest;
    public static boolean configTweakBlockDamage;
    public static boolean configCloudShadow;
    public static float configHandDepthMul;
    public static float configRenderResMul;
    public static float configShadowResMul;
    public static int configTexMinFilB;
    public static int configTexMinFilN;
    public static int configTexMinFilS;
    public static int configTexMagFilB;
    public static int configTexMagFilN;
    public static int configTexMagFilS;
    public static boolean configShadowClipFrustrum;
    public static boolean configNormalMap;
    public static boolean configSpecularMap;
    public static PropertyDefaultTrueFalse configOldLighting;
    public static PropertyDefaultTrueFalse configOldHandLight;
    public static int configAntialiasingLevel;
    public static final int texMinFilRange = 3;
    public static final int texMagFilRange = 2;
    public static final String[] texMinFilDesc;
    public static final String[] texMagFilDesc;
    public static final int[] texMinFilValue;
    public static final int[] texMagFilValue;
    static IShaderPack shaderPack;
    public static boolean shaderPackLoaded;
    static File currentshader;
    static String currentshadername;
    public static String packNameNone;
    static String packNameDefault;
    static String shaderpacksdirname;
    static String optionsfilename;
    static File shadersdir;
    static File shaderpacksdir;
    static File configFile;
    static ShaderOption[] shaderPackOptions;
    static Set<String> shaderPackOptionSliders;
    static ShaderProfile[] shaderPackProfiles;
    static Map<String, ScreenShaderOptions> shaderPackGuiScreens;
    public static PropertyDefaultFastFancyOff shaderPackClouds;
    public static PropertyDefaultTrueFalse shaderPackOldLighting;
    public static PropertyDefaultTrueFalse shaderPackOldHandLight;
    public static PropertyDefaultTrueFalse shaderPackDynamicHandLight;
    public static PropertyDefaultTrueFalse shaderPackShadowTranslucent;
    public static PropertyDefaultTrueFalse shaderPackUnderwaterOverlay;
    public static PropertyDefaultTrueFalse shaderPackSun;
    public static PropertyDefaultTrueFalse shaderPackMoon;
    public static PropertyDefaultTrueFalse shaderPackVignette;
    public static PropertyDefaultTrueFalse shaderPackBackFaceSolid;
    public static PropertyDefaultTrueFalse shaderPackBackFaceCutout;
    public static PropertyDefaultTrueFalse shaderPackBackFaceCutoutMipped;
    public static PropertyDefaultTrueFalse shaderPackBackFaceTranslucent;
    private static Map<String, String> shaderPackResources;
    private static World currentWorld;
    private static List<Integer> shaderPackDimensions;
    private static CustomTexture[] customTexturesGbuffers;
    private static CustomTexture[] customTexturesComposite;
    private static String noiseTexturePath;
    private static final int STAGE_GBUFFERS = 0;
    private static final int STAGE_COMPOSITE = 1;
    private static final String[] STAGE_NAMES;
    public static final boolean enableShadersOption = true;
    private static final boolean enableShadersDebug = true;
    private static final boolean saveFinalShaders;
    public static float blockLightLevel05;
    public static float blockLightLevel06;
    public static float blockLightLevel08;
    public static float aoLevel;
    public static float sunPathRotation;
    public static float shadowAngleInterval;
    public static int fogMode;
    public static float fogColorR;
    public static float fogColorG;
    public static float fogColorB;
    public static float shadowIntervalSize;
    public static int terrainIconSize;
    public static int[] terrainTextureSize;
    private static ICustomTexture noiseTexture;
    private static boolean noiseTextureEnabled;
    private static int noiseTextureResolution;
    static final int[] dfbColorTexturesA;
    static final int[] colorTexturesToggle;
    static final int[] colorTextureTextureImageUnit;
    static final boolean[][] programsToggleColorTextures;
    private static final int bigBufferSize = 2196;
    private static final ByteBuffer bigBuffer;
    static final float[] faProjection;
    static final float[] faProjectionInverse;
    static final float[] faModelView;
    static final float[] faModelViewInverse;
    static final float[] faShadowProjection;
    static final float[] faShadowProjectionInverse;
    static final float[] faShadowModelView;
    static final float[] faShadowModelViewInverse;
    static final FloatBuffer projection;
    static final FloatBuffer projectionInverse;
    static final FloatBuffer modelView;
    static final FloatBuffer modelViewInverse;
    static final FloatBuffer shadowProjection;
    static final FloatBuffer shadowProjectionInverse;
    static final FloatBuffer shadowModelView;
    static final FloatBuffer shadowModelViewInverse;
    static final FloatBuffer previousProjection;
    static final FloatBuffer previousModelView;
    static final FloatBuffer tempMatrixDirectBuffer;
    static final FloatBuffer tempDirectFloatBuffer;
    static final IntBuffer dfbColorTextures;
    static final IntBuffer dfbDepthTextures;
    static final IntBuffer sfbColorTextures;
    static final IntBuffer sfbDepthTextures;
    static final IntBuffer dfbDrawBuffers;
    static final IntBuffer sfbDrawBuffers;
    static final IntBuffer drawBuffersNone;
    static final IntBuffer drawBuffersAll;
    static final IntBuffer drawBuffersClear0;
    static final IntBuffer drawBuffersClear1;
    static final IntBuffer drawBuffersClearColor;
    static final IntBuffer drawBuffersColorAtt0;
    static final IntBuffer[] drawBuffersBuffer;
    static Map<Block, Integer> mapBlockToEntityData;
    private static final String[] formatNames;
    private static final int[] formatIds;
    private static final Pattern patternLoadEntityDataMap;
    public static int[] entityData;
    public static int entityDataIndex;

    private static ByteBuffer nextByteBuffer(int n) {
        ByteBuffer byteBuffer = bigBuffer;
        int n2 = byteBuffer.limit();
        byteBuffer.position(n2).limit(n2 + n);
        return byteBuffer.slice();
    }

    private static IntBuffer nextIntBuffer(int n) {
        ByteBuffer byteBuffer = bigBuffer;
        int n2 = byteBuffer.limit();
        byteBuffer.position(n2).limit(n2 + n * 4);
        return byteBuffer.asIntBuffer();
    }

    private static FloatBuffer nextFloatBuffer(int n) {
        ByteBuffer byteBuffer = bigBuffer;
        int n2 = byteBuffer.limit();
        byteBuffer.position(n2).limit(n2 + n * 4);
        return byteBuffer.asFloatBuffer();
    }

    private static IntBuffer[] nextIntBufferArray(int n, int n2) {
        IntBuffer[] intBufferArray = new IntBuffer[n];
        for (int i = 0; i < n; ++i) {
            intBufferArray[i] = Shaders.nextIntBuffer(n2);
        }
        return intBufferArray;
    }

    public static void loadConfig() {
        Object object;
        SMCLog.info("Load ShadersMod configuration.");
        try {
            if (!shaderpacksdir.exists()) {
                shaderpacksdir.mkdir();
            }
        }
        catch (Exception exception) {
            SMCLog.severe("Failed to open the shaderpacks directory: " + String.valueOf(shaderpacksdir));
        }
        shadersConfig = new PropertiesOrdered();
        shadersConfig.setProperty(EnumShaderOption.SHADER_PACK.getPropertyKey(), "");
        if (configFile.exists()) {
            try {
                object = new FileReader(configFile);
                shadersConfig.load((Reader)object);
                ((InputStreamReader)object).close();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (!configFile.exists()) {
            try {
                Shaders.storeConfig();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        object = EnumShaderOption.values();
        for (int i = 0; i < ((EnumShaderOption[])object).length; ++i) {
            Object object2 = object[i];
            String string = ((EnumShaderOption)((Object)object2)).getPropertyKey();
            String string2 = ((EnumShaderOption)((Object)object2)).getValueDefault();
            String string3 = shadersConfig.getProperty(string, string2);
            Shaders.setEnumShaderOption((EnumShaderOption)((Object)object2), string3);
        }
        Shaders.loadShaderPack();
    }

    private static void setEnumShaderOption(EnumShaderOption enumShaderOption, String string) {
        if (string == null) {
            string = enumShaderOption.getValueDefault();
        }
        switch (enumShaderOption) {
            case ANTIALIASING: {
                configAntialiasingLevel = Config.parseInt(string, 0);
                break;
            }
            case NORMAL_MAP: {
                configNormalMap = Config.parseBoolean(string, true);
                break;
            }
            case SPECULAR_MAP: {
                configSpecularMap = Config.parseBoolean(string, true);
                break;
            }
            case RENDER_RES_MUL: {
                configRenderResMul = Config.parseFloat(string, 1.0f);
                break;
            }
            case SHADOW_RES_MUL: {
                configShadowResMul = Config.parseFloat(string, 1.0f);
                break;
            }
            case HAND_DEPTH_MUL: {
                configHandDepthMul = Config.parseFloat(string, 0.125f);
                break;
            }
            case CLOUD_SHADOW: {
                configCloudShadow = Config.parseBoolean(string, true);
                break;
            }
            case OLD_HAND_LIGHT: {
                configOldHandLight.setPropertyValue(string);
                break;
            }
            case OLD_LIGHTING: {
                configOldLighting.setPropertyValue(string);
                break;
            }
            case SHADER_PACK: {
                currentshadername = string;
                break;
            }
            case TWEAK_BLOCK_DAMAGE: {
                configTweakBlockDamage = Config.parseBoolean(string, true);
                break;
            }
            case SHADOW_CLIP_FRUSTRUM: {
                configShadowClipFrustrum = Config.parseBoolean(string, true);
                break;
            }
            case TEX_MIN_FIL_B: {
                configTexMinFilB = Config.parseInt(string, 0);
                break;
            }
            case TEX_MIN_FIL_N: {
                configTexMinFilN = Config.parseInt(string, 0);
                break;
            }
            case TEX_MIN_FIL_S: {
                configTexMinFilS = Config.parseInt(string, 0);
                break;
            }
            case TEX_MAG_FIL_B: {
                configTexMagFilB = Config.parseInt(string, 0);
                break;
            }
            case TEX_MAG_FIL_N: {
                configTexMagFilB = Config.parseInt(string, 0);
                break;
            }
            case TEX_MAG_FIL_S: {
                configTexMagFilB = Config.parseInt(string, 0);
                break;
            }
            default: {
                throw new IllegalArgumentException("Unknown option: " + String.valueOf((Object)enumShaderOption));
            }
        }
    }

    public static void storeConfig() {
        SMCLog.info("Save ShadersMod configuration.");
        if (shadersConfig == null) {
            shadersConfig = new PropertiesOrdered();
        }
        EnumShaderOption[] enumShaderOptionArray = EnumShaderOption.values();
        for (int i = 0; i < enumShaderOptionArray.length; ++i) {
            EnumShaderOption enumShaderOption = enumShaderOptionArray[i];
            String string = enumShaderOption.getPropertyKey();
            String string2 = Shaders.getEnumShaderOption(enumShaderOption);
            shadersConfig.setProperty(string, string2);
        }
        try {
            FileWriter fileWriter = new FileWriter(configFile);
            shadersConfig.store(fileWriter, (String)null);
            fileWriter.close();
        }
        catch (Exception exception) {
            SMCLog.severe("Error saving configuration: " + exception.getClass().getName() + ": " + exception.getMessage());
        }
    }

    public static String getEnumShaderOption(EnumShaderOption enumShaderOption) {
        switch (enumShaderOption) {
            case ANTIALIASING: {
                return Integer.toString(configAntialiasingLevel);
            }
            case NORMAL_MAP: {
                return Boolean.toString(configNormalMap);
            }
            case SPECULAR_MAP: {
                return Boolean.toString(configSpecularMap);
            }
            case RENDER_RES_MUL: {
                return Float.toString(configRenderResMul);
            }
            case SHADOW_RES_MUL: {
                return Float.toString(configShadowResMul);
            }
            case HAND_DEPTH_MUL: {
                return Float.toString(configHandDepthMul);
            }
            case CLOUD_SHADOW: {
                return Boolean.toString(configCloudShadow);
            }
            case OLD_HAND_LIGHT: {
                return configOldHandLight.getPropertyValue();
            }
            case OLD_LIGHTING: {
                return configOldLighting.getPropertyValue();
            }
            case SHADER_PACK: {
                return currentshadername;
            }
            case TWEAK_BLOCK_DAMAGE: {
                return Boolean.toString(configTweakBlockDamage);
            }
            case SHADOW_CLIP_FRUSTRUM: {
                return Boolean.toString(configShadowClipFrustrum);
            }
            case TEX_MIN_FIL_B: {
                return Integer.toString(configTexMinFilB);
            }
            case TEX_MIN_FIL_N: {
                return Integer.toString(configTexMinFilN);
            }
            case TEX_MIN_FIL_S: {
                return Integer.toString(configTexMinFilS);
            }
            case TEX_MAG_FIL_B: {
                return Integer.toString(configTexMagFilB);
            }
            case TEX_MAG_FIL_N: {
                return Integer.toString(configTexMagFilB);
            }
            case TEX_MAG_FIL_S: {
                return Integer.toString(configTexMagFilB);
            }
        }
        throw new IllegalArgumentException("Unknown option: " + String.valueOf((Object)enumShaderOption));
    }

    public static void setShaderPack(String string) {
        currentshadername = string;
        shadersConfig.setProperty(EnumShaderOption.SHADER_PACK.getPropertyKey(), string);
        Shaders.loadShaderPack();
    }

    public static void loadShaderPack() {
        boolean bl;
        String string;
        boolean bl2 = shaderPackLoaded;
        boolean bl3 = Shaders.isOldLighting();
        shaderPackLoaded = false;
        if (shaderPack != null) {
            shaderPack.close();
            shaderPack = null;
            shaderPackResources.clear();
            shaderPackDimensions.clear();
            shaderPackOptions = null;
            shaderPackOptionSliders = null;
            shaderPackProfiles = null;
            shaderPackGuiScreens = null;
            shaderPackClouds.resetValue();
            shaderPackOldHandLight.resetValue();
            shaderPackDynamicHandLight.resetValue();
            shaderPackOldLighting.resetValue();
            Shaders.resetCustomTextures();
            noiseTexturePath = null;
        }
        boolean bl4 = false;
        if (Config.isAntialiasing()) {
            SMCLog.info("Shaders can not be loaded, Antialiasing is enabled: " + Config.getAntialiasingLevel() + "x");
            bl4 = true;
        }
        if (Config.isAnisotropicFiltering()) {
            SMCLog.info("Shaders can not be loaded, Anisotropic Filtering is enabled: " + Config.getAnisotropicFilterLevel() + "x");
            bl4 = true;
        }
        if (Config.isFastRender()) {
            SMCLog.info("Shaders can not be loaded, Fast Render is enabled.");
            bl4 = true;
        }
        if (!((string = shadersConfig.getProperty(EnumShaderOption.SHADER_PACK.getPropertyKey(), packNameDefault)).isEmpty() || string.equals(packNameNone) || bl4)) {
            if (string.equals(packNameDefault)) {
                shaderPack = new ShaderPackDefault();
                shaderPackLoaded = true;
            } else {
                try {
                    File file = new File(shaderpacksdir, string);
                    if (file.isDirectory()) {
                        shaderPack = new ShaderPackFolder(string, file);
                        shaderPackLoaded = true;
                    } else if (file.isFile() && string.toLowerCase().endsWith(".zip")) {
                        shaderPack = new ShaderPackZip(string, file);
                        shaderPackLoaded = true;
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
        if (shaderPack != null) {
            SMCLog.info("Loaded shaderpack: " + Shaders.getShaderPackName());
        } else {
            SMCLog.info("No shaderpack loaded.");
            shaderPack = new ShaderPackNone();
        }
        Shaders.loadShaderPackResources();
        Shaders.loadShaderPackDimensions();
        shaderPackOptions = Shaders.loadShaderPackOptions();
        Shaders.loadShaderPackProperties();
        boolean bl5 = shaderPackLoaded != bl2;
        boolean bl6 = bl = Shaders.isOldLighting() != bl3;
        if (bl5 || bl) {
            DefaultVertexFormats.updateVertexFormats();
            if (Reflector.LightUtil.exists()) {
                Reflector.LightUtil_itemConsumer.setValue(null);
                Reflector.LightUtil_tessellator.setValue(null);
            }
            Shaders.updateBlockLightLevel();
            mc.scheduleResourcesRefresh();
        }
    }

    private static void loadShaderPackDimensions() {
        shaderPackDimensions.clear();
        for (int i = -128; i <= 128; ++i) {
            String string = "/shaders/world" + i;
            if (!shaderPack.hasDirectory(string)) continue;
            shaderPackDimensions.add(i);
        }
        if (shaderPackDimensions.size() > 0) {
            Integer[] integerArray = shaderPackDimensions.toArray(new Integer[shaderPackDimensions.size()]);
            Config.dbg("[Shaders] Worlds: " + Config.arrayToString((Object[])integerArray));
        }
    }

    private static void loadShaderPackProperties() {
        shaderPackClouds.resetValue();
        shaderPackOldHandLight.resetValue();
        shaderPackDynamicHandLight.resetValue();
        shaderPackOldLighting.resetValue();
        shaderPackShadowTranslucent.resetValue();
        shaderPackUnderwaterOverlay.resetValue();
        shaderPackSun.resetValue();
        shaderPackMoon.resetValue();
        shaderPackVignette.resetValue();
        shaderPackBackFaceSolid.resetValue();
        shaderPackBackFaceCutout.resetValue();
        shaderPackBackFaceCutoutMipped.resetValue();
        shaderPackBackFaceTranslucent.resetValue();
        BlockAliases.reset();
        if (shaderPack != null) {
            BlockAliases.update(shaderPack);
            String string = "/shaders/shaders.properties";
            try {
                InputStream inputStream = shaderPack.getResourceAsStream(string);
                if (inputStream == null) {
                    return;
                }
                PropertiesOrdered propertiesOrdered = new PropertiesOrdered();
                propertiesOrdered.load(inputStream);
                inputStream.close();
                shaderPackClouds.loadFrom(propertiesOrdered);
                shaderPackOldHandLight.loadFrom(propertiesOrdered);
                shaderPackDynamicHandLight.loadFrom(propertiesOrdered);
                shaderPackOldLighting.loadFrom(propertiesOrdered);
                shaderPackShadowTranslucent.loadFrom(propertiesOrdered);
                shaderPackUnderwaterOverlay.loadFrom(propertiesOrdered);
                shaderPackSun.loadFrom(propertiesOrdered);
                shaderPackVignette.loadFrom(propertiesOrdered);
                shaderPackMoon.loadFrom(propertiesOrdered);
                shaderPackBackFaceSolid.loadFrom(propertiesOrdered);
                shaderPackBackFaceCutout.loadFrom(propertiesOrdered);
                shaderPackBackFaceCutoutMipped.loadFrom(propertiesOrdered);
                shaderPackBackFaceTranslucent.loadFrom(propertiesOrdered);
                shaderPackOptionSliders = ShaderPackParser.parseOptionSliders(propertiesOrdered, shaderPackOptions);
                shaderPackProfiles = ShaderPackParser.parseProfiles(propertiesOrdered, shaderPackOptions);
                shaderPackGuiScreens = ShaderPackParser.parseGuiScreens(propertiesOrdered, shaderPackProfiles, shaderPackOptions);
                customTexturesGbuffers = Shaders.loadCustomTextures(propertiesOrdered, 0);
                customTexturesComposite = Shaders.loadCustomTextures(propertiesOrdered, 1);
                noiseTexturePath = propertiesOrdered.getProperty("texture.noise");
                if (noiseTexturePath != null) {
                    noiseTextureEnabled = true;
                }
            }
            catch (IOException iOException) {
                Config.warn("[Shaders] Error reading: " + string);
            }
        }
    }

    private static CustomTexture[] loadCustomTextures(Properties properties, int n) {
        String string = "texture." + STAGE_NAMES[n] + ".";
        Set<Object> set = properties.keySet();
        ArrayList<CustomTexture> arrayList = new ArrayList<CustomTexture>();
        for (Object object : set) {
            String string2 = (String)object;
            if (!string2.startsWith(string)) continue;
            String string3 = string2.substring(string.length());
            String string4 = properties.getProperty(string2).trim();
            int n2 = Shaders.getTextureIndex(n, string3);
            if (n2 < 0) {
                SMCLog.warning("Invalid texture name: " + string2);
                continue;
            }
            CustomTexture customTexture = Shaders.loadCustomTexture(n2, string4);
            if (customTexture == null) continue;
            arrayList.add(customTexture);
        }
        if (arrayList.size() <= 0) {
            return null;
        }
        CustomTexture[] customTextureArray = arrayList.toArray(new CustomTexture[arrayList.size()]);
        return customTextureArray;
    }

    private static CustomTexture loadCustomTexture(int n, String object) {
        if (object == null) {
            return null;
        }
        if (((String)(object = ((String)object).trim())).indexOf(46) < 0) {
            object = (String)object + ".png";
        }
        try {
            String string = "shaders/" + StrUtils.removePrefix((String)object, "/");
            InputStream inputStream = shaderPack.getResourceAsStream(string);
            if (inputStream == null) {
                SMCLog.warning("Texture not found: " + (String)object);
                return null;
            }
            IOUtils.closeQuietly((InputStream)inputStream);
            SimpleShaderTexture simpleShaderTexture = new SimpleShaderTexture(string);
            simpleShaderTexture.loadTexture(mc.getResourceManager());
            CustomTexture customTexture = new CustomTexture(n, string, simpleShaderTexture);
            return customTexture;
        }
        catch (IOException iOException) {
            SMCLog.warning("Error loading texture: " + (String)object);
            SMCLog.warning(iOException.getClass().getName() + ": " + iOException.getMessage());
            return null;
        }
    }

    private static int getTextureIndex(int n, String string) {
        if (n == 0) {
            if (string.equals("texture")) {
                return 0;
            }
            if (string.equals("lightmap")) {
                return 1;
            }
            if (string.equals("normals")) {
                return 2;
            }
            if (string.equals("specular")) {
                return 3;
            }
            if (string.equals("shadowtex0") || string.equals("watershadow")) {
                return 4;
            }
            if (string.equals("shadow")) {
                return waterShadowEnabled ? 5 : 4;
            }
            if (string.equals("shadowtex1")) {
                return 5;
            }
            if (string.equals("depthtex0")) {
                return 6;
            }
            if (string.equals("gaux1")) {
                return 7;
            }
            if (string.equals("gaux2")) {
                return 8;
            }
            if (string.equals("gaux3")) {
                return 9;
            }
            if (string.equals("gaux4")) {
                return 10;
            }
            if (string.equals("depthtex1")) {
                return 12;
            }
            if (string.equals("shadowcolor0") || string.equals("shadowcolor")) {
                return 13;
            }
            if (string.equals("shadowcolor1")) {
                return 14;
            }
            if (string.equals("noisetex")) {
                return 15;
            }
        }
        if (n == 1) {
            if (string.equals("colortex0") || string.equals("colortex0")) {
                return 0;
            }
            if (string.equals("colortex1") || string.equals("gdepth")) {
                return 1;
            }
            if (string.equals("colortex2") || string.equals("gnormal")) {
                return 2;
            }
            if (string.equals("colortex3") || string.equals("composite")) {
                return 3;
            }
            if (string.equals("shadowtex0") || string.equals("watershadow")) {
                return 4;
            }
            if (string.equals("shadow")) {
                return waterShadowEnabled ? 5 : 4;
            }
            if (string.equals("shadowtex1")) {
                return 5;
            }
            if (string.equals("depthtex0") || string.equals("gdepthtex")) {
                return 6;
            }
            if (string.equals("colortex4") || string.equals("gaux1")) {
                return 7;
            }
            if (string.equals("colortex5") || string.equals("gaux2")) {
                return 8;
            }
            if (string.equals("colortex6") || string.equals("gaux3")) {
                return 9;
            }
            if (string.equals("colortex7") || string.equals("gaux4")) {
                return 10;
            }
            if (string.equals("depthtex1")) {
                return 11;
            }
            if (string.equals("depthtex2")) {
                return 12;
            }
            if (string.equals("shadowcolor0") || string.equals("shadowcolor")) {
                return 13;
            }
            if (string.equals("shadowcolor1")) {
                return 14;
            }
            if (string.equals("noisetex")) {
                return 15;
            }
        }
        return -1;
    }

    private static void bindCustomTextures(CustomTexture[] customTextureArray) {
        if (customTextureArray != null) {
            for (int i = 0; i < customTextureArray.length; ++i) {
                CustomTexture customTexture = customTextureArray[i];
                GlStateManager.setActiveTexture(33984 + customTexture.getTextureUnit());
                ITextureObject iTextureObject = customTexture.getTexture();
                GlStateManager.bindTexture(iTextureObject.getGlTextureId());
            }
        }
    }

    private static void resetCustomTextures() {
        Shaders.deleteCustomTextures(customTexturesGbuffers);
        Shaders.deleteCustomTextures(customTexturesComposite);
        customTexturesGbuffers = null;
        customTexturesComposite = null;
    }

    private static void deleteCustomTextures(CustomTexture[] customTextureArray) {
        if (customTextureArray != null) {
            for (int i = 0; i < customTextureArray.length; ++i) {
                CustomTexture customTexture = customTextureArray[i];
                customTexture.deleteTexture();
            }
        }
    }

    public static ShaderOption[] getShaderPackOptions(String string) {
        Object[] objectArray = (ShaderOption[])shaderPackOptions.clone();
        if (shaderPackGuiScreens == null) {
            if (shaderPackProfiles != null) {
                ShaderOptionProfile shaderOptionProfile = new ShaderOptionProfile(shaderPackProfiles, (ShaderOption[])objectArray);
                objectArray = (ShaderOption[])Config.addObjectToArray(objectArray, shaderOptionProfile, 0);
            }
            objectArray = Shaders.getVisibleOptions((ShaderOption[])objectArray);
            return objectArray;
        }
        Object object = string != null ? "screen." + string : "screen";
        ScreenShaderOptions screenShaderOptions = shaderPackGuiScreens.get(object);
        if (screenShaderOptions == null) {
            return new ShaderOption[0];
        }
        ShaderOption[] shaderOptionArray = screenShaderOptions.getShaderOptions();
        ArrayList<ShaderOption> arrayList = new ArrayList<ShaderOption>();
        for (int i = 0; i < shaderOptionArray.length; ++i) {
            ShaderOption shaderOption = shaderOptionArray[i];
            if (shaderOption == null) {
                arrayList.add(null);
                continue;
            }
            if (shaderOption instanceof ShaderOptionRest) {
                ShaderOption[] shaderOptionArray2 = Shaders.getShaderOptionsRest(shaderPackGuiScreens, (ShaderOption[])objectArray);
                arrayList.addAll(Arrays.asList(shaderOptionArray2));
                continue;
            }
            arrayList.add(shaderOption);
        }
        ShaderOption[] shaderOptionArray3 = arrayList.toArray(new ShaderOption[arrayList.size()]);
        return shaderOptionArray3;
    }

    public static int getShaderPackColumns(String string, int n) {
        Object object;
        Object object2 = object = string != null ? "screen." + string : "screen";
        if (shaderPackGuiScreens == null) {
            return n;
        }
        ScreenShaderOptions screenShaderOptions = shaderPackGuiScreens.get(object);
        return screenShaderOptions == null ? n : screenShaderOptions.getColumns();
    }

    private static ShaderOption[] getShaderOptionsRest(Map<String, ScreenShaderOptions> map, ShaderOption[] shaderOptionArray) {
        Object object;
        Object object2;
        HashSet<String> hashSet = new HashSet<String>();
        for (String string : map.keySet()) {
            object2 = map.get(string);
            object = ((ScreenShaderOptions)object2).getShaderOptions();
            for (int i = 0; i < ((ShaderOption[])object).length; ++i) {
                ShaderOption shaderOption = object[i];
                if (shaderOption == null) continue;
                hashSet.add(shaderOption.getName());
            }
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < shaderOptionArray.length; ++i) {
            object2 = shaderOptionArray[i];
            if (!((ShaderOption)object2).isVisible() || hashSet.contains(object = ((ShaderOption)object2).getName())) continue;
            arrayList.add(object2);
        }
        ShaderOption[] shaderOptionArray2 = arrayList.toArray(new ShaderOption[arrayList.size()]);
        return shaderOptionArray2;
    }

    public static ShaderOption getShaderOption(String string) {
        return ShaderUtils.getShaderOption(string, shaderPackOptions);
    }

    public static ShaderOption[] getShaderPackOptions() {
        return shaderPackOptions;
    }

    public static boolean isShaderPackOptionSlider(String string) {
        return shaderPackOptionSliders == null ? false : shaderPackOptionSliders.contains(string);
    }

    private static ShaderOption[] getVisibleOptions(ShaderOption[] shaderOptionArray) {
        ArrayList<ShaderOption> arrayList = new ArrayList<ShaderOption>();
        for (int i = 0; i < shaderOptionArray.length; ++i) {
            ShaderOption shaderOption = shaderOptionArray[i];
            if (!shaderOption.isVisible()) continue;
            arrayList.add(shaderOption);
        }
        ShaderOption[] shaderOptionArray2 = arrayList.toArray(new ShaderOption[arrayList.size()]);
        return shaderOptionArray2;
    }

    public static void saveShaderPackOptions() {
        Shaders.saveShaderPackOptions(shaderPackOptions, shaderPack);
    }

    private static void saveShaderPackOptions(ShaderOption[] shaderOptionArray, IShaderPack iShaderPack) {
        Properties properties = new Properties();
        if (shaderPackOptions != null) {
            for (int i = 0; i < shaderOptionArray.length; ++i) {
                ShaderOption shaderOption = shaderOptionArray[i];
                if (!shaderOption.isChanged() || !shaderOption.isEnabled()) continue;
                properties.setProperty(shaderOption.getName(), shaderOption.getValue());
            }
        }
        try {
            Shaders.saveOptionProperties(iShaderPack, properties);
        }
        catch (IOException iOException) {
            Config.warn("[Shaders] Error saving configuration for " + shaderPack.getName());
            iOException.printStackTrace();
        }
    }

    private static void saveOptionProperties(IShaderPack iShaderPack, Properties properties) throws IOException {
        String string = shaderpacksdirname + "/" + iShaderPack.getName() + ".txt";
        File file = new File(Minecraft.getMinecraft().mcDataDir, string);
        if (properties.isEmpty()) {
            file.delete();
        } else {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            properties.store(fileOutputStream, (String)null);
            fileOutputStream.flush();
            fileOutputStream.close();
        }
    }

    private static ShaderOption[] loadShaderPackOptions() {
        try {
            ShaderOption[] shaderOptionArray = ShaderPackParser.parseShaderPackOptions(shaderPack, programNames, shaderPackDimensions);
            Properties properties = Shaders.loadOptionProperties(shaderPack);
            for (int i = 0; i < shaderOptionArray.length; ++i) {
                ShaderOption shaderOption = shaderOptionArray[i];
                String string = properties.getProperty(shaderOption.getName());
                if (string == null) continue;
                shaderOption.resetValue();
                if (shaderOption.setValue(string)) continue;
                Config.warn("[Shaders] Invalid value, option: " + shaderOption.getName() + ", value: " + string);
            }
            return shaderOptionArray;
        }
        catch (IOException iOException) {
            Config.warn("[Shaders] Error reading configuration for " + shaderPack.getName());
            iOException.printStackTrace();
            return null;
        }
    }

    private static Properties loadOptionProperties(IShaderPack iShaderPack) throws IOException {
        Properties properties = new Properties();
        String string = shaderpacksdirname + "/" + iShaderPack.getName() + ".txt";
        File file = new File(Minecraft.getMinecraft().mcDataDir, string);
        if (file.exists() && file.isFile() && file.canRead()) {
            FileInputStream fileInputStream = new FileInputStream(file);
            properties.load(fileInputStream);
            fileInputStream.close();
            return properties;
        }
        return properties;
    }

    public static ShaderOption[] getChangedOptions(ShaderOption[] shaderOptionArray) {
        ArrayList<ShaderOption> arrayList = new ArrayList<ShaderOption>();
        for (int i = 0; i < shaderOptionArray.length; ++i) {
            ShaderOption shaderOption = shaderOptionArray[i];
            if (!shaderOption.isEnabled() || !shaderOption.isChanged()) continue;
            arrayList.add(shaderOption);
        }
        ShaderOption[] shaderOptionArray2 = arrayList.toArray(new ShaderOption[arrayList.size()]);
        return shaderOptionArray2;
    }

    private static String applyOptions(String string, ShaderOption[] shaderOptionArray) {
        if (shaderOptionArray != null && shaderOptionArray.length > 0) {
            for (int i = 0; i < shaderOptionArray.length; ++i) {
                ShaderOption shaderOption = shaderOptionArray[i];
                String string2 = shaderOption.getName();
                if (!shaderOption.matchesLine(string)) continue;
                string = shaderOption.getSourceLine();
                break;
            }
            return string;
        }
        return string;
    }

    static ArrayList listOfShaders() {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(packNameNone);
        arrayList.add(packNameDefault);
        try {
            if (!shaderpacksdir.exists()) {
                shaderpacksdir.mkdir();
            }
            File[] fileArray = shaderpacksdir.listFiles();
            for (int i = 0; i < fileArray.length; ++i) {
                File file = fileArray[i];
                String string = file.getName();
                if (file.isDirectory()) {
                    File file2 = new File(file, "shaders");
                    if (!file2.exists() || !file2.isDirectory()) continue;
                    arrayList.add(string);
                    continue;
                }
                if (!file.isFile() || !string.toLowerCase().endsWith(".zip")) continue;
                arrayList.add(string);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrayList;
    }

    static String versiontostring(int n) {
        String string = Integer.toString(n);
        return Integer.toString(Integer.parseInt(string.substring(1, 3))) + "." + Integer.toString(Integer.parseInt(string.substring(3, 5))) + "." + Integer.toString(Integer.parseInt(string.substring(5)));
    }

    static void checkOptifine() {
    }

    public static int checkFramebufferStatus(String string) {
        int n = EXTFramebufferObject.glCheckFramebufferStatusEXT((int)36160);
        if (n != 36053) {
            System.err.format("FramebufferStatus 0x%04X at %s\n", n, string);
        }
        return n;
    }

    public static int checkGLError(String string) {
        boolean bl;
        int n = GL11.glGetError();
        if (n != 0 && !(bl = false)) {
            if (n == 1286) {
                int n2 = EXTFramebufferObject.glCheckFramebufferStatusEXT((int)36160);
                System.err.format("GL error 0x%04X: %s (Fb status 0x%04X) at %s\n", n, GLU.gluErrorString((int)n), n2, string);
            } else {
                System.err.format("GL error 0x%04X: %s at %s\n", n, GLU.gluErrorString((int)n), string);
            }
        }
        return n;
    }

    public static int checkGLError(String string, String string2) {
        int n = GL11.glGetError();
        if (n != 0) {
            System.err.format("GL error 0x%04x: %s at %s %s\n", n, GLU.gluErrorString((int)n), string, string2);
        }
        return n;
    }

    public static int checkGLError(String string, String string2, String string3) {
        int n = GL11.glGetError();
        if (n != 0) {
            System.err.format("GL error 0x%04x: %s at %s %s %s\n", n, GLU.gluErrorString((int)n), string, string2, string3);
        }
        return n;
    }

    private static void printChat(String string) {
        Shaders.mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(string));
    }

    private static void printChatAndLogError(String string) {
        SMCLog.severe(string);
        Shaders.mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(string));
    }

    public static void printIntBuffer(String string, IntBuffer intBuffer) {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append(string).append(" [pos ").append(intBuffer.position()).append(" lim ").append(intBuffer.limit()).append(" cap ").append(intBuffer.capacity()).append(" :");
        int n = intBuffer.limit();
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(" ").append(intBuffer.get(i));
        }
        stringBuilder.append("]");
        SMCLog.info(stringBuilder.toString());
    }

    public static void startup(Minecraft minecraft) {
        Shaders.checkShadersModInstalled();
        mc = minecraft;
        minecraft = Minecraft.getMinecraft();
        capabilities = GLContext.getCapabilities();
        glVersionString = GL11.glGetString((int)7938);
        glVendorString = GL11.glGetString((int)7936);
        glRendererString = GL11.glGetString((int)7937);
        SMCLog.info("ShadersMod version: 2.4.12");
        SMCLog.info("OpenGL Version: " + glVersionString);
        SMCLog.info("Vendor:  " + glVendorString);
        SMCLog.info("Renderer: " + glRendererString);
        SMCLog.info("Capabilities: " + (Shaders.capabilities.OpenGL20 ? " 2.0 " : " - ") + (Shaders.capabilities.OpenGL21 ? " 2.1 " : " - ") + (Shaders.capabilities.OpenGL30 ? " 3.0 " : " - ") + (Shaders.capabilities.OpenGL32 ? " 3.2 " : " - ") + (Shaders.capabilities.OpenGL40 ? " 4.0 " : " - "));
        SMCLog.info("GL_MAX_DRAW_BUFFERS: " + GL11.glGetInteger((int)34852));
        SMCLog.info("GL_MAX_COLOR_ATTACHMENTS_EXT: " + GL11.glGetInteger((int)36063));
        SMCLog.info("GL_MAX_TEXTURE_IMAGE_UNITS: " + GL11.glGetInteger((int)34930));
        hasGlGenMipmap = Shaders.capabilities.OpenGL30;
        Shaders.loadConfig();
    }

    private static String toStringYN(boolean bl) {
        return bl ? "Y" : "N";
    }

    public static void updateBlockLightLevel() {
        if (Shaders.isOldLighting()) {
            blockLightLevel05 = 0.5f;
            blockLightLevel06 = 0.6f;
            blockLightLevel08 = 0.8f;
        } else {
            blockLightLevel05 = 1.0f;
            blockLightLevel06 = 1.0f;
            blockLightLevel08 = 1.0f;
        }
    }

    public static boolean isOldHandLight() {
        if (!configOldHandLight.isDefault()) {
            return configOldHandLight.isTrue();
        }
        return !shaderPackOldHandLight.isDefault() ? shaderPackOldHandLight.isTrue() : true;
    }

    public static boolean isDynamicHandLight() {
        return !shaderPackDynamicHandLight.isDefault() ? shaderPackDynamicHandLight.isTrue() : true;
    }

    public static boolean isOldLighting() {
        if (!configOldLighting.isDefault()) {
            return configOldLighting.isTrue();
        }
        return !shaderPackOldLighting.isDefault() ? shaderPackOldLighting.isTrue() : true;
    }

    public static boolean isRenderShadowTranslucent() {
        return !shaderPackShadowTranslucent.isFalse();
    }

    public static boolean isUnderwaterOverlay() {
        return !shaderPackUnderwaterOverlay.isFalse();
    }

    public static boolean isSun() {
        return !shaderPackSun.isFalse();
    }

    public static boolean isMoon() {
        return !shaderPackMoon.isFalse();
    }

    public static boolean isVignette() {
        return !shaderPackVignette.isFalse();
    }

    public static boolean isRenderBackFace(BlockRenderLayer blockRenderLayer) {
        switch (blockRenderLayer) {
            case SOLID: {
                return shaderPackBackFaceSolid.isTrue();
            }
            case CUTOUT: {
                return shaderPackBackFaceCutout.isTrue();
            }
            case CUTOUT_MIPPED: {
                return shaderPackBackFaceCutoutMipped.isTrue();
            }
            case TRANSLUCENT: {
                return shaderPackBackFaceTranslucent.isTrue();
            }
        }
        return false;
    }

    public static void init() {
        boolean bl;
        if (!isInitializedOnce) {
            isInitializedOnce = true;
            bl = true;
        } else {
            bl = false;
        }
        if (!isShaderPackInitialized) {
            int n;
            Object object;
            int n2;
            Object object2;
            int n3;
            Shaders.checkGLError("Shaders.init pre");
            if (Shaders.getShaderPackName() != null) {
                // empty if block
            }
            if (!Shaders.capabilities.OpenGL20) {
                Shaders.printChatAndLogError("No OpenGL 2.0");
            }
            if (!Shaders.capabilities.GL_EXT_framebuffer_object) {
                Shaders.printChatAndLogError("No EXT_framebuffer_object");
            }
            dfbDrawBuffers.position(0).limit(8);
            dfbColorTextures.position(0).limit(16);
            dfbDepthTextures.position(0).limit(3);
            sfbDrawBuffers.position(0).limit(8);
            sfbDepthTextures.position(0).limit(2);
            sfbColorTextures.position(0).limit(8);
            usedColorBuffers = 4;
            usedDepthBuffers = 1;
            usedShadowColorBuffers = 0;
            usedShadowDepthBuffers = 0;
            usedColorAttachs = 1;
            usedDrawBuffers = 1;
            Arrays.fill(gbuffersFormat, 6408);
            Arrays.fill(gbuffersClear, true);
            Arrays.fill(shadowHardwareFilteringEnabled, false);
            Arrays.fill(shadowMipmapEnabled, false);
            Arrays.fill(shadowFilterNearest, false);
            Arrays.fill(shadowColorMipmapEnabled, false);
            Arrays.fill(shadowColorFilterNearest, false);
            centerDepthSmoothEnabled = false;
            noiseTextureEnabled = false;
            sunPathRotation = 0.0f;
            shadowIntervalSize = 2.0f;
            shadowDistanceRenderMul = -1.0f;
            aoLevel = -1.0f;
            useEntityAttrib = false;
            useMidTexCoordAttrib = false;
            useMultiTexCoord3Attrib = false;
            useTangentAttrib = false;
            waterShadowEnabled = false;
            updateChunksErrorRecorded = false;
            Shaders.updateBlockLightLevel();
            ShaderProfile shaderProfile = ShaderUtils.detectProfile(shaderPackProfiles, shaderPackOptions, false);
            Object object3 = "";
            if (currentWorld != null && shaderPackDimensions.contains(n3 = Shaders.currentWorld.provider.getDimensionType().getId())) {
                object3 = "world" + n3 + "/";
            }
            if (saveFinalShaders) {
                Shaders.clearDirectory(new File(shaderpacksdir, "debug"));
            }
            for (n3 = 0; n3 < 33; ++n3) {
                String string = programNames[n3];
                if (string.equals("")) {
                    Shaders.programsRef[n3] = 0;
                    Shaders.programsID[n3] = 0;
                    Shaders.programsDrawBufSettings[n3] = null;
                    Shaders.programsColorAtmSettings[n3] = null;
                    Shaders.programsCompositeMipmapSetting[n3] = 0;
                    continue;
                }
                newDrawBufSetting = null;
                newColorAtmSetting = null;
                newCompositeMipmapSetting = 0;
                object2 = (String)object3 + string;
                if (shaderProfile != null && shaderProfile.isProgramDisabled((String)object2)) {
                    SMCLog.info("Program disabled: " + (String)object2);
                    string = "<disabled>";
                    object2 = (String)object3 + string;
                }
                if ((n2 = Shaders.setupProgram(n3, (String)(object = "/shaders/" + (String)object2) + ".vsh", (String)object + ".fsh")) > 0) {
                    SMCLog.info("Program loaded: " + (String)object2);
                }
                Shaders.programsID[n3] = Shaders.programsRef[n3] = n2;
                Shaders.programsDrawBufSettings[n3] = n2 != 0 ? newDrawBufSetting : null;
                Shaders.programsColorAtmSettings[n3] = n2 != 0 ? newColorAtmSetting : null;
                Shaders.programsCompositeMipmapSetting[n3] = n2 != 0 ? newCompositeMipmapSetting : 0;
            }
            n3 = GL11.glGetInteger((int)34852);
            new HashMap();
            for (n = 0; n < 33; ++n) {
                Arrays.fill(programsToggleColorTextures[n], false);
                if (n == 29) {
                    Shaders.programsDrawBuffers[n] = null;
                    continue;
                }
                if (programsID[n] == 0) {
                    if (n == 30) {
                        Shaders.programsDrawBuffers[n] = drawBuffersNone;
                        continue;
                    }
                    Shaders.programsDrawBuffers[n] = drawBuffersColorAtt0;
                    continue;
                }
                object2 = programsDrawBufSettings[n];
                if (object2 != null) {
                    object = drawBuffersBuffer[n];
                    n2 = ((String)object2).length();
                    if (n2 > usedDrawBuffers) {
                        usedDrawBuffers = n2;
                    }
                    if (n2 > n3) {
                        n2 = n3;
                    }
                    Shaders.programsDrawBuffers[n] = object;
                    ((IntBuffer)object).limit(n2);
                    for (int i = 0; i < n2; ++i) {
                        int n4 = 0;
                        if (((String)object2).length() > i) {
                            int n5 = ((String)object2).charAt(i) - 48;
                            if (n != 30) {
                                if (n5 >= 0 && n5 <= 7) {
                                    Shaders.programsToggleColorTextures[n][n5] = true;
                                    n4 = n5 + 36064;
                                    if (n5 > usedColorAttachs) {
                                        usedColorAttachs = n5;
                                    }
                                    if (n5 > usedColorBuffers) {
                                        usedColorBuffers = n5;
                                    }
                                }
                            } else if (n5 >= 0 && n5 <= 1) {
                                n4 = n5 + 36064;
                                if (n5 > usedShadowColorBuffers) {
                                    usedShadowColorBuffers = n5;
                                }
                            }
                        }
                        ((IntBuffer)object).put(i, n4);
                    }
                    continue;
                }
                if (n != 30 && n != 31 && n != 32) {
                    Shaders.programsDrawBuffers[n] = dfbDrawBuffers;
                    usedDrawBuffers = usedColorBuffers;
                    Arrays.fill(programsToggleColorTextures[n], 0, usedColorBuffers, true);
                    continue;
                }
                Shaders.programsDrawBuffers[n] = sfbDrawBuffers;
            }
            usedColorAttachs = usedColorBuffers;
            shadowPassInterval = usedShadowDepthBuffers > 0 ? 1 : 0;
            shouldSkipDefaultShadow = usedShadowDepthBuffers > 0;
            SMCLog.info("usedColorBuffers: " + usedColorBuffers);
            SMCLog.info("usedDepthBuffers: " + usedDepthBuffers);
            SMCLog.info("usedShadowColorBuffers: " + usedShadowColorBuffers);
            SMCLog.info("usedShadowDepthBuffers: " + usedShadowDepthBuffers);
            SMCLog.info("usedColorAttachs: " + usedColorAttachs);
            SMCLog.info("usedDrawBuffers: " + usedDrawBuffers);
            dfbDrawBuffers.position(0).limit(usedDrawBuffers);
            dfbColorTextures.position(0).limit(usedColorBuffers * 2);
            for (n = 0; n < usedDrawBuffers; ++n) {
                dfbDrawBuffers.put(n, 36064 + n);
            }
            if (usedDrawBuffers > n3) {
                Shaders.printChatAndLogError("[Shaders] Error: Not enough draw buffers, needed: " + usedDrawBuffers + ", available: " + n3);
            }
            sfbDrawBuffers.position(0).limit(usedShadowColorBuffers);
            for (n = 0; n < usedShadowColorBuffers; ++n) {
                sfbDrawBuffers.put(n, 36064 + n);
            }
            for (n = 0; n < 33; ++n) {
                int n6 = n;
                while (programsID[n6] == 0 && programBackups[n6] != n6) {
                    n6 = programBackups[n6];
                }
                if (n6 == n || n == 30) continue;
                Shaders.programsID[n] = programsID[n6];
                Shaders.programsDrawBufSettings[n] = programsDrawBufSettings[n6];
                Shaders.programsDrawBuffers[n] = programsDrawBuffers[n6];
            }
            Shaders.resize();
            Shaders.resizeShadow();
            if (noiseTextureEnabled) {
                Shaders.setupNoiseTexture();
            }
            if (defaultTexture == null) {
                defaultTexture = ShadersTex.createDefaultTexture();
            }
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-90.0f, 0.0f, 1.0f, 0.0f);
            Shaders.preCelestialRotate();
            Shaders.postCelestialRotate();
            GlStateManager.popMatrix();
            isShaderPackInitialized = true;
            Shaders.loadEntityDataMap();
            Shaders.resetDisplayList();
            if (!bl) {
                // empty if block
            }
            Shaders.checkGLError("Shaders.init");
        }
    }

    public static void resetDisplayList() {
        ++numberResetDisplayList;
        needResetModels = true;
        SMCLog.info("Reset world renderers");
        Shaders.mc.renderGlobal.loadRenderers();
    }

    public static void resetDisplayListModels() {
        if (needResetModels) {
            needResetModels = false;
            SMCLog.info("Reset model renderers");
            for (Render render : mc.getRenderManager().getEntityRenderMap().values()) {
                if (!(render instanceof RenderLiving)) continue;
                RenderLiving renderLiving = (RenderLiving)render;
                Shaders.resetDisplayListModel(renderLiving.getMainModel());
            }
        }
    }

    public static void resetDisplayListModel(ModelBase modelBase) {
        if (modelBase != null) {
            for (ModelRenderer modelRenderer : modelBase.boxList) {
                if (!(modelRenderer instanceof ModelRenderer)) continue;
                Shaders.resetDisplayListModelRenderer(modelRenderer);
            }
        }
    }

    public static void resetDisplayListModelRenderer(ModelRenderer modelRenderer) {
        modelRenderer.resetDisplayList();
        if (modelRenderer.childModels != null) {
            int n = modelRenderer.childModels.size();
            for (int i = 0; i < n; ++i) {
                Shaders.resetDisplayListModelRenderer(modelRenderer.childModels.get(i));
            }
        }
    }

    private static int setupProgram(int n, String string, String string2) {
        Shaders.checkGLError("pre setupProgram");
        int n2 = ARBShaderObjects.glCreateProgramObjectARB();
        Shaders.checkGLError("create");
        if (n2 != 0) {
            progUseEntityAttrib = false;
            progUseMidTexCoordAttrib = false;
            progUseTangentAttrib = false;
            int n3 = Shaders.createVertShader(string);
            int n4 = Shaders.createFragShader(string2);
            Shaders.checkGLError("create");
            if (n3 == 0 && n4 == 0) {
                ARBShaderObjects.glDeleteObjectARB((int)n2);
                n2 = 0;
            } else {
                if (n3 != 0) {
                    ARBShaderObjects.glAttachObjectARB((int)n2, (int)n3);
                    Shaders.checkGLError("attach");
                }
                if (n4 != 0) {
                    ARBShaderObjects.glAttachObjectARB((int)n2, (int)n4);
                    Shaders.checkGLError("attach");
                }
                if (progUseEntityAttrib) {
                    ARBVertexShader.glBindAttribLocationARB((int)n2, (int)entityAttrib, (CharSequence)"mc_Entity");
                    Shaders.checkGLError("mc_Entity");
                }
                if (progUseMidTexCoordAttrib) {
                    ARBVertexShader.glBindAttribLocationARB((int)n2, (int)midTexCoordAttrib, (CharSequence)"mc_midTexCoord");
                    Shaders.checkGLError("mc_midTexCoord");
                }
                if (progUseTangentAttrib) {
                    ARBVertexShader.glBindAttribLocationARB((int)n2, (int)tangentAttrib, (CharSequence)"at_tangent");
                    Shaders.checkGLError("at_tangent");
                }
                ARBShaderObjects.glLinkProgramARB((int)n2);
                if (GL20.glGetProgrami((int)n2, (int)35714) != 1) {
                    SMCLog.severe("Error linking program: " + n2);
                }
                Shaders.printLogInfo(n2, string + ", " + string2);
                if (n3 != 0) {
                    ARBShaderObjects.glDetachObjectARB((int)n2, (int)n3);
                    ARBShaderObjects.glDeleteObjectARB((int)n3);
                }
                if (n4 != 0) {
                    ARBShaderObjects.glDetachObjectARB((int)n2, (int)n4);
                    ARBShaderObjects.glDeleteObjectARB((int)n4);
                }
                Shaders.programsID[n] = n2;
                Shaders.useProgram(n);
                ARBShaderObjects.glValidateProgramARB((int)n2);
                Shaders.useProgram(0);
                Shaders.printLogInfo(n2, string + ", " + string2);
                int n5 = GL20.glGetProgrami((int)n2, (int)35715);
                if (n5 != 1) {
                    String string3 = "\"";
                    Shaders.printChatAndLogError("[Shaders] Error: Invalid program " + string3 + programNames[n] + string3);
                    ARBShaderObjects.glDeleteObjectARB((int)n2);
                    n2 = 0;
                }
            }
        }
        return n2;
    }

    private static int createVertShader(String string) {
        int n = ARBShaderObjects.glCreateShaderObjectARB((int)35633);
        if (n == 0) {
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder(131072);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(shaderPack.getResourceAsStream(string)));
        }
        catch (Exception exception) {
            ARBShaderObjects.glDeleteObjectARB((int)n);
            return 0;
        }
        ShaderOption[] shaderOptionArray = Shaders.getChangedOptions(shaderPackOptions);
        ArrayList<String> arrayList = new ArrayList<String>();
        if (bufferedReader != null) {
            try {
                bufferedReader = ShaderPackParser.resolveIncludes(bufferedReader, string, shaderPack, 0, arrayList, 0);
                while (true) {
                    String string2;
                    if ((string2 = bufferedReader.readLine()) == null) {
                        bufferedReader.close();
                        break;
                    }
                    string2 = Shaders.applyOptions(string2, shaderOptionArray);
                    stringBuilder.append(string2).append('\n');
                    if (string2.matches("attribute [_a-zA-Z0-9]+ mc_Entity.*")) {
                        useEntityAttrib = true;
                        progUseEntityAttrib = true;
                        continue;
                    }
                    if (string2.matches("attribute [_a-zA-Z0-9]+ mc_midTexCoord.*")) {
                        useMidTexCoordAttrib = true;
                        progUseMidTexCoordAttrib = true;
                        continue;
                    }
                    if (string2.matches(".*gl_MultiTexCoord3.*")) {
                        useMultiTexCoord3Attrib = true;
                        continue;
                    }
                    if (!string2.matches("attribute [_a-zA-Z0-9]+ at_tangent.*")) continue;
                    useTangentAttrib = true;
                    progUseTangentAttrib = true;
                }
            }
            catch (Exception exception) {
                SMCLog.severe("Couldn't read " + string + "!");
                exception.printStackTrace();
                ARBShaderObjects.glDeleteObjectARB((int)n);
                return 0;
            }
        }
        if (saveFinalShaders) {
            Shaders.saveShader(string, stringBuilder.toString());
        }
        ARBShaderObjects.glShaderSourceARB((int)n, (CharSequence)stringBuilder);
        ARBShaderObjects.glCompileShaderARB((int)n);
        if (GL20.glGetShaderi((int)n, (int)35713) != 1) {
            SMCLog.severe("Error compiling vertex shader: " + string);
        }
        Shaders.printShaderLogInfo(n, string, arrayList);
        return n;
    }

    private static int createFragShader(String string) {
        int n = ARBShaderObjects.glCreateShaderObjectARB((int)35632);
        if (n == 0) {
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder(131072);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(shaderPack.getResourceAsStream(string)));
        }
        catch (Exception exception) {
            ARBShaderObjects.glDeleteObjectARB((int)n);
            return 0;
        }
        ShaderOption[] shaderOptionArray = Shaders.getChangedOptions(shaderPackOptions);
        ArrayList<String> arrayList = new ArrayList<String>();
        if (bufferedReader != null) {
            try {
                bufferedReader = ShaderPackParser.resolveIncludes(bufferedReader, string, shaderPack, 0, arrayList, 0);
                while (true) {
                    String string2;
                    String string3;
                    if ((string3 = bufferedReader.readLine()) == null) {
                        bufferedReader.close();
                        break;
                    }
                    string3 = Shaders.applyOptions(string3, shaderOptionArray);
                    stringBuilder.append(string3).append('\n');
                    ShaderLine shaderLine = ShaderParser.parseLine(string3);
                    if (shaderLine == null) continue;
                    if (shaderLine.isUniform()) {
                        string2 = shaderLine.getName();
                        int n2 = ShaderParser.getShadowDepthIndex(string2);
                        if (n2 >= 0) {
                            usedShadowDepthBuffers = Math.max(usedShadowDepthBuffers, n2 + 1);
                            continue;
                        }
                        n2 = ShaderParser.getShadowColorIndex(string2);
                        if (n2 >= 0) {
                            usedShadowColorBuffers = Math.max(usedShadowColorBuffers, n2 + 1);
                            continue;
                        }
                        n2 = ShaderParser.getDepthIndex(string2);
                        if (n2 >= 0) {
                            usedDepthBuffers = Math.max(usedDepthBuffers, n2 + 1);
                            continue;
                        }
                        if (string2.equals("gdepth") && gbuffersFormat[1] == 6408) {
                            Shaders.gbuffersFormat[1] = 34836;
                            continue;
                        }
                        n2 = ShaderParser.getColorIndex(string2);
                        if (n2 >= 0) {
                            usedColorBuffers = Math.max(usedColorBuffers, n2 + 1);
                            continue;
                        }
                        if (!string2.equals("centerDepthSmooth")) continue;
                        centerDepthSmoothEnabled = true;
                        continue;
                    }
                    if (!shaderLine.isConstInt("shadowMapResolution") && !shaderLine.isComment("SHADOWRES")) {
                        if (!shaderLine.isConstFloat("shadowMapFov") && !shaderLine.isComment("SHADOWFOV")) {
                            if (!shaderLine.isConstFloat("shadowDistance") && !shaderLine.isComment("SHADOWHPL")) {
                                if (shaderLine.isConstFloat("shadowDistanceRenderMul")) {
                                    shadowDistanceRenderMul = shaderLine.getValueFloat();
                                    SMCLog.info("Shadow distance render mul: " + shadowDistanceRenderMul);
                                    continue;
                                }
                                if (shaderLine.isConstFloat("shadowIntervalSize")) {
                                    shadowIntervalSize = shaderLine.getValueFloat();
                                    SMCLog.info("Shadow map interval size: " + shadowIntervalSize);
                                    continue;
                                }
                                if (shaderLine.isConstBool("generateShadowMipmap", true)) {
                                    Arrays.fill(shadowMipmapEnabled, true);
                                    SMCLog.info("Generate shadow mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("generateShadowColorMipmap", true)) {
                                    Arrays.fill(shadowColorMipmapEnabled, true);
                                    SMCLog.info("Generate shadow color mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowHardwareFiltering", true)) {
                                    Arrays.fill(shadowHardwareFilteringEnabled, true);
                                    SMCLog.info("Hardware shadow filtering enabled.");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowHardwareFiltering0", true)) {
                                    Shaders.shadowHardwareFilteringEnabled[0] = true;
                                    SMCLog.info("shadowHardwareFiltering0");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowHardwareFiltering1", true)) {
                                    Shaders.shadowHardwareFilteringEnabled[1] = true;
                                    SMCLog.info("shadowHardwareFiltering1");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowtex0Mipmap", "shadowtexMipmap", true)) {
                                    Shaders.shadowMipmapEnabled[0] = true;
                                    SMCLog.info("shadowtex0Mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowtex1Mipmap", true)) {
                                    Shaders.shadowMipmapEnabled[1] = true;
                                    SMCLog.info("shadowtex1Mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowcolor0Mipmap", "shadowColor0Mipmap", true)) {
                                    Shaders.shadowColorMipmapEnabled[0] = true;
                                    SMCLog.info("shadowcolor0Mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowcolor1Mipmap", "shadowColor1Mipmap", true)) {
                                    Shaders.shadowColorMipmapEnabled[1] = true;
                                    SMCLog.info("shadowcolor1Mipmap");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowtex0Nearest", "shadowtexNearest", "shadow0MinMagNearest", true)) {
                                    Shaders.shadowFilterNearest[0] = true;
                                    SMCLog.info("shadowtex0Nearest");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowtex1Nearest", "shadow1MinMagNearest", true)) {
                                    Shaders.shadowFilterNearest[1] = true;
                                    SMCLog.info("shadowtex1Nearest");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowcolor0Nearest", "shadowColor0Nearest", "shadowColor0MinMagNearest", true)) {
                                    Shaders.shadowColorFilterNearest[0] = true;
                                    SMCLog.info("shadowcolor0Nearest");
                                    continue;
                                }
                                if (shaderLine.isConstBool("shadowcolor1Nearest", "shadowColor1Nearest", "shadowColor1MinMagNearest", true)) {
                                    Shaders.shadowColorFilterNearest[1] = true;
                                    SMCLog.info("shadowcolor1Nearest");
                                    continue;
                                }
                                if (!shaderLine.isConstFloat("wetnessHalflife") && !shaderLine.isComment("WETNESSHL")) {
                                    if (!shaderLine.isConstFloat("drynessHalflife") && !shaderLine.isComment("DRYNESSHL")) {
                                        if (shaderLine.isConstFloat("eyeBrightnessHalflife")) {
                                            eyeBrightnessHalflife = shaderLine.getValueFloat();
                                            SMCLog.info("Eye brightness halflife: " + eyeBrightnessHalflife);
                                            continue;
                                        }
                                        if (shaderLine.isConstFloat("centerDepthHalflife")) {
                                            centerDepthSmoothHalflife = shaderLine.getValueFloat();
                                            SMCLog.info("Center depth halflife: " + centerDepthSmoothHalflife);
                                            continue;
                                        }
                                        if (shaderLine.isConstFloat("sunPathRotation")) {
                                            sunPathRotation = shaderLine.getValueFloat();
                                            SMCLog.info("Sun path rotation: " + sunPathRotation);
                                            continue;
                                        }
                                        if (shaderLine.isConstFloat("ambientOcclusionLevel")) {
                                            aoLevel = Config.limit(shaderLine.getValueFloat(), 0.0f, 1.0f);
                                            SMCLog.info("AO Level: " + aoLevel);
                                            continue;
                                        }
                                        if (shaderLine.isConstInt("superSamplingLevel")) {
                                            int n3 = shaderLine.getValueInt();
                                            if (n3 > 1) {
                                                SMCLog.info("Super sampling level: " + n3 + "x");
                                                superSamplingLevel = n3;
                                                continue;
                                            }
                                            superSamplingLevel = 1;
                                            continue;
                                        }
                                        if (shaderLine.isConstInt("noiseTextureResolution")) {
                                            noiseTextureResolution = shaderLine.getValueInt();
                                            noiseTextureEnabled = true;
                                            SMCLog.info("Noise texture enabled");
                                            SMCLog.info("Noise texture resolution: " + noiseTextureResolution);
                                            continue;
                                        }
                                        if (shaderLine.isConstIntSuffix("Format")) {
                                            string2 = StrUtils.removeSuffix(shaderLine.getName(), "Format");
                                            String string4 = shaderLine.getValue();
                                            int n4 = Shaders.getBufferIndexFromString(string2);
                                            int n5 = Shaders.getTextureFormatFromString(string4);
                                            if (n4 < 0 || n5 == 0) continue;
                                            Shaders.gbuffersFormat[n4] = n5;
                                            SMCLog.info("%s format: %s", string2, string4);
                                            continue;
                                        }
                                        if (shaderLine.isConstBoolSuffix("Clear", false)) {
                                            int n6;
                                            if (!ShaderParser.isComposite(string) || (n6 = Shaders.getBufferIndexFromString(string2 = StrUtils.removeSuffix(shaderLine.getName(), "Clear"))) < 0) continue;
                                            Shaders.gbuffersClear[n6] = false;
                                            SMCLog.info("%s clear disabled", string2);
                                            continue;
                                        }
                                        if (shaderLine.isComment("GAUX4FORMAT", "RGBA32F")) {
                                            Shaders.gbuffersFormat[7] = 34836;
                                            SMCLog.info("gaux4 format : RGB32AF");
                                            continue;
                                        }
                                        if (shaderLine.isComment("GAUX4FORMAT", "RGB32F")) {
                                            Shaders.gbuffersFormat[7] = 34837;
                                            SMCLog.info("gaux4 format : RGB32F");
                                            continue;
                                        }
                                        if (shaderLine.isComment("GAUX4FORMAT", "RGB16")) {
                                            Shaders.gbuffersFormat[7] = 32852;
                                            SMCLog.info("gaux4 format : RGB16");
                                            continue;
                                        }
                                        if (shaderLine.isConstBoolSuffix("MipmapEnabled", true)) {
                                            int n7;
                                            if (!ShaderParser.isComposite(string) && !ShaderParser.isFinal(string) || (n7 = Shaders.getBufferIndexFromString(string2 = StrUtils.removeSuffix(shaderLine.getName(), "MipmapEnabled"))) < 0) continue;
                                            newCompositeMipmapSetting |= 1 << n7;
                                            SMCLog.info("%s mipmap enabled", string2);
                                            continue;
                                        }
                                        if (!shaderLine.isComment("DRAWBUFFERS")) continue;
                                        string2 = shaderLine.getValue();
                                        if (ShaderParser.isValidDrawBuffers(string2)) {
                                            newDrawBufSetting = string2;
                                            continue;
                                        }
                                        SMCLog.warning("Invalid draw buffers: " + string2);
                                        continue;
                                    }
                                    drynessHalfLife = shaderLine.getValueFloat();
                                    SMCLog.info("Dryness halflife: " + drynessHalfLife);
                                    continue;
                                }
                                wetnessHalfLife = shaderLine.getValueFloat();
                                SMCLog.info("Wetness halflife: " + wetnessHalfLife);
                                continue;
                            }
                            shadowMapHalfPlane = shaderLine.getValueFloat();
                            shadowMapIsOrtho = true;
                            SMCLog.info("Shadow map distance: " + shadowMapHalfPlane);
                            continue;
                        }
                        shadowMapFOV = shaderLine.getValueFloat();
                        shadowMapIsOrtho = false;
                        SMCLog.info("Shadow map field of view: " + shadowMapFOV);
                        continue;
                    }
                    spShadowMapWidth = spShadowMapHeight = shaderLine.getValueInt();
                    shadowMapWidth = shadowMapHeight = Math.round((float)spShadowMapWidth * configShadowResMul);
                    SMCLog.info("Shadow map resolution: " + spShadowMapWidth);
                }
            }
            catch (Exception exception) {
                SMCLog.severe("Couldn't read " + string + "!");
                exception.printStackTrace();
                ARBShaderObjects.glDeleteObjectARB((int)n);
                return 0;
            }
        }
        if (saveFinalShaders) {
            Shaders.saveShader(string, stringBuilder.toString());
        }
        ARBShaderObjects.glShaderSourceARB((int)n, (CharSequence)stringBuilder);
        ARBShaderObjects.glCompileShaderARB((int)n);
        if (GL20.glGetShaderi((int)n, (int)35713) != 1) {
            SMCLog.severe("Error compiling fragment shader: " + string);
        }
        Shaders.printShaderLogInfo(n, string, arrayList);
        return n;
    }

    private static void saveShader(String string, String string2) {
        try {
            File file = new File(shaderpacksdir, "debug/" + string);
            file.getParentFile().mkdirs();
            Config.writeFile(file, string2);
        }
        catch (IOException iOException) {
            Config.warn("Error saving: " + string);
            iOException.printStackTrace();
        }
    }

    private static void clearDirectory(File file) {
        File[] fileArray;
        if (file.exists() && file.isDirectory() && (fileArray = file.listFiles()) != null) {
            for (int i = 0; i < fileArray.length; ++i) {
                File file2 = fileArray[i];
                if (file2.isDirectory()) {
                    Shaders.clearDirectory(file2);
                }
                file2.delete();
            }
        }
    }

    private static boolean printLogInfo(int n, String string) {
        IntBuffer intBuffer = BufferUtils.createIntBuffer((int)1);
        ARBShaderObjects.glGetObjectParameterARB((int)n, (int)35716, (IntBuffer)intBuffer);
        int n2 = intBuffer.get();
        if (n2 > 1) {
            ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)n2);
            intBuffer.flip();
            ARBShaderObjects.glGetInfoLogARB((int)n, (IntBuffer)intBuffer, (ByteBuffer)byteBuffer);
            byte[] byArray = new byte[n2];
            byteBuffer.get(byArray);
            if (byArray[n2 - 1] == 0) {
                byArray[n2 - 1] = 10;
            }
            String string2 = new String(byArray);
            SMCLog.info("Info log: " + string + "\n" + string2);
            return false;
        }
        return true;
    }

    private static boolean printShaderLogInfo(int n, String string, List<String> list) {
        IntBuffer intBuffer = BufferUtils.createIntBuffer((int)1);
        int n2 = GL20.glGetShaderi((int)n, (int)35716);
        if (n2 <= 1) {
            return true;
        }
        for (int i = 0; i < list.size(); ++i) {
            String string2 = list.get(i);
            SMCLog.info("File: " + (i + 1) + " = " + string2);
        }
        String string3 = GL20.glGetShaderInfoLog((int)n, (int)n2);
        SMCLog.info("Shader info log: " + string + "\n" + string3);
        return false;
    }

    public static void setDrawBuffers(IntBuffer intBuffer) {
        if (intBuffer == null) {
            intBuffer = drawBuffersNone;
        }
        if (activeDrawBuffers != intBuffer) {
            activeDrawBuffers = intBuffer;
            GL20.glDrawBuffers((IntBuffer)intBuffer);
        }
    }

    public static void useProgram(int n) {
        Shaders.checkGLError("pre-useProgram");
        if (isShadowPass) {
            n = 30;
            if (programsID[30] == 0) {
                normalMapEnabled = false;
                return;
            }
        }
        if (activeProgram != n) {
            activeProgram = n;
            ARBShaderObjects.glUseProgramObjectARB((int)programsID[n]);
            if (programsID[n] == 0) {
                normalMapEnabled = false;
            } else {
                int n2;
                if (Shaders.checkGLError("useProgram ", programNames[n]) != 0) {
                    Shaders.programsID[n] = 0;
                }
                IntBuffer intBuffer = programsDrawBuffers[n];
                if (isRenderingDfb) {
                    Shaders.setDrawBuffers(intBuffer);
                    Shaders.checkGLError(programNames[n], " draw buffers = ", programsDrawBufSettings[n]);
                }
                activeCompositeMipmapSetting = programsCompositeMipmapSetting[n];
                uniformEntityColor.setProgram(programsID[activeProgram]);
                uniformEntityId.setProgram(programsID[activeProgram]);
                uniformBlockEntityId.setProgram(programsID[activeProgram]);
                switch (n) {
                    case 1: 
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: 
                    case 6: 
                    case 7: 
                    case 8: 
                    case 9: 
                    case 10: 
                    case 11: 
                    case 12: 
                    case 13: 
                    case 16: 
                    case 18: 
                    case 19: 
                    case 20: {
                        normalMapEnabled = true;
                        Shaders.setProgramUniform1i("texture", 0);
                        Shaders.setProgramUniform1i("lightmap", 1);
                        Shaders.setProgramUniform1i("normals", 2);
                        Shaders.setProgramUniform1i("specular", 3);
                        Shaders.setProgramUniform1i("shadow", waterShadowEnabled ? 5 : 4);
                        Shaders.setProgramUniform1i("watershadow", 4);
                        Shaders.setProgramUniform1i("shadowtex0", 4);
                        Shaders.setProgramUniform1i("shadowtex1", 5);
                        Shaders.setProgramUniform1i("depthtex0", 6);
                        if (customTexturesGbuffers != null) {
                            Shaders.setProgramUniform1i("gaux1", 7);
                            Shaders.setProgramUniform1i("gaux2", 8);
                            Shaders.setProgramUniform1i("gaux3", 9);
                            Shaders.setProgramUniform1i("gaux4", 10);
                        }
                        Shaders.setProgramUniform1i("depthtex1", 12);
                        Shaders.setProgramUniform1i("shadowcolor", 13);
                        Shaders.setProgramUniform1i("shadowcolor0", 13);
                        Shaders.setProgramUniform1i("shadowcolor1", 14);
                        Shaders.setProgramUniform1i("noisetex", 15);
                        break;
                    }
                    default: {
                        normalMapEnabled = false;
                        break;
                    }
                    case 21: 
                    case 22: 
                    case 23: 
                    case 24: 
                    case 25: 
                    case 26: 
                    case 27: 
                    case 28: 
                    case 29: {
                        normalMapEnabled = false;
                        Shaders.setProgramUniform1i("gcolor", 0);
                        Shaders.setProgramUniform1i("gdepth", 1);
                        Shaders.setProgramUniform1i("gnormal", 2);
                        Shaders.setProgramUniform1i("composite", 3);
                        Shaders.setProgramUniform1i("gaux1", 7);
                        Shaders.setProgramUniform1i("gaux2", 8);
                        Shaders.setProgramUniform1i("gaux3", 9);
                        Shaders.setProgramUniform1i("gaux4", 10);
                        Shaders.setProgramUniform1i("colortex0", 0);
                        Shaders.setProgramUniform1i("colortex1", 1);
                        Shaders.setProgramUniform1i("colortex2", 2);
                        Shaders.setProgramUniform1i("colortex3", 3);
                        Shaders.setProgramUniform1i("colortex4", 7);
                        Shaders.setProgramUniform1i("colortex5", 8);
                        Shaders.setProgramUniform1i("colortex6", 9);
                        Shaders.setProgramUniform1i("colortex7", 10);
                        Shaders.setProgramUniform1i("shadow", waterShadowEnabled ? 5 : 4);
                        Shaders.setProgramUniform1i("watershadow", 4);
                        Shaders.setProgramUniform1i("shadowtex0", 4);
                        Shaders.setProgramUniform1i("shadowtex1", 5);
                        Shaders.setProgramUniform1i("gdepthtex", 6);
                        Shaders.setProgramUniform1i("depthtex0", 6);
                        Shaders.setProgramUniform1i("depthtex1", 11);
                        Shaders.setProgramUniform1i("depthtex2", 12);
                        Shaders.setProgramUniform1i("shadowcolor", 13);
                        Shaders.setProgramUniform1i("shadowcolor0", 13);
                        Shaders.setProgramUniform1i("shadowcolor1", 14);
                        Shaders.setProgramUniform1i("noisetex", 15);
                        break;
                    }
                    case 30: 
                    case 31: 
                    case 32: {
                        Shaders.setProgramUniform1i("tex", 0);
                        Shaders.setProgramUniform1i("texture", 0);
                        Shaders.setProgramUniform1i("lightmap", 1);
                        Shaders.setProgramUniform1i("normals", 2);
                        Shaders.setProgramUniform1i("specular", 3);
                        Shaders.setProgramUniform1i("shadow", waterShadowEnabled ? 5 : 4);
                        Shaders.setProgramUniform1i("watershadow", 4);
                        Shaders.setProgramUniform1i("shadowtex0", 4);
                        Shaders.setProgramUniform1i("shadowtex1", 5);
                        if (customTexturesGbuffers != null) {
                            Shaders.setProgramUniform1i("gaux1", 7);
                            Shaders.setProgramUniform1i("gaux2", 8);
                            Shaders.setProgramUniform1i("gaux3", 9);
                            Shaders.setProgramUniform1i("gaux4", 10);
                        }
                        Shaders.setProgramUniform1i("shadowcolor", 13);
                        Shaders.setProgramUniform1i("shadowcolor0", 13);
                        Shaders.setProgramUniform1i("shadowcolor1", 14);
                        Shaders.setProgramUniform1i("noisetex", 15);
                    }
                }
                ItemStack itemStack = Shaders.mc.player != null ? Shaders.mc.player.getHeldItemMainhand() : null;
                Item item = itemStack != null ? itemStack.getItem() : null;
                int n3 = -1;
                Block block = null;
                if (item != null) {
                    n3 = Item.REGISTRY.getIDForObject(item);
                    block = Block.REGISTRY.getObjectById(n3);
                }
                int n4 = block != null ? block.getLightValue(block.getDefaultState()) : 0;
                ItemStack itemStack2 = Shaders.mc.player != null ? Shaders.mc.player.getHeldItemOffhand() : null;
                Item item2 = itemStack2 != null ? itemStack2.getItem() : null;
                int n5 = -1;
                Block block2 = null;
                if (item2 != null) {
                    n5 = Item.REGISTRY.getIDForObject(item2);
                    block2 = Block.REGISTRY.getObjectById(n5);
                }
                int n6 = n2 = block2 != null ? block2.getLightValue(block2.getDefaultState()) : 0;
                if (Shaders.isOldHandLight() && n2 > n4) {
                    n3 = n5;
                    n4 = n2;
                }
                Shaders.setProgramUniform1i("heldItemId", n3);
                Shaders.setProgramUniform1i("heldBlockLightValue", n4);
                Shaders.setProgramUniform1i("heldItemId2", n5);
                Shaders.setProgramUniform1i("heldBlockLightValue2", n2);
                Shaders.setProgramUniform1i("fogMode", fogEnabled ? fogMode : 0);
                Shaders.setProgramUniform3f("fogColor", fogColorR, fogColorG, fogColorB);
                Shaders.setProgramUniform3f("skyColor", skyColorR, skyColorG, skyColorB);
                Shaders.setProgramUniform1i("worldTime", (int)(worldTime % 24000L));
                Shaders.setProgramUniform1i("worldDay", (int)(worldTime / 24000L));
                Shaders.setProgramUniform1i("moonPhase", moonPhase);
                Shaders.setProgramUniform1i("frameCounter", frameCounter);
                Shaders.setProgramUniform1f("frameTime", frameTime);
                Shaders.setProgramUniform1f("frameTimeCounter", frameTimeCounter);
                Shaders.setProgramUniform1f("sunAngle", sunAngle);
                Shaders.setProgramUniform1f("shadowAngle", shadowAngle);
                Shaders.setProgramUniform1f("rainStrength", rainStrength);
                Shaders.setProgramUniform1f("aspectRatio", (float)renderWidth / (float)renderHeight);
                Shaders.setProgramUniform1f("viewWidth", renderWidth);
                Shaders.setProgramUniform1f("viewHeight", renderHeight);
                Shaders.setProgramUniform1f("near", 0.05f);
                Shaders.setProgramUniform1f("far", Shaders.mc.gameSettings.renderDistanceChunks * 16);
                Shaders.setProgramUniform3f("sunPosition", sunPosition[0], sunPosition[1], sunPosition[2]);
                Shaders.setProgramUniform3f("moonPosition", moonPosition[0], moonPosition[1], moonPosition[2]);
                Shaders.setProgramUniform3f("shadowLightPosition", shadowLightPosition[0], shadowLightPosition[1], shadowLightPosition[2]);
                Shaders.setProgramUniform3f("upPosition", upPosition[0], upPosition[1], upPosition[2]);
                Shaders.setProgramUniform3f("previousCameraPosition", (float)previousCameraPositionX, (float)previousCameraPositionY, (float)previousCameraPositionZ);
                Shaders.setProgramUniform3f("cameraPosition", (float)cameraPositionX, (float)cameraPositionY, (float)cameraPositionZ);
                Shaders.setProgramUniformMatrix4ARB("gbufferModelView", false, modelView);
                Shaders.setProgramUniformMatrix4ARB("gbufferModelViewInverse", false, modelViewInverse);
                Shaders.setProgramUniformMatrix4ARB("gbufferPreviousProjection", false, previousProjection);
                Shaders.setProgramUniformMatrix4ARB("gbufferProjection", false, projection);
                Shaders.setProgramUniformMatrix4ARB("gbufferProjectionInverse", false, projectionInverse);
                Shaders.setProgramUniformMatrix4ARB("gbufferPreviousModelView", false, previousModelView);
                if (usedShadowDepthBuffers > 0) {
                    Shaders.setProgramUniformMatrix4ARB("shadowProjection", false, shadowProjection);
                    Shaders.setProgramUniformMatrix4ARB("shadowProjectionInverse", false, shadowProjectionInverse);
                    Shaders.setProgramUniformMatrix4ARB("shadowModelView", false, shadowModelView);
                    Shaders.setProgramUniformMatrix4ARB("shadowModelViewInverse", false, shadowModelViewInverse);
                }
                Shaders.setProgramUniform1f("wetness", wetness);
                Shaders.setProgramUniform1f("eyeAltitude", eyePosY);
                Shaders.setProgramUniform2i("eyeBrightness", eyeBrightness & 0xFFFF, eyeBrightness >> 16);
                Shaders.setProgramUniform2i("eyeBrightnessSmooth", Math.round(eyeBrightnessFadeX), Math.round(eyeBrightnessFadeY));
                Shaders.setProgramUniform2i("terrainTextureSize", terrainTextureSize[0], terrainTextureSize[1]);
                Shaders.setProgramUniform1i("terrainIconSize", terrainIconSize);
                Shaders.setProgramUniform1i("isEyeInWater", isEyeInWater);
                Shaders.setProgramUniform1f("nightVision", nightVision);
                Shaders.setProgramUniform1f("blindness", blindness);
                Shaders.setProgramUniform1f("screenBrightness", Shaders.mc.gameSettings.gammaSetting);
                Shaders.setProgramUniform1i("hideGUI", Shaders.mc.gameSettings.hideGUI ? 1 : 0);
                Shaders.setProgramUniform1f("centerDepthSmooth", centerDepthSmooth);
                Shaders.setProgramUniform2i("atlasSize", atlasSizeX, atlasSizeY);
                Shaders.checkGLError("useProgram ", programNames[n]);
            }
        }
    }

    public static void setProgramUniform1i(String string, int n) {
        int n2 = programsID[activeProgram];
        if (n2 != 0) {
            int n3 = ARBShaderObjects.glGetUniformLocationARB((int)n2, (CharSequence)string);
            ARBShaderObjects.glUniform1iARB((int)n3, (int)n);
            Shaders.checkGLError(programNames[activeProgram], string);
        }
    }

    public static void setProgramUniform2i(String string, int n, int n2) {
        int n3 = programsID[activeProgram];
        if (n3 != 0) {
            int n4 = ARBShaderObjects.glGetUniformLocationARB((int)n3, (CharSequence)string);
            ARBShaderObjects.glUniform2iARB((int)n4, (int)n, (int)n2);
            Shaders.checkGLError(programNames[activeProgram], string);
        }
    }

    public static void setProgramUniform1f(String string, float f) {
        int n = programsID[activeProgram];
        if (n != 0) {
            int n2 = ARBShaderObjects.glGetUniformLocationARB((int)n, (CharSequence)string);
            ARBShaderObjects.glUniform1fARB((int)n2, (float)f);
            Shaders.checkGLError(programNames[activeProgram], string);
        }
    }

    public static void setProgramUniform3f(String string, float f, float f2, float f3) {
        int n = programsID[activeProgram];
        if (n != 0) {
            int n2 = ARBShaderObjects.glGetUniformLocationARB((int)n, (CharSequence)string);
            ARBShaderObjects.glUniform3fARB((int)n2, (float)f, (float)f2, (float)f3);
            Shaders.checkGLError(programNames[activeProgram], string);
        }
    }

    public static void setProgramUniformMatrix4ARB(String string, boolean bl, FloatBuffer floatBuffer) {
        int n = programsID[activeProgram];
        if (n != 0 && floatBuffer != null) {
            int n2 = ARBShaderObjects.glGetUniformLocationARB((int)n, (CharSequence)string);
            ARBShaderObjects.glUniformMatrix4ARB((int)n2, (boolean)bl, (FloatBuffer)floatBuffer);
            Shaders.checkGLError(programNames[activeProgram], string);
        }
    }

    private static int getBufferIndexFromString(String string) {
        if (!string.equals("colortex0") && !string.equals("gcolor")) {
            if (!string.equals("colortex1") && !string.equals("gdepth")) {
                if (!string.equals("colortex2") && !string.equals("gnormal")) {
                    if (!string.equals("colortex3") && !string.equals("composite")) {
                        if (!string.equals("colortex4") && !string.equals("gaux1")) {
                            if (!string.equals("colortex5") && !string.equals("gaux2")) {
                                if (!string.equals("colortex6") && !string.equals("gaux3")) {
                                    return !string.equals("colortex7") && !string.equals("gaux4") ? -1 : 7;
                                }
                                return 6;
                            }
                            return 5;
                        }
                        return 4;
                    }
                    return 3;
                }
                return 2;
            }
            return 1;
        }
        return 0;
    }

    private static int getTextureFormatFromString(String string) {
        string = string.trim();
        for (int i = 0; i < formatNames.length; ++i) {
            String string2 = formatNames[i];
            if (!string.equals(string2)) continue;
            return formatIds[i];
        }
        return 0;
    }

    private static void setupNoiseTexture() {
        if (noiseTexture == null && noiseTexturePath != null) {
            noiseTexture = Shaders.loadCustomTexture(15, noiseTexturePath);
        }
        if (noiseTexture == null) {
            noiseTexture = new HFNoiseTexture(noiseTextureResolution, noiseTextureResolution);
        }
    }

    private static void loadEntityDataMap() {
        Object object;
        mapBlockToEntityData = new IdentityHashMap<Block, Integer>(300);
        if (mapBlockToEntityData.isEmpty()) {
            for (Object object2 : Block.REGISTRY.getKeys()) {
                object = Block.REGISTRY.getObject((ResourceLocation)object2);
                int n = Block.REGISTRY.getIDForObject((Block)object);
                mapBlockToEntityData.put((Block)object, n);
            }
        }
        Object object3 = null;
        try {
            object3 = new BufferedReader(new InputStreamReader(shaderPack.getResourceAsStream("/mc_Entity_x.txt")));
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (object3 != null) {
            try {
                Object object2;
                while ((object2 = ((BufferedReader)object3).readLine()) != null) {
                    object = patternLoadEntityDataMap.matcher((CharSequence)object2);
                    if (((Matcher)object).matches()) {
                        String string = ((Matcher)object).group(1);
                        String string2 = ((Matcher)object).group(2);
                        int n = Integer.parseInt(string2);
                        Block block = Block.getBlockFromName(string);
                        if (block != null) {
                            mapBlockToEntityData.put(block, n);
                            continue;
                        }
                        SMCLog.warning("Unknown block name %s", string);
                        continue;
                    }
                    SMCLog.warning("unmatched %s\n", object2);
                }
            }
            catch (Exception exception) {
                SMCLog.warning("Error parsing mc_Entity_x.txt");
            }
        }
        if (object3 != null) {
            try {
                ((BufferedReader)object3).close();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private static IntBuffer fillIntBufferZero(IntBuffer intBuffer) {
        int n = intBuffer.limit();
        for (int i = intBuffer.position(); i < n; ++i) {
            intBuffer.put(i, 0);
        }
        return intBuffer;
    }

    public static void uninit() {
        if (isShaderPackInitialized) {
            Shaders.checkGLError("Shaders.uninit pre");
            for (int i = 0; i < 33; ++i) {
                if (programsRef[i] != 0) {
                    ARBShaderObjects.glDeleteObjectARB((int)programsRef[i]);
                    Shaders.checkGLError("del programRef");
                }
                Shaders.programsRef[i] = 0;
                Shaders.programsID[i] = 0;
                Shaders.programsDrawBufSettings[i] = null;
                Shaders.programsDrawBuffers[i] = null;
                Shaders.programsCompositeMipmapSetting[i] = 0;
            }
            if (dfb != 0) {
                EXTFramebufferObject.glDeleteFramebuffersEXT((int)dfb);
                dfb = 0;
                Shaders.checkGLError("del dfb");
            }
            if (sfb != 0) {
                EXTFramebufferObject.glDeleteFramebuffersEXT((int)sfb);
                sfb = 0;
                Shaders.checkGLError("del sfb");
            }
            if (dfbDepthTextures != null) {
                GlStateManager.deleteTextures(dfbDepthTextures);
                Shaders.fillIntBufferZero(dfbDepthTextures);
                Shaders.checkGLError("del dfbDepthTextures");
            }
            if (dfbColorTextures != null) {
                GlStateManager.deleteTextures(dfbColorTextures);
                Shaders.fillIntBufferZero(dfbColorTextures);
                Shaders.checkGLError("del dfbTextures");
            }
            if (sfbDepthTextures != null) {
                GlStateManager.deleteTextures(sfbDepthTextures);
                Shaders.fillIntBufferZero(sfbDepthTextures);
                Shaders.checkGLError("del shadow depth");
            }
            if (sfbColorTextures != null) {
                GlStateManager.deleteTextures(sfbColorTextures);
                Shaders.fillIntBufferZero(sfbColorTextures);
                Shaders.checkGLError("del shadow color");
            }
            if (dfbDrawBuffers != null) {
                Shaders.fillIntBufferZero(dfbDrawBuffers);
            }
            if (noiseTexture != null) {
                noiseTexture.deleteTexture();
                noiseTexture = null;
            }
            SMCLog.info("Uninit");
            shadowPassInterval = 0;
            shouldSkipDefaultShadow = false;
            isShaderPackInitialized = false;
            Shaders.checkGLError("Shaders.uninit");
        }
    }

    public static void scheduleResize() {
        renderDisplayHeight = 0;
    }

    public static void scheduleResizeShadow() {
        needResizeShadow = true;
    }

    private static void resize() {
        renderDisplayWidth = Shaders.mc.displayWidth;
        renderDisplayHeight = Shaders.mc.displayHeight;
        renderWidth = Math.round((float)renderDisplayWidth * configRenderResMul);
        renderHeight = Math.round((float)renderDisplayHeight * configRenderResMul);
        Shaders.setupFrameBuffer();
    }

    private static void resizeShadow() {
        needResizeShadow = false;
        shadowMapWidth = Math.round((float)spShadowMapWidth * configShadowResMul);
        shadowMapHeight = Math.round((float)spShadowMapHeight * configShadowResMul);
        Shaders.setupShadowFrameBuffer();
    }

    private static void setupFrameBuffer() {
        int n;
        if (dfb != 0) {
            EXTFramebufferObject.glDeleteFramebuffersEXT((int)dfb);
            GlStateManager.deleteTextures(dfbDepthTextures);
            GlStateManager.deleteTextures(dfbColorTextures);
        }
        dfb = EXTFramebufferObject.glGenFramebuffersEXT();
        GL11.glGenTextures((IntBuffer)dfbDepthTextures.clear().limit(usedDepthBuffers));
        GL11.glGenTextures((IntBuffer)dfbColorTextures.clear().limit(16));
        dfbDepthTextures.position(0);
        dfbColorTextures.position(0);
        dfbColorTextures.get(dfbColorTexturesA).position(0);
        EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)dfb);
        GL20.glDrawBuffers((int)0);
        GL11.glReadBuffer((int)0);
        for (n = 0; n < usedDepthBuffers; ++n) {
            GlStateManager.bindTexture(dfbDepthTextures.get(n));
            GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
            GL11.glTexParameteri((int)3553, (int)34891, (int)6409);
            GL11.glTexImage2D((int)3553, (int)0, (int)6402, (int)renderWidth, (int)renderHeight, (int)0, (int)6402, (int)5126, (FloatBuffer)null);
        }
        EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36096, (int)3553, (int)dfbDepthTextures.get(0), (int)0);
        GL20.glDrawBuffers((IntBuffer)dfbDrawBuffers);
        GL11.glReadBuffer((int)0);
        Shaders.checkGLError("FT d");
        for (n = 0; n < usedColorBuffers; ++n) {
            GlStateManager.bindTexture(dfbColorTexturesA[n]);
            GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexImage2D((int)3553, (int)0, (int)gbuffersFormat[n], (int)renderWidth, (int)renderHeight, (int)0, (int)32993, (int)33639, (ByteBuffer)null);
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + n), (int)3553, (int)dfbColorTexturesA[n], (int)0);
            Shaders.checkGLError("FT c");
        }
        for (n = 0; n < usedColorBuffers; ++n) {
            GlStateManager.bindTexture(dfbColorTexturesA[8 + n]);
            GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexImage2D((int)3553, (int)0, (int)gbuffersFormat[n], (int)renderWidth, (int)renderHeight, (int)0, (int)32993, (int)33639, (ByteBuffer)null);
            Shaders.checkGLError("FT ca");
        }
        n = EXTFramebufferObject.glCheckFramebufferStatusEXT((int)36160);
        if (n == 36058) {
            Shaders.printChatAndLogError("[Shaders] Error: Failed framebuffer incomplete formats");
            for (int i = 0; i < usedColorBuffers; ++i) {
                GlStateManager.bindTexture(dfbColorTextures.get(i));
                GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)renderWidth, (int)renderHeight, (int)0, (int)32993, (int)33639, (ByteBuffer)null);
                EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + i), (int)3553, (int)dfbColorTextures.get(i), (int)0);
                Shaders.checkGLError("FT c");
            }
            n = EXTFramebufferObject.glCheckFramebufferStatusEXT((int)36160);
            if (n == 36053) {
                SMCLog.info("complete");
            }
        }
        GlStateManager.bindTexture(0);
        if (n != 36053) {
            Shaders.printChatAndLogError("[Shaders] Error: Failed creating framebuffer! (Status " + n + ")");
        } else {
            SMCLog.info("Framebuffer created.");
        }
    }

    private static void setupShadowFrameBuffer() {
        if (usedShadowDepthBuffers != 0) {
            int n;
            int n2;
            if (sfb != 0) {
                EXTFramebufferObject.glDeleteFramebuffersEXT((int)sfb);
                GlStateManager.deleteTextures(sfbDepthTextures);
                GlStateManager.deleteTextures(sfbColorTextures);
            }
            sfb = EXTFramebufferObject.glGenFramebuffersEXT();
            EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)sfb);
            GL11.glDrawBuffer((int)0);
            GL11.glReadBuffer((int)0);
            GL11.glGenTextures((IntBuffer)sfbDepthTextures.clear().limit(usedShadowDepthBuffers));
            GL11.glGenTextures((IntBuffer)sfbColorTextures.clear().limit(usedShadowColorBuffers));
            sfbDepthTextures.position(0);
            sfbColorTextures.position(0);
            for (n2 = 0; n2 < usedShadowDepthBuffers; ++n2) {
                GlStateManager.bindTexture(sfbDepthTextures.get(n2));
                GL11.glTexParameterf((int)3553, (int)10242, (float)10496.0f);
                GL11.glTexParameterf((int)3553, (int)10243, (float)10496.0f);
                n = shadowFilterNearest[n2] ? 9728 : 9729;
                GL11.glTexParameteri((int)3553, (int)10241, (int)n);
                GL11.glTexParameteri((int)3553, (int)10240, (int)n);
                if (shadowHardwareFilteringEnabled[n2]) {
                    GL11.glTexParameteri((int)3553, (int)34892, (int)34894);
                }
                GL11.glTexImage2D((int)3553, (int)0, (int)6402, (int)shadowMapWidth, (int)shadowMapHeight, (int)0, (int)6402, (int)5126, (FloatBuffer)null);
            }
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36096, (int)3553, (int)sfbDepthTextures.get(0), (int)0);
            Shaders.checkGLError("FT sd");
            for (n2 = 0; n2 < usedShadowColorBuffers; ++n2) {
                GlStateManager.bindTexture(sfbColorTextures.get(n2));
                GL11.glTexParameterf((int)3553, (int)10242, (float)10496.0f);
                GL11.glTexParameterf((int)3553, (int)10243, (float)10496.0f);
                n = shadowColorFilterNearest[n2] ? 9728 : 9729;
                GL11.glTexParameteri((int)3553, (int)10241, (int)n);
                GL11.glTexParameteri((int)3553, (int)10240, (int)n);
                GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)shadowMapWidth, (int)shadowMapHeight, (int)0, (int)32993, (int)33639, (ByteBuffer)null);
                EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + n2), (int)3553, (int)sfbColorTextures.get(n2), (int)0);
                Shaders.checkGLError("FT sc");
            }
            GlStateManager.bindTexture(0);
            if (usedShadowColorBuffers > 0) {
                GL20.glDrawBuffers((IntBuffer)sfbDrawBuffers);
            }
            if ((n2 = EXTFramebufferObject.glCheckFramebufferStatusEXT((int)36160)) != 36053) {
                Shaders.printChatAndLogError("[Shaders] Error: Failed creating shadow framebuffer! (Status " + n2 + ")");
            } else {
                SMCLog.info("Shadow framebuffer created.");
            }
        }
    }

    public static void beginRender(Minecraft minecraft, float f, long l) {
        int n;
        block25: {
            Shaders.checkGLError("pre beginRender");
            Shaders.checkWorldChanged(Shaders.mc.world);
            mc = minecraft;
            Shaders.mc.mcProfiler.startSection("init");
            entityRenderer = Shaders.mc.entityRenderer;
            if (!isShaderPackInitialized) {
                try {
                    Shaders.init();
                }
                catch (IllegalStateException illegalStateException) {
                    if (!Config.normalize(illegalStateException.getMessage()).equals("Function is not supported")) break block25;
                    Shaders.printChatAndLogError("[Shaders] Error: " + illegalStateException.getMessage());
                    illegalStateException.printStackTrace();
                    Shaders.setShaderPack(packNameNone);
                    return;
                }
            }
        }
        if (Shaders.mc.displayWidth != renderDisplayWidth || Shaders.mc.displayHeight != renderDisplayHeight) {
            Shaders.resize();
        }
        if (needResizeShadow) {
            Shaders.resizeShadow();
        }
        if ((diffWorldTime = ((worldTime = Shaders.mc.world.getWorldTime()) - lastWorldTime) % 24000L) < 0L) {
            diffWorldTime += 24000L;
        }
        lastWorldTime = worldTime;
        moonPhase = Shaders.mc.world.getMoonPhase();
        if (++frameCounter >= 720720) {
            frameCounter = 0;
        }
        systemTime = System.currentTimeMillis();
        if (lastSystemTime == 0L) {
            lastSystemTime = systemTime;
        }
        diffSystemTime = systemTime - lastSystemTime;
        lastSystemTime = systemTime;
        frameTime = (float)diffSystemTime / 1000.0f;
        frameTimeCounter += frameTime;
        frameTimeCounter %= 3600.0f;
        rainStrength = minecraft.world.getRainStrength(f);
        float f2 = (float)diffSystemTime * 0.01f;
        float f3 = (float)Math.exp(Math.log(0.5) * (double)f2 / (double)(wetness < rainStrength ? drynessHalfLife : wetnessHalfLife));
        wetness = wetness * f3 + rainStrength * (1.0f - f3);
        Entity entity = mc.getRenderViewEntity();
        if (entity != null) {
            isSleeping = entity instanceof EntityLivingBase && ((EntityLivingBase)entity).isPlayerSleeping();
            eyePosY = (float)entity.posY * f + (float)entity.lastTickPosY * (1.0f - f);
            eyeBrightness = entity.getBrightnessForRender();
            f3 = (float)diffSystemTime * 0.01f;
            float f4 = (float)Math.exp(Math.log(0.5) * (double)f3 / (double)eyeBrightnessHalflife);
            eyeBrightnessFadeX = eyeBrightnessFadeX * f4 + (float)(eyeBrightness & 0xFFFF) * (1.0f - f4);
            eyeBrightnessFadeY = eyeBrightnessFadeY * f4 + (float)(eyeBrightness >> 16) * (1.0f - f4);
            isEyeInWater = 0;
            if (Shaders.mc.gameSettings.thirdPersonView == 0 && !isSleeping) {
                if (entity.isInsideOfMaterial(Material.WATER)) {
                    isEyeInWater = 1;
                } else if (entity.isInsideOfMaterial(Material.LAVA)) {
                    isEyeInWater = 2;
                }
            }
            if (Shaders.mc.player != null) {
                nightVision = 0.0f;
                if (Shaders.mc.player.isPotionActive(MobEffects.NIGHT_VISION)) {
                    nightVision = Config.getMinecraft().entityRenderer.getNightVisionBrightness(Shaders.mc.player, f);
                }
                blindness = 0.0f;
                if (Shaders.mc.player.isPotionActive(MobEffects.BLINDNESS)) {
                    int n2 = Shaders.mc.player.getActivePotionEffect(MobEffects.BLINDNESS).getDuration();
                    blindness = Config.limit((float)n2 / 20.0f, 0.0f, 1.0f);
                }
            }
            Vec3d vec3d = Shaders.mc.world.getSkyColor(entity, f);
            vec3d = CustomColors.getWorldSkyColor(vec3d, currentWorld, entity, f);
            skyColorR = (float)vec3d.xCoord;
            skyColorG = (float)vec3d.yCoord;
            skyColorB = (float)vec3d.zCoord;
        }
        isRenderingWorld = true;
        isCompositeRendered = false;
        isHandRenderedMain = false;
        isHandRenderedOff = false;
        skipRenderHandMain = false;
        skipRenderHandOff = false;
        if (usedShadowDepthBuffers >= 1) {
            GlStateManager.setActiveTexture(33988);
            GlStateManager.bindTexture(sfbDepthTextures.get(0));
            if (usedShadowDepthBuffers >= 2) {
                GlStateManager.setActiveTexture(33989);
                GlStateManager.bindTexture(sfbDepthTextures.get(1));
            }
        }
        GlStateManager.setActiveTexture(33984);
        for (n = 0; n < usedColorBuffers; ++n) {
            GlStateManager.bindTexture(dfbColorTexturesA[n]);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GlStateManager.bindTexture(dfbColorTexturesA[8 + n]);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        }
        GlStateManager.bindTexture(0);
        for (n = 0; n < 4 && 4 + n < usedColorBuffers; ++n) {
            GlStateManager.setActiveTexture(33991 + n);
            GlStateManager.bindTexture(dfbColorTextures.get(4 + n));
        }
        GlStateManager.setActiveTexture(33990);
        GlStateManager.bindTexture(dfbDepthTextures.get(0));
        if (usedDepthBuffers >= 2) {
            GlStateManager.setActiveTexture(33995);
            GlStateManager.bindTexture(dfbDepthTextures.get(1));
            if (usedDepthBuffers >= 3) {
                GlStateManager.setActiveTexture(33996);
                GlStateManager.bindTexture(dfbDepthTextures.get(2));
            }
        }
        for (n = 0; n < usedShadowColorBuffers; ++n) {
            GlStateManager.setActiveTexture(33997 + n);
            GlStateManager.bindTexture(sfbColorTextures.get(n));
        }
        if (noiseTextureEnabled) {
            GlStateManager.setActiveTexture(33984 + noiseTexture.getTextureUnit());
            GlStateManager.bindTexture(noiseTexture.getTextureId());
            GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
            GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        }
        Shaders.bindCustomTextures(customTexturesGbuffers);
        GlStateManager.setActiveTexture(33984);
        previousCameraPositionX = cameraPositionX;
        previousCameraPositionY = cameraPositionY;
        previousCameraPositionZ = cameraPositionZ;
        previousProjection.position(0);
        projection.position(0);
        previousProjection.put(projection);
        previousProjection.position(0);
        projection.position(0);
        previousModelView.position(0);
        modelView.position(0);
        previousModelView.put(modelView);
        previousModelView.position(0);
        modelView.position(0);
        Shaders.checkGLError("beginRender");
        ShadersRender.renderShadowMap(entityRenderer, 0, f, l);
        Shaders.mc.mcProfiler.endSection();
        EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)dfb);
        for (n = 0; n < usedColorBuffers; ++n) {
            Shaders.colorTexturesToggle[n] = 0;
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + n), (int)3553, (int)dfbColorTexturesA[n], (int)0);
        }
        Shaders.checkGLError("end beginRender");
    }

    private static void checkWorldChanged(World world) {
        if (currentWorld != world) {
            World world2 = currentWorld;
            currentWorld = world;
            if (world2 != null && world != null) {
                int n = world2.provider.getDimensionType().getId();
                int n2 = world.provider.getDimensionType().getId();
                boolean bl = shaderPackDimensions.contains(n);
                boolean bl2 = shaderPackDimensions.contains(n2);
                if (bl || bl2) {
                    Shaders.uninit();
                }
            }
        }
    }

    public static void beginRenderPass(int n, float f, long l) {
        if (!isShadowPass) {
            EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)dfb);
            GL11.glViewport((int)0, (int)0, (int)renderWidth, (int)renderHeight);
            activeDrawBuffers = null;
            ShadersTex.bindNSTextures(defaultTexture.getMultiTexID());
            Shaders.useProgram(2);
            Shaders.checkGLError("end beginRenderPass");
        }
    }

    public static void setViewport(int n, int n2, int n3, int n4) {
        GlStateManager.colorMask(true, true, true, true);
        if (isShadowPass) {
            GL11.glViewport((int)0, (int)0, (int)shadowMapWidth, (int)shadowMapHeight);
        } else {
            GL11.glViewport((int)0, (int)0, (int)renderWidth, (int)renderHeight);
            EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)dfb);
            isRenderingDfb = true;
            GlStateManager.enableCull();
            GlStateManager.enableDepth();
            Shaders.setDrawBuffers(drawBuffersNone);
            Shaders.useProgram(2);
            Shaders.checkGLError("beginRenderPass");
        }
    }

    public static int setFogMode(int n) {
        fogMode = n;
        return n;
    }

    public static void setFogColor(float f, float f2, float f3) {
        fogColorR = f;
        fogColorG = f2;
        fogColorB = f3;
    }

    public static void setClearColor(float f, float f2, float f3, float f4) {
        GlStateManager.clearColor(f, f2, f3, f4);
        clearColorR = f;
        clearColorG = f2;
        clearColorB = f3;
    }

    public static void clearRenderBuffer() {
        if (isShadowPass) {
            Shaders.checkGLError("shadow clear pre");
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36096, (int)3553, (int)sfbDepthTextures.get(0), (int)0);
            GL11.glClearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL20.glDrawBuffers((IntBuffer)programsDrawBuffers[30]);
            Shaders.checkFramebufferStatus("shadow clear");
            GL11.glClear((int)16640);
            Shaders.checkGLError("shadow clear");
        } else {
            Shaders.checkGLError("clear pre");
            if (gbuffersClear[0]) {
                GL20.glDrawBuffers((int)36064);
                GL11.glClear((int)16384);
            }
            if (gbuffersClear[1]) {
                GL20.glDrawBuffers((int)36065);
                GL11.glClearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GL11.glClear((int)16384);
            }
            for (int i = 2; i < usedColorBuffers; ++i) {
                if (!gbuffersClear[i]) continue;
                GL20.glDrawBuffers((int)(36064 + i));
                GL11.glClearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
                GL11.glClear((int)16384);
            }
            Shaders.setDrawBuffers(dfbDrawBuffers);
            Shaders.checkFramebufferStatus("clear");
            Shaders.checkGLError("clear");
        }
    }

    public static void setCamera(float f) {
        Entity entity = mc.getRenderViewEntity();
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f;
        cameraPositionX = d;
        cameraPositionY = d2;
        cameraPositionZ = d3;
        GL11.glGetFloat((int)2983, (FloatBuffer)projection.position(0));
        SMath.invertMat4FBFA(projectionInverse.position(0), projection.position(0), faProjectionInverse, faProjection);
        projection.position(0);
        projectionInverse.position(0);
        GL11.glGetFloat((int)2982, (FloatBuffer)modelView.position(0));
        SMath.invertMat4FBFA(modelViewInverse.position(0), modelView.position(0), faModelViewInverse, faModelView);
        modelView.position(0);
        modelViewInverse.position(0);
        Shaders.checkGLError("setCamera");
    }

    public static void setCameraShadow(float f) {
        float f2;
        float f3;
        float f4;
        Entity entity = mc.getRenderViewEntity();
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f;
        cameraPositionX = d;
        cameraPositionY = d2;
        cameraPositionZ = d3;
        GL11.glGetFloat((int)2983, (FloatBuffer)projection.position(0));
        SMath.invertMat4FBFA(projectionInverse.position(0), projection.position(0), faProjectionInverse, faProjection);
        projection.position(0);
        projectionInverse.position(0);
        GL11.glGetFloat((int)2982, (FloatBuffer)modelView.position(0));
        SMath.invertMat4FBFA(modelViewInverse.position(0), modelView.position(0), faModelViewInverse, faModelView);
        modelView.position(0);
        modelViewInverse.position(0);
        GL11.glViewport((int)0, (int)0, (int)shadowMapWidth, (int)shadowMapHeight);
        GL11.glMatrixMode((int)5889);
        GL11.glLoadIdentity();
        if (shadowMapIsOrtho) {
            GL11.glOrtho((double)(-shadowMapHalfPlane), (double)shadowMapHalfPlane, (double)(-shadowMapHalfPlane), (double)shadowMapHalfPlane, (double)0.05f, (double)256.0);
        } else {
            GLU.gluPerspective((float)shadowMapFOV, (float)((float)shadowMapWidth / (float)shadowMapHeight), (float)0.05f, (float)256.0f);
        }
        GL11.glMatrixMode((int)5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef((float)0.0f, (float)0.0f, (float)-100.0f);
        GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        celestialAngle = Shaders.mc.world.getCelestialAngle(f);
        sunAngle = celestialAngle < 0.75f ? celestialAngle + 0.25f : celestialAngle - 0.75f;
        float f5 = celestialAngle * -360.0f;
        float f6 = f4 = shadowAngleInterval > 0.0f ? f5 % shadowAngleInterval - shadowAngleInterval * 0.5f : 0.0f;
        if ((double)sunAngle <= 0.5) {
            GL11.glRotatef((float)(f5 - f4), (float)0.0f, (float)0.0f, (float)1.0f);
            GL11.glRotatef((float)sunPathRotation, (float)1.0f, (float)0.0f, (float)0.0f);
            shadowAngle = sunAngle;
        } else {
            GL11.glRotatef((float)(f5 + 180.0f - f4), (float)0.0f, (float)0.0f, (float)1.0f);
            GL11.glRotatef((float)sunPathRotation, (float)1.0f, (float)0.0f, (float)0.0f);
            shadowAngle = sunAngle - 0.5f;
        }
        if (shadowMapIsOrtho) {
            f3 = shadowIntervalSize;
            f2 = f3 / 2.0f;
            GL11.glTranslatef((float)((float)d % f3 - f2), (float)((float)d2 % f3 - f2), (float)((float)d3 % f3 - f2));
        }
        f3 = sunAngle * ((float)Math.PI * 2);
        f2 = (float)Math.cos(f3);
        float f7 = (float)Math.sin(f3);
        float f8 = sunPathRotation * ((float)Math.PI * 2);
        float f9 = f2;
        float f10 = f7 * (float)Math.cos(f8);
        float f11 = f7 * (float)Math.sin(f8);
        if ((double)sunAngle > 0.5) {
            f9 = -f2;
            f10 = -f10;
            f11 = -f11;
        }
        Shaders.shadowLightPositionVector[0] = f9;
        Shaders.shadowLightPositionVector[1] = f10;
        Shaders.shadowLightPositionVector[2] = f11;
        Shaders.shadowLightPositionVector[3] = 0.0f;
        GL11.glGetFloat((int)2983, (FloatBuffer)shadowProjection.position(0));
        SMath.invertMat4FBFA(shadowProjectionInverse.position(0), shadowProjection.position(0), faShadowProjectionInverse, faShadowProjection);
        shadowProjection.position(0);
        shadowProjectionInverse.position(0);
        GL11.glGetFloat((int)2982, (FloatBuffer)shadowModelView.position(0));
        SMath.invertMat4FBFA(shadowModelViewInverse.position(0), shadowModelView.position(0), faShadowModelViewInverse, faShadowModelView);
        shadowModelView.position(0);
        shadowModelViewInverse.position(0);
        Shaders.setProgramUniformMatrix4ARB("gbufferProjection", false, projection);
        Shaders.setProgramUniformMatrix4ARB("gbufferProjectionInverse", false, projectionInverse);
        Shaders.setProgramUniformMatrix4ARB("gbufferPreviousProjection", false, previousProjection);
        Shaders.setProgramUniformMatrix4ARB("gbufferModelView", false, modelView);
        Shaders.setProgramUniformMatrix4ARB("gbufferModelViewInverse", false, modelViewInverse);
        Shaders.setProgramUniformMatrix4ARB("gbufferPreviousModelView", false, previousModelView);
        Shaders.setProgramUniformMatrix4ARB("shadowProjection", false, shadowProjection);
        Shaders.setProgramUniformMatrix4ARB("shadowProjectionInverse", false, shadowProjectionInverse);
        Shaders.setProgramUniformMatrix4ARB("shadowModelView", false, shadowModelView);
        Shaders.setProgramUniformMatrix4ARB("shadowModelViewInverse", false, shadowModelViewInverse);
        Shaders.mc.gameSettings.thirdPersonView = 1;
        Shaders.checkGLError("setCamera");
    }

    public static void preCelestialRotate() {
        GL11.glRotatef((float)(sunPathRotation * 1.0f), (float)0.0f, (float)0.0f, (float)1.0f);
        Shaders.checkGLError("preCelestialRotate");
    }

    public static void postCelestialRotate() {
        FloatBuffer floatBuffer = tempMatrixDirectBuffer;
        floatBuffer.clear();
        GL11.glGetFloat((int)2982, (FloatBuffer)floatBuffer);
        floatBuffer.get(tempMat, 0, 16);
        SMath.multiplyMat4xVec4(sunPosition, tempMat, sunPosModelView);
        SMath.multiplyMat4xVec4(moonPosition, tempMat, moonPosModelView);
        System.arraycopy(shadowAngle == sunAngle ? sunPosition : moonPosition, 0, shadowLightPosition, 0, 3);
        Shaders.setProgramUniform3f("sunPosition", sunPosition[0], sunPosition[1], sunPosition[2]);
        Shaders.setProgramUniform3f("moonPosition", moonPosition[0], moonPosition[1], moonPosition[2]);
        Shaders.setProgramUniform3f("shadowLightPosition", shadowLightPosition[0], shadowLightPosition[1], shadowLightPosition[2]);
        Shaders.checkGLError("postCelestialRotate");
    }

    public static void setUpPosition() {
        FloatBuffer floatBuffer = tempMatrixDirectBuffer;
        floatBuffer.clear();
        GL11.glGetFloat((int)2982, (FloatBuffer)floatBuffer);
        floatBuffer.get(tempMat, 0, 16);
        SMath.multiplyMat4xVec4(upPosition, tempMat, upPosModelView);
        Shaders.setProgramUniform3f("upPosition", upPosition[0], upPosition[1], upPosition[2]);
    }

    public static void genCompositeMipmap() {
        if (hasGlGenMipmap) {
            for (int i = 0; i < usedColorBuffers; ++i) {
                if ((activeCompositeMipmapSetting & 1 << i) == 0) continue;
                GlStateManager.setActiveTexture(33984 + colorTextureTextureImageUnit[i]);
                GL11.glTexParameteri((int)3553, (int)10241, (int)9987);
                GL30.glGenerateMipmap((int)3553);
            }
            GlStateManager.setActiveTexture(33984);
        }
    }

    public static void drawComposite() {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex3f((float)0.0f, (float)0.0f, (float)0.0f);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex3f((float)1.0f, (float)0.0f, (float)0.0f);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex3f((float)1.0f, (float)1.0f, (float)0.0f);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex3f((float)0.0f, (float)1.0f, (float)0.0f);
        GL11.glEnd();
    }

    public static void renderCompositeFinal() {
        if (!isShadowPass) {
            int n;
            int n2;
            Shaders.checkGLError("pre-renderCompositeFinal");
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glMatrixMode((int)5889);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glOrtho((double)0.0, (double)1.0, (double)0.0, (double)1.0, (double)0.0, (double)1.0);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GlStateManager.enableTexture2D();
            GlStateManager.disableAlpha();
            GlStateManager.disableBlend();
            GlStateManager.enableDepth();
            GlStateManager.depthFunc(519);
            GlStateManager.depthMask(false);
            GlStateManager.disableLighting();
            if (usedShadowDepthBuffers >= 1) {
                GlStateManager.setActiveTexture(33988);
                GlStateManager.bindTexture(sfbDepthTextures.get(0));
                if (usedShadowDepthBuffers >= 2) {
                    GlStateManager.setActiveTexture(33989);
                    GlStateManager.bindTexture(sfbDepthTextures.get(1));
                }
            }
            for (n2 = 0; n2 < usedColorBuffers; ++n2) {
                GlStateManager.setActiveTexture(33984 + colorTextureTextureImageUnit[n2]);
                GlStateManager.bindTexture(dfbColorTexturesA[n2]);
            }
            GlStateManager.setActiveTexture(33990);
            GlStateManager.bindTexture(dfbDepthTextures.get(0));
            if (usedDepthBuffers >= 2) {
                GlStateManager.setActiveTexture(33995);
                GlStateManager.bindTexture(dfbDepthTextures.get(1));
                if (usedDepthBuffers >= 3) {
                    GlStateManager.setActiveTexture(33996);
                    GlStateManager.bindTexture(dfbDepthTextures.get(2));
                }
            }
            for (n2 = 0; n2 < usedShadowColorBuffers; ++n2) {
                GlStateManager.setActiveTexture(33997 + n2);
                GlStateManager.bindTexture(sfbColorTextures.get(n2));
            }
            if (noiseTextureEnabled) {
                GlStateManager.setActiveTexture(33984 + noiseTexture.getTextureUnit());
                GlStateManager.bindTexture(noiseTexture.getTextureId());
                GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
                GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
                GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
                GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            }
            Shaders.bindCustomTextures(customTexturesComposite);
            GlStateManager.setActiveTexture(33984);
            n2 = 1;
            for (n = 0; n < usedColorBuffers; ++n) {
                EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + n), (int)3553, (int)dfbColorTexturesA[8 + n], (int)0);
            }
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36096, (int)3553, (int)dfbDepthTextures.get(0), (int)0);
            GL20.glDrawBuffers((IntBuffer)dfbDrawBuffers);
            Shaders.checkGLError("pre-composite");
            for (n = 0; n < 8; ++n) {
                if (programsID[21 + n] == 0) continue;
                Shaders.useProgram(21 + n);
                Shaders.checkGLError(programNames[21 + n]);
                if (activeCompositeMipmapSetting != 0) {
                    Shaders.genCompositeMipmap();
                }
                Shaders.drawComposite();
                for (int i = 0; i < usedColorBuffers; ++i) {
                    if (!programsToggleColorTextures[21 + n][i]) continue;
                    int n3 = colorTexturesToggle[i];
                    int n4 = Shaders.colorTexturesToggle[i] = 8 - n3;
                    GlStateManager.setActiveTexture(33984 + colorTextureTextureImageUnit[i]);
                    GlStateManager.bindTexture(dfbColorTexturesA[n4 + i]);
                    EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)(36064 + i), (int)3553, (int)dfbColorTexturesA[n3 + i], (int)0);
                }
                GlStateManager.setActiveTexture(33984);
            }
            Shaders.checkGLError("composite");
            isRenderingDfb = false;
            mc.getFramebuffer().bindFramebuffer(true);
            OpenGlHelper.glFramebufferTexture2D(OpenGlHelper.GL_FRAMEBUFFER, OpenGlHelper.GL_COLOR_ATTACHMENT0, 3553, Shaders.mc.getFramebuffer().framebufferTexture, 0);
            GL11.glViewport((int)0, (int)0, (int)Shaders.mc.displayWidth, (int)Shaders.mc.displayHeight);
            if (EntityRenderer.anaglyphEnable) {
                n = EntityRenderer.anaglyphField != 0 ? 1 : 0;
                GlStateManager.colorMask(n != 0, n == 0, n == 0, true);
            }
            GlStateManager.depthMask(true);
            GL11.glClearColor((float)clearColorR, (float)clearColorG, (float)clearColorB, (float)1.0f);
            GL11.glClear((int)16640);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GlStateManager.enableTexture2D();
            GlStateManager.disableAlpha();
            GlStateManager.disableBlend();
            GlStateManager.enableDepth();
            GlStateManager.depthFunc(519);
            GlStateManager.depthMask(false);
            Shaders.checkGLError("pre-final");
            Shaders.useProgram(29);
            Shaders.checkGLError("final");
            if (activeCompositeMipmapSetting != 0) {
                Shaders.genCompositeMipmap();
            }
            Shaders.drawComposite();
            Shaders.checkGLError("renderCompositeFinal");
            isCompositeRendered = true;
            GlStateManager.enableLighting();
            GlStateManager.enableTexture2D();
            GlStateManager.enableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.depthFunc(515);
            GlStateManager.depthMask(true);
            GL11.glPopMatrix();
            GL11.glMatrixMode((int)5888);
            GL11.glPopMatrix();
            Shaders.useProgram(0);
        }
    }

    public static void endRender() {
        if (isShadowPass) {
            Shaders.checkGLError("shadow endRender");
        } else {
            if (!isCompositeRendered) {
                Shaders.renderCompositeFinal();
            }
            isRenderingWorld = false;
            GlStateManager.colorMask(true, true, true, true);
            Shaders.useProgram(0);
            RenderHelper.disableStandardItemLighting();
            Shaders.checkGLError("endRender end");
        }
    }

    public static void beginSky() {
        isRenderingSky = true;
        fogEnabled = true;
        Shaders.setDrawBuffers(dfbDrawBuffers);
        Shaders.useProgram(5);
        Shaders.pushEntity(-2, 0);
    }

    public static void setSkyColor(Vec3d vec3d) {
        skyColorR = (float)vec3d.xCoord;
        skyColorG = (float)vec3d.yCoord;
        skyColorB = (float)vec3d.zCoord;
        Shaders.setProgramUniform3f("skyColor", skyColorR, skyColorG, skyColorB);
    }

    public static void drawHorizon() {
        BufferBuilder bufferBuilder = Tessellator.getInstance().getBuffer();
        float f = Shaders.mc.gameSettings.renderDistanceChunks * 16;
        double d = (double)f * 0.9238;
        double d2 = (double)f * 0.3826;
        double d3 = -d2;
        double d4 = -d;
        double d5 = 16.0;
        double d6 = -cameraPositionY;
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(d3, d6, d4).endVertex();
        bufferBuilder.pos(d3, d5, d4).endVertex();
        bufferBuilder.pos(d4, d5, d3).endVertex();
        bufferBuilder.pos(d4, d6, d3).endVertex();
        bufferBuilder.pos(d4, d6, d3).endVertex();
        bufferBuilder.pos(d4, d5, d3).endVertex();
        bufferBuilder.pos(d4, d5, d2).endVertex();
        bufferBuilder.pos(d4, d6, d2).endVertex();
        bufferBuilder.pos(d4, d6, d2).endVertex();
        bufferBuilder.pos(d4, d5, d2).endVertex();
        bufferBuilder.pos(d3, d5, d2).endVertex();
        bufferBuilder.pos(d3, d6, d2).endVertex();
        bufferBuilder.pos(d3, d6, d2).endVertex();
        bufferBuilder.pos(d3, d5, d2).endVertex();
        bufferBuilder.pos(d2, d5, d).endVertex();
        bufferBuilder.pos(d2, d6, d).endVertex();
        bufferBuilder.pos(d2, d6, d).endVertex();
        bufferBuilder.pos(d2, d5, d).endVertex();
        bufferBuilder.pos(d, d5, d2).endVertex();
        bufferBuilder.pos(d, d6, d2).endVertex();
        bufferBuilder.pos(d, d6, d2).endVertex();
        bufferBuilder.pos(d, d5, d2).endVertex();
        bufferBuilder.pos(d, d5, d3).endVertex();
        bufferBuilder.pos(d, d6, d3).endVertex();
        bufferBuilder.pos(d, d6, d3).endVertex();
        bufferBuilder.pos(d, d5, d3).endVertex();
        bufferBuilder.pos(d2, d5, d4).endVertex();
        bufferBuilder.pos(d2, d6, d4).endVertex();
        bufferBuilder.pos(d2, d6, d4).endVertex();
        bufferBuilder.pos(d2, d5, d4).endVertex();
        bufferBuilder.pos(d3, d5, d4).endVertex();
        bufferBuilder.pos(d3, d6, d4).endVertex();
        Tessellator.getInstance().draw();
    }

    public static void preSkyList() {
        Shaders.setUpPosition();
        GL11.glColor3f((float)fogColorR, (float)fogColorG, (float)fogColorB);
        Shaders.drawHorizon();
        GL11.glColor3f((float)skyColorR, (float)skyColorG, (float)skyColorB);
    }

    public static void endSky() {
        isRenderingSky = false;
        Shaders.setDrawBuffers(dfbDrawBuffers);
        Shaders.useProgram(lightmapEnabled ? 3 : 2);
        Shaders.popEntity();
    }

    public static void beginUpdateChunks() {
        Shaders.checkGLError("beginUpdateChunks1");
        Shaders.checkFramebufferStatus("beginUpdateChunks1");
        if (!isShadowPass) {
            Shaders.useProgram(7);
        }
        Shaders.checkGLError("beginUpdateChunks2");
        Shaders.checkFramebufferStatus("beginUpdateChunks2");
    }

    public static void endUpdateChunks() {
        Shaders.checkGLError("endUpdateChunks1");
        Shaders.checkFramebufferStatus("endUpdateChunks1");
        if (!isShadowPass) {
            Shaders.useProgram(7);
        }
        Shaders.checkGLError("endUpdateChunks2");
        Shaders.checkFramebufferStatus("endUpdateChunks2");
    }

    public static boolean shouldRenderClouds(GameSettings gameSettings) {
        if (!shaderPackLoaded) {
            return true;
        }
        Shaders.checkGLError("shouldRenderClouds");
        return isShadowPass ? configCloudShadow : gameSettings.clouds > 0;
    }

    public static void beginClouds() {
        fogEnabled = true;
        Shaders.pushEntity(-3, 0);
        Shaders.useProgram(6);
    }

    public static void endClouds() {
        Shaders.disableFog();
        Shaders.popEntity();
        Shaders.useProgram(lightmapEnabled ? 3 : 2);
    }

    public static void beginEntities() {
        if (isRenderingWorld) {
            Shaders.useProgram(16);
            Shaders.resetDisplayListModels();
        }
    }

    public static void nextEntity(Entity entity) {
        if (isRenderingWorld) {
            Shaders.useProgram(16);
            Shaders.setEntityId(entity);
        }
    }

    public static void setEntityId(Entity entity) {
        if (isRenderingWorld && !isShadowPass && uniformEntityId.isDefined()) {
            int n = EntityUtils.getEntityIdByClass(entity);
            uniformEntityId.setValue(n);
        }
    }

    public static void beginSpiderEyes() {
        if (isRenderingWorld && programsID[18] != programsID[0]) {
            Shaders.useProgram(18);
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(516, 0.0f);
            GlStateManager.blendFunc(770, 771);
        }
    }

    public static void endSpiderEyes() {
        if (isRenderingWorld && programsID[18] != programsID[0]) {
            Shaders.useProgram(16);
            GlStateManager.disableAlpha();
        }
    }

    public static void endEntities() {
        if (isRenderingWorld) {
            Shaders.useProgram(lightmapEnabled ? 3 : 2);
        }
    }

    public static void setEntityColor(float f, float f2, float f3, float f4) {
        if (isRenderingWorld && !isShadowPass) {
            uniformEntityColor.setValue(f, f2, f3, f4);
        }
    }

    public static void beginLivingDamage() {
        if (isRenderingWorld) {
            ShadersTex.bindTexture(defaultTexture);
            if (!isShadowPass) {
                Shaders.setDrawBuffers(drawBuffersColorAtt0);
            }
        }
    }

    public static void endLivingDamage() {
        if (isRenderingWorld && !isShadowPass) {
            Shaders.setDrawBuffers(programsDrawBuffers[16]);
        }
    }

    public static void beginBlockEntities() {
        if (isRenderingWorld) {
            Shaders.checkGLError("beginBlockEntities");
            Shaders.useProgram(13);
        }
    }

    public static void nextBlockEntity(TileEntity tileEntity) {
        if (isRenderingWorld) {
            Shaders.checkGLError("nextBlockEntity");
            Shaders.useProgram(13);
            Shaders.setBlockEntityId(tileEntity);
        }
    }

    public static void setBlockEntityId(TileEntity tileEntity) {
        if (isRenderingWorld && !isShadowPass && uniformBlockEntityId.isDefined()) {
            Block block = tileEntity.getBlockType();
            int n = Block.getIdFromBlock(block);
            uniformBlockEntityId.setValue(n);
        }
    }

    public static void endBlockEntities() {
        if (isRenderingWorld) {
            Shaders.checkGLError("endBlockEntities");
            Shaders.useProgram(lightmapEnabled ? 3 : 2);
            ShadersTex.bindNSTextures(defaultTexture.getMultiTexID());
        }
    }

    public static void beginLitParticles() {
        Shaders.useProgram(3);
    }

    public static void beginParticles() {
        Shaders.useProgram(2);
    }

    public static void endParticles() {
        Shaders.useProgram(3);
    }

    public static void readCenterDepth() {
        if (!isShadowPass && centerDepthSmoothEnabled) {
            tempDirectFloatBuffer.clear();
            GL11.glReadPixels((int)(renderWidth / 2), (int)(renderHeight / 2), (int)1, (int)1, (int)6402, (int)5126, (FloatBuffer)tempDirectFloatBuffer);
            centerDepth = tempDirectFloatBuffer.get(0);
            float f = (float)diffSystemTime * 0.01f;
            float f2 = (float)Math.exp(Math.log(0.5) * (double)f / (double)centerDepthSmoothHalflife);
            centerDepthSmooth = centerDepthSmooth * f2 + centerDepth * (1.0f - f2);
        }
    }

    public static void beginWeather() {
        if (!isShadowPass) {
            if (usedDepthBuffers >= 3) {
                GlStateManager.setActiveTexture(33996);
                GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)renderWidth, (int)renderHeight);
                GlStateManager.setActiveTexture(33984);
            }
            GlStateManager.enableDepth();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            GlStateManager.enableAlpha();
            Shaders.useProgram(20);
        }
    }

    public static void endWeather() {
        GlStateManager.disableBlend();
        Shaders.useProgram(3);
    }

    public static void preWater() {
        if (usedDepthBuffers >= 2) {
            GlStateManager.setActiveTexture(33995);
            Shaders.checkGLError("pre copy depth");
            GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)renderWidth, (int)renderHeight);
            Shaders.checkGLError("copy depth");
            GlStateManager.setActiveTexture(33984);
        }
        ShadersTex.bindNSTextures(defaultTexture.getMultiTexID());
    }

    public static void beginWater() {
        if (isRenderingWorld) {
            if (!isShadowPass) {
                Shaders.useProgram(12);
                GlStateManager.enableBlend();
                GlStateManager.depthMask(true);
            } else {
                GlStateManager.depthMask(true);
            }
        }
    }

    public static void endWater() {
        if (isRenderingWorld) {
            if (isShadowPass) {
                // empty if block
            }
            Shaders.useProgram(lightmapEnabled ? 3 : 2);
        }
    }

    public static void beginProjectRedHalo() {
        if (isRenderingWorld) {
            Shaders.useProgram(1);
        }
    }

    public static void endProjectRedHalo() {
        if (isRenderingWorld) {
            Shaders.useProgram(3);
        }
    }

    public static void applyHandDepth() {
        if ((double)configHandDepthMul != 1.0) {
            GL11.glScaled((double)1.0, (double)1.0, (double)configHandDepthMul);
        }
    }

    public static void beginHand() {
        GL11.glMatrixMode((int)5888);
        GL11.glPushMatrix();
        GL11.glMatrixMode((int)5889);
        GL11.glPushMatrix();
        GL11.glMatrixMode((int)5888);
        Shaders.useProgram(19);
        Shaders.checkGLError("beginHand");
        Shaders.checkFramebufferStatus("beginHand");
    }

    public static void endHand() {
        Shaders.checkGLError("pre endHand");
        Shaders.checkFramebufferStatus("pre endHand");
        GL11.glMatrixMode((int)5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode((int)5888);
        GL11.glPopMatrix();
        GlStateManager.blendFunc(770, 771);
        Shaders.checkGLError("endHand");
    }

    public static void beginFPOverlay() {
        GlStateManager.disableLighting();
        GlStateManager.disableBlend();
    }

    public static void endFPOverlay() {
    }

    public static void glEnableWrapper(int n) {
        GL11.glEnable((int)n);
        if (n == 3553) {
            Shaders.enableTexture2D();
        } else if (n == 2912) {
            Shaders.enableFog();
        }
    }

    public static void glDisableWrapper(int n) {
        GL11.glDisable((int)n);
        if (n == 3553) {
            Shaders.disableTexture2D();
        } else if (n == 2912) {
            Shaders.disableFog();
        }
    }

    public static void sglEnableT2D(int n) {
        GL11.glEnable((int)n);
        Shaders.enableTexture2D();
    }

    public static void sglDisableT2D(int n) {
        GL11.glDisable((int)n);
        Shaders.disableTexture2D();
    }

    public static void sglEnableFog(int n) {
        GL11.glEnable((int)n);
        Shaders.enableFog();
    }

    public static void sglDisableFog(int n) {
        GL11.glDisable((int)n);
        Shaders.disableFog();
    }

    public static void enableTexture2D() {
        if (isRenderingSky) {
            Shaders.useProgram(5);
        } else if (activeProgram == 1) {
            Shaders.useProgram(lightmapEnabled ? 3 : 2);
        }
    }

    public static void disableTexture2D() {
        if (isRenderingSky) {
            Shaders.useProgram(4);
        } else if (activeProgram == 2 || activeProgram == 3) {
            Shaders.useProgram(1);
        }
    }

    public static void beginLeash() {
        Shaders.useProgram(1);
    }

    public static void endLeash() {
        Shaders.useProgram(16);
    }

    public static void enableFog() {
        fogEnabled = true;
        Shaders.setProgramUniform1i("fogMode", fogMode);
    }

    public static void disableFog() {
        fogEnabled = false;
        Shaders.setProgramUniform1i("fogMode", 0);
    }

    public static void setFog(GlStateManager.FogMode fogMode) {
        GlStateManager.setFog(fogMode);
        if (fogEnabled) {
            Shaders.setProgramUniform1i("fogMode", fogMode.capabilityId);
        }
    }

    public static void sglFogi(int n, int n2) {
        GL11.glFogi((int)n, (int)n2);
        if (n == 2917) {
            fogMode = n2;
            if (fogEnabled) {
                Shaders.setProgramUniform1i("fogMode", fogMode);
            }
        }
    }

    public static void enableLightmap() {
        lightmapEnabled = true;
        if (activeProgram == 2) {
            Shaders.useProgram(3);
        }
    }

    public static void disableLightmap() {
        lightmapEnabled = false;
        if (activeProgram == 3) {
            Shaders.useProgram(2);
        }
    }

    public static int getEntityData() {
        return entityData[entityDataIndex * 2];
    }

    public static int getEntityData2() {
        return entityData[entityDataIndex * 2 + 1];
    }

    public static int setEntityData1(int n) {
        Shaders.entityData[Shaders.entityDataIndex * 2] = entityData[entityDataIndex * 2] & 0xFFFF | n << 16;
        return n;
    }

    public static int setEntityData2(int n) {
        Shaders.entityData[Shaders.entityDataIndex * 2 + 1] = entityData[entityDataIndex * 2 + 1] & 0xFFFF0000 | n & 0xFFFF;
        return n;
    }

    public static void pushEntity(int n, int n2) {
        Shaders.entityData[++Shaders.entityDataIndex * 2] = n & 0xFFFF | n2 << 16;
        Shaders.entityData[Shaders.entityDataIndex * 2 + 1] = 0;
    }

    public static void pushEntity(int n) {
        Shaders.entityData[++Shaders.entityDataIndex * 2] = n & 0xFFFF;
        Shaders.entityData[Shaders.entityDataIndex * 2 + 1] = 0;
    }

    public static void pushEntity(Block block) {
        int n = block.getRenderType(block.getDefaultState()).ordinal();
        Shaders.entityData[++Shaders.entityDataIndex * 2] = Block.REGISTRY.getIDForObject(block) & 0xFFFF | n << 16;
        Shaders.entityData[Shaders.entityDataIndex * 2 + 1] = 0;
    }

    public static void popEntity() {
        Shaders.entityData[Shaders.entityDataIndex * 2] = 0;
        Shaders.entityData[Shaders.entityDataIndex * 2 + 1] = 0;
        --entityDataIndex;
    }

    public static void mcProfilerEndSection() {
        Shaders.mc.mcProfiler.endSection();
    }

    public static String getShaderPackName() {
        if (shaderPack == null) {
            return null;
        }
        return shaderPack instanceof ShaderPackNone ? null : shaderPack.getName();
    }

    public static InputStream getShaderPackResourceStream(String string) {
        return shaderPack == null ? null : shaderPack.getResourceAsStream(string);
    }

    public static void nextAntialiasingLevel() {
        configAntialiasingLevel += 2;
        if ((configAntialiasingLevel = configAntialiasingLevel / 2 * 2) > 4) {
            configAntialiasingLevel = 0;
        }
        configAntialiasingLevel = Config.limit(configAntialiasingLevel, 0, 4);
    }

    public static void checkShadersModInstalled() {
        try {
            Class<?> clazz = Class.forName("shadersmod.transform.SMCClassTransformer");
        }
        catch (Throwable throwable) {
            return;
        }
        throw new RuntimeException("Shaders Mod detected. Please remove it, OptiFine has built-in support for shaders.");
    }

    public static void resourcesReloaded() {
        Shaders.loadShaderPackResources();
    }

    private static void loadShaderPackResources() {
        shaderPackResources = new HashMap<String, String>();
        if (shaderPackLoaded) {
            ArrayList<CallSite> arrayList = new ArrayList<CallSite>();
            String string = "/shaders/lang/";
            String string2 = "en_US";
            String string3 = ".lang";
            arrayList.add((CallSite)((Object)(string + string2 + string3)));
            if (!Config.getGameSettings().language.equals(string2)) {
                arrayList.add((CallSite)((Object)(string + Config.getGameSettings().language + string3)));
            }
            try {
                for (String string4 : arrayList) {
                    InputStream inputStream = shaderPack.getResourceAsStream(string4);
                    if (inputStream == null) continue;
                    Properties properties = new Properties();
                    Lang.loadLocaleData(inputStream, properties);
                    inputStream.close();
                    for (Object object : properties.keySet()) {
                        String string5 = properties.getProperty((String)object);
                        shaderPackResources.put((String)object, string5);
                    }
                }
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    public static String translate(String string, String string2) {
        String string3 = shaderPackResources.get(string);
        return string3 == null ? string2 : string3;
    }

    public static boolean isProgramPath(String string) {
        if (string == null) {
            return false;
        }
        if (string.length() <= 0) {
            return false;
        }
        int n = string.lastIndexOf("/");
        if (n >= 0) {
            string = string.substring(n + 1);
        }
        return Arrays.asList(programNames).contains(string);
    }

    public static void setItemToRenderMain(ItemStack itemStack) {
        itemToRenderMainTranslucent = Shaders.isTranslucentBlock(itemStack);
    }

    public static void setItemToRenderOff(ItemStack itemStack) {
        itemToRenderOffTranslucent = Shaders.isTranslucentBlock(itemStack);
    }

    public static boolean isItemToRenderMainTranslucent() {
        return itemToRenderMainTranslucent;
    }

    public static boolean isItemToRenderOffTranslucent() {
        return itemToRenderOffTranslucent;
    }

    public static boolean isBothHandsRendered() {
        return isHandRenderedMain && isHandRenderedOff;
    }

    private static boolean isTranslucentBlock(ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        Item item = itemStack.getItem();
        if (item == null) {
            return false;
        }
        if (!(item instanceof ItemBlock)) {
            return false;
        }
        ItemBlock itemBlock = (ItemBlock)item;
        Block block = itemBlock.getBlock();
        if (block == null) {
            return false;
        }
        BlockRenderLayer blockRenderLayer = block.getBlockLayer();
        return blockRenderLayer == BlockRenderLayer.TRANSLUCENT;
    }

    public static boolean isSkipRenderHand(EnumHand enumHand) {
        if (enumHand == EnumHand.MAIN_HAND && skipRenderHandMain) {
            return true;
        }
        return enumHand == EnumHand.OFF_HAND && skipRenderHandOff;
    }

    public static boolean isRenderBothHands() {
        return !skipRenderHandMain && !skipRenderHandOff;
    }

    public static void setSkipRenderHands(boolean bl, boolean bl2) {
        skipRenderHandMain = bl;
        skipRenderHandOff = bl2;
    }

    public static void setHandsRendered(boolean bl, boolean bl2) {
        isHandRenderedMain = bl;
        isHandRenderedOff = bl2;
    }

    public static boolean isHandRenderedMain() {
        return isHandRenderedMain;
    }

    public static boolean isHandRenderedOff() {
        return isHandRenderedOff;
    }

    public static float getShadowRenderDistance() {
        return shadowDistanceRenderMul < 0.0f ? -1.0f : shadowMapHalfPlane * shadowDistanceRenderMul;
    }

    public static void setRenderingFirstPersonHand(boolean bl) {
        isRenderingFirstPersonHand = bl;
    }

    public static boolean isRenderingFirstPersonHand() {
        return isRenderingFirstPersonHand;
    }

    public static void beginBeacon() {
        if (isRenderingWorld) {
            Shaders.useProgram(14);
        }
    }

    public static void endBeacon() {
        if (isRenderingWorld) {
            Shaders.useProgram(13);
        }
    }

    static {
        isInitializedOnce = false;
        isShaderPackInitialized = false;
        hasGlGenMipmap = false;
        hasForge = false;
        numberResetDisplayList = 0;
        needResetModels = false;
        renderDisplayWidth = 0;
        renderDisplayHeight = 0;
        renderWidth = 0;
        renderHeight = 0;
        isRenderingWorld = false;
        isRenderingSky = false;
        isCompositeRendered = false;
        isRenderingDfb = false;
        isShadowPass = false;
        renderItemKeepDepthMask = false;
        itemToRenderMainTranslucent = false;
        itemToRenderOffTranslucent = false;
        sunPosition = new float[4];
        moonPosition = new float[4];
        shadowLightPosition = new float[4];
        upPosition = new float[4];
        shadowLightPositionVector = new float[4];
        upPosModelView = new float[]{0.0f, 100.0f, 0.0f, 0.0f};
        sunPosModelView = new float[]{0.0f, 100.0f, 0.0f, 0.0f};
        moonPosModelView = new float[]{0.0f, -100.0f, 0.0f, 0.0f};
        tempMat = new float[16];
        worldTime = 0L;
        lastWorldTime = 0L;
        diffWorldTime = 0L;
        celestialAngle = 0.0f;
        sunAngle = 0.0f;
        shadowAngle = 0.0f;
        moonPhase = 0;
        systemTime = 0L;
        lastSystemTime = 0L;
        diffSystemTime = 0L;
        frameCounter = 0;
        frameTime = 0.0f;
        frameTimeCounter = 0.0f;
        systemTimeInt32 = 0;
        rainStrength = 0.0f;
        wetness = 0.0f;
        wetnessHalfLife = 600.0f;
        drynessHalfLife = 200.0f;
        eyeBrightnessHalflife = 10.0f;
        usewetness = false;
        isEyeInWater = 0;
        eyeBrightness = 0;
        eyeBrightnessFadeX = 0.0f;
        eyeBrightnessFadeY = 0.0f;
        eyePosY = 0.0f;
        centerDepth = 0.0f;
        centerDepthSmooth = 0.0f;
        centerDepthSmoothHalflife = 1.0f;
        centerDepthSmoothEnabled = false;
        superSamplingLevel = 1;
        nightVision = 0.0f;
        blindness = 0.0f;
        updateChunksErrorRecorded = false;
        lightmapEnabled = false;
        fogEnabled = true;
        entityAttrib = 10;
        midTexCoordAttrib = 11;
        tangentAttrib = 12;
        useEntityAttrib = false;
        useMidTexCoordAttrib = false;
        useMultiTexCoord3Attrib = false;
        useTangentAttrib = false;
        progUseEntityAttrib = false;
        progUseMidTexCoordAttrib = false;
        progUseTangentAttrib = false;
        atlasSizeX = 0;
        atlasSizeY = 0;
        uniformEntityColor = new ShaderUniformFloat4("entityColor");
        uniformEntityId = new ShaderUniformInt("entityId");
        uniformBlockEntityId = new ShaderUniformInt("blockEntityId");
        shadowPassInterval = 0;
        needResizeShadow = false;
        shadowMapWidth = 1024;
        shadowMapHeight = 1024;
        spShadowMapWidth = 1024;
        spShadowMapHeight = 1024;
        shadowMapFOV = 90.0f;
        shadowMapHalfPlane = 160.0f;
        shadowMapIsOrtho = true;
        shadowDistanceRenderMul = -1.0f;
        shadowPassCounter = 0;
        shouldSkipDefaultShadow = false;
        waterShadowEnabled = false;
        usedColorBuffers = 0;
        usedDepthBuffers = 0;
        usedShadowColorBuffers = 0;
        usedShadowDepthBuffers = 0;
        usedColorAttachs = 0;
        usedDrawBuffers = 0;
        dfb = 0;
        sfb = 0;
        gbuffersFormat = new int[8];
        gbuffersClear = new boolean[8];
        activeProgram = 0;
        programNames = new String[]{"", "gbuffers_basic", "gbuffers_textured", "gbuffers_textured_lit", "gbuffers_skybasic", "gbuffers_skytextured", "gbuffers_clouds", "gbuffers_terrain", "gbuffers_terrain_solid", "gbuffers_terrain_cutout_mip", "gbuffers_terrain_cutout", "gbuffers_damagedblock", "gbuffers_water", "gbuffers_block", "gbuffers_beaconbeam", "gbuffers_item", "gbuffers_entities", "gbuffers_armor_glint", "gbuffers_spidereyes", "gbuffers_hand", "gbuffers_weather", "composite", "composite1", "composite2", "composite3", "composite4", "composite5", "composite6", "composite7", "final", "shadow", "shadow_solid", "shadow_cutout"};
        programBackups = new int[]{0, 0, 1, 2, 1, 2, 2, 3, 7, 7, 7, 7, 7, 7, 2, 3, 3, 2, 2, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 30};
        programsID = new int[33];
        programsRef = new int[33];
        programIDCopyDepth = 0;
        programsDrawBufSettings = new String[33];
        newDrawBufSetting = null;
        programsDrawBuffers = new IntBuffer[33];
        activeDrawBuffers = null;
        programsColorAtmSettings = new String[33];
        newColorAtmSetting = null;
        activeColorAtmSettings = null;
        programsCompositeMipmapSetting = new int[33];
        newCompositeMipmapSetting = 0;
        activeCompositeMipmapSetting = 0;
        loadedShaders = null;
        shadersConfig = null;
        defaultTexture = null;
        normalMapEnabled = false;
        shadowHardwareFilteringEnabled = new boolean[2];
        shadowMipmapEnabled = new boolean[2];
        shadowFilterNearest = new boolean[2];
        shadowColorMipmapEnabled = new boolean[8];
        shadowColorFilterNearest = new boolean[8];
        configTweakBlockDamage = false;
        configCloudShadow = false;
        configHandDepthMul = 0.125f;
        configRenderResMul = 1.0f;
        configShadowResMul = 1.0f;
        configTexMinFilB = 0;
        configTexMinFilN = 0;
        configTexMinFilS = 0;
        configTexMagFilB = 0;
        configTexMagFilN = 0;
        configTexMagFilS = 0;
        configShadowClipFrustrum = true;
        configNormalMap = true;
        configSpecularMap = true;
        configOldLighting = new PropertyDefaultTrueFalse("oldLighting", "Classic Lighting", 0);
        configOldHandLight = new PropertyDefaultTrueFalse("oldHandLight", "Old Hand Light", 0);
        configAntialiasingLevel = 0;
        texMinFilDesc = new String[]{"Nearest", "Nearest-Nearest", "Nearest-Linear"};
        texMagFilDesc = new String[]{"Nearest", "Linear"};
        texMinFilValue = new int[]{9728, 9984, 9986};
        texMagFilValue = new int[]{9728, 9729};
        shaderPack = null;
        shaderPackLoaded = false;
        packNameNone = "OFF";
        packNameDefault = "(internal)";
        shaderpacksdirname = "shaderpacks";
        optionsfilename = "optionsshaders.txt";
        shaderPackOptions = null;
        shaderPackOptionSliders = null;
        shaderPackProfiles = null;
        shaderPackGuiScreens = null;
        shaderPackClouds = new PropertyDefaultFastFancyOff("clouds", "Clouds", 0);
        shaderPackOldLighting = new PropertyDefaultTrueFalse("oldLighting", "Classic Lighting", 0);
        shaderPackOldHandLight = new PropertyDefaultTrueFalse("oldHandLight", "Old Hand Light", 0);
        shaderPackDynamicHandLight = new PropertyDefaultTrueFalse("dynamicHandLight", "Dynamic Hand Light", 0);
        shaderPackShadowTranslucent = new PropertyDefaultTrueFalse("shadowTranslucent", "Shadow Translucent", 0);
        shaderPackUnderwaterOverlay = new PropertyDefaultTrueFalse("underwaterOverlay", "Underwater Overlay", 0);
        shaderPackSun = new PropertyDefaultTrueFalse("sun", "Sun", 0);
        shaderPackMoon = new PropertyDefaultTrueFalse("moon", "Moon", 0);
        shaderPackVignette = new PropertyDefaultTrueFalse("vignette", "Vignette", 0);
        shaderPackBackFaceSolid = new PropertyDefaultTrueFalse("backFace.solid", "Back-face Solid", 0);
        shaderPackBackFaceCutout = new PropertyDefaultTrueFalse("backFace.cutout", "Back-face Cutout", 0);
        shaderPackBackFaceCutoutMipped = new PropertyDefaultTrueFalse("backFace.cutoutMipped", "Back-face Cutout Mipped", 0);
        shaderPackBackFaceTranslucent = new PropertyDefaultTrueFalse("backFace.translucent", "Back-face Translucent", 0);
        shaderPackResources = new HashMap<String, String>();
        currentWorld = null;
        shaderPackDimensions = new ArrayList<Integer>();
        customTexturesGbuffers = null;
        customTexturesComposite = null;
        noiseTexturePath = null;
        STAGE_NAMES = new String[]{"gbuffers", "composite"};
        saveFinalShaders = System.getProperty("shaders.debug.save", "false").equals("true");
        blockLightLevel05 = 0.5f;
        blockLightLevel06 = 0.6f;
        blockLightLevel08 = 0.8f;
        aoLevel = -1.0f;
        sunPathRotation = 0.0f;
        shadowAngleInterval = 0.0f;
        fogMode = 0;
        shadowIntervalSize = 2.0f;
        terrainIconSize = 16;
        terrainTextureSize = new int[2];
        noiseTextureEnabled = false;
        noiseTextureResolution = 256;
        dfbColorTexturesA = new int[16];
        colorTexturesToggle = new int[8];
        colorTextureTextureImageUnit = new int[]{0, 1, 2, 3, 7, 8, 9, 10};
        programsToggleColorTextures = new boolean[33][8];
        bigBuffer = BufferUtils.createByteBuffer((int)2196).limit(0);
        faProjection = new float[16];
        faProjectionInverse = new float[16];
        faModelView = new float[16];
        faModelViewInverse = new float[16];
        faShadowProjection = new float[16];
        faShadowProjectionInverse = new float[16];
        faShadowModelView = new float[16];
        faShadowModelViewInverse = new float[16];
        projection = Shaders.nextFloatBuffer(16);
        projectionInverse = Shaders.nextFloatBuffer(16);
        modelView = Shaders.nextFloatBuffer(16);
        modelViewInverse = Shaders.nextFloatBuffer(16);
        shadowProjection = Shaders.nextFloatBuffer(16);
        shadowProjectionInverse = Shaders.nextFloatBuffer(16);
        shadowModelView = Shaders.nextFloatBuffer(16);
        shadowModelViewInverse = Shaders.nextFloatBuffer(16);
        previousProjection = Shaders.nextFloatBuffer(16);
        previousModelView = Shaders.nextFloatBuffer(16);
        tempMatrixDirectBuffer = Shaders.nextFloatBuffer(16);
        tempDirectFloatBuffer = Shaders.nextFloatBuffer(16);
        dfbColorTextures = Shaders.nextIntBuffer(16);
        dfbDepthTextures = Shaders.nextIntBuffer(3);
        sfbColorTextures = Shaders.nextIntBuffer(8);
        sfbDepthTextures = Shaders.nextIntBuffer(2);
        dfbDrawBuffers = Shaders.nextIntBuffer(8);
        sfbDrawBuffers = Shaders.nextIntBuffer(8);
        drawBuffersNone = Shaders.nextIntBuffer(8);
        drawBuffersAll = Shaders.nextIntBuffer(8);
        drawBuffersClear0 = Shaders.nextIntBuffer(8);
        drawBuffersClear1 = Shaders.nextIntBuffer(8);
        drawBuffersClearColor = Shaders.nextIntBuffer(8);
        drawBuffersColorAtt0 = Shaders.nextIntBuffer(8);
        drawBuffersBuffer = Shaders.nextIntBufferArray(33, 8);
        formatNames = new String[]{"R8", "RG8", "RGB8", "RGBA8", "R8_SNORM", "RG8_SNORM", "RGB8_SNORM", "RGBA8_SNORM", "R16", "RG16", "RGB16", "RGBA16", "R16_SNORM", "RG16_SNORM", "RGB16_SNORM", "RGBA16_SNORM", "R16F", "RG16F", "RGB16F", "RGBA16F", "R32F", "RG32F", "RGB32F", "RGBA32F", "R32I", "RG32I", "RGB32I", "RGBA32I", "R32UI", "RG32UI", "RGB32UI", "RGBA32UI", "R3_G3_B2", "RGB5_A1", "RGB10_A2", "R11F_G11F_B10F", "RGB9_E5"};
        formatIds = new int[]{33321, 33323, 32849, 32856, 36756, 36757, 36758, 36759, 33322, 33324, 32852, 32859, 36760, 36761, 36762, 36763, 33325, 33327, 34843, 34842, 33326, 33328, 34837, 34836, 33333, 33339, 36227, 36226, 33334, 33340, 36209, 36208, 10768, 32855, 32857, 35898, 35901};
        patternLoadEntityDataMap = Pattern.compile("\\s*([\\w:]+)\\s*=\\s*([-]?\\d+)\\s*");
        entityData = new int[32];
        entityDataIndex = 0;
        shadersdir = new File(Minecraft.getMinecraft().mcDataDir, "shaders");
        shaderpacksdir = new File(Minecraft.getMinecraft().mcDataDir, shaderpacksdirname);
        configFile = new File(Minecraft.getMinecraft().mcDataDir, optionsfilename);
        drawBuffersNone.limit(0);
        drawBuffersColorAtt0.put(36064).position(0).limit(1);
    }
}
