package shadersmod.client;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import shadersmod.client.ShaderOption;

public class ShaderProfile {
    private String name = null;
    private Map<String, String> mapOptionValues = new HashMap<String, String>();
    private Set<String> disabledPrograms = new HashSet<String>();

    public ShaderProfile(String string) {
        this.name = string;
    }

    public String getName() {
        return this.name;
    }

    public void addOptionValue(String string, String string2) {
        this.mapOptionValues.put(string, string2);
    }

    public void addOptionValues(ShaderProfile shaderProfile) {
        if (shaderProfile != null) {
            this.mapOptionValues.putAll(shaderProfile.mapOptionValues);
        }
    }

    public void applyOptionValues(ShaderOption[] shaderOptionArray) {
        for (int i = 0; i < shaderOptionArray.length; ++i) {
            ShaderOption shaderOption = shaderOptionArray[i];
            String string = shaderOption.getName();
            String string2 = this.mapOptionValues.get(string);
            if (string2 == null) continue;
            shaderOption.setValue(string2);
        }
    }

    public String[] getOptions() {
        Set<String> set = this.mapOptionValues.keySet();
        String[] stringArray = set.toArray(new String[set.size()]);
        return stringArray;
    }

    public String getValue(String string) {
        return this.mapOptionValues.get(string);
    }

    public void addDisabledProgram(String string) {
        this.disabledPrograms.add(string);
    }

    public Collection<String> getDisabledPrograms() {
        return new HashSet<String>(this.disabledPrograms);
    }

    public void addDisabledPrograms(Collection<String> collection) {
        this.disabledPrograms.addAll(collection);
    }

    public boolean isProgramDisabled(String string) {
        return this.disabledPrograms.contains(string);
    }
}
