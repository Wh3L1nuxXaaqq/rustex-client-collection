package shadersmod.client;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import optifine.Config;
import optifine.Lang;
import org.lwjgl.Sys;
import shadersmod.client.EnumShaderOption;
import shadersmod.client.GuiButtonEnumShaderOption;
import shadersmod.client.GuiShaderOptions;
import shadersmod.client.GuiSlotShaders;
import shadersmod.client.Shaders;
import shadersmod.client.ShadersTex;

public class GuiShaders
extends GuiScreen {
    protected GuiScreen parentGui;
    protected String screenTitle = "Shaders";
    private int updateTimer = -1;
    private GuiSlotShaders shaderList;
    private boolean saved = false;
    private static float[] QUALITY_MULTIPLIERS = new float[]{0.5f, 0.70710677f, 1.0f, 1.4142135f, 2.0f};
    private static String[] QUALITY_MULTIPLIER_NAMES = new String[]{"0.5x", "0.7x", "1x", "1.5x", "2x"};
    private static float[] HAND_DEPTH_VALUES = new float[]{0.0625f, 0.125f, 0.25f};
    private static String[] HAND_DEPTH_NAMES = new String[]{"0.5x", "1x", "2x"};
    public static final int EnumOS_UNKNOWN = 0;
    public static final int EnumOS_WINDOWS = 1;
    public static final int EnumOS_OSX = 2;
    public static final int EnumOS_SOLARIS = 3;
    public static final int EnumOS_LINUX = 4;

    public GuiShaders(GuiScreen guiScreen, GameSettings gameSettings) {
        this.parentGui = guiScreen;
    }

    @Override
    public void initGui() {
        this.screenTitle = I18n.format("of.options.shadersTitle", new Object[0]);
        if (Shaders.shadersConfig == null) {
            Shaders.loadConfig();
        }
        int n = 120;
        int n2 = 20;
        int n3 = this.width - n - 10;
        int n4 = 30;
        int n5 = 20;
        int n6 = this.width - n - 20;
        this.shaderList = new GuiSlotShaders(this, n6, this.height, n4, this.height - 50, 16);
        this.shaderList.registerScrollButtons(7, 8);
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.ANTIALIASING, n3, 0 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.NORMAL_MAP, n3, 1 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.SPECULAR_MAP, n3, 2 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.RENDER_RES_MUL, n3, 3 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.SHADOW_RES_MUL, n3, 4 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.HAND_DEPTH_MUL, n3, 5 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.OLD_HAND_LIGHT, n3, 6 * n5 + n4, n, n2));
        this.buttonList.add(new GuiButtonEnumShaderOption(EnumShaderOption.OLD_LIGHTING, n3, 7 * n5 + n4, n, n2));
        int n7 = Math.min(150, n6 / 2 - 10);
        this.buttonList.add(new GuiButton(201, n6 / 4 - n7 / 2, this.height - 25, n7, n2, Lang.get("of.options.shaders.shadersFolder")));
        this.buttonList.add(new GuiButton(202, n6 / 4 * 3 - n7 / 2, this.height - 25, n7, n2, I18n.format("gui.done", new Object[0])));
        this.buttonList.add(new GuiButton(203, n3, this.height - 25, n, n2, Lang.get("of.options.shaders.shaderOptions")));
        this.updateButtons();
    }

    public void updateButtons() {
        boolean bl = Config.isShaders();
        for (GuiButton guiButton : this.buttonList) {
            if (guiButton.id == 201 || guiButton.id == 202 || guiButton.id == EnumShaderOption.ANTIALIASING.ordinal()) continue;
            guiButton.enabled = bl;
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        this.shaderList.handleMouseInput();
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) {
        if (guiButton.enabled) {
            if (guiButton instanceof GuiButtonEnumShaderOption) {
                GuiButtonEnumShaderOption guiButtonEnumShaderOption = (GuiButtonEnumShaderOption)guiButton;
                switch (guiButtonEnumShaderOption.getEnumShaderOption()) {
                    case ANTIALIASING: {
                        Shaders.nextAntialiasingLevel();
                        Shaders.uninit();
                        break;
                    }
                    case NORMAL_MAP: {
                        Shaders.configNormalMap = !Shaders.configNormalMap;
                        Shaders.uninit();
                        mc.scheduleResourcesRefresh();
                        break;
                    }
                    case SPECULAR_MAP: {
                        Shaders.configSpecularMap = !Shaders.configSpecularMap;
                        Shaders.uninit();
                        mc.scheduleResourcesRefresh();
                        break;
                    }
                    case RENDER_RES_MUL: {
                        float f = Shaders.configRenderResMul;
                        float[] fArray = QUALITY_MULTIPLIERS;
                        String[] stringArray = QUALITY_MULTIPLIER_NAMES;
                        int n = GuiShaders.getValueIndex(f, fArray);
                        if (GuiShaders.isShiftKeyDown()) {
                            if (--n < 0) {
                                n = fArray.length - 1;
                            }
                        } else if (++n >= fArray.length) {
                            n = 0;
                        }
                        Shaders.configRenderResMul = fArray[n];
                        Shaders.uninit();
                        Shaders.scheduleResize();
                        break;
                    }
                    case SHADOW_RES_MUL: {
                        float f = Shaders.configShadowResMul;
                        float[] fArray = QUALITY_MULTIPLIERS;
                        String[] stringArray = QUALITY_MULTIPLIER_NAMES;
                        int n = GuiShaders.getValueIndex(f, fArray);
                        if (GuiShaders.isShiftKeyDown()) {
                            if (--n < 0) {
                                n = fArray.length - 1;
                            }
                        } else if (++n >= fArray.length) {
                            n = 0;
                        }
                        Shaders.configShadowResMul = fArray[n];
                        Shaders.uninit();
                        Shaders.scheduleResizeShadow();
                        break;
                    }
                    case HAND_DEPTH_MUL: {
                        float f = Shaders.configHandDepthMul;
                        float[] fArray = HAND_DEPTH_VALUES;
                        String[] stringArray = HAND_DEPTH_NAMES;
                        int n = GuiShaders.getValueIndex(f, fArray);
                        if (GuiShaders.isShiftKeyDown()) {
                            if (--n < 0) {
                                n = fArray.length - 1;
                            }
                        } else if (++n >= fArray.length) {
                            n = 0;
                        }
                        Shaders.configHandDepthMul = fArray[n];
                        Shaders.uninit();
                        break;
                    }
                    case OLD_HAND_LIGHT: {
                        Shaders.configOldHandLight.nextValue();
                        Shaders.uninit();
                        break;
                    }
                    case OLD_LIGHTING: {
                        Shaders.configOldLighting.nextValue();
                        Shaders.updateBlockLightLevel();
                        Shaders.uninit();
                        mc.scheduleResourcesRefresh();
                        break;
                    }
                    case TWEAK_BLOCK_DAMAGE: {
                        Shaders.configTweakBlockDamage = !Shaders.configTweakBlockDamage;
                        break;
                    }
                    case CLOUD_SHADOW: {
                        Shaders.configCloudShadow = !Shaders.configCloudShadow;
                        break;
                    }
                    case TEX_MIN_FIL_B: {
                        Shaders.configTexMinFilN = Shaders.configTexMinFilS = (Shaders.configTexMinFilB = (Shaders.configTexMinFilB + 1) % 3);
                        guiButton.displayString = "Tex Min: " + Shaders.texMinFilDesc[Shaders.configTexMinFilB];
                        ShadersTex.updateTextureMinMagFilter();
                        break;
                    }
                    case TEX_MAG_FIL_N: {
                        Shaders.configTexMagFilN = (Shaders.configTexMagFilN + 1) % 2;
                        guiButton.displayString = "Tex_n Mag: " + Shaders.texMagFilDesc[Shaders.configTexMagFilN];
                        ShadersTex.updateTextureMinMagFilter();
                        break;
                    }
                    case TEX_MAG_FIL_S: {
                        Shaders.configTexMagFilS = (Shaders.configTexMagFilS + 1) % 2;
                        guiButton.displayString = "Tex_s Mag: " + Shaders.texMagFilDesc[Shaders.configTexMagFilS];
                        ShadersTex.updateTextureMinMagFilter();
                        break;
                    }
                    case SHADOW_CLIP_FRUSTRUM: {
                        Shaders.configShadowClipFrustrum = !Shaders.configShadowClipFrustrum;
                        guiButton.displayString = "ShadowClipFrustrum: " + GuiShaders.toStringOnOff(Shaders.configShadowClipFrustrum);
                        ShadersTex.updateTextureMinMagFilter();
                    }
                }
                guiButtonEnumShaderOption.updateButtonText();
            } else {
                switch (guiButton.id) {
                    case 201: {
                        switch (GuiShaders.getOSType()) {
                            case 1: {
                                String string = String.format("cmd.exe /C start \"Open file\" \"%s\"", Shaders.shaderpacksdir.getAbsolutePath());
                                try {
                                    Runtime.getRuntime().exec(string);
                                    return;
                                }
                                catch (IOException iOException) {
                                    iOException.printStackTrace();
                                    break;
                                }
                            }
                            case 2: {
                                try {
                                    Runtime.getRuntime().exec(new String[]{"/usr/bin/open", Shaders.shaderpacksdir.getAbsolutePath()});
                                    return;
                                }
                                catch (IOException iOException) {
                                    iOException.printStackTrace();
                                }
                            }
                        }
                        boolean bl = false;
                        try {
                            Class<?> clazz = Class.forName("java.awt.Desktop");
                            Object object = clazz.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
                            Object[] objectArray = new Object[1];
                            objectArray[0] = new File(GuiShaders.mc.mcDataDir, Shaders.shaderpacksdirname).toURI();
                            clazz.getMethod("browse", URI.class).invoke(object, objectArray);
                        }
                        catch (Throwable throwable) {
                            throwable.printStackTrace();
                            bl = true;
                        }
                        if (!bl) break;
                        Config.dbg("Opening via system class!");
                        Sys.openURL((String)("file://" + Shaders.shaderpacksdir.getAbsolutePath()));
                        break;
                    }
                    case 202: {
                        new File(Shaders.shadersdir, "current.cfg");
                        Shaders.storeConfig();
                        this.saved = true;
                        mc.displayGuiScreen(this.parentGui);
                        break;
                    }
                    case 203: {
                        GuiShaderOptions guiShaderOptions = new GuiShaderOptions(this, Config.getGameSettings());
                        Config.getMinecraft().displayGuiScreen(guiShaderOptions);
                        break;
                    }
                    default: {
                        this.shaderList.actionPerformed(guiButton);
                    }
                }
            }
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        if (!this.saved) {
            Shaders.storeConfig();
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        this.shaderList.drawScreen(n, n2, f);
        if (this.updateTimer <= 0) {
            this.shaderList.updateList();
            this.updateTimer += 20;
        }
        this.drawCenteredString(this.fontRendererObj, this.screenTitle + " ", this.width / 2, 15, 0xFFFFFF);
        String string = "OpenGL: " + Shaders.glVersionString + ", " + Shaders.glVendorString + ", " + Shaders.glRendererString;
        int n3 = this.fontRendererObj.getStringWidth(string);
        if (n3 < this.width - 5) {
            this.drawCenteredString(this.fontRendererObj, string, this.width / 2, this.height - 40, 0x808080);
        } else {
            this.drawString(this.fontRendererObj, string, 5, this.height - 40, 0x808080);
        }
        super.drawScreen(n, n2, f);
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        --this.updateTimer;
    }

    public Minecraft getMc() {
        return mc;
    }

    public void drawCenteredString(String string, int n, int n2, int n3) {
        this.drawCenteredString(this.fontRendererObj, string, n, n2, n3);
    }

    public static String toStringOnOff(boolean bl) {
        String string = Lang.getOn();
        String string2 = Lang.getOff();
        return bl ? string : string2;
    }

    public static String toStringAa(int n) {
        if (n == 2) {
            return "FXAA 2x";
        }
        return n == 4 ? "FXAA 4x" : Lang.getOff();
    }

    public static String toStringValue(float f, float[] fArray, String[] stringArray) {
        int n = GuiShaders.getValueIndex(f, fArray);
        return stringArray[n];
    }

    public static int getValueIndex(float f, float[] fArray) {
        for (int i = 0; i < fArray.length; ++i) {
            float f2 = fArray[i];
            if (!(f2 >= f)) continue;
            return i;
        }
        return fArray.length - 1;
    }

    public static String toStringQuality(float f) {
        return GuiShaders.toStringValue(f, QUALITY_MULTIPLIERS, QUALITY_MULTIPLIER_NAMES);
    }

    public static String toStringHandDepth(float f) {
        return GuiShaders.toStringValue(f, HAND_DEPTH_VALUES, HAND_DEPTH_NAMES);
    }

    public static int getOSType() {
        String string = System.getProperty("os.name").toLowerCase();
        if (string.contains("win")) {
            return 1;
        }
        if (string.contains("mac")) {
            return 2;
        }
        if (string.contains("solaris")) {
            return 3;
        }
        if (string.contains("sunos")) {
            return 3;
        }
        if (string.contains("linux")) {
            return 4;
        }
        return string.contains("unix") ? 4 : 0;
    }
}
