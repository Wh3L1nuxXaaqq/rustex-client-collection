package shadersmod.client;

import java.util.ArrayList;
import net.minecraft.client.gui.GuiSlot;
import optifine.Lang;
import shadersmod.client.GuiShaders;
import shadersmod.client.Shaders;

class GuiSlotShaders
extends GuiSlot {
    private ArrayList shaderslist;
    private int selectedIndex;
    private long lastClickedCached = 0L;
    final GuiShaders shadersGui;

    public GuiSlotShaders(GuiShaders guiShaders, int n, int n2, int n3, int n4, int n5) {
        super(guiShaders.getMc(), n, n2, n3, n4, n5);
        this.shadersGui = guiShaders;
        this.updateList();
        this.amountScrolled = 0.0f;
        int n6 = this.selectedIndex * n5;
        int n7 = (n4 - n3) / 2;
        if (n6 > n7) {
            this.scrollBy(n6 - n7);
        }
    }

    @Override
    public int getListWidth() {
        return this.width - 20;
    }

    public void updateList() {
        this.shaderslist = Shaders.listOfShaders();
        this.selectedIndex = 0;
        int n = this.shaderslist.size();
        for (int i = 0; i < n; ++i) {
            if (!((String)this.shaderslist.get(i)).equals(Shaders.currentshadername)) continue;
            this.selectedIndex = i;
            break;
        }
    }

    @Override
    protected int getSize() {
        return this.shaderslist.size();
    }

    @Override
    protected void elementClicked(int n, boolean bl, int n2, int n3) {
        if (n != this.selectedIndex || this.lastClicked != this.lastClickedCached) {
            this.selectedIndex = n;
            this.lastClickedCached = this.lastClicked;
            Shaders.setShaderPack((String)this.shaderslist.get(n));
            Shaders.uninit();
            this.shadersGui.updateButtons();
        }
    }

    @Override
    protected boolean isSelected(int n) {
        return n == this.selectedIndex;
    }

    @Override
    protected int getScrollBarX() {
        return this.width - 6;
    }

    @Override
    protected int getContentHeight() {
        return this.getSize() * 18;
    }

    @Override
    protected void drawBackground() {
    }

    @Override
    protected void func_192637_a(int n, int n2, int n3, int n4, int n5, int n6, float f) {
        String string = (String)this.shaderslist.get(n);
        if (string.equals(Shaders.packNameNone)) {
            string = Lang.get("of.options.shaders.packNone");
        } else if (string.equals(Shaders.packNameDefault)) {
            string = Lang.get("of.options.shaders.packDefault");
        }
        this.shadersGui.drawCenteredString(string, this.width / 2, n3 + 1, 0xFFFFFF);
    }

    public int getSelectedIndex() {
        return this.selectedIndex;
    }
}
