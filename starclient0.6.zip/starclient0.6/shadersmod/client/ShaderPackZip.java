package shadersmod.client;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import optifine.StrUtils;
import shadersmod.client.IShaderPack;

public class ShaderPackZip
implements IShaderPack {
    protected File packFile;
    protected ZipFile packZipFile;

    public ShaderPackZip(String string, File file) {
        this.packFile = file;
        this.packZipFile = null;
    }

    @Override
    public void close() {
        if (this.packZipFile != null) {
            try {
                this.packZipFile.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
            this.packZipFile = null;
        }
    }

    @Override
    public InputStream getResourceAsStream(String string) {
        try {
            String string2;
            ZipEntry zipEntry;
            if (this.packZipFile == null) {
                this.packZipFile = new ZipFile(this.packFile);
            }
            return (zipEntry = this.packZipFile.getEntry(string2 = StrUtils.removePrefix(string, "/"))) == null ? null : this.packZipFile.getInputStream(zipEntry);
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public boolean hasDirectory(String string) {
        try {
            String string2;
            ZipEntry zipEntry;
            if (this.packZipFile == null) {
                this.packZipFile = new ZipFile(this.packFile);
            }
            return (zipEntry = this.packZipFile.getEntry(string2 = StrUtils.removePrefix(string, "/"))) != null;
        }
        catch (IOException iOException) {
            return false;
        }
    }

    @Override
    public String getName() {
        return this.packFile.getName();
    }
}
