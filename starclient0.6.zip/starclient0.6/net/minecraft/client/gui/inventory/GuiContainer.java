package net.minecraft.client.gui.inventory;

import com.google.common.collect.Sets;
import java.awt.Color;
import java.io.IOException;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.impl.player.ItemScroller;
import starclient.alpha.utility.math.TimerUtility;
import starclient.alpha.utility.misc.TimerHelper;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

public abstract class GuiContainer
extends GuiScreen {
    public static final ResourceLocation INVENTORY_BACKGROUND = new ResourceLocation("textures/gui/container/inventory.png");
    protected int xSize = 176;
    protected int ySize = 166;
    public Container inventorySlots;
    protected int guiLeft;
    protected int guiTop;
    private Slot theSlot;
    private Slot clickedSlot;
    private boolean isRightMouseClick;
    private ItemStack draggedStack = ItemStack.field_190927_a;
    private int touchUpX;
    private int touchUpY;
    private Slot returningStackDestSlot;
    private long returningStackTime;
    private ItemStack returningStack = ItemStack.field_190927_a;
    private Slot currentDragTargetSlot;
    private long dragItemDropDelay;
    protected final Set<Slot> dragSplittingSlots = Sets.newHashSet();
    protected boolean dragSplitting;
    private int dragSplittingLimit;
    private int dragSplittingButton;
    private boolean ignoreMouseUp;
    private int dragSplittingRemnant;
    private long lastClickTime;
    private Slot lastClickSlot;
    private int lastClickButton;
    private boolean doubleClick;
    private ItemStack shiftClickedSlot = ItemStack.field_190927_a;
    private final TimerHelper timer;

    public GuiContainer(Container container) {
        this.inventorySlots = container;
        this.ignoreMouseUp = true;
        this.timer = new TimerHelper();
    }

    @Override
    public void initGui() {
        super.initGui();
        GuiContainer.mc.player.openContainer = this.inventorySlots;
        this.guiLeft = (this.width - this.xSize) / 2;
        this.guiTop = (this.height - this.ySize) / 2;
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        int n3;
        int n4;
        Object object;
        int n5 = StarClient.getInstance().getC(0).getRGB();
        int n6 = StarClient.getInstance().getC(500).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        int n7 = bl ? new Color(255, 255, 255).getRGB() : new Color(44, 44, 44).getRGB();
        int n8 = bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB();
        int n9 = new ScaledResolution(mc).getScaledWidth();
        int n10 = new ScaledResolution(mc).getScaledHeight();
        RenderUtility.drawGradientGlow((float)(n9 / 2 - (Fonts.mntsb16.getStringWidth("Drop items") / 2 + 3)), (float)(n10 / 2 - 150), (float)(Fonts.mntsb16.getStringWidth("Drop items") + 5), 15.0f, 5, n5, n6, n5, n6);
        RenderUtility.drawRoundedRect(n9 / 2 - (Fonts.mntsb16.getStringWidth("Drop items") / 2 + 3), n10 / 2 - 150, Fonts.mntsb16.getStringWidth("Drop items") + 5, 15.0f, 5.0f, n8);
        Fonts.mntsb16.drawCenteredString("Drop items", n9 / 2, n10 / 2 - 145, n7);
        int n11 = this.guiLeft;
        int n12 = this.guiTop;
        this.drawGuiContainerBackgroundLayer(f, n, n2);
        GlStateManager.disableRescaleNormal();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        super.drawScreen(n, n2, f);
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.pushMatrix();
        GlStateManager.translate(n11, n12, 0.0f);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.enableRescaleNormal();
        this.theSlot = null;
        int n13 = 240;
        int n14 = 240;
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0f, 240.0f);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        for (int i = 0; i < this.inventorySlots.inventorySlots.size(); ++i) {
            object = this.inventorySlots.inventorySlots.get(i);
            if (((Slot)object).canBeHovered()) {
                this.drawSlot((Slot)object);
            }
            if (!this.isMouseOverSlot((Slot)object, n, n2) || !((Slot)object).canBeHovered()) continue;
            if (StarClient.getInstance().getModuleManager().getModule(ItemScroller.class).isEnabled() && Mouse.isButtonDown((int)0)) {
                if (Keyboard.isKeyDown((int)GuiContainer.mc.gameSettings.keyBindSneak.getKeyCode()) && this.timer.hasReached(ItemScroller.delay.get()) && ((Slot)object).getStack().getItem() != Items.DIAMOND_AXE) {
                    this.handleMouseClick((Slot)object, ((Slot)object).slotNumber, 0, ClickType.QUICK_MOVE);
                    this.timer.reset();
                }
            }
            this.theSlot = object;
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            n4 = ((Slot)object).xDisplayPosition;
            n3 = ((Slot)object).yDisplayPosition;
            GlStateManager.colorMask(true, true, true, false);
            this.drawGradientRect(n4, n3, n4 + 16, n3 + 16, -2130706433, -2130706433);
            GlStateManager.colorMask(true, true, true, true);
            GlStateManager.enableLighting();
            GlStateManager.enableDepth();
        }
        RenderHelper.disableStandardItemLighting();
        this.drawGuiContainerForegroundLayer(n, n2);
        RenderHelper.enableGUIStandardItemLighting();
        InventoryPlayer inventoryPlayer = GuiContainer.mc.player.inventory;
        Object object2 = object = this.draggedStack.func_190926_b() ? inventoryPlayer.getItemStack() : this.draggedStack;
        if (!((ItemStack)object).func_190926_b()) {
            n4 = 8;
            n3 = this.draggedStack.func_190926_b() ? 8 : 16;
            String string = null;
            if (!this.draggedStack.func_190926_b() && this.isRightMouseClick) {
                object = ((ItemStack)object).copy();
                ((ItemStack)object).func_190920_e(MathHelper.ceil((float)((ItemStack)object).func_190916_E() / 2.0f));
            } else if (this.dragSplitting && this.dragSplittingSlots.size() > 1) {
                object = ((ItemStack)object).copy();
                ((ItemStack)object).func_190920_e(this.dragSplittingRemnant);
                if (((ItemStack)object).func_190926_b()) {
                    string = String.valueOf((Object)TextFormatting.YELLOW) + "0";
                }
            }
            this.drawItemStack((ItemStack)object, n - n11 - 8, n2 - n12 - n3, string);
        }
        if (!this.returningStack.func_190926_b()) {
            float f2 = (float)(Minecraft.getSystemTime() - this.returningStackTime) / 100.0f;
            if (f2 >= 1.0f) {
                f2 = 1.0f;
                this.returningStack = ItemStack.field_190927_a;
            }
            n3 = this.returningStackDestSlot.xDisplayPosition - this.touchUpX;
            int n15 = this.returningStackDestSlot.yDisplayPosition - this.touchUpY;
            int n16 = this.touchUpX + (int)((float)n3 * f2);
            int n17 = this.touchUpY + (int)((float)n15 * f2);
            this.drawItemStack(this.returningStack, n16, n17, null);
        }
        GlStateManager.popMatrix();
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
        RenderHelper.enableStandardItemLighting();
    }

    protected void func_191948_b(int n, int n2) {
        if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b() && this.theSlot != null && this.theSlot.getHasStack()) {
            this.renderToolTip(this.theSlot.getStack(), n, n2);
        }
    }

    private void drawItemStack(ItemStack itemStack, int n, int n2, String string) {
        GlStateManager.translate(0.0f, 0.0f, 32.0f);
        this.zLevel = 200.0f;
        this.itemRender.zLevel = 200.0f;
        this.itemRender.renderItemAndEffectIntoGUI(itemStack, n, n2);
        this.itemRender.renderItemOverlayIntoGUI(this.fontRendererObj, itemStack, n, n2 - (this.draggedStack.func_190926_b() ? 0 : 8), string);
        this.zLevel = 0.0f;
        this.itemRender.zLevel = 0.0f;
    }

    protected void drawGuiContainerForegroundLayer(int n, int n2) {
    }

    protected abstract void drawGuiContainerBackgroundLayer(float var1, int var2, int var3);

    private void drawSlot(Slot slot) {
        String string;
        int n = slot.xDisplayPosition;
        int n2 = slot.yDisplayPosition;
        ItemStack itemStack = slot.getStack();
        boolean bl = false;
        boolean bl2 = slot == this.clickedSlot && !this.draggedStack.func_190926_b() && !this.isRightMouseClick;
        ItemStack itemStack2 = GuiContainer.mc.player.inventory.getItemStack();
        String string2 = null;
        if (slot == this.clickedSlot && !this.draggedStack.func_190926_b() && this.isRightMouseClick && !itemStack.func_190926_b()) {
            itemStack = itemStack.copy();
            itemStack.func_190920_e(itemStack.func_190916_E() / 2);
        } else if (this.dragSplitting && this.dragSplittingSlots.contains(slot) && !itemStack2.func_190926_b()) {
            if (this.dragSplittingSlots.size() == 1) {
                return;
            }
            if (Container.canAddItemToSlot(slot, itemStack2, true) && this.inventorySlots.canDragIntoSlot(slot)) {
                itemStack = itemStack2.copy();
                bl = true;
                Container.computeStackSize(this.dragSplittingSlots, this.dragSplittingLimit, itemStack, slot.getStack().func_190926_b() ? 0 : slot.getStack().func_190916_E());
                int n3 = Math.min(itemStack.getMaxStackSize(), slot.getItemStackLimit(itemStack));
                if (itemStack.func_190916_E() > n3) {
                    string2 = TextFormatting.YELLOW.toString() + n3;
                    itemStack.func_190920_e(n3);
                }
            } else {
                this.dragSplittingSlots.remove(slot);
                this.updateDragSplitting();
            }
        }
        this.zLevel = 100.0f;
        this.itemRender.zLevel = 100.0f;
        if (itemStack.func_190926_b() && slot.canBeHovered() && (string = slot.getSlotTexture()) != null) {
            TextureAtlasSprite textureAtlasSprite = mc.getTextureMapBlocks().getAtlasSprite(string);
            GlStateManager.disableLighting();
            mc.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
            this.drawTexturedModalRect(n, n2, textureAtlasSprite, 16, 16);
            GlStateManager.enableLighting();
            bl2 = true;
        }
        if (!bl2) {
            if (bl) {
                GuiContainer.drawRect(n, n2, n + 16, n2 + 16, -2130706433);
            }
            GlStateManager.enableDepth();
            this.itemRender.renderItemAndEffectIntoGUI(GuiContainer.mc.player, itemStack, n, n2);
            this.itemRender.renderItemOverlayIntoGUI(this.fontRendererObj, itemStack, n, n2, string2);
        }
        this.itemRender.zLevel = 0.0f;
        this.zLevel = 0.0f;
    }

    private void updateDragSplitting() {
        ItemStack itemStack = GuiContainer.mc.player.inventory.getItemStack();
        if (!itemStack.func_190926_b() && this.dragSplitting) {
            if (this.dragSplittingLimit == 2) {
                this.dragSplittingRemnant = itemStack.getMaxStackSize();
            } else {
                this.dragSplittingRemnant = itemStack.func_190916_E();
                for (Slot slot : this.dragSplittingSlots) {
                    ItemStack itemStack2 = itemStack.copy();
                    ItemStack itemStack3 = slot.getStack();
                    int n = itemStack3.func_190926_b() ? 0 : itemStack3.func_190916_E();
                    Container.computeStackSize(this.dragSplittingSlots, this.dragSplittingLimit, itemStack2, n);
                    int n2 = Math.min(itemStack2.getMaxStackSize(), slot.getItemStackLimit(itemStack2));
                    if (itemStack2.func_190916_E() > n2) {
                        itemStack2.func_190920_e(n2);
                    }
                    this.dragSplittingRemnant -= itemStack2.func_190916_E() - n;
                }
            }
        }
    }

    private Slot getSlotAtPosition(int n, int n2) {
        for (int i = 0; i < this.inventorySlots.inventorySlots.size(); ++i) {
            Slot slot = this.inventorySlots.inventorySlots.get(i);
            if (!this.isMouseOverSlot(slot, n, n2) || !slot.canBeHovered()) continue;
            return slot;
        }
        return null;
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        super.mouseClicked(n, n2, n3);
        boolean bl = n3 == GuiContainer.mc.gameSettings.keyBindPickBlock.getKeyCode() + 100;
        Slot slot = this.getSlotAtPosition(n, n2);
        long l = Minecraft.getSystemTime();
        this.doubleClick = this.lastClickSlot == slot && l - this.lastClickTime < 250L && this.lastClickButton == n3;
        this.ignoreMouseUp = false;
        int n4 = new ScaledResolution(mc).getScaledWidth();
        int n5 = new ScaledResolution(mc).getScaledHeight();
        if (n3 == 0 || n3 == 1 || bl) {
            int n6;
            if (RenderUtility.isHovered(n, n2, n4 / 2 - (Fonts.mntsb16.getStringWidth("Drop items") / 2 + 3), n5 / 2 - 150, Fonts.mntsb16.getStringWidth("Drop items") + 5, 15.0f)) {
                System.out.println("Clicked");
                TimerUtility timerUtility = new TimerUtility();
                for (n6 = 0; n6 < GuiContainer.mc.player.openContainer.inventorySlots.size(); ++n6) {
                    Slot slot2 = GuiContainer.mc.player.openContainer.inventorySlots.get(n6);
                    if (slot2.getStack().getItem() == Items.DIAMOND_HOE || slot2.getStack().getItem() == Items.field_190931_a) continue;
                    timerUtility.hasReached(2500.0);
                    GuiContainer.mc.playerController.windowClick(GuiContainer.mc.player.openContainer.windowId, slot2.slotNumber, 1, ClickType.THROW, GuiContainer.mc.player);
                    timerUtility.reset();
                }
            }
            int n7 = this.guiLeft;
            n6 = this.guiTop;
            boolean bl2 = this.func_193983_c(n, n2, n7, n6);
            int n8 = -1;
            if (slot != null) {
                n8 = slot.slotNumber;
            }
            if (bl2) {
                n8 = -999;
            }
            if (GuiContainer.mc.gameSettings.touchscreen && bl2) {
                if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b()) {
                    mc.displayGuiScreen(null);
                    return;
                }
            }
            if (n8 != -1) {
                if (GuiContainer.mc.gameSettings.touchscreen) {
                    if (slot != null && slot.getHasStack()) {
                        this.clickedSlot = slot;
                        this.draggedStack = ItemStack.field_190927_a;
                        this.isRightMouseClick = n3 == 1;
                    } else {
                        this.clickedSlot = null;
                    }
                } else if (!this.dragSplitting) {
                    if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b()) {
                        if (n3 == GuiContainer.mc.gameSettings.keyBindPickBlock.getKeyCode() + 100) {
                            this.handleMouseClick(slot, n8, n3, ClickType.CLONE);
                        } else {
                            boolean bl3 = n8 != -999 && (Keyboard.isKeyDown((int)42) || Keyboard.isKeyDown((int)54));
                            ClickType clickType = ClickType.PICKUP;
                            if (bl3) {
                                this.shiftClickedSlot = slot != null && slot.getHasStack() ? slot.getStack().copy() : ItemStack.field_190927_a;
                                clickType = ClickType.QUICK_MOVE;
                            } else if (n8 == -999) {
                                clickType = ClickType.THROW;
                            }
                            this.handleMouseClick(slot, n8, n3, clickType);
                        }
                        this.ignoreMouseUp = true;
                    } else {
                        this.dragSplitting = true;
                        this.dragSplittingButton = n3;
                        this.dragSplittingSlots.clear();
                        if (n3 == 0) {
                            this.dragSplittingLimit = 0;
                        } else if (n3 == 1) {
                            this.dragSplittingLimit = 1;
                        } else if (n3 == GuiContainer.mc.gameSettings.keyBindPickBlock.getKeyCode() + 100) {
                            this.dragSplittingLimit = 2;
                        }
                    }
                }
            }
        }
        this.lastClickSlot = slot;
        this.lastClickTime = l;
        this.lastClickButton = n3;
    }

    protected boolean func_193983_c(int n, int n2, int n3, int n4) {
        return n < n3 || n2 < n4 || n >= n3 + this.xSize || n2 >= n4 + this.ySize;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void mouseClickMove(int n, int n2, int n3, long l) {
        Slot slot = this.getSlotAtPosition(n, n2);
        ItemStack itemStack = GuiContainer.mc.player.inventory.getItemStack();
        if (this.clickedSlot != null) {
            if (GuiContainer.mc.gameSettings.touchscreen) {
                if (n3 != 0) {
                    if (n3 != 1) return;
                }
                if (this.draggedStack.func_190926_b()) {
                    if (slot == this.clickedSlot) return;
                    if (this.clickedSlot.getStack().func_190926_b()) return;
                    this.draggedStack = this.clickedSlot.getStack().copy();
                    return;
                }
                if (this.draggedStack.func_190916_E() <= 1) return;
                if (slot == null) return;
                if (!Container.canAddItemToSlot(slot, this.draggedStack, false)) return;
                long l2 = Minecraft.getSystemTime();
                if (this.currentDragTargetSlot == slot) {
                    if (l2 - this.dragItemDropDelay <= 500L) return;
                    this.handleMouseClick(this.clickedSlot, this.clickedSlot.slotNumber, 0, ClickType.PICKUP);
                    this.handleMouseClick(slot, slot.slotNumber, 1, ClickType.PICKUP);
                    this.handleMouseClick(this.clickedSlot, this.clickedSlot.slotNumber, 0, ClickType.PICKUP);
                    this.dragItemDropDelay = l2 + 750L;
                    this.draggedStack.func_190918_g(1);
                    return;
                }
                this.currentDragTargetSlot = slot;
                this.dragItemDropDelay = l2;
                return;
            }
        }
        if (!this.dragSplitting) return;
        if (slot == null) return;
        if (itemStack.func_190926_b()) return;
        if (itemStack.func_190916_E() <= this.dragSplittingSlots.size()) {
            if (this.dragSplittingLimit != 2) return;
        }
        if (!Container.canAddItemToSlot(slot, itemStack, true)) return;
        if (!slot.isItemValid(itemStack)) return;
        if (!this.inventorySlots.canDragIntoSlot(slot)) return;
        this.dragSplittingSlots.add(slot);
        this.updateDragSplitting();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void mouseReleased(int n, int n2, int n3) {
        block25: {
            int n4;
            Slot slot;
            block26: {
                int n5;
                int n6;
                block24: {
                    slot = this.getSlotAtPosition(n, n2);
                    n6 = this.guiLeft;
                    n5 = this.guiTop;
                    boolean bl = this.func_193983_c(n, n2, n6, n5);
                    n4 = -1;
                    if (slot != null) {
                        n4 = slot.slotNumber;
                    }
                    if (bl) {
                        n4 = -999;
                    }
                    if (!this.doubleClick || slot == null || n3 != 0 || !this.inventorySlots.canMergeSlot(ItemStack.field_190927_a, slot)) break block24;
                    if (GuiContainer.isShiftKeyDown()) {
                        if (!this.shiftClickedSlot.func_190926_b()) {
                            for (Slot slot2 : this.inventorySlots.inventorySlots) {
                                if (slot2 == null) continue;
                                if (!slot2.canTakeStack(GuiContainer.mc.player) || !slot2.getHasStack() || slot2.inventory != slot.inventory || !Container.canAddItemToSlot(slot2, this.shiftClickedSlot, true)) continue;
                                this.handleMouseClick(slot2, slot2.slotNumber, n3, ClickType.QUICK_MOVE);
                            }
                        }
                    } else {
                        this.handleMouseClick(slot, n4, n3, ClickType.PICKUP_ALL);
                    }
                    this.doubleClick = false;
                    this.lastClickTime = 0L;
                    break block25;
                }
                if (this.dragSplitting && this.dragSplittingButton != n3) {
                    this.dragSplitting = false;
                    this.dragSplittingSlots.clear();
                    this.ignoreMouseUp = true;
                    return;
                }
                if (this.ignoreMouseUp) {
                    this.ignoreMouseUp = false;
                    return;
                }
                if (this.clickedSlot == null) break block26;
                if (!GuiContainer.mc.gameSettings.touchscreen) break block26;
                if (n3 == 0 || n3 == 1) {
                    if (this.draggedStack.func_190926_b() && slot != this.clickedSlot) {
                        this.draggedStack = this.clickedSlot.getStack();
                    }
                    boolean bl = Container.canAddItemToSlot(slot, this.draggedStack, false);
                    if (n4 != -1 && !this.draggedStack.func_190926_b() && bl) {
                        this.handleMouseClick(this.clickedSlot, this.clickedSlot.slotNumber, n3, ClickType.PICKUP);
                        this.handleMouseClick(slot, n4, 0, ClickType.PICKUP);
                        if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b()) {
                            this.returningStack = ItemStack.field_190927_a;
                        } else {
                            this.handleMouseClick(this.clickedSlot, this.clickedSlot.slotNumber, n3, ClickType.PICKUP);
                            this.touchUpX = n - n6;
                            this.touchUpY = n2 - n5;
                            this.returningStackDestSlot = this.clickedSlot;
                            this.returningStack = this.draggedStack;
                            this.returningStackTime = Minecraft.getSystemTime();
                        }
                    } else if (!this.draggedStack.func_190926_b()) {
                        this.touchUpX = n - n6;
                        this.touchUpY = n2 - n5;
                        this.returningStackDestSlot = this.clickedSlot;
                        this.returningStack = this.draggedStack;
                        this.returningStackTime = Minecraft.getSystemTime();
                    }
                    this.draggedStack = ItemStack.field_190927_a;
                    this.clickedSlot = null;
                }
                break block25;
            }
            if (this.dragSplitting && !this.dragSplittingSlots.isEmpty()) {
                this.handleMouseClick(null, -999, Container.getQuickcraftMask(0, this.dragSplittingLimit), ClickType.QUICK_CRAFT);
                for (Slot slot3 : this.dragSplittingSlots) {
                    this.handleMouseClick(slot3, slot3.slotNumber, Container.getQuickcraftMask(1, this.dragSplittingLimit), ClickType.QUICK_CRAFT);
                }
                this.handleMouseClick(null, -999, Container.getQuickcraftMask(2, this.dragSplittingLimit), ClickType.QUICK_CRAFT);
            } else if (!GuiContainer.mc.player.inventory.getItemStack().func_190926_b()) {
                if (n3 == GuiContainer.mc.gameSettings.keyBindPickBlock.getKeyCode() + 100) {
                    this.handleMouseClick(slot, n4, n3, ClickType.CLONE);
                } else {
                    boolean bl;
                    boolean bl2 = bl = n4 != -999 && (Keyboard.isKeyDown((int)42) || Keyboard.isKeyDown((int)54));
                    if (bl) {
                        this.shiftClickedSlot = slot != null && slot.getHasStack() ? slot.getStack().copy() : ItemStack.field_190927_a;
                    }
                    this.handleMouseClick(slot, n4, n3, bl ? ClickType.QUICK_MOVE : ClickType.PICKUP);
                }
            }
        }
        if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b()) {
            this.lastClickTime = 0L;
        }
        this.dragSplitting = false;
    }

    private boolean isMouseOverSlot(Slot slot, int n, int n2) {
        return this.isPointInRegion(slot.xDisplayPosition, slot.yDisplayPosition, 16, 16, n, n2);
    }

    protected boolean isPointInRegion(int n, int n2, int n3, int n4, int n5, int n6) {
        int n7 = this.guiLeft;
        int n8 = this.guiTop;
        return (n5 -= n7) >= n - 1 && n5 < n + n3 + 1 && (n6 -= n8) >= n2 - 1 && n6 < n2 + n4 + 1;
    }

    protected void handleMouseClick(Slot slot, int n, int n2, ClickType clickType) {
        if (slot != null) {
            n = slot.slotNumber;
        }
        GuiContainer.mc.playerController.windowClick(this.inventorySlots.windowId, n, n2, clickType, GuiContainer.mc.player);
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        block8: {
            block7: {
                if (n == 1) break block7;
                if (n != GuiContainer.mc.gameSettings.keyBindInventory.getKeyCode()) break block8;
            }
            GuiContainer.mc.player.closeScreen();
        }
        this.checkHotbarKeys(n);
        if (this.theSlot != null && this.theSlot.getHasStack()) {
            if (n == GuiContainer.mc.gameSettings.keyBindPickBlock.getKeyCode()) {
                this.handleMouseClick(this.theSlot, this.theSlot.slotNumber, 0, ClickType.CLONE);
            } else if (n == GuiContainer.mc.gameSettings.keyBindDrop.getKeyCode()) {
                this.handleMouseClick(this.theSlot, this.theSlot.slotNumber, GuiContainer.isCtrlKeyDown() ? 1 : 0, ClickType.THROW);
            }
        }
    }

    protected boolean checkHotbarKeys(int n) {
        if (GuiContainer.mc.player.inventory.getItemStack().func_190926_b() && this.theSlot != null) {
            for (int i = 0; i < 9; ++i) {
                if (n != GuiContainer.mc.gameSettings.keyBindsHotbar[i].getKeyCode()) continue;
                this.handleMouseClick(this.theSlot, this.theSlot.slotNumber, i, ClickType.SWAP);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onGuiClosed() {
        if (GuiContainer.mc.player != null) {
            this.inventorySlots.onContainerClosed(GuiContainer.mc.player);
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        block3: {
            block2: {
                super.updateScreen();
                if (!GuiContainer.mc.player.isEntityAlive()) break block2;
                if (!GuiContainer.mc.player.isDead) break block3;
            }
            GuiContainer.mc.player.closeScreen();
        }
    }
}
