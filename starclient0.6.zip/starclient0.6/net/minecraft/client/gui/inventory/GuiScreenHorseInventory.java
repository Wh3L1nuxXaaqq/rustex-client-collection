package net.minecraft.client.gui.inventory;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.passive.AbstractChestHorse;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.inventory.ContainerHorseInventory;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.ResourceLocation;

public class GuiScreenHorseInventory
extends GuiContainer {
    private static final ResourceLocation HORSE_GUI_TEXTURES = new ResourceLocation("textures/gui/container/horse.png");
    private final IInventory playerInventory;
    private final IInventory horseInventory;
    private final AbstractHorse horseEntity;
    private float mousePosx;
    private float mousePosY;

    public GuiScreenHorseInventory(IInventory iInventory, IInventory iInventory2, AbstractHorse abstractHorse) {
        super(new ContainerHorseInventory(iInventory, iInventory2, abstractHorse, Minecraft.getMinecraft().player));
        this.playerInventory = iInventory;
        this.horseInventory = iInventory2;
        this.horseEntity = abstractHorse;
        this.allowUserInput = false;
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int n, int n2) {
        this.fontRendererObj.drawString(this.horseInventory.getDisplayName().getUnformattedText(), 8, 6, 0x404040);
        this.fontRendererObj.drawString(this.playerInventory.getDisplayName().getUnformattedText(), 8, this.ySize - 96 + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int n, int n2) {
        AbstractChestHorse abstractChestHorse;
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        mc.getTextureManager().bindTexture(HORSE_GUI_TEXTURES);
        int n3 = (this.width - this.xSize) / 2;
        int n4 = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(n3, n4, 0, 0, this.xSize, this.ySize);
        if (this.horseEntity instanceof AbstractChestHorse && (abstractChestHorse = (AbstractChestHorse)this.horseEntity).func_190695_dh()) {
            this.drawTexturedModalRect(n3 + 79, n4 + 17, 0, this.ySize, abstractChestHorse.func_190696_dl() * 18, 54);
        }
        if (this.horseEntity.func_190685_dA()) {
            this.drawTexturedModalRect(n3 + 7, n4 + 35 - 18, 18, this.ySize + 54, 18, 18);
        }
        if (this.horseEntity.func_190677_dK()) {
            if (this.horseEntity instanceof EntityLlama) {
                this.drawTexturedModalRect(n3 + 7, n4 + 35, 36, this.ySize + 54, 18, 18);
            } else {
                this.drawTexturedModalRect(n3 + 7, n4 + 35, 0, this.ySize + 54, 18, 18);
            }
        }
        GuiInventory.drawEntityOnScreen(n3 + 51, n4 + 60, 17, (float)(n3 + 51) - this.mousePosx, (float)(n4 + 75 - 50) - this.mousePosY, this.horseEntity);
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        this.mousePosx = n;
        this.mousePosY = n2;
        super.drawScreen(n, n2, f);
        this.func_191948_b(n, n2);
    }
}
