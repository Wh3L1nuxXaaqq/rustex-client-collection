package net.minecraft.client.gui.inventory;

import io.netty.buffer.Unpooled;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.potion.Potion;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GuiBeacon
extends GuiContainer {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ResourceLocation BEACON_GUI_TEXTURES = new ResourceLocation("textures/gui/container/beacon.png");
    private final IInventory tileBeacon;
    private ConfirmButton beaconConfirmButton;
    private boolean buttonsNotDrawn;

    public GuiBeacon(InventoryPlayer inventoryPlayer, IInventory iInventory) {
        super(new ContainerBeacon(inventoryPlayer, iInventory));
        this.tileBeacon = iInventory;
        this.xSize = 230;
        this.ySize = 219;
    }

    @Override
    public void initGui() {
        super.initGui();
        this.beaconConfirmButton = new ConfirmButton(-1, this.guiLeft + 164, this.guiTop + 107);
        this.buttonList.add(this.beaconConfirmButton);
        this.buttonList.add(new CancelButton(-2, this.guiLeft + 190, this.guiTop + 107));
        this.buttonsNotDrawn = true;
        this.beaconConfirmButton.enabled = false;
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        int n = this.tileBeacon.getField(0);
        Potion potion = Potion.getPotionById(this.tileBeacon.getField(1));
        Potion potion2 = Potion.getPotionById(this.tileBeacon.getField(2));
        if (this.buttonsNotDrawn && n >= 0) {
            PowerButton powerButton;
            Potion potion3;
            int n2;
            int n3;
            int n4;
            int n5;
            this.buttonsNotDrawn = false;
            int n6 = 100;
            for (n5 = 0; n5 <= 2; ++n5) {
                n4 = TileEntityBeacon.EFFECTS_LIST[n5].length;
                n3 = n4 * 22 + (n4 - 1) * 2;
                for (n2 = 0; n2 < n4; ++n2) {
                    potion3 = TileEntityBeacon.EFFECTS_LIST[n5][n2];
                    powerButton = new PowerButton(n6++, this.guiLeft + 76 + n2 * 24 - n3 / 2, this.guiTop + 22 + n5 * 25, potion3, n5);
                    this.buttonList.add(powerButton);
                    if (n5 >= n) {
                        powerButton.enabled = false;
                        continue;
                    }
                    if (potion3 != potion) continue;
                    powerButton.setSelected(true);
                }
            }
            n5 = 3;
            n4 = TileEntityBeacon.EFFECTS_LIST[3].length + 1;
            n3 = n4 * 22 + (n4 - 1) * 2;
            for (n2 = 0; n2 < n4 - 1; ++n2) {
                potion3 = TileEntityBeacon.EFFECTS_LIST[3][n2];
                powerButton = new PowerButton(n6++, this.guiLeft + 167 + n2 * 24 - n3 / 2, this.guiTop + 47, potion3, 3);
                this.buttonList.add(powerButton);
                if (3 >= n) {
                    powerButton.enabled = false;
                    continue;
                }
                if (potion3 != potion2) continue;
                powerButton.setSelected(true);
            }
            if (potion != null) {
                PowerButton powerButton2 = new PowerButton(n6++, this.guiLeft + 167 + (n4 - 1) * 24 - n3 / 2, this.guiTop + 47, potion, 3);
                this.buttonList.add(powerButton2);
                if (3 >= n) {
                    powerButton2.enabled = false;
                } else if (potion == potion2) {
                    powerButton2.setSelected(true);
                }
            }
        }
        this.beaconConfirmButton.enabled = !this.tileBeacon.getStackInSlot(0).func_190926_b() && potion != null;
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.id == -2) {
            GuiBeacon.mc.player.connection.sendPacket(new CPacketCloseWindow(GuiBeacon.mc.player.openContainer.windowId));
            mc.displayGuiScreen(null);
        } else if (guiButton.id == -1) {
            String string = "MC|Beacon";
            PacketBuffer packetBuffer = new PacketBuffer(Unpooled.buffer());
            packetBuffer.writeInt(this.tileBeacon.getField(1));
            packetBuffer.writeInt(this.tileBeacon.getField(2));
            mc.getConnection().sendPacket(new CPacketCustomPayload("MC|Beacon", packetBuffer));
            GuiBeacon.mc.player.connection.sendPacket(new CPacketCloseWindow(GuiBeacon.mc.player.openContainer.windowId));
            mc.displayGuiScreen(null);
        } else if (guiButton instanceof PowerButton) {
            PowerButton powerButton = (PowerButton)guiButton;
            if (powerButton.isSelected()) {
                return;
            }
            int n = Potion.getIdFromPotion(powerButton.effect);
            if (powerButton.tier < 3) {
                this.tileBeacon.setField(1, n);
            } else {
                this.tileBeacon.setField(2, n);
            }
            this.buttonList.clear();
            this.initGui();
            this.updateScreen();
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        super.drawScreen(n, n2, f);
        this.func_191948_b(n, n2);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int n, int n2) {
        RenderHelper.disableStandardItemLighting();
        this.drawCenteredString(this.fontRendererObj, I18n.format("tile.beacon.primary", new Object[0]), 62, 10, 0xE0E0E0);
        this.drawCenteredString(this.fontRendererObj, I18n.format("tile.beacon.secondary", new Object[0]), 169, 10, 0xE0E0E0);
        for (GuiButton guiButton : this.buttonList) {
            if (!guiButton.isMouseOver()) continue;
            guiButton.drawButtonForegroundLayer(n - this.guiLeft, n2 - this.guiTop);
            break;
        }
        RenderHelper.enableGUIStandardItemLighting();
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int n, int n2) {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        mc.getTextureManager().bindTexture(BEACON_GUI_TEXTURES);
        int n3 = (this.width - this.xSize) / 2;
        int n4 = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(n3, n4, 0, 0, this.xSize, this.ySize);
        this.itemRender.zLevel = 100.0f;
        this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.EMERALD), n3 + 42, n4 + 109);
        this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.DIAMOND), n3 + 42 + 22, n4 + 109);
        this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.GOLD_INGOT), n3 + 42 + 44, n4 + 109);
        this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.IRON_INGOT), n3 + 42 + 66, n4 + 109);
        this.itemRender.zLevel = 0.0f;
    }

    class ConfirmButton
    extends Button {
        public ConfirmButton(int n, int n2, int n3) {
            super(n, n2, n3, BEACON_GUI_TEXTURES, 90, 220);
        }

        @Override
        public void drawButtonForegroundLayer(int n, int n2) {
            GuiBeacon.this.drawCreativeTabHoveringText(I18n.format("gui.done", new Object[0]), n, n2);
        }
    }

    class CancelButton
    extends Button {
        public CancelButton(int n, int n2, int n3) {
            super(n, n2, n3, BEACON_GUI_TEXTURES, 112, 220);
        }

        @Override
        public void drawButtonForegroundLayer(int n, int n2) {
            GuiBeacon.this.drawCreativeTabHoveringText(I18n.format("gui.cancel", new Object[0]), n, n2);
        }
    }

    class PowerButton
    extends Button {
        private final Potion effect;
        private final int tier;

        public PowerButton(int n, int n2, int n3, Potion potion, int n4) {
            super(n, n2, n3, GuiContainer.INVENTORY_BACKGROUND, potion.getStatusIconIndex() % 8 * 18, 198 + potion.getStatusIconIndex() / 8 * 18);
            this.effect = potion;
            this.tier = n4;
        }

        @Override
        public void drawButtonForegroundLayer(int n, int n2) {
            Object object = I18n.format(this.effect.getName(), new Object[0]);
            if (this.tier >= 3 && this.effect != MobEffects.REGENERATION) {
                object = (String)object + " II";
            }
            GuiBeacon.this.drawCreativeTabHoveringText((String)object, n, n2);
        }
    }

    static class Button
    extends GuiButton {
        private final ResourceLocation iconTexture;
        private final int iconX;
        private final int iconY;
        private boolean selected;

        protected Button(int n, int n2, int n3, ResourceLocation resourceLocation, int n4, int n5) {
            super(n, n2, n3, 22, 22, "");
            this.iconTexture = resourceLocation;
            this.iconX = n4;
            this.iconY = n5;
        }

        @Override
        public void func_191745_a(Minecraft minecraft, int n, int n2, float f) {
            if (this.visible) {
                minecraft.getTextureManager().bindTexture(BEACON_GUI_TEXTURES);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                this.hovered = n >= this.xPosition && n2 >= this.yPosition && n < this.xPosition + this.width && n2 < this.yPosition + this.height;
                int n3 = 219;
                int n4 = 0;
                if (!this.enabled) {
                    n4 += this.width * 2;
                } else if (this.selected) {
                    n4 += this.width * 1;
                } else if (this.hovered) {
                    n4 += this.width * 3;
                }
                this.drawTexturedModalRect(this.xPosition, this.yPosition, n4, 219, this.width, this.height);
                if (!BEACON_GUI_TEXTURES.equals(this.iconTexture)) {
                    minecraft.getTextureManager().bindTexture(this.iconTexture);
                }
                this.drawTexturedModalRect(this.xPosition + 2, this.yPosition + 2, this.iconX, this.iconY, 18, 18);
            }
        }

        public boolean isSelected() {
            return this.selected;
        }

        public void setSelected(boolean bl) {
            this.selected = bl;
        }
    }
}
