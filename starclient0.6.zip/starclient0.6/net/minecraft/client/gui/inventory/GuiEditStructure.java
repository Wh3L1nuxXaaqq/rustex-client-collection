package net.minecraft.client.gui.inventory;

import com.google.common.collect.Lists;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.tileentity.TileEntityStructure;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class GuiEditStructure
extends GuiScreen {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final int[] LEGAL_KEY_CODES = new int[]{203, 205, 14, 211, 199, 207};
    private final TileEntityStructure tileStructure;
    private Mirror mirror = Mirror.NONE;
    private Rotation rotation = Rotation.NONE;
    private TileEntityStructure.Mode mode = TileEntityStructure.Mode.DATA;
    private boolean ignoreEntities;
    private boolean showAir;
    private boolean showBoundingBox;
    private GuiTextField nameEdit;
    private GuiTextField posXEdit;
    private GuiTextField posYEdit;
    private GuiTextField posZEdit;
    private GuiTextField sizeXEdit;
    private GuiTextField sizeYEdit;
    private GuiTextField sizeZEdit;
    private GuiTextField integrityEdit;
    private GuiTextField seedEdit;
    private GuiTextField dataEdit;
    private GuiButton doneButton;
    private GuiButton cancelButton;
    private GuiButton saveButton;
    private GuiButton loadButton;
    private GuiButton rotateZeroDegreesButton;
    private GuiButton rotateNinetyDegreesButton;
    private GuiButton rotate180DegreesButton;
    private GuiButton rotate270DegressButton;
    private GuiButton modeButton;
    private GuiButton detectSizeButton;
    private GuiButton showEntitiesButton;
    private GuiButton mirrorButton;
    private GuiButton showAirButton;
    private GuiButton showBoundingBoxButton;
    private final List<GuiTextField> tabOrder = Lists.newArrayList();
    private final DecimalFormat decimalFormat = new DecimalFormat("0.0###");

    public GuiEditStructure(TileEntityStructure tileEntityStructure) {
        this.tileStructure = tileEntityStructure;
        this.decimalFormat.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
    }

    @Override
    public void updateScreen() {
        this.nameEdit.updateCursorCounter();
        this.posXEdit.updateCursorCounter();
        this.posYEdit.updateCursorCounter();
        this.posZEdit.updateCursorCounter();
        this.sizeXEdit.updateCursorCounter();
        this.sizeYEdit.updateCursorCounter();
        this.sizeZEdit.updateCursorCounter();
        this.integrityEdit.updateCursorCounter();
        this.seedEdit.updateCursorCounter();
        this.dataEdit.updateCursorCounter();
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.buttonList.clear();
        this.doneButton = this.addButton(new GuiButton(0, this.width / 2 - 4 - 150, 210, 150, 20, I18n.format("gui.done", new Object[0])));
        this.cancelButton = this.addButton(new GuiButton(1, this.width / 2 + 4, 210, 150, 20, I18n.format("gui.cancel", new Object[0])));
        this.saveButton = this.addButton(new GuiButton(9, this.width / 2 + 4 + 100, 185, 50, 20, I18n.format("structure_block.button.save", new Object[0])));
        this.loadButton = this.addButton(new GuiButton(10, this.width / 2 + 4 + 100, 185, 50, 20, I18n.format("structure_block.button.load", new Object[0])));
        this.modeButton = this.addButton(new GuiButton(18, this.width / 2 - 4 - 150, 185, 50, 20, "MODE"));
        this.detectSizeButton = this.addButton(new GuiButton(19, this.width / 2 + 4 + 100, 120, 50, 20, I18n.format("structure_block.button.detect_size", new Object[0])));
        this.showEntitiesButton = this.addButton(new GuiButton(20, this.width / 2 + 4 + 100, 160, 50, 20, "ENTITIES"));
        this.mirrorButton = this.addButton(new GuiButton(21, this.width / 2 - 20, 185, 40, 20, "MIRROR"));
        this.showAirButton = this.addButton(new GuiButton(22, this.width / 2 + 4 + 100, 80, 50, 20, "SHOWAIR"));
        this.showBoundingBoxButton = this.addButton(new GuiButton(23, this.width / 2 + 4 + 100, 80, 50, 20, "SHOWBB"));
        this.rotateZeroDegreesButton = this.addButton(new GuiButton(11, this.width / 2 - 1 - 40 - 1 - 40 - 20, 185, 40, 20, "0"));
        this.rotateNinetyDegreesButton = this.addButton(new GuiButton(12, this.width / 2 - 1 - 40 - 20, 185, 40, 20, "90"));
        this.rotate180DegreesButton = this.addButton(new GuiButton(13, this.width / 2 + 1 + 20, 185, 40, 20, "180"));
        this.rotate270DegressButton = this.addButton(new GuiButton(14, this.width / 2 + 1 + 40 + 1 + 20, 185, 40, 20, "270"));
        this.nameEdit = new GuiTextField(2, this.fontRendererObj, this.width / 2 - 152, 40, 300, 20);
        this.nameEdit.setMaxStringLength(64);
        this.nameEdit.setText(this.tileStructure.getName());
        this.tabOrder.add(this.nameEdit);
        BlockPos blockPos = this.tileStructure.getPosition();
        this.posXEdit = new GuiTextField(3, this.fontRendererObj, this.width / 2 - 152, 80, 80, 20);
        this.posXEdit.setMaxStringLength(15);
        this.posXEdit.setText(Integer.toString(blockPos.getX()));
        this.tabOrder.add(this.posXEdit);
        this.posYEdit = new GuiTextField(4, this.fontRendererObj, this.width / 2 - 72, 80, 80, 20);
        this.posYEdit.setMaxStringLength(15);
        this.posYEdit.setText(Integer.toString(blockPos.getY()));
        this.tabOrder.add(this.posYEdit);
        this.posZEdit = new GuiTextField(5, this.fontRendererObj, this.width / 2 + 8, 80, 80, 20);
        this.posZEdit.setMaxStringLength(15);
        this.posZEdit.setText(Integer.toString(blockPos.getZ()));
        this.tabOrder.add(this.posZEdit);
        BlockPos blockPos2 = this.tileStructure.getStructureSize();
        this.sizeXEdit = new GuiTextField(6, this.fontRendererObj, this.width / 2 - 152, 120, 80, 20);
        this.sizeXEdit.setMaxStringLength(15);
        this.sizeXEdit.setText(Integer.toString(blockPos2.getX()));
        this.tabOrder.add(this.sizeXEdit);
        this.sizeYEdit = new GuiTextField(7, this.fontRendererObj, this.width / 2 - 72, 120, 80, 20);
        this.sizeYEdit.setMaxStringLength(15);
        this.sizeYEdit.setText(Integer.toString(blockPos2.getY()));
        this.tabOrder.add(this.sizeYEdit);
        this.sizeZEdit = new GuiTextField(8, this.fontRendererObj, this.width / 2 + 8, 120, 80, 20);
        this.sizeZEdit.setMaxStringLength(15);
        this.sizeZEdit.setText(Integer.toString(blockPos2.getZ()));
        this.tabOrder.add(this.sizeZEdit);
        this.integrityEdit = new GuiTextField(15, this.fontRendererObj, this.width / 2 - 152, 120, 80, 20);
        this.integrityEdit.setMaxStringLength(15);
        this.integrityEdit.setText(this.decimalFormat.format(this.tileStructure.getIntegrity()));
        this.tabOrder.add(this.integrityEdit);
        this.seedEdit = new GuiTextField(16, this.fontRendererObj, this.width / 2 - 72, 120, 80, 20);
        this.seedEdit.setMaxStringLength(31);
        this.seedEdit.setText(Long.toString(this.tileStructure.getSeed()));
        this.tabOrder.add(this.seedEdit);
        this.dataEdit = new GuiTextField(17, this.fontRendererObj, this.width / 2 - 152, 120, 240, 20);
        this.dataEdit.setMaxStringLength(128);
        this.dataEdit.setText(this.tileStructure.getMetadata());
        this.tabOrder.add(this.dataEdit);
        this.mirror = this.tileStructure.getMirror();
        this.updateMirrorButton();
        this.rotation = this.tileStructure.getRotation();
        this.updateDirectionButtons();
        this.mode = this.tileStructure.getMode();
        this.updateMode();
        this.ignoreEntities = this.tileStructure.ignoresEntities();
        this.updateEntitiesButton();
        this.showAir = this.tileStructure.showsAir();
        this.updateToggleAirButton();
        this.showBoundingBox = this.tileStructure.showsBoundingBox();
        this.updateToggleBoundingBox();
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.enabled) {
            if (guiButton.id == 1) {
                this.tileStructure.setMirror(this.mirror);
                this.tileStructure.setRotation(this.rotation);
                this.tileStructure.setMode(this.mode);
                this.tileStructure.setIgnoresEntities(this.ignoreEntities);
                this.tileStructure.setShowAir(this.showAir);
                this.tileStructure.setShowBoundingBox(this.showBoundingBox);
                mc.displayGuiScreen(null);
            } else if (guiButton.id == 0) {
                if (this.sendToServer(1)) {
                    mc.displayGuiScreen(null);
                }
            } else if (guiButton.id == 9) {
                if (this.tileStructure.getMode() == TileEntityStructure.Mode.SAVE) {
                    this.sendToServer(2);
                    mc.displayGuiScreen(null);
                }
            } else if (guiButton.id == 10) {
                if (this.tileStructure.getMode() == TileEntityStructure.Mode.LOAD) {
                    this.sendToServer(3);
                    mc.displayGuiScreen(null);
                }
            } else if (guiButton.id == 11) {
                this.tileStructure.setRotation(Rotation.NONE);
                this.updateDirectionButtons();
            } else if (guiButton.id == 12) {
                this.tileStructure.setRotation(Rotation.CLOCKWISE_90);
                this.updateDirectionButtons();
            } else if (guiButton.id == 13) {
                this.tileStructure.setRotation(Rotation.CLOCKWISE_180);
                this.updateDirectionButtons();
            } else if (guiButton.id == 14) {
                this.tileStructure.setRotation(Rotation.COUNTERCLOCKWISE_90);
                this.updateDirectionButtons();
            } else if (guiButton.id == 18) {
                this.tileStructure.nextMode();
                this.updateMode();
            } else if (guiButton.id == 19) {
                if (this.tileStructure.getMode() == TileEntityStructure.Mode.SAVE) {
                    this.sendToServer(4);
                    mc.displayGuiScreen(null);
                }
            } else if (guiButton.id == 20) {
                this.tileStructure.setIgnoresEntities(!this.tileStructure.ignoresEntities());
                this.updateEntitiesButton();
            } else if (guiButton.id == 22) {
                this.tileStructure.setShowAir(!this.tileStructure.showsAir());
                this.updateToggleAirButton();
            } else if (guiButton.id == 23) {
                this.tileStructure.setShowBoundingBox(!this.tileStructure.showsBoundingBox());
                this.updateToggleBoundingBox();
            } else if (guiButton.id == 21) {
                switch (this.tileStructure.getMirror()) {
                    case NONE: {
                        this.tileStructure.setMirror(Mirror.LEFT_RIGHT);
                        break;
                    }
                    case LEFT_RIGHT: {
                        this.tileStructure.setMirror(Mirror.FRONT_BACK);
                        break;
                    }
                    case FRONT_BACK: {
                        this.tileStructure.setMirror(Mirror.NONE);
                    }
                }
                this.updateMirrorButton();
            }
        }
    }

    private void updateEntitiesButton() {
        boolean bl = !this.tileStructure.ignoresEntities();
        this.showEntitiesButton.displayString = bl ? I18n.format("options.on", new Object[0]) : I18n.format("options.off", new Object[0]);
    }

    private void updateToggleAirButton() {
        boolean bl = this.tileStructure.showsAir();
        this.showAirButton.displayString = bl ? I18n.format("options.on", new Object[0]) : I18n.format("options.off", new Object[0]);
    }

    private void updateToggleBoundingBox() {
        boolean bl = this.tileStructure.showsBoundingBox();
        this.showBoundingBoxButton.displayString = bl ? I18n.format("options.on", new Object[0]) : I18n.format("options.off", new Object[0]);
    }

    private void updateMirrorButton() {
        Mirror mirror = this.tileStructure.getMirror();
        switch (mirror) {
            case NONE: {
                this.mirrorButton.displayString = "|";
                break;
            }
            case LEFT_RIGHT: {
                this.mirrorButton.displayString = "< >";
                break;
            }
            case FRONT_BACK: {
                this.mirrorButton.displayString = "^ v";
            }
        }
    }

    private void updateDirectionButtons() {
        this.rotateZeroDegreesButton.enabled = true;
        this.rotateNinetyDegreesButton.enabled = true;
        this.rotate180DegreesButton.enabled = true;
        this.rotate270DegressButton.enabled = true;
        switch (this.tileStructure.getRotation()) {
            case NONE: {
                this.rotateZeroDegreesButton.enabled = false;
                break;
            }
            case CLOCKWISE_180: {
                this.rotate180DegreesButton.enabled = false;
                break;
            }
            case COUNTERCLOCKWISE_90: {
                this.rotate270DegressButton.enabled = false;
                break;
            }
            case CLOCKWISE_90: {
                this.rotateNinetyDegreesButton.enabled = false;
            }
        }
    }

    private void updateMode() {
        this.nameEdit.setFocused(false);
        this.posXEdit.setFocused(false);
        this.posYEdit.setFocused(false);
        this.posZEdit.setFocused(false);
        this.sizeXEdit.setFocused(false);
        this.sizeYEdit.setFocused(false);
        this.sizeZEdit.setFocused(false);
        this.integrityEdit.setFocused(false);
        this.seedEdit.setFocused(false);
        this.dataEdit.setFocused(false);
        this.nameEdit.setVisible(false);
        this.nameEdit.setFocused(false);
        this.posXEdit.setVisible(false);
        this.posYEdit.setVisible(false);
        this.posZEdit.setVisible(false);
        this.sizeXEdit.setVisible(false);
        this.sizeYEdit.setVisible(false);
        this.sizeZEdit.setVisible(false);
        this.integrityEdit.setVisible(false);
        this.seedEdit.setVisible(false);
        this.dataEdit.setVisible(false);
        this.saveButton.visible = false;
        this.loadButton.visible = false;
        this.detectSizeButton.visible = false;
        this.showEntitiesButton.visible = false;
        this.mirrorButton.visible = false;
        this.rotateZeroDegreesButton.visible = false;
        this.rotateNinetyDegreesButton.visible = false;
        this.rotate180DegreesButton.visible = false;
        this.rotate270DegressButton.visible = false;
        this.showAirButton.visible = false;
        this.showBoundingBoxButton.visible = false;
        switch (this.tileStructure.getMode()) {
            case SAVE: {
                this.nameEdit.setVisible(true);
                this.nameEdit.setFocused(true);
                this.posXEdit.setVisible(true);
                this.posYEdit.setVisible(true);
                this.posZEdit.setVisible(true);
                this.sizeXEdit.setVisible(true);
                this.sizeYEdit.setVisible(true);
                this.sizeZEdit.setVisible(true);
                this.saveButton.visible = true;
                this.detectSizeButton.visible = true;
                this.showEntitiesButton.visible = true;
                this.showAirButton.visible = true;
                break;
            }
            case LOAD: {
                this.nameEdit.setVisible(true);
                this.nameEdit.setFocused(true);
                this.posXEdit.setVisible(true);
                this.posYEdit.setVisible(true);
                this.posZEdit.setVisible(true);
                this.integrityEdit.setVisible(true);
                this.seedEdit.setVisible(true);
                this.loadButton.visible = true;
                this.showEntitiesButton.visible = true;
                this.mirrorButton.visible = true;
                this.rotateZeroDegreesButton.visible = true;
                this.rotateNinetyDegreesButton.visible = true;
                this.rotate180DegreesButton.visible = true;
                this.rotate270DegressButton.visible = true;
                this.showBoundingBoxButton.visible = true;
                this.updateDirectionButtons();
                break;
            }
            case CORNER: {
                this.nameEdit.setVisible(true);
                this.nameEdit.setFocused(true);
                break;
            }
            case DATA: {
                this.dataEdit.setVisible(true);
                this.dataEdit.setFocused(true);
            }
        }
        this.modeButton.displayString = I18n.format("structure_block.mode." + this.tileStructure.getMode().getName(), new Object[0]);
    }

    private boolean sendToServer(int n) {
        try {
            PacketBuffer packetBuffer = new PacketBuffer(Unpooled.buffer());
            this.tileStructure.writeCoordinates(packetBuffer);
            packetBuffer.writeByte(n);
            packetBuffer.writeString(this.tileStructure.getMode().toString());
            packetBuffer.writeString(this.nameEdit.getText());
            packetBuffer.writeInt(this.parseCoordinate(this.posXEdit.getText()));
            packetBuffer.writeInt(this.parseCoordinate(this.posYEdit.getText()));
            packetBuffer.writeInt(this.parseCoordinate(this.posZEdit.getText()));
            packetBuffer.writeInt(this.parseCoordinate(this.sizeXEdit.getText()));
            packetBuffer.writeInt(this.parseCoordinate(this.sizeYEdit.getText()));
            packetBuffer.writeInt(this.parseCoordinate(this.sizeZEdit.getText()));
            packetBuffer.writeString(this.tileStructure.getMirror().toString());
            packetBuffer.writeString(this.tileStructure.getRotation().toString());
            packetBuffer.writeString(this.dataEdit.getText());
            packetBuffer.writeBoolean(this.tileStructure.ignoresEntities());
            packetBuffer.writeBoolean(this.tileStructure.showsAir());
            packetBuffer.writeBoolean(this.tileStructure.showsBoundingBox());
            packetBuffer.writeFloat(this.parseIntegrity(this.integrityEdit.getText()));
            packetBuffer.writeVarLong(this.parseSeed(this.seedEdit.getText()));
            mc.getConnection().sendPacket(new CPacketCustomPayload("MC|Struct", packetBuffer));
            return true;
        }
        catch (Exception exception) {
            LOGGER.warn("Could not send structure block info", (Throwable)exception);
            return false;
        }
    }

    private long parseSeed(String string) {
        try {
            return Long.valueOf(string);
        }
        catch (NumberFormatException numberFormatException) {
            return 0L;
        }
    }

    private float parseIntegrity(String string) {
        try {
            return Float.valueOf(string).floatValue();
        }
        catch (NumberFormatException numberFormatException) {
            return 1.0f;
        }
    }

    private int parseCoordinate(String string) {
        try {
            return Integer.parseInt(string);
        }
        catch (NumberFormatException numberFormatException) {
            return 0;
        }
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        if (this.nameEdit.getVisible() && GuiEditStructure.isValidCharacterForName(c, n)) {
            this.nameEdit.textboxKeyTyped(c, n);
        }
        if (this.posXEdit.getVisible()) {
            this.posXEdit.textboxKeyTyped(c, n);
        }
        if (this.posYEdit.getVisible()) {
            this.posYEdit.textboxKeyTyped(c, n);
        }
        if (this.posZEdit.getVisible()) {
            this.posZEdit.textboxKeyTyped(c, n);
        }
        if (this.sizeXEdit.getVisible()) {
            this.sizeXEdit.textboxKeyTyped(c, n);
        }
        if (this.sizeYEdit.getVisible()) {
            this.sizeYEdit.textboxKeyTyped(c, n);
        }
        if (this.sizeZEdit.getVisible()) {
            this.sizeZEdit.textboxKeyTyped(c, n);
        }
        if (this.integrityEdit.getVisible()) {
            this.integrityEdit.textboxKeyTyped(c, n);
        }
        if (this.seedEdit.getVisible()) {
            this.seedEdit.textboxKeyTyped(c, n);
        }
        if (this.dataEdit.getVisible()) {
            this.dataEdit.textboxKeyTyped(c, n);
        }
        if (n == 15) {
            GuiTextField guiTextField = null;
            GuiTextField guiTextField2 = null;
            for (GuiTextField guiTextField3 : this.tabOrder) {
                if (guiTextField != null && guiTextField3.getVisible()) {
                    guiTextField2 = guiTextField3;
                    break;
                }
                if (!guiTextField3.isFocused() || !guiTextField3.getVisible()) continue;
                guiTextField = guiTextField3;
            }
            if (guiTextField != null && guiTextField2 == null) {
                for (GuiTextField guiTextField3 : this.tabOrder) {
                    if (!guiTextField3.getVisible() || guiTextField3 == guiTextField) continue;
                    guiTextField2 = guiTextField3;
                    break;
                }
            }
            if (guiTextField2 != null && guiTextField2 != guiTextField) {
                guiTextField.setFocused(false);
                guiTextField2.setFocused(true);
            }
        }
        if (n != 28 && n != 156) {
            if (n == 1) {
                this.actionPerformed(this.cancelButton);
            }
        } else {
            this.actionPerformed(this.doneButton);
        }
    }

    private static boolean isValidCharacterForName(char c, int n) {
        boolean bl = true;
        for (int n2 : LEGAL_KEY_CODES) {
            if (n2 != n) continue;
            return true;
        }
        for (int n2 : ChatAllowedCharacters.ILLEGAL_STRUCTURE_CHARACTERS) {
            if (n2 != c) continue;
            bl = false;
            break;
        }
        return bl;
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        super.mouseClicked(n, n2, n3);
        if (this.nameEdit.getVisible()) {
            this.nameEdit.mouseClicked(n, n2, n3);
        }
        if (this.posXEdit.getVisible()) {
            this.posXEdit.mouseClicked(n, n2, n3);
        }
        if (this.posYEdit.getVisible()) {
            this.posYEdit.mouseClicked(n, n2, n3);
        }
        if (this.posZEdit.getVisible()) {
            this.posZEdit.mouseClicked(n, n2, n3);
        }
        if (this.sizeXEdit.getVisible()) {
            this.sizeXEdit.mouseClicked(n, n2, n3);
        }
        if (this.sizeYEdit.getVisible()) {
            this.sizeYEdit.mouseClicked(n, n2, n3);
        }
        if (this.sizeZEdit.getVisible()) {
            this.sizeZEdit.mouseClicked(n, n2, n3);
        }
        if (this.integrityEdit.getVisible()) {
            this.integrityEdit.mouseClicked(n, n2, n3);
        }
        if (this.seedEdit.getVisible()) {
            this.seedEdit.mouseClicked(n, n2, n3);
        }
        if (this.dataEdit.getVisible()) {
            this.dataEdit.mouseClicked(n, n2, n3);
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        int n3;
        Object object;
        this.drawDefaultBackground();
        TileEntityStructure.Mode mode = this.tileStructure.getMode();
        this.drawCenteredString(this.fontRendererObj, I18n.format("tile.structureBlock.name", new Object[0]), this.width / 2, 10, 0xFFFFFF);
        if (mode != TileEntityStructure.Mode.DATA) {
            this.drawString(this.fontRendererObj, I18n.format("structure_block.structure_name", new Object[0]), this.width / 2 - 153, 30, 0xA0A0A0);
            this.nameEdit.drawTextBox();
        }
        if (mode == TileEntityStructure.Mode.LOAD || mode == TileEntityStructure.Mode.SAVE) {
            this.drawString(this.fontRendererObj, I18n.format("structure_block.position", new Object[0]), this.width / 2 - 153, 70, 0xA0A0A0);
            this.posXEdit.drawTextBox();
            this.posYEdit.drawTextBox();
            this.posZEdit.drawTextBox();
            object = I18n.format("structure_block.include_entities", new Object[0]);
            n3 = this.fontRendererObj.getStringWidth((String)object);
            this.drawString(this.fontRendererObj, (String)object, this.width / 2 + 154 - n3, 150, 0xA0A0A0);
        }
        if (mode == TileEntityStructure.Mode.SAVE) {
            this.drawString(this.fontRendererObj, I18n.format("structure_block.size", new Object[0]), this.width / 2 - 153, 110, 0xA0A0A0);
            this.sizeXEdit.drawTextBox();
            this.sizeYEdit.drawTextBox();
            this.sizeZEdit.drawTextBox();
            object = I18n.format("structure_block.detect_size", new Object[0]);
            n3 = this.fontRendererObj.getStringWidth((String)object);
            this.drawString(this.fontRendererObj, (String)object, this.width / 2 + 154 - n3, 110, 0xA0A0A0);
            String string = I18n.format("structure_block.show_air", new Object[0]);
            int n4 = this.fontRendererObj.getStringWidth(string);
            this.drawString(this.fontRendererObj, string, this.width / 2 + 154 - n4, 70, 0xA0A0A0);
        }
        if (mode == TileEntityStructure.Mode.LOAD) {
            this.drawString(this.fontRendererObj, I18n.format("structure_block.integrity", new Object[0]), this.width / 2 - 153, 110, 0xA0A0A0);
            this.integrityEdit.drawTextBox();
            this.seedEdit.drawTextBox();
            object = I18n.format("structure_block.show_boundingbox", new Object[0]);
            n3 = this.fontRendererObj.getStringWidth((String)object);
            this.drawString(this.fontRendererObj, (String)object, this.width / 2 + 154 - n3, 70, 0xA0A0A0);
        }
        if (mode == TileEntityStructure.Mode.DATA) {
            this.drawString(this.fontRendererObj, I18n.format("structure_block.custom_data", new Object[0]), this.width / 2 - 153, 110, 0xA0A0A0);
            this.dataEdit.drawTextBox();
        }
        object = "structure_block.mode_info." + mode.getName();
        this.drawString(this.fontRendererObj, I18n.format((String)object, new Object[0]), this.width / 2 - 153, 174, 0xA0A0A0);
        super.drawScreen(n, n2, f);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
