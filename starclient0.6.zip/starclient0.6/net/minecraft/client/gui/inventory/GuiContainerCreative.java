package net.minecraft.client.gui.inventory;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.achievement.GuiStats;
import net.minecraft.client.gui.inventory.CreativeCrafting;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.CreativeSettings;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.HotbarSnapshot;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.util.SearchTreeManager;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiContainerCreative
extends InventoryEffectRenderer {
    private static final ResourceLocation CREATIVE_INVENTORY_TABS = new ResourceLocation("textures/gui/container/creative_inventory/tabs.png");
    private static final InventoryBasic basicInventory = new InventoryBasic("tmp", true, 45);
    private static int selectedTabIndex = CreativeTabs.BUILDING_BLOCKS.getTabIndex();
    private float currentScroll;
    private boolean isScrolling;
    private boolean wasClicking;
    private GuiTextField searchField;
    private List<Slot> originalSlots;
    private Slot destroyItemSlot;
    private boolean clearSearch;
    private CreativeCrafting listener;

    public GuiContainerCreative(EntityPlayer entityPlayer) {
        super(new ContainerCreative(entityPlayer));
        entityPlayer.openContainer = this.inventorySlots;
        this.allowUserInput = true;
        this.ySize = 136;
        this.xSize = 195;
    }

    @Override
    public void updateScreen() {
        if (!GuiContainerCreative.mc.playerController.isInCreativeMode()) {
            mc.displayGuiScreen(new GuiInventory(GuiContainerCreative.mc.player));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void handleMouseClick(@Nullable Slot slot, int n, int n2, ClickType clickType) {
        ItemStack itemStack;
        this.clearSearch = true;
        boolean bl = clickType == ClickType.QUICK_MOVE;
        ClickType clickType2 = clickType = n == -999 && clickType == ClickType.PICKUP ? ClickType.THROW : clickType;
        if (slot == null && selectedTabIndex != CreativeTabs.INVENTORY.getTabIndex() && clickType != ClickType.QUICK_CRAFT) {
            InventoryPlayer inventoryPlayer = GuiContainerCreative.mc.player.inventory;
            if (inventoryPlayer.getItemStack().func_190926_b()) return;
            if (n2 == 0) {
                GuiContainerCreative.mc.player.dropItem(inventoryPlayer.getItemStack(), true);
                GuiContainerCreative.mc.playerController.sendPacketDropItem(inventoryPlayer.getItemStack());
                inventoryPlayer.setItemStack(ItemStack.field_190927_a);
            }
            if (n2 != 1) return;
            ItemStack itemStack2 = inventoryPlayer.getItemStack().splitStack(1);
            GuiContainerCreative.mc.player.dropItem(itemStack2, true);
            GuiContainerCreative.mc.playerController.sendPacketDropItem(itemStack2);
            return;
        }
        if (slot != null) {
            if (!slot.canTakeStack(GuiContainerCreative.mc.player)) {
                return;
            }
        }
        if (slot == this.destroyItemSlot && bl) {
            int n3 = 0;
            while (n3 < GuiContainerCreative.mc.player.inventoryContainer.getInventory().size()) {
                GuiContainerCreative.mc.playerController.sendSlotPacket(ItemStack.field_190927_a, n3);
                ++n3;
            }
            return;
        }
        if (selectedTabIndex == CreativeTabs.INVENTORY.getTabIndex()) {
            if (slot == this.destroyItemSlot) {
                GuiContainerCreative.mc.player.inventory.setItemStack(ItemStack.field_190927_a);
                return;
            }
            if (clickType == ClickType.THROW && slot != null && slot.getHasStack()) {
                ItemStack itemStack3 = slot.decrStackSize(n2 == 0 ? 1 : slot.getStack().getMaxStackSize());
                ItemStack itemStack4 = slot.getStack();
                GuiContainerCreative.mc.player.dropItem(itemStack3, true);
                GuiContainerCreative.mc.playerController.sendPacketDropItem(itemStack3);
                GuiContainerCreative.mc.playerController.sendSlotPacket(itemStack4, ((CreativeSlot)slot).slot.slotNumber);
                return;
            }
            if (clickType == ClickType.THROW) {
                if (!GuiContainerCreative.mc.player.inventory.getItemStack().func_190926_b()) {
                    GuiContainerCreative.mc.player.dropItem(GuiContainerCreative.mc.player.inventory.getItemStack(), true);
                    GuiContainerCreative.mc.playerController.sendPacketDropItem(GuiContainerCreative.mc.player.inventory.getItemStack());
                    GuiContainerCreative.mc.player.inventory.setItemStack(ItemStack.field_190927_a);
                    return;
                }
            }
            GuiContainerCreative.mc.player.inventoryContainer.slotClick(slot == null ? n : ((CreativeSlot)slot).slot.slotNumber, n2, clickType, GuiContainerCreative.mc.player);
            GuiContainerCreative.mc.player.inventoryContainer.detectAndSendChanges();
            return;
        }
        if (clickType != ClickType.QUICK_CRAFT && slot.inventory == basicInventory) {
            InventoryPlayer inventoryPlayer = GuiContainerCreative.mc.player.inventory;
            ItemStack itemStack5 = inventoryPlayer.getItemStack();
            ItemStack itemStack6 = slot.getStack();
            if (clickType == ClickType.SWAP) {
                if (itemStack6.func_190926_b()) return;
                if (n2 < 0) return;
                if (n2 >= 9) return;
                ItemStack itemStack7 = itemStack6.copy();
                itemStack7.func_190920_e(itemStack7.getMaxStackSize());
                GuiContainerCreative.mc.player.inventory.setInventorySlotContents(n2, itemStack7);
                GuiContainerCreative.mc.player.inventoryContainer.detectAndSendChanges();
                return;
            }
            if (clickType == ClickType.CLONE) {
                if (!inventoryPlayer.getItemStack().func_190926_b()) return;
                if (!slot.getHasStack()) return;
                ItemStack itemStack8 = slot.getStack().copy();
                itemStack8.func_190920_e(itemStack8.getMaxStackSize());
                inventoryPlayer.setItemStack(itemStack8);
                return;
            }
            if (clickType == ClickType.THROW) {
                if (itemStack6.func_190926_b()) return;
                ItemStack itemStack9 = itemStack6.copy();
                itemStack9.func_190920_e(n2 == 0 ? 1 : itemStack9.getMaxStackSize());
                GuiContainerCreative.mc.player.dropItem(itemStack9, true);
                GuiContainerCreative.mc.playerController.sendPacketDropItem(itemStack9);
                return;
            }
            if (!itemStack5.func_190926_b() && !itemStack6.func_190926_b() && itemStack5.isItemEqual(itemStack6) && ItemStack.areItemStackTagsEqual(itemStack5, itemStack6)) {
                if (n2 != 0) {
                    itemStack5.func_190918_g(1);
                    return;
                }
                if (bl) {
                    itemStack5.func_190920_e(itemStack5.getMaxStackSize());
                    return;
                }
                if (itemStack5.func_190916_E() >= itemStack5.getMaxStackSize()) return;
                itemStack5.func_190917_f(1);
                return;
            }
            if (!itemStack6.func_190926_b() && itemStack5.func_190926_b()) {
                inventoryPlayer.setItemStack(itemStack6.copy());
                itemStack5 = inventoryPlayer.getItemStack();
                if (!bl) return;
                itemStack5.func_190920_e(itemStack5.getMaxStackSize());
                return;
            }
            if (n2 == 0) {
                inventoryPlayer.setItemStack(ItemStack.field_190927_a);
                return;
            }
            inventoryPlayer.getItemStack().func_190918_g(1);
            return;
        }
        if (this.inventorySlots == null) return;
        ItemStack itemStack10 = itemStack = slot == null ? ItemStack.field_190927_a : this.inventorySlots.getSlot(slot.slotNumber).getStack();
        this.inventorySlots.slotClick(slot == null ? n : slot.slotNumber, n2, clickType, GuiContainerCreative.mc.player);
        if (Container.getDragEvent(n2) == 2) {
            int n4 = 0;
            while (n4 < 9) {
                GuiContainerCreative.mc.playerController.sendSlotPacket(this.inventorySlots.getSlot(45 + n4).getStack(), 36 + n4);
                ++n4;
            }
            return;
        }
        if (slot == null) return;
        ItemStack itemStack11 = this.inventorySlots.getSlot(slot.slotNumber).getStack();
        GuiContainerCreative.mc.playerController.sendSlotPacket(itemStack11, slot.slotNumber - this.inventorySlots.inventorySlots.size() + 9 + 36);
        int n5 = 45 + n2;
        if (clickType == ClickType.SWAP) {
            GuiContainerCreative.mc.playerController.sendSlotPacket(itemStack, n5 - this.inventorySlots.inventorySlots.size() + 9 + 36);
        } else if (clickType == ClickType.THROW && !itemStack.func_190926_b()) {
            ItemStack itemStack12 = itemStack.copy();
            itemStack12.func_190920_e(n2 == 0 ? 1 : itemStack12.getMaxStackSize());
            GuiContainerCreative.mc.player.dropItem(itemStack12, true);
            GuiContainerCreative.mc.playerController.sendPacketDropItem(itemStack12);
        }
        GuiContainerCreative.mc.player.inventoryContainer.detectAndSendChanges();
    }

    @Override
    protected void updateActivePotionEffects() {
        int n = this.guiLeft;
        super.updateActivePotionEffects();
        if (this.searchField != null && this.guiLeft != n) {
            this.searchField.xPosition = this.guiLeft + 82;
        }
    }

    @Override
    public void initGui() {
        if (GuiContainerCreative.mc.playerController.isInCreativeMode()) {
            super.initGui();
            this.buttonList.clear();
            Keyboard.enableRepeatEvents((boolean)true);
            this.searchField = new GuiTextField(0, this.fontRendererObj, this.guiLeft + 82, this.guiTop + 6, 80, this.fontRendererObj.FONT_HEIGHT);
            this.searchField.setMaxStringLength(50);
            this.searchField.setEnableBackgroundDrawing(false);
            this.searchField.setVisible(false);
            this.searchField.setTextColor(0xFFFFFF);
            int n = selectedTabIndex;
            selectedTabIndex = -1;
            this.setCurrentCreativeTab(CreativeTabs.CREATIVE_TAB_ARRAY[n]);
            this.listener = new CreativeCrafting(mc);
            GuiContainerCreative.mc.player.inventoryContainer.addListener(this.listener);
        } else {
            mc.displayGuiScreen(new GuiInventory(GuiContainerCreative.mc.player));
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        if (GuiContainerCreative.mc.player != null) {
            if (GuiContainerCreative.mc.player.inventory != null) {
                GuiContainerCreative.mc.player.inventoryContainer.removeListener(this.listener);
            }
        }
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        if (selectedTabIndex != CreativeTabs.SEARCH.getTabIndex()) {
            if (GameSettings.isKeyDown(GuiContainerCreative.mc.gameSettings.keyBindChat)) {
                this.setCurrentCreativeTab(CreativeTabs.SEARCH);
            } else {
                super.keyTyped(c, n);
            }
        } else {
            if (this.clearSearch) {
                this.clearSearch = false;
                this.searchField.setText("");
            }
            if (!this.checkHotbarKeys(n)) {
                if (this.searchField.textboxKeyTyped(c, n)) {
                    this.updateCreativeSearch();
                } else {
                    super.keyTyped(c, n);
                }
            }
        }
    }

    private void updateCreativeSearch() {
        ContainerCreative containerCreative = (ContainerCreative)this.inventorySlots;
        containerCreative.itemList.clear();
        if (this.searchField.getText().isEmpty()) {
            for (Item item : Item.REGISTRY) {
                item.getSubItems(CreativeTabs.SEARCH, containerCreative.itemList);
            }
        } else {
            containerCreative.itemList.addAll(mc.func_193987_a(SearchTreeManager.field_194011_a).func_194038_a(this.searchField.getText().toLowerCase(Locale.ROOT)));
        }
        this.currentScroll = 0.0f;
        containerCreative.scrollTo(0.0f);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int n, int n2) {
        CreativeTabs creativeTabs = CreativeTabs.CREATIVE_TAB_ARRAY[selectedTabIndex];
        if (creativeTabs.drawInForegroundOfTab()) {
            GlStateManager.disableBlend();
            this.fontRendererObj.drawString(I18n.format(creativeTabs.getTranslatedTabLabel(), new Object[0]), 8, 6, 0x404040);
        }
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        if (n3 == 0) {
            int n4 = n - this.guiLeft;
            int n5 = n2 - this.guiTop;
            for (CreativeTabs creativeTabs : CreativeTabs.CREATIVE_TAB_ARRAY) {
                if (!this.isMouseOverTab(creativeTabs, n4, n5)) continue;
                return;
            }
        }
        super.mouseClicked(n, n2, n3);
    }

    @Override
    protected void mouseReleased(int n, int n2, int n3) {
        if (n3 == 0) {
            int n4 = n - this.guiLeft;
            int n5 = n2 - this.guiTop;
            for (CreativeTabs creativeTabs : CreativeTabs.CREATIVE_TAB_ARRAY) {
                if (!this.isMouseOverTab(creativeTabs, n4, n5)) continue;
                this.setCurrentCreativeTab(creativeTabs);
                return;
            }
        }
        super.mouseReleased(n, n2, n3);
    }

    private boolean needsScrollBars() {
        return selectedTabIndex != CreativeTabs.INVENTORY.getTabIndex() && CreativeTabs.CREATIVE_TAB_ARRAY[selectedTabIndex].shouldHidePlayerInventory() && ((ContainerCreative)this.inventorySlots).canScroll();
    }

    private void setCurrentCreativeTab(CreativeTabs creativeTabs) {
        int n = selectedTabIndex;
        selectedTabIndex = creativeTabs.getTabIndex();
        ContainerCreative containerCreative = (ContainerCreative)this.inventorySlots;
        this.dragSplittingSlots.clear();
        containerCreative.itemList.clear();
        if (creativeTabs == CreativeTabs.field_192395_m) {
            for (int i = 0; i < 9; ++i) {
                HotbarSnapshot hotbarSnapshot = GuiContainerCreative.mc.field_191950_u.func_192563_a(i);
                if (hotbarSnapshot.isEmpty()) {
                    for (int j = 0; j < 9; ++j) {
                        if (j == i) {
                            ItemStack itemStack = new ItemStack(Items.PAPER);
                            itemStack.func_190925_c("CustomCreativeLock");
                            String string = GameSettings.getKeyDisplayString(GuiContainerCreative.mc.gameSettings.keyBindsHotbar[i].getKeyCode());
                            String string2 = GameSettings.getKeyDisplayString(GuiContainerCreative.mc.gameSettings.field_193629_ap.getKeyCode());
                            itemStack.setStackDisplayName(new TextComponentTranslation("inventory.hotbarInfo", string2, string).getUnformattedText());
                            containerCreative.itemList.add(itemStack);
                            continue;
                        }
                        containerCreative.itemList.add(ItemStack.field_190927_a);
                    }
                    continue;
                }
                containerCreative.itemList.addAll(hotbarSnapshot);
            }
        } else if (creativeTabs != CreativeTabs.SEARCH) {
            creativeTabs.displayAllRelevantItems(containerCreative.itemList);
        }
        if (creativeTabs == CreativeTabs.INVENTORY) {
            Container container = GuiContainerCreative.mc.player.inventoryContainer;
            if (this.originalSlots == null) {
                this.originalSlots = containerCreative.inventorySlots;
            }
            containerCreative.inventorySlots = Lists.newArrayList();
            for (int i = 0; i < container.inventorySlots.size(); ++i) {
                int n2;
                int n3;
                int n4;
                CreativeSlot creativeSlot = new CreativeSlot(container.inventorySlots.get(i), i);
                containerCreative.inventorySlots.add(creativeSlot);
                if (i >= 5 && i < 9) {
                    n4 = i - 5;
                    n3 = n4 / 2;
                    n2 = n4 % 2;
                    creativeSlot.xDisplayPosition = 54 + n3 * 54;
                    creativeSlot.yDisplayPosition = 6 + n2 * 27;
                    continue;
                }
                if (i >= 0 && i < 5) {
                    creativeSlot.xDisplayPosition = -2000;
                    creativeSlot.yDisplayPosition = -2000;
                    continue;
                }
                if (i == 45) {
                    creativeSlot.xDisplayPosition = 35;
                    creativeSlot.yDisplayPosition = 20;
                    continue;
                }
                if (i >= container.inventorySlots.size()) continue;
                n4 = i - 9;
                n3 = n4 % 9;
                n2 = n4 / 9;
                creativeSlot.xDisplayPosition = 9 + n3 * 18;
                creativeSlot.yDisplayPosition = i >= 36 ? 112 : 54 + n2 * 18;
            }
            this.destroyItemSlot = new Slot(basicInventory, 0, 173, 112);
            containerCreative.inventorySlots.add(this.destroyItemSlot);
        } else if (n == CreativeTabs.INVENTORY.getTabIndex()) {
            containerCreative.inventorySlots = this.originalSlots;
            this.originalSlots = null;
        }
        if (this.searchField != null) {
            if (creativeTabs == CreativeTabs.SEARCH) {
                this.searchField.setVisible(true);
                this.searchField.setCanLoseFocus(false);
                this.searchField.setFocused(true);
                this.searchField.setText("");
                this.updateCreativeSearch();
            } else {
                this.searchField.setVisible(false);
                this.searchField.setCanLoseFocus(true);
                this.searchField.setFocused(false);
            }
        }
        this.currentScroll = 0.0f;
        containerCreative.scrollTo(0.0f);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int n = Mouse.getEventDWheel();
        if (n != 0 && this.needsScrollBars()) {
            int n2 = (((ContainerCreative)this.inventorySlots).itemList.size() + 9 - 1) / 9 - 5;
            if (n > 0) {
                n = 1;
            }
            if (n < 0) {
                n = -1;
            }
            this.currentScroll = (float)((double)this.currentScroll - (double)n / (double)n2);
            this.currentScroll = MathHelper.clamp(this.currentScroll, 0.0f, 1.0f);
            ((ContainerCreative)this.inventorySlots).scrollTo(this.currentScroll);
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        boolean bl = Mouse.isButtonDown((int)0);
        int n3 = this.guiLeft;
        int n4 = this.guiTop;
        int n5 = n3 + 175;
        int n6 = n4 + 18;
        int n7 = n5 + 14;
        int n8 = n6 + 112;
        if (!this.wasClicking && bl && n >= n5 && n2 >= n6 && n < n7 && n2 < n8) {
            this.isScrolling = this.needsScrollBars();
        }
        if (!bl) {
            this.isScrolling = false;
        }
        this.wasClicking = bl;
        if (this.isScrolling) {
            this.currentScroll = ((float)(n2 - n6) - 7.5f) / ((float)(n8 - n6) - 15.0f);
            this.currentScroll = MathHelper.clamp(this.currentScroll, 0.0f, 1.0f);
            ((ContainerCreative)this.inventorySlots).scrollTo(this.currentScroll);
        }
        super.drawScreen(n, n2, f);
        for (CreativeTabs creativeTabs : CreativeTabs.CREATIVE_TAB_ARRAY) {
            if (this.renderCreativeInventoryHoveringText(creativeTabs, n, n2)) break;
        }
        if (this.destroyItemSlot != null && selectedTabIndex == CreativeTabs.INVENTORY.getTabIndex() && this.isPointInRegion(this.destroyItemSlot.xDisplayPosition, this.destroyItemSlot.yDisplayPosition, 16, 16, n, n2)) {
            this.drawCreativeTabHoveringText(I18n.format("inventory.binSlot", new Object[0]), n, n2);
        }
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.disableLighting();
        this.func_191948_b(n, n2);
    }

    @Override
    protected void renderToolTip(ItemStack itemStack, int n, int n2) {
        if (selectedTabIndex == CreativeTabs.SEARCH.getTabIndex()) {
            Map<Enchantment, Integer> map;
            List<String> list = itemStack.getTooltip(GuiContainerCreative.mc.player, GuiContainerCreative.mc.gameSettings.advancedItemTooltips ? ITooltipFlag.TooltipFlags.ADVANCED : ITooltipFlag.TooltipFlags.NORMAL);
            CreativeTabs creativeTabs = itemStack.getItem().getCreativeTab();
            if (creativeTabs == null && itemStack.getItem() == Items.ENCHANTED_BOOK && (map = EnchantmentHelper.getEnchantments(itemStack)).size() == 1) {
                Enchantment enchantment = map.keySet().iterator().next();
                for (CreativeTabs creativeTabs2 : CreativeTabs.CREATIVE_TAB_ARRAY) {
                    if (!creativeTabs2.hasRelevantEnchantmentType(enchantment.type)) continue;
                    creativeTabs = creativeTabs2;
                    break;
                }
            }
            if (creativeTabs != null) {
                list.add(1, String.valueOf((Object)TextFormatting.BOLD) + String.valueOf((Object)TextFormatting.BLUE) + I18n.format(creativeTabs.getTranslatedTabLabel(), new Object[0]));
            }
            for (int i = 0; i < list.size(); ++i) {
                if (i == 0) {
                    list.set(i, String.valueOf((Object)itemStack.getRarity().rarityColor) + list.get(i));
                    continue;
                }
                list.set(i, String.valueOf((Object)TextFormatting.GRAY) + list.get(i));
            }
            this.drawHoveringText(list, n, n2);
        } else {
            super.renderToolTip(itemStack, n, n2);
        }
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int n, int n2) {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        RenderHelper.enableGUIStandardItemLighting();
        CreativeTabs creativeTabs = CreativeTabs.CREATIVE_TAB_ARRAY[selectedTabIndex];
        for (CreativeTabs creativeTabs2 : CreativeTabs.CREATIVE_TAB_ARRAY) {
            mc.getTextureManager().bindTexture(CREATIVE_INVENTORY_TABS);
            if (creativeTabs2.getTabIndex() == selectedTabIndex) continue;
            this.drawTab(creativeTabs2);
        }
        mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/creative_inventory/tab_" + creativeTabs.getBackgroundImageName()));
        this.drawTexturedModalRect(this.guiLeft, this.guiTop, 0, 0, this.xSize, this.ySize);
        this.searchField.drawTextBox();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        int n3 = this.guiLeft + 175;
        int n4 = this.guiTop + 18;
        int n5 = n4 + 112;
        mc.getTextureManager().bindTexture(CREATIVE_INVENTORY_TABS);
        if (creativeTabs.shouldHidePlayerInventory()) {
            this.drawTexturedModalRect(n3, n4 + (int)((float)(n5 - n4 - 17) * this.currentScroll), 232 + (this.needsScrollBars() ? 0 : 12), 0, 12, 15);
        }
        this.drawTab(creativeTabs);
        if (creativeTabs == CreativeTabs.INVENTORY) {
            GuiInventory.drawEntityOnScreen(this.guiLeft + 88, this.guiTop + 45, 20, this.guiLeft + 88 - n, this.guiTop + 45 - 30 - n2, GuiContainerCreative.mc.player);
        }
    }

    protected boolean isMouseOverTab(CreativeTabs creativeTabs, int n, int n2) {
        int n3 = creativeTabs.getTabColumn();
        int n4 = 28 * n3;
        int n5 = 0;
        if (creativeTabs.func_192394_m()) {
            n4 = this.xSize - 28 * (6 - n3) + 2;
        } else if (n3 > 0) {
            n4 += n3;
        }
        n5 = creativeTabs.isTabInFirstRow() ? (n5 -= 32) : (n5 += this.ySize);
        return n >= n4 && n <= n4 + 28 && n2 >= n5 && n2 <= n5 + 32;
    }

    protected boolean renderCreativeInventoryHoveringText(CreativeTabs creativeTabs, int n, int n2) {
        int n3 = creativeTabs.getTabColumn();
        int n4 = 28 * n3;
        int n5 = 0;
        if (creativeTabs.func_192394_m()) {
            n4 = this.xSize - 28 * (6 - n3) + 2;
        } else if (n3 > 0) {
            n4 += n3;
        }
        n5 = creativeTabs.isTabInFirstRow() ? (n5 -= 32) : (n5 += this.ySize);
        if (this.isPointInRegion(n4 + 3, n5 + 3, 23, 27, n, n2)) {
            this.drawCreativeTabHoveringText(I18n.format(creativeTabs.getTranslatedTabLabel(), new Object[0]), n, n2);
            return true;
        }
        return false;
    }

    protected void drawTab(CreativeTabs creativeTabs) {
        boolean bl = creativeTabs.getTabIndex() == selectedTabIndex;
        boolean bl2 = creativeTabs.isTabInFirstRow();
        int n = creativeTabs.getTabColumn();
        int n2 = n * 28;
        int n3 = 0;
        int n4 = this.guiLeft + 28 * n;
        int n5 = this.guiTop;
        int n6 = 32;
        if (bl) {
            n3 += 32;
        }
        if (creativeTabs.func_192394_m()) {
            n4 = this.guiLeft + this.xSize - 28 * (6 - n);
        } else if (n > 0) {
            n4 += n;
        }
        if (bl2) {
            n5 -= 28;
        } else {
            n3 += 64;
            n5 += this.ySize - 4;
        }
        GlStateManager.disableLighting();
        this.drawTexturedModalRect(n4, n5, n2, n3, 28, 32);
        this.zLevel = 100.0f;
        this.itemRender.zLevel = 100.0f;
        n5 = n5 + 8 + (bl2 ? 1 : -1);
        GlStateManager.enableLighting();
        GlStateManager.enableRescaleNormal();
        ItemStack itemStack = creativeTabs.getIconItemStack();
        this.itemRender.renderItemAndEffectIntoGUI(itemStack, n4 += 6, n5);
        this.itemRender.renderItemOverlays(this.fontRendererObj, itemStack, n4, n5);
        GlStateManager.disableLighting();
        this.itemRender.zLevel = 0.0f;
        this.zLevel = 0.0f;
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.id == 1) {
            mc.displayGuiScreen(new GuiStats(this, GuiContainerCreative.mc.player.getStatFileWriter()));
        }
    }

    public int getSelectedTabIndex() {
        return selectedTabIndex;
    }

    public static void func_192044_a(Minecraft minecraft, int n, boolean bl, boolean bl2) {
        EntityPlayerSP entityPlayerSP = minecraft.player;
        CreativeSettings creativeSettings = minecraft.field_191950_u;
        HotbarSnapshot hotbarSnapshot = creativeSettings.func_192563_a(n);
        if (bl) {
            for (int i = 0; i < InventoryPlayer.getHotbarSize(); ++i) {
                ItemStack itemStack = ((ItemStack)hotbarSnapshot.get(i)).copy();
                entityPlayerSP.inventory.setInventorySlotContents(i, itemStack);
                minecraft.playerController.sendSlotPacket(itemStack, 36 + i);
            }
            entityPlayerSP.inventoryContainer.detectAndSendChanges();
        } else if (bl2) {
            for (int i = 0; i < InventoryPlayer.getHotbarSize(); ++i) {
                hotbarSnapshot.set(i, entityPlayerSP.inventory.getStackInSlot(i).copy());
            }
            String string = GameSettings.getKeyDisplayString(minecraft.gameSettings.keyBindsHotbar[n].getKeyCode());
            String string2 = GameSettings.getKeyDisplayString(minecraft.gameSettings.field_193630_aq.getKeyCode());
            minecraft.ingameGUI.setRecordPlaying(new TextComponentTranslation("inventory.hotbarSaved", string2, string), false);
            creativeSettings.func_192564_b();
        }
    }

    public static class ContainerCreative
    extends Container {
        public NonNullList<ItemStack> itemList = NonNullList.func_191196_a();

        public ContainerCreative(EntityPlayer entityPlayer) {
            int n;
            InventoryPlayer inventoryPlayer = entityPlayer.inventory;
            for (n = 0; n < 5; ++n) {
                for (int i = 0; i < 9; ++i) {
                    this.addSlotToContainer(new LockedSlot(basicInventory, n * 9 + i, 9 + i * 18, 18 + n * 18));
                }
            }
            for (n = 0; n < 9; ++n) {
                this.addSlotToContainer(new Slot(inventoryPlayer, n, 9 + n * 18, 112));
            }
            this.scrollTo(0.0f);
        }

        @Override
        public boolean canInteractWith(EntityPlayer entityPlayer) {
            return true;
        }

        public void scrollTo(float f) {
            int n = (this.itemList.size() + 9 - 1) / 9 - 5;
            int n2 = (int)((double)(f * (float)n) + 0.5);
            if (n2 < 0) {
                n2 = 0;
            }
            for (int i = 0; i < 5; ++i) {
                for (int j = 0; j < 9; ++j) {
                    int n3 = j + (i + n2) * 9;
                    if (n3 >= 0 && n3 < this.itemList.size()) {
                        basicInventory.setInventorySlotContents(j + i * 9, this.itemList.get(n3));
                        continue;
                    }
                    basicInventory.setInventorySlotContents(j + i * 9, ItemStack.field_190927_a);
                }
            }
        }

        public boolean canScroll() {
            return this.itemList.size() > 45;
        }

        @Override
        public ItemStack transferStackInSlot(EntityPlayer entityPlayer, int n) {
            Slot slot;
            if (n >= this.inventorySlots.size() - 9 && n < this.inventorySlots.size() && (slot = (Slot)this.inventorySlots.get(n)) != null && slot.getHasStack()) {
                slot.putStack(ItemStack.field_190927_a);
            }
            return ItemStack.field_190927_a;
        }

        @Override
        public boolean canMergeSlot(ItemStack itemStack, Slot slot) {
            return slot.yDisplayPosition > 90;
        }

        @Override
        public boolean canDragIntoSlot(Slot slot) {
            return slot.inventory instanceof InventoryPlayer || slot.yDisplayPosition > 90 && slot.xDisplayPosition <= 162;
        }
    }

    class CreativeSlot
    extends Slot {
        private final Slot slot;

        public CreativeSlot(Slot slot, int n) {
            super(slot.inventory, n, 0, 0);
            this.slot = slot;
        }

        @Override
        public ItemStack func_190901_a(EntityPlayer entityPlayer, ItemStack itemStack) {
            this.slot.func_190901_a(entityPlayer, itemStack);
            return itemStack;
        }

        @Override
        public boolean isItemValid(ItemStack itemStack) {
            return this.slot.isItemValid(itemStack);
        }

        @Override
        public ItemStack getStack() {
            return this.slot.getStack();
        }

        @Override
        public boolean getHasStack() {
            return this.slot.getHasStack();
        }

        @Override
        public void putStack(ItemStack itemStack) {
            this.slot.putStack(itemStack);
        }

        @Override
        public void onSlotChanged() {
            this.slot.onSlotChanged();
        }

        @Override
        public int getSlotStackLimit() {
            return this.slot.getSlotStackLimit();
        }

        @Override
        public int getItemStackLimit(ItemStack itemStack) {
            return this.slot.getItemStackLimit(itemStack);
        }

        @Override
        @Nullable
        public String getSlotTexture() {
            return this.slot.getSlotTexture();
        }

        @Override
        public ItemStack decrStackSize(int n) {
            return this.slot.decrStackSize(n);
        }

        @Override
        public boolean isHere(IInventory iInventory, int n) {
            return this.slot.isHere(iInventory, n);
        }

        @Override
        public boolean canBeHovered() {
            return this.slot.canBeHovered();
        }

        @Override
        public boolean canTakeStack(EntityPlayer entityPlayer) {
            return this.slot.canTakeStack(entityPlayer);
        }
    }

    static class LockedSlot
    extends Slot {
        public LockedSlot(IInventory iInventory, int n, int n2, int n3) {
            super(iInventory, n, n2, n3);
        }

        @Override
        public boolean canTakeStack(EntityPlayer entityPlayer) {
            if (super.canTakeStack(entityPlayer) && this.getHasStack()) {
                return this.getStack().getSubCompound("CustomCreativeLock") == null;
            }
            return !this.getHasStack();
        }
    }
}
