package net.minecraft.client.gui.inventory;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class CreativeCrafting
implements IContainerListener {
    private final Minecraft mc;

    public CreativeCrafting(Minecraft minecraft) {
        this.mc = minecraft;
    }

    @Override
    public void updateCraftingInventory(Container container, NonNullList<ItemStack> nonNullList) {
    }

    @Override
    public void sendSlotContents(Container container, int n, ItemStack itemStack) {
        this.mc.playerController.sendSlotPacket(itemStack, n);
    }

    @Override
    public void sendProgressBarUpdate(Container container, int n, int n2) {
    }

    @Override
    public void sendAllWindowProperties(Container container, IInventory iInventory) {
    }
}
