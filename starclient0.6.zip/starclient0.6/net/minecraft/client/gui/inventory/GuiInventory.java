package net.minecraft.client.gui.inventory;

import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiButtonImage;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.recipebook.GuiRecipeBook;
import net.minecraft.client.gui.recipebook.IRecipeShownListener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.Slot;

public class GuiInventory
extends InventoryEffectRenderer
implements IRecipeShownListener {
    private float oldMouseX;
    private float oldMouseY;
    private GuiButtonImage field_192048_z;
    private final GuiRecipeBook field_192045_A = new GuiRecipeBook();
    private boolean field_192046_B;
    private boolean field_194031_B;

    public GuiInventory(EntityPlayer entityPlayer) {
        super(entityPlayer.inventoryContainer);
        this.allowUserInput = true;
    }

    @Override
    public void updateScreen() {
        if (GuiInventory.mc.playerController.isInCreativeMode()) {
            mc.displayGuiScreen(new GuiContainerCreative(GuiInventory.mc.player));
        }
        this.field_192045_A.func_193957_d();
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        if (GuiInventory.mc.playerController.isInCreativeMode()) {
            mc.displayGuiScreen(new GuiContainerCreative(GuiInventory.mc.player));
        } else {
            super.initGui();
        }
        this.field_192046_B = this.width < 379;
        this.field_192045_A.func_194303_a(this.width, this.height, mc, this.field_192046_B, ((ContainerPlayer)this.inventorySlots).craftMatrix);
        this.guiLeft = this.field_192045_A.func_193011_a(this.field_192046_B, this.width, this.xSize);
        this.field_192048_z = new GuiButtonImage(10, this.guiLeft + 104, this.height / 2 - 22, 20, 18, 178, 0, 19, INVENTORY_BACKGROUND);
        this.buttonList.add(this.field_192048_z);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int n, int n2) {
        this.fontRendererObj.drawString(I18n.format("container.crafting", new Object[0]), 97, 8, 0x404040);
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        boolean bl = this.hasActivePotionEffects = !this.field_192045_A.func_191878_b();
        if (this.field_192045_A.func_191878_b() && this.field_192046_B) {
            this.drawGuiContainerBackgroundLayer(f, n, n2);
            this.field_192045_A.func_191861_a(n, n2, f);
        } else {
            this.field_192045_A.func_191861_a(n, n2, f);
            super.drawScreen(n, n2, f);
            this.field_192045_A.func_191864_a(this.guiLeft, this.guiTop, false, f);
        }
        this.func_191948_b(n, n2);
        this.field_192045_A.func_191876_c(this.guiLeft, this.guiTop, n, n2);
        this.oldMouseX = n;
        this.oldMouseY = n2;
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int n, int n2) {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        mc.getTextureManager().bindTexture(INVENTORY_BACKGROUND);
        int n3 = this.guiLeft;
        int n4 = this.guiTop;
        this.drawTexturedModalRect(n3, n4, 0, 0, this.xSize, this.ySize);
        GuiInventory.drawEntityOnScreen(n3 + 51, n4 + 75, 30, (float)(n3 + 51) - this.oldMouseX, (float)(n4 + 75 - 50) - this.oldMouseY, GuiInventory.mc.player);
    }

    public static void drawEntityOnScreen(int n, int n2, int n3, float f, float f2, EntityLivingBase entityLivingBase) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate(n, n2, 50.0f);
        GlStateManager.scale(-n3, n3, n3);
        GlStateManager.rotate(180.0f, 0.0f, 0.0f, 1.0f);
        float f3 = entityLivingBase.renderYawOffset;
        float f4 = entityLivingBase.rotationYaw;
        float f5 = entityLivingBase.rotationPitch;
        float f6 = entityLivingBase.prevRotationYawHead;
        float f7 = entityLivingBase.rotationYawHead;
        GlStateManager.rotate(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(-((float)Math.atan(f2 / 40.0f)) * 20.0f, 1.0f, 0.0f, 0.0f);
        entityLivingBase.renderYawOffset = (float)Math.atan(f / 40.0f) * 20.0f;
        entityLivingBase.rotationYaw = (float)Math.atan(f / 40.0f) * 40.0f;
        entityLivingBase.rotationPitch = -((float)Math.atan(f2 / 40.0f)) * 20.0f;
        entityLivingBase.rotationYawHead = entityLivingBase.rotationYaw;
        entityLivingBase.prevRotationYawHead = entityLivingBase.rotationYaw;
        GlStateManager.translate(0.0f, 0.0f, 0.0f);
        RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
        renderManager.setPlayerViewY(180.0f);
        renderManager.setRenderShadow(false);
        renderManager.doRenderEntity(entityLivingBase, 0.0, 0.0, 0.0, 0.0f, 1.0f, false);
        renderManager.setRenderShadow(true);
        entityLivingBase.renderYawOffset = f3;
        entityLivingBase.rotationYaw = f4;
        entityLivingBase.rotationPitch = f5;
        entityLivingBase.prevRotationYawHead = f6;
        entityLivingBase.rotationYawHead = f7;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    }

    @Override
    protected boolean isPointInRegion(int n, int n2, int n3, int n4, int n5, int n6) {
        return (!this.field_192046_B || !this.field_192045_A.func_191878_b()) && super.isPointInRegion(n, n2, n3, n4, n5, n6);
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        if (!(this.field_192045_A.func_191862_a(n, n2, n3) || this.field_192046_B && this.field_192045_A.func_191878_b())) {
            super.mouseClicked(n, n2, n3);
        }
    }

    @Override
    protected void mouseReleased(int n, int n2, int n3) {
        if (this.field_194031_B) {
            this.field_194031_B = false;
        } else {
            super.mouseReleased(n, n2, n3);
        }
    }

    @Override
    protected boolean func_193983_c(int n, int n2, int n3, int n4) {
        boolean bl = n < n3 || n2 < n4 || n >= n3 + this.xSize || n2 >= n4 + this.ySize;
        return this.field_192045_A.func_193955_c(n, n2, this.guiLeft, this.guiTop, this.xSize, this.ySize) && bl;
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.id == 10) {
            this.field_192045_A.func_193014_a(this.field_192046_B, ((ContainerPlayer)this.inventorySlots).craftMatrix);
            this.field_192045_A.func_191866_a();
            this.guiLeft = this.field_192045_A.func_193011_a(this.field_192046_B, this.width, this.xSize);
            this.field_192048_z.func_191746_c(this.guiLeft + 104, this.height / 2 - 22);
            this.field_194031_B = true;
        }
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        if (!this.field_192045_A.func_191859_a(c, n)) {
            super.keyTyped(c, n);
        }
    }

    @Override
    protected void handleMouseClick(Slot slot, int n, int n2, ClickType clickType) {
        super.handleMouseClick(slot, n, n2, clickType);
        this.field_192045_A.func_191874_a(slot);
    }

    @Override
    public void func_192043_J_() {
        this.field_192045_A.func_193948_e();
    }

    @Override
    public void onGuiClosed() {
        this.field_192045_A.func_191871_c();
        super.onGuiClosed();
    }

    @Override
    public GuiRecipeBook func_194310_f() {
        return this.field_192045_A;
    }
}
