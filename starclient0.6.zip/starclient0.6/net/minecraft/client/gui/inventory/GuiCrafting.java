package net.minecraft.client.gui.inventory;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiButtonImage;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.recipebook.GuiRecipeBook;
import net.minecraft.client.gui.recipebook.IRecipeShownListener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.inventory.Slot;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class GuiCrafting
extends GuiContainer
implements IRecipeShownListener {
    private static final ResourceLocation CRAFTING_TABLE_GUI_TEXTURES = new ResourceLocation("textures/gui/container/crafting_table.png");
    private GuiButtonImage field_192049_w;
    private final GuiRecipeBook field_192050_x = new GuiRecipeBook();
    private boolean field_193112_y;

    public GuiCrafting(InventoryPlayer inventoryPlayer, World world) {
        this(inventoryPlayer, world, BlockPos.ORIGIN);
    }

    public GuiCrafting(InventoryPlayer inventoryPlayer, World world, BlockPos blockPos) {
        super(new ContainerWorkbench(inventoryPlayer, world, blockPos));
    }

    @Override
    public void initGui() {
        super.initGui();
        this.field_193112_y = this.width < 379;
        this.field_192050_x.func_194303_a(this.width, this.height, mc, this.field_193112_y, ((ContainerWorkbench)this.inventorySlots).craftMatrix);
        this.guiLeft = this.field_192050_x.func_193011_a(this.field_193112_y, this.width, this.xSize);
        this.field_192049_w = new GuiButtonImage(10, this.guiLeft + 5, this.height / 2 - 49, 20, 18, 0, 168, 19, CRAFTING_TABLE_GUI_TEXTURES);
        this.buttonList.add(this.field_192049_w);
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        this.field_192050_x.func_193957_d();
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        if (this.field_192050_x.func_191878_b() && this.field_193112_y) {
            this.drawGuiContainerBackgroundLayer(f, n, n2);
            this.field_192050_x.func_191861_a(n, n2, f);
        } else {
            this.field_192050_x.func_191861_a(n, n2, f);
            super.drawScreen(n, n2, f);
            this.field_192050_x.func_191864_a(this.guiLeft, this.guiTop, true, f);
        }
        this.func_191948_b(n, n2);
        this.field_192050_x.func_191876_c(this.guiLeft, this.guiTop, n, n2);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int n, int n2) {
        this.fontRendererObj.drawString(I18n.format("container.crafting", new Object[0]), 28, 6, 0x404040);
        this.fontRendererObj.drawString(I18n.format("container.inventory", new Object[0]), 8, this.ySize - 96 + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int n, int n2) {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        mc.getTextureManager().bindTexture(CRAFTING_TABLE_GUI_TEXTURES);
        int n3 = this.guiLeft;
        int n4 = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(n3, n4, 0, 0, this.xSize, this.ySize);
    }

    @Override
    protected boolean isPointInRegion(int n, int n2, int n3, int n4, int n5, int n6) {
        return (!this.field_193112_y || !this.field_192050_x.func_191878_b()) && super.isPointInRegion(n, n2, n3, n4, n5, n6);
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        if (!(this.field_192050_x.func_191862_a(n, n2, n3) || this.field_193112_y && this.field_192050_x.func_191878_b())) {
            super.mouseClicked(n, n2, n3);
        }
    }

    @Override
    protected boolean func_193983_c(int n, int n2, int n3, int n4) {
        boolean bl = n < n3 || n2 < n4 || n >= n3 + this.xSize || n2 >= n4 + this.ySize;
        return this.field_192050_x.func_193955_c(n, n2, this.guiLeft, this.guiTop, this.xSize, this.ySize) && bl;
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.id == 10) {
            this.field_192050_x.func_193014_a(this.field_193112_y, ((ContainerWorkbench)this.inventorySlots).craftMatrix);
            this.field_192050_x.func_191866_a();
            this.guiLeft = this.field_192050_x.func_193011_a(this.field_193112_y, this.width, this.xSize);
            this.field_192049_w.func_191746_c(this.guiLeft + 5, this.height / 2 - 49);
        }
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        if (!this.field_192050_x.func_191859_a(c, n)) {
            super.keyTyped(c, n);
        }
    }

    @Override
    protected void handleMouseClick(Slot slot, int n, int n2, ClickType clickType) {
        super.handleMouseClick(slot, n, n2, clickType);
        this.field_192050_x.func_191874_a(slot);
    }

    @Override
    public void func_192043_J_() {
        this.field_192050_x.func_193948_e();
    }

    @Override
    public void onGuiClosed() {
        this.field_192050_x.func_191871_c();
        super.onGuiClosed();
    }

    @Override
    public GuiRecipeBook func_194310_f() {
        return this.field_192050_x;
    }
}
