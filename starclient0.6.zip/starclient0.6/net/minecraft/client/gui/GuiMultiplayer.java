package net.minecraft.client.gui;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiListExtended;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenAddServer;
import net.minecraft.client.gui.GuiScreenServerList;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.ServerListEntryLanDetected;
import net.minecraft.client.gui.ServerListEntryLanScan;
import net.minecraft.client.gui.ServerListEntryNormal;
import net.minecraft.client.gui.ServerSelectionList;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector;
import net.minecraft.client.network.LanServerInfo;
import net.minecraft.client.network.ServerPinger;
import net.minecraft.client.resources.I18n;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayer
extends GuiScreen {
    private static final Logger LOGGER = LogManager.getLogger();
    private final ServerPinger oldServerPinger = new ServerPinger();
    private final GuiScreen parentScreen;
    private ServerSelectionList serverListSelector;
    private ServerList savedServerList;
    private GuiButton btnEditServer;
    private GuiButton btnSelectServer;
    private GuiButton btnDeleteServer;
    private boolean deletingServer;
    private boolean addingServer;
    private boolean editingServer;
    private boolean directConnect;
    private String hoveringText;
    private ServerData selectedServer;
    private LanServerDetector.LanServerList lanServerList;
    private LanServerDetector.ThreadLanServerFind lanServerDetector;
    private boolean initialized;

    public GuiMultiplayer(GuiScreen guiScreen) {
        this.parentScreen = guiScreen;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.buttonList.clear();
        if (this.initialized) {
            this.serverListSelector.setDimensions(this.width, this.height, 32, this.height - 64);
        } else {
            this.initialized = true;
            this.savedServerList = new ServerList(mc);
            this.savedServerList.loadServerList();
            this.lanServerList = new LanServerDetector.LanServerList();
            try {
                this.lanServerDetector = new LanServerDetector.ThreadLanServerFind(this.lanServerList);
                this.lanServerDetector.start();
            }
            catch (Exception exception) {
                LOGGER.warn("Unable to start LAN server detection: {}", (Object)exception.getMessage());
            }
            this.serverListSelector = new ServerSelectionList(this, mc, this.width, this.height, 32, this.height - 64, 36);
            this.serverListSelector.updateOnlineServers(this.savedServerList);
        }
        this.createButtons();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        this.serverListSelector.handleMouseInput();
    }

    public void createButtons() {
        this.btnEditServer = this.addButton(new GuiButton(7, this.width / 2 - 154, this.height - 28, 70, 20, I18n.format("selectServer.edit", new Object[0])));
        this.btnDeleteServer = this.addButton(new GuiButton(2, this.width / 2 - 74, this.height - 28, 70, 20, I18n.format("selectServer.delete", new Object[0])));
        this.btnSelectServer = this.addButton(new GuiButton(1, this.width / 2 - 154, this.height - 52, 100, 20, I18n.format("selectServer.select", new Object[0])));
        this.buttonList.add(new GuiButton(4, this.width / 2 - 50, this.height - 52, 100, 20, I18n.format("selectServer.direct", new Object[0])));
        this.buttonList.add(new GuiButton(3, this.width / 2 + 4 + 50, this.height - 52, 100, 20, I18n.format("selectServer.add", new Object[0])));
        this.buttonList.add(new GuiButton(8, this.width / 2 + 4, this.height - 28, 70, 20, I18n.format("selectServer.refresh", new Object[0])));
        this.buttonList.add(new GuiButton(0, this.width / 2 + 4 + 76, this.height - 28, 75, 20, I18n.format("gui.cancel", new Object[0])));
        this.selectServer(this.serverListSelector.getSelected());
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        if (this.lanServerList.getWasUpdated()) {
            List<LanServerInfo> list = this.lanServerList.getLanServers();
            this.lanServerList.setWasNotUpdated();
            this.serverListSelector.updateNetworkServers(list);
        }
        this.oldServerPinger.pingPendingNetworks();
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
        if (this.lanServerDetector != null) {
            this.lanServerDetector.interrupt();
            this.lanServerDetector = null;
        }
        this.oldServerPinger.clearPendingNetworks();
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        if (guiButton.enabled) {
            GuiListExtended.IGuiListEntry iGuiListEntry;
            GuiListExtended.IGuiListEntry iGuiListEntry2 = iGuiListEntry = this.serverListSelector.getSelected() < 0 ? null : this.serverListSelector.getListEntry(this.serverListSelector.getSelected());
            if (guiButton.id == 2 && iGuiListEntry instanceof ServerListEntryNormal) {
                String string = ((ServerListEntryNormal)iGuiListEntry).getServerData().serverName;
                if (string != null) {
                    this.deletingServer = true;
                    String string2 = I18n.format("selectServer.deleteQuestion", new Object[0]);
                    String string3 = "'" + string + "' " + I18n.format("selectServer.deleteWarning", new Object[0]);
                    String string4 = I18n.format("selectServer.deleteButton", new Object[0]);
                    String string5 = I18n.format("gui.cancel", new Object[0]);
                    GuiYesNo guiYesNo = new GuiYesNo(this, string2, string3, string4, string5, this.serverListSelector.getSelected());
                    mc.displayGuiScreen(guiYesNo);
                }
            } else if (guiButton.id == 1) {
                this.connectToSelected();
            } else if (guiButton.id == 4) {
                this.directConnect = true;
                this.selectedServer = new ServerData(I18n.format("selectServer.defaultName", new Object[0]), "", false);
                mc.displayGuiScreen(new GuiScreenServerList(this, this.selectedServer));
            } else if (guiButton.id == 3) {
                this.addingServer = true;
                this.selectedServer = new ServerData(I18n.format("selectServer.defaultName", new Object[0]), "", false);
                mc.displayGuiScreen(new GuiScreenAddServer(this, this.selectedServer));
            } else if (guiButton.id == 7 && iGuiListEntry instanceof ServerListEntryNormal) {
                this.editingServer = true;
                ServerData serverData = ((ServerListEntryNormal)iGuiListEntry).getServerData();
                this.selectedServer = new ServerData(serverData.serverName, serverData.serverIP, false);
                this.selectedServer.copyFrom(serverData);
                mc.displayGuiScreen(new GuiScreenAddServer(this, this.selectedServer));
            } else if (guiButton.id == 0) {
                mc.displayGuiScreen(this.parentScreen);
            } else if (guiButton.id == 8) {
                this.refreshServerList();
            }
        }
    }

    private void refreshServerList() {
        mc.displayGuiScreen(new GuiMultiplayer(this.parentScreen));
    }

    @Override
    public void confirmClicked(boolean bl, int n) {
        GuiListExtended.IGuiListEntry iGuiListEntry;
        GuiListExtended.IGuiListEntry iGuiListEntry2 = iGuiListEntry = this.serverListSelector.getSelected() < 0 ? null : this.serverListSelector.getListEntry(this.serverListSelector.getSelected());
        if (this.deletingServer) {
            this.deletingServer = false;
            if (bl && iGuiListEntry instanceof ServerListEntryNormal) {
                this.savedServerList.removeServerData(this.serverListSelector.getSelected());
                this.savedServerList.saveServerList();
                this.serverListSelector.setSelectedSlotIndex(-1);
                this.serverListSelector.updateOnlineServers(this.savedServerList);
            }
            mc.displayGuiScreen(this);
        } else if (this.directConnect) {
            this.directConnect = false;
            if (bl) {
                this.connectToServer(this.selectedServer);
            } else {
                mc.displayGuiScreen(this);
            }
        } else if (this.addingServer) {
            this.addingServer = false;
            if (bl) {
                this.savedServerList.addServerData(this.selectedServer);
                this.savedServerList.saveServerList();
                this.serverListSelector.setSelectedSlotIndex(-1);
                this.serverListSelector.updateOnlineServers(this.savedServerList);
            }
            mc.displayGuiScreen(this);
        } else if (this.editingServer) {
            this.editingServer = false;
            if (bl && iGuiListEntry instanceof ServerListEntryNormal) {
                ServerData serverData = ((ServerListEntryNormal)iGuiListEntry).getServerData();
                serverData.serverName = this.selectedServer.serverName;
                serverData.serverIP = this.selectedServer.serverIP;
                serverData.copyFrom(this.selectedServer);
                this.savedServerList.saveServerList();
                this.serverListSelector.updateOnlineServers(this.savedServerList);
            }
            mc.displayGuiScreen(this);
        }
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        GuiListExtended.IGuiListEntry iGuiListEntry;
        int n2 = this.serverListSelector.getSelected();
        GuiListExtended.IGuiListEntry iGuiListEntry2 = iGuiListEntry = n2 < 0 ? null : this.serverListSelector.getListEntry(n2);
        if (n == 63) {
            this.refreshServerList();
        } else if (n2 >= 0) {
            if (n == 200) {
                if (GuiMultiplayer.isShiftKeyDown()) {
                    if (n2 > 0 && iGuiListEntry instanceof ServerListEntryNormal) {
                        this.savedServerList.swapServers(n2, n2 - 1);
                        this.selectServer(this.serverListSelector.getSelected() - 1);
                        this.serverListSelector.scrollBy(-this.serverListSelector.getSlotHeight());
                        this.serverListSelector.updateOnlineServers(this.savedServerList);
                    }
                } else if (n2 > 0) {
                    this.selectServer(this.serverListSelector.getSelected() - 1);
                    this.serverListSelector.scrollBy(-this.serverListSelector.getSlotHeight());
                    if (this.serverListSelector.getListEntry(this.serverListSelector.getSelected()) instanceof ServerListEntryLanScan) {
                        if (this.serverListSelector.getSelected() > 0) {
                            this.selectServer(this.serverListSelector.getSize() - 1);
                            this.serverListSelector.scrollBy(-this.serverListSelector.getSlotHeight());
                        } else {
                            this.selectServer(-1);
                        }
                    }
                } else {
                    this.selectServer(-1);
                }
            } else if (n == 208) {
                if (GuiMultiplayer.isShiftKeyDown()) {
                    if (n2 < this.savedServerList.countServers() - 1) {
                        this.savedServerList.swapServers(n2, n2 + 1);
                        this.selectServer(n2 + 1);
                        this.serverListSelector.scrollBy(this.serverListSelector.getSlotHeight());
                        this.serverListSelector.updateOnlineServers(this.savedServerList);
                    }
                } else if (n2 < this.serverListSelector.getSize()) {
                    this.selectServer(this.serverListSelector.getSelected() + 1);
                    this.serverListSelector.scrollBy(this.serverListSelector.getSlotHeight());
                    if (this.serverListSelector.getListEntry(this.serverListSelector.getSelected()) instanceof ServerListEntryLanScan) {
                        if (this.serverListSelector.getSelected() < this.serverListSelector.getSize() - 1) {
                            this.selectServer(this.serverListSelector.getSize() + 1);
                            this.serverListSelector.scrollBy(this.serverListSelector.getSlotHeight());
                        } else {
                            this.selectServer(-1);
                        }
                    }
                } else {
                    this.selectServer(-1);
                }
            } else if (n != 28 && n != 156) {
                super.keyTyped(c, n);
            } else {
                this.actionPerformed((GuiButton)this.buttonList.get(2));
            }
        } else {
            super.keyTyped(c, n);
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.hoveringText = null;
        this.drawDefaultBackground();
        this.serverListSelector.drawScreen(n, n2, f);
        this.drawCenteredString(this.fontRendererObj, I18n.format("multiplayer.title", new Object[0]), this.width / 2, 20, 0xFFFFFF);
        super.drawScreen(n, n2, f);
        if (this.hoveringText != null) {
            this.drawHoveringText(Lists.newArrayList(Splitter.on("\n").split(this.hoveringText)), n, n2);
        }
    }

    public void connectToSelected() {
        GuiListExtended.IGuiListEntry iGuiListEntry;
        GuiListExtended.IGuiListEntry iGuiListEntry2 = iGuiListEntry = this.serverListSelector.getSelected() < 0 ? null : this.serverListSelector.getListEntry(this.serverListSelector.getSelected());
        if (iGuiListEntry instanceof ServerListEntryNormal) {
            this.connectToServer(((ServerListEntryNormal)iGuiListEntry).getServerData());
        } else if (iGuiListEntry instanceof ServerListEntryLanDetected) {
            LanServerInfo lanServerInfo = ((ServerListEntryLanDetected)iGuiListEntry).getServerData();
            this.connectToServer(new ServerData(lanServerInfo.getServerMotd(), lanServerInfo.getServerIpPort(), true));
        }
    }

    private void connectToServer(ServerData serverData) {
        mc.displayGuiScreen(new GuiConnecting(this, mc, serverData));
    }

    public void selectServer(int n) {
        this.serverListSelector.setSelectedSlotIndex(n);
        GuiListExtended.IGuiListEntry iGuiListEntry = n < 0 ? null : this.serverListSelector.getListEntry(n);
        this.btnSelectServer.enabled = false;
        this.btnEditServer.enabled = false;
        this.btnDeleteServer.enabled = false;
        if (iGuiListEntry != null && !(iGuiListEntry instanceof ServerListEntryLanScan)) {
            this.btnSelectServer.enabled = true;
            if (iGuiListEntry instanceof ServerListEntryNormal) {
                this.btnEditServer.enabled = true;
                this.btnDeleteServer.enabled = true;
            }
        }
    }

    public ServerPinger getOldServerPinger() {
        return this.oldServerPinger;
    }

    public void setHoveringText(String string) {
        this.hoveringText = string;
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        super.mouseClicked(n, n2, n3);
        this.serverListSelector.mouseClicked(n, n2, n3);
    }

    @Override
    protected void mouseReleased(int n, int n2, int n3) {
        super.mouseReleased(n, n2, n3);
        this.serverListSelector.mouseReleased(n, n2, n3);
    }

    public ServerList getServerList() {
        return this.savedServerList;
    }

    public boolean canMoveUp(ServerListEntryNormal serverListEntryNormal, int n) {
        return n > 0;
    }

    public boolean canMoveDown(ServerListEntryNormal serverListEntryNormal, int n) {
        return n < this.savedServerList.countServers() - 1;
    }

    public void moveServerUp(ServerListEntryNormal serverListEntryNormal, int n, boolean bl) {
        int n2 = bl ? 0 : n - 1;
        this.savedServerList.swapServers(n, n2);
        if (this.serverListSelector.getSelected() == n) {
            this.selectServer(n2);
        }
        this.serverListSelector.updateOnlineServers(this.savedServerList);
    }

    public void moveServerDown(ServerListEntryNormal serverListEntryNormal, int n, boolean bl) {
        int n2 = bl ? this.savedServerList.countServers() - 1 : n + 1;
        this.savedServerList.swapServers(n, n2);
        if (this.serverListSelector.getSelected() == n) {
            this.selectServer(n2);
        }
        this.serverListSelector.updateOnlineServers(this.savedServerList);
    }
}
