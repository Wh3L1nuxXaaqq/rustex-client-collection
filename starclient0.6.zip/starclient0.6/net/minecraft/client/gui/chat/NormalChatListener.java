package net.minecraft.client.gui.chat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.IChatListener;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;

public class NormalChatListener
implements IChatListener {
    private final Minecraft field_192581_a;

    public NormalChatListener(Minecraft minecraft) {
        this.field_192581_a = minecraft;
    }

    @Override
    public void func_192576_a(ChatType chatType, ITextComponent iTextComponent) {
        this.field_192581_a.ingameGUI.getChatGUI().printChatMessage(iTextComponent);
    }
}
