package net.minecraft.client.gui.chat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.IChatListener;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;

public class OverlayChatListener
implements IChatListener {
    private final Minecraft field_192577_a;

    public OverlayChatListener(Minecraft minecraft) {
        this.field_192577_a = minecraft;
    }

    @Override
    public void func_192576_a(ChatType chatType, ITextComponent iTextComponent) {
        this.field_192577_a.ingameGUI.setRecordPlaying(iTextComponent, false);
    }
}
