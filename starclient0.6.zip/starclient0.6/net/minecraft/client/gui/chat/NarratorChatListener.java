package net.minecraft.client.gui.chat;

import com.mojang.text2speech.Narrator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.IChatListener;
import net.minecraft.client.gui.toasts.GuiToast;
import net.minecraft.client.gui.toasts.SystemToast;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;

public class NarratorChatListener
implements IChatListener {
    public static final NarratorChatListener field_193643_a = new NarratorChatListener();
    private final Narrator field_192580_a = Narrator.getNarrator();

    @Override
    public void func_192576_a(ChatType chatType, ITextComponent iTextComponent) {
        int n = Minecraft.getMinecraft().gameSettings.field_192571_R;
        if (n != 0 && this.field_192580_a.active() && (n == 1 || n == 2 && chatType == ChatType.CHAT || n == 3 && chatType == ChatType.SYSTEM)) {
            if (iTextComponent instanceof TextComponentTranslation && "chat.type.text".equals(((TextComponentTranslation)iTextComponent).getKey())) {
                this.field_192580_a.say(new TextComponentTranslation("chat.type.text.narrate", ((TextComponentTranslation)iTextComponent).getFormatArgs()).getUnformattedText());
            } else {
                this.field_192580_a.say(iTextComponent.getUnformattedText());
            }
        }
    }

    public void func_193641_a(int n) {
        this.field_192580_a.clear();
        this.field_192580_a.say(new TextComponentTranslation("options.narrator", new Object[0]).getUnformattedText() + " : " + new TextComponentTranslation(GameSettings.field_193632_b[n], new Object[0]).getUnformattedText());
        GuiToast guiToast = Minecraft.getMinecraft().func_193033_an();
        if (this.field_192580_a.active()) {
            if (n == 0) {
                SystemToast.func_193657_a(guiToast, SystemToast.Type.NARRATOR_TOGGLE, new TextComponentTranslation("narrator.toast.disabled", new Object[0]), null);
            } else {
                SystemToast.func_193657_a(guiToast, SystemToast.Type.NARRATOR_TOGGLE, new TextComponentTranslation("narrator.toast.enabled", new Object[0]), new TextComponentTranslation(GameSettings.field_193632_b[n], new Object[0]));
            }
        } else {
            SystemToast.func_193657_a(guiToast, SystemToast.Type.NARRATOR_TOGGLE, new TextComponentTranslation("narrator.toast.disabled", new Object[0]), new TextComponentTranslation("options.narrator.notavailable", new Object[0]));
        }
    }

    public boolean func_193640_a() {
        return this.field_192580_a.active();
    }

    public void func_193642_b() {
        this.field_192580_a.clear();
    }
}
