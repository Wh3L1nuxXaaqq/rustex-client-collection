package net.minecraft.util;

import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.util.math.MathHelper;

public class CooldownTracker {
    private final Map<Item, Cooldown> cooldowns = Maps.newHashMap();
    private int ticks;

    public boolean hasCooldown(Item item) {
        return this.getCooldown(item, 0.0f) > 0.0f;
    }

    public float getCooldown(Item item, float f) {
        Cooldown cooldown = this.cooldowns.get(item);
        if (cooldown != null) {
            float f2 = cooldown.expireTicks - cooldown.createTicks;
            float f3 = (float)cooldown.expireTicks - ((float)this.ticks + f);
            return MathHelper.clamp(f3 / f2, 0.0f, 1.0f);
        }
        return 0.0f;
    }

    public void tick() {
        ++this.ticks;
        if (!this.cooldowns.isEmpty()) {
            Iterator<Map.Entry<Item, Cooldown>> iterator = this.cooldowns.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Item, Cooldown> entry = iterator.next();
                if (entry.getValue().expireTicks > this.ticks) continue;
                iterator.remove();
                this.notifyOnRemove(entry.getKey());
            }
        }
    }

    public void setCooldown(Item item, int n) {
        this.cooldowns.put(item, new Cooldown(this.ticks, this.ticks + n));
        this.notifyOnSet(item, n);
    }

    public void removeCooldown(Item item) {
        this.cooldowns.remove(item);
        this.notifyOnRemove(item);
    }

    protected void notifyOnSet(Item item, int n) {
    }

    protected void notifyOnRemove(Item item) {
    }

    class Cooldown {
        final int createTicks;
        final int expireTicks;

        private Cooldown(int n, int n2) {
            this.createTicks = n;
            this.expireTicks = n2;
        }
    }
}
