package net.minecraft.util;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.Explosion;

public class DamageSource {
    public static final DamageSource inFire = new DamageSource("inFire").setFireDamage();
    public static final DamageSource lightningBolt = new DamageSource("lightningBolt");
    public static final DamageSource onFire = new DamageSource("onFire").setDamageBypassesArmor().setFireDamage();
    public static final DamageSource lava = new DamageSource("lava").setFireDamage();
    public static final DamageSource hotFloor = new DamageSource("hotFloor").setFireDamage();
    public static final DamageSource inWall = new DamageSource("inWall").setDamageBypassesArmor();
    public static final DamageSource field_191291_g = new DamageSource("cramming").setDamageBypassesArmor();
    public static final DamageSource drown = new DamageSource("drown").setDamageBypassesArmor();
    public static final DamageSource starve = new DamageSource("starve").setDamageBypassesArmor().setDamageIsAbsolute();
    public static final DamageSource cactus = new DamageSource("cactus");
    public static final DamageSource fall = new DamageSource("fall").setDamageBypassesArmor();
    public static final DamageSource flyIntoWall = new DamageSource("flyIntoWall").setDamageBypassesArmor();
    public static final DamageSource outOfWorld = new DamageSource("outOfWorld").setDamageBypassesArmor().setDamageAllowedInCreativeMode();
    public static final DamageSource generic = new DamageSource("generic").setDamageBypassesArmor();
    public static final DamageSource magic = new DamageSource("magic").setDamageBypassesArmor().setMagicDamage();
    public static final DamageSource wither = new DamageSource("wither").setDamageBypassesArmor();
    public static final DamageSource anvil = new DamageSource("anvil");
    public static final DamageSource fallingBlock = new DamageSource("fallingBlock");
    public static final DamageSource dragonBreath = new DamageSource("dragonBreath").setDamageBypassesArmor();
    public static final DamageSource field_191552_t = new DamageSource("fireworks").setExplosion();
    private boolean isUnblockable;
    private boolean isDamageAllowedInCreativeMode;
    private boolean damageIsAbsolute;
    private float hungerDamage = 0.1f;
    private boolean fireDamage;
    private boolean projectile;
    private boolean difficultyScaled;
    private boolean magicDamage;
    private boolean explosion;
    public String damageType;

    public static DamageSource causeMobDamage(EntityLivingBase entityLivingBase) {
        return new EntityDamageSource("mob", entityLivingBase);
    }

    public static DamageSource causeIndirectDamage(Entity entity, EntityLivingBase entityLivingBase) {
        return new EntityDamageSourceIndirect("mob", entity, entityLivingBase);
    }

    public static DamageSource causePlayerDamage(EntityPlayer entityPlayer) {
        return new EntityDamageSource("player", entityPlayer);
    }

    public static DamageSource causeArrowDamage(EntityArrow entityArrow, @Nullable Entity entity) {
        return new EntityDamageSourceIndirect("arrow", entityArrow, entity).setProjectile();
    }

    public static DamageSource causeFireballDamage(EntityFireball entityFireball, @Nullable Entity entity) {
        return entity == null ? new EntityDamageSourceIndirect("onFire", entityFireball, entityFireball).setFireDamage().setProjectile() : new EntityDamageSourceIndirect("fireball", entityFireball, entity).setFireDamage().setProjectile();
    }

    public static DamageSource causeThrownDamage(Entity entity, @Nullable Entity entity2) {
        return new EntityDamageSourceIndirect("thrown", entity, entity2).setProjectile();
    }

    public static DamageSource causeIndirectMagicDamage(Entity entity, @Nullable Entity entity2) {
        return new EntityDamageSourceIndirect("indirectMagic", entity, entity2).setDamageBypassesArmor().setMagicDamage();
    }

    public static DamageSource causeThornsDamage(Entity entity) {
        return new EntityDamageSource("thorns", entity).setIsThornsDamage().setMagicDamage();
    }

    public static DamageSource causeExplosionDamage(@Nullable Explosion explosion) {
        return explosion != null && explosion.getExplosivePlacedBy() != null ? new EntityDamageSource("explosion.player", explosion.getExplosivePlacedBy()).setDifficultyScaled().setExplosion() : new DamageSource("explosion").setDifficultyScaled().setExplosion();
    }

    public static DamageSource causeExplosionDamage(@Nullable EntityLivingBase entityLivingBase) {
        return entityLivingBase != null ? new EntityDamageSource("explosion.player", entityLivingBase).setDifficultyScaled().setExplosion() : new DamageSource("explosion").setDifficultyScaled().setExplosion();
    }

    public boolean isProjectile() {
        return this.projectile;
    }

    public DamageSource setProjectile() {
        this.projectile = true;
        return this;
    }

    public boolean isExplosion() {
        return this.explosion;
    }

    public DamageSource setExplosion() {
        this.explosion = true;
        return this;
    }

    public boolean isUnblockable() {
        return this.isUnblockable;
    }

    public float getHungerDamage() {
        return this.hungerDamage;
    }

    public boolean canHarmInCreative() {
        return this.isDamageAllowedInCreativeMode;
    }

    public boolean isDamageAbsolute() {
        return this.damageIsAbsolute;
    }

    protected DamageSource(String string) {
        this.damageType = string;
    }

    @Nullable
    public Entity getSourceOfDamage() {
        return this.getEntity();
    }

    @Nullable
    public Entity getEntity() {
        return null;
    }

    protected DamageSource setDamageBypassesArmor() {
        this.isUnblockable = true;
        this.hungerDamage = 0.0f;
        return this;
    }

    protected DamageSource setDamageAllowedInCreativeMode() {
        this.isDamageAllowedInCreativeMode = true;
        return this;
    }

    protected DamageSource setDamageIsAbsolute() {
        this.damageIsAbsolute = true;
        this.hungerDamage = 0.0f;
        return this;
    }

    protected DamageSource setFireDamage() {
        this.fireDamage = true;
        return this;
    }

    public ITextComponent getDeathMessage(EntityLivingBase entityLivingBase) {
        EntityLivingBase entityLivingBase2 = entityLivingBase.getAttackingEntity();
        String string = "death.attack." + this.damageType;
        String string2 = string + ".player";
        return entityLivingBase2 != null && I18n.canTranslate(string2) ? new TextComponentTranslation(string2, entityLivingBase.getDisplayName(), entityLivingBase2.getDisplayName()) : new TextComponentTranslation(string, entityLivingBase.getDisplayName());
    }

    public boolean isFireDamage() {
        return this.fireDamage;
    }

    public String getDamageType() {
        return this.damageType;
    }

    public DamageSource setDifficultyScaled() {
        this.difficultyScaled = true;
        return this;
    }

    public boolean isDifficultyScaled() {
        return this.difficultyScaled;
    }

    public boolean isMagicDamage() {
        return this.magicDamage;
    }

    public DamageSource setMagicDamage() {
        this.magicDamage = true;
        return this;
    }

    public boolean isCreativePlayer() {
        Entity entity = this.getEntity();
        return entity instanceof EntityPlayer && ((EntityPlayer)entity).capabilities.isCreativeMode;
    }

    @Nullable
    public Vec3d getDamageLocation() {
        return null;
    }
}
