package net.minecraft.util;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.WeightedRandom;

public class WeightedSpawnerEntity
extends WeightedRandom.Item {
    private final NBTTagCompound nbt;

    public WeightedSpawnerEntity() {
        super(1);
        this.nbt = new NBTTagCompound();
        this.nbt.setString("id", "minecraft:pig");
    }

    public WeightedSpawnerEntity(NBTTagCompound nBTTagCompound) {
        this(nBTTagCompound.hasKey("Weight", 99) ? nBTTagCompound.getInteger("Weight") : 1, nBTTagCompound.getCompoundTag("Entity"));
    }

    public WeightedSpawnerEntity(int n, NBTTagCompound nBTTagCompound) {
        super(n);
        this.nbt = nBTTagCompound;
    }

    public NBTTagCompound toCompoundTag() {
        NBTTagCompound nBTTagCompound = new NBTTagCompound();
        if (!this.nbt.hasKey("id", 8)) {
            this.nbt.setString("id", "minecraft:pig");
        } else if (!this.nbt.getString("id").contains(":")) {
            this.nbt.setString("id", new ResourceLocation(this.nbt.getString("id")).toString());
        }
        nBTTagCompound.setTag("Entity", this.nbt);
        nBTTagCompound.setInteger("Weight", this.itemWeight);
        return nBTTagCompound;
    }

    public NBTTagCompound getNbt() {
        return this.nbt;
    }
}
