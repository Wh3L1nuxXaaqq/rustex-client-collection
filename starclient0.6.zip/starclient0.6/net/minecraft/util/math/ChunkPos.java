package net.minecraft.util.math;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;

public class ChunkPos {
    public final int chunkXPos;
    public final int chunkZPos;
    private int cachedHashCode = 0;

    public ChunkPos(int n, int n2) {
        this.chunkXPos = n;
        this.chunkZPos = n2;
    }

    public ChunkPos(BlockPos blockPos) {
        this.chunkXPos = blockPos.getX() >> 4;
        this.chunkZPos = blockPos.getZ() >> 4;
    }

    public static long asLong(int n, int n2) {
        return (long)n & 0xFFFFFFFFL | ((long)n2 & 0xFFFFFFFFL) << 32;
    }

    public int hashCode() {
        if (this.cachedHashCode != 0) {
            return this.cachedHashCode;
        }
        int n = 1664525 * this.chunkXPos + 1013904223;
        int n2 = 1664525 * (this.chunkZPos ^ 0xDEADBEEF) + 1013904223;
        this.cachedHashCode = n ^ n2;
        return this.cachedHashCode;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof ChunkPos)) {
            return false;
        }
        ChunkPos chunkPos = (ChunkPos)object;
        return this.chunkXPos == chunkPos.chunkXPos && this.chunkZPos == chunkPos.chunkZPos;
    }

    public double getDistanceSq(Entity entity) {
        double d = this.chunkXPos * 16 + 8;
        double d2 = this.chunkZPos * 16 + 8;
        double d3 = d - entity.posX;
        double d4 = d2 - entity.posZ;
        return d3 * d3 + d4 * d4;
    }

    public int getXStart() {
        return this.chunkXPos << 4;
    }

    public int getZStart() {
        return this.chunkZPos << 4;
    }

    public int getXEnd() {
        return (this.chunkXPos << 4) + 15;
    }

    public int getZEnd() {
        return (this.chunkZPos << 4) + 15;
    }

    public BlockPos getBlock(int n, int n2, int n3) {
        return new BlockPos((this.chunkXPos << 4) + n, n2, (this.chunkZPos << 4) + n3);
    }

    public String toString() {
        return "[" + this.chunkXPos + ", " + this.chunkZPos + "]";
    }
}
