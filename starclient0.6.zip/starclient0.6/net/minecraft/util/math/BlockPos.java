package net.minecraft.util.math;

import com.google.common.collect.AbstractIterator;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.concurrent.Immutable;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Immutable
public class BlockPos
extends Vec3i {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final BlockPos ORIGIN = new BlockPos(0, 0, 0);
    private static final int NUM_X_BITS;
    private static final int NUM_Z_BITS;
    private static final int NUM_Y_BITS;
    private static final int Y_SHIFT;
    private static final int X_SHIFT;
    private static final long X_MASK;
    private static final long Y_MASK;
    private static final long Z_MASK;

    public BlockPos(int n, int n2, int n3) {
        super(n, n2, n3);
    }

    public BlockPos(double d, double d2, double d3) {
        super(d, d2, d3);
    }

    public BlockPos(Entity entity) {
        this(entity.posX, entity.posY, entity.posZ);
    }

    public BlockPos(Vec3d vec3d) {
        this(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }

    public BlockPos(Vec3i vec3i) {
        this(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    public BlockPos add(double d, double d2, double d3) {
        return d == 0.0 && d2 == 0.0 && d3 == 0.0 ? this : new BlockPos((double)this.getX() + d, (double)this.getY() + d2, (double)this.getZ() + d3);
    }

    public BlockPos add(int n, int n2, int n3) {
        return n == 0 && n2 == 0 && n3 == 0 ? this : new BlockPos(this.getX() + n, this.getY() + n2, this.getZ() + n3);
    }

    public BlockPos add(Vec3i vec3i) {
        return this.add(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    public BlockPos subtract(Vec3i vec3i) {
        return this.add(-vec3i.getX(), -vec3i.getY(), -vec3i.getZ());
    }

    public BlockPos up() {
        return this.up(1);
    }

    public BlockPos up(int n) {
        return this.offset(EnumFacing.UP, n);
    }

    public BlockPos down() {
        return this.down(1);
    }

    public BlockPos down(int n) {
        return this.offset(EnumFacing.DOWN, n);
    }

    public BlockPos north() {
        return this.north(1);
    }

    public BlockPos north(int n) {
        return this.offset(EnumFacing.NORTH, n);
    }

    public BlockPos south() {
        return this.south(1);
    }

    public BlockPos south(int n) {
        return this.offset(EnumFacing.SOUTH, n);
    }

    public BlockPos west() {
        return this.west(1);
    }

    public BlockPos west(int n) {
        return this.offset(EnumFacing.WEST, n);
    }

    public BlockPos east() {
        return this.east(1);
    }

    public BlockPos east(int n) {
        return this.offset(EnumFacing.EAST, n);
    }

    public BlockPos offset(EnumFacing enumFacing) {
        return this.offset(enumFacing, 1);
    }

    public BlockPos offset(EnumFacing enumFacing, int n) {
        return n == 0 ? this : new BlockPos(this.getX() + enumFacing.getFrontOffsetX() * n, this.getY() + enumFacing.getFrontOffsetY() * n, this.getZ() + enumFacing.getFrontOffsetZ() * n);
    }

    public BlockPos func_190942_a(Rotation rotation) {
        switch (rotation) {
            default: {
                return this;
            }
            case CLOCKWISE_90: {
                return new BlockPos(-this.getZ(), this.getY(), this.getX());
            }
            case CLOCKWISE_180: {
                return new BlockPos(-this.getX(), this.getY(), -this.getZ());
            }
            case COUNTERCLOCKWISE_90: 
        }
        return new BlockPos(this.getZ(), this.getY(), -this.getX());
    }

    @Override
    public BlockPos crossProduct(Vec3i vec3i) {
        return new BlockPos(this.getY() * vec3i.getZ() - this.getZ() * vec3i.getY(), this.getZ() * vec3i.getX() - this.getX() * vec3i.getZ(), this.getX() * vec3i.getY() - this.getY() * vec3i.getX());
    }

    public long toLong() {
        return ((long)this.getX() & X_MASK) << X_SHIFT | ((long)this.getY() & Y_MASK) << Y_SHIFT | ((long)this.getZ() & Z_MASK) << 0;
    }

    public static BlockPos fromLong(long l) {
        int n = (int)(l << 64 - X_SHIFT - NUM_X_BITS >> 64 - NUM_X_BITS);
        int n2 = (int)(l << 64 - Y_SHIFT - NUM_Y_BITS >> 64 - NUM_Y_BITS);
        int n3 = (int)(l << 64 - NUM_Z_BITS >> 64 - NUM_Z_BITS);
        return new BlockPos(n, n2, n3);
    }

    public static Iterable<BlockPos> getAllInBox(BlockPos blockPos, BlockPos blockPos2) {
        return BlockPos.func_191532_a(Math.min(blockPos.getX(), blockPos2.getX()), Math.min(blockPos.getY(), blockPos2.getY()), Math.min(blockPos.getZ(), blockPos2.getZ()), Math.max(blockPos.getX(), blockPos2.getX()), Math.max(blockPos.getY(), blockPos2.getY()), Math.max(blockPos.getZ(), blockPos2.getZ()));
    }

    public static Iterable<BlockPos> func_191532_a(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        return new Iterable<BlockPos>(){

            @Override
            public Iterator<BlockPos> iterator() {
                return new AbstractIterator<BlockPos>(){
                    private boolean field_191534_b = true;
                    private int field_191535_c;
                    private int field_191536_d;
                    private int field_191537_e;

                    @Override
                    protected BlockPos computeNext() {
                        if (this.field_191534_b) {
                            this.field_191534_b = false;
                            this.field_191535_c = n;
                            this.field_191536_d = n2;
                            this.field_191537_e = n3;
                            return new BlockPos(n, n2, n3);
                        }
                        if (this.field_191535_c == n4 && this.field_191536_d == n5 && this.field_191537_e == n6) {
                            return (BlockPos)this.endOfData();
                        }
                        if (this.field_191535_c < n4) {
                            ++this.field_191535_c;
                        } else if (this.field_191536_d < n5) {
                            this.field_191535_c = n;
                            ++this.field_191536_d;
                        } else if (this.field_191537_e < n6) {
                            this.field_191535_c = n;
                            this.field_191536_d = n2;
                            ++this.field_191537_e;
                        }
                        return new BlockPos(this.field_191535_c, this.field_191536_d, this.field_191537_e);
                    }
                };
            }
        };
    }

    public BlockPos toImmutable() {
        return this;
    }

    public static Iterable<MutableBlockPos> getAllInBoxMutable(BlockPos blockPos, BlockPos blockPos2) {
        return BlockPos.func_191531_b(Math.min(blockPos.getX(), blockPos2.getX()), Math.min(blockPos.getY(), blockPos2.getY()), Math.min(blockPos.getZ(), blockPos2.getZ()), Math.max(blockPos.getX(), blockPos2.getX()), Math.max(blockPos.getY(), blockPos2.getY()), Math.max(blockPos.getZ(), blockPos2.getZ()));
    }

    public static Iterable<MutableBlockPos> func_191531_b(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        return new Iterable<MutableBlockPos>(){

            @Override
            public Iterator<MutableBlockPos> iterator() {
                return new AbstractIterator<MutableBlockPos>(){
                    private MutableBlockPos theBlockPos;

                    @Override
                    protected MutableBlockPos computeNext() {
                        if (this.theBlockPos == null) {
                            this.theBlockPos = new MutableBlockPos(n, n2, n3);
                            return this.theBlockPos;
                        }
                        if (this.theBlockPos.x == n4 && this.theBlockPos.y == n5 && this.theBlockPos.z == n6) {
                            return (MutableBlockPos)this.endOfData();
                        }
                        if (this.theBlockPos.x < n4) {
                            ++this.theBlockPos.x;
                        } else if (this.theBlockPos.y < n5) {
                            this.theBlockPos.x = n;
                            ++this.theBlockPos.y;
                        } else if (this.theBlockPos.z < n6) {
                            this.theBlockPos.x = n;
                            this.theBlockPos.y = n2;
                            ++this.theBlockPos.z;
                        }
                        return this.theBlockPos;
                    }
                };
            }
        };
    }

    static {
        NUM_Z_BITS = NUM_X_BITS = 1 + MathHelper.log2(MathHelper.smallestEncompassingPowerOfTwo(30000000));
        NUM_Y_BITS = 64 - NUM_X_BITS - NUM_Z_BITS;
        Y_SHIFT = 0 + NUM_Z_BITS;
        X_SHIFT = Y_SHIFT + NUM_Y_BITS;
        X_MASK = (1L << NUM_X_BITS) - 1L;
        Y_MASK = (1L << NUM_Y_BITS) - 1L;
        Z_MASK = (1L << NUM_Z_BITS) - 1L;
    }

    public static final class PooledMutableBlockPos
    extends MutableBlockPos {
        private boolean released;
        private static final List<PooledMutableBlockPos> POOL = Lists.newArrayList();

        private PooledMutableBlockPos(int n, int n2, int n3) {
            super(n, n2, n3);
        }

        public static PooledMutableBlockPos retain() {
            return PooledMutableBlockPos.retain(0, 0, 0);
        }

        public static PooledMutableBlockPos retain(double d, double d2, double d3) {
            return PooledMutableBlockPos.retain(MathHelper.floor(d), MathHelper.floor(d2), MathHelper.floor(d3));
        }

        public static PooledMutableBlockPos retain(Vec3i vec3i) {
            return PooledMutableBlockPos.retain(vec3i.getX(), vec3i.getY(), vec3i.getZ());
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public static PooledMutableBlockPos retain(int n, int n2, int n3) {
            List<PooledMutableBlockPos> list = POOL;
            synchronized (list) {
                PooledMutableBlockPos pooledMutableBlockPos;
                if (!POOL.isEmpty() && (pooledMutableBlockPos = POOL.remove(POOL.size() - 1)) != null && pooledMutableBlockPos.released) {
                    pooledMutableBlockPos.released = false;
                    pooledMutableBlockPos.setPos(n, n2, n3);
                    return pooledMutableBlockPos;
                }
            }
            return new PooledMutableBlockPos(n, n2, n3);
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public void release() {
            List<PooledMutableBlockPos> list = POOL;
            synchronized (list) {
                if (POOL.size() < 100) {
                    POOL.add(this);
                }
                this.released = true;
            }
        }

        @Override
        public PooledMutableBlockPos setPos(int n, int n2, int n3) {
            if (this.released) {
                LOGGER.error("PooledMutableBlockPosition modified after it was released.", new Throwable());
                this.released = false;
            }
            return (PooledMutableBlockPos)super.setPos(n, n2, n3);
        }

        @Override
        public PooledMutableBlockPos setPos(Entity entity) {
            return (PooledMutableBlockPos)super.setPos(entity);
        }

        @Override
        public PooledMutableBlockPos setPos(double d, double d2, double d3) {
            return (PooledMutableBlockPos)super.setPos(d, d2, d3);
        }

        @Override
        public PooledMutableBlockPos setPos(Vec3i vec3i) {
            return (PooledMutableBlockPos)super.setPos(vec3i);
        }

        @Override
        public PooledMutableBlockPos move(EnumFacing enumFacing) {
            return (PooledMutableBlockPos)super.move(enumFacing);
        }

        @Override
        public PooledMutableBlockPos move(EnumFacing enumFacing, int n) {
            return (PooledMutableBlockPos)super.move(enumFacing, n);
        }
    }

    public static class MutableBlockPos
    extends BlockPos {
        protected int x;
        protected int y;
        protected int z;

        public MutableBlockPos() {
            this(0, 0, 0);
        }

        public MutableBlockPos(BlockPos blockPos) {
            this(blockPos.getX(), blockPos.getY(), blockPos.getZ());
        }

        public MutableBlockPos(int n, int n2, int n3) {
            super(0, 0, 0);
            this.x = n;
            this.y = n2;
            this.z = n3;
        }

        @Override
        public BlockPos add(double d, double d2, double d3) {
            return super.add(d, d2, d3).toImmutable();
        }

        @Override
        public BlockPos add(int n, int n2, int n3) {
            return super.add(n, n2, n3).toImmutable();
        }

        @Override
        public BlockPos offset(EnumFacing enumFacing, int n) {
            return super.offset(enumFacing, n).toImmutable();
        }

        @Override
        public BlockPos func_190942_a(Rotation rotation) {
            return super.func_190942_a(rotation).toImmutable();
        }

        @Override
        public int getX() {
            return this.x;
        }

        @Override
        public int getY() {
            return this.y;
        }

        @Override
        public int getZ() {
            return this.z;
        }

        public MutableBlockPos setPos(int n, int n2, int n3) {
            this.x = n;
            this.y = n2;
            this.z = n3;
            return this;
        }

        public MutableBlockPos setPos(Entity entity) {
            return this.setPos(entity.posX, entity.posY, entity.posZ);
        }

        public MutableBlockPos setPos(double d, double d2, double d3) {
            return this.setPos(MathHelper.floor(d), MathHelper.floor(d2), MathHelper.floor(d3));
        }

        public MutableBlockPos setPos(Vec3i vec3i) {
            return this.setPos(vec3i.getX(), vec3i.getY(), vec3i.getZ());
        }

        public MutableBlockPos move(EnumFacing enumFacing) {
            return this.move(enumFacing, 1);
        }

        public MutableBlockPos move(EnumFacing enumFacing, int n) {
            return this.setPos(this.x + enumFacing.getFrontOffsetX() * n, this.y + enumFacing.getFrontOffsetY() * n, this.z + enumFacing.getFrontOffsetZ() * n);
        }

        public void setY(int n) {
            this.y = n;
        }

        @Override
        public BlockPos toImmutable() {
            return new BlockPos(this);
        }
    }
}
