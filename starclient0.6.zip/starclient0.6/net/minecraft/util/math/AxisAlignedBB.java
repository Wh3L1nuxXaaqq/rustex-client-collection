package net.minecraft.util.math;

import com.google.common.annotations.VisibleForTesting;
import javax.annotation.Nullable;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class AxisAlignedBB {
    public final double minX;
    public final double minY;
    public final double minZ;
    public final double maxX;
    public final double maxY;
    public final double maxZ;

    public AxisAlignedBB(double d, double d2, double d3, double d4, double d5, double d6) {
        this.minX = Math.min(d, d4);
        this.minY = Math.min(d2, d5);
        this.minZ = Math.min(d3, d6);
        this.maxX = Math.max(d, d4);
        this.maxY = Math.max(d2, d5);
        this.maxZ = Math.max(d3, d6);
    }

    public AxisAlignedBB(BlockPos blockPos) {
        this(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos.getX() + 1, blockPos.getY() + 1, blockPos.getZ() + 1);
    }

    public AxisAlignedBB(BlockPos blockPos, BlockPos blockPos2) {
        this(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos2.getX(), blockPos2.getY(), blockPos2.getZ());
    }

    public AxisAlignedBB(Vec3d vec3d, Vec3d vec3d2) {
        this(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord, vec3d2.xCoord, vec3d2.yCoord, vec3d2.zCoord);
    }

    public AxisAlignedBB setMaxY(double d) {
        return new AxisAlignedBB(this.minX, this.minY, this.minZ, this.maxX, d, this.maxZ);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof AxisAlignedBB)) {
            return false;
        }
        AxisAlignedBB axisAlignedBB = (AxisAlignedBB)object;
        if (Double.compare(axisAlignedBB.minX, this.minX) != 0) {
            return false;
        }
        if (Double.compare(axisAlignedBB.minY, this.minY) != 0) {
            return false;
        }
        if (Double.compare(axisAlignedBB.minZ, this.minZ) != 0) {
            return false;
        }
        if (Double.compare(axisAlignedBB.maxX, this.maxX) != 0) {
            return false;
        }
        if (Double.compare(axisAlignedBB.maxY, this.maxY) != 0) {
            return false;
        }
        return Double.compare(axisAlignedBB.maxZ, this.maxZ) == 0;
    }

    public int hashCode() {
        long l = Double.doubleToLongBits(this.minX);
        int n = (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.minY);
        n = 31 * n + (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.minZ);
        n = 31 * n + (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.maxX);
        n = 31 * n + (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.maxY);
        n = 31 * n + (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.maxZ);
        n = 31 * n + (int)(l ^ l >>> 32);
        return n;
    }

    public AxisAlignedBB func_191195_a(double d, double d2, double d3) {
        double d4 = this.minX;
        double d5 = this.minY;
        double d6 = this.minZ;
        double d7 = this.maxX;
        double d8 = this.maxY;
        double d9 = this.maxZ;
        if (d < 0.0) {
            d4 -= d;
        } else if (d > 0.0) {
            d7 -= d;
        }
        if (d2 < 0.0) {
            d5 -= d2;
        } else if (d2 > 0.0) {
            d8 -= d2;
        }
        if (d3 < 0.0) {
            d6 -= d3;
        } else if (d3 > 0.0) {
            d9 -= d3;
        }
        return new AxisAlignedBB(d4, d5, d6, d7, d8, d9);
    }

    public AxisAlignedBB addCoord(double d, double d2, double d3) {
        double d4 = this.minX;
        double d5 = this.minY;
        double d6 = this.minZ;
        double d7 = this.maxX;
        double d8 = this.maxY;
        double d9 = this.maxZ;
        if (d < 0.0) {
            d4 += d;
        } else if (d > 0.0) {
            d7 += d;
        }
        if (d2 < 0.0) {
            d5 += d2;
        } else if (d2 > 0.0) {
            d8 += d2;
        }
        if (d3 < 0.0) {
            d6 += d3;
        } else if (d3 > 0.0) {
            d9 += d3;
        }
        return new AxisAlignedBB(d4, d5, d6, d7, d8, d9);
    }

    public AxisAlignedBB expand(double d, double d2, double d3) {
        double d4 = this.minX - d;
        double d5 = this.minY - d2;
        double d6 = this.minZ - d3;
        double d7 = this.maxX + d;
        double d8 = this.maxY + d2;
        double d9 = this.maxZ + d3;
        return new AxisAlignedBB(d4, d5, d6, d7, d8, d9);
    }

    public Vec3d clamp(Vec3d vec3d) {
        double d = MathHelper.clamp(vec3d.x, this.minX, this.maxX);
        double d2 = MathHelper.clamp(vec3d.y, this.minY, this.maxY);
        double d3 = MathHelper.clamp(vec3d.z, this.minZ, this.maxZ);
        return new Vec3d(d, d2, d3);
    }

    public AxisAlignedBB expandXyz(double d) {
        return this.expand(d, d, d);
    }

    public AxisAlignedBB func_191500_a(AxisAlignedBB axisAlignedBB) {
        double d = Math.max(this.minX, axisAlignedBB.minX);
        double d2 = Math.max(this.minY, axisAlignedBB.minY);
        double d3 = Math.max(this.minZ, axisAlignedBB.minZ);
        double d4 = Math.min(this.maxX, axisAlignedBB.maxX);
        double d5 = Math.min(this.maxY, axisAlignedBB.maxY);
        double d6 = Math.min(this.maxZ, axisAlignedBB.maxZ);
        return new AxisAlignedBB(d, d2, d3, d4, d5, d6);
    }

    public AxisAlignedBB union(AxisAlignedBB axisAlignedBB) {
        double d = Math.min(this.minX, axisAlignedBB.minX);
        double d2 = Math.min(this.minY, axisAlignedBB.minY);
        double d3 = Math.min(this.minZ, axisAlignedBB.minZ);
        double d4 = Math.max(this.maxX, axisAlignedBB.maxX);
        double d5 = Math.max(this.maxY, axisAlignedBB.maxY);
        double d6 = Math.max(this.maxZ, axisAlignedBB.maxZ);
        return new AxisAlignedBB(d, d2, d3, d4, d5, d6);
    }

    public AxisAlignedBB offset(double d, double d2, double d3) {
        return new AxisAlignedBB(this.minX + d, this.minY + d2, this.minZ + d3, this.maxX + d, this.maxY + d2, this.maxZ + d3);
    }

    public AxisAlignedBB offset(BlockPos blockPos) {
        return new AxisAlignedBB(this.minX + (double)blockPos.getX(), this.minY + (double)blockPos.getY(), this.minZ + (double)blockPos.getZ(), this.maxX + (double)blockPos.getX(), this.maxY + (double)blockPos.getY(), this.maxZ + (double)blockPos.getZ());
    }

    public AxisAlignedBB func_191194_a(Vec3d vec3d) {
        return this.offset(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }

    public double calculateXOffset(AxisAlignedBB axisAlignedBB, double d) {
        if (axisAlignedBB.maxY > this.minY && axisAlignedBB.minY < this.maxY && axisAlignedBB.maxZ > this.minZ && axisAlignedBB.minZ < this.maxZ) {
            double d2;
            if (d > 0.0 && axisAlignedBB.maxX <= this.minX) {
                double d3 = this.minX - axisAlignedBB.maxX;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && axisAlignedBB.minX >= this.maxX && (d2 = this.maxX - axisAlignedBB.minX) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public double calculateYOffset(AxisAlignedBB axisAlignedBB, double d) {
        if (axisAlignedBB.maxX > this.minX && axisAlignedBB.minX < this.maxX && axisAlignedBB.maxZ > this.minZ && axisAlignedBB.minZ < this.maxZ) {
            double d2;
            if (d > 0.0 && axisAlignedBB.maxY <= this.minY) {
                double d3 = this.minY - axisAlignedBB.maxY;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && axisAlignedBB.minY >= this.maxY && (d2 = this.maxY - axisAlignedBB.minY) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public double calculateZOffset(AxisAlignedBB axisAlignedBB, double d) {
        if (axisAlignedBB.maxX > this.minX && axisAlignedBB.minX < this.maxX && axisAlignedBB.maxY > this.minY && axisAlignedBB.minY < this.maxY) {
            double d2;
            if (d > 0.0 && axisAlignedBB.maxZ <= this.minZ) {
                double d3 = this.minZ - axisAlignedBB.maxZ;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && axisAlignedBB.minZ >= this.maxZ && (d2 = this.maxZ - axisAlignedBB.minZ) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public boolean intersectsWith(AxisAlignedBB axisAlignedBB) {
        return this.intersects(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ);
    }

    public boolean intersects(double d, double d2, double d3, double d4, double d5, double d6) {
        return this.minX < d4 && this.maxX > d && this.minY < d5 && this.maxY > d2 && this.minZ < d6 && this.maxZ > d3;
    }

    public boolean intersects(Vec3d vec3d, Vec3d vec3d2) {
        return this.intersects(Math.min(vec3d.xCoord, vec3d2.xCoord), Math.min(vec3d.yCoord, vec3d2.yCoord), Math.min(vec3d.zCoord, vec3d2.zCoord), Math.max(vec3d.xCoord, vec3d2.xCoord), Math.max(vec3d.yCoord, vec3d2.yCoord), Math.max(vec3d.zCoord, vec3d2.zCoord));
    }

    public boolean isVecInside(Vec3d vec3d) {
        if (vec3d.xCoord > this.minX && vec3d.xCoord < this.maxX) {
            if (vec3d.yCoord > this.minY && vec3d.yCoord < this.maxY) {
                return vec3d.zCoord > this.minZ && vec3d.zCoord < this.maxZ;
            }
            return false;
        }
        return false;
    }

    public double getAverageEdgeLength() {
        double d = this.maxX - this.minX;
        double d2 = this.maxY - this.minY;
        double d3 = this.maxZ - this.minZ;
        return (d + d2 + d3) / 3.0;
    }

    public AxisAlignedBB contract(double d) {
        return this.expandXyz(-d);
    }

    public AxisAlignedBB contract(double d, double d2, double d3) {
        double d4 = this.minX;
        double d5 = this.minY;
        double d6 = this.minZ;
        double d7 = this.maxX;
        double d8 = this.maxY;
        double d9 = this.maxZ;
        if (d < 0.0) {
            d4 -= d;
        } else if (d > 0.0) {
            d7 -= d;
        }
        if (d2 < 0.0) {
            d5 -= d2;
        } else if (d2 > 0.0) {
            d8 -= d2;
        }
        if (d3 < 0.0) {
            d6 -= d3;
        } else if (d3 > 0.0) {
            d9 -= d3;
        }
        return new AxisAlignedBB(d4, d5, d6, d7, d8, d9);
    }

    @Nullable
    public RayTraceResult calculateIntercept(Vec3d vec3d, Vec3d vec3d2) {
        Vec3d vec3d3 = this.collideWithXPlane(this.minX, vec3d, vec3d2);
        EnumFacing enumFacing = EnumFacing.WEST;
        Vec3d vec3d4 = this.collideWithXPlane(this.maxX, vec3d, vec3d2);
        if (vec3d4 != null && this.isClosest(vec3d, vec3d3, vec3d4)) {
            vec3d3 = vec3d4;
            enumFacing = EnumFacing.EAST;
        }
        if ((vec3d4 = this.collideWithYPlane(this.minY, vec3d, vec3d2)) != null && this.isClosest(vec3d, vec3d3, vec3d4)) {
            vec3d3 = vec3d4;
            enumFacing = EnumFacing.DOWN;
        }
        if ((vec3d4 = this.collideWithYPlane(this.maxY, vec3d, vec3d2)) != null && this.isClosest(vec3d, vec3d3, vec3d4)) {
            vec3d3 = vec3d4;
            enumFacing = EnumFacing.UP;
        }
        if ((vec3d4 = this.collideWithZPlane(this.minZ, vec3d, vec3d2)) != null && this.isClosest(vec3d, vec3d3, vec3d4)) {
            vec3d3 = vec3d4;
            enumFacing = EnumFacing.NORTH;
        }
        if ((vec3d4 = this.collideWithZPlane(this.maxZ, vec3d, vec3d2)) != null && this.isClosest(vec3d, vec3d3, vec3d4)) {
            vec3d3 = vec3d4;
            enumFacing = EnumFacing.SOUTH;
        }
        return vec3d3 == null ? null : new RayTraceResult(vec3d3, enumFacing);
    }

    @VisibleForTesting
    boolean isClosest(Vec3d vec3d, @Nullable Vec3d vec3d2, Vec3d vec3d3) {
        return vec3d2 == null || vec3d.squareDistanceTo(vec3d3) < vec3d.squareDistanceTo(vec3d2);
    }

    @Nullable
    @VisibleForTesting
    Vec3d collideWithXPlane(double d, Vec3d vec3d, Vec3d vec3d2) {
        Vec3d vec3d3 = vec3d.getIntermediateWithXValue(vec3d2, d);
        return vec3d3 != null && this.intersectsWithYZ(vec3d3) ? vec3d3 : null;
    }

    @Nullable
    @VisibleForTesting
    Vec3d collideWithYPlane(double d, Vec3d vec3d, Vec3d vec3d2) {
        Vec3d vec3d3 = vec3d.getIntermediateWithYValue(vec3d2, d);
        return vec3d3 != null && this.intersectsWithXZ(vec3d3) ? vec3d3 : null;
    }

    @Nullable
    @VisibleForTesting
    Vec3d collideWithZPlane(double d, Vec3d vec3d, Vec3d vec3d2) {
        Vec3d vec3d3 = vec3d.getIntermediateWithZValue(vec3d2, d);
        return vec3d3 != null && this.intersectsWithXY(vec3d3) ? vec3d3 : null;
    }

    @VisibleForTesting
    public boolean intersectsWithYZ(Vec3d vec3d) {
        return vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ;
    }

    @VisibleForTesting
    public boolean intersectsWithXZ(Vec3d vec3d) {
        return vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ;
    }

    @VisibleForTesting
    public boolean intersectsWithXY(Vec3d vec3d) {
        return vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY;
    }

    public String toString() {
        return "box[" + this.minX + ", " + this.minY + ", " + this.minZ + " -> " + this.maxX + ", " + this.maxY + ", " + this.maxZ + "]";
    }

    public boolean hasNaN() {
        return Double.isNaN(this.minX) || Double.isNaN(this.minY) || Double.isNaN(this.minZ) || Double.isNaN(this.maxX) || Double.isNaN(this.maxY) || Double.isNaN(this.maxZ);
    }

    public Vec3d getCenter() {
        return new Vec3d(this.minX + (this.maxX - this.minX) * 0.5, this.minY + (this.maxY - this.minY) * 0.5, this.minZ + (this.maxZ - this.minZ) * 0.5);
    }

    public AxisAlignedBB grow(double d, double d2, double d3) {
        double d4 = this.minX - d;
        double d5 = this.minY - d2;
        double d6 = this.minZ - d3;
        double d7 = this.maxX + d;
        double d8 = this.maxY + d2;
        double d9 = this.maxZ + d3;
        return new AxisAlignedBB(d4, d5, d6, d7, d8, d9);
    }

    public AxisAlignedBB grow(double d) {
        return this.grow(d, d, d);
    }

    public AxisAlignedBB shrink(double d) {
        return this.grow(-d);
    }

    public boolean contains(Vec3d vec3d) {
        if (vec3d.x > this.minX && vec3d.x < this.maxX) {
            if (vec3d.y > this.minY && vec3d.y < this.maxY) {
                return vec3d.z > this.minZ && vec3d.z < this.maxZ;
            }
            return false;
        }
        return false;
    }
}
