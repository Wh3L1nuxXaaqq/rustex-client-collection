package net.minecraft.util.math;

import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class RayTraceResult {
    private BlockPos blockPos;
    public Type typeOfHit;
    public EnumFacing sideHit;
    public Vec3d hitVec;
    public Entity entityHit;

    public RayTraceResult(Vec3d vec3d, EnumFacing enumFacing, BlockPos blockPos) {
        this(Type.BLOCK, vec3d, enumFacing, blockPos);
    }

    public RayTraceResult(Vec3d vec3d, EnumFacing enumFacing) {
        this(Type.BLOCK, vec3d, enumFacing, BlockPos.ORIGIN);
    }

    public RayTraceResult(Entity entity) {
        this(entity, new Vec3d(entity.posX, entity.posY, entity.posZ));
    }

    public RayTraceResult(Type type, Vec3d vec3d, EnumFacing enumFacing, BlockPos blockPos) {
        this.typeOfHit = type;
        this.blockPos = blockPos;
        this.sideHit = enumFacing;
        this.hitVec = new Vec3d(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }

    public RayTraceResult(Entity entity, Vec3d vec3d) {
        this.typeOfHit = Type.ENTITY;
        this.entityHit = entity;
        this.hitVec = vec3d;
    }

    public BlockPos getBlockPos() {
        return this.blockPos;
    }

    public String toString() {
        return "HitResult{type=" + String.valueOf((Object)this.typeOfHit) + ", blockpos=" + String.valueOf(this.blockPos) + ", f=" + String.valueOf(this.sideHit) + ", pos=" + String.valueOf(this.hitVec) + ", entity=" + String.valueOf(this.entityHit) + "}";
    }

    public static enum Type {
        MISS,
        BLOCK,
        ENTITY;

    }
}
