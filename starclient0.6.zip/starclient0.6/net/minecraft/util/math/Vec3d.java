package net.minecraft.util.math;

import javax.annotation.Nullable;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3i;

public class Vec3d {
    public static final Vec3d ZERO = new Vec3d(0.0, 0.0, 0.0);
    public final double xCoord;
    public final double yCoord;
    public final double zCoord;
    public double x;
    public double y;
    public double z;

    public Vec3d(double d, double d2, double d3) {
        if (d == -0.0) {
            d = 0.0;
        }
        if (d2 == -0.0) {
            d2 = 0.0;
        }
        if (d3 == -0.0) {
            d3 = 0.0;
        }
        this.xCoord = d;
        this.yCoord = d2;
        this.zCoord = d3;
        this.x = d;
        this.y = d2;
        this.z = d3;
    }

    public Vec3d(Vec3i vec3i) {
        this(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    public Vec3d subtractReverse(Vec3d vec3d) {
        return new Vec3d(vec3d.xCoord - this.xCoord, vec3d.yCoord - this.yCoord, vec3d.zCoord - this.zCoord);
    }

    public Vec3d normalize() {
        double d = MathHelper.sqrt(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
        return d < 1.0E-4 ? ZERO : new Vec3d(this.xCoord / d, this.yCoord / d, this.zCoord / d);
    }

    public double dotProduct(Vec3d vec3d) {
        return this.xCoord * vec3d.xCoord + this.yCoord * vec3d.yCoord + this.zCoord * vec3d.zCoord;
    }

    public Vec3d crossProduct(Vec3d vec3d) {
        return new Vec3d(this.yCoord * vec3d.zCoord - this.zCoord * vec3d.yCoord, this.zCoord * vec3d.xCoord - this.xCoord * vec3d.zCoord, this.xCoord * vec3d.yCoord - this.yCoord * vec3d.xCoord);
    }

    public Vec3d subtract(Vec3d vec3d) {
        return this.subtract(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }

    public Vec3d subtract(double d, double d2, double d3) {
        return this.addVector(-d, -d2, -d3);
    }

    public Vec3d add(Vec3d vec3d) {
        return this.addVector(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }

    public Vec3d add(double d, double d2, double d3) {
        return new Vec3d(this.x + d, this.y + d2, this.z + d3);
    }

    public Vec3d addVector(double d, double d2, double d3) {
        return new Vec3d(this.xCoord + d, this.yCoord + d2, this.zCoord + d3);
    }

    public double distanceTo(Vec3d vec3d) {
        double d = vec3d.xCoord - this.xCoord;
        double d2 = vec3d.yCoord - this.yCoord;
        double d3 = vec3d.zCoord - this.zCoord;
        return MathHelper.sqrt(d * d + d2 * d2 + d3 * d3);
    }

    public double squareDistanceTo(Vec3d vec3d) {
        double d = vec3d.xCoord - this.xCoord;
        double d2 = vec3d.yCoord - this.yCoord;
        double d3 = vec3d.zCoord - this.zCoord;
        return d * d + d2 * d2 + d3 * d3;
    }

    public double squareDistanceTo(double d, double d2, double d3) {
        double d4 = d - this.xCoord;
        double d5 = d2 - this.yCoord;
        double d6 = d3 - this.zCoord;
        return d4 * d4 + d5 * d5 + d6 * d6;
    }

    public Vec3d scale(double d) {
        return new Vec3d(this.xCoord * d, this.yCoord * d, this.zCoord * d);
    }

    public double lengthVector() {
        return MathHelper.sqrt(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
    }

    public double lengthSquared() {
        return this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord;
    }

    @Nullable
    public Vec3d getIntermediateWithXValue(Vec3d vec3d, double d) {
        double d2 = vec3d.xCoord - this.xCoord;
        double d3 = vec3d.yCoord - this.yCoord;
        double d4 = vec3d.zCoord - this.zCoord;
        if (d2 * d2 < (double)1.0E-7f) {
            return null;
        }
        double d5 = (d - this.xCoord) / d2;
        return d5 >= 0.0 && d5 <= 1.0 ? new Vec3d(this.xCoord + d2 * d5, this.yCoord + d3 * d5, this.zCoord + d4 * d5) : null;
    }

    @Nullable
    public Vec3d getIntermediateWithYValue(Vec3d vec3d, double d) {
        double d2 = vec3d.xCoord - this.xCoord;
        double d3 = vec3d.yCoord - this.yCoord;
        double d4 = vec3d.zCoord - this.zCoord;
        if (d3 * d3 < (double)1.0E-7f) {
            return null;
        }
        double d5 = (d - this.yCoord) / d3;
        return d5 >= 0.0 && d5 <= 1.0 ? new Vec3d(this.xCoord + d2 * d5, this.yCoord + d3 * d5, this.zCoord + d4 * d5) : null;
    }

    @Nullable
    public Vec3d getIntermediateWithZValue(Vec3d vec3d, double d) {
        double d2 = vec3d.xCoord - this.xCoord;
        double d3 = vec3d.yCoord - this.yCoord;
        double d4 = vec3d.zCoord - this.zCoord;
        if (d4 * d4 < (double)1.0E-7f) {
            return null;
        }
        double d5 = (d - this.zCoord) / d4;
        return d5 >= 0.0 && d5 <= 1.0 ? new Vec3d(this.xCoord + d2 * d5, this.yCoord + d3 * d5, this.zCoord + d4 * d5) : null;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Vec3d)) {
            return false;
        }
        Vec3d vec3d = (Vec3d)object;
        if (Double.compare(vec3d.xCoord, this.xCoord) != 0) {
            return false;
        }
        if (Double.compare(vec3d.yCoord, this.yCoord) != 0) {
            return false;
        }
        return Double.compare(vec3d.zCoord, this.zCoord) == 0;
    }

    public int hashCode() {
        long l = Double.doubleToLongBits(this.xCoord);
        int n = (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.yCoord);
        n = 31 * n + (int)(l ^ l >>> 32);
        l = Double.doubleToLongBits(this.zCoord);
        n = 31 * n + (int)(l ^ l >>> 32);
        return n;
    }

    public String toString() {
        return "(" + this.xCoord + ", " + this.yCoord + ", " + this.zCoord + ")";
    }

    public Vec3d rotatePitch(float f) {
        float f2 = MathHelper.cos(f);
        float f3 = MathHelper.sin(f);
        double d = this.xCoord;
        double d2 = this.yCoord * (double)f2 + this.zCoord * (double)f3;
        double d3 = this.zCoord * (double)f2 - this.yCoord * (double)f3;
        return new Vec3d(d, d2, d3);
    }

    public Vec3d rotateYaw(float f) {
        float f2 = MathHelper.cos(f);
        float f3 = MathHelper.sin(f);
        double d = this.xCoord * (double)f2 + this.zCoord * (double)f3;
        double d2 = this.yCoord;
        double d3 = this.zCoord * (double)f2 - this.xCoord * (double)f3;
        return new Vec3d(d, d2, d3);
    }

    public static Vec3d fromPitchYawVector(Vec2f vec2f) {
        return Vec3d.fromPitchYaw(vec2f.x, vec2f.y);
    }

    public static Vec3d fromPitchYaw(float f, float f2) {
        float f3 = MathHelper.cos(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f4 = MathHelper.sin(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f5 = -MathHelper.cos(-f * ((float)Math.PI / 180));
        float f6 = MathHelper.sin(-f * ((float)Math.PI / 180));
        return new Vec3d(f4 * f5, f6, f3 * f5);
    }
}
