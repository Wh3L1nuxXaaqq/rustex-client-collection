package net.minecraft.util;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Locale;
import net.minecraft.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

public class ResourceLocation
implements Comparable<ResourceLocation> {
    protected final String resourceDomain;
    protected final String resourcePath;

    protected ResourceLocation(int n, String ... stringArray) {
        this.resourceDomain = StringUtils.isEmpty((CharSequence)stringArray[0]) ? "minecraft" : stringArray[0].toLowerCase(Locale.ROOT);
        this.resourcePath = stringArray[1].toLowerCase(Locale.ROOT);
        Validate.notNull((Object)this.resourcePath);
    }

    public ResourceLocation(String string) {
        this(0, ResourceLocation.splitObjectName(string));
    }

    public ResourceLocation(String string, String string2) {
        this(0, string, string2);
    }

    protected static String[] splitObjectName(String string) {
        String[] stringArray = new String[]{"minecraft", string};
        int n = string.indexOf(58);
        if (n >= 0) {
            stringArray[1] = string.substring(n + 1, string.length());
            if (n > 1) {
                stringArray[0] = string.substring(0, n);
            }
        }
        return stringArray;
    }

    public String getResourcePath() {
        return this.resourcePath;
    }

    public String getResourceDomain() {
        return this.resourceDomain;
    }

    public String toString() {
        return this.resourceDomain + ":" + this.resourcePath;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof ResourceLocation)) {
            return false;
        }
        ResourceLocation resourceLocation = (ResourceLocation)object;
        return this.resourceDomain.equals(resourceLocation.resourceDomain) && this.resourcePath.equals(resourceLocation.resourcePath);
    }

    public int hashCode() {
        return 31 * this.resourceDomain.hashCode() + this.resourcePath.hashCode();
    }

    @Override
    public int compareTo(ResourceLocation resourceLocation) {
        int n = this.resourceDomain.compareTo(resourceLocation.resourceDomain);
        if (n == 0) {
            n = this.resourcePath.compareTo(resourceLocation.resourcePath);
        }
        return n;
    }

    public static class Serializer
    implements JsonDeserializer<ResourceLocation>,
    JsonSerializer<ResourceLocation> {
        @Override
        public ResourceLocation deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return new ResourceLocation(JsonUtils.getString(jsonElement, "location"));
        }

        @Override
        public JsonElement serialize(ResourceLocation resourceLocation, Type type, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(resourceLocation.toString());
        }
    }
}
