package net.minecraft.util.datafix.fixes;

import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class BedItemColor
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 1125;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("minecraft:bed".equals(nBTTagCompound.getString("id")) && nBTTagCompound.getShort("Damage") == 0) {
            nBTTagCompound.setShort("Damage", (short)EnumDyeColor.RED.getMetadata());
        }
        return nBTTagCompound;
    }
}
