package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class SkeletonSplit
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 701;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        String string = nBTTagCompound.getString("id");
        if ("Skeleton".equals(string)) {
            int n = nBTTagCompound.getInteger("SkeletonType");
            if (n == 1) {
                nBTTagCompound.setString("id", "WitherSkeleton");
            } else if (n == 2) {
                nBTTagCompound.setString("id", "Stray");
            }
            nBTTagCompound.removeTag("SkeletonType");
        }
        return nBTTagCompound;
    }
}
