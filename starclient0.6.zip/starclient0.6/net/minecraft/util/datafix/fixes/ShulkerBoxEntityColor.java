package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ShulkerBoxEntityColor
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 808;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("minecraft:shulker".equals(nBTTagCompound.getString("id")) && !nBTTagCompound.hasKey("Color", 99)) {
            nBTTagCompound.setByte("Color", (byte)10);
        }
        return nBTTagCompound;
    }
}
