package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class PotionWater
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 806;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        String string = nBTTagCompound.getString("id");
        if ("minecraft:potion".equals(string) || "minecraft:splash_potion".equals(string) || "minecraft:lingering_potion".equals(string) || "minecraft:tipped_arrow".equals(string)) {
            NBTTagCompound nBTTagCompound2 = nBTTagCompound.getCompoundTag("tag");
            if (!nBTTagCompound2.hasKey("Potion", 8)) {
                nBTTagCompound2.setString("Potion", "minecraft:water");
            }
            if (!nBTTagCompound.hasKey("tag", 10)) {
                nBTTagCompound.setTag("tag", nBTTagCompound2);
            }
        }
        return nBTTagCompound;
    }
}
