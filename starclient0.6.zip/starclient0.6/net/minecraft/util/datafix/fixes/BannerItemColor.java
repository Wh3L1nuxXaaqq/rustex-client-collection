package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;

public class BannerItemColor
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 804;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        NBTTagCompound nBTTagCompound2;
        NBTTagCompound nBTTagCompound3;
        if ("minecraft:banner".equals(nBTTagCompound.getString("id")) && nBTTagCompound.hasKey("tag", 10) && (nBTTagCompound3 = nBTTagCompound.getCompoundTag("tag")).hasKey("BlockEntityTag", 10) && (nBTTagCompound2 = nBTTagCompound3.getCompoundTag("BlockEntityTag")).hasKey("Base", 99)) {
            NBTTagList nBTTagList;
            NBTTagCompound nBTTagCompound4;
            nBTTagCompound.setShort("Damage", (short)(nBTTagCompound2.getShort("Base") & 0xF));
            if (nBTTagCompound3.hasKey("display", 10) && (nBTTagCompound4 = nBTTagCompound3.getCompoundTag("display")).hasKey("Lore", 9) && (nBTTagList = nBTTagCompound4.getTagList("Lore", 8)).tagCount() == 1 && "(+NBT)".equals(nBTTagList.getStringTagAt(0))) {
                return nBTTagCompound;
            }
            nBTTagCompound2.removeTag("Base");
            if (nBTTagCompound2.hasNoTags()) {
                nBTTagCompound3.removeTag("BlockEntityTag");
            }
            if (nBTTagCompound3.hasNoTags()) {
                nBTTagCompound.removeTag("tag");
            }
        }
        return nBTTagCompound;
    }
}
