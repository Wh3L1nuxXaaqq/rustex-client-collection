package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;

public class RedundantChanceTags
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 113;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        NBTTagList nBTTagList;
        if (nBTTagCompound.hasKey("HandDropChances", 9) && (nBTTagList = nBTTagCompound.getTagList("HandDropChances", 5)).tagCount() == 2 && nBTTagList.getFloatAt(0) == 0.0f && nBTTagList.getFloatAt(1) == 0.0f) {
            nBTTagCompound.removeTag("HandDropChances");
        }
        if (nBTTagCompound.hasKey("ArmorDropChances", 9) && (nBTTagList = nBTTagCompound.getTagList("ArmorDropChances", 5)).tagCount() == 4 && nBTTagList.getFloatAt(0) == 0.0f && nBTTagList.getFloatAt(1) == 0.0f && nBTTagList.getFloatAt(2) == 0.0f && nBTTagList.getFloatAt(3) == 0.0f) {
            nBTTagCompound.removeTag("ArmorDropChances");
        }
        return nBTTagCompound;
    }
}
