package net.minecraft.util.datafix.fixes;

import com.google.gson.JsonParseException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.StringUtils;
import net.minecraft.util.datafix.IFixableData;
import net.minecraft.util.datafix.fixes.SignStrictJSON;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class BookPagesStrictJSON
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 165;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        NBTTagCompound nBTTagCompound2;
        if ("minecraft:written_book".equals(nBTTagCompound.getString("id")) && (nBTTagCompound2 = nBTTagCompound.getCompoundTag("tag")).hasKey("pages", 9)) {
            NBTTagList nBTTagList = nBTTagCompound2.getTagList("pages", 8);
            for (int i = 0; i < nBTTagList.tagCount(); ++i) {
                String string = nBTTagList.getStringTagAt(i);
                ITextComponent iTextComponent = null;
                if (!"null".equals(string) && !StringUtils.isNullOrEmpty(string)) {
                    if (string.charAt(0) == '\"' && string.charAt(string.length() - 1) == '\"' || string.charAt(0) == '{' && string.charAt(string.length() - 1) == '}') {
                        try {
                            iTextComponent = JsonUtils.gsonDeserialize(SignStrictJSON.GSON_INSTANCE, string, ITextComponent.class, true);
                            if (iTextComponent == null) {
                                iTextComponent = new TextComponentString("");
                            }
                        }
                        catch (JsonParseException jsonParseException) {
                            // empty catch block
                        }
                        if (iTextComponent == null) {
                            try {
                                iTextComponent = ITextComponent.Serializer.jsonToComponent(string);
                            }
                            catch (JsonParseException jsonParseException) {
                                // empty catch block
                            }
                        }
                        if (iTextComponent == null) {
                            try {
                                iTextComponent = ITextComponent.Serializer.fromJsonLenient(string);
                            }
                            catch (JsonParseException jsonParseException) {
                                // empty catch block
                            }
                        }
                        if (iTextComponent == null) {
                            iTextComponent = new TextComponentString(string);
                        }
                    } else {
                        iTextComponent = new TextComponentString(string);
                    }
                } else {
                    iTextComponent = new TextComponentString("");
                }
                nBTTagList.set(i, new NBTTagString(ITextComponent.Serializer.componentToJson(iTextComponent)));
            }
            nBTTagCompound2.setTag("pages", nBTTagList);
        }
        return nBTTagCompound;
    }
}
