package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ShulkerBoxItemColor
implements IFixableData {
    public static final String[] field_191278_a = new String[]{"minecraft:white_shulker_box", "minecraft:orange_shulker_box", "minecraft:magenta_shulker_box", "minecraft:light_blue_shulker_box", "minecraft:yellow_shulker_box", "minecraft:lime_shulker_box", "minecraft:pink_shulker_box", "minecraft:gray_shulker_box", "minecraft:silver_shulker_box", "minecraft:cyan_shulker_box", "minecraft:purple_shulker_box", "minecraft:blue_shulker_box", "minecraft:brown_shulker_box", "minecraft:green_shulker_box", "minecraft:red_shulker_box", "minecraft:black_shulker_box"};

    @Override
    public int getFixVersion() {
        return 813;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        NBTTagCompound nBTTagCompound2;
        if ("minecraft:shulker_box".equals(nBTTagCompound.getString("id")) && nBTTagCompound.hasKey("tag", 10) && (nBTTagCompound2 = nBTTagCompound.getCompoundTag("tag")).hasKey("BlockEntityTag", 10)) {
            NBTTagCompound nBTTagCompound3 = nBTTagCompound2.getCompoundTag("BlockEntityTag");
            if (nBTTagCompound3.getTagList("Items", 10).hasNoTags()) {
                nBTTagCompound3.removeTag("Items");
            }
            int n = nBTTagCompound3.getInteger("Color");
            nBTTagCompound3.removeTag("Color");
            if (nBTTagCompound3.hasNoTags()) {
                nBTTagCompound2.removeTag("BlockEntityTag");
            }
            if (nBTTagCompound2.hasNoTags()) {
                nBTTagCompound.removeTag("tag");
            }
            nBTTagCompound.setString("id", field_191278_a[n % 16]);
        }
        return nBTTagCompound;
    }
}
