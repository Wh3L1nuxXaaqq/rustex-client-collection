package net.minecraft.util.datafix.fixes;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class MinecartEntityTypes
implements IFixableData {
    private static final List<String> MINECART_TYPE_LIST = Lists.newArrayList("MinecartRideable", "MinecartChest", "MinecartFurnace", "MinecartTNT", "MinecartSpawner", "MinecartHopper", "MinecartCommandBlock");

    @Override
    public int getFixVersion() {
        return 106;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("Minecart".equals(nBTTagCompound.getString("id"))) {
            String string = "MinecartRideable";
            int n = nBTTagCompound.getInteger("Type");
            if (n > 0 && n < MINECART_TYPE_LIST.size()) {
                string = MINECART_TYPE_LIST.get(n);
            }
            nBTTagCompound.setString("id", string);
            nBTTagCompound.removeTag("Type");
        }
        return nBTTagCompound;
    }
}
