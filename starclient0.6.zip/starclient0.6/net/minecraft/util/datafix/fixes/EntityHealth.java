package net.minecraft.util.datafix.fixes;

import com.google.common.collect.Sets;
import java.util.Set;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class EntityHealth
implements IFixableData {
    private static final Set<String> ENTITY_LIST = Sets.newHashSet("ArmorStand", "Bat", "Blaze", "CaveSpider", "Chicken", "Cow", "Creeper", "EnderDragon", "Enderman", "Endermite", "EntityHorse", "Ghast", "Giant", "Guardian", "LavaSlime", "MushroomCow", "Ozelot", "Pig", "PigZombie", "Rabbit", "Sheep", "Shulker", "Silverfish", "Skeleton", "Slime", "SnowMan", "Spider", "Squid", "Villager", "VillagerGolem", "Witch", "WitherBoss", "Wolf", "Zombie");

    @Override
    public int getFixVersion() {
        return 109;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if (ENTITY_LIST.contains(nBTTagCompound.getString("id"))) {
            float f;
            if (nBTTagCompound.hasKey("HealF", 99)) {
                f = nBTTagCompound.getFloat("HealF");
                nBTTagCompound.removeTag("HealF");
            } else {
                if (!nBTTagCompound.hasKey("Health", 99)) {
                    return nBTTagCompound;
                }
                f = nBTTagCompound.getFloat("Health");
            }
            nBTTagCompound.setFloat("Health", f);
        }
        return nBTTagCompound;
    }
}
