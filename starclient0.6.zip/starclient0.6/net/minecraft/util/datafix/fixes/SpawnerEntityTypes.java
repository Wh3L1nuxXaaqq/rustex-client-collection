package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;

public class SpawnerEntityTypes
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 107;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        Object object;
        if (!"MobSpawner".equals(nBTTagCompound.getString("id"))) {
            return nBTTagCompound;
        }
        if (nBTTagCompound.hasKey("EntityId", 8)) {
            object = nBTTagCompound.getString("EntityId");
            NBTTagCompound nBTTagCompound2 = nBTTagCompound.getCompoundTag("SpawnData");
            nBTTagCompound2.setString("id", (String)(((String)object).isEmpty() ? "Pig" : object));
            nBTTagCompound.setTag("SpawnData", nBTTagCompound2);
            nBTTagCompound.removeTag("EntityId");
        }
        if (nBTTagCompound.hasKey("SpawnPotentials", 9)) {
            object = nBTTagCompound.getTagList("SpawnPotentials", 10);
            for (int i = 0; i < ((NBTTagList)object).tagCount(); ++i) {
                NBTTagCompound nBTTagCompound3 = ((NBTTagList)object).getCompoundTagAt(i);
                if (!nBTTagCompound3.hasKey("Type", 8)) continue;
                NBTTagCompound nBTTagCompound4 = nBTTagCompound3.getCompoundTag("Properties");
                nBTTagCompound4.setString("id", nBTTagCompound3.getString("Type"));
                nBTTagCompound3.setTag("Entity", nBTTagCompound4);
                nBTTagCompound3.removeTag("Type");
                nBTTagCompound3.removeTag("Properties");
            }
        }
        return nBTTagCompound;
    }
}
