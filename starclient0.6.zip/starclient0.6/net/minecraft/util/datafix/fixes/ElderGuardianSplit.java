package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ElderGuardianSplit
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 700;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("Guardian".equals(nBTTagCompound.getString("id"))) {
            if (nBTTagCompound.getBoolean("Elder")) {
                nBTTagCompound.setString("id", "ElderGuardian");
            }
            nBTTagCompound.removeTag("Elder");
        }
        return nBTTagCompound;
    }
}
