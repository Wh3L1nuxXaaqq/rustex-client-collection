package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ArmorStandSilent
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 147;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("ArmorStand".equals(nBTTagCompound.getString("id")) && nBTTagCompound.getBoolean("Silent") && !nBTTagCompound.getBoolean("Marker")) {
            nBTTagCompound.removeTag("Silent");
        }
        return nBTTagCompound;
    }
}
