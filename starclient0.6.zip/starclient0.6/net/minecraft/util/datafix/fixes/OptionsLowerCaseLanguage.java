package net.minecraft.util.datafix.fixes;

import java.util.Locale;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class OptionsLowerCaseLanguage
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 816;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if (nBTTagCompound.hasKey("lang", 8)) {
            nBTTagCompound.setString("lang", nBTTagCompound.getString("lang").toLowerCase(Locale.ROOT));
        }
        return nBTTagCompound;
    }
}
