package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;

public class RidingToPassengers
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 135;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        while (nBTTagCompound.hasKey("Riding", 10)) {
            NBTTagCompound nBTTagCompound2 = this.extractVehicle(nBTTagCompound);
            this.addPassengerToVehicle(nBTTagCompound, nBTTagCompound2);
            nBTTagCompound = nBTTagCompound2;
        }
        return nBTTagCompound;
    }

    protected void addPassengerToVehicle(NBTTagCompound nBTTagCompound, NBTTagCompound nBTTagCompound2) {
        NBTTagList nBTTagList = new NBTTagList();
        nBTTagList.appendTag(nBTTagCompound);
        nBTTagCompound2.setTag("Passengers", nBTTagList);
    }

    protected NBTTagCompound extractVehicle(NBTTagCompound nBTTagCompound) {
        NBTTagCompound nBTTagCompound2 = nBTTagCompound.getCompoundTag("Riding");
        nBTTagCompound.removeTag("Riding");
        return nBTTagCompound2;
    }
}
