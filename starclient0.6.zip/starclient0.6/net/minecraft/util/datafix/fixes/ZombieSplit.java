package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ZombieSplit
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 702;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("Zombie".equals(nBTTagCompound.getString("id"))) {
            int n = nBTTagCompound.getInteger("ZombieType");
            switch (n) {
                default: {
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: {
                    nBTTagCompound.setString("id", "ZombieVillager");
                    nBTTagCompound.setInteger("Profession", n - 1);
                    break;
                }
                case 6: {
                    nBTTagCompound.setString("id", "Husk");
                }
            }
            nBTTagCompound.removeTag("ZombieType");
        }
        return nBTTagCompound;
    }
}
