package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class HorseSplit
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 703;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("EntityHorse".equals(nBTTagCompound.getString("id"))) {
            int n = nBTTagCompound.getInteger("Type");
            switch (n) {
                default: {
                    nBTTagCompound.setString("id", "Horse");
                    break;
                }
                case 1: {
                    nBTTagCompound.setString("id", "Donkey");
                    break;
                }
                case 2: {
                    nBTTagCompound.setString("id", "Mule");
                    break;
                }
                case 3: {
                    nBTTagCompound.setString("id", "ZombieHorse");
                    break;
                }
                case 4: {
                    nBTTagCompound.setString("id", "SkeletonHorse");
                }
            }
            nBTTagCompound.removeTag("Type");
        }
        return nBTTagCompound;
    }
}
