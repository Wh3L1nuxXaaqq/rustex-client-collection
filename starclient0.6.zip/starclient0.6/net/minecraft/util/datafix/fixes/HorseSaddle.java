package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class HorseSaddle
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 110;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("EntityHorse".equals(nBTTagCompound.getString("id")) && !nBTTagCompound.hasKey("SaddleItem", 10) && nBTTagCompound.getBoolean("Saddle")) {
            NBTTagCompound nBTTagCompound2 = new NBTTagCompound();
            nBTTagCompound2.setString("id", "minecraft:saddle");
            nBTTagCompound2.setByte("Count", (byte)1);
            nBTTagCompound2.setShort("Damage", (short)0);
            nBTTagCompound.setTag("SaddleItem", nBTTagCompound2);
            nBTTagCompound.removeTag("Saddle");
        }
        return nBTTagCompound;
    }
}
