package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.datafix.IFixableData;

public class PaintingDirection
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 111;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        String string = nBTTagCompound.getString("id");
        boolean bl = "Painting".equals(string);
        boolean bl2 = "ItemFrame".equals(string);
        if ((bl || bl2) && !nBTTagCompound.hasKey("Facing", 99)) {
            EnumFacing enumFacing;
            if (nBTTagCompound.hasKey("Direction", 99)) {
                enumFacing = EnumFacing.getHorizontal(nBTTagCompound.getByte("Direction"));
                nBTTagCompound.setInteger("TileX", nBTTagCompound.getInteger("TileX") + enumFacing.getFrontOffsetX());
                nBTTagCompound.setInteger("TileY", nBTTagCompound.getInteger("TileY") + enumFacing.getFrontOffsetY());
                nBTTagCompound.setInteger("TileZ", nBTTagCompound.getInteger("TileZ") + enumFacing.getFrontOffsetZ());
                nBTTagCompound.removeTag("Direction");
                if (bl2 && nBTTagCompound.hasKey("ItemRotation", 99)) {
                    nBTTagCompound.setByte("ItemRotation", (byte)(nBTTagCompound.getByte("ItemRotation") * 2));
                }
            } else {
                enumFacing = EnumFacing.getHorizontal(nBTTagCompound.getByte("Dir"));
                nBTTagCompound.removeTag("Dir");
            }
            nBTTagCompound.setByte("Facing", (byte)enumFacing.getHorizontalIndex());
        }
        return nBTTagCompound;
    }
}
