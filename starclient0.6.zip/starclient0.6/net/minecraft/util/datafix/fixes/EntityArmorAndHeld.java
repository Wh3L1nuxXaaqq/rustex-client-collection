package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;

public class EntityArmorAndHeld
implements IFixableData {
    @Override
    public int getFixVersion() {
        return 100;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        NBTTagList nBTTagList;
        NBTTagList nBTTagList2 = nBTTagCompound.getTagList("Equipment", 10);
        if (!nBTTagList2.hasNoTags() && !nBTTagCompound.hasKey("HandItems", 10)) {
            nBTTagList = new NBTTagList();
            nBTTagList.appendTag(nBTTagList2.get(0));
            nBTTagList.appendTag(new NBTTagCompound());
            nBTTagCompound.setTag("HandItems", nBTTagList);
        }
        if (nBTTagList2.tagCount() > 1 && !nBTTagCompound.hasKey("ArmorItem", 10)) {
            nBTTagList = new NBTTagList();
            nBTTagList.appendTag(nBTTagList2.getCompoundTagAt(1));
            nBTTagList.appendTag(nBTTagList2.getCompoundTagAt(2));
            nBTTagList.appendTag(nBTTagList2.getCompoundTagAt(3));
            nBTTagList.appendTag(nBTTagList2.getCompoundTagAt(4));
            nBTTagCompound.setTag("ArmorItems", nBTTagList);
        }
        nBTTagCompound.removeTag("Equipment");
        if (nBTTagCompound.hasKey("DropChances", 9)) {
            NBTTagList nBTTagList3;
            nBTTagList = nBTTagCompound.getTagList("DropChances", 5);
            if (!nBTTagCompound.hasKey("HandDropChances", 10)) {
                nBTTagList3 = new NBTTagList();
                nBTTagList3.appendTag(new NBTTagFloat(nBTTagList.getFloatAt(0)));
                nBTTagList3.appendTag(new NBTTagFloat(0.0f));
                nBTTagCompound.setTag("HandDropChances", nBTTagList3);
            }
            if (!nBTTagCompound.hasKey("ArmorDropChances", 10)) {
                nBTTagList3 = new NBTTagList();
                nBTTagList3.appendTag(new NBTTagFloat(nBTTagList.getFloatAt(1)));
                nBTTagList3.appendTag(new NBTTagFloat(nBTTagList.getFloatAt(2)));
                nBTTagList3.appendTag(new NBTTagFloat(nBTTagList.getFloatAt(3)));
                nBTTagList3.appendTag(new NBTTagFloat(nBTTagList.getFloatAt(4)));
                nBTTagCompound.setTag("ArmorDropChances", nBTTagList3);
            }
            nBTTagCompound.removeTag("DropChances");
        }
        return nBTTagCompound;
    }
}
