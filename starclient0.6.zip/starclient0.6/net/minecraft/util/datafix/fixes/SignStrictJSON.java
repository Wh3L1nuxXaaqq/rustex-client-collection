package net.minecraft.util.datafix.fixes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.StringUtils;
import net.minecraft.util.datafix.IFixableData;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class SignStrictJSON
implements IFixableData {
    public static final Gson GSON_INSTANCE = new GsonBuilder().registerTypeAdapter((Type)((Object)ITextComponent.class), new JsonDeserializer<ITextComponent>(){

        @Override
        public ITextComponent deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            if (jsonElement.isJsonPrimitive()) {
                return new TextComponentString(jsonElement.getAsString());
            }
            if (jsonElement.isJsonArray()) {
                JsonArray jsonArray = jsonElement.getAsJsonArray();
                ITextComponent iTextComponent = null;
                for (JsonElement jsonElement2 : jsonArray) {
                    ITextComponent iTextComponent2 = this.deserialize(jsonElement2, jsonElement2.getClass(), jsonDeserializationContext);
                    if (iTextComponent == null) {
                        iTextComponent = iTextComponent2;
                        continue;
                    }
                    iTextComponent.appendSibling(iTextComponent2);
                }
                return iTextComponent;
            }
            throw new JsonParseException("Don't know how to turn " + String.valueOf(jsonElement) + " into a Component");
        }
    }).create();

    @Override
    public int getFixVersion() {
        return 101;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("Sign".equals(nBTTagCompound.getString("id"))) {
            this.updateLine(nBTTagCompound, "Text1");
            this.updateLine(nBTTagCompound, "Text2");
            this.updateLine(nBTTagCompound, "Text3");
            this.updateLine(nBTTagCompound, "Text4");
        }
        return nBTTagCompound;
    }

    private void updateLine(NBTTagCompound nBTTagCompound, String string) {
        String string2 = nBTTagCompound.getString(string);
        ITextComponent iTextComponent = null;
        if (!"null".equals(string2) && !StringUtils.isNullOrEmpty(string2)) {
            if (string2.charAt(0) == '\"' && string2.charAt(string2.length() - 1) == '\"' || string2.charAt(0) == '{' && string2.charAt(string2.length() - 1) == '}') {
                try {
                    iTextComponent = JsonUtils.gsonDeserialize(GSON_INSTANCE, string2, ITextComponent.class, true);
                    if (iTextComponent == null) {
                        iTextComponent = new TextComponentString("");
                    }
                }
                catch (JsonParseException jsonParseException) {
                    // empty catch block
                }
                if (iTextComponent == null) {
                    try {
                        iTextComponent = ITextComponent.Serializer.jsonToComponent(string2);
                    }
                    catch (JsonParseException jsonParseException) {
                        // empty catch block
                    }
                }
                if (iTextComponent == null) {
                    try {
                        iTextComponent = ITextComponent.Serializer.fromJsonLenient(string2);
                    }
                    catch (JsonParseException jsonParseException) {
                        // empty catch block
                    }
                }
                if (iTextComponent == null) {
                    iTextComponent = new TextComponentString(string2);
                }
            } else {
                iTextComponent = new TextComponentString(string2);
            }
        } else {
            iTextComponent = new TextComponentString("");
        }
        nBTTagCompound.setString(string, ITextComponent.Serializer.componentToJson(iTextComponent));
    }
}
