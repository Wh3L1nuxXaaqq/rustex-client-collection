package net.minecraft.util.datafix.fixes;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.datafix.IFixableData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AddBedTileEntity
implements IFixableData {
    private static final Logger field_193842_a = LogManager.getLogger();

    @Override
    public int getFixVersion() {
        return 1125;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        int n = 416;
        try {
            NBTTagCompound nBTTagCompound2 = nBTTagCompound.getCompoundTag("Level");
            int n2 = nBTTagCompound2.getInteger("xPos");
            int n3 = nBTTagCompound2.getInteger("zPos");
            NBTTagList nBTTagList = nBTTagCompound2.getTagList("TileEntities", 10);
            NBTTagList nBTTagList2 = nBTTagCompound2.getTagList("Sections", 10);
            for (int i = 0; i < nBTTagList2.tagCount(); ++i) {
                NBTTagCompound nBTTagCompound3 = nBTTagList2.getCompoundTagAt(i);
                byte by = nBTTagCompound3.getByte("Y");
                byte[] byArray = nBTTagCompound3.getByteArray("Blocks");
                for (int j = 0; j < byArray.length; ++j) {
                    if (416 != (byArray[j] & 0xFF) << 4) continue;
                    int n4 = j & 0xF;
                    int n5 = j >> 8 & 0xF;
                    int n6 = j >> 4 & 0xF;
                    NBTTagCompound nBTTagCompound4 = new NBTTagCompound();
                    nBTTagCompound4.setString("id", "bed");
                    nBTTagCompound4.setInteger("x", n4 + (n2 << 4));
                    nBTTagCompound4.setInteger("y", n5 + (by << 4));
                    nBTTagCompound4.setInteger("z", n6 + (n3 << 4));
                    nBTTagList.appendTag(nBTTagCompound4);
                }
            }
        }
        catch (Exception exception) {
            field_193842_a.warn("Unable to datafix Bed blocks, level format may be missing tags.");
        }
        return nBTTagCompound;
    }
}
