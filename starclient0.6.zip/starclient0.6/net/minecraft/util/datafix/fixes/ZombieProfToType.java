package net.minecraft.util.datafix.fixes;

import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.IFixableData;

public class ZombieProfToType
implements IFixableData {
    private static final Random RANDOM = new Random();

    @Override
    public int getFixVersion() {
        return 502;
    }

    @Override
    public NBTTagCompound fixTagCompound(NBTTagCompound nBTTagCompound) {
        if ("Zombie".equals(nBTTagCompound.getString("id")) && nBTTagCompound.getBoolean("IsVillager")) {
            if (!nBTTagCompound.hasKey("ZombieType", 99)) {
                int n = -1;
                if (nBTTagCompound.hasKey("VillagerProfession", 99)) {
                    try {
                        n = this.func_191277_a(nBTTagCompound.getInteger("VillagerProfession"));
                    }
                    catch (RuntimeException runtimeException) {
                        // empty catch block
                    }
                }
                if (n == -1) {
                    n = this.func_191277_a(RANDOM.nextInt(6));
                }
                nBTTagCompound.setInteger("ZombieType", n);
            }
            nBTTagCompound.removeTag("IsVillager");
        }
        return nBTTagCompound;
    }

    private int func_191277_a(int n) {
        return n >= 0 && n < 6 ? n : -1;
    }
}
