package net.minecraft.util.datafix.walkers;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;

public abstract class Filtered
implements IDataWalker {
    private final ResourceLocation key;

    public Filtered(Class<?> clazz) {
        this.key = Entity.class.isAssignableFrom(clazz) ? EntityList.func_191306_a(clazz) : (TileEntity.class.isAssignableFrom(clazz) ? TileEntity.func_190559_a(clazz) : null);
    }

    @Override
    public NBTTagCompound process(IDataFixer iDataFixer, NBTTagCompound nBTTagCompound, int n) {
        if (new ResourceLocation(nBTTagCompound.getString("id")).equals(this.key)) {
            nBTTagCompound = this.filteredProcess(iDataFixer, nBTTagCompound, n);
        }
        return nBTTagCompound;
    }

    abstract NBTTagCompound filteredProcess(IDataFixer var1, NBTTagCompound var2, int var3);
}
