package net.minecraft.util.datafix.walkers;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityTag
implements IDataWalker {
    private static final Logger LOGGER = LogManager.getLogger();

    @Override
    public NBTTagCompound process(IDataFixer iDataFixer, NBTTagCompound nBTTagCompound, int n) {
        NBTTagCompound nBTTagCompound2 = nBTTagCompound.getCompoundTag("tag");
        if (nBTTagCompound2.hasKey("EntityTag", 10)) {
            boolean bl;
            String string;
            NBTTagCompound nBTTagCompound3 = nBTTagCompound2.getCompoundTag("EntityTag");
            String string2 = nBTTagCompound.getString("id");
            if ("minecraft:armor_stand".equals(string2)) {
                string = n < 515 ? "ArmorStand" : "minecraft:armor_stand";
            } else {
                if (!"minecraft:spawn_egg".equals(string2)) {
                    return nBTTagCompound;
                }
                string = nBTTagCompound3.getString("id");
            }
            if (string == null) {
                LOGGER.warn("Unable to resolve Entity for ItemInstance: {}", (Object)string2);
                bl = false;
            } else {
                bl = !nBTTagCompound3.hasKey("id", 8);
                nBTTagCompound3.setString("id", string);
            }
            iDataFixer.process(FixTypes.ENTITY, nBTTagCompound3, n);
            if (bl) {
                nBTTagCompound3.removeTag("id");
            }
        }
        return nBTTagCompound;
    }
}
