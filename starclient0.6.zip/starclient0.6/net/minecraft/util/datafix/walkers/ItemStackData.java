package net.minecraft.util.datafix.walkers;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.datafix.DataFixesManager;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.walkers.Filtered;

public class ItemStackData
extends Filtered {
    private final String[] matchingTags;

    public ItemStackData(Class<?> clazz, String ... stringArray) {
        super(clazz);
        this.matchingTags = stringArray;
    }

    @Override
    NBTTagCompound filteredProcess(IDataFixer iDataFixer, NBTTagCompound nBTTagCompound, int n) {
        for (String string : this.matchingTags) {
            nBTTagCompound = DataFixesManager.processItemStack(iDataFixer, nBTTagCompound, n, string);
        }
        return nBTTagCompound;
    }
}
