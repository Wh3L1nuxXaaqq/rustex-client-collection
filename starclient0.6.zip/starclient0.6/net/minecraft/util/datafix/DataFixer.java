package net.minecraft.util.datafix;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.Util;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;
import net.minecraft.util.datafix.IFixType;
import net.minecraft.util.datafix.IFixableData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DataFixer
implements IDataFixer {
    private static final Logger LOGGER = LogManager.getLogger();
    private final Map<IFixType, List<IDataWalker>> walkerMap = Maps.newHashMap();
    private final Map<IFixType, List<IFixableData>> fixMap = Maps.newHashMap();
    private final int version;

    public DataFixer(int n) {
        this.version = n;
    }

    public NBTTagCompound process(IFixType iFixType, NBTTagCompound nBTTagCompound) {
        int n = nBTTagCompound.hasKey("DataVersion", 99) ? nBTTagCompound.getInteger("DataVersion") : -1;
        return n >= 1343 ? nBTTagCompound : this.process(iFixType, nBTTagCompound, n);
    }

    @Override
    public NBTTagCompound process(IFixType iFixType, NBTTagCompound nBTTagCompound, int n) {
        if (n < this.version) {
            nBTTagCompound = this.processFixes(iFixType, nBTTagCompound, n);
            nBTTagCompound = this.processWalkers(iFixType, nBTTagCompound, n);
        }
        return nBTTagCompound;
    }

    private NBTTagCompound processFixes(IFixType iFixType, NBTTagCompound nBTTagCompound, int n) {
        List<IFixableData> list = this.fixMap.get(iFixType);
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                IFixableData iFixableData = list.get(i);
                if (iFixableData.getFixVersion() <= n) continue;
                nBTTagCompound = iFixableData.fixTagCompound(nBTTagCompound);
            }
        }
        return nBTTagCompound;
    }

    private NBTTagCompound processWalkers(IFixType iFixType, NBTTagCompound nBTTagCompound, int n) {
        List<IDataWalker> list = this.walkerMap.get(iFixType);
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                nBTTagCompound = list.get(i).process(this, nBTTagCompound, n);
            }
        }
        return nBTTagCompound;
    }

    public void registerWalker(FixTypes fixTypes, IDataWalker iDataWalker) {
        this.registerWalkerAdd(fixTypes, iDataWalker);
    }

    public void registerWalkerAdd(IFixType iFixType, IDataWalker iDataWalker) {
        this.getTypeList(this.walkerMap, iFixType).add(iDataWalker);
    }

    public void registerFix(IFixType iFixType, IFixableData iFixableData) {
        List list = this.getTypeList(this.fixMap, iFixType);
        int n = iFixableData.getFixVersion();
        if (n > this.version) {
            LOGGER.warn("Ignored fix registered for version: {} as the DataVersion of the game is: {}", (Object)n, (Object)this.version);
        } else if (!list.isEmpty() && ((IFixableData)Util.getLastElement(list)).getFixVersion() > n) {
            for (int i = 0; i < list.size(); ++i) {
                if (((IFixableData)list.get(i)).getFixVersion() <= n) continue;
                list.add(i, iFixableData);
                break;
            }
        } else {
            list.add(iFixableData);
        }
    }

    private <V> List<V> getTypeList(Map<IFixType, List<V>> map, IFixType iFixType) {
        List<V> list = map.get(iFixType);
        if (list == null) {
            list = Lists.newArrayList();
            map.put(iFixType, list);
        }
        return list;
    }
}
