package net.minecraft.util;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.util.RecipeItemHelper;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.inventory.InventoryCraftResult;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.network.play.server.SPacketPlaceGhostRecipe;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ServerRecipeBookHelper {
    private final Logger field_194330_a = LogManager.getLogger();
    private final RecipeItemHelper field_194331_b = new RecipeItemHelper();
    private EntityPlayerMP field_194332_c;
    private IRecipe field_194333_d;
    private boolean field_194334_e;
    private InventoryCraftResult field_194335_f;
    private InventoryCrafting field_194336_g;
    private List<Slot> field_194337_h;

    public void func_194327_a(EntityPlayerMP entityPlayerMP, @Nullable IRecipe iRecipe, boolean bl) {
        if (iRecipe != null && entityPlayerMP.func_192037_E().func_193830_f(iRecipe)) {
            this.field_194332_c = entityPlayerMP;
            this.field_194333_d = iRecipe;
            this.field_194334_e = bl;
            this.field_194337_h = entityPlayerMP.openContainer.inventorySlots;
            Container container = entityPlayerMP.openContainer;
            this.field_194335_f = null;
            this.field_194336_g = null;
            if (container instanceof ContainerWorkbench) {
                this.field_194335_f = ((ContainerWorkbench)container).craftResult;
                this.field_194336_g = ((ContainerWorkbench)container).craftMatrix;
            } else if (container instanceof ContainerPlayer) {
                this.field_194335_f = ((ContainerPlayer)container).craftResult;
                this.field_194336_g = ((ContainerPlayer)container).craftMatrix;
            }
            if (this.field_194335_f != null && this.field_194336_g != null && (this.func_194328_c() || entityPlayerMP.isCreative())) {
                this.field_194331_b.func_194119_a();
                entityPlayerMP.inventory.func_194016_a(this.field_194331_b, false);
                this.field_194336_g.func_194018_a(this.field_194331_b);
                if (this.field_194331_b.func_194116_a(iRecipe, null)) {
                    this.func_194329_b();
                } else {
                    this.func_194326_a();
                    entityPlayerMP.connection.sendPacket(new SPacketPlaceGhostRecipe(entityPlayerMP.openContainer.windowId, iRecipe));
                }
                entityPlayerMP.inventory.markDirty();
            }
        }
    }

    private void func_194326_a() {
        InventoryPlayer inventoryPlayer = this.field_194332_c.inventory;
        for (int i = 0; i < this.field_194336_g.getSizeInventory(); ++i) {
            ItemStack itemStack = this.field_194336_g.getStackInSlot(i);
            if (itemStack.func_190926_b()) continue;
            while (itemStack.func_190916_E() > 0) {
                int n = inventoryPlayer.storeItemStack(itemStack);
                if (n == -1) {
                    n = inventoryPlayer.getFirstEmptyStack();
                }
                ItemStack itemStack2 = itemStack.copy();
                itemStack2.func_190920_e(1);
                inventoryPlayer.func_191971_c(n, itemStack2);
                this.field_194336_g.decrStackSize(i, 1);
            }
        }
        this.field_194336_g.clear();
        this.field_194335_f.clear();
    }

    private void func_194329_b() {
        IntArrayList intArrayList;
        int n;
        boolean bl = this.field_194333_d.matches(this.field_194336_g, this.field_194332_c.world);
        int n2 = this.field_194331_b.func_194114_b(this.field_194333_d, null);
        if (bl) {
            n = 1;
            for (int i = 0; i < this.field_194336_g.getSizeInventory(); ++i) {
                ItemStack itemStack = this.field_194336_g.getStackInSlot(i);
                if (itemStack.func_190926_b() || Math.min(n2, itemStack.getMaxStackSize()) <= itemStack.func_190916_E()) continue;
                n = 0;
            }
            if (n != 0) {
                return;
            }
        }
        if (this.field_194331_b.func_194118_a(this.field_194333_d, (IntList)(intArrayList = new IntArrayList()), n = this.func_194324_a(n2, bl))) {
            int n3 = n;
            IntListIterator intListIterator = intArrayList.iterator();
            while (intListIterator.hasNext()) {
                int n4 = (Integer)intListIterator.next();
                int n5 = RecipeItemHelper.func_194115_b(n4).getMaxStackSize();
                if (n5 >= n3) continue;
                n3 = n5;
            }
            if (this.field_194331_b.func_194118_a(this.field_194333_d, (IntList)intArrayList, n3)) {
                this.func_194326_a();
                this.func_194323_a(n3, (IntList)intArrayList);
            }
        }
    }

    private int func_194324_a(int n, boolean bl) {
        int n2 = 1;
        if (this.field_194334_e) {
            n2 = n;
        } else if (bl) {
            n2 = 64;
            for (int i = 0; i < this.field_194336_g.getSizeInventory(); ++i) {
                ItemStack itemStack = this.field_194336_g.getStackInSlot(i);
                if (itemStack.func_190926_b() || n2 <= itemStack.func_190916_E()) continue;
                n2 = itemStack.func_190916_E();
            }
            if (n2 < 64) {
                ++n2;
            }
        }
        return n2;
    }

    private void func_194323_a(int n, IntList intList) {
        int n2 = this.field_194336_g.getWidth();
        int n3 = this.field_194336_g.getHeight();
        if (this.field_194333_d instanceof ShapedRecipes) {
            ShapedRecipes shapedRecipes = (ShapedRecipes)this.field_194333_d;
            n2 = shapedRecipes.func_192403_f();
            n3 = shapedRecipes.func_192404_g();
        }
        int n4 = 1;
        IntListIterator intListIterator = intList.iterator();
        for (int i = 0; i < this.field_194336_g.getWidth() && n3 != i; ++i) {
            for (int j = 0; j < this.field_194336_g.getHeight(); ++j) {
                if (n2 == j || !intListIterator.hasNext()) {
                    n4 += this.field_194336_g.getWidth() - j;
                    break;
                }
                Slot slot = this.field_194337_h.get(n4);
                ItemStack itemStack = RecipeItemHelper.func_194115_b((Integer)intListIterator.next());
                if (itemStack.func_190926_b()) {
                    ++n4;
                    continue;
                }
                for (int k = 0; k < n; ++k) {
                    this.func_194325_a(slot, itemStack);
                }
                ++n4;
            }
            if (!intListIterator.hasNext()) break;
        }
    }

    private void func_194325_a(Slot slot, ItemStack itemStack) {
        ItemStack itemStack2;
        InventoryPlayer inventoryPlayer = this.field_194332_c.inventory;
        int n = inventoryPlayer.func_194014_c(itemStack);
        if (n != -1 && !(itemStack2 = inventoryPlayer.getStackInSlot(n).copy()).func_190926_b()) {
            if (itemStack2.func_190916_E() > 1) {
                inventoryPlayer.decrStackSize(n, 1);
            } else {
                inventoryPlayer.removeStackFromSlot(n);
            }
            itemStack2.func_190920_e(1);
            if (slot.getStack().func_190926_b()) {
                slot.putStack(itemStack2);
            } else {
                slot.getStack().func_190917_f(1);
            }
        }
    }

    private boolean func_194328_c() {
        InventoryPlayer inventoryPlayer = this.field_194332_c.inventory;
        for (int i = 0; i < this.field_194336_g.getSizeInventory(); ++i) {
            ItemStack itemStack = this.field_194336_g.getStackInSlot(i);
            if (itemStack.func_190926_b()) continue;
            int n = inventoryPlayer.storeItemStack(itemStack);
            if (n == -1) {
                n = inventoryPlayer.getFirstEmptyStack();
            }
            if (n != -1) continue;
            return false;
        }
        return true;
    }
}
