package net.minecraft.util;

import net.minecraft.util.math.MathHelper;
import org.apache.commons.lang3.Validate;

public class BitArray {
    private final long[] longArray;
    private final int bitsPerEntry;
    private final long maxEntryValue;
    private final int arraySize;

    public BitArray(int n, int n2) {
        Validate.inclusiveBetween((long)1L, (long)32L, (long)n);
        this.arraySize = n2;
        this.bitsPerEntry = n;
        this.maxEntryValue = (1L << n) - 1L;
        this.longArray = new long[MathHelper.roundUp(n2 * n, 64) / 64];
    }

    public void setAt(int n, int n2) {
        Validate.inclusiveBetween((long)0L, (long)(this.arraySize - 1), (long)n);
        Validate.inclusiveBetween((long)0L, (long)this.maxEntryValue, (long)n2);
        int n3 = n * this.bitsPerEntry;
        int n4 = n3 / 64;
        int n5 = ((n + 1) * this.bitsPerEntry - 1) / 64;
        int n6 = n3 % 64;
        this.longArray[n4] = this.longArray[n4] & (this.maxEntryValue << n6 ^ 0xFFFFFFFFFFFFFFFFL) | ((long)n2 & this.maxEntryValue) << n6;
        if (n4 != n5) {
            int n7 = 64 - n6;
            int n8 = this.bitsPerEntry - n7;
            this.longArray[n5] = this.longArray[n5] >>> n8 << n8 | ((long)n2 & this.maxEntryValue) >> n7;
        }
    }

    public int getAt(int n) {
        Validate.inclusiveBetween((long)0L, (long)(this.arraySize - 1), (long)n);
        int n2 = n * this.bitsPerEntry;
        int n3 = n2 / 64;
        int n4 = ((n + 1) * this.bitsPerEntry - 1) / 64;
        int n5 = n2 % 64;
        if (n3 == n4) {
            return (int)(this.longArray[n3] >>> n5 & this.maxEntryValue);
        }
        int n6 = 64 - n5;
        return (int)((this.longArray[n3] >>> n5 | this.longArray[n4] << n6) & this.maxEntryValue);
    }

    public long[] getBackingLongArray() {
        return this.longArray;
    }

    public int size() {
        return this.arraySize;
    }
}
