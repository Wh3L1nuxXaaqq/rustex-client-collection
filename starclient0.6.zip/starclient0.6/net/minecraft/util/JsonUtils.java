package net.minecraft.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import net.minecraft.item.Item;
import org.apache.commons.lang3.StringUtils;

public class JsonUtils {
    public static boolean isString(JsonObject jsonObject, String string) {
        return !JsonUtils.isJsonPrimitive(jsonObject, string) ? false : jsonObject.getAsJsonPrimitive(string).isString();
    }

    public static boolean isString(JsonElement jsonElement) {
        return !jsonElement.isJsonPrimitive() ? false : jsonElement.getAsJsonPrimitive().isString();
    }

    public static boolean isNumber(JsonElement jsonElement) {
        return !jsonElement.isJsonPrimitive() ? false : jsonElement.getAsJsonPrimitive().isNumber();
    }

    public static boolean isBoolean(JsonObject jsonObject, String string) {
        return !JsonUtils.isJsonPrimitive(jsonObject, string) ? false : jsonObject.getAsJsonPrimitive(string).isBoolean();
    }

    public static boolean isJsonArray(JsonObject jsonObject, String string) {
        return !JsonUtils.hasField(jsonObject, string) ? false : jsonObject.get(string).isJsonArray();
    }

    public static boolean isJsonPrimitive(JsonObject jsonObject, String string) {
        return !JsonUtils.hasField(jsonObject, string) ? false : jsonObject.get(string).isJsonPrimitive();
    }

    public static boolean hasField(JsonObject jsonObject, String string) {
        if (jsonObject == null) {
            return false;
        }
        return jsonObject.get(string) != null;
    }

    public static String getString(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive()) {
            return jsonElement.getAsString();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a string, was " + JsonUtils.toString(jsonElement));
    }

    public static String getString(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getString(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a string");
    }

    public static String getString(JsonObject jsonObject, String string, String string2) {
        return jsonObject.has(string) ? JsonUtils.getString(jsonObject.get(string), string) : string2;
    }

    public static Item getItem(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive()) {
            String string2 = jsonElement.getAsString();
            Item item = Item.getByNameOrId(string2);
            if (item == null) {
                throw new JsonSyntaxException("Expected " + string + " to be an item, was unknown string '" + string2 + "'");
            }
            return item;
        }
        throw new JsonSyntaxException("Expected " + string + " to be an item, was " + JsonUtils.toString(jsonElement));
    }

    public static Item getItem(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getItem(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find an item");
    }

    public static boolean getBoolean(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive()) {
            return jsonElement.getAsBoolean();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Boolean, was " + JsonUtils.toString(jsonElement));
    }

    public static boolean getBoolean(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getBoolean(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Boolean");
    }

    public static boolean getBoolean(JsonObject jsonObject, String string, boolean bl) {
        return jsonObject.has(string) ? JsonUtils.getBoolean(jsonObject.get(string), string) : bl;
    }

    public static float getFloat(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber()) {
            return jsonElement.getAsFloat();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Float, was " + JsonUtils.toString(jsonElement));
    }

    public static float getFloat(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getFloat(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Float");
    }

    public static float getFloat(JsonObject jsonObject, String string, float f) {
        return jsonObject.has(string) ? JsonUtils.getFloat(jsonObject.get(string), string) : f;
    }

    public static int getInt(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber()) {
            return jsonElement.getAsInt();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Int, was " + JsonUtils.toString(jsonElement));
    }

    public static int getInt(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getInt(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Int");
    }

    public static int getInt(JsonObject jsonObject, String string, int n) {
        return jsonObject.has(string) ? JsonUtils.getInt(jsonObject.get(string), string) : n;
    }

    public static JsonObject getJsonObject(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonObject()) {
            return jsonElement.getAsJsonObject();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a JsonObject, was " + JsonUtils.toString(jsonElement));
    }

    public static JsonObject getJsonObject(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getJsonObject(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a JsonObject");
    }

    public static JsonObject getJsonObject(JsonObject jsonObject, String string, JsonObject jsonObject2) {
        return jsonObject.has(string) ? JsonUtils.getJsonObject(jsonObject.get(string), string) : jsonObject2;
    }

    public static JsonArray getJsonArray(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonArray()) {
            return jsonElement.getAsJsonArray();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a JsonArray, was " + JsonUtils.toString(jsonElement));
    }

    public static JsonArray getJsonArray(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return JsonUtils.getJsonArray(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a JsonArray");
    }

    public static JsonArray getJsonArray(JsonObject jsonObject, String string, @Nullable JsonArray jsonArray) {
        return jsonObject.has(string) ? JsonUtils.getJsonArray(jsonObject.get(string), string) : jsonArray;
    }

    public static <T> T deserializeClass(@Nullable JsonElement jsonElement, String string, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> clazz) {
        if (jsonElement != null) {
            return jsonDeserializationContext.deserialize(jsonElement, clazz);
        }
        throw new JsonSyntaxException("Missing " + string);
    }

    public static <T> T deserializeClass(JsonObject jsonObject, String string, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> clazz) {
        if (jsonObject.has(string)) {
            return JsonUtils.deserializeClass(jsonObject.get(string), string, jsonDeserializationContext, clazz);
        }
        throw new JsonSyntaxException("Missing " + string);
    }

    public static <T> T deserializeClass(JsonObject jsonObject, String string, T t, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> clazz) {
        return jsonObject.has(string) ? JsonUtils.deserializeClass(jsonObject.get(string), string, jsonDeserializationContext, clazz) : t;
    }

    public static String toString(JsonElement jsonElement) {
        String string = StringUtils.abbreviateMiddle((String)String.valueOf(jsonElement), (String)"...", (int)10);
        if (jsonElement == null) {
            return "null (missing)";
        }
        if (jsonElement.isJsonNull()) {
            return "null (json)";
        }
        if (jsonElement.isJsonArray()) {
            return "an array (" + string + ")";
        }
        if (jsonElement.isJsonObject()) {
            return "an object (" + string + ")";
        }
        if (jsonElement.isJsonPrimitive()) {
            JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
            if (jsonPrimitive.isNumber()) {
                return "a number (" + string + ")";
            }
            if (jsonPrimitive.isBoolean()) {
                return "a boolean (" + string + ")";
            }
        }
        return string;
    }

    @Nullable
    public static <T> T gsonDeserialize(Gson gson, Reader reader, Class<T> clazz, boolean bl) {
        try {
            JsonReader jsonReader = new JsonReader(reader);
            jsonReader.setLenient(bl);
            return gson.getAdapter(clazz).read(jsonReader);
        }
        catch (IOException iOException) {
            throw new JsonParseException(iOException);
        }
    }

    @Nullable
    public static <T> T func_193838_a(Gson gson, Reader reader, Type type, boolean bl) {
        try {
            JsonReader jsonReader = new JsonReader(reader);
            jsonReader.setLenient(bl);
            return (T)gson.getAdapter(TypeToken.get(type)).read(jsonReader);
        }
        catch (IOException iOException) {
            throw new JsonParseException(iOException);
        }
    }

    @Nullable
    public static <T> T func_193837_a(Gson gson, String string, Type type, boolean bl) {
        return JsonUtils.func_193838_a(gson, new StringReader(string), type, bl);
    }

    @Nullable
    public static <T> T gsonDeserialize(Gson gson, String string, Class<T> clazz, boolean bl) {
        return JsonUtils.gsonDeserialize(gson, new StringReader(string), clazz, bl);
    }

    @Nullable
    public static <T> T func_193841_a(Gson gson, Reader reader, Type type) {
        return JsonUtils.func_193838_a(gson, reader, type, false);
    }

    @Nullable
    public static <T> T func_193840_a(Gson gson, String string, Type type) {
        return JsonUtils.func_193837_a(gson, string, type, false);
    }

    @Nullable
    public static <T> T func_193839_a(Gson gson, Reader reader, Class<T> clazz) {
        return JsonUtils.gsonDeserialize(gson, reader, clazz, false);
    }

    @Nullable
    public static <T> T gsonDeserialize(Gson gson, String string, Class<T> clazz) {
        return JsonUtils.gsonDeserialize(gson, string, clazz, false);
    }
}
