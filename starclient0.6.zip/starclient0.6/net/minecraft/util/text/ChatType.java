package net.minecraft.util.text;

public enum ChatType {
    CHAT(0),
    SYSTEM(1),
    GAME_INFO(2);

    private final byte field_192588_d;

    private ChatType(byte by) {
        this.field_192588_d = by;
    }

    public byte func_192583_a() {
        return this.field_192588_d;
    }

    public static ChatType func_192582_a(byte by) {
        for (ChatType chatType : ChatType.values()) {
            if (by != chatType.field_192588_d) continue;
            return chatType;
        }
        return CHAT;
    }
}
