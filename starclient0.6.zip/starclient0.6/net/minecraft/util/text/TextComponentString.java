package net.minecraft.util.text;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentBase;

public class TextComponentString
extends TextComponentBase {
    private final String text;

    public TextComponentString(String string) {
        this.text = string;
    }

    public String getText() {
        return this.text;
    }

    @Override
    public String getUnformattedComponentText() {
        return this.text;
    }

    @Override
    public TextComponentString createCopy() {
        TextComponentString textComponentString = new TextComponentString(this.text);
        textComponentString.setStyle(this.getStyle().createShallowCopy());
        for (ITextComponent iTextComponent : this.getSiblings()) {
            textComponentString.appendSibling(iTextComponent.createCopy());
        }
        return textComponentString;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentString)) {
            return false;
        }
        TextComponentString textComponentString = (TextComponentString)object;
        return this.text.equals(textComponentString.getText()) && super.equals(object);
    }

    @Override
    public String toString() {
        return "TextComponent{text='" + this.text + "', siblings=" + String.valueOf(this.siblings) + ", style=" + String.valueOf(this.getStyle()) + "}";
    }
}
