package net.minecraft.util.text;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentBase;

public class TextComponentSelector
extends TextComponentBase {
    private final String selector;

    public TextComponentSelector(String string) {
        this.selector = string;
    }

    public String getSelector() {
        return this.selector;
    }

    @Override
    public String getUnformattedComponentText() {
        return this.selector;
    }

    @Override
    public TextComponentSelector createCopy() {
        TextComponentSelector textComponentSelector = new TextComponentSelector(this.selector);
        textComponentSelector.setStyle(this.getStyle().createShallowCopy());
        for (ITextComponent iTextComponent : this.getSiblings()) {
            textComponentSelector.appendSibling(iTextComponent.createCopy());
        }
        return textComponentSelector;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentSelector)) {
            return false;
        }
        TextComponentSelector textComponentSelector = (TextComponentSelector)object;
        return this.selector.equals(textComponentSelector.selector) && super.equals(object);
    }

    @Override
    public String toString() {
        return "SelectorComponent{pattern='" + this.selector + "', siblings=" + String.valueOf(this.siblings) + ", style=" + String.valueOf(this.getStyle()) + "}";
    }
}
