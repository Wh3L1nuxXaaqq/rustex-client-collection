package net.minecraft.util.text;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentBase;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslationFormatException;
import net.minecraft.util.text.translation.I18n;

public class TextComponentTranslation
extends TextComponentBase {
    private final String key;
    private final Object[] formatArgs;
    private final Object syncLock = new Object();
    private long lastTranslationUpdateTimeInMilliseconds = -1L;
    @VisibleForTesting
    List<ITextComponent> children = Lists.newArrayList();
    public static final Pattern STRING_VARIABLE_PATTERN = Pattern.compile("%(?:(\\d+)\\$)?([A-Za-z%]|$)");

    public TextComponentTranslation(String string, Object ... objectArray) {
        this.key = string;
        this.formatArgs = objectArray;
        for (Object object : objectArray) {
            if (!(object instanceof ITextComponent)) continue;
            ((ITextComponent)object).getStyle().setParentStyle(this.getStyle());
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @VisibleForTesting
    synchronized void ensureInitialized() {
        Object object = this.syncLock;
        synchronized (object) {
            long l = I18n.getLastTranslationUpdateTimeInMilliseconds();
            if (l == this.lastTranslationUpdateTimeInMilliseconds) {
                return;
            }
            this.lastTranslationUpdateTimeInMilliseconds = l;
            this.children.clear();
        }
        try {
            this.initializeFromFormat(I18n.translateToLocal(this.key));
        }
        catch (TextComponentTranslationFormatException textComponentTranslationFormatException) {
            this.children.clear();
            try {
                this.initializeFromFormat(I18n.translateToFallback(this.key));
            }
            catch (TextComponentTranslationFormatException textComponentTranslationFormatException2) {
                throw textComponentTranslationFormatException;
            }
        }
    }

    protected void initializeFromFormat(String string) {
        boolean bl = false;
        Matcher matcher = STRING_VARIABLE_PATTERN.matcher(string);
        int n = 0;
        int n2 = 0;
        try {
            while (matcher.find(n2)) {
                Object object;
                int n3 = matcher.start();
                int n4 = matcher.end();
                if (n3 > n2) {
                    object = new TextComponentString(String.format(string.substring(n2, n3), new Object[0]));
                    ((TextComponentBase)object).getStyle().setParentStyle(this.getStyle());
                    this.children.add((ITextComponent)object);
                }
                object = matcher.group(2);
                String string2 = string.substring(n3, n4);
                if ("%".equals(object) && "%%".equals(string2)) {
                    var10_12 = new TextComponentString("%");
                    ((TextComponentBase)var10_12).getStyle().setParentStyle(this.getStyle());
                    this.children.add((ITextComponent)var10_12);
                } else {
                    int n5;
                    if (!"s".equals(object)) {
                        throw new TextComponentTranslationFormatException(this, "Unsupported format: '" + string2 + "'");
                    }
                    var10_12 = matcher.group(1);
                    int n6 = n5 = var10_12 != null ? Integer.parseInt((String)var10_12) - 1 : n++;
                    if (n5 < this.formatArgs.length) {
                        this.children.add(this.getFormatArgumentAsComponent(n5));
                    }
                }
                n2 = n4;
            }
            if (n2 < string.length()) {
                TextComponentString textComponentString = new TextComponentString(String.format(string.substring(n2), new Object[0]));
                textComponentString.getStyle().setParentStyle(this.getStyle());
                this.children.add(textComponentString);
            }
        }
        catch (IllegalFormatException illegalFormatException) {
            throw new TextComponentTranslationFormatException(this, (Throwable)illegalFormatException);
        }
    }

    private ITextComponent getFormatArgumentAsComponent(int n) {
        ITextComponent iTextComponent;
        if (n >= this.formatArgs.length) {
            throw new TextComponentTranslationFormatException(this, n);
        }
        Object object = this.formatArgs[n];
        if (object instanceof ITextComponent) {
            iTextComponent = (ITextComponent)object;
        } else {
            iTextComponent = new TextComponentString(object == null ? "null" : object.toString());
            iTextComponent.getStyle().setParentStyle(this.getStyle());
        }
        return iTextComponent;
    }

    @Override
    public ITextComponent setStyle(Style style) {
        super.setStyle(style);
        for (Object object : this.formatArgs) {
            if (!(object instanceof ITextComponent)) continue;
            ((ITextComponent)object).getStyle().setParentStyle(this.getStyle());
        }
        if (this.lastTranslationUpdateTimeInMilliseconds > -1L) {
            for (ITextComponent iTextComponent : this.children) {
                iTextComponent.getStyle().setParentStyle(style);
            }
        }
        return this;
    }

    @Override
    public Iterator<ITextComponent> iterator() {
        this.ensureInitialized();
        return Iterators.concat(TextComponentTranslation.createDeepCopyIterator(this.children), TextComponentTranslation.createDeepCopyIterator(this.siblings));
    }

    @Override
    public String getUnformattedComponentText() {
        this.ensureInitialized();
        StringBuilder stringBuilder = new StringBuilder();
        for (ITextComponent iTextComponent : this.children) {
            stringBuilder.append(iTextComponent.getUnformattedComponentText());
        }
        return stringBuilder.toString();
    }

    @Override
    public TextComponentTranslation createCopy() {
        Object[] objectArray = new Object[this.formatArgs.length];
        for (int i = 0; i < this.formatArgs.length; ++i) {
            objectArray[i] = this.formatArgs[i] instanceof ITextComponent ? ((ITextComponent)this.formatArgs[i]).createCopy() : this.formatArgs[i];
        }
        TextComponentTranslation textComponentTranslation = new TextComponentTranslation(this.key, objectArray);
        textComponentTranslation.setStyle(this.getStyle().createShallowCopy());
        for (ITextComponent iTextComponent : this.getSiblings()) {
            textComponentTranslation.appendSibling(iTextComponent.createCopy());
        }
        return textComponentTranslation;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentTranslation)) {
            return false;
        }
        TextComponentTranslation textComponentTranslation = (TextComponentTranslation)object;
        return Arrays.equals(this.formatArgs, textComponentTranslation.formatArgs) && this.key.equals(textComponentTranslation.key) && super.equals(object);
    }

    @Override
    public int hashCode() {
        int n = super.hashCode();
        n = 31 * n + this.key.hashCode();
        n = 31 * n + Arrays.hashCode(this.formatArgs);
        return n;
    }

    @Override
    public String toString() {
        return "TranslatableComponent{key='" + this.key + "', args=" + Arrays.toString(this.formatArgs) + ", siblings=" + String.valueOf(this.siblings) + ", style=" + String.valueOf(this.getStyle()) + "}";
    }

    public String getKey() {
        return this.key;
    }

    public Object[] getFormatArgs() {
        return this.formatArgs;
    }
}
