package net.minecraft.util.text;

import com.google.common.base.Function;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public abstract class TextComponentBase
implements ITextComponent {
    protected List<ITextComponent> siblings = Lists.newArrayList();
    private Style style;

    @Override
    public ITextComponent appendSibling(ITextComponent iTextComponent) {
        iTextComponent.getStyle().setParentStyle(this.getStyle());
        this.siblings.add(iTextComponent);
        return this;
    }

    @Override
    public List<ITextComponent> getSiblings() {
        return this.siblings;
    }

    @Override
    public ITextComponent appendText(String string) {
        return this.appendSibling(new TextComponentString(string));
    }

    @Override
    public ITextComponent setStyle(Style style) {
        this.style = style;
        for (ITextComponent iTextComponent : this.siblings) {
            iTextComponent.getStyle().setParentStyle(this.getStyle());
        }
        return this;
    }

    @Override
    public Style getStyle() {
        if (this.style == null) {
            this.style = new Style();
            for (ITextComponent iTextComponent : this.siblings) {
                iTextComponent.getStyle().setParentStyle(this.style);
            }
        }
        return this.style;
    }

    @Override
    public Iterator<ITextComponent> iterator() {
        return Iterators.concat(Iterators.forArray(this), TextComponentBase.createDeepCopyIterator(this.siblings));
    }

    @Override
    public final String getUnformattedText() {
        StringBuilder stringBuilder = new StringBuilder();
        for (ITextComponent iTextComponent : this) {
            stringBuilder.append(iTextComponent.getUnformattedComponentText());
        }
        return stringBuilder.toString();
    }

    @Override
    public final String getFormattedText() {
        StringBuilder stringBuilder = new StringBuilder();
        for (ITextComponent iTextComponent : this) {
            String string = iTextComponent.getUnformattedComponentText();
            if (string.isEmpty()) continue;
            stringBuilder.append(iTextComponent.getStyle().getFormattingCode());
            stringBuilder.append(string);
            stringBuilder.append((Object)TextFormatting.RESET);
        }
        return stringBuilder.toString();
    }

    public static Iterator<ITextComponent> createDeepCopyIterator(Iterable<ITextComponent> iterable) {
        Iterator<ITextComponent> iterator = Iterators.concat(Iterators.transform(iterable.iterator(), new Function<ITextComponent, Iterator<ITextComponent>>(){

            @Override
            public Iterator<ITextComponent> apply(@Nullable ITextComponent iTextComponent) {
                return iTextComponent.iterator();
            }
        }));
        iterator = Iterators.transform(iterator, new Function<ITextComponent, ITextComponent>(){

            @Override
            public ITextComponent apply(@Nullable ITextComponent iTextComponent) {
                ITextComponent iTextComponent2 = iTextComponent.createCopy();
                iTextComponent2.setStyle(iTextComponent2.getStyle().createDeepCopy());
                return iTextComponent2;
            }
        });
        return iterator;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentBase)) {
            return false;
        }
        TextComponentBase textComponentBase = (TextComponentBase)object;
        return this.siblings.equals(textComponentBase.siblings) && this.getStyle().equals(textComponentBase.getStyle());
    }

    public int hashCode() {
        return 31 * this.style.hashCode() + this.siblings.hashCode();
    }

    public String toString() {
        return "BaseComponent{style=" + String.valueOf(this.style) + ", siblings=" + String.valueOf(this.siblings) + "}";
    }
}
