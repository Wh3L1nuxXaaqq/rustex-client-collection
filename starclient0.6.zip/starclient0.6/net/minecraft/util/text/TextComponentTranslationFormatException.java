package net.minecraft.util.text;

import net.minecraft.util.text.TextComponentTranslation;

public class TextComponentTranslationFormatException
extends IllegalArgumentException {
    public TextComponentTranslationFormatException(TextComponentTranslation textComponentTranslation, String string) {
        super(String.format("Error parsing: %s: %s", textComponentTranslation, string));
    }

    public TextComponentTranslationFormatException(TextComponentTranslation textComponentTranslation, int n) {
        super(String.format("Invalid index %d requested for %s", n, textComponentTranslation));
    }

    public TextComponentTranslationFormatException(TextComponentTranslation textComponentTranslation, Throwable throwable) {
        super(String.format("Error while parsing: %s", textComponentTranslation), throwable);
    }
}
