package net.minecraft.util.text;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.text.event.HoverEvent;

public class Style {
    private Style parentStyle;
    private TextFormatting color;
    private Boolean bold;
    private Boolean italic;
    private Boolean underlined;
    private Boolean strikethrough;
    private Boolean obfuscated;
    private ClickEvent clickEvent;
    private HoverEvent hoverEvent;
    private String insertion;
    private static final Style ROOT = new Style(){

        @Override
        @Nullable
        public TextFormatting getColor() {
            return null;
        }

        @Override
        public boolean getBold() {
            return false;
        }

        @Override
        public boolean getItalic() {
            return false;
        }

        @Override
        public boolean getStrikethrough() {
            return false;
        }

        @Override
        public boolean getUnderlined() {
            return false;
        }

        @Override
        public boolean getObfuscated() {
            return false;
        }

        @Override
        @Nullable
        public ClickEvent getClickEvent() {
            return null;
        }

        @Override
        @Nullable
        public HoverEvent getHoverEvent() {
            return null;
        }

        @Override
        @Nullable
        public String getInsertion() {
            return null;
        }

        @Override
        public Style setColor(TextFormatting textFormatting) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setBold(Boolean bl) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setItalic(Boolean bl) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setStrikethrough(Boolean bl) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setUnderlined(Boolean bl) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setObfuscated(Boolean bl) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setClickEvent(ClickEvent clickEvent) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setHoverEvent(HoverEvent hoverEvent) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Style setParentStyle(Style style) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String toString() {
            return "Style.ROOT";
        }

        @Override
        public Style createShallowCopy() {
            return this;
        }

        @Override
        public Style createDeepCopy() {
            return this;
        }

        @Override
        public String getFormattingCode() {
            return "";
        }
    };

    @Nullable
    public TextFormatting getColor() {
        return this.color == null ? this.getParent().getColor() : this.color;
    }

    public boolean getBold() {
        return this.bold == null ? this.getParent().getBold() : this.bold.booleanValue();
    }

    public boolean getItalic() {
        return this.italic == null ? this.getParent().getItalic() : this.italic.booleanValue();
    }

    public boolean getStrikethrough() {
        return this.strikethrough == null ? this.getParent().getStrikethrough() : this.strikethrough.booleanValue();
    }

    public boolean getUnderlined() {
        return this.underlined == null ? this.getParent().getUnderlined() : this.underlined.booleanValue();
    }

    public boolean getObfuscated() {
        return this.obfuscated == null ? this.getParent().getObfuscated() : this.obfuscated.booleanValue();
    }

    public boolean isEmpty() {
        return this.bold == null && this.italic == null && this.strikethrough == null && this.underlined == null && this.obfuscated == null && this.color == null && this.clickEvent == null && this.hoverEvent == null && this.insertion == null;
    }

    @Nullable
    public ClickEvent getClickEvent() {
        return this.clickEvent == null ? this.getParent().getClickEvent() : this.clickEvent;
    }

    @Nullable
    public HoverEvent getHoverEvent() {
        return this.hoverEvent == null ? this.getParent().getHoverEvent() : this.hoverEvent;
    }

    @Nullable
    public String getInsertion() {
        return this.insertion == null ? this.getParent().getInsertion() : this.insertion;
    }

    public Style setColor(TextFormatting textFormatting) {
        this.color = textFormatting;
        return this;
    }

    public Style setBold(Boolean bl) {
        this.bold = bl;
        return this;
    }

    public Style setItalic(Boolean bl) {
        this.italic = bl;
        return this;
    }

    public Style setStrikethrough(Boolean bl) {
        this.strikethrough = bl;
        return this;
    }

    public Style setUnderlined(Boolean bl) {
        this.underlined = bl;
        return this;
    }

    public Style setObfuscated(Boolean bl) {
        this.obfuscated = bl;
        return this;
    }

    public Style setClickEvent(ClickEvent clickEvent) {
        this.clickEvent = clickEvent;
        return this;
    }

    public Style setHoverEvent(HoverEvent hoverEvent) {
        this.hoverEvent = hoverEvent;
        return this;
    }

    public Style setInsertion(String string) {
        this.insertion = string;
        return this;
    }

    public Style setParentStyle(Style style) {
        this.parentStyle = style;
        return this;
    }

    public String getFormattingCode() {
        if (this.isEmpty()) {
            return this.parentStyle != null ? this.parentStyle.getFormattingCode() : "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (this.getColor() != null) {
            stringBuilder.append((Object)this.getColor());
        }
        if (this.getBold()) {
            stringBuilder.append((Object)TextFormatting.BOLD);
        }
        if (this.getItalic()) {
            stringBuilder.append((Object)TextFormatting.ITALIC);
        }
        if (this.getUnderlined()) {
            stringBuilder.append((Object)TextFormatting.UNDERLINE);
        }
        if (this.getObfuscated()) {
            stringBuilder.append((Object)TextFormatting.OBFUSCATED);
        }
        if (this.getStrikethrough()) {
            stringBuilder.append((Object)TextFormatting.STRIKETHROUGH);
        }
        return stringBuilder.toString();
    }

    private Style getParent() {
        return this.parentStyle == null ? ROOT : this.parentStyle;
    }

    public String toString() {
        return "Style{hasParent=" + (this.parentStyle != null) + ", color=" + String.valueOf((Object)this.color) + ", bold=" + this.bold + ", italic=" + this.italic + ", underlined=" + this.underlined + ", obfuscated=" + this.obfuscated + ", clickEvent=" + String.valueOf(this.getClickEvent()) + ", hoverEvent=" + String.valueOf(this.getHoverEvent()) + ", insertion=" + this.getInsertion() + "}";
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Style)) {
            return false;
        }
        Style style = (Style)object;
        if (this.getBold() != style.getBold() || this.getColor() != style.getColor() || this.getItalic() != style.getItalic() || this.getObfuscated() != style.getObfuscated() || this.getStrikethrough() != style.getStrikethrough() || this.getUnderlined() != style.getUnderlined() || (this.getClickEvent() == null ? style.getClickEvent() != null : !this.getClickEvent().equals(style.getClickEvent())) || (this.getHoverEvent() == null ? style.getHoverEvent() != null : !this.getHoverEvent().equals(style.getHoverEvent())) || !(this.getInsertion() != null ? this.getInsertion().equals(style.getInsertion()) : style.getInsertion() == null)) {
            boolean bl = false;
            return bl;
        }
        boolean bl = true;
        return bl;
    }

    public int hashCode() {
        int n = this.color.hashCode();
        n = 31 * n + this.bold.hashCode();
        n = 31 * n + this.italic.hashCode();
        n = 31 * n + this.underlined.hashCode();
        n = 31 * n + this.strikethrough.hashCode();
        n = 31 * n + this.obfuscated.hashCode();
        n = 31 * n + this.clickEvent.hashCode();
        n = 31 * n + this.hoverEvent.hashCode();
        n = 31 * n + this.insertion.hashCode();
        return n;
    }

    public Style createShallowCopy() {
        Style style = new Style();
        style.bold = this.bold;
        style.italic = this.italic;
        style.strikethrough = this.strikethrough;
        style.underlined = this.underlined;
        style.obfuscated = this.obfuscated;
        style.color = this.color;
        style.clickEvent = this.clickEvent;
        style.hoverEvent = this.hoverEvent;
        style.parentStyle = this.parentStyle;
        style.insertion = this.insertion;
        return style;
    }

    public Style createDeepCopy() {
        Style style = new Style();
        style.setBold(this.getBold());
        style.setItalic(this.getItalic());
        style.setStrikethrough(this.getStrikethrough());
        style.setUnderlined(this.getUnderlined());
        style.setObfuscated(this.getObfuscated());
        style.setColor(this.getColor());
        style.setClickEvent(this.getClickEvent());
        style.setHoverEvent(this.getHoverEvent());
        style.setInsertion(this.getInsertion());
        return style;
    }

    public static class Serializer
    implements JsonDeserializer<Style>,
    JsonSerializer<Style> {
        @Override
        @Nullable
        public Style deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            if (jsonElement.isJsonObject()) {
                Object object;
                ClickEvent.Action action;
                JsonPrimitive jsonPrimitive;
                JsonObject jsonObject;
                Style style = new Style();
                JsonObject jsonObject2 = jsonElement.getAsJsonObject();
                if (jsonObject2 == null) {
                    return null;
                }
                if (jsonObject2.has("bold")) {
                    style.bold = jsonObject2.get("bold").getAsBoolean();
                }
                if (jsonObject2.has("italic")) {
                    style.italic = jsonObject2.get("italic").getAsBoolean();
                }
                if (jsonObject2.has("underlined")) {
                    style.underlined = jsonObject2.get("underlined").getAsBoolean();
                }
                if (jsonObject2.has("strikethrough")) {
                    style.strikethrough = jsonObject2.get("strikethrough").getAsBoolean();
                }
                if (jsonObject2.has("obfuscated")) {
                    style.obfuscated = jsonObject2.get("obfuscated").getAsBoolean();
                }
                if (jsonObject2.has("color")) {
                    style.color = (TextFormatting)((Object)jsonDeserializationContext.deserialize(jsonObject2.get("color"), (Type)((Object)TextFormatting.class)));
                }
                if (jsonObject2.has("insertion")) {
                    style.insertion = jsonObject2.get("insertion").getAsString();
                }
                if (jsonObject2.has("clickEvent") && (jsonObject = jsonObject2.getAsJsonObject("clickEvent")) != null) {
                    String string;
                    jsonPrimitive = jsonObject.getAsJsonPrimitive("action");
                    action = jsonPrimitive == null ? null : ClickEvent.Action.getValueByCanonicalName(jsonPrimitive.getAsString());
                    object = jsonObject.getAsJsonPrimitive("value");
                    String string2 = string = object == null ? null : ((JsonPrimitive)object).getAsString();
                    if (action != null && string != null && action.shouldAllowInChat()) {
                        style.clickEvent = new ClickEvent(action, string);
                    }
                }
                if (jsonObject2.has("hoverEvent") && (jsonObject = jsonObject2.getAsJsonObject("hoverEvent")) != null) {
                    jsonPrimitive = jsonObject.getAsJsonPrimitive("action");
                    action = jsonPrimitive == null ? null : HoverEvent.Action.getValueByCanonicalName(jsonPrimitive.getAsString());
                    object = (ITextComponent)jsonDeserializationContext.deserialize(jsonObject.get("value"), (Type)((Object)ITextComponent.class));
                    if (action != null && object != null && ((HoverEvent.Action)((Object)action)).shouldAllowInChat()) {
                        style.hoverEvent = new HoverEvent((HoverEvent.Action)((Object)action), (ITextComponent)object);
                    }
                }
                return style;
            }
            return null;
        }

        @Override
        @Nullable
        public JsonElement serialize(Style style, Type type, JsonSerializationContext jsonSerializationContext) {
            JsonObject jsonObject;
            if (style.isEmpty()) {
                return null;
            }
            JsonObject jsonObject2 = new JsonObject();
            if (style.bold != null) {
                jsonObject2.addProperty("bold", style.bold);
            }
            if (style.italic != null) {
                jsonObject2.addProperty("italic", style.italic);
            }
            if (style.underlined != null) {
                jsonObject2.addProperty("underlined", style.underlined);
            }
            if (style.strikethrough != null) {
                jsonObject2.addProperty("strikethrough", style.strikethrough);
            }
            if (style.obfuscated != null) {
                jsonObject2.addProperty("obfuscated", style.obfuscated);
            }
            if (style.color != null) {
                jsonObject2.add("color", jsonSerializationContext.serialize((Object)style.color));
            }
            if (style.insertion != null) {
                jsonObject2.add("insertion", jsonSerializationContext.serialize(style.insertion));
            }
            if (style.clickEvent != null) {
                jsonObject = new JsonObject();
                jsonObject.addProperty("action", style.clickEvent.getAction().getCanonicalName());
                jsonObject.addProperty("value", style.clickEvent.getValue());
                jsonObject2.add("clickEvent", jsonObject);
            }
            if (style.hoverEvent != null) {
                jsonObject = new JsonObject();
                jsonObject.addProperty("action", style.hoverEvent.getAction().getCanonicalName());
                jsonObject.add("value", jsonSerializationContext.serialize(style.hoverEvent.getValue()));
                jsonObject2.add("hoverEvent", jsonObject);
            }
            return jsonObject2;
        }
    }
}
