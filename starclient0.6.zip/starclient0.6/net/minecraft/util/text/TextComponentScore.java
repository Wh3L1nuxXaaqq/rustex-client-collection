package net.minecraft.util.text;

import net.minecraft.command.ICommandSender;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.StringUtils;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentBase;

public class TextComponentScore
extends TextComponentBase {
    private final String name;
    private final String objective;
    private String value = "";

    public TextComponentScore(String string, String string2) {
        this.name = string;
        this.objective = string2;
    }

    public String getName() {
        return this.name;
    }

    public String getObjective() {
        return this.objective;
    }

    public void setValue(String string) {
        this.value = string;
    }

    @Override
    public String getUnformattedComponentText() {
        return this.value;
    }

    public void resolve(ICommandSender iCommandSender) {
        MinecraftServer minecraftServer = iCommandSender.getServer();
        if (minecraftServer != null && minecraftServer.isAnvilFileSet() && StringUtils.isNullOrEmpty(this.value)) {
            ScoreObjective scoreObjective;
            Scoreboard scoreboard = minecraftServer.worldServerForDimension(0).getScoreboard();
            if (scoreboard.entityHasObjective(this.name, scoreObjective = scoreboard.getObjective(this.objective))) {
                Score score = scoreboard.getOrCreateScore(this.name, scoreObjective);
                this.setValue(String.format("%d", score.getScorePoints()));
            } else {
                this.value = "";
            }
        }
    }

    @Override
    public TextComponentScore createCopy() {
        TextComponentScore textComponentScore = new TextComponentScore(this.name, this.objective);
        textComponentScore.setValue(this.value);
        textComponentScore.setStyle(this.getStyle().createShallowCopy());
        for (ITextComponent iTextComponent : this.getSiblings()) {
            textComponentScore.appendSibling(iTextComponent.createCopy());
        }
        return textComponentScore;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentScore)) {
            return false;
        }
        TextComponentScore textComponentScore = (TextComponentScore)object;
        return this.name.equals(textComponentScore.name) && this.objective.equals(textComponentScore.objective) && super.equals(object);
    }

    @Override
    public String toString() {
        return "ScoreComponent{name='" + this.name + "'objective='" + this.objective + "', siblings=" + String.valueOf(this.siblings) + ", style=" + String.valueOf(this.getStyle()) + "}";
    }
}
