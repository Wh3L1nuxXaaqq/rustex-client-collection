package net.minecraft.util.text;

import java.util.List;
import net.minecraft.command.CommandException;
import net.minecraft.command.EntityNotFoundException;
import net.minecraft.command.EntitySelector;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentKeybind;
import net.minecraft.util.text.TextComponentScore;
import net.minecraft.util.text.TextComponentSelector;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;

public class TextComponentUtils {
    public static ITextComponent processComponent(ICommandSender iCommandSender, ITextComponent iTextComponent, Entity entity) throws CommandException {
        ITextComponent iTextComponent2;
        Object object;
        if (iTextComponent instanceof TextComponentScore) {
            object = (TextComponentScore)iTextComponent;
            String string = ((TextComponentScore)object).getName();
            if (EntitySelector.hasArguments(string)) {
                List<Entity> object2 = EntitySelector.matchEntities(iCommandSender, string, Entity.class);
                if (object2.size() != 1) {
                    throw new EntityNotFoundException("commands.generic.selector.notFound", string);
                }
                Entity entity2 = object2.get(0);
                string = entity2 instanceof EntityPlayer ? entity2.getName() : entity2.getCachedUniqueIdString();
            }
            String string2 = entity != null && string.equals("*") ? entity.getName() : string;
            iTextComponent2 = new TextComponentScore(string2, ((TextComponentScore)object).getObjective());
            ((TextComponentScore)iTextComponent2).setValue(((TextComponentScore)object).getUnformattedComponentText());
            ((TextComponentScore)iTextComponent2).resolve(iCommandSender);
        } else if (iTextComponent instanceof TextComponentSelector) {
            object = ((TextComponentSelector)iTextComponent).getSelector();
            iTextComponent2 = EntitySelector.matchEntitiesToTextComponent(iCommandSender, (String)object);
            if (iTextComponent2 == null) {
                iTextComponent2 = new TextComponentString("");
            }
        } else if (iTextComponent instanceof TextComponentString) {
            iTextComponent2 = new TextComponentString(((TextComponentString)iTextComponent).getText());
        } else if (iTextComponent instanceof TextComponentKeybind) {
            iTextComponent2 = new TextComponentKeybind(((TextComponentKeybind)iTextComponent).func_193633_h());
        } else {
            if (!(iTextComponent instanceof TextComponentTranslation)) {
                return iTextComponent;
            }
            object = ((TextComponentTranslation)iTextComponent).getFormatArgs();
            for (int i = 0; i < ((Object[])object).length; ++i) {
                Object object2 = object[i];
                if (!(object2 instanceof ITextComponent)) continue;
                object[i] = TextComponentUtils.processComponent(iCommandSender, (ITextComponent)object2, entity);
            }
            iTextComponent2 = new TextComponentTranslation(((TextComponentTranslation)iTextComponent).getKey(), (Object[])object);
        }
        object = iTextComponent.getStyle();
        if (object != null) {
            iTextComponent2.setStyle(((Style)object).createShallowCopy());
        }
        for (ITextComponent iTextComponent3 : iTextComponent.getSiblings()) {
            iTextComponent2.appendSibling(TextComponentUtils.processComponent(iCommandSender, iTextComponent3, entity));
        }
        return iTextComponent2;
    }
}
