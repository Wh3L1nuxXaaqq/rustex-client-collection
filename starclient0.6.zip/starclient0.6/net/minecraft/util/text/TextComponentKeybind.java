package net.minecraft.util.text;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentBase;

public class TextComponentKeybind
extends TextComponentBase {
    public static Function<String, Supplier<String>> field_193637_b = string -> () -> string;
    private final String field_193638_c;
    private Supplier<String> field_193639_d;

    public TextComponentKeybind(String string) {
        this.field_193638_c = string;
    }

    @Override
    public String getUnformattedComponentText() {
        if (this.field_193639_d == null) {
            this.field_193639_d = field_193637_b.apply(this.field_193638_c);
        }
        return this.field_193639_d.get();
    }

    @Override
    public TextComponentKeybind createCopy() {
        TextComponentKeybind textComponentKeybind = new TextComponentKeybind(this.field_193638_c);
        textComponentKeybind.setStyle(this.getStyle().createShallowCopy());
        for (ITextComponent iTextComponent : this.getSiblings()) {
            textComponentKeybind.appendSibling(iTextComponent.createCopy());
        }
        return textComponentKeybind;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof TextComponentKeybind)) {
            return false;
        }
        TextComponentKeybind textComponentKeybind = (TextComponentKeybind)object;
        return this.field_193638_c.equals(textComponentKeybind.field_193638_c) && super.equals(object);
    }

    @Override
    public String toString() {
        return "KeybindComponent{keybind='" + this.field_193638_c + "', siblings=" + String.valueOf(this.siblings) + ", style=" + String.valueOf(this.getStyle()) + "}";
    }

    public String func_193633_h() {
        return this.field_193638_c;
    }
}
