package net.minecraft.util.text;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.util.EnumTypeAdapterFactory;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentBase;
import net.minecraft.util.text.TextComponentKeybind;
import net.minecraft.util.text.TextComponentScore;
import net.minecraft.util.text.TextComponentSelector;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;

public interface ITextComponent
extends Iterable<ITextComponent> {
    public ITextComponent setStyle(Style var1);

    public Style getStyle();

    public ITextComponent appendText(String var1);

    public ITextComponent appendSibling(ITextComponent var1);

    public String getUnformattedComponentText();

    public String getUnformattedText();

    public String getFormattedText();

    public List<ITextComponent> getSiblings();

    public ITextComponent createCopy();

    public static class Serializer
    implements JsonDeserializer<ITextComponent>,
    JsonSerializer<ITextComponent> {
        private static final Gson GSON;

        @Override
        public ITextComponent deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            Object object;
            TextComponentBase textComponentBase;
            if (jsonElement.isJsonPrimitive()) {
                return new TextComponentString(jsonElement.getAsString());
            }
            if (!jsonElement.isJsonObject()) {
                if (jsonElement.isJsonArray()) {
                    JsonArray jsonArray = jsonElement.getAsJsonArray();
                    ITextComponent iTextComponent = null;
                    for (JsonElement jsonElement2 : jsonArray) {
                        ITextComponent iTextComponent2 = this.deserialize(jsonElement2, jsonElement2.getClass(), jsonDeserializationContext);
                        if (iTextComponent == null) {
                            iTextComponent = iTextComponent2;
                            continue;
                        }
                        iTextComponent.appendSibling(iTextComponent2);
                    }
                    return iTextComponent;
                }
                throw new JsonParseException("Don't know how to turn " + String.valueOf(jsonElement) + " into a Component");
            }
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            if (jsonObject.has("text")) {
                textComponentBase = new TextComponentString(jsonObject.get("text").getAsString());
            } else if (jsonObject.has("translate")) {
                object = jsonObject.get("translate").getAsString();
                if (jsonObject.has("with")) {
                    JsonArray jsonArray = jsonObject.getAsJsonArray("with");
                    Object[] objectArray = new Object[jsonArray.size()];
                    for (int i = 0; i < objectArray.length; ++i) {
                        TextComponentString textComponentString;
                        objectArray[i] = this.deserialize(jsonArray.get(i), type, jsonDeserializationContext);
                        if (!(objectArray[i] instanceof TextComponentString) || !(textComponentString = (TextComponentString)objectArray[i]).getStyle().isEmpty() || !textComponentString.getSiblings().isEmpty()) continue;
                        objectArray[i] = textComponentString.getText();
                    }
                    textComponentBase = new TextComponentTranslation((String)object, objectArray);
                } else {
                    textComponentBase = new TextComponentTranslation((String)object, new Object[0]);
                }
            } else if (jsonObject.has("score")) {
                object = jsonObject.getAsJsonObject("score");
                if (!((JsonObject)object).has("name") || !((JsonObject)object).has("objective")) {
                    throw new JsonParseException("A score component needs a least a name and an objective");
                }
                textComponentBase = new TextComponentScore(JsonUtils.getString((JsonObject)object, "name"), JsonUtils.getString((JsonObject)object, "objective"));
                if (((JsonObject)object).has("value")) {
                    ((TextComponentScore)textComponentBase).setValue(JsonUtils.getString((JsonObject)object, "value"));
                }
            } else if (jsonObject.has("selector")) {
                textComponentBase = new TextComponentSelector(JsonUtils.getString(jsonObject, "selector"));
            } else {
                if (!jsonObject.has("keybind")) {
                    throw new JsonParseException("Don't know how to turn " + String.valueOf(jsonElement) + " into a Component");
                }
                textComponentBase = new TextComponentKeybind(JsonUtils.getString(jsonObject, "keybind"));
            }
            if (jsonObject.has("extra")) {
                object = jsonObject.getAsJsonArray("extra");
                if (((JsonArray)object).size() <= 0) {
                    throw new JsonParseException("Unexpected empty array of components");
                }
                for (int i = 0; i < ((JsonArray)object).size(); ++i) {
                    textComponentBase.appendSibling(this.deserialize(((JsonArray)object).get(i), type, jsonDeserializationContext));
                }
            }
            textComponentBase.setStyle((Style)jsonDeserializationContext.deserialize(jsonElement, (Type)((Object)Style.class)));
            return textComponentBase;
        }

        private void serializeChatStyle(Style style, JsonObject jsonObject, JsonSerializationContext jsonSerializationContext) {
            JsonElement jsonElement = jsonSerializationContext.serialize(style);
            if (jsonElement.isJsonObject()) {
                JsonObject jsonObject2 = (JsonObject)jsonElement;
                for (Map.Entry<String, JsonElement> entry : jsonObject2.entrySet()) {
                    jsonObject.add(entry.getKey(), entry.getValue());
                }
            }
        }

        @Override
        public JsonElement serialize(ITextComponent iTextComponent, Type type, JsonSerializationContext jsonSerializationContext) {
            Iterable<JsonElement> iterable;
            JsonObject jsonObject = new JsonObject();
            if (!iTextComponent.getStyle().isEmpty()) {
                this.serializeChatStyle(iTextComponent.getStyle(), jsonObject, jsonSerializationContext);
            }
            if (!iTextComponent.getSiblings().isEmpty()) {
                iterable = new JsonArray();
                for (ITextComponent objectArray : iTextComponent.getSiblings()) {
                    ((JsonArray)iterable).add(this.serialize(objectArray, (Type)objectArray.getClass(), jsonSerializationContext));
                }
                jsonObject.add("extra", (JsonElement)((Object)iterable));
            }
            if (iTextComponent instanceof TextComponentString) {
                jsonObject.addProperty("text", ((TextComponentString)iTextComponent).getText());
            } else if (iTextComponent instanceof TextComponentTranslation) {
                iterable = (TextComponentTranslation)iTextComponent;
                jsonObject.addProperty("translate", ((TextComponentTranslation)iterable).getKey());
                if (((TextComponentTranslation)iterable).getFormatArgs() != null && ((TextComponentTranslation)iterable).getFormatArgs().length > 0) {
                    var6_6 = new JsonArray();
                    for (Object object : ((TextComponentTranslation)iterable).getFormatArgs()) {
                        if (object instanceof ITextComponent) {
                            ((JsonArray)var6_6).add(this.serialize((ITextComponent)object, (Type)object.getClass(), jsonSerializationContext));
                            continue;
                        }
                        ((JsonArray)var6_6).add(new JsonPrimitive(String.valueOf(object)));
                    }
                    jsonObject.add("with", (JsonElement)var6_6);
                }
            } else if (iTextComponent instanceof TextComponentScore) {
                iterable = (TextComponentScore)iTextComponent;
                var6_6 = new JsonObject();
                ((JsonObject)var6_6).addProperty("name", ((TextComponentScore)iterable).getName());
                ((JsonObject)var6_6).addProperty("objective", ((TextComponentScore)iterable).getObjective());
                ((JsonObject)var6_6).addProperty("value", ((TextComponentScore)iterable).getUnformattedComponentText());
                jsonObject.add("score", (JsonElement)var6_6);
            } else if (iTextComponent instanceof TextComponentSelector) {
                iterable = (TextComponentSelector)iTextComponent;
                jsonObject.addProperty("selector", ((TextComponentSelector)iterable).getSelector());
            } else {
                if (!(iTextComponent instanceof TextComponentKeybind)) {
                    throw new IllegalArgumentException("Don't know how to serialize " + String.valueOf(iTextComponent) + " as a Component");
                }
                iterable = (TextComponentKeybind)iTextComponent;
                jsonObject.addProperty("keybind", ((TextComponentKeybind)iterable).func_193633_h());
            }
            return jsonObject;
        }

        public static String componentToJson(ITextComponent iTextComponent) {
            return GSON.toJson(iTextComponent);
        }

        @Nullable
        public static ITextComponent jsonToComponent(String string) {
            return JsonUtils.gsonDeserialize(GSON, string, ITextComponent.class, false);
        }

        @Nullable
        public static ITextComponent fromJsonLenient(String string) {
            return JsonUtils.gsonDeserialize(GSON, string, ITextComponent.class, true);
        }

        static {
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeHierarchyAdapter(ITextComponent.class, new Serializer());
            gsonBuilder.registerTypeHierarchyAdapter(Style.class, new Style.Serializer());
            gsonBuilder.registerTypeAdapterFactory(new EnumTypeAdapterFactory());
            GSON = gsonBuilder.create();
        }
    }
}
