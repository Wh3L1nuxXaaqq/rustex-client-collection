package net.minecraft.util.text;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

public enum TextFormatting {
    BLACK("BLACK", '0', 0),
    DARK_BLUE("DARK_BLUE", '1', 1),
    DARK_GREEN("DARK_GREEN", '2', 2),
    DARK_AQUA("DARK_AQUA", '3', 3),
    DARK_RED("DARK_RED", '4', 4),
    DARK_PURPLE("DARK_PURPLE", '5', 5),
    GOLD("GOLD", '6', 6),
    GRAY("GRAY", '7', 7),
    DARK_GRAY("DARK_GRAY", '8', 8),
    BLUE("BLUE", '9', 9),
    GREEN("GREEN", 'a', 10),
    AQUA("AQUA", 'b', 11),
    RED("RED", 'c', 12),
    LIGHT_PURPLE("LIGHT_PURPLE", 'd', 13),
    YELLOW("YELLOW", 'e', 14),
    WHITE("WHITE", 'f', 15),
    OBFUSCATED("OBFUSCATED", 'k', true),
    BOLD("BOLD", 'l', true),
    STRIKETHROUGH("STRIKETHROUGH", 'm', true),
    UNDERLINE("UNDERLINE", 'n', true),
    ITALIC("ITALIC", 'o', true),
    RESET("RESET", 'r', -1);

    private static final Map<String, TextFormatting> NAME_MAPPING;
    private static final Pattern FORMATTING_CODE_PATTERN;
    private final String name;
    private final char formattingCode;
    private final boolean fancyStyling;
    private final String controlString;
    private final int colorIndex;

    private static String lowercaseAlpha(String string) {
        return string.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }

    private TextFormatting(String string2, char c, int n2) {
        this(string2, c, false, n2);
    }

    private TextFormatting(String string2, char c, boolean bl) {
        this(string2, c, bl, -1);
    }

    private TextFormatting(String string2, char c, boolean bl, int n2) {
        this.name = string2;
        this.formattingCode = c;
        this.fancyStyling = bl;
        this.colorIndex = n2;
        this.controlString = "\u00a7" + c;
    }

    public int getColorIndex() {
        return this.colorIndex;
    }

    public boolean isFancyStyling() {
        return this.fancyStyling;
    }

    public boolean isColor() {
        return !this.fancyStyling && this != RESET;
    }

    public String getFriendlyName() {
        return this.name().toLowerCase(Locale.ROOT);
    }

    public String toString() {
        return this.controlString;
    }

    @Nullable
    public static String getTextWithoutFormattingCodes(@Nullable String string) {
        return string == null ? null : FORMATTING_CODE_PATTERN.matcher(string).replaceAll("");
    }

    @Nullable
    public static TextFormatting getValueByName(@Nullable String string) {
        return string == null ? null : NAME_MAPPING.get(TextFormatting.lowercaseAlpha(string));
    }

    @Nullable
    public static TextFormatting fromColorIndex(int n) {
        if (n < 0) {
            return RESET;
        }
        for (TextFormatting textFormatting : TextFormatting.values()) {
            if (textFormatting.getColorIndex() != n) continue;
            return textFormatting;
        }
        return null;
    }

    public static Collection<String> getValidValues(boolean bl, boolean bl2) {
        ArrayList<String> arrayList = Lists.newArrayList();
        for (TextFormatting textFormatting : TextFormatting.values()) {
            if (textFormatting.isColor() && !bl || textFormatting.isFancyStyling() && !bl2) continue;
            arrayList.add(textFormatting.getFriendlyName());
        }
        return arrayList;
    }

    static {
        NAME_MAPPING = Maps.newHashMap();
        FORMATTING_CODE_PATTERN = Pattern.compile("(?i)\u00a7[0-9A-FK-OR]");
        for (TextFormatting textFormatting : TextFormatting.values()) {
            NAME_MAPPING.put(TextFormatting.lowercaseAlpha(textFormatting.name), textFormatting);
        }
    }
}
