package net.minecraft.util.registry;

import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.util.registry.IRegistry;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RegistrySimple<K, V>
implements IRegistry<K, V> {
    private static final Logger LOGGER = LogManager.getLogger();
    protected final Map<K, V> registryObjects = this.createUnderlyingMap();
    private Object[] values;

    protected Map<K, V> createUnderlyingMap() {
        return Maps.newHashMap();
    }

    @Override
    @Nullable
    public V getObject(@Nullable K k) {
        return this.registryObjects.get(k);
    }

    @Override
    public void putObject(K k, V v) {
        Validate.notNull(k);
        Validate.notNull(v);
        this.values = null;
        if (this.registryObjects.containsKey(k)) {
            LOGGER.debug("Adding duplicate key '{}' to registry", k);
        }
        this.registryObjects.put(k, v);
    }

    @Override
    public Set<K> getKeys() {
        return Collections.unmodifiableSet(this.registryObjects.keySet());
    }

    @Nullable
    public V getRandomObject(Random random) {
        if (this.values == null) {
            Collection<V> collection = this.registryObjects.values();
            if (collection.isEmpty()) {
                return null;
            }
            this.values = collection.toArray(new Object[collection.size()]);
        }
        return (V)this.values[random.nextInt(this.values.length)];
    }

    public boolean containsKey(K k) {
        return this.registryObjects.containsKey(k);
    }

    @Override
    public Iterator<V> iterator() {
        return this.registryObjects.values().iterator();
    }
}
