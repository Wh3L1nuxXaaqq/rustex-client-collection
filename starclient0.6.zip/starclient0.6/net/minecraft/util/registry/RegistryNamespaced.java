package net.minecraft.util.registry;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.util.IObjectIntIterable;
import net.minecraft.util.IntIdentityHashBiMap;
import net.minecraft.util.registry.RegistrySimple;

public class RegistryNamespaced<K, V>
extends RegistrySimple<K, V>
implements IObjectIntIterable<V> {
    protected final IntIdentityHashBiMap<V> underlyingIntegerMap = new IntIdentityHashBiMap(256);
    protected final Map<V, K> inverseObjectRegistry = ((BiMap)this.registryObjects).inverse();

    public void register(int n, K k, V v) {
        this.underlyingIntegerMap.put(v, n);
        this.putObject(k, v);
    }

    @Override
    protected Map<K, V> createUnderlyingMap() {
        return HashBiMap.create();
    }

    @Override
    @Nullable
    public V getObject(@Nullable K k) {
        return super.getObject(k);
    }

    @Nullable
    public K getNameForObject(V v) {
        return this.inverseObjectRegistry.get(v);
    }

    @Override
    public boolean containsKey(K k) {
        return super.containsKey(k);
    }

    public int getIDForObject(@Nullable V v) {
        return this.underlyingIntegerMap.getId(v);
    }

    @Nullable
    public V getObjectById(int n) {
        return this.underlyingIntegerMap.get(n);
    }

    @Override
    public Iterator<V> iterator() {
        return this.underlyingIntegerMap.iterator();
    }
}
