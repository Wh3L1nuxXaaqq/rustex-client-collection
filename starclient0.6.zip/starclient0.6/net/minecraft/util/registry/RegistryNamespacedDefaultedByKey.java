package net.minecraft.util.registry;

import java.util.Random;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.util.registry.RegistryNamespaced;
import org.apache.commons.lang3.Validate;

public class RegistryNamespacedDefaultedByKey<K, V>
extends RegistryNamespaced<K, V> {
    private final K defaultValueKey;
    private V defaultValue;

    public RegistryNamespacedDefaultedByKey(K k) {
        this.defaultValueKey = k;
    }

    @Override
    public void register(int n, K k, V v) {
        if (this.defaultValueKey.equals(k)) {
            this.defaultValue = v;
        }
        super.register(n, k, v);
    }

    public void validateKey() {
        Validate.notNull(this.defaultValue, (String)("Missing default of DefaultedMappedRegistry: " + String.valueOf(this.defaultValueKey)), (Object[])new Object[0]);
    }

    @Override
    public int getIDForObject(V v) {
        int n = super.getIDForObject(v);
        return n == -1 ? super.getIDForObject(this.defaultValue) : n;
    }

    @Override
    @Nonnull
    public K getNameForObject(V v) {
        Object k = super.getNameForObject(v);
        return k == null ? this.defaultValueKey : k;
    }

    @Override
    @Nonnull
    public V getObject(@Nullable K k) {
        Object v = super.getObject(k);
        return v == null ? this.defaultValue : v;
    }

    @Override
    @Nonnull
    public V getObjectById(int n) {
        Object v = super.getObjectById(n);
        return v == null ? this.defaultValue : v;
    }

    @Override
    @Nonnull
    public V getRandomObject(Random random) {
        Object v = super.getRandomObject(random);
        return v == null ? this.defaultValue : v;
    }
}
