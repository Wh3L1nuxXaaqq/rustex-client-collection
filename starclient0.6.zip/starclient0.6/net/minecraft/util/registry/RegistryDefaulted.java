package net.minecraft.util.registry;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.util.registry.RegistrySimple;

public class RegistryDefaulted<K, V>
extends RegistrySimple<K, V> {
    private final V defaultObject;

    public RegistryDefaulted(V v) {
        this.defaultObject = v;
    }

    @Override
    @Nonnull
    public V getObject(@Nullable K k) {
        Object v = super.getObject(k);
        return v == null ? this.defaultObject : v;
    }
}
