package net.minecraft.util;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.nio.IntBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.event.ClickEvent;
import optifine.Config;
import optifine.Reflector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.BufferUtils;

public class ScreenShotHelper {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");
    private static IntBuffer pixelBuffer;
    private static int[] pixelValues;

    public static ITextComponent saveScreenshot(File file, int n, int n2, Framebuffer framebuffer) {
        return ScreenShotHelper.saveScreenshot(file, null, n, n2, framebuffer);
    }

    public static ITextComponent saveScreenshot(File file, @Nullable String string, int n, int n2, Framebuffer framebuffer) {
        try {
            ITextComponent iTextComponent;
            boolean bl;
            File file2 = new File(file, "screenshots");
            file2.mkdir();
            Minecraft minecraft = Minecraft.getMinecraft();
            int n3 = Config.getGameSettings().guiScale;
            ScaledResolution scaledResolution = new ScaledResolution(minecraft);
            int n4 = scaledResolution.getScaleFactor();
            int n5 = Config.getScreenshotSize();
            boolean bl2 = bl = OpenGlHelper.isFramebufferEnabled() && n5 > 1;
            if (bl) {
                Config.getGameSettings().guiScale = n4 * n5;
                ScreenShotHelper.resize(n * n5, n2 * n5);
                GlStateManager.pushMatrix();
                GlStateManager.clear(16640);
                minecraft.getFramebuffer().bindFramebuffer(true);
                minecraft.entityRenderer.updateCameraAndRender(minecraft.getRenderPartialTicks(), System.nanoTime());
            }
            BufferedImage bufferedImage = ScreenShotHelper.createScreenshot(n, n2, framebuffer);
            if (bl) {
                minecraft.getFramebuffer().unbindFramebuffer();
                GlStateManager.popMatrix();
                Config.getGameSettings().guiScale = n3;
                ScreenShotHelper.resize(n, n2);
            }
            File file3 = string == null ? ScreenShotHelper.getTimestampedPNGFileForDirectory(file2) : new File(file2, string);
            file3 = file3.getCanonicalFile();
            Object object = null;
            if (Reflector.ForgeHooksClient_onScreenshot.exists()) {
                object = Reflector.call(Reflector.ForgeHooksClient_onScreenshot, bufferedImage, file3);
                if (Reflector.callBoolean(object, Reflector.Event_isCanceled, new Object[0])) {
                    return (ITextComponent)Reflector.call(object, Reflector.ScreenshotEvent_getCancelMessage, new Object[0]);
                }
                file3 = (File)Reflector.call(object, Reflector.ScreenshotEvent_getScreenshotFile, new Object[0]);
            }
            ImageIO.write((RenderedImage)bufferedImage, "png", file3);
            TextComponentString textComponentString = new TextComponentString(file3.getName());
            textComponentString.getStyle().setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, file3.getAbsolutePath()));
            textComponentString.getStyle().setUnderlined(true);
            if (object != null && (iTextComponent = (ITextComponent)Reflector.call(object, Reflector.ScreenshotEvent_getResultMessage, new Object[0])) != null) {
                return iTextComponent;
            }
            return new TextComponentTranslation("screenshot.success", textComponentString);
        }
        catch (Exception exception) {
            LOGGER.warn("Couldn't save screenshot", (Throwable)exception);
            return new TextComponentTranslation("screenshot.failure", exception.getMessage());
        }
    }

    public static BufferedImage createScreenshot(int n, int n2, Framebuffer framebuffer) {
        if (OpenGlHelper.isFramebufferEnabled()) {
            n = framebuffer.framebufferTextureWidth;
            n2 = framebuffer.framebufferTextureHeight;
        }
        int n3 = n * n2;
        if (pixelBuffer == null || pixelBuffer.capacity() < n3) {
            pixelBuffer = BufferUtils.createIntBuffer((int)n3);
            pixelValues = new int[n3];
        }
        GlStateManager.glPixelStorei(3333, 1);
        GlStateManager.glPixelStorei(3317, 1);
        pixelBuffer.clear();
        if (OpenGlHelper.isFramebufferEnabled()) {
            GlStateManager.bindTexture(framebuffer.framebufferTexture);
            GlStateManager.glGetTexImage(3553, 0, 32993, 33639, pixelBuffer);
        } else {
            GlStateManager.glReadPixels(0, 0, n, n2, 32993, 33639, pixelBuffer);
        }
        pixelBuffer.get(pixelValues);
        TextureUtil.processPixelValues(pixelValues, n, n2);
        BufferedImage bufferedImage = new BufferedImage(n, n2, 1);
        bufferedImage.setRGB(0, 0, n, n2, pixelValues, 0, n);
        return bufferedImage;
    }

    private static File getTimestampedPNGFileForDirectory(File file) {
        String string = DATE_FORMAT.format(new Date()).toString();
        int n = 1;
        File file2;
        while ((file2 = new File(file, string + (String)(n == 1 ? "" : "_" + n) + ".png")).exists()) {
            ++n;
        }
        return file2;
    }

    private static void resize(int n, int n2) {
        Minecraft minecraft = Minecraft.getMinecraft();
        minecraft.displayWidth = Math.max(1, n);
        minecraft.displayHeight = Math.max(1, n2);
        if (minecraft.currentScreen != null) {
            ScaledResolution scaledResolution = new ScaledResolution(minecraft);
            minecraft.currentScreen.onResize(minecraft, scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
        }
        ScreenShotHelper.updateFramebufferSize();
    }

    private static void updateFramebufferSize() {
        Minecraft minecraft = Minecraft.getMinecraft();
        minecraft.getFramebuffer().createBindFramebuffer(minecraft.displayWidth, minecraft.displayHeight);
        if (minecraft.entityRenderer != null) {
            minecraft.entityRenderer.updateShaderGroupSize(minecraft.displayWidth, minecraft.displayHeight);
        }
    }
}
