package net.minecraft.util;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Set;

public enum SoundCategory {
    MASTER("master"),
    MUSIC("music"),
    RECORDS("record"),
    WEATHER("weather"),
    BLOCKS("block"),
    HOSTILE("hostile"),
    NEUTRAL("neutral"),
    PLAYERS("player"),
    AMBIENT("ambient"),
    VOICE("voice");

    private static final Map<String, SoundCategory> SOUND_CATEGORIES;
    private final String name;

    private SoundCategory(String string2) {
        this.name = string2;
    }

    public String getName() {
        return this.name;
    }

    public static SoundCategory getByName(String string) {
        return SOUND_CATEGORIES.get(string);
    }

    public static Set<String> getSoundCategoryNames() {
        return SOUND_CATEGORIES.keySet();
    }

    static {
        SOUND_CATEGORIES = Maps.newHashMap();
        for (SoundCategory soundCategory : SoundCategory.values()) {
            if (SOUND_CATEGORIES.containsKey(soundCategory.getName())) {
                throw new Error("Clash in Sound Category name pools! Cannot insert " + String.valueOf((Object)soundCategory));
            }
            SOUND_CATEGORIES.put(soundCategory.getName(), soundCategory);
        }
    }
}
