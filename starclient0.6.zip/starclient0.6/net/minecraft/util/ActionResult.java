package net.minecraft.util;

import net.minecraft.util.EnumActionResult;

public class ActionResult<T> {
    private final EnumActionResult type;
    private final T result;

    public ActionResult(EnumActionResult enumActionResult, T t) {
        this.type = enumActionResult;
        this.result = t;
    }

    public EnumActionResult getType() {
        return this.type;
    }

    public T getResult() {
        return this.result;
    }
}
