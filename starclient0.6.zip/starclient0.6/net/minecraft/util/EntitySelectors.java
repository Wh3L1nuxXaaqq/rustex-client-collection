package net.minecraft.util;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Team;

public final class EntitySelectors {
    public static final Predicate<Entity> IS_ALIVE = new Predicate<Entity>(){

        @Override
        public boolean apply(@Nullable Entity entity) {
            return entity.isEntityAlive();
        }
    };
    public static final Predicate<Entity> IS_STANDALONE = new Predicate<Entity>(){

        @Override
        public boolean apply(@Nullable Entity entity) {
            return entity.isEntityAlive() && !entity.isBeingRidden() && !entity.isRiding();
        }
    };
    public static final Predicate<Entity> HAS_INVENTORY = new Predicate<Entity>(){

        @Override
        public boolean apply(@Nullable Entity entity) {
            return entity instanceof IInventory && entity.isEntityAlive();
        }
    };
    public static final Predicate<Entity> CAN_AI_TARGET = new Predicate<Entity>(){

        @Override
        public boolean apply(@Nullable Entity entity) {
            return !(entity instanceof EntityPlayer) || !((EntityPlayer)entity).isSpectator() && !((EntityPlayer)entity).isCreative();
        }
    };
    public static final Predicate<Entity> NOT_SPECTATING = new Predicate<Entity>(){

        @Override
        public boolean apply(@Nullable Entity entity) {
            return !(entity instanceof EntityPlayer) || !((EntityPlayer)entity).isSpectator();
        }
    };

    public static <T extends Entity> Predicate<T> withinRange(final double d, final double d2, final double d3, double d4) {
        final double d5 = d4 * d4;
        return new Predicate<T>(){

            @Override
            public boolean apply(@Nullable T t) {
                return t != null && ((Entity)t).getDistanceSq(d, d2, d3) <= d5;
            }
        };
    }

    public static <T extends Entity> Predicate<T> getTeamCollisionPredicate(final Entity entity) {
        final Team team = entity.getTeam();
        final Team.CollisionRule collisionRule = team == null ? Team.CollisionRule.ALWAYS : team.getCollisionRule();
        Predicate predicate = collisionRule == Team.CollisionRule.NEVER ? Predicates.alwaysFalse() : Predicates.and(NOT_SPECTATING, new Predicate<Entity>(){

            @Override
            public boolean apply(@Nullable Entity entity2) {
                if (!entity2.canBePushed()) {
                    return false;
                }
                if (!entity.world.isRemote || entity2 instanceof EntityPlayer && ((EntityPlayer)entity2).isUser()) {
                    boolean bl;
                    Team.CollisionRule collisionRule3;
                    Team team2 = entity2.getTeam();
                    Team.CollisionRule collisionRule2 = collisionRule3 = team2 == null ? Team.CollisionRule.ALWAYS : team2.getCollisionRule();
                    if (collisionRule3 == Team.CollisionRule.NEVER) {
                        return false;
                    }
                    boolean bl2 = bl = team != null && team.isSameTeam(team2);
                    if ((collisionRule == Team.CollisionRule.HIDE_FOR_OWN_TEAM || collisionRule3 == Team.CollisionRule.HIDE_FOR_OWN_TEAM) && bl) {
                        return false;
                    }
                    return collisionRule != Team.CollisionRule.HIDE_FOR_OTHER_TEAMS && collisionRule3 != Team.CollisionRule.HIDE_FOR_OTHER_TEAMS || bl;
                }
                return false;
            }
        });
        return predicate;
    }

    public static Predicate<Entity> func_191324_b(final Entity entity) {
        return new Predicate<Entity>(){

            @Override
            public boolean apply(@Nullable Entity entity2) {
                while (entity2.isRiding()) {
                    if ((entity2 = entity2.getRidingEntity()) != entity) continue;
                    return false;
                }
                return true;
            }
        };
    }

    public static class ArmoredMob
    implements Predicate<Entity> {
        private final ItemStack armor;

        public ArmoredMob(ItemStack itemStack) {
            this.armor = itemStack;
        }

        @Override
        public boolean apply(@Nullable Entity entity) {
            if (!entity.isEntityAlive()) {
                return false;
            }
            if (!(entity instanceof EntityLivingBase)) {
                return false;
            }
            EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            if (!entityLivingBase.getItemStackFromSlot(EntityLiving.getSlotForItemStack(this.armor)).func_190926_b()) {
                return false;
            }
            if (entityLivingBase instanceof EntityLiving) {
                return ((EntityLiving)entityLivingBase).canPickUpLoot();
            }
            if (entityLivingBase instanceof EntityArmorStand) {
                return true;
            }
            return entityLivingBase instanceof EntityPlayer;
        }
    }
}
