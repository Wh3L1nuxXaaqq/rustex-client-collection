package net.minecraft.util;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.translation.I18n;

public class EntityDamageSourceIndirect
extends EntityDamageSource {
    private final Entity indirectEntity;

    public EntityDamageSourceIndirect(String string, Entity entity, @Nullable Entity entity2) {
        super(string, entity);
        this.indirectEntity = entity2;
    }

    @Override
    @Nullable
    public Entity getSourceOfDamage() {
        return this.damageSourceEntity;
    }

    @Override
    @Nullable
    public Entity getEntity() {
        return this.indirectEntity;
    }

    @Override
    public ITextComponent getDeathMessage(EntityLivingBase entityLivingBase) {
        ITextComponent iTextComponent = this.indirectEntity == null ? this.damageSourceEntity.getDisplayName() : this.indirectEntity.getDisplayName();
        ItemStack itemStack = this.indirectEntity instanceof EntityLivingBase ? ((EntityLivingBase)this.indirectEntity).getHeldItemMainhand() : ItemStack.field_190927_a;
        String string = "death.attack." + this.damageType;
        String string2 = string + ".item";
        return !itemStack.func_190926_b() && itemStack.hasDisplayName() && I18n.canTranslate(string2) ? new TextComponentTranslation(string2, entityLivingBase.getDisplayName(), iTextComponent, itemStack.getTextComponent()) : new TextComponentTranslation(string, entityLivingBase.getDisplayName(), iTextComponent);
    }
}
