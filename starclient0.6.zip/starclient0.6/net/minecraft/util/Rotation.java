package net.minecraft.util;

import net.minecraft.util.EnumFacing;

public enum Rotation {
    NONE("rotate_0"),
    CLOCKWISE_90("rotate_90"),
    CLOCKWISE_180("rotate_180"),
    COUNTERCLOCKWISE_90("rotate_270");

    private final String name;
    private static final String[] rotationNames;

    private Rotation(String string2) {
        this.name = string2;
    }

    public Rotation add(Rotation rotation) {
        switch (rotation) {
            case CLOCKWISE_180: {
                switch (this) {
                    case NONE: {
                        return CLOCKWISE_180;
                    }
                    case CLOCKWISE_90: {
                        return COUNTERCLOCKWISE_90;
                    }
                    case CLOCKWISE_180: {
                        return NONE;
                    }
                    case COUNTERCLOCKWISE_90: {
                        return CLOCKWISE_90;
                    }
                }
            }
            case COUNTERCLOCKWISE_90: {
                switch (this) {
                    case NONE: {
                        return COUNTERCLOCKWISE_90;
                    }
                    case CLOCKWISE_90: {
                        return NONE;
                    }
                    case CLOCKWISE_180: {
                        return CLOCKWISE_90;
                    }
                    case COUNTERCLOCKWISE_90: {
                        return CLOCKWISE_180;
                    }
                }
            }
            case CLOCKWISE_90: {
                switch (this) {
                    case NONE: {
                        return CLOCKWISE_90;
                    }
                    case CLOCKWISE_90: {
                        return CLOCKWISE_180;
                    }
                    case CLOCKWISE_180: {
                        return COUNTERCLOCKWISE_90;
                    }
                    case COUNTERCLOCKWISE_90: {
                        return NONE;
                    }
                }
            }
        }
        return this;
    }

    public EnumFacing rotate(EnumFacing enumFacing) {
        if (enumFacing.getAxis() == EnumFacing.Axis.Y) {
            return enumFacing;
        }
        switch (this) {
            case CLOCKWISE_90: {
                return enumFacing.rotateY();
            }
            case CLOCKWISE_180: {
                return enumFacing.getOpposite();
            }
            case COUNTERCLOCKWISE_90: {
                return enumFacing.rotateYCCW();
            }
        }
        return enumFacing;
    }

    public int rotate(int n, int n2) {
        switch (this) {
            case CLOCKWISE_90: {
                return (n + n2 / 4) % n2;
            }
            case CLOCKWISE_180: {
                return (n + n2 / 2) % n2;
            }
            case COUNTERCLOCKWISE_90: {
                return (n + n2 * 3 / 4) % n2;
            }
        }
        return n;
    }

    static {
        rotationNames = new String[Rotation.values().length];
        int n = 0;
        for (Rotation rotation : Rotation.values()) {
            Rotation.rotationNames[n++] = rotation.name;
        }
    }
}
