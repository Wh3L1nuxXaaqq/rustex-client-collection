package net.minecraft.util;

import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.CombatEntry;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;

public class CombatTracker {
    private final List<CombatEntry> combatEntries = Lists.newArrayList();
    private final EntityLivingBase fighter;
    private int lastDamageTime;
    private int combatStartTime;
    private int combatEndTime;
    private boolean inCombat;
    private boolean takingDamage;
    private String fallSuffix;

    public CombatTracker(EntityLivingBase entityLivingBase) {
        this.fighter = entityLivingBase;
    }

    public void calculateFallSuffix() {
        this.resetFallSuffix();
        if (this.fighter.isOnLadder()) {
            Block block = this.fighter.world.getBlockState(new BlockPos(this.fighter.posX, this.fighter.getEntityBoundingBox().minY, this.fighter.posZ)).getBlock();
            if (block == Blocks.LADDER) {
                this.fallSuffix = "ladder";
            } else if (block == Blocks.VINE) {
                this.fallSuffix = "vines";
            }
        } else if (this.fighter.isInWater()) {
            this.fallSuffix = "water";
        }
    }

    public void trackDamage(DamageSource damageSource, float f, float f2) {
        this.reset();
        this.calculateFallSuffix();
        CombatEntry combatEntry = new CombatEntry(damageSource, this.fighter.ticksExisted, f, f2, this.fallSuffix, this.fighter.fallDistance);
        this.combatEntries.add(combatEntry);
        this.lastDamageTime = this.fighter.ticksExisted;
        this.takingDamage = true;
        if (combatEntry.isLivingDamageSrc() && !this.inCombat && this.fighter.isEntityAlive()) {
            this.inCombat = true;
            this.combatEndTime = this.combatStartTime = this.fighter.ticksExisted;
            this.fighter.sendEnterCombat();
        }
    }

    public ITextComponent getDeathMessage() {
        ITextComponent iTextComponent;
        if (this.combatEntries.isEmpty()) {
            return new TextComponentTranslation("death.attack.generic", this.fighter.getDisplayName());
        }
        CombatEntry combatEntry = this.getBestCombatEntry();
        CombatEntry combatEntry2 = this.combatEntries.get(this.combatEntries.size() - 1);
        ITextComponent iTextComponent2 = combatEntry2.getDamageSrcDisplayName();
        Entity entity = combatEntry2.getDamageSrc().getEntity();
        if (combatEntry != null && combatEntry2.getDamageSrc() == DamageSource.fall) {
            ITextComponent iTextComponent3 = combatEntry.getDamageSrcDisplayName();
            if (combatEntry.getDamageSrc() != DamageSource.fall && combatEntry.getDamageSrc() != DamageSource.outOfWorld) {
                if (!(iTextComponent3 == null || iTextComponent2 != null && iTextComponent3.equals(iTextComponent2))) {
                    ItemStack itemStack;
                    Entity entity2 = combatEntry.getDamageSrc().getEntity();
                    ItemStack itemStack2 = itemStack = entity2 instanceof EntityLivingBase ? ((EntityLivingBase)entity2).getHeldItemMainhand() : ItemStack.field_190927_a;
                    iTextComponent = !itemStack.func_190926_b() && itemStack.hasDisplayName() ? new TextComponentTranslation("death.fell.assist.item", this.fighter.getDisplayName(), iTextComponent3, itemStack.getTextComponent()) : new TextComponentTranslation("death.fell.assist", this.fighter.getDisplayName(), iTextComponent3);
                } else if (iTextComponent2 != null) {
                    ItemStack itemStack;
                    ItemStack itemStack3 = itemStack = entity instanceof EntityLivingBase ? ((EntityLivingBase)entity).getHeldItemMainhand() : ItemStack.field_190927_a;
                    iTextComponent = !itemStack.func_190926_b() && itemStack.hasDisplayName() ? new TextComponentTranslation("death.fell.finish.item", this.fighter.getDisplayName(), iTextComponent2, itemStack.getTextComponent()) : new TextComponentTranslation("death.fell.finish", this.fighter.getDisplayName(), iTextComponent2);
                } else {
                    iTextComponent = new TextComponentTranslation("death.fell.killer", this.fighter.getDisplayName());
                }
            } else {
                iTextComponent = new TextComponentTranslation("death.fell.accident." + this.getFallSuffix(combatEntry), this.fighter.getDisplayName());
            }
        } else {
            iTextComponent = combatEntry2.getDamageSrc().getDeathMessage(this.fighter);
        }
        return iTextComponent;
    }

    @Nullable
    public EntityLivingBase getBestAttacker() {
        EntityLivingBase entityLivingBase = null;
        EntityPlayer entityPlayer = null;
        float f = 0.0f;
        float f2 = 0.0f;
        for (CombatEntry combatEntry : this.combatEntries) {
            if (combatEntry.getDamageSrc().getEntity() instanceof EntityPlayer && (entityPlayer == null || combatEntry.getDamage() > f2)) {
                f2 = combatEntry.getDamage();
                entityPlayer = (EntityPlayer)combatEntry.getDamageSrc().getEntity();
            }
            if (!(combatEntry.getDamageSrc().getEntity() instanceof EntityLivingBase) || entityLivingBase != null && !(combatEntry.getDamage() > f)) continue;
            f = combatEntry.getDamage();
            entityLivingBase = (EntityLivingBase)combatEntry.getDamageSrc().getEntity();
        }
        if (entityPlayer != null && f2 >= f / 3.0f) {
            return entityPlayer;
        }
        return entityLivingBase;
    }

    @Nullable
    private CombatEntry getBestCombatEntry() {
        CombatEntry combatEntry = null;
        CombatEntry combatEntry2 = null;
        float f = 0.0f;
        float f2 = 0.0f;
        for (int i = 0; i < this.combatEntries.size(); ++i) {
            CombatEntry combatEntry3;
            CombatEntry combatEntry4 = this.combatEntries.get(i);
            CombatEntry combatEntry5 = combatEntry3 = i > 0 ? this.combatEntries.get(i - 1) : null;
            if ((combatEntry4.getDamageSrc() == DamageSource.fall || combatEntry4.getDamageSrc() == DamageSource.outOfWorld) && combatEntry4.getDamageAmount() > 0.0f && (combatEntry == null || combatEntry4.getDamageAmount() > f2)) {
                combatEntry = i > 0 ? combatEntry3 : combatEntry4;
                f2 = combatEntry4.getDamageAmount();
            }
            if (combatEntry4.getFallSuffix() == null || combatEntry2 != null && !(combatEntry4.getDamage() > f)) continue;
            combatEntry2 = combatEntry4;
            f = combatEntry4.getDamage();
        }
        if (f2 > 5.0f && combatEntry != null) {
            return combatEntry;
        }
        if (f > 5.0f && combatEntry2 != null) {
            return combatEntry2;
        }
        return null;
    }

    private String getFallSuffix(CombatEntry combatEntry) {
        return combatEntry.getFallSuffix() == null ? "generic" : combatEntry.getFallSuffix();
    }

    public int getCombatDuration() {
        return this.inCombat ? this.fighter.ticksExisted - this.combatStartTime : this.combatEndTime - this.combatStartTime;
    }

    private void resetFallSuffix() {
        this.fallSuffix = null;
    }

    public void reset() {
        int n;
        int n2 = n = this.inCombat ? 300 : 100;
        if (this.takingDamage && (!this.fighter.isEntityAlive() || this.fighter.ticksExisted - this.lastDamageTime > n)) {
            boolean bl = this.inCombat;
            this.takingDamage = false;
            this.inCombat = false;
            this.combatEndTime = this.fighter.ticksExisted;
            if (bl) {
                this.fighter.sendEndCombat();
            }
            this.combatEntries.clear();
        }
    }

    public EntityLivingBase getFighter() {
        return this.fighter;
    }
}
