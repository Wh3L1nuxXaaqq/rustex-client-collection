package net.minecraft.util;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;

public enum Mirror {
    NONE("no_mirror"),
    LEFT_RIGHT("mirror_left_right"),
    FRONT_BACK("mirror_front_back");

    private final String name;
    private static final String[] mirrorNames;

    private Mirror(String string2) {
        this.name = string2;
    }

    public int mirrorRotation(int n, int n2) {
        int n3 = n2 / 2;
        int n4 = n > n3 ? n - n2 : n;
        switch (this) {
            case FRONT_BACK: {
                return (n2 - n4) % n2;
            }
            case LEFT_RIGHT: {
                return (n3 - n4 + n2) % n2;
            }
        }
        return n;
    }

    public Rotation toRotation(EnumFacing enumFacing) {
        EnumFacing.Axis axis = enumFacing.getAxis();
        return !(this == LEFT_RIGHT && axis == EnumFacing.Axis.Z || this == FRONT_BACK && axis == EnumFacing.Axis.X) ? Rotation.NONE : Rotation.CLOCKWISE_180;
    }

    public EnumFacing mirror(EnumFacing enumFacing) {
        switch (this) {
            case FRONT_BACK: {
                if (enumFacing == EnumFacing.WEST) {
                    return EnumFacing.EAST;
                }
                if (enumFacing == EnumFacing.EAST) {
                    return EnumFacing.WEST;
                }
                return enumFacing;
            }
            case LEFT_RIGHT: {
                if (enumFacing == EnumFacing.NORTH) {
                    return EnumFacing.SOUTH;
                }
                if (enumFacing == EnumFacing.SOUTH) {
                    return EnumFacing.NORTH;
                }
                return enumFacing;
            }
        }
        return enumFacing;
    }

    static {
        mirrorNames = new String[Mirror.values().length];
        int n = 0;
        for (Mirror mirror : Mirror.values()) {
            Mirror.mirrorNames[n++] = mirror.name;
        }
    }
}
