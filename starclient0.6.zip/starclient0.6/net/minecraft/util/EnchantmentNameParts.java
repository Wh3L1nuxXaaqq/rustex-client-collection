package net.minecraft.util;

import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.FontRenderer;
import org.apache.commons.lang3.StringUtils;

public class EnchantmentNameParts {
    private static final EnchantmentNameParts INSTANCE = new EnchantmentNameParts();
    private final Random rand = new Random();
    private final String[] namePartsArray = "the elder scrolls klaatu berata niktu xyzzy bless curse light darkness fire air earth water hot dry cold wet ignite snuff embiggen twist shorten stretch fiddle destroy imbue galvanize enchant free limited range of towards inside sphere cube self other ball mental physical grow shrink demon elemental spirit animal creature beast humanoid undead fresh stale phnglui mglwnafh cthulhu rlyeh wgahnagl fhtagnbaguette".split(" ");

    public static EnchantmentNameParts getInstance() {
        return INSTANCE;
    }

    public String generateNewRandomName(FontRenderer fontRenderer, int n) {
        int n2 = this.rand.nextInt(2) + 3;
        Object object = "";
        for (int i = 0; i < n2; ++i) {
            if (i > 0) {
                object = (String)object + " ";
            }
            object = (String)object + this.namePartsArray[this.rand.nextInt(this.namePartsArray.length)];
        }
        List<String> list = fontRenderer.listFormattedStringToWidth((String)object, n);
        return StringUtils.join(list.size() >= 2 ? list.subList(0, 2) : list, (String)" ");
    }

    public void reseedRandomGenerator(long l) {
        this.rand.setSeed(l);
    }
}
