package net.minecraft.util;

import net.minecraft.client.Minecraft;

public class Timer {
    public int elapsedTicks;
    public float field_194147_b;
    public float field_194148_c;
    public float timerSpeed;
    private long lastSyncSysClock;
    public float field_194149_e;

    public Timer(float f) {
        this.field_194149_e = 1000.0f / f;
        this.lastSyncSysClock = Minecraft.getSystemTime();
    }

    public void updateTimer() {
        long l = Minecraft.getSystemTime();
        this.field_194148_c = (float)(l - this.lastSyncSysClock) / this.field_194149_e;
        this.lastSyncSysClock = l;
        this.field_194147_b += this.field_194148_c;
        this.elapsedTicks = (int)this.field_194147_b;
        this.field_194147_b -= (float)this.elapsedTicks;
    }

    public void setTimer(float f) {
        this.field_194147_b = f;
    }

    public void setTimer(double d) {
        this.field_194147_b = (float)d;
    }
}
