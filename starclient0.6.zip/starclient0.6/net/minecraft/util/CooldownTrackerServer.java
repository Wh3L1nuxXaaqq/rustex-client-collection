package net.minecraft.util;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.network.play.server.SPacketCooldown;
import net.minecraft.util.CooldownTracker;

public class CooldownTrackerServer
extends CooldownTracker {
    private final EntityPlayerMP player;

    public CooldownTrackerServer(EntityPlayerMP entityPlayerMP) {
        this.player = entityPlayerMP;
    }

    @Override
    protected void notifyOnSet(Item item, int n) {
        super.notifyOnSet(item, n);
        this.player.connection.sendPacket(new SPacketCooldown(item, n));
    }

    @Override
    protected void notifyOnRemove(Item item) {
        super.notifyOnRemove(item);
        this.player.connection.sendPacket(new SPacketCooldown(item, 0));
    }
}
