package net.minecraft.util;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;

public class NonNullList<E>
extends AbstractList<E> {
    private final List<E> field_191198_a;
    private final E field_191199_b;

    public static <E> NonNullList<E> func_191196_a() {
        return new NonNullList<E>();
    }

    public static <E> NonNullList<E> func_191197_a(int n, E e) {
        Validate.notNull(e);
        Object[] objectArray = new Object[n];
        Arrays.fill(objectArray, e);
        return new NonNullList<Object>(Arrays.asList(objectArray), e);
    }

    public static <E> NonNullList<E> func_193580_a(E e, E ... EArray) {
        return new NonNullList<E>(Arrays.asList(EArray), e);
    }

    protected NonNullList() {
        this(new ArrayList(), null);
    }

    protected NonNullList(List<E> list, @Nullable E e) {
        this.field_191198_a = list;
        this.field_191199_b = e;
    }

    @Override
    @Nonnull
    public E get(int n) {
        return this.field_191198_a.get(n);
    }

    @Override
    public E set(int n, E e) {
        Validate.notNull(e);
        return this.field_191198_a.set(n, e);
    }

    @Override
    public void add(int n, E e) {
        Validate.notNull(e);
        this.field_191198_a.add(n, e);
    }

    @Override
    public E remove(int n) {
        return this.field_191198_a.remove(n);
    }

    @Override
    public int size() {
        return this.field_191198_a.size();
    }

    @Override
    public void clear() {
        if (this.field_191199_b == null) {
            super.clear();
        } else {
            for (int i = 0; i < this.size(); ++i) {
                this.set(i, this.field_191199_b);
            }
        }
    }
}
