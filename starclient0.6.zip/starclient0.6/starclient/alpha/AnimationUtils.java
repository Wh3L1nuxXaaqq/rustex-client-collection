package starclient.alpha;

import net.minecraft.client.Minecraft;

public class AnimationUtils {
    long mc;
    float anim;
    public float to;
    public float speed;
    Type type;

    public AnimationUtils(float f, float f2, float f3) {
        this.anim = f;
        this.to = f2;
        this.speed = f3;
        this.mc = System.currentTimeMillis();
        this.type = Type.HARP;
    }

    public AnimationUtils(float f, float f2, float f3, Type type) {
        this.anim = f;
        this.to = f2;
        this.speed = f3;
        this.mc = System.currentTimeMillis();
        this.type = type;
    }

    public static double deltaTime() {
        return Minecraft.getDebugFPS() > 0 ? 1.0 / (double)Minecraft.getDebugFPS() : 1.0;
    }

    public static float harp(float f, float f2, float f3) {
        float f4 = (f2 - f) * (f3 / 2.0f) > 0.0f ? Math.max(f3, Math.min(f2 - f, (f2 - f) * (f3 / 2.0f))) : Math.max(f2 - f, Math.min(-(f3 / 2.0f), (f2 - f) * (f3 / 2.0f)));
        return f + f4;
    }

    public float getAnim() {
        int n = (int)((System.currentTimeMillis() - this.mc) / 5L);
        if (n > 0) {
            this.mc = System.currentTimeMillis();
        }
        for (int i = 0; i < n; ++i) {
            if (this.type == Type.HARP) {
                this.anim = AnimationUtils.harp(this.anim, this.to, this.speed);
                continue;
            }
            if (this.type != Type.SIMPLE) continue;
            if (this.anim > this.to) {
                this.anim -= this.speed;
            } else if (this.anim < this.to) {
                this.anim += this.speed;
            }
            if (!(Math.abs(this.to - this.anim) < this.speed)) continue;
            this.anim = this.to;
        }
        return this.anim;
    }

    public void reset() {
        this.mc = System.currentTimeMillis();
    }

    public void setAnim(float f) {
        this.anim = f;
        this.mc = System.currentTimeMillis();
    }

    public static enum Type {
        HARP,
        SIMPLE;

    }
}
