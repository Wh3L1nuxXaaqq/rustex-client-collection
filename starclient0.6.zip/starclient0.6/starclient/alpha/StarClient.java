package starclient.alpha;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderPlayer;
import starclient.alpha.UserInfo;
import starclient.alpha.command.CommandManager;
import starclient.alpha.event.input.EventInputKey;
import starclient.alpha.event.input.EventMouse;
import starclient.alpha.manager.config.ConfigManager;
import starclient.alpha.manager.dragging.DragManager;
import starclient.alpha.manager.friend.FriendManager;
import starclient.alpha.manager.lastAccount.LastAccountManager;
import starclient.alpha.manager.macro.MacroManager;
import starclient.alpha.manager.theme.ThemeManager;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleManager;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.ui.csgui.CsGui;
import starclient.alpha.ui.menu.altmanager.alt.AltFileManager;
import starclient.alpha.utility.discord.DiscordPresence;
import starclient.alpha.utility.discord.DiscordUtil;
import starclient.alpha.utility.misc.BullingUtility;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.model.WingsLayerRender;
import starclient.alpha.utility.render.model.WingsModel;

public class StarClient {
    public static String NAME = "PastaClient";
    public DiscordUtil discordUtil;
    public static String VERSION = "0.6";
    private static final StarClient instance = new StarClient();
    private ModuleManager moduleManager;
    private final ConfigManager configManager = new ConfigManager();
    private ThemeManager themeManager;
    private CommandManager commandManager;
    private AltFileManager altFileManager;
    private LastAccountManager lastAccountManager;
    private FriendManager friendManager;
    private BullingUtility bullingUtility;
    private MacroManager macroManager;
    private DragManager dragManager;
    private CsGui csGui;
    private UserInfo userInfo;
    public static String username;
    public static int uid;
    public static String role;
    public static String till;

    public void start() throws IOException {
        this.discordUtil = new DiscordUtil();
        DiscordPresence.startDiscord();
        this.discordUtil.startRpc();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f.. | 1/15");
        username = System.getProperty("user.name");
        uid = 1;
        role = "User";
        till = "dildo";
        this.userInfo = new UserInfo(username, uid, role, till);
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u0442\u0435\u043c \u043a\u043b\u0438\u0435\u043d\u0442\u0430.. | 2/15");
        this.themeManager = new ThemeManager();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043c\u043e\u0434\u0443\u043b\u0435\u0439.. | 3/15");
        this.moduleManager = new ModuleManager();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043a\u043e\u043c\u043c\u0430\u043d\u0434.. | 4/15");
        this.commandManager = new CommandManager();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043a\u043e\u043d\u0444\u0438\u0433\u043e\u0432.. | 5/15");
        this.configManager.loadConfig("autocfg");
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u043e\u0432.. | 6/15");
        this.altFileManager = new AltFileManager();
        this.altFileManager.init();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u0435\u0433\u043e \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430.. | 7/15");
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043f\u0435\u0440\u0435\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f \u0445\u0443\u0434\u0430.. | 8/15");
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u0441\u043f\u0438\u0441\u043a\u0430 \u0434\u0440\u0443\u0437\u0435\u0439.. | 9/15");
        this.friendManager = new FriendManager();
        this.friendManager.init();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432.. | 10/15");
        this.macroManager = new MacroManager();
        this.macroManager.init();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u0430\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u0438 \u0432 \u0434\u0438\u0441\u043a\u043e\u0440\u0434\u0435.. | 11/15");
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043a\u043b\u0438\u043a\u0433\u0443\u0438.. | 12/15");
        this.csGui = new CsGui();
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u043a\u0440\u044b\u043b\u044c\u0435\u0432.. | 13/15");
        new WingsModel();
        for (RenderPlayer renderPlayer : Minecraft.getMinecraft().getRenderManager().getSkinMap().values()) {
            renderPlayer.addLayer(new WingsLayerRender());
        }
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u044d\u0432\u0435\u043d\u0442\u043e\u0432.. | 14/15");
        EventManager.register(this);
        System.out.println("\u0418\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f \u0431\u0443\u043b\u043b\u0438\u043d\u0433\u0430.. | 15/15");
        this.bullingUtility = new BullingUtility();
        this.bullingUtility.init();
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
    }

    private String onDraggable(String string, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = string.length();
        int n2 = string2.length();
        for (int i = 0; i < n; ++i) {
            stringBuilder.append((char)(string.charAt(i) ^ string2.charAt(i % n2)));
        }
        return stringBuilder.toString();
    }

    public void reload() {
        this.userInfo = new UserInfo(username, uid, role, till);
    }

    public void shutdown() {
        this.dragManager.save();
        this.altFileManager.saveAll();
        this.configManager.saveConfig("autocfg");
    }

    @EventTarget
    public void onInputKey(EventInputKey eventInputKey) {
        for (Module module : this.moduleManager.getModules()) {
            if (module.getBind() != eventInputKey.getKey()) continue;
            module.toggle();
        }
        this.macroManager.onKeyPressed(eventInputKey.getKey());
    }

    @EventTarget
    public void onMouse(EventMouse eventMouse) {
        for (Module module : this.moduleManager.getModules()) {
            if (module.getMouseBind() != eventMouse.getButton() || eventMouse.getButton() <= 2) continue;
            module.toggle();
        }
        this.macroManager.onMousePressed(eventMouse.getButton());
    }

    private static String kaki(InputStream inputStream) throws IOException {
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));){
            String string2;
            String string;
            StringBuilder stringBuilder = new StringBuilder();
            while ((string = bufferedReader.readLine()) != null) {
                stringBuilder.append(string);
            }
            String string3 = string2 = stringBuilder.toString();
            return string3;
        }
    }

    public UserInfo getUserInfo() {
        return this.userInfo;
    }

    public static StarClient getInstance() {
        return instance;
    }

    public Color getC(int n) {
        Color color = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[0];
        Color color2 = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[1];
        return ColorUtility.TwoColorEffect(color, color2, Arraylist.colorSpeed.get(), n);
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public ThemeManager getThemeManager() {
        return this.themeManager;
    }

    public FriendManager getFriendManager() {
        return this.friendManager;
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public CsGui getCsGui() {
        return this.csGui;
    }

    public CommandManager getCommandManager() {
        return this.commandManager;
    }

    public MacroManager getMacroManager() {
        return this.macroManager;
    }
}
