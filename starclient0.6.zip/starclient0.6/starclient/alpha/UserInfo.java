package starclient.alpha;

public class UserInfo {
    private String name;
    private int uid;
    private String role;
    private String till;

    public String getName() {
        return this.name;
    }

    public int getUid() {
        return this.uid;
    }

    public String getRole() {
        return this.role;
    }

    public String getTill() {
        return this.till;
    }

    public UserInfo(String string, int n, String string2, String string3) {
        this.name = string;
        this.uid = n;
        this.role = string2;
        this.till = string3;
    }
}
