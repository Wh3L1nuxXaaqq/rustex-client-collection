package starclient.alpha.command.impl.report;

import net.minecraft.util.text.TextFormatting;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;

@Command(name="report", description="\u041e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0440\u0435\u043f\u043e\u0440\u0442 \u043f\u0440\u044f\u043c\u043e \u043a \u0430\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043a\u043b\u0438\u0435\u043d\u0442\u0430")
public class ReportCommand
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
