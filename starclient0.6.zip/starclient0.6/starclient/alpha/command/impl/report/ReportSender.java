package starclient.alpha.command.impl.report;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;

public class ReportSender {
    private final String url;
    private String content;
    private String username;
    private String avatarUrl;
    private boolean tts;
    private List<EmbedObject> embeds = new ArrayList<EmbedObject>();

    public ReportSender(String string) {
        this.url = string;
    }

    public void setContent(String string) {
        this.content = string;
    }

    public void setUsername(String string) {
        this.username = string;
    }

    public void setAvatarUrl(String string) {
        this.avatarUrl = string;
    }

    public void setTts(boolean bl) {
        this.tts = bl;
    }

    public void addEmbed(EmbedObject embedObject) {
        this.embeds.add(embedObject);
    }

    /*
     * WARNING - void declaration
     */
    public void execute() {
        void var4_12;
        Serializable serializable;
        if (this.content == null && this.embeds.isEmpty()) {
            throw new IllegalArgumentException("Set content or add at least one EmbedObject");
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("content", this.content);
        jSONObject.put("username", this.username);
        jSONObject.put("avatar_url", this.avatarUrl);
        jSONObject.put("tts", this.tts);
        if (!this.embeds.isEmpty()) {
            serializable = new ArrayList();
            for (EmbedObject object2 : this.embeds) {
                JSONObject jSONObject2;
                Object object;
                JSONObject iOException = new JSONObject();
                iOException.put("title", object2.getTitle());
                iOException.put("description", object2.getDescription());
                iOException.put("url", object2.getUrl());
                if (object2.getColor() != null) {
                    object = object2.getColor();
                    int n = ((Color)object).getRed();
                    n = (n << 8) + ((Color)object).getGreen();
                    n = (n << 8) + ((Color)object).getBlue();
                    iOException.put("color", n);
                }
                object = object2.getFooter();
                EmbedObject.Image image = object2.getImage();
                EmbedObject.Thumbnail thumbnail = object2.getThumbnail();
                EmbedObject.Author author = object2.getAuthor();
                List<EmbedObject.Field> list = object2.getFields();
                if (object != null) {
                    jSONObject2 = new JSONObject();
                    jSONObject2.put("text", ((EmbedObject.Footer)object).getText());
                    jSONObject2.put("icon_url", ((EmbedObject.Footer)object).getIconUrl());
                    iOException.put("footer", jSONObject2);
                }
                if (image != null) {
                    jSONObject2 = new JSONObject();
                    jSONObject2.put("url", image.getUrl());
                    iOException.put("image", jSONObject2);
                }
                if (thumbnail != null) {
                    jSONObject2 = new JSONObject();
                    jSONObject2.put("url", thumbnail.getUrl());
                    iOException.put("thumbnail", jSONObject2);
                }
                if (author != null) {
                    jSONObject2 = new JSONObject();
                    jSONObject2.put("name", author.getName());
                    jSONObject2.put("url", author.getUrl());
                    jSONObject2.put("icon_url", author.getIconUrl());
                    iOException.put("author", jSONObject2);
                }
                ArrayList<JSONObject> arrayList = new ArrayList<JSONObject>();
                for (EmbedObject.Field field : list) {
                    JSONObject jSONObject3 = new JSONObject();
                    jSONObject3.put("name", field.getName());
                    jSONObject3.put("value", field.getValue());
                    jSONObject3.put("inline", field.isInline());
                    arrayList.add(jSONObject3);
                }
                iOException.put("fields", arrayList.toArray());
                serializable.add(iOException);
            }
            jSONObject.put("embeds", serializable.toArray());
        }
        serializable = null;
        try {
            serializable = new URL(this.url);
        }
        catch (MalformedURLException malformedURLException) {
            // empty catch block
        }
        Object object4 = null;
        try {
            object4 = (HttpsURLConnection)((URL)serializable).openConnection();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        ((URLConnection)object4).addRequestProperty("Content-Type", "application/json");
        ((URLConnection)object4).addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
        ((URLConnection)object4).setDoOutput(true);
        try {
            ((HttpURLConnection)object4).setRequestMethod("POST");
        }
        catch (ProtocolException protocolException) {
            // empty catch block
        }
        Object var4_10 = null;
        try {
            OutputStream outputStream = ((URLConnection)object4).getOutputStream();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        try {
            var4_12.write(jSONObject.toString().getBytes());
        }
        catch (IOException iOException) {
            // empty catch block
        }
        try {
            var4_12.flush();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        try {
            var4_12.close();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        try {
            ((URLConnection)object4).getInputStream().close();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        ((HttpURLConnection)object4).disconnect();
    }

    private class JSONObject {
        private final HashMap<String, Object> map = new HashMap();

        private JSONObject() {
        }

        void put(String string, Object object) {
            if (object != null) {
                this.map.put(string, object);
            }
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            Set<Map.Entry<String, Object>> set = this.map.entrySet();
            stringBuilder.append("{");
            int n = 0;
            for (Map.Entry<String, Object> entry : set) {
                Object object = entry.getValue();
                stringBuilder.append(this.quote(entry.getKey())).append(":");
                if (object instanceof String) {
                    stringBuilder.append(this.quote(String.valueOf(object)));
                } else if (object instanceof Integer) {
                    stringBuilder.append(Integer.valueOf(String.valueOf(object)));
                } else if (object instanceof Boolean) {
                    stringBuilder.append(object);
                } else if (object instanceof JSONObject) {
                    stringBuilder.append(object.toString());
                } else if (object.getClass().isArray()) {
                    stringBuilder.append("[");
                    int n2 = Array.getLength(object);
                    for (int i = 0; i < n2; ++i) {
                        stringBuilder.append(Array.get(object, i).toString()).append(i != n2 - 1 ? "," : "");
                    }
                    stringBuilder.append("]");
                }
                stringBuilder.append(++n == set.size() ? "}" : ",");
            }
            return stringBuilder.toString();
        }

        private String quote(String string) {
            return "\"" + string + "\"";
        }
    }

    public static class EmbedObject {
        private String title;
        private String description;
        private String url;
        private Color color;
        private Footer footer;
        private Thumbnail thumbnail;
        private Image image;
        private Author author;
        private List<Field> fields = new ArrayList<Field>();

        public String getTitle() {
            return this.title;
        }

        public String getDescription() {
            return this.description;
        }

        public String getUrl() {
            return this.url;
        }

        public Color getColor() {
            return this.color;
        }

        public Footer getFooter() {
            return this.footer;
        }

        public Thumbnail getThumbnail() {
            return this.thumbnail;
        }

        public Image getImage() {
            return this.image;
        }

        public Author getAuthor() {
            return this.author;
        }

        public List<Field> getFields() {
            return this.fields;
        }

        public EmbedObject setTitle(String string) {
            this.title = string;
            return this;
        }

        public EmbedObject setDescription(String string) {
            this.description = string;
            return this;
        }

        public EmbedObject setUrl(String string) {
            this.url = string;
            return this;
        }

        public EmbedObject setColor(Color color) {
            this.color = color;
            return this;
        }

        public EmbedObject setFooter(String string, String string2) {
            this.footer = new Footer(string, string2);
            return this;
        }

        public EmbedObject setThumbnail(String string) {
            this.thumbnail = new Thumbnail(string);
            return this;
        }

        public EmbedObject setImage(String string) {
            this.image = new Image(string);
            return this;
        }

        public EmbedObject setAuthor(String string, String string2, String string3) {
            this.author = new Author(string, string2, string3);
            return this;
        }

        public EmbedObject addField(String string, String string2, boolean bl) {
            this.fields.add(new Field(string, string2, bl));
            return this;
        }

        private class Footer {
            private String text;
            private String iconUrl;

            private Footer(String string, String string2) {
                this.text = string;
                this.iconUrl = string2;
            }

            private String getText() {
                return this.text;
            }

            private String getIconUrl() {
                return this.iconUrl;
            }
        }

        private class Thumbnail {
            private String url;

            private Thumbnail(String string) {
                this.url = string;
            }

            private String getUrl() {
                return this.url;
            }
        }

        private class Image {
            private String url;

            private Image(String string) {
                this.url = string;
            }

            private String getUrl() {
                return this.url;
            }
        }

        private class Author {
            private String name;
            private String url;
            private String iconUrl;

            private Author(String string, String string2, String string3) {
                this.name = string;
                this.url = string2;
                this.iconUrl = string3;
            }

            private String getName() {
                return this.name;
            }

            private String getUrl() {
                return this.url;
            }

            private String getIconUrl() {
                return this.iconUrl;
            }
        }

        private class Field {
            private String name;
            private String value;
            private boolean inline;

            private Field(String string, String string2, boolean bl) {
                this.name = string;
                this.value = string2;
                this.inline = bl;
            }

            private String getName() {
                return this.name;
            }

            private String getValue() {
                return this.value;
            }

            private boolean isInline() {
                return this.inline;
            }
        }
    }
}
