package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.command.CommandManager;

@Command(name="prefix", description="\u0418\u0437\u043c\u0435\u043d\u044f\u0435\u0442 \u043f\u0440\u0435\u0444\u0438\u043a\u0441 \u0434\u043b\u044f \u043a\u043e\u043c\u0430\u043d\u0434")
public class PrefixCommand
extends CommandAbstract {
    @Override
    public void error() {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438" + String.valueOf(ChatFormatting.WHITE) + ":");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "prefix " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "symbol" + String.valueOf(ChatFormatting.GRAY) + ">");
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        CommandManager.setPrefix(stringArray[1]);
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041f\u0440\u0435\u0444\u0438\u043a\u0441 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0438\u0437\u043c\u0435\u043d\u0435\u043d \u043d\u0430 " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[1]);
    }
}
