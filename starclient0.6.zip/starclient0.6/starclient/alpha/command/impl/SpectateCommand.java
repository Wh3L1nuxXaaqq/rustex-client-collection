package starclient.alpha.command.impl;

import net.minecraft.util.text.TextFormatting;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.module.Utils;
import starclient.alpha.module.impl.util.Spectator;
import starclient.alpha.utility.misc.ChatUtility;

@Command(name="spectator", description="\u0423\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u0442 \u0438\u0433\u0440\u043e\u043a\u0430 \u0434\u043b\u044f \u043c\u043e\u0434\u0443\u043b\u044f Spectator")
public class SpectateCommand
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
        if (stringArray[1] != null) {
            if (Utils.mc.world.getPlayerEntityByName(stringArray[1]) != null) {
                Spectator.playerName = Utils.mc.world.getPlayerEntityByName(stringArray[1]).getName();
                ChatUtility.addChatMessage("\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0430 \u0441\u043b\u0435\u0436\u043a\u0430 \u0437\u0430 " + Utils.mc.world.getPlayerEntityByName(stringArray[1]).getName());
            } else {
                ChatUtility.addChatMessage("\u0418\u0433\u0440\u043e\u043a \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043b\u0438 \u0435\u0433\u043e \u043d\u0435\u0442\u0443 \u0440\u044f\u0434\u043e\u043c.");
            }
        } else {
            ChatUtility.addChatMessage("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043d\u0438\u043a \u0438\u0433\u0440\u043e\u043a\u0430!");
        }
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
