package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.command.CommandManager;

@Command(name="help", description="help")
public class HelpCommand
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043a\u043e\u043c\u0430\u043d\u0434: ");
        for (CommandAbstract commandAbstract : StarClient.getInstance().getCommandManager().getCommands()) {
            if (commandAbstract instanceof HelpCommand) continue;
            this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + commandAbstract.name + String.valueOf(ChatFormatting.GOLD) + " - " + String.valueOf(ChatFormatting.RESET) + commandAbstract.description);
        }
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
