package starclient.alpha.command.impl;

import net.minecraft.util.text.TextFormatting;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.module.impl.util.NameProtect;

@Command(name="np", description="\u0418\u0437\u043c\u0435\u043d\u044f\u0435\u0442 \u043d\u0438\u043a \u0432 NameProtect")
public class NameProtectCommand
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
        if (stringArray[1] != null) {
            NameProtect.protectedNick = stringArray[1];
            this.sendMessage("\u041d\u0438\u043a \u0438\u0437\u043c\u0435\u043d\u0435\u043d \u043d\u0430 " + NameProtect.protectedNick);
        }
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
