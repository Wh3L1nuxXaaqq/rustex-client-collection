package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.io.File;
import net.minecraft.client.Minecraft;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.utility.Utility;

@Command(name="parse", description="\u041f\u0430\u0440\u0441\u0438\u0442 \u0434\u043e\u043d\u0430\u0442\u0435\u0440\u043e\u0432 \u0432 \u0444\u0430\u0439\u043b")
public class ParseCommand
extends CommandAbstract
implements Utility {
    private static final File parseDir = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\parser");

    @Override
    public void error() {
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        if (mc.isSingleplayer()) {
            this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u042d\u0442\u0430 \u043a\u043e\u043c\u0430\u043d\u0434\u0430 \u043d\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0432 \u043e\u0434\u0438\u043d\u043e\u0447\u043d\u043e\u0439 \u0438\u0433\u0440\u0435!");
        }
    }
}
