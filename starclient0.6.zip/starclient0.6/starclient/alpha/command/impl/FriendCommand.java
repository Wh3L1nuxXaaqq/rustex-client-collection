package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.command.CommandManager;

@Command(name="friend", description="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0443\u043f\u0440\u0430\u0432\u043b\u044f\u0442\u044c \u0441\u043f\u0438\u0441\u043a\u043e\u043c \u0434\u0440\u0443\u0437\u0435\u0439")
public class FriendCommand
extends CommandAbstract {
    @Override
    public void error() {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438:");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "friend add " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + "> - \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430 \u0432 \u0434\u0440\u0443\u0437\u044c\u044f");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "friend remove " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + "> - \u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430 \u0438\u0437 \u0434\u0440\u0443\u0437\u0435\u0439");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "friend list" + String.valueOf(ChatFormatting.GRAY) + " - \u043f\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "friend clear" + String.valueOf(ChatFormatting.GRAY) + " - \u043e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439");
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        switch (stringArray[1]) {
            case "add": {
                if (stringArray[2].equalsIgnoreCase(Minecraft.getMinecraft().getSession().getUsername())) {
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041d\u0435\u043b\u044c\u0437\u044f \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u0430\u043c\u043e\u0433\u043e \u0441\u0435\u0431\u044f \u0432 \u0434\u0440\u0443\u0437\u044c\u044f :)");
                    break;
                }
                if (StarClient.getInstance().getFriendManager().getFriends().contains(stringArray[2])) {
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0436\u0435 \u0435\u0441\u0442\u044c \u0432 \u0441\u043f\u0438\u0441\u043a\u0435 \u0434\u0440\u0443\u0437\u0435\u0439.");
                    break;
                }
                StarClient.getInstance().getFriendManager().addFriend(stringArray[2]);
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0434\u0440\u0443\u0437\u044c\u044f!");
                break;
            }
            case "remove": {
                if (StarClient.getInstance().getFriendManager().isFriend(stringArray[2])) {
                    StarClient.getInstance().getFriendManager().removeFriend(stringArray[2]);
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430 \u0434\u0440\u0443\u0437\u0435\u0439.");
                    break;
                }
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a\u0430 " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u043d\u0435\u0442 \u0432 \u0441\u043f\u0438\u0441\u043a\u0435 \u0434\u0440\u0443\u0437\u0435\u0439.");
                break;
            }
            case "clear": {
                if (StarClient.getInstance().getFriendManager().getFriends().isEmpty()) {
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439 \u043f\u0443\u0441\u0442 :(");
                    break;
                }
                StarClient.getInstance().getFriendManager().clearFriend();
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043e\u0447\u0438\u0449\u0435\u043d!");
                break;
            }
            case "list": {
                if (StarClient.getInstance().getFriendManager().getFriends().isEmpty()) {
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439 \u043f\u0443\u0441\u0442 :(");
                    return;
                }
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439: ");
                StarClient.getInstance().getFriendManager().getFriends().forEach(friend -> this.sendMessage(friend.getName()));
            }
        }
    }
}
