package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.module.Module;
import starclient.alpha.module.impl.render.ClickGuiModule;

@Command(name="bind", description="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0431\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u0438")
public class BindCommand
extends CommandAbstract {
    @Override
    public void error() {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438" + String.valueOf(ChatFormatting.WHITE) + ":");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".bind " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + "> <" + String.valueOf((Object)TextFormatting.GOLD) + "key" + String.valueOf(ChatFormatting.GRAY) + "> - \u0437\u0430\u0431\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".bind " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + "> " + String.valueOf(ChatFormatting.WHITE) + "none" + String.valueOf(ChatFormatting.GRAY) + " - \u0440\u0430\u0437\u0431\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".bind list" + String.valueOf(ChatFormatting.GRAY) + " - \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u0431\u0438\u043d\u0434\u043e\u0432");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".bind clear" + String.valueOf(ChatFormatting.GRAY) + " - \u043e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0432\u0441\u0435 \u0431\u0438\u043d\u0434\u044b");
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        if (stringArray.length >= 2) {
            if (stringArray[1].equals("clear")) {
                for (Module module : StarClient.getInstance().getModuleManager().getModules()) {
                    if (module instanceof ClickGuiModule || module.getBind() == 0) continue;
                    module.bind = 0;
                }
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0412\u0441\u0435 \u0431\u0438\u043d\u0434\u044b \u0431\u044b\u043b\u0438 \u043e\u0447\u0438\u0449\u0435\u043d\u044b!");
                return;
            }
            if (stringArray[1].equals("list")) {
                this.sendMessage(String.valueOf(ChatFormatting.GREEN) + "\u0421\u043f\u0438\u0441\u043e\u043a \u0431\u0438\u043d\u0434\u043e\u0432: ");
                for (Module module : StarClient.getInstance().getModuleManager().getModules()) {
                    if (module.getBind() == 0) continue;
                    if (module.getBind() < 0) {
                        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + "\u041c\u043e\u0434\u0443\u043b\u044c: " + String.valueOf((Object)TextFormatting.GOLD) + module.getName() + String.valueOf(ChatFormatting.WHITE) + ", \u041a\u043d\u043e\u043f\u043a\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + (module.getBind() + 100));
                        continue;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.WHITE) + "\u041c\u043e\u0434\u0443\u043b\u044c: " + String.valueOf((Object)TextFormatting.GOLD) + module.getName() + String.valueOf(ChatFormatting.WHITE) + ", \u041a\u043b\u0430\u0432\u0438\u0448\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + Keyboard.getKeyName((int)module.getBind()));
                }
                return;
            }
            Module module = StarClient.getInstance().getModuleManager().getModule(stringArray[1]);
            if (module == null) {
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041c\u043e\u0434\u0443\u043b\u044c " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[1] + String.valueOf(ChatFormatting.GRAY) + " \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!");
            } else if (stringArray[2].equalsIgnoreCase("none")) {
                module.bind = 0;
                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041c\u043e\u0434\u0443\u043b\u044c " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[1] + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b \u0440\u0430\u0437\u0431\u0438\u043d\u0436\u0435\u043d!");
            } else {
                int n = Keyboard.getKeyIndex((String)stringArray[2].toUpperCase());
                if (n == 0) {
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0422\u0430\u043a\u043e\u0439 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!");
                } else {
                    module.bind = n;
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041c\u043e\u0434\u0443\u043b\u044c " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[1] + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b \u0437\u0430\u0431\u0438\u043d\u0436\u0435\u043d \u043d\u0430 \u043a\u043b\u0430\u0432\u0438\u0448\u0443 " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2].toUpperCase());
                }
            }
        } else {
            this.error();
        }
    }
}
