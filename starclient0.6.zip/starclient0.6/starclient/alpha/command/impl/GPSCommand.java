package starclient.alpha.command.impl;

import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.module.impl.util.GPS;

@Command(name="gps", description="\u0441\u0442\u0430\u0432\u0438\u0442 \u0442\u043e\u0447\u043a\u0443 \u043d\u0430 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b")
public class GPSCommand
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
        block5: {
            if (stringArray.length >= 3) {
                try {
                    GPS.x = Double.parseDouble(stringArray[1]);
                    GPS.z = Double.parseDouble(stringArray[2]);
                    GPS.mode = stringArray[3].toLowerCase();
                    if (GPS.mode.equals("on") || GPS.mode.equals("off")) {
                        this.sendMessage("GPS \u043f\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d \u043d\u0430 X: " + GPS.x + " Z: " + GPS.z + " Mode: " + GPS.mode);
                        break block5;
                    }
                    this.error();
                }
                catch (Exception exception) {
                    this.error();
                }
            } else {
                this.error();
            }
        }
    }

    @Override
    public void error() {
        this.sendMessage("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435: .gps <x> <z> <on/off>");
    }
}
