package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.io.File;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.command.CommandManager;
import starclient.alpha.manager.config.ConfigManager;

@Command(name="cfg", description="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0443\u043f\u0440\u0430\u0432\u043b\u044f\u0442\u044c \u043a\u043e\u043d\u0444\u0438\u0433\u0430\u043c\u0438 \u0447\u0438\u0442\u0430")
public class ConfigCommand
extends CommandAbstract {
    @Override
    public void error() {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438" + String.valueOf(ChatFormatting.WHITE) + ":");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "cfg load " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + ">");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "cfg save " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + ">");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "cfg delete " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "name" + String.valueOf(ChatFormatting.GRAY) + ">");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "cfg list" + String.valueOf(ChatFormatting.GRAY) + " - \u0441\u043f\u0438\u0441\u043e\u043a \u043a\u043e\u043d\u0444\u0438\u0433\u043e\u0432");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + CommandManager.getPrefix() + "cfg dir" + String.valueOf(ChatFormatting.GRAY) + " - \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u043f\u0430\u043f\u043a\u0443 \u0441 \u043a\u043e\u043d\u0444\u0438\u0433\u0430\u043c\u0438");
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        if (stringArray.length >= 2) {
            switch (stringArray[1]) {
                case "dir": {
                    OpenGlHelper.openFile(new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\configs"));
                    break;
                }
                case "list": {
                    File file = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\configs");
                    if (ConfigManager.getLoadedConfigs().isEmpty()) {
                        this.sendMessage("\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u0438 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u044b.");
                        break;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.GREEN) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u0439: ");
                    for (File file2 : Objects.requireNonNull(file.listFiles())) {
                        this.sendMessage(file2.getName().replaceAll(".star", ""));
                    }
                    return;
                }
                case "load": {
                    if (StarClient.getInstance().getConfigManager().loadConfig(stringArray[2])) {
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u0430.");
                        break;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u043d\u0435 \u0431\u044b\u043b\u0430 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u0430. \u0421\u043a\u043e\u0440\u0435\u0435 \u0432\u0441\u0435\u0433\u043e, \u043e\u043d\u0430 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442.");
                    break;
                }
                case "save": {
                    StarClient.getInstance().getConfigManager().saveConfig(stringArray[2]);
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0430.");
                    break;
                }
                case "delete": {
                    if (StarClient.getInstance().getConfigManager().deleteConfig(stringArray[2])) {
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0443\u0434\u0430\u043b\u0435\u043d\u0430.");
                        break;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + stringArray[2] + String.valueOf(ChatFormatting.GRAY) + " \u043d\u0435 \u0431\u044b\u043b\u0430 \u0443\u0434\u0430\u043b\u0435\u043d\u0430. \u0421\u043a\u043e\u0440\u0435\u0435 \u0432\u0441\u0435\u0433\u043e, \u043e\u043d\u0430 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442.");
                }
            }
        } else {
            this.error();
        }
    }
}
