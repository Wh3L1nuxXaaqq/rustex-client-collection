package starclient.alpha.command.impl;

import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.module.Utils;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.utility.misc.ChatUtility;

@Command(name="debug", description="show debug info")
public class RofolComanda
extends CommandAbstract {
    @Override
    public void execute(String[] stringArray) throws Exception {
        ChatUtility.addChatMessage("\u0410\u0439\u0434\u0438 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430 \u0432 \u0440\u0443\u043a\u0435 - " + Utils.mc.player.getHeldItemMainhand().itemDamage);
        ChatUtility.addChatMessage("\u041d\u0430\u0445\u043e\u0434\u0438\u0442\u0441\u044f \u043b\u0438 \u043b\u0443\u043a \u0432 \u0440\u0443\u043a\u0435 - " + AimBot.ishandcontainbow);
        if (AimBot.lastTarget != null) {
            ChatUtility.addChatMessage("\u041f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439 \u0442\u0430\u0440\u0433\u0435\u0442 - " + AimBot.lastTarget.getTarget().getName());
        }
        ChatUtility.addChatMessage("\u042e\u0437\u0435\u0440\u043d\u0435\u0439\u043c - " + StarClient.getInstance().getUserInfo().getName());
        ChatUtility.addChatMessage("\u0423\u043d\u0438\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0430\u0439\u0434\u0438 - " + StarClient.getInstance().getUserInfo().getUid());
        ChatUtility.addChatMessage("\u0420\u043e\u043b\u044c - " + StarClient.getInstance().getUserInfo().getRole());
        ChatUtility.addChatMessage("\u0420\u0435\u043a\u043e\u043c\u0435\u043d\u0434\u0443\u0435\u043c\u044b\u0439 \u043f\u0440\u0435\u0434\u0438\u043a\u0442 - " + (float)Utils.mc.getConnection().getPlayerInfo(Utils.mc.player.getUniqueID()).getResponseTime() / 20.0f);
        System.gc();
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
