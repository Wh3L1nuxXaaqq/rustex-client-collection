package starclient.alpha.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import starclient.alpha.StarClient;
import starclient.alpha.command.Command;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.manager.macro.Macro;
import starclient.alpha.utility.misc.StringUtility;

@Command(name="macro", description="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u043f\u043e \u043d\u0430\u0436\u0430\u0442\u0438\u044e \u043a\u043d\u043e\u043f\u043a\u0438")
public class MacroCommand
extends CommandAbstract {
    @Override
    public void error() {
        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438" + String.valueOf(ChatFormatting.WHITE) + ":");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".macro add " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "key" + String.valueOf(ChatFormatting.GRAY) + "> <" + String.valueOf((Object)TextFormatting.GOLD) + "message" + String.valueOf(ChatFormatting.GRAY) + ">");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".macro remove " + String.valueOf(ChatFormatting.GRAY) + "<" + String.valueOf((Object)TextFormatting.GOLD) + "key" + String.valueOf(ChatFormatting.GRAY) + ">");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".macro list");
        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + ".macro clear");
    }

    @Override
    public void execute(String[] stringArray) throws Exception {
        if (stringArray.length > 1) {
            switch (stringArray[1]) {
                case "add": {
                    int n = Keyboard.getKeyIndex((String)stringArray[2].toUpperCase());
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i = 3; i < stringArray.length; ++i) {
                        stringBuilder.append(stringArray[i]).append(" ");
                    }
                    String string = stringBuilder.toString().trim();
                    String string2 = StringUtility.getStringRedColor(string);
                    if (n == 0) {
                        if (stringArray[2].startsWith("mouse")) {
                            try {
                                int n2 = Integer.parseInt(stringArray[2].replaceAll("mouse", ""));
                                if (n2 < 100) {
                                    StarClient.getInstance().getMacroManager().addMacros(new Macro(string, n2 - 100));
                                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u043c\u0430\u043a\u0440\u043e\u0441 \u0434\u043b\u044f \u043a\u043d\u043e\u043f\u043a\u0438 \u043c\u044b\u0448\u0438" + String.valueOf((Object)TextFormatting.GOLD) + " \"" + n2 + String.valueOf((Object)TextFormatting.GOLD) + "\" " + String.valueOf(ChatFormatting.GRAY) + "\u0441 \u043a\u043e\u043c\u0430\u043d\u0434\u043e\u0439 " + String.valueOf((Object)TextFormatting.GOLD) + string2);
                                    break;
                                }
                                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043d\u043e\u043f\u043a\u0430 \u043c\u044b\u0448\u0438 \u043d\u0435 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c 100 \u0438 \u0431\u043e\u043b\u044c\u0448\u0435!");
                            }
                            catch (NumberFormatException numberFormatException) {
                                this.error();
                            }
                            break;
                        }
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0422\u0430\u043a\u043e\u0439 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!");
                        break;
                    }
                    StarClient.getInstance().getMacroManager().addMacros(new Macro(string, n));
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u043c\u0430\u043a\u0440\u043e\u0441 \u0434\u043b\u044f \u043a\u043d\u043e\u043f\u043a\u0438" + String.valueOf((Object)TextFormatting.GOLD) + " \"" + stringArray[2].toUpperCase() + String.valueOf((Object)TextFormatting.GOLD) + "\" " + String.valueOf(ChatFormatting.GRAY) + "\u0441 \u043a\u043e\u043c\u0430\u043d\u0434\u043e\u0439 " + String.valueOf((Object)TextFormatting.GOLD) + string2);
                    break;
                }
                case "clear": {
                    if (StarClient.getInstance().getMacroManager().getMacros().isEmpty()) {
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u043f\u0443\u0441\u0442.");
                        break;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043e\u0447\u0438\u0449\u0435\u043d!");
                    StarClient.getInstance().getMacroManager().getMacros().clear();
                    StarClient.getInstance().getMacroManager().updateFile();
                    break;
                }
                case "remove": {
                    int n = Keyboard.getKeyIndex((String)stringArray[2].toUpperCase());
                    if (n == 0) {
                        if (stringArray[2].startsWith("mouse")) {
                            String string = StringUtility.getDigits(stringArray[2]);
                            try {
                                n = Integer.parseInt(string);
                                StarClient.getInstance().getMacroManager().deleteMacro(n - 100);
                                this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041c\u0430\u043a\u0440\u043e\u0441 \u0431\u044b\u043b \u0443\u0434\u0430\u043b\u0435\u043d \u0441 \u043a\u043d\u043e\u043f\u043a\u0438 " + String.valueOf((Object)TextFormatting.GOLD) + "\"" + stringArray[2] + "\"");
                            }
                            catch (NumberFormatException numberFormatException) {
                                this.error();
                            }
                            break;
                        }
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0422\u0430\u043a\u043e\u0439 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!");
                        break;
                    }
                    StarClient.getInstance().getMacroManager().deleteMacro(n);
                    this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u041c\u0430\u043a\u0440\u043e\u0441 \u0431\u044b\u043b \u0443\u0434\u0430\u043b\u0435\u043d \u0441 \u043a\u043d\u043e\u043f\u043a\u0438 " + String.valueOf((Object)TextFormatting.GOLD) + "\"" + stringArray[2].toUpperCase() + "\"");
                    break;
                }
                case "list": {
                    if (StarClient.getInstance().getMacroManager().getMacros().isEmpty()) {
                        this.sendMessage(String.valueOf(ChatFormatting.GRAY) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u043f\u0443\u0441\u0442.");
                        break;
                    }
                    this.sendMessage(String.valueOf(ChatFormatting.GREEN) + "\u0421\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432: ");
                    for (Macro macro : StarClient.getInstance().getMacroManager().getMacros()) {
                        if (macro.getKey() < 0) {
                            this.sendMessage(String.valueOf(ChatFormatting.WHITE) + "\u041a\u043e\u043c\u0430\u043d\u0434\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + macro.getMessage() + String.valueOf(ChatFormatting.WHITE) + ", \u041a\u043d\u043e\u043f\u043a\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + (macro.getKey() + 100));
                            continue;
                        }
                        this.sendMessage(String.valueOf(ChatFormatting.WHITE) + "\u041a\u043e\u043c\u0430\u043d\u0434\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + macro.getMessage() + String.valueOf(ChatFormatting.WHITE) + ", \u041a\u043b\u0430\u0432\u0438\u0448\u0430: " + String.valueOf((Object)TextFormatting.GOLD) + Keyboard.getKeyName((int)macro.getKey()));
                    }
                    break;
                }
            }
        } else {
            this.error();
        }
    }
}
