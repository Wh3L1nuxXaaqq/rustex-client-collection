package starclient.alpha.command;

import starclient.alpha.command.Command;
import starclient.alpha.utility.misc.ChatUtility;

public abstract class CommandAbstract {
    public String name = this.getClass().getAnnotation(Command.class).name();
    public String description = this.getClass().getAnnotation(Command.class).description();

    public abstract void error();

    public abstract void execute(String[] var1) throws Exception;

    public void sendMessage(String string) {
        ChatUtility.addChatMessage(string);
    }
}
