package starclient.alpha.command;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.realmsclient.gui.ChatFormatting;
import starclient.alpha.command.CommandManager;
import starclient.alpha.event.misc.EventMessage;
import starclient.alpha.utility.misc.ChatUtility;

public class CommandHandler {
    public CommandManager commandManager;

    public CommandHandler(CommandManager commandManager) {
        this.commandManager = commandManager;
    }

    @EventTarget
    public void onMessage(EventMessage eventMessage) {
        String string = eventMessage.getMessage();
        if (string.startsWith(CommandManager.getPrefix())) {
            eventMessage.setCancelled(true);
            if (!this.commandManager.execute(string)) {
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u0422\u0430\u043a\u043e\u0439 \u043a\u043e\u043c\u0430\u043d\u0434\u044b \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442.");
            }
        }
    }
}
