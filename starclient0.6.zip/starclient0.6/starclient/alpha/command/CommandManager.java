package starclient.alpha.command;

import com.darkmagician6.eventapi.EventManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import starclient.alpha.command.CommandAbstract;
import starclient.alpha.command.CommandHandler;
import starclient.alpha.command.impl.BindCommand;
import starclient.alpha.command.impl.ConfigCommand;
import starclient.alpha.command.impl.FriendCommand;
import starclient.alpha.command.impl.GPSCommand;
import starclient.alpha.command.impl.HelpCommand;
import starclient.alpha.command.impl.MacroCommand;
import starclient.alpha.command.impl.NameProtectCommand;
import starclient.alpha.command.impl.ParseCommand;
import starclient.alpha.command.impl.PrefixCommand;
import starclient.alpha.command.impl.RofolComanda;
import starclient.alpha.command.impl.SpectateCommand;

public class CommandManager {
    private final ArrayList<CommandAbstract> commands = new ArrayList();
    private static String prefix = ".";

    public CommandManager() {
        EventManager.register(new CommandHandler(this));
        this.commands.add(new PrefixCommand());
        this.commands.add(new ConfigCommand());
        this.commands.add(new FriendCommand());
        this.commands.add(new BindCommand());
        this.commands.add(new MacroCommand());
        this.commands.add(new ParseCommand());
        this.commands.add(new SpectateCommand());
        this.commands.add(new HelpCommand());
        this.commands.add(new RofolComanda());
        this.commands.add(new NameProtectCommand());
        this.commands.add(new GPSCommand());
    }

    public List<CommandAbstract> getCommands() {
        return this.commands;
    }

    public boolean execute(String string) {
        CommandAbstract commandAbstract;
        String[] stringArray;
        Iterator<CommandAbstract> iterator = this.commands.iterator();
        do {
            if (!iterator.hasNext()) {
                return false;
            }
            commandAbstract = iterator.next();
        } while (!(stringArray = string.substring(1).split(" "))[0].equalsIgnoreCase(commandAbstract.name));
        try {
            commandAbstract.execute(stringArray);
        }
        catch (Exception exception) {
            commandAbstract.error();
        }
        return true;
    }

    public static String getPrefix() {
        return prefix;
    }

    public static void setPrefix(String string) {
        prefix = string;
    }
}
