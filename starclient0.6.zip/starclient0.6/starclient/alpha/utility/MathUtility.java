package starclient.alpha.utility;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.MathHelper;
import starclient.alpha.utility.Utility;

public class MathUtility
implements Utility {
    public static BigDecimal round(float f, int n) {
        BigDecimal bigDecimal = new BigDecimal(Float.toString(f));
        bigDecimal = bigDecimal.setScale(n, RoundingMode.HALF_UP);
        return bigDecimal;
    }

    public static float map(float f, float f2, float f3, float f4, float f5) {
        return f4 + (f5 - f4) * ((f - f2) / (f3 - f2));
    }

    public static float updateRotation(float f, float f2, float f3) {
        float f4 = MathHelper.wrapDegrees(f2 - f);
        if (f4 > f3) {
            f4 = f3;
        }
        if (f4 < -f3) {
            f4 = -f3;
        }
        return f + f4;
    }

    public static int intRandom(int n, int n2) {
        return ThreadLocalRandom.current().nextInt(n, n2);
    }

    public static float interpolate(float f, float f2, float f3) {
        return f + (f2 - f) * MathUtility.clamp(f3, 0.0f, 1.0f);
    }

    public static float lerp(float f, float f2, float f3) {
        return f + (f2 - f) * MathUtility.clamp(f3, 0.0f, 1.0f);
    }

    public static double lerp(double d, double d2, double d3) {
        return d + (d2 - d) * (double)MathUtility.clamp((float)d3, 0.0f, 1.0f);
    }

    public static float randomizeFloat(float f, float f2) {
        return (float)(Math.random() * (double)(f2 - f)) + f;
    }

    public static double randomNumber(double d, double d2) {
        return Math.random() * (d - d2) + d2;
    }

    public static double round(double d, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bigDecimal = new BigDecimal(d);
        bigDecimal = bigDecimal.setScale(n, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

    public static double interpolate(double d, double d2, double d3) {
        return d2 + (d - d2) * d3;
    }

    public static float interpolate(float f, float f2, double d) {
        return (float)MathUtility.interpolate((double)f, (double)f2, d);
    }

    public static float interpolate2(double d, double d2, double d3) {
        return (float)(d + (d2 - d) * d3);
    }

    public static int interpolate(int n, int n2, double d) {
        return (int)MathUtility.interpolate((double)n, (double)n2, d);
    }

    public static int getCenter(int n, int n2) {
        return n / 2 - n2 / 2;
    }

    public static double round(double d, double d2) {
        double d3 = (double)Math.round(d / d2) * d2;
        BigDecimal bigDecimal = new BigDecimal(d3);
        bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

    public static float clamp(float f, float f2, float f3) {
        if (f <= f2) {
            f = f2;
        }
        if (f >= f3) {
            f = f3;
        }
        return f;
    }

    public static double clamp(double d, double d2, double d3) {
        if (d <= d2) {
            d = d2;
        }
        if (d >= d3) {
            d = d3;
        }
        return d;
    }
}
