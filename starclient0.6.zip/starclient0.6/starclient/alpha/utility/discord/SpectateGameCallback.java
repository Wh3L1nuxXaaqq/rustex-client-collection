package starclient.alpha.utility.discord;

import com.sun.jna.Callback;

public interface SpectateGameCallback
extends Callback {
    public void apply(String var1);
}
