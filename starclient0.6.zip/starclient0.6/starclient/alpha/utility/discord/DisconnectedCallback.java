package starclient.alpha.utility.discord;

import com.sun.jna.Callback;

public interface DisconnectedCallback
extends Callback {
    public void apply(int var1, String var2);
}
