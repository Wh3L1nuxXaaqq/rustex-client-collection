package starclient.alpha.utility.discord;

import com.sun.jna.Callback;
import starclient.alpha.utility.discord.DiscordUser;

public interface JoinRequestCallback
extends Callback {
    public void apply(DiscordUser var1);
}
