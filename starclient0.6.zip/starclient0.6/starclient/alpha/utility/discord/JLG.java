package starclient.alpha.utility.discord;

public class JLG {
    private static final JLG instance = new JLG();
    private static String currentClient;
    private static String name;
    private static String username;
    private static String UID;
    private static String SUB;
    private static String NickName;
    private static long lastAuthTime;
    private static String hwid;

    public static JLG getInstance() {
        return instance;
    }

    public String getCurrentClient() {
        return currentClient;
    }

    public String getCurrentName() {
        return name;
    }

    public long getAuthTime() {
        return lastAuthTime;
    }

    public String getCurrentUID() {
        return UID;
    }

    public String getCurrentSubscription() {
        return SUB;
    }

    public String getCurrentHWID() {
        return hwid;
    }

    public String getCurrentUserName() {
        return username;
    }

    public String GetNickName() {
        return NickName;
    }

    static {
        name = "JLegion";
        username = System.getProperty("user.name");
    }
}
