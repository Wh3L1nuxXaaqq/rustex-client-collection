package starclient.alpha.utility.discord;

import starclient.alpha.StarClient;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.discord.DiscordEventHandlers;
import starclient.alpha.utility.discord.DiscordRPC;
import starclient.alpha.utility.discord.DiscordRichPresence;
import starclient.alpha.utility.discord.JLG;

public class DiscordUtil
implements Utility {
    private static final DiscordRPC rpc = DiscordRPC.INSTANCE;
    public static DiscordRichPresence presence = new DiscordRichPresence();
    public static boolean started;
    static String String1;
    private static Thread thread;

    public void onDisable() {
        started = false;
        if (thread != null && !thread.isInterrupted()) {
            thread.interrupt();
        }
        rpc.Discord_Shutdown();
    }

    public void onUpdate() {
        this.startRpc();
    }

    public void startRpc() {
        if (!started) {
            started = true;
            DiscordEventHandlers discordEventHandlers = new DiscordEventHandlers();
            rpc.Discord_Initialize("1330784043356131399", discordEventHandlers, true, "");
            DiscordUtil.presence.startTimestamp = System.currentTimeMillis() / 1000L;
            DiscordUtil.presence.largeImageText = "_4_";
            rpc.Discord_UpdatePresence(presence);
            thread = new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    rpc.Discord_RunCallbacks();
                    DiscordUtil.presence.largeImageKey = "_4_";
                    DiscordUtil.presence.largeImageText = JLG.getInstance().getCurrentUserName();
                    DiscordUtil.presence.details = "Version: " + StarClient.VERSION;
                    DiscordUtil.presence.state = "always on top";
                    DiscordUtil.presence.button_label_1 = "\u041a\u0443\u043f\u0438\u0442\u044c";
                    DiscordUtil.presence.button_url_1 = "https://funpay.com/users/7583227/";
                    DiscordUtil.presence.button_label_2 = "\u0414\u0438\u0441\u043a\u043e\u0440\u0434";
                    DiscordUtil.presence.button_url_2 = "https://discord.gg/aYbNSaUsHU";
                    rpc.Discord_UpdatePresence(presence);
                    try {
                        Thread.sleep(2000L);
                    }
                    catch (InterruptedException interruptedException) {}
                }
            }, "DiscordRPC");
            thread.start();
        }
    }

    static {
        String1 = "none";
    }
}
