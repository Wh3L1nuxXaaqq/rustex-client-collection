package starclient.alpha.utility.discord;

import com.sun.jna.Structure;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import starclient.alpha.utility.discord.RPCButton;

public class DiscordRichPresence
extends Structure {
    public String largeImageKey;
    public String largeImageText;
    public String smallImageText;
    public String partyPrivacy;
    public long startTimestamp;
    public String button_label_1;
    public int instance;
    public String partyId;
    public int partySize;
    public long endTimestamp;
    public String details;
    public String joinSecret;
    public String spectateSecret;
    public String smallImageKey;
    public String matchSecret;
    public String button_url_2;
    public String button_label_2;
    public String state;
    public String button_url_1;
    public int partyMax;

    public DiscordRichPresence() {
        this.setStringEncoding("UTF-8");
    }

    protected List<String> getFieldOrder() {
        return Arrays.asList("state", "details", "startTimestamp", "endTimestamp", "largeImageKey", "largeImageText", "smallImageKey", "smallImageText", "partyId", "partySize", "partyMax", "partyPrivacy", "matchSecret", "joinSecret", "spectateSecret", "button_label_1", "button_url_1", "button_label_2", "button_url_2", "instance");
    }

    public static class Builder {
        private final DiscordRichPresence rpc = new DiscordRichPresence();

        public Builder setSmallImage(String string) {
            return this.setSmallImage(string, "");
        }

        public Builder setDetails(String string) {
            if (string != null && !string.isEmpty()) {
                this.rpc.details = string.substring(0, Math.min(string.length(), 128));
            }
            return this;
        }

        public Builder setLargeImage(String string, String string2) {
            this.rpc.largeImageKey = string;
            this.rpc.largeImageText = string2;
            return this;
        }

        public Builder setState(String string) {
            if (string != null && !string.isEmpty()) {
                this.rpc.state = string.substring(0, Math.min(string.length(), 128));
            }
            return this;
        }

        public Builder setInstance(boolean bl) {
            if (this.rpc.button_label_1 != null && this.rpc.button_label_1.isEmpty() || this.rpc.button_label_2 != null && this.rpc.button_label_2.isEmpty()) {
                return this;
            }
            this.rpc.instance = bl ? 1 : 0;
            return this;
        }

        public Builder setButtons(RPCButton rPCButton) {
            return this.setButtons(Collections.singletonList(rPCButton));
        }

        public Builder setSmallImage(String string, String string2) {
            this.rpc.smallImageKey = string;
            this.rpc.smallImageText = string2;
            return this;
        }

        public Builder setParty(String string, int n, int n2) {
            if (this.rpc.button_label_1 != null && this.rpc.button_label_1.isEmpty() || this.rpc.button_label_2 != null && this.rpc.button_label_2.isEmpty()) {
                return this;
            }
            this.rpc.partyId = string;
            this.rpc.partySize = n;
            this.rpc.partyMax = n2;
            return this;
        }

        public Builder setButtons(List<RPCButton> list) {
            if (list != null && !list.isEmpty()) {
                int n = Math.min(list.size(), 2);
                this.rpc.button_label_1 = list.get(0).getLabel();
                this.rpc.button_url_1 = list.get(0).getUrl();
                if (n == 2) {
                    this.rpc.button_label_2 = list.get(1).getLabel();
                    this.rpc.button_url_2 = list.get(1).getUrl();
                }
            }
            return this;
        }

        public Builder setStartTimestamp(OffsetDateTime offsetDateTime) {
            this.rpc.startTimestamp = offsetDateTime.toEpochSecond();
            return this;
        }

        public Builder setSecrets(String string, String string2, String string3) {
            if (this.rpc.button_label_1 != null && this.rpc.button_label_1.isEmpty() || this.rpc.button_label_2 != null && this.rpc.button_label_2.isEmpty()) {
                return this;
            }
            this.rpc.matchSecret = string;
            this.rpc.joinSecret = string2;
            this.rpc.spectateSecret = string3;
            return this;
        }

        public Builder setButtons(RPCButton rPCButton, RPCButton rPCButton2) {
            return this.setButtons(Arrays.asList(rPCButton, rPCButton2));
        }

        public Builder setStartTimestamp(long l) {
            this.rpc.startTimestamp = l;
            return this;
        }

        public Builder setSecrets(String string, String string2) {
            if (this.rpc.button_label_1 != null && this.rpc.button_label_1.isEmpty() || this.rpc.button_label_2 != null && this.rpc.button_label_2.isEmpty()) {
                return this;
            }
            this.rpc.joinSecret = string;
            this.rpc.spectateSecret = string2;
            return this;
        }

        public Builder setEndTimestamp(long l) {
            this.rpc.endTimestamp = l;
            return this;
        }

        public Builder setEndTimestamp(OffsetDateTime offsetDateTime) {
            this.rpc.endTimestamp = offsetDateTime.toEpochSecond();
            return this;
        }

        public Builder setLargeImage(String string) {
            return this.setLargeImage(string, "");
        }

        public DiscordRichPresence build() {
            return this.rpc;
        }
    }
}
