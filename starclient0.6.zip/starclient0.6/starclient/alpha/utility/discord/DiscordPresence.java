package starclient.alpha.utility.discord;

import java.awt.image.BufferedImage;
import java.net.URL;
import java.net.URLConnection;
import javax.imageio.ImageIO;
import starclient.alpha.StarClient;
import starclient.alpha.utility.discord.DiscordEventHandlers;
import starclient.alpha.utility.discord.DiscordRPC;
import starclient.alpha.utility.discord.DiscordRichPresence;
import starclient.alpha.utility.discord.RPCButton;

public class DiscordPresence {
    private static Thread rpcThread;
    private static final long lastTimeMillis;
    public static String avatarUrl;
    public static BufferedImage avatar;
    public static String name;

    public static void startDiscord() {
        DiscordEventHandlers discordEventHandlers = new DiscordEventHandlers.Builder().ready(discordUser -> {
            if (discordUser.avatar != null) {
                avatarUrl = "https://cdn.discordapp.com/avatars/" + discordUser.userId + "/" + discordUser.avatar + ".png";
                try {
                    URLConnection uRLConnection = new URL(avatarUrl).openConnection();
                    uRLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    avatar = ImageIO.read(uRLConnection.getInputStream());
                }
                catch (Exception exception) {
                    // empty catch block
                }
                if (discordUser.username != null) {
                    name = discordUser.username;
                }
            }
        }).build();
        DiscordRPC.INSTANCE.Discord_Initialize("1330784043356131399", discordEventHandlers, true, "");
        rpcThread = new Thread(() -> {
            while (true) {
                DiscordRPC.INSTANCE.Discord_RunCallbacks();
                DiscordPresence.updatePresence();
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException interruptedException) {
                }
            }
        });
        rpcThread.start();
    }

    public static void shutdownDiscord() {
        if (rpcThread != null) {
            rpcThread.interrupt();
            DiscordRPC.INSTANCE.Discord_Shutdown();
        }
    }

    private static void updatePresence() {
        DiscordRichPresence.Builder builder = new DiscordRichPresence.Builder();
        builder.setStartTimestamp(lastTimeMillis / 1000L);
        builder.setDetails("Version: " + StarClient.VERSION);
        builder.setState("always on top");
        builder.setButtons(RPCButton.create("\u041a\u0443\u043f\u0438\u0442\u044c", "https://funpay.com/users/7583227/"), RPCButton.create("\u0414\u0438\u0441\u043a\u043e\u0440\u0434", "https://discord.gg/aYbNSaUsHU"));
        builder.setLargeImage("_4_");
        if (avatarUrl != null) {
            builder.setSmallImage(avatarUrl, name);
        }
        builder.setDetails("Version: " + StarClient.VERSION);
        builder.setState("always on top");
        builder.setButtons(RPCButton.create("\u041a\u0443\u043f\u0438\u0442\u044c", "https://funpay.com/users/7583227/"), RPCButton.create("\u0414\u0438\u0441\u043a\u043e\u0440\u0434", "https://discord.gg/aYbNSaUsHU"));
        DiscordRPC.INSTANCE.Discord_UpdatePresence(builder.build());
    }

    static {
        lastTimeMillis = System.currentTimeMillis();
    }
}
