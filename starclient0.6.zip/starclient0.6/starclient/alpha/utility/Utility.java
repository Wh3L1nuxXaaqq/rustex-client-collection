package starclient.alpha.utility;

import net.minecraft.client.Minecraft;

public interface Utility {
    public static final Minecraft mc = Minecraft.getMinecraft();
}
