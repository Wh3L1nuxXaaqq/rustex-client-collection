package starclient.alpha.utility.move;

import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import starclient.alpha.utility.Utility;

public class MovementUtility
implements Utility {
    public static boolean reason(boolean bl) {
        boolean bl2 = bl && MovementUtility.mc.world.getBlockState(new BlockPos(MovementUtility.mc.player.posX, MovementUtility.mc.player.posY, MovementUtility.mc.player.posZ)).getBlock() instanceof BlockLiquid && MovementUtility.mc.world.getBlockState(new BlockPos(MovementUtility.mc.player.posX, MovementUtility.mc.player.posY + 1.0, MovementUtility.mc.player.posZ)).getBlock() instanceof BlockAir;
        return MovementUtility.mc.player.isPotionActive(MobEffects.BLINDNESS) || MovementUtility.mc.player.isOnLadder() || MovementUtility.mc.player.isInWater() && !bl2 || MovementUtility.mc.player.isInWeb || MovementUtility.mc.player.capabilities.isFlying;
    }

    public static boolean getUnderBoxes(EntityPlayer entityPlayer) {
        return !MovementUtility.mc.world.getCollisionBoxes(entityPlayer, entityPlayer.getEntityBoundingBox().shrink(0.0625)).isEmpty();
    }

    public static double getBaseSpeed() {
        double d = 0.2873;
        if (MovementUtility.mc.player.isPotionActive(Potion.getPotionById(1))) {
            int n = MovementUtility.mc.player.getActivePotionEffect(Potion.getPotionById(1)).getAmplifier();
            d *= 1.0 + 0.2 * (double)(n + 1);
        }
        return d;
    }

    public static boolean isBlockAboveHead() {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(MovementUtility.mc.player.posX - 0.3, MovementUtility.mc.player.posY + (double)MovementUtility.mc.player.getEyeHeight(), MovementUtility.mc.player.posZ + 0.3, MovementUtility.mc.player.posX + 0.3, MovementUtility.mc.player.posY + (!MovementUtility.mc.player.onGround ? 1.5 : 2.5), MovementUtility.mc.player.posZ - 0.3);
        return !MovementUtility.mc.world.getCollisionBoxes(MovementUtility.mc.player, axisAlignedBB).isEmpty();
    }

    public static boolean getOffsetBoxes() {
        return MovementUtility.mc.world.getCollisionBoxes(MovementUtility.mc.player, MovementUtility.mc.player.getEntityBoundingBox().offset(0.0, 0.1, 0.0)).isEmpty();
    }

    public static boolean isMoving() {
        return MovementUtility.mc.gameSettings.keyBindForward.isKeyDown() || MovementUtility.mc.gameSettings.keyBindBack.isKeyDown() || MovementUtility.mc.gameSettings.keyBindRight.isKeyDown() || MovementUtility.mc.gameSettings.keyBindLeft.isKeyDown();
    }

    public static void strafe(double d) {
        if (MovementUtility.isMoving()) {
            double d2 = MovementUtility.getDirection();
            MovementUtility.mc.player.motionX = -Math.sin(d2) * d;
            MovementUtility.mc.player.motionZ = Math.cos(d2) * d;
        }
    }

    public static float getDirection() {
        float f = MovementUtility.mc.player.rotationYaw;
        float f2 = 0.0f;
        if (MovementUtility.mc.player.moveForward > 0.0f) {
            f2 = 1.0f;
        }
        if (MovementUtility.mc.player.moveForward < 0.0f) {
            f2 = -1.0f;
        }
        if (f2 == 0.0f) {
            MovementInput cfr_ignored_0 = MovementUtility.mc.player.movementInput;
            if (MovementInput.moveStrafe > 0.0f) {
                f -= 90.0f;
            }
            MovementInput cfr_ignored_1 = MovementUtility.mc.player.movementInput;
            if (MovementInput.moveStrafe < 0.0f) {
                f += 90.0f;
            }
        } else {
            MovementInput cfr_ignored_2 = MovementUtility.mc.player.movementInput;
            if (MovementInput.moveStrafe > 0.0f) {
                f -= 45.0f * f2;
            }
            MovementInput cfr_ignored_3 = MovementUtility.mc.player.movementInput;
            if (MovementInput.moveStrafe < 0.0f) {
                f += 45.0f * f2;
            }
        }
        if (f2 < 0.0f) {
            f -= 180.0f;
        }
        return (float)Math.toRadians(f);
    }

    public static void setMotion(double d) {
        double d2 = MovementUtility.mc.player.moveForward;
        MovementInput cfr_ignored_0 = MovementUtility.mc.player.movementInput;
        double d3 = MovementInput.moveStrafe;
        float f = MovementUtility.mc.player.rotationYaw;
        if (d2 == 0.0 && d3 == 0.0) {
            MovementUtility.mc.player.motionX = 0.0;
            MovementUtility.mc.player.motionZ = 0.0;
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            double d4 = MathHelper.sin((float)Math.toRadians(f + 90.0f));
            double d5 = MathHelper.cos((float)Math.toRadians(f + 90.0f));
            MovementUtility.mc.player.motionX = d2 * d * d5 + d3 * d * d4;
            MovementUtility.mc.player.motionZ = d2 * d * d4 - d3 * d * d5;
        }
    }

    public static float getMotion() {
        return (float)Math.sqrt(MovementUtility.mc.player.motionX * MovementUtility.mc.player.motionX + MovementUtility.mc.player.motionZ * MovementUtility.mc.player.motionZ);
    }

    public static boolean isInLiquid() {
        return MovementUtility.mc.player.isInWater() || MovementUtility.mc.player.isInLava();
    }
}
