package starclient.alpha.utility.move;

import net.minecraft.network.play.server.SPacketHeldItemChange;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.utility.Utility;

public class PacketUtility
implements Utility {
    public static boolean state;
    private boolean itemChanged;
    private int currentItem = -1;

    public void processPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketHeldItemChange) {
            this.itemChanged = true;
        }
    }

    public void dE(boolean bl) {
        if (this.itemChanged && this.currentItem != -1) {
            state = true;
            PacketUtility.mc.player.inventory.currentItem = this.currentItem;
            if (bl) {
                this.itemChanged = false;
                this.currentItem = -1;
                state = false;
            }
        }
    }

    public void setCurrentItem(int n) {
        this.currentItem = n;
    }
}
