package starclient.alpha.utility.move;

import net.minecraft.block.BlockLiquid;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import starclient.alpha.utility.Utility;

public class BlockUtility
implements Utility {
    public static boolean checkLiquid(float f) {
        return BlockUtility.mc.player != null && BlockUtility.mc.world.getBlockState(new BlockPos(BlockUtility.mc.player.posX, BlockUtility.mc.player.posY - (double)f, BlockUtility.mc.player.posZ)).getBlock() instanceof BlockLiquid;
    }

    public static boolean isBlockUnder(float f) {
        if (BlockUtility.mc.player.posY < 0.0) {
            return false;
        }
        AxisAlignedBB axisAlignedBB = BlockUtility.mc.player.getEntityBoundingBox().offset(0.0, -f, 0.0);
        return BlockUtility.mc.world.getCollisionBoxes(BlockUtility.mc.player, axisAlignedBB).isEmpty();
    }
}
