package starclient.alpha.utility.move;

import java.util.Objects;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.utility.Utility;

public class MoveUtil
implements Utility {
    public static void setSpeed(float f) {
        if (MoveUtil.mc.player.moveForward > 0.0f) {
            MoveUtil.mc.player.motionX = -Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
            MoveUtil.mc.player.motionZ = Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
        }
        if (MoveUtil.mc.player.moveForward < 0.0f) {
            MoveUtil.mc.player.motionX = Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
            MoveUtil.mc.player.motionZ = -Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing > 0.0f) {
            MoveUtil.mc.player.motionX = Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
            MoveUtil.mc.player.motionZ = Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing < 0.0f) {
            MoveUtil.mc.player.motionX = -Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
            MoveUtil.mc.player.motionZ = -Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing > 0.0f && MoveUtil.mc.player.moveForward > 0.0f) {
            MoveUtil.mc.player.motionX = Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw + 45.0f)) * (double)f;
            MoveUtil.mc.player.motionZ = Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw + 45.0f)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing < 0.0f && MoveUtil.mc.player.moveForward > 0.0f) {
            MoveUtil.mc.player.motionX = -Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw - 45.0f)) * (double)f;
            MoveUtil.mc.player.motionZ = -Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw - 45.0f)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing > 0.0f && MoveUtil.mc.player.moveForward < 0.0f) {
            MoveUtil.mc.player.motionX = -Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw + 135.0f)) * (double)f;
            MoveUtil.mc.player.motionZ = -Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw + 135.0f)) * (double)f;
        }
        if (MoveUtil.mc.player.moveStrafing < 0.0f && MoveUtil.mc.player.moveForward < 0.0f) {
            MoveUtil.mc.player.motionX = Math.cos(Math.toRadians(MoveUtil.mc.player.rotationYaw - 135.0f)) * (double)f;
            MoveUtil.mc.player.motionZ = Math.sin(Math.toRadians(MoveUtil.mc.player.rotationYaw - 135.0f)) * (double)f;
        }
    }

    public static void setMotion(double d) {
        double d2 = MoveUtil.mc.player.moveForward;
        MovementInput cfr_ignored_0 = MoveUtil.mc.player.movementInput;
        double d3 = MovementInput.moveStrafe;
        float f = MoveUtil.mc.player.rotationYaw;
        if (d2 == 0.0 && d3 == 0.0) {
            MoveUtil.mc.player.motionX = 0.0;
            MoveUtil.mc.player.motionZ = 0.0;
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            double d4 = MathHelper.sin((float)Math.toRadians(f + 90.0f));
            double d5 = MathHelper.cos((float)Math.toRadians(f + 90.0f));
            MoveUtil.mc.player.motionX = d2 * d * d5 + d3 * d * d4;
            MoveUtil.mc.player.motionZ = d2 * d * d4 - d3 * d * d5;
        }
    }

    public static boolean isUnderBedrock() {
        if (MoveUtil.mc.player.posY <= 3.0) {
            RayTraceResult rayTraceResult = MoveUtil.mc.world.rayTraceBlocks(MoveUtil.mc.player.getPositionVector(), new Vec3d(MoveUtil.mc.player.posX, 0.0, MoveUtil.mc.player.posZ), false, false, false);
            return rayTraceResult == null || rayTraceResult.typeOfHit != RayTraceResult.Type.BLOCK;
        }
        return false;
    }

    public static void setSpeed2(float f) {
        float f2 = MoveUtil.mc.player.rotationYaw;
        float f3 = MoveUtil.mc.player.moveForward;
        MovementInput cfr_ignored_0 = MoveUtil.mc.player.movementInput;
        float f4 = MovementInput.moveStrafe;
        if (f3 != 0.0f) {
            if (f4 > 0.0f) {
                f2 += (float)(f3 > 0.0f ? -45 : 45);
            } else if (f4 < 0.0f) {
                f2 += (float)(f3 > 0.0f ? 45 : -45);
            }
            f4 = 0.0f;
            if (f3 > 0.0f) {
                f3 = 1.0f;
            } else if (f3 < 0.0f) {
                f3 = -1.0f;
            }
        }
        MoveUtil.mc.player.motionX = (double)(f3 * f) * Math.cos(Math.toRadians(f2 + 90.0f)) + (double)(f4 * f) * Math.sin(Math.toRadians(f2 + 90.0f));
        MoveUtil.mc.player.motionZ = (double)(f3 * f) * Math.sin(Math.toRadians(f2 + 90.0f)) - (double)(f4 * f) * Math.cos(Math.toRadians(f2 + 90.0f));
    }

    public static boolean reason(boolean bl) {
        boolean bl2 = bl && MoveUtil.mc.world.getBlockState(new BlockPos(MoveUtil.mc.player.posX, MoveUtil.mc.player.posY, MoveUtil.mc.player.posZ)).getBlock() instanceof BlockLiquid && MoveUtil.mc.world.getBlockState(new BlockPos(MoveUtil.mc.player.posX, MoveUtil.mc.player.posY + 1.0, MoveUtil.mc.player.posZ)).getBlock() instanceof BlockAir;
        return MoveUtil.mc.player.isPotionActive(MobEffects.BLINDNESS) || MoveUtil.mc.player.isOnLadder() || MoveUtil.mc.player.isInWater() && !bl2 || MoveUtil.mc.player.isInWeb || MoveUtil.mc.player.capabilities.isFlying;
    }

    public static double getPlayerMotion() {
        return Math.hypot(MoveUtil.mc.player.motionX, MoveUtil.mc.player.motionZ);
    }

    public static double getBaseSpeed() {
        double d = 0.2873;
        if (MoveUtil.mc.player.isPotionActive(Potion.getPotionById(1))) {
            int n = MoveUtil.mc.player.getActivePotionEffect(Potion.getPotionById(1)).getAmplifier();
            d *= 1.0 + 0.2 * (double)(n + 1);
        }
        return d;
    }

    public static double[] getSpeed(double d) {
        float f = MoveUtil.mc.player.rotationYaw;
        float f2 = MoveUtil.mc.player.moveForward;
        MovementInput cfr_ignored_0 = MoveUtil.mc.player.movementInput;
        float f3 = MovementInput.moveStrafe;
        if (f2 != 0.0f) {
            if (f3 > 0.0f) {
                f += (float)(f2 > 0.0f ? -45 : 45);
            } else if (f3 < 0.0f) {
                f += (float)(f2 > 0.0f ? 45 : -45);
            }
            f3 = 0.0f;
            if (f2 > 0.0f) {
                f2 = 1.0f;
            } else if (f2 < 0.0f) {
                f2 = -1.0f;
            }
        }
        return new double[]{(double)f2 * d * Math.cos(Math.toRadians(f + 90.0f)) + (double)f3 * d * Math.sin(Math.toRadians(f + 90.0f)), (double)f2 * d * Math.sin(Math.toRadians(f + 90.0f)) - (double)f3 * d * Math.cos(Math.toRadians(f + 90.0f)), f};
    }

    public static int getSpeedEffect() {
        if (MoveUtil.mc.player.isPotionActive(MobEffects.SPEED)) {
            return Objects.requireNonNull(MoveUtil.mc.player.getActivePotionEffect(MobEffects.SPEED)).getAmplifier() + 1;
        }
        return 0;
    }

    public static void setStrafe(double d) {
        if (!MoveUtil.isMoving()) {
            return;
        }
        double d2 = MoveUtil.getDirection();
        MoveUtil.mc.player.motionX = -Math.sin(d2) * d;
        MoveUtil.mc.player.motionZ = Math.cos(d2) * d;
    }

    public static boolean isMoving() {
        return MoveUtil.mc.gameSettings.keyBindForward.isKeyDown() || MoveUtil.mc.gameSettings.keyBindBack.isKeyDown() || MoveUtil.mc.gameSettings.keyBindRight.isKeyDown() || MoveUtil.mc.gameSettings.keyBindLeft.isKeyDown();
    }

    public static float getDirection() {
        float f = MoveUtil.mc.player.rotationYaw;
        float f2 = 0.0f;
        if (MoveUtil.mc.player.moveForward > 0.0f) {
            f2 = 1.0f;
        }
        if (MoveUtil.mc.player.moveForward < 0.0f) {
            f2 = -1.0f;
        }
        if (f2 == 0.0f) {
            MovementInput cfr_ignored_0 = MoveUtil.mc.player.movementInput;
            if (MovementInput.moveStrafe > 0.0f) {
                f -= 90.0f;
            }
            MovementInput cfr_ignored_1 = MoveUtil.mc.player.movementInput;
            if (MovementInput.moveStrafe < 0.0f) {
                f += 90.0f;
            }
        } else {
            MovementInput cfr_ignored_2 = MoveUtil.mc.player.movementInput;
            if (MovementInput.moveStrafe > 0.0f) {
                f -= 45.0f * f2;
            }
            MovementInput cfr_ignored_3 = MoveUtil.mc.player.movementInput;
            if (MovementInput.moveStrafe < 0.0f) {
                f += 45.0f * f2;
            }
        }
        if (f2 < 0.0f) {
            f -= 180.0f;
        }
        return (float)Math.toRadians(f);
    }

    public static boolean isBlockAboveHead() {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(MoveUtil.mc.player.posX - 0.3, MoveUtil.mc.player.posY + (double)MoveUtil.mc.player.getEyeHeight(), MoveUtil.mc.player.posZ + 0.3, MoveUtil.mc.player.posX + 0.3, MoveUtil.mc.player.posY + (!MoveUtil.mc.player.onGround ? 1.5 : 2.5), MoveUtil.mc.player.posZ - 0.3);
        return !MoveUtil.mc.world.getCollisionBoxes(MoveUtil.mc.player, axisAlignedBB).isEmpty();
    }

    public static float getMotion() {
        return (float)Math.sqrt(MoveUtil.mc.player.motionX * MoveUtil.mc.player.motionX + MoveUtil.mc.player.motionZ * MoveUtil.mc.player.motionZ);
    }

    public static boolean isInGround() {
        return MoveUtil.mc.player.onGround && !MoveUtil.mc.gameSettings.keyBindJump.pressed;
    }

    public static boolean isInLiquid() {
        return MoveUtil.mc.player.isInWater() || MoveUtil.mc.player.isInLava();
    }
}
