package starclient.alpha.utility.move;

import net.minecraft.init.MobEffects;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketExplosion;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.player.EventDamage;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.misc.TimerHelper;

public class DamageHandler
implements Utility {
    private final TimerHelper timerHelper = new TimerHelper();
    private boolean normalDamage;
    private boolean fallDamage;
    private boolean explosionDamage;
    private boolean arrowDamage;
    private boolean pearlDamage;

    public void processPacket(EventReceivePacket eventReceivePacket) {
        if (!this.isBadEffectActive()) {
            boolean bl;
            if (eventReceivePacket.getPacket() instanceof SPacketExplosion) {
                this.explosionDamage = true;
            }
            boolean bl2 = bl = this.fallDamage || this.arrowDamage || this.explosionDamage || this.pearlDamage;
            if (!bl) {
                SPacketEntityStatus sPacketEntityStatus;
                Packet<?> packet = eventReceivePacket.getPacket();
                if (packet instanceof SPacketEntityStatus && (sPacketEntityStatus = (SPacketEntityStatus)packet).getOpCode() == 2 && sPacketEntityStatus.getEntity(DamageHandler.mc.world) == DamageHandler.mc.player) {
                    this.normalDamage = true;
                }
            } else if (DamageHandler.mc.player.hurtTime > 0) {
                this.normalDamage = false;
                this.reset();
            }
        }
    }

    public boolean isReachedNormal(float f) {
        if (this.normalDamage) {
            if (this.timerHelper.hasReached(f)) {
                this.normalDamage = false;
                this.timerHelper.reset();
                return true;
            }
        } else {
            this.timerHelper.reset();
        }
        return false;
    }

    public void processDamage(EventDamage eventDamage) {
        switch (eventDamage.getDamageType()) {
            case FALL: {
                this.fallDamage = true;
                break;
            }
            case ARROW: {
                this.arrowDamage = true;
                break;
            }
            case ENDER_PEARL: {
                this.pearlDamage = true;
            }
        }
        this.normalDamage = false;
    }

    public void resetDamages() {
        this.normalDamage = false;
        this.reset();
        this.timerHelper.reset();
    }

    private void reset() {
        this.fallDamage = false;
        this.explosionDamage = false;
        this.arrowDamage = false;
        this.pearlDamage = false;
    }

    private boolean isBadEffectActive() {
        return DamageHandler.mc.player.isPotionActive(MobEffects.POISON) || DamageHandler.mc.player.isPotionActive(MobEffects.WITHER) || DamageHandler.mc.player.isPotionActive(MobEffects.INSTANT_DAMAGE);
    }

    public boolean isNormalDamage() {
        return this.normalDamage;
    }
}
