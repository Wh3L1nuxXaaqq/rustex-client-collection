package starclient.alpha.utility.blur.wtf.shader;

import starclient.alpha.utility.blur.wtf.shader.impl.GaussianBlurShader;
import starclient.alpha.utility.blur.wtf.shader.impl.RQShader;

public interface RiseShaders {
    public static final GaussianBlurShader GAUSSIAN_BLUR_SHADER = new GaussianBlurShader();
    public static final RQShader RQ = new RQShader();
}
