package starclient.alpha.utility.blur.wtf.shader.impl;

public class RQShader {
}
