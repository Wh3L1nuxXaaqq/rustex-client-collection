package starclient.alpha.utility.blur.wtf.shader.base;

public enum ShaderRenderType {
    CAMERA,
    OVERLAY;

}
