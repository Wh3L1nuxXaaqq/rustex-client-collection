package starclient.alpha.utility.blur.wtf.shader.base;

import java.util.List;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.wtf.shader.base.ShaderRenderType;

public abstract class RiseShader
implements Utility {
    private boolean active;

    public abstract void run(ShaderRenderType var1, float var2, List<Runnable> var3);

    public abstract void update();

    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean bl) {
        this.active = bl;
    }
}
