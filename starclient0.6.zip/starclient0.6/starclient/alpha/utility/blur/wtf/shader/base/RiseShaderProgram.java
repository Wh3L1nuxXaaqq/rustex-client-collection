package starclient.alpha.utility.blur.wtf.shader.base;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.wtf.shader.ShaderUtil;

public class RiseShaderProgram
implements Utility {
    private final int programId;

    public RiseShaderProgram(String string, String string2) {
        this.programId = ShaderUtil.createShader(string, string2);
    }

    public static void drawQuad(double d, double d2, double d3, double d4) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
        bufferBuilder.pos(d, d2 + d4, 0.0).tex(0.0, 0.0).endVertex();
        bufferBuilder.pos(d + d3, d2 + d4, 0.0).tex(1.0, 0.0).endVertex();
        bufferBuilder.pos(d + d3, d2, 0.0).tex(1.0, 1.0).endVertex();
        bufferBuilder.pos(d, d2, 0.0).tex(0.0, 1.0).endVertex();
        Tessellator.getInstance().draw();
    }

    public int getUniform(String string) {
        return GL20.glGetUniformLocation((int)this.getProgramId(), (CharSequence)string);
    }

    public void setUniformf(String string, float ... fArray) {
        int n = GL20.glGetUniformLocation((int)this.getProgramId(), (CharSequence)string);
        switch (fArray.length) {
            case 1: {
                GL20.glUniform1f((int)n, (float)fArray[0]);
                break;
            }
            case 2: {
                GL20.glUniform2f((int)n, (float)fArray[0], (float)fArray[1]);
                break;
            }
            case 3: {
                GL20.glUniform3f((int)n, (float)fArray[0], (float)fArray[1], (float)fArray[2]);
                break;
            }
            case 4: {
                GL20.glUniform4f((int)n, (float)fArray[0], (float)fArray[1], (float)fArray[2], (float)fArray[3]);
            }
        }
    }

    public void setUniformi(String string, int ... nArray) {
        int n = GL20.glGetUniformLocation((int)this.getProgramId(), (CharSequence)string);
        if (nArray.length > 1) {
            GL20.glUniform2i((int)n, (int)nArray[0], (int)nArray[1]);
        } else {
            GL20.glUniform1i((int)n, (int)nArray[0]);
        }
    }

    public static void drawQuad() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        RiseShaderProgram.drawQuad(0.0, 0.0, scaledResolution.getScaledWidth_double(), scaledResolution.getScaledHeight_double());
    }

    public void start() {
        GL20.glUseProgram((int)this.programId);
    }

    public static void stop() {
        GL20.glUseProgram((int)0);
    }

    public int getProgramId() {
        return this.programId;
    }
}
