package starclient.alpha.utility.blur.wtf.shader.impl;

import java.nio.FloatBuffer;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL13;
import starclient.alpha.utility.blur.wtf.shader.base.RiseShader;
import starclient.alpha.utility.blur.wtf.shader.base.RiseShaderProgram;
import starclient.alpha.utility.blur.wtf.shader.base.ShaderRenderType;
import starclient.alpha.utility.blur.wtf.shader.base.ShaderUniforms;
import starclient.alpha.utility.blur.wtf.shader.kernel.GaussianKernel;

public class GaussianBlurShader
extends RiseShader {
    private final RiseShaderProgram blurProgram = new RiseShaderProgram("/minecraft/starclient/shaders/gaussian.frag", "/assets/minecraft/client/shaders/vertex.vsh");
    private Framebuffer inputFramebuffer;
    private Framebuffer outputFramebuffer;
    private GaussianKernel gaussianKernel;

    public GaussianBlurShader() {
        this.inputFramebuffer = new Framebuffer(Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight, true);
        this.outputFramebuffer = new Framebuffer(Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight, true);
        this.gaussianKernel = new GaussianKernel(0);
    }

    @Override
    public void run(ShaderRenderType shaderRenderType, float f, List<Runnable> list) {
        if (!Display.isVisible()) {
            return;
        }
        switch (shaderRenderType) {
            case CAMERA: {
                this.update();
                this.setActive(!list.isEmpty());
                if (!this.isActive()) break;
                this.inputFramebuffer.bindFramebuffer(true);
                list.forEach(Runnable::run);
                mc.getFramebuffer().bindFramebuffer(true);
                break;
            }
            case OVERLAY: {
                this.setActive(this.isActive() || !list.isEmpty());
                if (!this.isActive()) break;
                this.inputFramebuffer.bindFramebuffer(true);
                list.forEach(Runnable::run);
                int n = 8;
                float f2 = 2.0f;
                int n2 = this.blurProgram.getProgramId();
                this.outputFramebuffer.bindFramebuffer(true);
                this.blurProgram.start();
                if (this.gaussianKernel.getSize() != 8) {
                    this.gaussianKernel = new GaussianKernel(8);
                    this.gaussianKernel.compute();
                    FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)8);
                    floatBuffer.put(this.gaussianKernel.getKernel());
                    floatBuffer.flip();
                    ShaderUniforms.uniform1f(n2, "u_radius", 8.0f);
                    ShaderUniforms.uniformFB(n2, "u_kernel", floatBuffer);
                    ShaderUniforms.uniform1i(n2, "u_diffuse_sampler", 0);
                    ShaderUniforms.uniform1i(n2, "u_other_sampler", 16);
                }
                ShaderUniforms.uniform2f(n2, "u_texel_size", 1.0f / (float)GaussianBlurShader.mc.displayWidth, 1.0f / (float)GaussianBlurShader.mc.displayHeight);
                ShaderUniforms.uniform2f(n2, "u_direction", 2.0f, 0.0f);
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                GlStateManager.alphaFunc(516, 0.0f);
                mc.getFramebuffer().bindFramebufferTexture();
                RiseShaderProgram.drawQuad();
                mc.getFramebuffer().bindFramebuffer(true);
                ShaderUniforms.uniform2f(n2, "u_direction", 0.0f, 2.0f);
                this.outputFramebuffer.bindFramebufferTexture();
                GL13.glActiveTexture((int)34004);
                this.inputFramebuffer.bindFramebufferTexture();
                GL13.glActiveTexture((int)33984);
                RiseShaderProgram.drawQuad();
                GlStateManager.disableBlend();
                RiseShaderProgram.stop();
            }
        }
    }

    @Override
    public void update() {
        this.setActive(false);
        if (GaussianBlurShader.mc.displayWidth != this.inputFramebuffer.framebufferWidth || GaussianBlurShader.mc.displayHeight != this.inputFramebuffer.framebufferHeight) {
            this.inputFramebuffer.deleteFramebuffer();
            this.inputFramebuffer = new Framebuffer(GaussianBlurShader.mc.displayWidth, GaussianBlurShader.mc.displayHeight, true);
            this.outputFramebuffer.deleteFramebuffer();
            this.outputFramebuffer = new Framebuffer(GaussianBlurShader.mc.displayWidth, GaussianBlurShader.mc.displayHeight, true);
        } else {
            this.inputFramebuffer.framebufferClear();
            this.outputFramebuffer.framebufferClear();
        }
    }
}
