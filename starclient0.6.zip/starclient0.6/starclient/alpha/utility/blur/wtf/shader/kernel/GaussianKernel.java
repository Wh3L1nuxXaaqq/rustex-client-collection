package starclient.alpha.utility.blur.wtf.shader.kernel;

public class GaussianKernel {
    private final int size;
    private final float[] kernel;

    public GaussianKernel(int n) {
        this.size = n;
        this.kernel = new float[n];
    }

    public void compute() {
        int n;
        float f = (float)this.size / 2.0f;
        float f2 = 0.0f;
        for (n = 0; n < this.size; ++n) {
            float f3 = (float)n / f;
            this.kernel[n] = 1.0f / (Math.abs(f) * 2.5066283f) * (float)Math.exp(-0.5 * (double)f3 * (double)f3);
            f2 += n > 0 ? this.kernel[n] * 2.0f : this.kernel[0];
        }
        n = 0;
        while (n < this.size) {
            int n2 = n++;
            this.kernel[n2] = this.kernel[n2] / f2;
        }
    }

    public int getSize() {
        return this.size;
    }

    public float[] getKernel() {
        return this.kernel;
    }
}
