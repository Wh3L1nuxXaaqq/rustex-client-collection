package starclient.alpha.utility.blur.wtf.shader.base;

import java.nio.FloatBuffer;
import org.lwjgl.opengl.GL20;

public class ShaderUniforms {
    public static void uniformFB(int n, String string, FloatBuffer floatBuffer) {
        GL20.glUniform1((int)ShaderUniforms.getLocation(n, string), (FloatBuffer)floatBuffer);
    }

    public static void uniform1i(int n, String string, int n2) {
        GL20.glUniform1i((int)ShaderUniforms.getLocation(n, string), (int)n2);
    }

    public static void uniform2i(int n, String string, int n2, int n3) {
        GL20.glUniform2i((int)ShaderUniforms.getLocation(n, string), (int)n2, (int)n3);
    }

    public static void uniform1f(int n, String string, float f) {
        GL20.glUniform1f((int)ShaderUniforms.getLocation(n, string), (float)f);
    }

    public static void uniform2f(int n, String string, float f, float f2) {
        GL20.glUniform2f((int)ShaderUniforms.getLocation(n, string), (float)f, (float)f2);
    }

    public static void uniform3f(int n, String string, float f, float f2, float f3) {
        GL20.glUniform3f((int)ShaderUniforms.getLocation(n, string), (float)f, (float)f2, (float)f3);
    }

    public static void uniform4f(int n, String string, float f, float f2, float f3, float f4) {
        GL20.glUniform4f((int)ShaderUniforms.getLocation(n, string), (float)f, (float)f2, (float)f3, (float)f4);
    }

    private static int getLocation(int n, String string) {
        return GL20.glGetUniformLocation((int)n, (CharSequence)string);
    }
}
