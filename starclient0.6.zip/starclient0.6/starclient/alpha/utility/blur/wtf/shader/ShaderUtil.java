package starclient.alpha.utility.blur.wtf.shader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.Utility;

public class ShaderUtil
implements Utility {
    private static final IResourceManager RESOURCE_MANAGER = mc.getResourceManager();

    public static int createShader(String string, String string2) {
        String string3 = ShaderUtil.getShaderResource(string);
        String string4 = ShaderUtil.getShaderResource(string2);
        if (string == null || string2 == null) {
            System.out.println("An error occurred whilst creating shader");
            System.out.println("Fragment: " + string3 == null);
            System.out.println("Vertex: " + string4 == null);
            return -1;
        }
        int n = GL20.glCreateShader((int)35632);
        int n2 = GL20.glCreateShader((int)35633);
        GL20.glShaderSource((int)n, (CharSequence)string3);
        GL20.glShaderSource((int)n2, (CharSequence)string4);
        GL20.glCompileShader((int)n);
        GL20.glCompileShader((int)n2);
        if (!ShaderUtil.compileShader(n)) {
            return -1;
        }
        if (!ShaderUtil.compileShader(n2)) {
            return -1;
        }
        int n3 = GL20.glCreateProgram();
        GL20.glAttachShader((int)n3, (int)n);
        GL20.glAttachShader((int)n3, (int)n2);
        GL20.glValidateProgram((int)n3);
        GL20.glLinkProgram((int)n3);
        GL20.glDeleteShader((int)n);
        GL20.glDeleteShader((int)n2);
        return n3;
    }

    private static boolean compileShader(int n) {
        boolean bl;
        boolean bl2 = bl = GL20.glGetShaderi((int)n, (int)35713) == 1;
        if (bl) {
            return true;
        }
        String string = GL20.glGetShaderInfoLog((int)n, (int)8192);
        System.out.println("\nError while compiling shader: ");
        System.out.println("-------------------------------");
        System.out.println(string);
        return false;
    }

    public static String getShaderResource(String string) {
        try {
            InputStream inputStream = RESOURCE_MANAGER.getResource(new ResourceLocation(string)).getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            Object object = "";
            try {
                String string2;
                while ((string2 = bufferedReader.readLine()) != null) {
                    object = (String)object + string2 + System.lineSeparator();
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
            return object;
        }
        catch (IOException | NullPointerException exception) {
            System.out.println("An error occurred while getting a shader resource");
            exception.printStackTrace();
            return null;
        }
    }

    public static void drawQuads(ScaledResolution scaledResolution) {
        if (Minecraft.getMinecraft().gameSettings.ofFastRender) {
            return;
        }
        float f = (float)scaledResolution.getScaledWidth_double();
        float f2 = (float)scaledResolution.getScaledHeight_double();
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)0.0f, (float)0.0f);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)0.0f, (float)f2);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)f, (float)0.0f);
        GL11.glEnd();
    }
}
