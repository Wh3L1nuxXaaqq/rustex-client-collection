package starclient.alpha.utility.blur;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.blur.FileUtils;

public class ShaderUtility {
    private final int programID;
    public static Minecraft mc = Minecraft.getMinecraft();
    private final String roundedTexturedShader = "#version 120\n\nuniform vec2 location, rectSize;\nuniform sampler2D textureIn;\nuniform float radius, alpha;\n\nfloat roundedBoxSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) -size, 0.)) - radius;\n}\n\n\nvoid main() {\n    float distance = roundedBoxSDF((rectSize * .5) - (gl_TexCoord[0].st * rectSize), (rectSize * .5) - radius - 1., radius);\n    float smoothedAlpha =  (1.0-smoothstep(0.0, 2.0, distance)) * alpha;\n    gl_FragColor = vec4(texture2D(textureIn, gl_TexCoord[0].st).rgb, smoothedAlpha);\n}";
    private final String roundedRectGradient = "#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color1, color2, color3, color4;\nuniform float radius;\n\n#define NOISE .5/255.0\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b , 0.0)) - r;\n}\n\nvec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\n    vec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\n    //Dithering the color\n    // from https://shader-tutorial.dev/advanced/color-banding-dithering/\n    color += mix(NOISE, -NOISE, fract(sin(dot(coords.xy, vec2(12.9898, 78.233))) * 43758.5453));\n    return color;\n}\n\nvoid main() {\n    vec2 st = gl_TexCoord[0].st;\n    vec2 halfSize = rectSize * .5;\n    \n    float smoothedAlpha =  (1.0-smoothstep(0.0, 2., roundSDF(halfSize - (gl_TexCoord[0].st * rectSize), halfSize - radius - 1., radius))) * color1.a;\n    gl_FragColor = vec4(createGradient(st, color1.rgb, color2.rgb, color3.rgb, color4.rgb), smoothedAlpha);\n}";
    private final String roundRectOutline = "#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color, outlineColor;\nuniform float radius, outlineThickness;\n\nfloat roundedSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) - size + radius, 0.0)) - radius;\n}\n\nvoid main() {\n    float distance = roundedSDF(gl_FragCoord.xy - location - (rectSize * .5), (rectSize * .5) + (outlineThickness *.5) - 1.0, radius);\n\n    float blendAmount = smoothstep(0., 2., abs(distance) - (outlineThickness * .5));\n\n    vec4 insideColor = (distance < 0.) ? color : vec4(outlineColor.rgb,  0.0);\n    gl_FragColor = mix(outlineColor, insideColor, blendAmount);\n\n}";
    private final String roundedRect = "#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color;\nuniform float radius;\nuniform bool blur;\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b, 0.0)) - r;\n}\n\n\nvoid main() {\n    vec2 rectHalf = rectSize * 0.5;\n    // Smooth the result (free antialiasing).\n    float smoothedAlpha =  (1.0-smoothstep(0.0, 1.0, roundSDF(rectHalf - (gl_TexCoord[0].st * rectSize), rectHalf - radius - 1., radius))) * color.a;\n    gl_FragColor = vec4(color.rgb, smoothedAlpha);// mix(quadColor, shadowColor, 0.0);\n\n}";

    public ShaderUtility(String string, String string2) {
        int n;
        int n2 = GL20.glCreateProgram();
        try {
            n = switch (string) {
                case "roundedRect", "rounded" -> this.createShader(new ByteArrayInputStream("#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color;\nuniform float radius;\nuniform bool blur;\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b, 0.0)) - r;\n}\n\n\nvoid main() {\n    vec2 rectHalf = rectSize * 0.5;\n    // Smooth the result (free antialiasing).\n    float smoothedAlpha =  (1.0-smoothstep(0.0, 1.0, roundSDF(rectHalf - (gl_TexCoord[0].st * rectSize), rectHalf - radius - 1., radius))) * color.a;\n    gl_FragColor = vec4(color.rgb, smoothedAlpha);// mix(quadColor, shadowColor, 0.0);\n\n}".getBytes()), 35632);
                case "roundedRectGradient" -> this.createShader(new ByteArrayInputStream("#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color1, color2, color3, color4;\nuniform float radius;\n\n#define NOISE .5/255.0\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b , 0.0)) - r;\n}\n\nvec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\n    vec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\n    //Dithering the color\n    // from https://shader-tutorial.dev/advanced/color-banding-dithering/\n    color += mix(NOISE, -NOISE, fract(sin(dot(coords.xy, vec2(12.9898, 78.233))) * 43758.5453));\n    return color;\n}\n\nvoid main() {\n    vec2 st = gl_TexCoord[0].st;\n    vec2 halfSize = rectSize * .5;\n    \n    float smoothedAlpha =  (1.0-smoothstep(0.0, 2., roundSDF(halfSize - (gl_TexCoord[0].st * rectSize), halfSize - radius - 1., radius))) * color1.a;\n    gl_FragColor = vec4(createGradient(st, color1.rgb, color2.rgb, color3.rgb, color4.rgb), smoothedAlpha);\n}".getBytes()), 35632);
                case "roundedTexturedShader" -> this.createShader(new ByteArrayInputStream("#version 120\n\nuniform vec2 location, rectSize;\nuniform sampler2D textureIn;\nuniform float radius, alpha;\n\nfloat roundedBoxSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) -size, 0.)) - radius;\n}\n\n\nvoid main() {\n    float distance = roundedBoxSDF((rectSize * .5) - (gl_TexCoord[0].st * rectSize), (rectSize * .5) - radius - 1., radius);\n    float smoothedAlpha =  (1.0-smoothstep(0.0, 2.0, distance)) * alpha;\n    gl_FragColor = vec4(texture2D(textureIn, gl_TexCoord[0].st).rgb, smoothedAlpha);\n}".getBytes()), 35632);
                case "roundRectOutline" -> this.createShader(new ByteArrayInputStream("#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color, outlineColor;\nuniform float radius, outlineThickness;\n\nfloat roundedSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) - size + radius, 0.0)) - radius;\n}\n\nvoid main() {\n    float distance = roundedSDF(gl_FragCoord.xy - location - (rectSize * .5), (rectSize * .5) + (outlineThickness *.5) - 1.0, radius);\n\n    float blendAmount = smoothstep(0., 2., abs(distance) - (outlineThickness * .5));\n\n    vec4 insideColor = (distance < 0.) ? color : vec4(outlineColor.rgb,  0.0);\n    gl_FragColor = mix(outlineColor, insideColor, blendAmount);\n\n}".getBytes()), 35632);
                default -> this.createShader(mc.getResourceManager().getResource(new ResourceLocation(string)).getInputStream(), 35632);
            };
            GL20.glAttachShader((int)n2, (int)n);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        GL20.glLinkProgram((int)n2);
        n = GL20.glGetProgrami((int)n2, (int)35714);
        if (n == 0) {
            throw new IllegalStateException("Shader failed to link!");
        }
        this.programID = n2;
    }

    public ShaderUtility(String string) {
        this(string, "expensive//shaders/vertex.vsh");
    }

    public static Framebuffer createFrameBuffer(Framebuffer framebuffer) {
        if (framebuffer == null || framebuffer.framebufferWidth != ShaderUtility.mc.displayWidth || framebuffer.framebufferHeight != ShaderUtility.mc.displayHeight) {
            if (framebuffer != null) {
                framebuffer.deleteFramebuffer();
            }
            return new Framebuffer(ShaderUtility.mc.displayWidth, ShaderUtility.mc.displayHeight, true);
        }
        return framebuffer;
    }

    public void init() {
        GL20.glUseProgram((int)this.programID);
    }

    public void unload() {
        GL20.glUseProgram((int)0);
    }

    public int getUniform(String string) {
        return GL20.glGetUniformLocation((int)this.programID, (CharSequence)string);
    }

    public static void setupRoundedRectUniforms(float f, float f2, float f3, float f4, float f5, ShaderUtility shaderUtility) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        float[] fArray = new float[2];
        fArray[0] = f * (float)scaledResolution.getScaleFactor();
        fArray[1] = (float)Minecraft.getMinecraft().displayHeight - f4 * (float)scaledResolution.getScaleFactor() - f2 * (float)scaledResolution.getScaleFactor();
        shaderUtility.setUniformf("location", fArray);
        float[] fArray2 = new float[2];
        fArray2[0] = f3 * (float)scaledResolution.getScaleFactor();
        fArray2[1] = f4 * (float)scaledResolution.getScaleFactor();
        shaderUtility.setUniformf("rectSize", fArray2);
        float[] fArray3 = new float[1];
        fArray3[0] = f5 * (float)scaledResolution.getScaleFactor();
        shaderUtility.setUniformf("radius", fArray3);
    }

    public void setUniformf(String string, float ... fArray) {
        int n = GL20.glGetUniformLocation((int)this.programID, (CharSequence)string);
        switch (fArray.length) {
            case 1: {
                GL20.glUniform1f((int)n, (float)fArray[0]);
                break;
            }
            case 2: {
                GL20.glUniform2f((int)n, (float)fArray[0], (float)fArray[1]);
                break;
            }
            case 3: {
                GL20.glUniform3f((int)n, (float)fArray[0], (float)fArray[1], (float)fArray[2]);
                break;
            }
            case 4: {
                GL20.glUniform4f((int)n, (float)fArray[0], (float)fArray[1], (float)fArray[2], (float)fArray[3]);
            }
        }
    }

    public void setUniformi(String string, int ... nArray) {
        int n = GL20.glGetUniformLocation((int)this.programID, (CharSequence)string);
        if (nArray.length > 1) {
            GL20.glUniform2i((int)n, (int)nArray[0], (int)nArray[1]);
        } else {
            GL20.glUniform1i((int)n, (int)nArray[0]);
        }
    }

    public static void drawQuads(float f, float f2, float f3, float f4) {
        if (ShaderUtility.mc.gameSettings.ofFastRender) {
            return;
        }
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
        bufferBuilder.pos(f, f2 + f4, 0.0).tex(0.0, 1.0).endVertex();
        bufferBuilder.pos(f + f3, f2 + f4, 0.0).tex(1.0, 1.0).endVertex();
        bufferBuilder.pos(f + f3, f2, 0.0).tex(1.0, 0.0).endVertex();
        bufferBuilder.pos(f, f2, 0.0).tex(0.0, 0.0).endVertex();
        tessellator.draw();
    }

    public static void drawQuads() {
        if (ShaderUtility.mc.gameSettings.ofFastRender) {
            return;
        }
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        float f = (float)scaledResolution.getScaledWidth_double();
        float f2 = (float)scaledResolution.getScaledHeight_double();
        BufferBuilder bufferBuilder = Tessellator.getInstance().getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
        bufferBuilder.pos(0.0, 0.0, 0.0).tex(0.0, 1.0).endVertex();
        bufferBuilder.pos(0.0, f2, 0.0).tex(0.0, 0.0).endVertex();
        bufferBuilder.pos(f, f2, 0.0).tex(1.0, 0.0).endVertex();
        bufferBuilder.pos(f, 0.0, 0.0).tex(1.0, 1.0).endVertex();
        Tessellator.getInstance().draw();
    }

    private int createShader(InputStream inputStream, int n) {
        int n2 = GL20.glCreateShader((int)n);
        GL20.glShaderSource((int)n2, (CharSequence)FileUtils.readInputStream(inputStream));
        GL20.glCompileShader((int)n2);
        if (GL20.glGetShaderi((int)n2, (int)35713) == 0) {
            System.out.println(GL20.glGetShaderInfoLog((int)n2, (int)4096));
            throw new IllegalStateException(String.format("Shader (%s) failed to compile!", n));
        }
        return n2;
    }

    public static void bindTexture(int n) {
        GlStateManager.bindTexture(n);
    }

    public static float calculateGaussianValue(float f, float f2) {
        double d = 3.141592653;
        double d2 = 1.0 / Math.sqrt(2.0 * d * (double)(f2 * f2));
        return (float)(d2 * Math.exp((double)(-(f * f)) / (2.0 * (double)(f2 * f2))));
    }
}
