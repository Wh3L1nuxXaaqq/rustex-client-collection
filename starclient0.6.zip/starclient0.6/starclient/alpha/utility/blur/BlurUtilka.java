package starclient.alpha.utility.blur;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.shader.Framebuffer;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.BloomUtil;
import starclient.alpha.utility.blur.ShaderUtility;
import starclient.alpha.utility.blur.StencilUtil;
import starclient.alpha.utility.render.blur.GaussianBlur;

public class BlurUtilka
implements Utility {
    public static Framebuffer bloomFramebuffer = ShaderUtility.createFrameBuffer(new Framebuffer(new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth(), new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight(), true));

    public static void drawBlur(float f, Runnable runnable) {
        StencilUtil.initStencilToWrite();
        runnable.run();
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(f);
        StencilUtil.uninitStencilBuffer();
    }

    public static void drawBlurRect(float f, Runnable runnable, float f2) {
        StencilUtil.initStencilToWrite();
        runnable.run();
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlurRect(f, f2);
        StencilUtil.uninitStencilBuffer();
    }

    public static void drawShadow(float f, float f2, Runnable runnable, int n, boolean bl) {
        bloomFramebuffer = ShaderUtility.createFrameBuffer(bloomFramebuffer);
        bloomFramebuffer.framebufferClear();
        bloomFramebuffer.bindFramebuffer(true);
        runnable.run();
        bloomFramebuffer.unbindFramebuffer();
        BloomUtil.renderBlur(BlurUtilka.bloomFramebuffer.framebufferTexture, (int)f, 1, n, f2, !bl);
    }
}
