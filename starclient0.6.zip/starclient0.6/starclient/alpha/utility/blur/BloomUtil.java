package starclient.alpha.utility.blur;

import java.nio.FloatBuffer;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.ShaderUtility;
import starclient.alpha.utility.render.ColorUtility;

public class BloomUtil
implements Utility {
    public static ShaderUtility gaussianBloom = new ShaderUtility("starclient/shaders/bloom.frag");
    public static Framebuffer framebuffer = ShaderUtility.createFrameBuffer(new Framebuffer(new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth(), new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight(), true));
    static Framebuffer framebuffer1 = ShaderUtility.createFrameBuffer(new Framebuffer(1, 1, false));

    public static void update(Framebuffer framebuffer) {
        if (framebuffer.framebufferWidth != BloomUtil.mc.displayWidth || framebuffer.framebufferHeight != BloomUtil.mc.displayHeight) {
            framebuffer.createBindFramebuffer(BloomUtil.mc.displayWidth, BloomUtil.mc.displayHeight);
        }
    }

    public static void renderBlur(List<Runnable> list) {
        BloomUtil.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        list.forEach(Runnable::run);
        framebuffer1.unbindFramebuffer();
        BloomUtil.renderBlur(BloomUtil.framebuffer1.framebufferTexture, 10, 1, ColorUtility.rgba(0, 0, 0, 255), 2.0f, true);
    }

    public static void renderBlur(Runnable runnable) {
        BloomUtil.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        runnable.run();
        framebuffer1.unbindFramebuffer();
        BloomUtil.renderBlur(BloomUtil.framebuffer1.framebufferTexture, 10, 1, ColorUtility.rgba(0, 0, 0, 255), 2.0f, true);
    }

    public static void renderBlur(Runnable runnable, int n, int n2, int n3, boolean bl) {
        BloomUtil.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        runnable.run();
        framebuffer1.unbindFramebuffer();
        BloomUtil.renderBlur(BloomUtil.framebuffer1.framebufferTexture, n, 1, n3, n2, bl);
    }

    public static void renderBlur(Runnable runnable, int n, int n2, int n3, boolean bl, Framebuffer framebuffer) {
        BloomUtil.update(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        runnable.run();
        framebuffer.unbindFramebuffer();
        BloomUtil.renderBlur(framebuffer.framebufferTexture, n, 1, n3, n2, bl);
    }

    public static void renderBlur(int n, int n2, int n3, int n4, float f, boolean bl) {
        framebuffer = ShaderUtility.createFrameBuffer(framebuffer);
        GlStateManager.pushMatrix();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.0f);
        GlStateManager.enableBlend();
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)256);
        for (int i = 1; i <= n2; ++i) {
            floatBuffer.put(ShaderUtility.calculateGaussianValue(i, (float)n2 / 2.0f));
        }
        floatBuffer.rewind();
        BloomUtil.setAlphaLimit(0.0f);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        gaussianBloom.init();
        BloomUtil.setupUniforms(n2, 1, 0, floatBuffer, n4, f, bl);
        ShaderUtility.bindTexture(n);
        ShaderUtility.drawQuads();
        gaussianBloom.unload();
        framebuffer.unbindFramebuffer();
        mc.getFramebuffer().bindFramebuffer(true);
        gaussianBloom.init();
        BloomUtil.setupUniforms(n2, 0, 1, floatBuffer, n4, f, bl);
        GlStateManager.setActiveTexture(34000);
        ShaderUtility.bindTexture(n);
        GlStateManager.setActiveTexture(33984);
        ShaderUtility.bindTexture(BloomUtil.framebuffer.framebufferTexture);
        ShaderUtility.drawQuads();
        gaussianBloom.unload();
        GlStateManager.alphaFunc(516, 0.0f);
        GlStateManager.enableAlpha();
        GlStateManager.bindTexture(0);
        GlStateManager.popMatrix();
    }

    public static void setAlphaLimit(float f) {
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, (float)((double)f * 0.01));
    }

    public static void setupUniforms(int n, int n2, int n3, FloatBuffer floatBuffer, int n4, float f, boolean bl) {
        gaussianBloom.setUniformi("avoidTexture", bl ? 1 : 0);
        gaussianBloom.setUniformi("inTexture", 0);
        gaussianBloom.setUniformi("textureToCheck", 16);
        gaussianBloom.setUniformf("radius", n);
        gaussianBloom.setUniformf("exposure", f);
        gaussianBloom.setUniformf("color", (float)ColorUtility.getRed(n4) / 255.0f, (float)ColorUtility.getGreen(n4) / 255.0f, (float)ColorUtility.getBlue(n4) / 255.0f);
        gaussianBloom.setUniformf("texelSize", 1.0f / (float)BloomUtil.mc.displayWidth, 1.0f / (float)BloomUtil.mc.displayHeight);
        gaussianBloom.setUniformf("direction", n2, n3);
        GL20.glUniform1((int)gaussianBloom.getUniform("weights"), (FloatBuffer)floatBuffer);
    }
}
