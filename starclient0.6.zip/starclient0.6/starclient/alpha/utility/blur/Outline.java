package starclient.alpha.utility.blur;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.ShaderUtility;

public class Outline
implements Utility {
    public static ShaderUtility gaussianBloom = new ShaderUtility("expensive/shaders/outline.frag");
    public static Framebuffer framebuffer = ShaderUtility.createFrameBuffer(new Framebuffer(new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth(), new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight(), true));
    static Framebuffer framebuffer1 = ShaderUtility.createFrameBuffer(new Framebuffer(1, 1, false));

    public static void update(Framebuffer framebuffer) {
        if (framebuffer.framebufferWidth != Outline.mc.displayWidth || framebuffer.framebufferHeight != Outline.mc.displayHeight) {
            framebuffer.createBindFramebuffer(Outline.mc.displayWidth, Outline.mc.displayHeight);
        }
    }

    public static void renderBlur(List<Runnable> list) {
        Outline.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        list.forEach(Runnable::run);
        framebuffer1.unbindFramebuffer();
        Outline.renderBlur(Outline.framebuffer1.framebufferTexture, 10, 1, Color.BLACK.getRGB(), 2.0f, true);
    }

    public static void renderBlur(Runnable runnable) {
        Outline.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        runnable.run();
        framebuffer1.unbindFramebuffer();
        Outline.renderBlur(Outline.framebuffer1.framebufferTexture, 10, 1, Color.BLACK.getRGB(), 2.0f, true);
    }

    public static void renderBlur(Runnable runnable, int n) {
        Outline.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        runnable.run();
        framebuffer1.unbindFramebuffer();
        Outline.renderBlur(Outline.framebuffer1.framebufferTexture, 0, 1, n, 0.0f, false);
    }

    public static void renderBlur(Runnable runnable, int n, int n2, int n3, boolean bl, Framebuffer framebuffer) {
        Outline.update(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        runnable.run();
        framebuffer.unbindFramebuffer();
        Outline.renderBlur(framebuffer.framebufferTexture, n, 1, n3, n2, bl);
    }

    public static void renderBlur(int n, int n2, int n3, int n4, float f, boolean bl) {
        Outline.update(framebuffer);
        GlStateManager.pushMatrix();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.0f);
        GlStateManager.enableBlend();
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)256);
        for (int i = 1; i <= n2; ++i) {
            floatBuffer.put(ShaderUtility.calculateGaussianValue(i, (float)n2 / 2.0f));
        }
        floatBuffer.rewind();
        Outline.setAlphaLimit(0.0f);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        gaussianBloom.init();
        Outline.setupUniforms(n2, 1, 0, floatBuffer, n4, f, bl);
        ShaderUtility.bindTexture(n);
        ShaderUtility.drawQuads();
        gaussianBloom.unload();
        framebuffer.unbindFramebuffer();
        mc.getFramebuffer().bindFramebuffer(true);
        gaussianBloom.init();
        Outline.setupUniforms(n2, 0, 1, floatBuffer, n4, f, bl);
        GlStateManager.setActiveTexture(34000);
        ShaderUtility.bindTexture(n);
        GlStateManager.setActiveTexture(33984);
        ShaderUtility.bindTexture(Outline.framebuffer.framebufferTexture);
        ShaderUtility.drawQuads();
        gaussianBloom.unload();
        GlStateManager.alphaFunc(516, 0.0f);
        GlStateManager.enableAlpha();
        GlStateManager.bindTexture(0);
        GlStateManager.popMatrix();
    }

    public static void setAlphaLimit(float f) {
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, (float)((double)f * 0.01));
    }

    public static void setupUniforms(int n, int n2, int n3, FloatBuffer floatBuffer, int n4, float f, boolean bl) {
        gaussianBloom.setUniformi("texture", 0);
        Color color = new Color(n4);
        gaussianBloom.setUniformf("color", (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f);
        gaussianBloom.setUniformf("texelSize", 1.0f / (float)Outline.mc.displayWidth, 1.0f / (float)Outline.mc.displayHeight);
        gaussianBloom.setUniformf("direction", n2, n3);
    }
}
