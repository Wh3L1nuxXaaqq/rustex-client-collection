package starclient.alpha.utility.blur;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL11;
import starclient.alpha.utility.blur.ShaderUtility;
import starclient.alpha.utility.blur.StencilUtil;

public class SmartStencil {
    public static Framebuffer framebuffer = new Framebuffer(1, 1, false);

    public static void update(Framebuffer framebuffer) {
        if (framebuffer.framebufferWidth != Minecraft.getMinecraft().displayWidth || framebuffer.framebufferHeight != Minecraft.getMinecraft().displayHeight) {
            framebuffer.createBindFramebuffer(Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        }
    }

    public static void renderStart(Runnable runnable) {
        SmartStencil.update(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        runnable.run();
        framebuffer.unbindFramebuffer();
        Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(true);
        if (framebuffer != null) {
            GL11.glPushMatrix();
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(516, 0.0f);
            GlStateManager.enableBlend();
            OpenGlHelper.glBlendFunc(770, 771, 1, 0);
            Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(true);
            ShaderUtility.bindTexture(SmartStencil.framebuffer.framebufferTexture);
            StencilUtil.initStencilToWrite();
            runnable.run();
            StencilUtil.readStencilBuffer(1);
        }
    }

    public static void renderEnd() {
        if (framebuffer != null) {
            StencilUtil.uninitStencilBuffer();
            Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(false);
            GlStateManager.disableAlpha();
            GL11.glPopMatrix();
        }
    }
}
