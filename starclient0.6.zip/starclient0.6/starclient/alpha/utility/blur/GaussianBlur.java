package starclient.alpha.utility.blur;

import java.nio.FloatBuffer;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.blur.ShaderUtility;
import starclient.alpha.utility.blur.StencilUtil;

public class GaussianBlur
implements Utility {
    public static ShaderUtility blurShader = new ShaderUtility("starclient/shaders/gaussian.frag");
    public static Framebuffer framebuffer = new Framebuffer(1, 1, false);
    static Framebuffer framebuffer1 = ShaderUtility.createFrameBuffer(new Framebuffer(1, 1, false));
    private static Framebuffer inputFramebuffer = new Framebuffer(GaussianBlur.mc.displayWidth, GaussianBlur.mc.displayHeight, true);
    private static Framebuffer outputFramebuffer = new Framebuffer(GaussianBlur.mc.displayWidth, GaussianBlur.mc.displayHeight, true);

    public static void setupUniforms(float f, float f2, float f3) {
        blurShader.setUniformi("textureIn", 0);
        blurShader.setUniformf("texelSize", 1.0f / (float)GaussianBlur.mc.displayWidth, 1.0f / (float)GaussianBlur.mc.displayHeight);
        blurShader.setUniformf("direction", f, f2);
        blurShader.setUniformf("radius", f3);
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)256);
        int n = 0;
        while ((float)n <= f3) {
            floatBuffer.put(ShaderUtility.calculateGaussianValue(n, f3 / 2.0f));
            ++n;
        }
        floatBuffer.rewind();
        GL20.glUniform1((int)blurShader.getUniform("weights"), (FloatBuffer)floatBuffer);
    }

    private static void drawBlur(float f, Runnable runnable) {
        StencilUtil.initStencilToWrite();
        runnable.run();
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(f);
        StencilUtil.uninitStencilBuffer();
    }

    public static void update(Framebuffer framebuffer) {
        if (framebuffer.framebufferWidth != GaussianBlur.mc.displayWidth || framebuffer.framebufferHeight != GaussianBlur.mc.displayHeight) {
            framebuffer.createBindFramebuffer(GaussianBlur.mc.displayWidth, GaussianBlur.mc.displayHeight);
        }
    }

    public static void renderBlur(float f, List<Runnable> list) {
        GaussianBlur.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        list.forEach(Runnable::run);
        framebuffer1.unbindFramebuffer();
        mc.getFramebuffer().bindFramebuffer(true);
        if (framebuffer1 != null) {
            GL11.glPushMatrix();
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(516, 0.0f);
            GlStateManager.enableBlend();
            OpenGlHelper.glBlendFunc(770, 771, 1, 0);
            mc.getFramebuffer().bindFramebuffer(true);
            ShaderUtility.bindTexture(GaussianBlur.framebuffer1.framebufferTexture);
            GaussianBlur.drawBlur(f, ShaderUtility::drawQuads);
            mc.getFramebuffer().bindFramebuffer(false);
            GlStateManager.disableAlpha();
            GL11.glPopMatrix();
        }
    }

    public static void renderBlur(float f, Runnable runnable) {
        GaussianBlur.update(framebuffer1);
        framebuffer1.framebufferClear();
        framebuffer1.bindFramebuffer(true);
        runnable.run();
        framebuffer1.unbindFramebuffer();
        mc.getFramebuffer().bindFramebuffer(true);
        if (framebuffer1 != null) {
            GL11.glPushMatrix();
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(516, 0.0f);
            GlStateManager.enableBlend();
            OpenGlHelper.glBlendFunc(770, 771, 1, 0);
            mc.getFramebuffer().bindFramebuffer(true);
            ShaderUtility.bindTexture(GaussianBlur.framebuffer1.framebufferTexture);
            GaussianBlur.drawBlur(f, ShaderUtility::drawQuads);
            mc.getFramebuffer().bindFramebuffer(false);
            GlStateManager.disableAlpha();
            GL11.glPopMatrix();
        }
    }

    public static void renderBlur(float f) {
        mc.getFramebuffer().bindFramebuffer(true);
        GlStateManager.enableBlend();
        GL11.glDisable((int)2929);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GaussianBlur.update(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        blurShader.init();
        GaussianBlur.setupUniforms(1.0f, 0.0f, f);
        ShaderUtility.bindTexture(GaussianBlur.mc.getFramebuffer().framebufferTexture);
        ShaderUtility.drawQuads();
        framebuffer.unbindFramebuffer();
        blurShader.unload();
        mc.getFramebuffer().bindFramebuffer(true);
        blurShader.init();
        GaussianBlur.setupUniforms(0.0f, 1.0f, f);
        ShaderUtility.bindTexture(GaussianBlur.framebuffer.framebufferTexture);
        ShaderUtility.drawQuads();
        blurShader.unload();
        GlStateManager.resetColor();
        GlStateManager.bindTexture(0);
        GL11.glEnable((int)2929);
    }
}
