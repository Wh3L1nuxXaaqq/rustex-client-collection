package starclient.alpha.utility.render.animation.impl;

import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;

public class EaseInOutQuad
extends Animation {
    public EaseInOutQuad(int n, float f) {
        super(n, f);
    }

    public EaseInOutQuad(int n, float f, Direction direction) {
        super(n, f, direction);
    }

    @Override
    protected float getEquation(float f) {
        double d = f / (float)this.duration;
        return (float)(d < 0.5 ? 2.0 * Math.pow(d, 2.0) : 1.0 - Math.pow(-2.0 * d + 2.0, 2.0) / 2.0);
    }
}
