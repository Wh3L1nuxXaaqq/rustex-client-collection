package starclient.alpha.utility.render.animation.impl;

import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;

public class DecelerateAnimation
extends Animation {
    public DecelerateAnimation(int n, float f) {
        super(n, f);
    }

    public DecelerateAnimation(int n, float f, Direction direction) {
        super(n, f, direction);
    }

    @Override
    protected float getEquation(float f) {
        float f2 = f / (float)this.duration;
        return 1.0f - (f2 - 1.0f) * (f2 - 1.0f);
    }
}
