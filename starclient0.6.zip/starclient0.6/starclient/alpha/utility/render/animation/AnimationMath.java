package starclient.alpha.utility.render.animation;

import net.minecraft.client.Minecraft;
import starclient.alpha.utility.math.MathUtility;

public class AnimationMath {
    public static double deltaTime() {
        return Minecraft.getDebugFPS() > 0 ? 1.0 / (double)Minecraft.getDebugFPS() : 1.0;
    }

    public static float fast(float f, float f2, float f3) {
        return (1.0f - MathUtility.clamp((float)(AnimationMath.deltaTime() * (double)f3), 0.0f, 1.0f)) * f + MathUtility.clamp((float)(AnimationMath.deltaTime() * (double)f3), 0.0f, 1.0f) * f2;
    }
}
