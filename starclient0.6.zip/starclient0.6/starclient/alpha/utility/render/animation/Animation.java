package starclient.alpha.utility.render.animation;

import starclient.alpha.utility.misc.TimerHelper;
import starclient.alpha.utility.render.animation.Direction;

public abstract class Animation {
    public TimerHelper timerUtil = new TimerHelper();
    protected int duration;
    protected float endPoint;
    protected Direction direction;

    public Animation(int n, float f) {
        this.duration = n;
        this.endPoint = f;
        this.direction = Direction.FORWARDS;
    }

    public Animation(int n, float f, Direction direction) {
        this.duration = n;
        this.endPoint = f;
        this.direction = direction;
    }

    public boolean finished(Direction direction) {
        return this.isDone() && this.direction.equals((Object)direction);
    }

    public float getLinearOutput() {
        return 1.0f - (float)this.timerUtil.getTimePassed() / (float)this.duration * this.endPoint;
    }

    public float getEndPoint() {
        return this.endPoint;
    }

    public void setEndPoint(float f) {
        this.endPoint = f;
    }

    public void reset() {
        this.timerUtil.reset();
    }

    public boolean isDone() {
        return this.timerUtil.hasReached(this.duration);
    }

    public void changeDirection() {
        this.setDirection(this.direction.opposite());
    }

    public Direction getDirection() {
        return this.direction;
    }

    public void setDirection(Direction direction) {
        if (this.direction != direction) {
            this.direction = direction;
            this.timerUtil.setTime(System.currentTimeMillis() - ((long)this.duration - Math.min((long)this.duration, this.timerUtil.getTimePassed())));
        }
    }

    public void setDuration(int n) {
        this.duration = n;
    }

    protected boolean correctOutput() {
        return false;
    }

    public long getTimePassed() {
        return this.timerUtil.getTimePassed();
    }

    public float getOutput() {
        if (this.direction == Direction.FORWARDS) {
            return this.isDone() ? this.endPoint : this.getEquation(this.timerUtil.getTimePassed()) * this.endPoint;
        }
        if (this.isDone()) {
            return 0.0f;
        }
        if (this.correctOutput()) {
            float f = Math.min((long)this.duration, Math.max(0L, (long)this.duration - this.timerUtil.getTimePassed()));
            return this.getEquation(f) * this.endPoint;
        }
        return (1.0f - this.getEquation(this.timerUtil.getTimePassed())) * this.endPoint;
    }

    protected abstract float getEquation(float var1);
}
