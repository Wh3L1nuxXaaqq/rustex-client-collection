package starclient.alpha.utility.render;

import org.lwjgl.opengl.GL11;

public class AntiAliasingUtility {
    public static void hook(boolean bl, boolean bl2, boolean bl3) {
        if (bl) {
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
        }
        if (bl2) {
            GL11.glEnable((int)2881);
            GL11.glHint((int)3155, (int)4354);
        }
        if (bl3) {
            GL11.glEnable((int)2832);
            GL11.glHint((int)3153, (int)4354);
        }
    }

    public static void unhook(boolean bl, boolean bl2, boolean bl3) {
        if (bl) {
            GL11.glHint((int)3154, (int)4352);
            GL11.glDisable((int)2848);
        }
        if (bl2) {
            GL11.glHint((int)3155, (int)4352);
            GL11.glDisable((int)2881);
        }
        if (bl3) {
            GL11.glHint((int)3153, (int)4352);
            GL11.glDisable((int)2832);
        }
    }
}
