package starclient.alpha.utility.render;

import com.google.common.collect.Lists;
import java.awt.Rectangle;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;

public final class SmartScissor {
    private static State state = new State();
    private static List<State> stateStack = Lists.newArrayList();

    public static void push() {
        stateStack.add(state.clone());
        GL11.glPushAttrib((int)524288);
    }

    public static void pop() {
        state = stateStack.remove(stateStack.size() - 1);
        GL11.glPopAttrib();
    }

    public static void unset() {
        GL11.glDisable((int)3089);
        SmartScissor.state.enabled = false;
    }

    public static void setFromComponentCoordinates(int n, int n2, int n3, int n4) {
        new ScaledResolution(Minecraft.getMinecraft());
        int n5 = 2;
        int n6 = n * n5;
        int n7 = n2 * n5;
        int n8 = n3 * n5;
        int n9 = n4 * n5;
        n7 = Minecraft.getMinecraft().displayHeight - n7 - n9;
        SmartScissor.set(n6, n7, n8, n9);
    }

    public static void setFromComponentCoordinates(double d, double d2, double d3, double d4) {
        new ScaledResolution(Minecraft.getMinecraft());
        int n = 2;
        int n2 = (int)(d * (double)n);
        int n3 = (int)(d2 * (double)n);
        int n4 = (int)(d3 * (double)n);
        int n5 = (int)(d4 * (double)n);
        n3 = Minecraft.getMinecraft().displayHeight - n3 - n5;
        SmartScissor.set(n2, n3, n4, n5);
    }

    public static void set(int n, int n2, int n3, int n4) {
        Rectangle rectangle = new Rectangle(0, 0, Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        Rectangle rectangle2 = SmartScissor.state.enabled ? new Rectangle(SmartScissor.state.x, SmartScissor.state.y, SmartScissor.state.width, SmartScissor.state.height) : rectangle;
        Rectangle rectangle3 = new Rectangle(n + SmartScissor.state.transX, n2 + SmartScissor.state.transY, n3, n4);
        Rectangle rectangle4 = rectangle2.intersection(rectangle3);
        rectangle4 = rectangle4.intersection(rectangle);
        if (rectangle4.width < 0) {
            rectangle4.width = 0;
        }
        if (rectangle4.height < 0) {
            rectangle4.height = 0;
        }
        SmartScissor.state.enabled = true;
        SmartScissor.state.x = rectangle4.x;
        SmartScissor.state.y = rectangle4.y;
        SmartScissor.state.width = rectangle4.width;
        SmartScissor.state.height = rectangle4.height;
        GL11.glEnable((int)3089);
        GL11.glScissor((int)rectangle4.x, (int)rectangle4.y, (int)rectangle4.width, (int)rectangle4.height);
    }

    public static void translate(int n, int n2) {
        SmartScissor.state.transX = n;
        SmartScissor.state.transY = n2;
    }

    public static void translateFromComponentCoordinates(int n, int n2) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        int n3 = scaledResolution.getScaledHeight();
        int n4 = scaledResolution.getScaleFactor();
        int n5 = n * n4;
        int n6 = n2 * n4;
        n6 = n3 * n4 - n6;
        SmartScissor.translate(n5, n6);
    }

    private static class State
    implements Cloneable {
        public boolean enabled;
        public int transX;
        public int transY;
        public int x;
        public int y;
        public int width;
        public int height;

        private State() {
        }

        public State clone() {
            try {
                return (State)super.clone();
            }
            catch (CloneNotSupportedException cloneNotSupportedException) {
                throw new AssertionError((Object)cloneNotSupportedException);
            }
        }

        State(Object object) {
            this();
        }
    }
}
