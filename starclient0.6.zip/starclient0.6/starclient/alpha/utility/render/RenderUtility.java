package starclient.alpha.utility.render;

import com.jhlabs.image.GaussianFilter;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.impl.util.Optimizer;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.AntiAliasingUtility;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.StencilUtility;
import starclient.alpha.utility.render.blur.GaussianBlur;
import starclient.alpha.utility.render.shader.Shader;

public class RenderUtility
implements Utility {
    private static final Tessellator TESSELLATOR = Tessellator.getInstance();
    private static final BufferBuilder BUILDER;
    private static final Shader ROUNDED_GRADIENT;
    private static final Shader ROUNDED;
    private static final Shader GRADIENT_MASK;
    private static final Shader ROUNDED_TEXTURE;
    private static final HashMap<Integer, Integer> SHADOW_CACHE;
    public static Frustum FRUSTUM;
    private static int PROFILE_ID;
    private static ICamera camera;
    private static final HashMap<Integer, Integer> shadowCache;

    public static Vec3d vectorTo2D(int n, double d, double d2, double d3) {
        float f = (float)d;
        float f2 = (float)d2;
        float f3 = (float)d3;
        IntBuffer intBuffer = GLAllocation.createDirectIntBuffer(16);
        FloatBuffer floatBuffer = GLAllocation.createDirectFloatBuffer(16);
        FloatBuffer floatBuffer2 = GLAllocation.createDirectFloatBuffer(16);
        FloatBuffer floatBuffer3 = GLAllocation.createDirectFloatBuffer(4);
        GL11.glGetFloat((int)2982, (FloatBuffer)floatBuffer);
        GL11.glGetFloat((int)2983, (FloatBuffer)floatBuffer2);
        GL11.glGetInteger((int)2978, (IntBuffer)intBuffer);
        if (GLU.gluProject((float)f, (float)f2, (float)f3, (FloatBuffer)floatBuffer, (FloatBuffer)floatBuffer2, (IntBuffer)intBuffer, (FloatBuffer)floatBuffer3)) {
            return new Vec3d(floatBuffer3.get(0) / (float)n, ((float)Display.getHeight() - floatBuffer3.get(1)) / (float)n, floatBuffer3.get(2));
        }
        return null;
    }

    public static void drawFov(float f, float f2, float f3, int n, int n2) {
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glLineWidth((float)2.5f);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n2; ++i) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)(f3 * 2.0f)), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)(f3 * 2.0f)));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void draw2lines(float f, float f2, int n, float f3) {
        int n2;
        int n3;
        int n4;
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        float f8 = (float)((int)f3 >> 24 & 0xFF) / 255.0f;
        float f9 = (float)((int)f3 >> 16 & 0xFF) / 255.0f;
        float f10 = (float)((int)f3 >> 8 & 0xFF) / 255.0f;
        float f11 = (float)((int)f3 & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glLineWidth((float)2.5f);
        GL11.glBegin((int)3);
        for (int i = -140; i <= -60; ++i) {
            n4 = 0;
            n3 = -1;
        }
        GL11.glEnd();
        GL11.glBegin((int)3);
        for (n4 = 100; n4 <= 180; ++n4) {
            n3 = 4;
            n2 = 2;
        }
        GL11.glEnd();
        GL11.glBegin((int)3);
        for (n3 = -20; n3 <= 60; ++n3) {
            n2 = 3;
            boolean bl4 = false;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawRobotgui(float f, float f2, int n, int n2, float f3) {
        int n3;
        int n4;
        int n5;
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        float f8 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f11 = (float)(n2 & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glLineWidth((float)2.5f);
        GL11.glBegin((int)3);
        for (int i = -140; i <= -60; ++i) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            GL11.glVertex2d((double)((double)f - 0.5 + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 - 10.0 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
            n5 = 0;
            n4 = -1;
        }
        GL11.glEnd();
        GL11.glBegin((int)3);
        for (n5 = 100; n5 <= 180; ++n5) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)n5 * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)n5 * Math.PI / 180.0) * (double)f3));
            GL11.glVertex2d((double)((double)f - 0.5 + Math.sin((double)n5 * Math.PI / 180.0) * (double)f3), (double)((double)f2 - 10.0 + Math.cos((double)n5 * Math.PI / 180.0) * (double)f3));
            n4 = 4;
            n3 = 2;
        }
        GL11.glEnd();
        GL11.glBegin((int)3);
        for (n4 = -20; n4 <= 60; ++n4) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)n4 * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)n4 * Math.PI / 180.0) * (double)f3));
            GL11.glVertex2d((double)((double)f - 0.5 + Math.sin((double)n4 * Math.PI / 180.0) * (double)f3), (double)((double)f2 - 10.0 + Math.cos((double)n4 * Math.PI / 180.0) * (double)f3));
            n3 = 3;
            boolean bl4 = false;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawProfile(float f, float f2, float f3, float f4) {
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        RenderUtility.drawRoundedRect(f, f2, f3, f4, f3 - 1.0f, bl ? new Color(57, 57, 57).getRGB() : new Color(100, 100, 100).getRGB());
    }

    public static Framebuffer createFrameBuffer(Framebuffer framebuffer) {
        if (framebuffer == null || framebuffer.framebufferWidth != RenderUtility.mc.displayWidth || framebuffer.framebufferHeight != RenderUtility.mc.displayHeight) {
            if (framebuffer != null) {
                framebuffer.deleteFramebuffer();
            }
            return new Framebuffer(RenderUtility.mc.displayWidth, RenderUtility.mc.displayHeight, true);
        }
        return framebuffer;
    }

    public static void bindTexture(int n) {
        GL11.glBindTexture((int)3553, (int)n);
    }

    public static void resetColor() {
        RenderUtility.color(1.0, 1.0, 1.0, 1.0);
    }

    public static final void color(double d, double d2, double d3, double d4) {
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)d4);
    }

    public static void setColor(Color color) {
        RenderUtility.color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static void blockEspFrame(BlockPos blockPos, double d, double d2, double d3) {
        double d4 = blockPos.getX();
        Minecraft.getMinecraft().getRenderManager();
        double d5 = d4 - Minecraft.getMinecraft().getRenderManager().viewerPosX;
        double d6 = blockPos.getY();
        Minecraft.getMinecraft().getRenderManager();
        double d7 = d6 - Minecraft.getMinecraft().getRenderManager().viewerPosY;
        double d8 = blockPos.getZ();
        Minecraft.getMinecraft().getRenderManager();
        double d9 = d8 - Minecraft.getMinecraft().getRenderManager().viewerPosZ;
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)d, (double)d2, (double)d3, (double)1.0);
        RenderUtility.drawSelectionBoundingBox(new AxisAlignedBB(d5, d7, d9, d5 + 1.0, d7 + 1.0, d9 + 1.0));
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawRect(float f, float f2, float f3, float f4, int n) {
        RenderUtility.drawGradientRect(f, f2, f3, f4, n, n, n, n);
    }

    public static void drawTriangle(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = bl = !GL11.glIsEnabled((int)3042);
        if (bl) {
            GL11.glEnable((int)3042);
        }
        int n4 = 255;
        int n5 = Math.max(n - 40, 0);
        int n6 = Math.max(n2 - 40, 0);
        int n7 = Math.max(n3 - 40, 0);
        float f = 6.0f;
        float f2 = 12.0f;
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2881);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)9);
        GL11.glColor4f((float)((float)n / 255.0f), (float)((float)n2 / 255.0f), (float)((float)n3 / 255.0f), (float)((float)n4 / 255.0f));
        GL11.glVertex2d((double)0.0, (double)(0.0f - f2));
        GL11.glVertex2d((double)(0.0f - f), (double)0.0);
        GL11.glVertex2d((double)0.0, (double)-3.0);
        GL11.glEnd();
        GL11.glBegin((int)9);
        GL11.glColor4f((float)((float)n5 / 255.0f), (float)((float)n6 / 255.0f), (float)((float)n7 / 255.0f), (float)((float)n4 / 255.0f));
        GL11.glVertex2d((double)0.0, (double)(0.0f - f2));
        GL11.glVertex2d((double)0.0, (double)-3.0);
        GL11.glVertex2d((double)(0.0f + f), (double)0.0);
        GL11.glEnd();
        GL11.glShadeModel((int)7424);
        GL11.glDisable((int)2881);
        GL11.glEnable((int)3553);
        if (bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawTriangle(double d, double d2, double d3, double d4, double d5) {
        boolean bl;
        boolean bl2 = bl = !GL11.glIsEnabled((int)3042);
        if (bl) {
            GL11.glEnable((int)3042);
        }
        int n = 255;
        int n2 = 255;
        int n3 = 255;
        int n4 = 255;
        int n5 = Math.max(n2 - 40, 0);
        int n6 = Math.max(n3 - 40, 0);
        int n7 = Math.max(n4 - 40, 0);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2881);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)9);
        GL11.glColor4f((float)((float)n2 / 255.0f), (float)((float)n3 / 255.0f), (float)((float)n4 / 255.0f), (float)((float)n / 255.0f));
        GL11.glVertex2d((double)d, (double)(d2 - d4));
        GL11.glVertex2d((double)(d - d3), (double)d2);
        GL11.glVertex2d((double)d, (double)(d2 - 3.0));
        GL11.glEnd();
        GL11.glBegin((int)9);
        GL11.glColor4f((float)((float)n5 / 255.0f), (float)((float)n6 / 255.0f), (float)((float)n7 / 255.0f), (float)((float)n / 255.0f));
        GL11.glVertex2d((double)d, (double)(d2 - d4));
        GL11.glVertex2d((double)d, (double)(d2 - 3.0));
        GL11.glVertex2d((double)(d + d3), (double)d2);
        GL11.glEnd();
        GL11.glShadeModel((int)7424);
        GL11.glDisable((int)2881);
        GL11.glEnable((int)3553);
        if (bl) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawTriangle(float f, float f2, float f3, float f4, int n) {
        GL11.glPushMatrix();
        GL11.glTranslated((double)f, (double)f2, (double)0.0);
        GL11.glRotatef((float)(180.0f + f3), (float)0.0f, (float)0.0f, (float)1.0f);
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2881);
        GL11.glHint((int)3155, (int)4354);
        GL11.glBlendFunc((int)770, (int)771);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(4, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(0.0, 3.1 * (double)f4, 0.0).endVertex();
        bufferBuilder.pos(2.0f * f4, -1.0f * f4, 0.0).endVertex();
        bufferBuilder.pos(-2.3 * (double)f4, -1.0f * f4, 0.0).endVertex();
        tessellator.draw();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2881);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GL11.glRotatef((float)(-180.0f - f3), (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)(-f), (double)(-f2), (double)0.0);
        GlStateManager.resetColor();
        GL11.glPopMatrix();
    }

    public static void drawTriangle(float f, float f2, float f3, int n) {
        GL11.glPushMatrix();
        GL11.glTranslated((double)f, (double)f2, (double)0.0);
        GL11.glRotatef((float)(180.0f + f3), (float)0.0f, (float)0.0f, (float)1.0f);
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2881);
        GL11.glHint((int)3155, (int)4354);
        GL11.glBlendFunc((int)770, (int)771);
        float f8 = 0.9f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(4, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(0.0, 3.1 * (double)f8, 0.0).endVertex();
        bufferBuilder.pos(2.0f * f8, -1.0f * f8, 0.0).endVertex();
        bufferBuilder.pos(-2.3 * (double)f8, -1.0f * f8, 0.0).endVertex();
        tessellator.draw();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2881);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GL11.glRotatef((float)(-180.0f - f3), (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)(-f), (double)(-f2), (double)0.0);
        GlStateManager.resetColor();
        GL11.glPopMatrix();
    }

    public static void drawCircle(float f, float f2, float f3, int n) {
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        boolean bl = GL11.glIsEnabled((int)3042);
        boolean bl2 = GL11.glIsEnabled((int)2848);
        boolean bl3 = GL11.glIsEnabled((int)3553);
        if (!bl) {
            GL11.glEnable((int)3042);
        }
        if (!bl2) {
            GL11.glEnable((int)2848);
        }
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glBegin((int)9);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)((double)f + Math.sin((double)i * Math.PI / 180.0) * (double)f3), (double)((double)f2 + Math.cos((double)i * Math.PI / 180.0) * (double)f3));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)2848);
        }
        if (!bl) {
            GL11.glDisable((int)3042);
        }
        GlStateManager.resetColor();
    }

    public static void drawBoxESP(AxisAlignedBB axisAlignedBB, Color color, float f, boolean bl, boolean bl2, int n, int n2) {
        AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(axisAlignedBB.minX - RenderUtility.mc.getRenderManager().viewerPosX, axisAlignedBB.minY - RenderUtility.mc.getRenderManager().viewerPosY, axisAlignedBB.minZ - RenderUtility.mc.getRenderManager().viewerPosZ, axisAlignedBB.maxX - RenderUtility.mc.getRenderManager().viewerPosX, axisAlignedBB.maxY - RenderUtility.mc.getRenderManager().viewerPosY, axisAlignedBB.maxZ - RenderUtility.mc.getRenderManager().viewerPosZ);
        camera.setPosition(Objects.requireNonNull(RenderUtility.mc.getRenderViewEntity()).posX, RenderUtility.mc.getRenderViewEntity().posY, RenderUtility.mc.getRenderViewEntity().posZ);
        if (camera.isBoundingBoxInFrustum(axisAlignedBB)) {
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLineWidth((float)f);
            if (bl2) {
                RenderGlobal.renderFilledBox(axisAlignedBB2, (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)n / 255.0f);
            }
            if (bl) {
                RenderGlobal.drawBoundingBox(axisAlignedBB2.minX, axisAlignedBB2.minY, axisAlignedBB2.minZ, axisAlignedBB2.maxX, axisAlignedBB2.maxY, axisAlignedBB2.maxZ, (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)n2 / 255.0f);
            }
            GL11.glDisable((int)2848);
            GlStateManager.depthMask(true);
            GlStateManager.enableDepth();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
        }
    }

    public static void blockEspFrame(BlockPos blockPos, float f, float f2, float f3) {
        double d = (double)blockPos.getX() - RenderUtility.mc.getRenderManager().renderPosX;
        double d2 = (double)blockPos.getY() - RenderUtility.mc.getRenderManager().renderPosY;
        double d3 = (double)blockPos.getZ() - RenderUtility.mc.getRenderManager().renderPosZ;
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GlStateManager.color(f, f2, f3, 1.0f);
        RenderUtility.drawSelectionBoundingBox(new AxisAlignedBB(d, d2, d3, d + 1.0, d2 + 1.0, d3 + 1.0));
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    public static void drawBlur(Runnable runnable, float f) {
        StencilUtility.initStencilToWrite();
        runnable.run();
        StencilUtility.readStencilBuffer(1);
        GaussianBlur.renderBlur(f);
        StencilUtility.uninitStencilBuffer();
    }

    public static void applyRound(float f, float f2, float f3, float f4, Runnable runnable) {
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.disableAlpha();
        ROUNDED_TEXTURE.useProgram();
        ROUNDED_TEXTURE.setupUniform2f("size", (f - f3) * 2.0f, (f2 - f3) * 2.0f);
        ROUNDED_TEXTURE.setupUniform1f("round", f3);
        ROUNDED_TEXTURE.setupUniform1f("alpha", f4);
        runnable.run();
        ROUNDED_TEXTURE.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawCircle3D(double d, double d2, double d3, float f, int n) {
        double[] dArray = new double[]{d - Minecraft.getMinecraft().getRenderManager().viewerPosX, d2 - Minecraft.getMinecraft().getRenderManager().viewerPosY, d3 - Minecraft.getMinecraft().getRenderManager().viewerPosZ};
        GL11.glPushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.disableTexture2D();
        GlStateManager.disableAlpha();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)4.0f);
        GL11.glPushMatrix();
        GlStateManager.translate(dArray[0], dArray[1], dArray[2]);
        GL11.glBegin((int)2);
        RenderUtility.glColor(n);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex3d((double)(Math.sin((double)i * Math.PI / 180.0) * (double)f), (double)0.0, (double)(Math.cos((double)i * Math.PI / 180.0) * (double)f));
        }
        GL11.glEnd();
        GL11.glPopMatrix();
        GlStateManager.enableAlpha();
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        RenderUtility.glColor(-1);
        GL11.glLineWidth((float)1.0f);
    }

    public static void glColor(int n) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        GlStateManager.color(f2, f3, f4, f);
    }

    public static void drawRoundedRect(float f, float f2, float f3, float f4, float f5, int n) {
        RenderUtility.drawRoundedGradientRect(f, f2, f3, f4, f5, 1.0f, n, n, n, n);
    }

    public static void drawCenteredRoundedRect(float f, float f2, float f3, float f4, float f5, int n) {
        RenderUtility.drawCenteredRoundedGradientRect(f, f2, f3, f4, f5, 1.0f, n, n, n, n);
    }

    public static void drawCenteredRoundedRect(int n, int n2, int n3, int n4, int n5, int n6) {
        RenderUtility.drawCenteredRoundedGradientRect(n, n2, n3, n4, n5, 1.0f, n6, n6, n6, n6);
    }

    public static void drawCRoundedRect(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n) {
        RenderUtility.CorneredGradient(f, f2, f3, f4, f5, f6, f7, f8, 1.0f, n, n, n, n);
    }

    public static void drawRoundCircle(float f, float f2, float f3, float f4, int n) {
        RenderUtility.drawRoundedRect(f - f3 / 2.0f, f2 - f3 / 2.0f, f3, f3, f4, n);
    }

    public static void applyGradientMask(float f, float f2, float f3, float f4, float f5, Color color, Color color2, Color color3, Color color4, Runnable runnable) {
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GRADIENT_MASK.useProgram();
        GRADIENT_MASK.setupUniform2f("location", f * 2.0f, (float)Minecraft.getMinecraft().displayHeight - f4 * 2.0f - f2 * 2.0f);
        GRADIENT_MASK.setupUniform2f("rectSize", f3 * 2.0f, f4 * 2.0f);
        GRADIENT_MASK.setupUniform1f("alpha", f5);
        GRADIENT_MASK.setupUniform3f("color1", (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f);
        GRADIENT_MASK.setupUniform3f("color2", (float)color2.getRed() / 255.0f, (float)color2.getGreen() / 255.0f, (float)color2.getBlue() / 255.0f);
        GRADIENT_MASK.setupUniform3f("color3", (float)color3.getRed() / 255.0f, (float)color3.getGreen() / 255.0f, (float)color3.getBlue() / 255.0f);
        GRADIENT_MASK.setupUniform3f("color4", (float)color4.getRed() / 255.0f, (float)color4.getGreen() / 255.0f, (float)color4.getBlue() / 255.0f);
        runnable.run();
        GRADIENT_MASK.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawRectWithOutline(float f, float f2, float f3, float f4, int n, int n2) {
        RenderUtility.drawRect(f - 0.5f, f2 - 0.5f, f3 + 1.0f, f4 + 1.0f, n2);
        RenderUtility.drawRect(f, f2, f3, f4, n);
    }

    public static void drawRectNoWH(double d, double d2, double d3, double d4, int n) {
        double d5;
        if (d < d3) {
            d5 = d;
            d = d3;
            d3 = d5;
        }
        if (d2 < d4) {
            d5 = d2;
            d2 = d4;
            d4 = d5;
        }
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(f2, f3, f4, f);
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(d, d4, 0.0).endVertex();
        bufferBuilder.pos(d3, d4, 0.0).endVertex();
        bufferBuilder.pos(d3, d2, 0.0).endVertex();
        bufferBuilder.pos(d, d2, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawLine(double d, double d2, double d3, double d4, float f, int n) {
        GL11.glPushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)f);
        ColorUtility.setColor(n);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GlStateManager.resetColor();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawLeftSideRoundedGradientRect(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", 0.0f, 0.0f, f5, f5);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", f6);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawBlockBox(BlockPos blockPos, Color color, int n) {
        double d = RenderUtility.mc.player.lastTickPosX + (RenderUtility.mc.player.posX - RenderUtility.mc.player.lastTickPosX) * (double)RenderUtility.mc.timer.field_194147_b;
        double d2 = RenderUtility.mc.player.lastTickPosY + (RenderUtility.mc.player.posY - RenderUtility.mc.player.lastTickPosY) * (double)RenderUtility.mc.timer.field_194147_b;
        double d3 = RenderUtility.mc.player.lastTickPosZ + (RenderUtility.mc.player.posZ - RenderUtility.mc.player.lastTickPosZ) * (double)RenderUtility.mc.timer.field_194147_b;
        RenderUtility.mc.entityRenderer.setupCameraTransform(mc.getRenderPartialTicks(), 2);
        GL11.glPushMatrix();
        AntiAliasingUtility.hook(true, false, false);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GlStateManager.color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)n / 255.0f);
        RenderUtility.drawSelectionBoundingBox(RenderUtility.mc.world.getBlockState(blockPos).getSelectedBoundingBox(RenderUtility.mc.world, blockPos).grow(0.002f).offset(-d, -d2, -d3));
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        AntiAliasingUtility.unhook(true, false, false);
        GL11.glPopMatrix();
    }

    public static void drawSelectionBoundingBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(3, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        bufferBuilder.begin(3, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        bufferBuilder.begin(1, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        bufferBuilder.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        tessellator.draw();
    }

    public static void drawLeftSideRoundedRect(float f, float f2, float f3, float f4, float f5, int n) {
        RenderUtility.drawLeftSideRoundedGradientRect(f, f2, f3, f4, f5, 1.0f, n, n, n, n);
    }

    public static void drawHeader(float f, float f2, float f3, float f4) {
        RenderUtility.drawGradientRect(f + f3 / 2.0f, f2, f3 / 2.0f, f4, new Color(0xB6B6B6).getRGB(), 3, 3, new Color(0xB6B6B6).getRGB());
        RenderUtility.drawGradientRect(f, f2, f3 / 2.0f, f4, 3, new Color(0xB6B6B6).getRGB(), new Color(0xB6B6B6).getRGB(), 3);
    }

    public static void drawRoundedRect(float f, float f2, float f3, float f4, float f5, float f6, float f7, int n, int n2) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED.useProgram();
        ROUNDED.setupUniform2f("size", (f3 - f5) * 2.0f, (f4 - f5) * 2.0f);
        ROUNDED.setupUniform1f("round", f5);
        ROUNDED.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED.setupUniform2f("swap", f6, f7);
        ROUNDED.setupUniform4f("firstColor", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED.setupUniform4f("secondColor", fArray2[0], fArray2[1], fArray2[2], fArray[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawCenteredRoundedRect(float f, float f2, float f3, float f4, float f5, float f6, float f7, int n, int n2) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED.useProgram();
        ROUNDED.setupUniform2f("size", (f3 - f5) * 2.0f, (f4 - f5) * 2.0f);
        ROUNDED.setupUniform1f("round", f5);
        ROUNDED.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED.setupUniform2f("swap", f6, f7);
        ROUNDED.setupUniform4f("firstColor", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED.setupUniform4f("secondColor", fArray2[0], fArray2[1], fArray2[2], fArray[3]);
        RenderUtility.allocTextureRectangle(f - f3 / 2.0f, f2, f3, f4);
        ROUNDED.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawVGradientRect(float f, float f2, float f3, float f4, int n, int n2) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float)(n2 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glVertex2d((double)f, (double)f2);
        GL11.glVertex2d((double)f3, (double)f2);
        GL11.glColor4f((float)f10, (float)f11, (float)f12, (float)f9);
        GL11.glVertex2d((double)f3, (double)f4);
        GL11.glVertex2d((double)f, (double)f4);
        GL11.glEnd();
        GL11.glPopMatrix();
        GlStateManager.resetColor();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    public static void drawGradientRect(float f, float f2, float f3, float f4, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR);
        BUILDER.pos(f, f4 + f2, 0.0).color(fArray[0], fArray[1], fArray[2], fArray[3]).endVertex();
        BUILDER.pos(f3 + f, f4 + f2, 0.0).color(fArray2[0], fArray2[1], fArray2[2], fArray2[3]).endVertex();
        BUILDER.pos(f3 + f, f2, 0.0).color(fArray3[0], fArray3[1], fArray3[2], fArray3[3]).endVertex();
        BUILDER.pos(f, f2, 0.0).color(fArray4[0], fArray4[1], fArray4[2], fArray4[3]).endVertex();
        TESSELLATOR.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRoundedGradientRect(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f5, f5, f5);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", f6);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawCenteredRoundedGradientRect(float f, float f2, float f3, float f4, float f5, float f6, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f5, f5, f5);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", f6);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f - f3 / 2.0f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawItemStack(ItemStack itemStack, int n, int n2) {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.enableDepth();
        RenderHelper.enableGUIStandardItemLighting();
        mc.getRenderItem().renderItemAndEffectIntoGUI(itemStack, n, n2);
        mc.getRenderItem().renderItemOverlays(RenderUtility.mc.fontRendererObj, itemStack, n, n2);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.disableDepth();
    }

    public static void CorneredGradient(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f6, f7, f8);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", f9);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void CorneredGradient(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n, int n2, int n3, int n4) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n2);
        float[] fArray3 = ColorUtility.getRGBAf(n3);
        float[] fArray4 = ColorUtility.getRGBAf(n4);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f6, f7, f8);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", 1.0f);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void Cornered(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int n) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n);
        float[] fArray3 = ColorUtility.getRGBAf(n);
        float[] fArray4 = ColorUtility.getRGBAf(n);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f6, f7, f8);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", f9);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void Cornered(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n) {
        float[] fArray = ColorUtility.getRGBAf(n);
        float[] fArray2 = ColorUtility.getRGBAf(n);
        float[] fArray3 = ColorUtility.getRGBAf(n);
        float[] fArray4 = ColorUtility.getRGBAf(n);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        ROUNDED_GRADIENT.useProgram();
        ROUNDED_GRADIENT.setupUniform2f("size", f3 * 2.0f, f4 * 2.0f);
        ROUNDED_GRADIENT.setupUniform4f("round", f5, f6, f7, f8);
        ROUNDED_GRADIENT.setupUniform2f("smoothness", 0.0f, 1.5f);
        ROUNDED_GRADIENT.setupUniform1f("value", 1.0f);
        ROUNDED_GRADIENT.setupUniform4f("color1", fArray[0], fArray[1], fArray[2], fArray[3]);
        ROUNDED_GRADIENT.setupUniform4f("color2", fArray2[0], fArray2[1], fArray2[2], fArray2[3]);
        ROUNDED_GRADIENT.setupUniform4f("color3", fArray3[0], fArray3[1], fArray3[2], fArray3[3]);
        ROUNDED_GRADIENT.setupUniform4f("color4", fArray4[0], fArray4[1], fArray4[2], fArray4[3]);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        ROUNDED_GRADIENT.unloadProgram();
        GlStateManager.disableBlend();
    }

    public static void drawGlow(float f, float f2, float f3, float f4, int n, int n2) {
        if (Optimizer.a) {
            return;
        }
        BufferedImage bufferedImage = null;
        GaussianFilter gaussianFilter = null;
        GL11.glPushMatrix();
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n3 = String.valueOf((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) + f3 + (float)(1000000000 * n) + (float)n).hashCode();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        int n4 = -1;
        if (shadowCache.containsKey(n3)) {
            n4 = shadowCache.get(n3);
            GlStateManager.bindTexture(n4);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.white);
            graphics.fillRect(n, n, (int)(f3 - (float)(n * 2)), (int)(f4 - (float)(n * 2)));
            graphics.dispose();
            gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            n4 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            shadowCache.put(n3, n4);
        }
        ColorUtility.setColor(n2);
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void drawGlow(float f, float f2, float f3, float f4, int n, Color color) {
        if (Optimizer.a) {
            return;
        }
        BufferedImage bufferedImage = null;
        GaussianFilter gaussianFilter = null;
        GL11.glPushMatrix();
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n2 = String.valueOf((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) + f3 + (float)(1000000000 * n) + (float)n).hashCode();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        int n3 = -1;
        if (shadowCache.containsKey(n2)) {
            n3 = shadowCache.get(n2);
            GlStateManager.bindTexture(n3);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.white);
            graphics.fillRect(n, n, (int)(f3 - (float)(n * 2)), (int)(f4 - (float)(n * 2)));
            graphics.dispose();
            gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            n3 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            shadowCache.put(n2, n3);
        }
        ColorUtility.setColor(color);
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void drawFixedGlow(float f, float f2, float f3, float f4, int n, int n2) {
        if (Optimizer.a) {
            return;
        }
        BufferedImage bufferedImage = null;
        GaussianFilter gaussianFilter = null;
        GL11.glPushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n3 = String.valueOf((double)((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) + f3) + Math.sin((float)n / f3 * f4) * (double)n + (double)n).hashCode();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        int n4 = -1;
        if (shadowCache.containsKey(n3)) {
            n4 = shadowCache.get(n3);
            GlStateManager.bindTexture(n4);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.white);
            graphics.fillRect(n, n, (int)f3 - n * 2, (int)f4 - n * 2);
            graphics.dispose();
            gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            n4 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            shadowCache.put(n3, n4);
        }
        GL11.glBegin((int)7);
        ColorUtility.setColor(n2);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        ColorUtility.setColor(n2);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        ColorUtility.setColor(n2);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        ColorUtility.setColor(n2);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void drawGradientGlow(float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, int n5) {
        if (Optimizer.a) {
            return;
        }
        BufferedImage bufferedImage = null;
        GaussianFilter gaussianFilter = null;
        GL11.glPushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n6 = String.valueOf((double)((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) + f3) + Math.sin((float)n / f3 * f4) * (double)n + (double)n).hashCode();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        int n7 = -1;
        if (shadowCache.containsKey(n6)) {
            n7 = shadowCache.get(n6);
            GlStateManager.bindTexture(n7);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.white);
            graphics.fillRect(n, n, (int)f3 - n * 2, (int)f4 - n * 2);
            graphics.dispose();
            gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            n7 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            shadowCache.put(n6, n7);
        }
        GL11.glBegin((int)7);
        ColorUtility.setColor(n2);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        ColorUtility.setColor(n3);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        ColorUtility.setColor(n5);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        ColorUtility.setColor(n4);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void drawGradientGlow(float f, float f2, float f3, float f4, int n, Color color, Color color2) {
        if (Optimizer.a) {
            return;
        }
        BufferedImage bufferedImage = null;
        GaussianFilter gaussianFilter = null;
        GL11.glPushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n2 = (int)((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) * (float)n);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        if (SHADOW_CACHE.containsKey(n2)) {
            int n3 = SHADOW_CACHE.get(n2);
            GlStateManager.bindTexture(n3);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.white);
            graphics.fillRect(n, n, (int)f3 - n * 2, (int)f4 - n * 2);
            graphics.dispose();
            gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            int n4 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            SHADOW_CACHE.put(n2, n4);
        }
        GlStateManager.resetColor();
        GL11.glBegin((int)7);
        ColorUtility.setColor(color);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        ColorUtility.setColor(color2);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void drawGradientGlow(float f, float f2, float f3, float f4, int n, Color color, Color color2, Color color3, Color color4) {
        if (Optimizer.a) {
            return;
        }
        GL11.glPushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        GlStateManager.alphaFunc(516, 0.01f);
        float f5 = (f -= (float)n) - 0.25f;
        float f6 = (f2 -= (float)n) + 0.25f;
        int n2 = (int)((f3 += (float)(n * 2)) * (f4 += (float)(n * 2)) + f3 + (float)(color.hashCode() * n) + (float)n);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3008);
        GlStateManager.enableBlend();
        if (SHADOW_CACHE.containsKey(n2)) {
            int n3 = SHADOW_CACHE.get(n2);
            GlStateManager.bindTexture(n3);
        } else {
            if (f3 <= 0.0f) {
                f3 = 1.0f;
            }
            if (f4 <= 0.0f) {
                f4 = 1.0f;
            }
            BufferedImage bufferedImage = new BufferedImage((int)f3, (int)f4, 3);
            Graphics graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.WHITE);
            graphics.fillRect(n, n, (int)(f3 - (float)(n * 2)), (int)(f4 - (float)(n * 2)));
            graphics.dispose();
            GaussianFilter gaussianFilter = new GaussianFilter(n);
            BufferedImage bufferedImage2 = gaussianFilter.filter(bufferedImage, null);
            int n4 = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage2, true, false);
            SHADOW_CACHE.put(n2, n4);
        }
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glBegin((int)7);
        ColorUtility.setColor(color);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)f5, (float)f6);
        ColorUtility.setColor(color2);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)f5, (float)(f6 + f4));
        ColorUtility.setColor(color3);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)(f6 + f4));
        ColorUtility.setColor(color4);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)(f5 + f3), (float)f6);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
        GL11.glEnable((int)2884);
        GL11.glPopMatrix();
    }

    public static void scaleStart(float f, float f2, float f3) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)f, (float)f2, (float)0.0f);
        GL11.glScalef((float)f3, (float)f3, (float)1.0f);
        GL11.glTranslatef((float)(-f), (float)(-f2), (float)0.0f);
    }

    public static void scaleEnd() {
        GL11.glPopMatrix();
    }

    public static void drawImage(ResourceLocation resourceLocation, float f, float f2, float f3, float f4) {
        mc.getTextureManager().bindTexture(resourceLocation);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        RenderUtility.allocTextureRectangle(f, f2, f3, f4);
        GlStateManager.bindTexture(0);
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4, int n5) {
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        RenderUtility.glColor(n5);
        Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation);
        Gui.drawModalRectWithCustomSizedTexture(n, n2, 0.0f, 0.0f, n3, n4, n3, n4);
        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
    }

    public static void allocTextureRectangle(float f, float f2, float f3, float f4) {
        BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
        BUILDER.pos(f, f2, 0.0).tex(0.0, 0.0).endVertex();
        BUILDER.pos(f, f2 + f4, 0.0).tex(0.0, 1.0).endVertex();
        BUILDER.pos(f + f3, f2 + f4, 0.0).tex(1.0, 1.0).endVertex();
        BUILDER.pos(f + f3, f2, 0.0).tex(1.0, 0.0).endVertex();
        TESSELLATOR.draw();
    }

    public static boolean isHovered(float f, float f2, float f3, float f4, float f5, float f6) {
        return f >= f3 && f2 >= f4 && f < f3 + f5 && f2 < f4 + f6;
    }

    public static boolean isHovered(double d, double d2, double d3, double d4, double d5, double d6) {
        return d >= d3 && d2 >= d4 && d < d3 + d5 && d2 < d4 + d6;
    }

    public static boolean isInViewFrustum(Entity entity) {
        return RenderUtility.isInViewFrustum(entity.getEntityBoundingBox()) || entity.ignoreFrustumCheck;
    }

    private static boolean isInViewFrustum(AxisAlignedBB axisAlignedBB) {
        Entity entity = mc.getRenderViewEntity();
        if (entity != null) {
            FRUSTUM.setPosition(entity.posX, entity.posY, entity.posZ);
        }
        return FRUSTUM.isBoundingBoxInFrustum(axisAlignedBB);
    }

    public static Vec3d project2D(int n, double d, double d2, double d3) {
        float f = (float)d;
        float f2 = (float)d2;
        float f3 = (float)d3;
        IntBuffer intBuffer = GLAllocation.createDirectIntBuffer(16);
        FloatBuffer floatBuffer = GLAllocation.createDirectFloatBuffer(16);
        FloatBuffer floatBuffer2 = GLAllocation.createDirectFloatBuffer(16);
        FloatBuffer floatBuffer3 = GLAllocation.createDirectFloatBuffer(4);
        GL11.glGetFloat((int)2982, (FloatBuffer)floatBuffer);
        GL11.glGetFloat((int)2983, (FloatBuffer)floatBuffer2);
        GL11.glGetInteger((int)2978, (IntBuffer)intBuffer);
        return GLU.gluProject((float)f, (float)f2, (float)f3, (FloatBuffer)floatBuffer, (FloatBuffer)floatBuffer2, (IntBuffer)intBuffer, (FloatBuffer)floatBuffer3) ? new Vec3d(floatBuffer3.get(0) / (float)n, ((float)Display.getHeight() - floatBuffer3.get(1)) / (float)n, floatBuffer3.get(2)) : null;
    }

    public static double interpolate(double d, double d2, double d3) {
        return d2 + (d - d2) * d3;
    }

    public static void renderItem(ItemStack itemStack, float f, float f2) {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.enableDepth();
        RenderHelper.enableGUIStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(itemStack, (int)f, (int)f2);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.disableDepth();
    }

    public static void customScaledObject2D(float f, float f2, float f3, float f4, float f5) {
        GL11.glTranslated((double)(f3 / 2.0f), (double)(f4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-f * f5 + f + f3 / 2.0f * -f5), (double)(-f2 * f5 + f2 + f4 / 2.0f * -f5), (double)1.0);
        GL11.glScaled((double)f5, (double)f5, (double)0.0);
    }

    static {
        camera = new Frustum();
        shadowCache = new HashMap();
        BUILDER = TESSELLATOR.getBuffer();
        ROUNDED_GRADIENT = new Shader("starclient/shaders/rounded_gradient.fsh", true);
        ROUNDED = new Shader("starclient/shaders/rounded.fsh", true);
        GRADIENT_MASK = new Shader("starclient/shaders/gradient_mask.fsh", true);
        ROUNDED_TEXTURE = new Shader("starclient/shaders/rounded_texture.fsh", true);
        SHADOW_CACHE = new HashMap();
        FRUSTUM = new Frustum();
        PROFILE_ID = -1337;
    }
}
