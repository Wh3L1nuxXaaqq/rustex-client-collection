package starclient.alpha.utility.render.particle;

import java.awt.Color;
import java.util.List;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.math.MathUtility;
import starclient.alpha.utility.render.RenderUtility;

public class Particle
implements Utility {
    float x;
    float y;
    float motionX = 0.0f;
    float motionY = 0.0f;
    public float mX;
    public float mY;

    public Particle() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n = scaledResolution.getScaledWidth();
        int n2 = scaledResolution.getScaledHeight();
        this.x = MathUtility.randomizeFloat(0.0f, n);
        this.y = MathUtility.randomizeFloat(0.0f, n2);
        this.motionY = MathUtility.randomizeFloat(-0.1f, 0.1f);
        this.motionX = MathUtility.randomizeFloat(-0.1f, 0.1f);
    }

    public void draw(List<Particle> list, int n, int n2) {
        RenderUtility.drawRoundCircle(this.x, this.y, 4.0f, 4.0f, new Color(255, 255, 255, 255).getRGB());
        list.forEach(particle -> {
            if (particle != this && MathUtility.getDistance(this.x, this.y, particle.x, particle.y) < 50.0) {
                RenderUtility.drawLine(this.x, this.y, particle.x, particle.y, 2.0f, new Color(255, 255, 255, 15).getRGB());
            }
        });
    }

    public void update(int n, int n2, int n3, int n4) {
        this.x += this.motionX;
        this.y += this.motionY;
        this.motionX = (float)((double)this.motionX * 0.99);
        this.motionY = (float)((double)this.motionY * 0.99);
        if ((double)Math.abs(this.motionX) < 0.1) {
            this.motionX += MathUtility.randomizeFloat(-0.01f, 0.01f);
        }
        if ((double)Math.abs(this.motionY) < 0.1) {
            this.motionY += MathUtility.randomizeFloat(-0.01f, 0.01f);
        }
        if (Mouse.isButtonDown((int)0) && MathUtility.getDistance(this.x, this.y, n, n2) < 50.0) {
            this.motionX += ((float)n - this.x) / 500.0f;
            this.motionY += ((float)n2 - this.y) / 500.0f;
        }
        if (this.x < 0.0f) {
            this.x = n3;
        }
        if (this.x > (float)n3) {
            this.x = 0.0f;
        }
        if (this.y < 0.0f) {
            this.y = n4;
        }
        if (this.y > (float)n4) {
            this.y = 0.0f;
        }
    }
}
