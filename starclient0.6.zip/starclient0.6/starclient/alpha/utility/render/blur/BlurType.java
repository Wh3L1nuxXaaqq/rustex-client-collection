package starclient.alpha.utility.render.blur;

public enum BlurType {
    CAMERA,
    OVERLAY;

}
