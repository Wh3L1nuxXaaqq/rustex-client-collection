package starclient.alpha.utility.render.blur;

import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.StencilUtility;
import starclient.alpha.utility.render.blur.GaussianBlur;

public class BlurUtility
implements Utility {
    public static void drawBlur(float f, Runnable runnable) {
        StencilUtility.initStencilToWrite();
        runnable.run();
        StencilUtility.readStencilBuffer(1);
        GaussianBlur.renderBlur(f);
        StencilUtility.uninitStencilBuffer();
    }

    public static void drawBlurredScreen(float f) {
        GaussianBlur.renderBlur(f);
    }
}
