package starclient.alpha.utility.render.blur;

import java.nio.FloatBuffer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.shader.Shader;
import starclient.alpha.utility.render.shader.ShaderUtility;

public class GaussianBlur
implements Utility {
    public static Shader blurShader = new Shader("starclient/shaders/gaussian.frag", true);
    public static Framebuffer framebuffer = new Framebuffer(1, 1, false);

    public static void setupUniforms(float f, float f2, float f3) {
        blurShader.setupUniform1i("textureIn", 0);
        blurShader.setupUniform2f("texelSize", 1.0f / (float)GaussianBlur.mc.displayWidth, 1.0f / (float)GaussianBlur.mc.displayHeight);
        blurShader.setupUniform2f("direction", f, f2);
        blurShader.setupUniform1f("radius", f3);
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)256);
        int n = 0;
        while ((float)n <= f3) {
            floatBuffer.put(GaussianBlur.calculateGaussianValue(n, f3 / 2.0f));
            ++n;
        }
        floatBuffer.rewind();
        GL20.glUniform1((int)blurShader.getUniform("weights"), (FloatBuffer)floatBuffer);
    }

    public static void renderBlur(float f) {
        GlStateManager.enableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        framebuffer = RenderUtility.createFrameBuffer(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        blurShader.useProgram();
        GaussianBlur.setupUniforms(1.0f, 0.0f, f);
        RenderUtility.bindTexture(GaussianBlur.mc.getFramebuffer().framebufferTexture);
        ShaderUtility.drawQuads();
        framebuffer.unbindFramebuffer();
        blurShader.unloadProgram();
        mc.getFramebuffer().bindFramebuffer(true);
        blurShader.useProgram();
        GaussianBlur.setupUniforms(0.0f, 1.0f, f);
        RenderUtility.bindTexture(GaussianBlur.framebuffer.framebufferTexture);
        ShaderUtility.drawQuads();
        blurShader.unloadProgram();
        RenderUtility.resetColor();
        GlStateManager.bindTexture(0);
    }

    public static void renderBlurRect(float f, float f2) {
        GlStateManager.enableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        framebuffer = RenderUtility.createFrameBuffer(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        blurShader.useProgram();
        GaussianBlur.setupUniformsRect(1.0f, 0.0f, f, f2);
        RenderUtility.bindTexture(GaussianBlur.mc.getFramebuffer().framebufferTexture);
        ShaderUtility.drawQuads();
        framebuffer.unbindFramebuffer();
        blurShader.unloadProgram();
        mc.getFramebuffer().bindFramebuffer(true);
        blurShader.useProgram();
        GaussianBlur.setupUniformsRect(0.0f, 1.0f, f, f2);
        RenderUtility.bindTexture(GaussianBlur.framebuffer.framebufferTexture);
        ShaderUtility.drawQuads();
        blurShader.unloadProgram();
        RenderUtility.resetColor();
        GlStateManager.bindTexture(0);
    }

    public static void setupUniformsRect(float f, float f2, float f3, float f4) {
        blurShader.setupUniform1i("textureIn", 0);
        blurShader.setupUniform2f("texelSize", 1.0f / (float)GaussianBlur.mc.displayWidth, 1.0f / (float)GaussianBlur.mc.displayHeight);
        blurShader.setupUniform2f("direction", f, f2);
        blurShader.setupUniform1f("radius", f3);
        blurShader.setupUniform1f("cornerRadius", f4);
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)256);
        int n = 0;
        while ((float)n <= f3) {
            floatBuffer.put(GaussianBlur.calculateGaussianValue(n, f3 / 2.0f));
            ++n;
        }
        floatBuffer.rewind();
        GL20.glUniform1((int)blurShader.getUniform("weights"), (FloatBuffer)floatBuffer);
    }

    public static float calculateGaussianValue(float f, float f2) {
        double d = 3.141592653;
        double d2 = 1.0 / Math.sqrt(2.0 * d * (double)(f2 * f2));
        return (float)(d2 * Math.exp((double)(-(f * f)) / (2.0 * (double)(f2 * f2))));
    }

    public static Shader getBlurShader() {
        return blurShader;
    }

    public static Framebuffer getFramebuffer() {
        return framebuffer;
    }
}
