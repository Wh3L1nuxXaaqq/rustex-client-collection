package starclient.alpha.utility.render.blur;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public interface Utility {
    public static final Minecraft mc = Minecraft.getMinecraft();
    public static final ScaledResolution sr = new ScaledResolution(mc);
    public static final List<Runnable> NORMAL_BLUR_RUNNABLES = new ArrayList<Runnable>();
    public static final List<Runnable> NORMAL_SHADOW_BLACK = new ArrayList<Runnable>();
}
