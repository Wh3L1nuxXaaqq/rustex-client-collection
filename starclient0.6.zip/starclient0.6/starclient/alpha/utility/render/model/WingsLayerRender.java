package starclient.alpha.utility.render.model;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import starclient.alpha.StarClient;
import starclient.alpha.module.impl.render.Wings;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.model.WingsModel;

public class WingsLayerRender
implements LayerRenderer<AbstractClientPlayer>,
Utility {
    @Override
    public void doRenderLayer(AbstractClientPlayer abstractClientPlayer, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (abstractClientPlayer == WingsLayerRender.mc.player && StarClient.getInstance().getModuleManager().getModule(Wings.class).isEnabled() && abstractClientPlayer.hasPlayerInfo() && !abstractClientPlayer.isInvisible()) {
            WingsModel.renderWings(abstractClientPlayer, f3, Wings.scale.get());
        }
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
