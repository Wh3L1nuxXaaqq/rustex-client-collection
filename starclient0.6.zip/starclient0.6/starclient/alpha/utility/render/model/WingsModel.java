package starclient.alpha.utility.render.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class WingsModel
extends ModelBase {
    private static final ResourceLocation location = new ResourceLocation("starclient/models/wings.png");
    private static ModelRenderer wingTip;
    private static ModelRenderer wing;

    public WingsModel() {
        this.setTextureOffset("wing.bone", 0, 0);
        this.setTextureOffset("wing.skin", -10, 8);
        this.setTextureOffset("wingtip.bone", 0, 5);
        this.setTextureOffset("wingtip.skin", -10, 18);
        wing = new ModelRenderer(this, "wing");
        wing.setTextureSize(30, 30);
        wing.setRotationPoint(-2.0f, 0.0f, 0.0f);
        wing.addBox("bone", -10.0f, -1.0f, -1.0f, 10, 2, 2);
        wing.addBox("skin", -10.0f, 0.0f, 0.5f, 10, 0, 10);
        wingTip = new ModelRenderer(this, "wingtip");
        wingTip.setTextureSize(30, 30);
        wingTip.setRotationPoint(-10.0f, 0.0f, 0.0f);
        wingTip.addBox("bone", -10.0f, -0.5f, -0.5f, 10, 1, 1);
        wingTip.addBox("skin", -10.0f, 0.0f, 0.5f, 10, 0, 10);
        wing.addChild(wingTip);
    }

    public static void renderWings(EntityPlayer entityPlayer, float f, double d) {
        double d2 = WingsModel.interpolate(entityPlayer.prevRenderYawOffset, entityPlayer.renderYawOffset, f);
        GL11.glPushMatrix();
        GL11.glScaled((double)d, (double)d, (double)d);
        GL11.glRotated((double)(Math.toRadians(d2) - 4.0), (double)0.0, (double)1.0, (double)0.0);
        GL11.glTranslated((double)0.0, (double)0.1, (double)0.095);
        if (entityPlayer.isSneaking()) {
            GL11.glTranslated((double)0.0, (double)0.2, (double)0.05);
        }
        if (!entityPlayer.inventory.armorInventory.get(2).isEmpty()) {
            GL11.glTranslated((double)0.0, (double)0.0, (double)0.05);
        }
        Minecraft.getMinecraft().getTextureManager().bindTexture(location);
        for (int i = 0; i < 2; ++i) {
            GL11.glEnable((int)2884);
            float f2 = (float)(System.currentTimeMillis() % 1000L) / 1000.0f * (float)Math.PI * 2.0f;
            WingsModel.wing.rotateAngleX = (float)(Math.toRadians(-80.0) - Math.cos(f2) * (double)0.2f);
            WingsModel.wing.rotateAngleY = (float)(Math.toRadians(30.0) + Math.sin(f2) * (double)0.4f);
            WingsModel.wing.rotateAngleZ = (float)Math.toRadians(20.0);
            WingsModel.wingTip.rotateAngleZ = (float)(-(Math.sin(f2 + 2.0f) + 0.5) * 0.75);
            wing.render(0.0625f);
            GL11.glScalef((float)-1.0f, (float)1.0f, (float)1.0f);
            if (i != 0) continue;
            GL11.glCullFace((int)1028);
        }
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2884);
        GL11.glPopMatrix();
    }

    private static float interpolate(float f, float f2, float f3) {
        float f4 = (f + (f2 - f) * f3) % 360.0f;
        return f4 < 0.0f ? f4 + 360.0f : f4;
    }
}
