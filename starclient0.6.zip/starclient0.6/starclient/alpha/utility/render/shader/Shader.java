package starclient.alpha.utility.render.shader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL20;

public class Shader {
    int shaderProgram;

    public String readInputStream(InputStream inputStream) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            String string;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            while ((string = bufferedReader.readLine()) != null) {
                stringBuilder.append(string).append('\n');
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return stringBuilder.toString();
    }

    public Shader(String string, boolean bl) {
        int n = GL20.glCreateProgram();
        int n2 = GL20.glCreateShader((int)35632);
        try {
            GL20.glShaderSource((int)n2, (CharSequence)(bl ? this.readInputStream(Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(string)).getInputStream()) : string));
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
        GL20.glCompileShader((int)n2);
        GL20.glAttachShader((int)n, (int)n2);
        int n3 = GL20.glCreateShader((int)35633);
        GL20.glShaderSource((int)n3, (CharSequence)"#version 120\nvoid main() {\n gl_TexCoord[0] = gl_MultiTexCoord0;\n gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}");
        GL20.glCompileShader((int)n3);
        GL20.glAttachShader((int)n, (int)n3);
        GL20.glLinkProgram((int)n);
        this.shaderProgram = n;
    }

    public Shader(String string, String string2, boolean bl) {
        int n = GL20.glCreateProgram();
        int n2 = GL20.glCreateShader((int)35632);
        try {
            GL20.glShaderSource((int)n2, (CharSequence)(bl ? this.readInputStream(Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(string)).getInputStream()) : string));
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
        GL20.glAttachShader((int)n, (int)n2);
        GL20.glCompileShader((int)n2);
        int n3 = GL20.glCreateShader((int)35633);
        try {
            GL20.glShaderSource((int)n3, (CharSequence)(bl ? this.readInputStream(Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(string2)).getInputStream()) : string2));
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
        GL20.glCompileShader((int)n3);
        GL20.glAttachShader((int)n, (int)n3);
        GL20.glDeleteShader((int)n2);
        GL20.glDeleteShader((int)n3);
        GL20.glLinkProgram((int)n);
        this.shaderProgram = n;
    }

    public void useProgram() {
        GL20.glUseProgram((int)this.shaderProgram);
    }

    public void unloadProgram() {
        GL20.glUseProgram((int)0);
    }

    public void setupUniform1f(String string, float f) {
        int n = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform1f((int)n, (float)f);
    }

    public void setupUniform2f(String string, float f, float f2) {
        int n = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform2f((int)n, (float)f, (float)f2);
    }

    public void setupUniform3f(String string, float f, float f2, float f3) {
        int n = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform3f((int)n, (float)f, (float)f2, (float)f3);
    }

    public void setupUniform4f(String string, float f, float f2, float f3, float f4) {
        int n = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform4f((int)n, (float)f, (float)f2, (float)f3, (float)f4);
    }

    public void setupUniform1i(String string, int n) {
        int n2 = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform1i((int)n2, (int)n);
    }

    public void setupUniform2i(String string, int n, int n2) {
        int n3 = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform2i((int)n3, (int)n, (int)n2);
    }

    public void setupUniform3i(String string, int n, int n2, int n3) {
        int n4 = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform3i((int)n4, (int)n, (int)n2, (int)n3);
    }

    public void setupUniform4i(String string, int n, int n2, int n3, int n4) {
        int n5 = GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
        GL20.glUniform4i((int)n5, (int)n, (int)n2, (int)n3, (int)n4);
    }

    public int getUniform(String string) {
        return GL20.glGetUniformLocation((int)this.shaderProgram, (CharSequence)string);
    }
}
