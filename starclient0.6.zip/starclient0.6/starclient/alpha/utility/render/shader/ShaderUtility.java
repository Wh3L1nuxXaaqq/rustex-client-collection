package starclient.alpha.utility.render.shader;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL11;
import starclient.alpha.utility.Utility;

public class ShaderUtility
implements Utility {
    public static Framebuffer createFrameBuffer(Framebuffer framebuffer) {
        if (framebuffer != null && framebuffer.framebufferWidth == ShaderUtility.mc.displayWidth && framebuffer.framebufferHeight == ShaderUtility.mc.displayHeight) {
            return framebuffer;
        }
        if (framebuffer != null) {
            framebuffer.deleteFramebuffer();
        }
        return new Framebuffer(ShaderUtility.mc.displayWidth, ShaderUtility.mc.displayHeight, true);
    }

    public static void bindTexture(int n) {
        GlStateManager.bindTexture(n);
    }

    public static void drawQuads() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        float f = scaledResolution.getScaledWidth();
        float f2 = scaledResolution.getScaledHeight();
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)0.0f, (float)1.0f);
        GL11.glVertex2f((float)0.0f, (float)0.0f);
        GL11.glTexCoord2f((float)0.0f, (float)0.0f);
        GL11.glVertex2f((float)0.0f, (float)f2);
        GL11.glTexCoord2f((float)1.0f, (float)0.0f);
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glTexCoord2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)f, (float)0.0f);
        GL11.glEnd();
    }
}
