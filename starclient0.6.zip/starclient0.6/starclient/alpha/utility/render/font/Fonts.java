package starclient.alpha.utility.render.font;

import java.awt.Font;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import starclient.alpha.utility.render.font.FontRenderer;

public class Fonts {
    public static FontRenderer icons21 = new FontRenderer(Fonts.getFontFromTTF("icons", 21.0f, 0), true, true);
    public static FontRenderer icons41 = new FontRenderer(Fonts.getFontFromTTF("icons", 41.0f, 0), true, true);
    public static FontRenderer nunitoBold14 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 14.0f, 0), true, true);
    public static FontRenderer nunitoBold15 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 15.0f, 0), true, true);
    public static FontRenderer nunitoBold16 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 16.0f, 0), true, true);
    public static FontRenderer nunitoBold18 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 18.0f, 0), true, true);
    public static FontRenderer nunitoBold20 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 20.0f, 0), true, true);
    public static FontRenderer nunitoBold26 = new FontRenderer(Fonts.getFontFromTTF("nunito-bold", 26.0f, 0), true, true);
    public static FontRenderer mntsb16 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 16.0f, 0), true, true);
    public static FontRenderer mntsb18 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 18.0f, 0), true, true);
    public static FontRenderer mntsb20 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 20.0f, 0), true, true);
    public static FontRenderer mntsb22 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 22.0f, 0), true, true);
    public static FontRenderer mntsb24 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 24.0f, 0), true, true);
    public static FontRenderer mntsb26 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 26.0f, 0), true, true);
    public static FontRenderer mntsb28 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 28.0f, 0), true, true);
    public static FontRenderer mntsb30 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 30.0f, 0), true, true);
    public static FontRenderer mntsb32 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 32.0f, 0), true, true);
    public static FontRenderer mntssb16 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 16.0f, 0), true, true);
    public static FontRenderer mntssb15 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 15.0f, 0), true, true);
    public static FontRenderer mntssb14 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 14.0f, 0), true, true);
    public static FontRenderer mntssb13 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 13.0f, 0), true, true);
    public static FontRenderer mntssb12 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 12.0f, 0), true, true);
    public static FontRenderer mntssb11 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 11.0f, 0), true, true);
    public static FontRenderer mntssb10 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 10.0f, 0), true, true);
    public static FontRenderer mntssb8 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 8.0f, 0), true, true);
    public static FontRenderer mntssb6 = new FontRenderer(Fonts.getFontFromTTF("mntssb", 6.0f, 0), true, true);
    public static FontRenderer mntsb13 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 13.0f, 0), true, true);
    public static FontRenderer tenacityBold28 = new FontRenderer(Fonts.getFontFromTTF("tenacity-bold", 28.0f, 0), true, true);
    public static FontRenderer tenacityBold35 = new FontRenderer(Fonts.getFontFromTTF("tenacity-bold", 35.0f, 0), true, true);
    public static FontRenderer tenacityBold45 = new FontRenderer(Fonts.getFontFromTTF("tenacity-bold", 45.0f, 0), true, true);
    public static FontRenderer tenacityBold18 = new FontRenderer(Fonts.getFontFromTTF("tenacity-bold", 18.0f, 0), true, true);
    public static FontRenderer tenacityBold12 = new FontRenderer(Fonts.getFontFromTTF("tenacity-bold", 12.0f, 0), true, true);
    public static FontRenderer ace16 = new FontRenderer(Fonts.getFontFromTTF("ace", 16.0f, 0), true, true);
    public static FontRenderer hack16 = new FontRenderer(Fonts.getFontFromTTF("hack", 16.0f, 0), true, true);
    public static FontRenderer minecraft13 = new FontRenderer(Fonts.getFontFromTTF("minecraft", 14.0f, 0), true, true);
    public static FontRenderer mntsb17 = new FontRenderer(Fonts.getFontFromTTF("mntsb", 17.0f, 0), true, true);
    public static FontRenderer nunito14 = new FontRenderer(Fonts.getFontFromTTF("nunito", 14.0f, 0), true, true);
    public static FontRenderer nunito12 = new FontRenderer(Fonts.getFontFromTTF("nunito", 12.0f, 0), true, true);
    public static FontRenderer nw12 = new FontRenderer(Fonts.getFontFromTTF("client", 12.0f, 0), true, true);
    public static FontRenderer nw14 = new FontRenderer(Fonts.getFontFromTTF("client", 14.0f, 0), true, true);
    public static FontRenderer nw16 = new FontRenderer(Fonts.getFontFromTTF("client", 16.0f, 0), true, true);
    public static FontRenderer nw18 = new FontRenderer(Fonts.getFontFromTTF("client", 18.0f, 0), true, true);
    public static FontRenderer nw20 = new FontRenderer(Fonts.getFontFromTTF("client", 20.0f, 0), true, true);
    public static FontRenderer st20 = new FontRenderer(Fonts.getFontFromTTF("client", 20.0f, 0), true, true);
    public static FontRenderer nw24 = new FontRenderer(Fonts.getFontFromTTF("client", 24.0f, 0), true, true);
    public static FontRenderer nw32 = new FontRenderer(Fonts.getFontFromTTF("client", 32.0f, 0), true, true);
    public static FontRenderer nw48 = new FontRenderer(Fonts.getFontFromTTF("client", 48.0f, 0), true, true);
    public static FontRenderer obelix = new FontRenderer(Fonts.getFontFromTTF("obelix", 32.0f, 0), true, true);
    public static FontRenderer obelixmin = new FontRenderer(Fonts.getFontFromTTF("obelix", 25.0f, 0), true, true);
    public static FontRenderer code18 = new FontRenderer(Fonts.getFontFromTTF("code", 18.0f, 0), true, true);
    public static FontRenderer code20 = new FontRenderer(Fonts.getFontFromTTF("code", 20.0f, 0), true, true);
    public static FontRenderer code25 = new FontRenderer(Fonts.getFontFromTTF("code", 25.0f, 0), true, true);
    public static FontRenderer code30 = new FontRenderer(Fonts.getFontFromTTF("code", 30.0f, 0), true, true);
    public static FontRenderer newicons24 = new FontRenderer(Fonts.getFontFromTTF("icons1", 24.0f, 0), true, true);
    public static FontRenderer newicons20 = new FontRenderer(Fonts.getFontFromTTF("icons1", 20.0f, 0), true, true);
    public static FontRenderer hitmarker = new FontRenderer(Fonts.getFontFromTTF("x", 20.0f, 0), true, true);
    public static FontRenderer neverlose45 = new FontRenderer(Fonts.getFontFromTTF("neverlose900", 45.0f, 0), true, true);
    public static FontRenderer neverlosed18 = new FontRenderer(Fonts.getFontFromTTF("neverlose500", 18.0f, 0), true, true);
    public static FontRenderer sfpro18 = new FontRenderer(Fonts.getFontFromTTF("sfpro", 18.0f, 0), true, true);
    public static FontRenderer iconsnur = new FontRenderer(Fonts.getFontFromTTF("iconsnur", 18.0f, 0), true, true);
    public static FontRenderer verdana14 = new FontRenderer(Fonts.getFontFromTTF("verdana", 14.0f, 0), true, true);
    public static FontRenderer roadrage38 = new FontRenderer(Fonts.getFontFromTTF("roadrage", 38.0f, 0), true, true);
    public static FontRenderer roadrage18 = new FontRenderer(Fonts.getFontFromTTF("roadrage", 18.0f, 0), true, true);

    public static Font getFontFromTTF(String string, float f, int n) {
        Font font = null;
        try {
            font = Font.createFont(n, Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("font/" + string + ".ttf")).getInputStream());
            font = font.deriveFont(f);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return font;
    }
}
