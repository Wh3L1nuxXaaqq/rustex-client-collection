package starclient.alpha.utility.render.font;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.font.CFont;
import starclient.alpha.utility.render.shader.Shader;

public class FontRenderer
extends CFont {
    private static final Shader FONT_SUBSTRING = new Shader("starclient/shaders/font_substring.fsh", true);
    protected CFont.CharData[] boldChars = new CFont.CharData[1104];
    protected CFont.CharData[] italicChars = new CFont.CharData[1104];
    protected CFont.CharData[] boldItalicChars = new CFont.CharData[1104];
    private final int[] colorCode = new int[32];
    protected DynamicTexture texBold;
    protected DynamicTexture texItalic;
    protected DynamicTexture texItalicBold;

    public FontRenderer(Font font, boolean bl, boolean bl2) {
        super(font, bl, bl2);
        this.setupMinecraftColorcodes();
        this.setupBoldItalicIDs();
    }

    public void drawStringWithDropShadow(String string, float f, float f2, int n) {
        for (int i = 0; i < 5; ++i) {
            this.drawString(string, f + 0.5f * (float)i, f2 + 0.5f * (float)i, new Color(0, 0, 0, 100 - i * 20).hashCode());
        }
        this.drawString(string, f, f2, n);
    }

    public float drawString(String string, float f, float f2, int n) {
        return this.drawString(string, f, f2, n, false);
    }

    public float drawString(String string, double d, double d2, int n) {
        return this.drawString(string, d, d2, n, false);
    }

    public void drawSubstring(String string, float f, float f2, int n, float f3) {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        FONT_SUBSTRING.useProgram();
        FONT_SUBSTRING.setupUniform4f("inColor", (float)(n >> 16 & 0xFF) / 255.0f, (float)(n >> 8 & 0xFF) / 255.0f, (float)(n & 0xFF) / 255.0f, (float)(n >> 24 & 0xFF) / 255.0f);
        FONT_SUBSTRING.setupUniform1f("width", f3);
        FONT_SUBSTRING.setupUniform1f("maxWidth", (f + f3) * 2.0f);
        this.drawString(string, f, f2, n);
        FONT_SUBSTRING.unloadProgram();
        GlStateManager.disableBlend();
    }

    public String trimStringToWidth(String string, int n, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        float f = 0.0f;
        int n2 = bl ? string.length() - 1 : 0;
        int n3 = bl ? -1 : 1;
        boolean bl2 = false;
        boolean bl3 = false;
        for (int i = n2; i >= 0 && i < string.length() && f < (float)n; i += n3) {
            char c = string.charAt(i);
            float f2 = this.getStringWidthCust(Character.toString(c));
            if (bl2) {
                bl2 = false;
                if (c != 'l' && c != 'L') {
                    if (c == 'r' || c == 'R') {
                        bl3 = false;
                    }
                } else {
                    bl3 = true;
                }
            } else if (f2 < 0.0f) {
                bl2 = true;
            } else {
                f += f2;
                if (bl3) {
                    f += 1.0f;
                }
            }
            if (f > (float)n) break;
            if (bl) {
                stringBuilder.insert(0, c);
                continue;
            }
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }

    public float drawStringWithShadow(String string, float f, float f2, int n) {
        float f3 = this.drawString(string, (double)f + 0.5, (double)f2 + 0.5, n, true);
        return Math.max(f3, this.drawString(string, f, f2, n, false));
    }

    public float drawStringWithShadow(String string, double d, double d2, int n) {
        float f = this.drawString(string, d + 0.5, d2 + 0.5, n, true);
        return Math.max(f, this.drawString(string, d, d2, n, false));
    }

    public float drawCenteredString(String string, float f, float f2, int n) {
        return this.drawString(string, f - (float)this.getStringWidth(string) / 2.0f, f2, n);
    }

    public float drawGradientCenteredString(String string, float f, float f2, Color color, Color color2) {
        return this.drawGradientString(string, f - (float)this.getStringWidth(string) / 2.0f, f2, color, color2);
    }

    public float drawCenteredString(String string, double d, double d2, int n) {
        return this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f), d2, n);
    }

    public float drawCenteredStringWithShadow(String string, float f, float f2, int n) {
        this.drawString(string, (double)(f - (float)this.getStringWidth(string) / 2.0f) + 0.45, (double)f2 + 0.5, n, true);
        return this.drawString(string, f - (float)this.getStringWidth(string) / 2.0f, f2, n);
    }

    public void drawStringWithOutline(String string, double d, double d2, int n) {
        this.drawString(ChatFormatting.stripFormatting((String)string), d - 0.5, d2, 0);
        this.drawString(ChatFormatting.stripFormatting((String)string), d + 0.5, d2, 0);
        this.drawString(ChatFormatting.stripFormatting((String)string), d, d2 - 0.5, 0);
        this.drawString(ChatFormatting.stripFormatting((String)string), d, d2 + 0.5, 0);
        this.drawString(string, d, d2, n);
    }

    public void drawCenteredStringWithOutline(String string, double d, double d2, int n) {
        this.drawCenteredString(ChatFormatting.stripFormatting((String)string), d - 0.5, d2, 0);
        this.drawCenteredString(ChatFormatting.stripFormatting((String)string), d + 0.5, d2, 0);
        this.drawCenteredString(ChatFormatting.stripFormatting((String)string), d, d2 - 0.5, 0);
        this.drawCenteredString(ChatFormatting.stripFormatting((String)string), d, d2 + 0.5, 0);
        this.drawCenteredString(string, d, d2, n);
    }

    public float drawCenteredStringWithShadow(String string, double d, double d2, int n) {
        this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f) + 0.45, d2 + 0.5, n, true);
        return this.drawString(string, d - (double)((float)this.getStringWidth(string) / 2.0f), d2, n);
    }

    public float drawString(String string, double d, double d2, int n, boolean bl) {
        try {
            d -= 1.0;
            if (string == null) {
                return 0.0f;
            }
            if (n == 0x20FFFFFF) {
                n = 0xFFFFFF;
            }
            if ((n & 0xFC000000) == 0) {
                n |= 0xFF000000;
            }
            if (bl) {
                n = (n & 0xFCFCFC) >> 2 | n & new Color(20, 20, 20, 200).getRGB();
            }
            CFont.CharData[] charDataArray = this.charData;
            float f = (float)(n >> 24 & 0xFF) / 255.0f;
            boolean bl2 = false;
            boolean bl3 = false;
            boolean bl4 = false;
            boolean bl5 = false;
            d *= 2.0;
            d2 = (d2 - 3.0) * 2.0;
            GL11.glPushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            GlStateManager.color((float)(n >> 16 & 0xFF) / 255.0f, (float)(n >> 8 & 0xFF) / 255.0f, (float)(n & 0xFF) / 255.0f, f);
            int n2 = string.length();
            GlStateManager.enableTexture2D();
            GlStateManager.bindTexture(this.tex.getGlTextureId());
            GL11.glBindTexture((int)3553, (int)this.tex.getGlTextureId());
            for (int i = 0; i < n2; ++i) {
                char c = string.charAt(i);
                if (String.valueOf(c).equals("\u00a7")) {
                    int n3 = 21;
                    try {
                        n3 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    if (n3 < 16) {
                        bl2 = false;
                        bl3 = false;
                        bl5 = false;
                        bl4 = false;
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                        if (n3 < 0) {
                            n3 = 15;
                        }
                        if (bl) {
                            n3 += 16;
                        }
                        int n4 = this.colorCode[n3];
                        GlStateManager.color((float)(n4 >> 16 & 0xFF) / 255.0f, (float)(n4 >> 8 & 0xFF) / 255.0f, (float)(n4 & 0xFF) / 255.0f, f);
                    } else if (n3 == 17) {
                        bl2 = true;
                        if (bl3) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texBold.getGlTextureId());
                            charDataArray = this.boldChars;
                        }
                    } else if (n3 == 18) {
                        bl4 = true;
                    } else if (n3 == 19) {
                        bl5 = true;
                    } else if (n3 == 20) {
                        bl3 = true;
                        if (bl2) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texItalic.getGlTextureId());
                            charDataArray = this.italicChars;
                        }
                    } else if (n3 == 21) {
                        bl2 = false;
                        bl3 = false;
                        bl5 = false;
                        bl4 = false;
                        GlStateManager.color((float)(n >> 16 & 0xFF) / 255.0f, (float)(n >> 8 & 0xFF) / 255.0f, (float)(n & 0xFF) / 255.0f, f);
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                    }
                    ++i;
                    continue;
                }
                if (c >= charDataArray.length) continue;
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl4) {
                    this.drawLine(d, d2 + (double)((float)charDataArray[c].height / 2.0f), d + (double)charDataArray[c].width - 8.0, d2 + (double)((float)charDataArray[c].height / 2.0f), 1.0f);
                }
                if (bl5) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)(charDataArray[c].width - 8 + this.charOffset);
            }
            GL11.glPopMatrix();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return (float)d / 2.0f;
    }

    public float drawGradientString(String string, double d, double d2, int n, Color color, Color color2) {
        try {
            d -= 1.0;
            if (string == null) {
                return 0.0f;
            }
            CFont.CharData[] charDataArray = this.charData;
            boolean bl = false;
            boolean bl2 = false;
            boolean bl3 = false;
            boolean bl4 = false;
            d *= 2.0;
            d2 = (d2 - 3.0) * 2.0;
            GL11.glPushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            int n2 = string.length();
            GlStateManager.enableTexture2D();
            GlStateManager.bindTexture(this.tex.getGlTextureId());
            GL11.glBindTexture((int)3553, (int)this.tex.getGlTextureId());
            for (int i = 0; i < n2; ++i) {
                Color color3 = ColorUtility.gradient(7, i * -n, color, color2);
                ColorUtility.setColor(color3);
                char c = string.charAt(i);
                if (String.valueOf(c).equals("\u00a7")) {
                    int n3 = 21;
                    try {
                        n3 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    if (n3 < 16) {
                        bl = false;
                        bl2 = false;
                        bl4 = false;
                        bl3 = false;
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                        if (n3 < 0) {
                            n3 = 15;
                        }
                        int n4 = this.colorCode[n3];
                        ColorUtility.setColor(color3);
                    } else if (n3 == 17) {
                        bl = true;
                        if (bl2) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texBold.getGlTextureId());
                            charDataArray = this.boldChars;
                        }
                    } else if (n3 == 18) {
                        bl3 = true;
                    } else if (n3 == 19) {
                        bl4 = true;
                    } else if (n3 == 20) {
                        bl2 = true;
                        if (bl) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texItalic.getGlTextureId());
                            charDataArray = this.italicChars;
                        }
                    } else if (n3 == 21) {
                        bl = false;
                        bl2 = false;
                        bl4 = false;
                        bl3 = false;
                        ColorUtility.setColor(color3);
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                    }
                    ++i;
                    continue;
                }
                if (c >= charDataArray.length) continue;
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl3) {
                    this.drawLine(d, d2 + (double)((float)charDataArray[c].height / 2.0f), d + (double)charDataArray[c].width - 8.0, d2 + (double)((float)charDataArray[c].height / 2.0f), 1.0f);
                }
                if (bl4) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)(charDataArray[c].width - 8 + this.charOffset);
            }
            GL11.glPopMatrix();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return (float)d / 2.0f;
    }

    public float drawGradientString(String string, double d, double d2, Color color, Color color2) {
        try {
            d -= 1.0;
            if (string == null) {
                return 0.0f;
            }
            CFont.CharData[] charDataArray = this.charData;
            boolean bl = false;
            boolean bl2 = false;
            boolean bl3 = false;
            boolean bl4 = false;
            d *= 2.0;
            d2 = (d2 - 3.0) * 2.0;
            GL11.glPushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            int n = string.length();
            GlStateManager.enableTexture2D();
            GlStateManager.bindTexture(this.tex.getGlTextureId());
            GL11.glBindTexture((int)3553, (int)this.tex.getGlTextureId());
            for (int i = 0; i < n; ++i) {
                Color color3 = ColorUtility.gradient(7, i * -30, color, color2);
                ColorUtility.setColor(color3);
                char c = string.charAt(i);
                if (String.valueOf(c).equals("\u00a7")) {
                    int n2 = 21;
                    try {
                        n2 = "0123456789abcdefklmnor".indexOf(string.charAt(i + 1));
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    if (n2 < 16) {
                        bl = false;
                        bl2 = false;
                        bl4 = false;
                        bl3 = false;
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                        if (n2 < 0) {
                            n2 = 15;
                        }
                        int n3 = this.colorCode[n2];
                        ColorUtility.setColor(color3);
                    } else if (n2 == 17) {
                        bl = true;
                        if (bl2) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texBold.getGlTextureId());
                            charDataArray = this.boldChars;
                        }
                    } else if (n2 == 18) {
                        bl3 = true;
                    } else if (n2 == 19) {
                        bl4 = true;
                    } else if (n2 == 20) {
                        bl2 = true;
                        if (bl) {
                            GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                            charDataArray = this.boldItalicChars;
                        } else {
                            GlStateManager.bindTexture(this.texItalic.getGlTextureId());
                            charDataArray = this.italicChars;
                        }
                    } else if (n2 == 21) {
                        bl = false;
                        bl2 = false;
                        bl4 = false;
                        bl3 = false;
                        ColorUtility.setColor(color3);
                        GlStateManager.bindTexture(this.tex.getGlTextureId());
                        charDataArray = this.charData;
                    }
                    ++i;
                    continue;
                }
                if (c >= charDataArray.length) continue;
                GL11.glBegin((int)4);
                this.drawChar(charDataArray, c, (float)d, (float)d2);
                GL11.glEnd();
                if (bl3) {
                    this.drawLine(d, d2 + (double)((float)charDataArray[c].height / 2.0f), d + (double)charDataArray[c].width - 8.0, d2 + (double)((float)charDataArray[c].height / 2.0f), 1.0f);
                }
                if (bl4) {
                    this.drawLine(d, d2 + (double)charDataArray[c].height - 2.0, d + (double)charDataArray[c].width - 8.0, d2 + (double)charDataArray[c].height - 2.0, 1.0f);
                }
                d += (double)(charDataArray[c].width - 8 + this.charOffset);
            }
            GL11.glPopMatrix();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return (float)d / 2.0f;
    }

    @Override
    public int getStringWidth(String string) {
        if (string == null) {
            return 0;
        }
        int n = 0;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        int n2 = string.length();
        for (int i = 0; i < n2; ++i) {
            char c = string.charAt(i);
            if (c == '\u00a7' && i < n2) {
                int n3 = "0123456789abcdefklmnor".indexOf(c);
                if (n3 < 16) {
                    bl = false;
                    bl2 = false;
                } else if (n3 == 17) {
                    bl = true;
                    charDataArray = bl2 ? this.boldItalicChars : this.boldChars;
                } else if (n3 == 20) {
                    bl2 = true;
                    charDataArray = bl ? this.boldItalicChars : this.italicChars;
                } else if (n3 == 21) {
                    bl = false;
                    bl2 = false;
                    charDataArray = this.charData;
                }
                ++i;
                continue;
            }
            if (c >= charDataArray.length || c < '\u0000' || charDataArray[c] == null) continue;
            n += charDataArray[c].width - 8 + this.charOffset;
        }
        return n / 2;
    }

    public int getStringWidthCust(String string) {
        if (string == null) {
            return 0;
        }
        int n = 0;
        CFont.CharData[] charDataArray = this.charData;
        boolean bl = false;
        boolean bl2 = false;
        int n2 = string.length();
        for (int i = 0; i < n2; ++i) {
            char c = string.charAt(i);
            if (String.valueOf(c).equals("\u00a7") && i < n2) {
                int n3 = "0123456789abcdefklmnor".indexOf(c);
                if (n3 < 16) {
                    bl = false;
                    bl2 = false;
                } else if (n3 == 17) {
                    bl = true;
                    charDataArray = bl2 ? this.boldItalicChars : this.boldChars;
                } else if (n3 == 20) {
                    bl2 = true;
                    charDataArray = bl ? this.boldItalicChars : this.italicChars;
                } else if (n3 == 21) {
                    bl = false;
                    bl2 = false;
                    charDataArray = this.charData;
                }
                ++i;
                continue;
            }
            if (c >= charDataArray.length || c < '\u0000') continue;
            n += charDataArray[c].width - 8 + this.charOffset;
        }
        return (n - this.charOffset) / 2;
    }

    @Override
    public void setFont(Font font) {
        super.setFont(font);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setAntiAlias(boolean bl) {
        super.setAntiAlias(bl);
        this.setupBoldItalicIDs();
    }

    @Override
    public void setFractionalMetrics(boolean bl) {
        super.setFractionalMetrics(bl);
        this.setupBoldItalicIDs();
    }

    private void setupBoldItalicIDs() {
        this.texBold = this.setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
        this.texItalic = this.setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
        this.texItalicBold = this.setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
    }

    private void drawLine(double d, double d2, double d3, double d4, float f) {
        GL11.glDisable((int)3553);
        GL11.glLineWidth((float)f);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
    }

    public List wrapWords(String string, double d) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        if ((double)this.getStringWidth(string) > d) {
            String[] stringArray = string.split(" ");
            Object object = "";
            char c = '\uffff';
            String[] stringArray2 = stringArray;
            int n = stringArray.length;
            for (int i = 0; i < n; ++i) {
                String string2 = stringArray2[i];
                for (int j = 0; j < string2.toCharArray().length; ++j) {
                    char c2 = string2.toCharArray()[j];
                    if (!String.valueOf(c2).equals("\u00a7") || j >= string2.toCharArray().length - 1) continue;
                    c = string2.toCharArray()[j + 1];
                }
                StringBuilder stringBuilder = new StringBuilder();
                if ((double)this.getStringWidth(stringBuilder.append((String)object).append(string2).append(" ").toString()) < d) {
                    object = (String)object + string2 + " ";
                    continue;
                }
                arrayList.add(object);
                object = c + string2 + " ";
            }
            if (((String)object).length() > 0) {
                if ((double)this.getStringWidth((String)object) < d) {
                    arrayList.add(c + (String)object + " ");
                    object = "";
                } else {
                    for (String string2 : this.formatString((String)object, d)) {
                        arrayList.add(string2);
                    }
                }
            }
        } else {
            arrayList.add(string);
        }
        return arrayList;
    }

    public List formatString(String string, double d) {
        ArrayList<String> arrayList = new ArrayList<String>();
        Object object = "";
        char c = '\uffff';
        char[] cArray = string.toCharArray();
        for (int i = 0; i < cArray.length; ++i) {
            StringBuilder stringBuilder;
            char c2 = cArray[i];
            if (String.valueOf(c2).equals("\u00a7") && i < cArray.length - 1) {
                c = cArray[i + 1];
            }
            if ((double)this.getStringWidth((stringBuilder = new StringBuilder()).append((String)object).append(c2).toString()) < d) {
                object = (String)object + c2;
                continue;
            }
            arrayList.add((String)object);
            object = "" + c + c2;
        }
        if (((String)object).length() > 0) {
            arrayList.add((String)object);
        }
        return arrayList;
    }

    private void setupMinecraftColorcodes() {
        for (int i = 0; i < 32; ++i) {
            int n = (i >> 3 & 1) * 85;
            int n2 = (i >> 2 & 1) * 170 + n;
            int n3 = (i >> 1 & 1) * 170 + n;
            int n4 = (i >> 0 & 1) * 170 + n;
            if (i == 6) {
                n2 += 85;
            }
            if (i >= 16) {
                n2 /= 4;
                n3 /= 4;
                n4 /= 4;
            }
            this.colorCode[i] = (n2 & 0xFF) << 16 | (n3 & 0xFF) << 8 | n4 & 0xFF;
        }
    }
}
