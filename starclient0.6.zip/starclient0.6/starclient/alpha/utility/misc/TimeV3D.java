package starclient.alpha.utility.misc;

import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class TimeV3D
extends Vec3d {
    private final long time;

    public TimeV3D(double d, double d2, double d3, long l) {
        super(d, d2, d3);
        this.time = l;
    }

    public TimeV3D(Vec3i vec3i, long l) {
        super(vec3i);
        this.time = l;
    }

    public long getTime() {
        return this.time;
    }
}
