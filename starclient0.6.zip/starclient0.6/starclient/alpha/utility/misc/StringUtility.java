package starclient.alpha.utility.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Arrays;
import starclient.alpha.utility.Utility;

public class StringUtility
implements Utility {
    public static String getDigits(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            if (!Character.isDigit(c)) continue;
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }

    public static String getStringRedColor(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        Arrays.asList(string2.split(" ")).forEach(string -> stringBuilder.append(ChatFormatting.RED).append((String)string).append(" "));
        return stringBuilder.toString().trim();
    }
}
