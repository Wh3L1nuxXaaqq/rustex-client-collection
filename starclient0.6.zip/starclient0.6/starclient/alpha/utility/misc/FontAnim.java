package starclient.alpha.utility.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class FontAnim {
    private List<String> texts = new ArrayList<String>();
    public String done = "";
    private int delay = 0;

    public FontAnim(int n, List<String> list) {
        this.delay = n;
        this.texts = list;
        this.start();
    }

    public void start() {
        CompletableFuture.runAsync(() -> {
            try {
                int n = 0;
                while (true) {
                    int n2;
                    for (n2 = 0; n2 < this.texts.get(n).length(); ++n2) {
                        this.done = this.done + this.texts.get(n).charAt(n2);
                        Thread.sleep(100L);
                    }
                    Thread.sleep(this.delay);
                    for (n2 = this.done.length(); n2 >= 0; --n2) {
                        this.done = this.done.substring(0, n2);
                        Thread.sleep(60L);
                    }
                    if (n >= this.texts.size() - 1) {
                        n = 0;
                    }
                    ++n;
                    Thread.sleep(400L);
                }
            }
            catch (InterruptedException interruptedException) {
                throw new RuntimeException(interruptedException);
            }
        });
    }
}
