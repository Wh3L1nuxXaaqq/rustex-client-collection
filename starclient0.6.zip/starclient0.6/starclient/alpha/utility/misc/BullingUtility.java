package starclient.alpha.utility.misc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import net.minecraft.client.Minecraft;
import starclient.alpha.utility.misc.ChatUtility;

public class BullingUtility {
    private static final File bullingFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\killmessages.star");

    public static CompletableFuture<String> bull() {
        return CompletableFuture.supplyAsync(() -> {
            String string;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((InputStream)new FileInputStream(String.valueOf(Minecraft.getMinecraft().mcDataDir) + "\\StarClient\\killmessages.star"), StandardCharsets.UTF_8));
            try {
                String string2;
                ArrayList<String> arrayList = new ArrayList<String>();
                while ((string2 = bufferedReader.readLine()) != null) {
                    arrayList.add(string2);
                }
                if (arrayList.isEmpty()) {
                    ChatUtility.addChatMessage("\u0424\u0430\u0439\u043b \u043f\u0443\u0441\u0442.");
                }
                Collections.shuffle(arrayList);
                Random random = new Random();
                int n = random.nextInt(arrayList.size());
                string = (String)arrayList.get(n);
            }
            catch (Throwable throwable) {
                try {
                    try {
                        bufferedReader.close();
                    }
                    catch (Throwable throwable2) {
                        throwable.addSuppressed(throwable2);
                    }
                    throw throwable;
                }
                catch (IOException iOException) {
                    ChatUtility.addChatMessage("\u041e\u0448\u0438\u0431\u043a\u0430: " + iOException.getMessage());
                    return null;
                }
            }
            bufferedReader.close();
            return string;
        }, Executors.newSingleThreadExecutor());
    }

    public void init() throws IOException {
        if (!bullingFile.exists()) {
            bullingFile.createNewFile();
        }
    }
}
