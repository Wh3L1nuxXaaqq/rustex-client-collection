package starclient.alpha.utility.misc;

import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import starclient.alpha.StarClient;

public class Discord {
    private static final String discordID = "1330784043356131399";
    private static final DiscordRichPresence discordRichPresence = new DiscordRichPresence();
    private static final DiscordRPC discordRPC = DiscordRPC.INSTANCE;

    public static void startRPC() {
        DiscordEventHandlers discordEventHandlers = new DiscordEventHandlers();
        discordRPC.Discord_Initialize(discordID, discordEventHandlers, true, null);
        Discord.discordRichPresence.startTimestamp = System.currentTimeMillis() / 1000L;
        Discord.discordRichPresence.largeImageKey = "_4_";
        new Thread(() -> {
            while (true) {
                try {
                    while (true) {
                        Discord.discordRichPresence.details = "Version: " + StarClient.VERSION;
                        Discord.discordRichPresence.state = "always on top";
                        discordRPC.Discord_UpdatePresence(discordRichPresence);
                        Thread.sleep(2000L);
                    }
                }
                catch (InterruptedException interruptedException) {
                    continue;
                }
                break;
            }
        }).start();
    }

    public static void stopRPC() {
        discordRPC.Discord_Shutdown();
    }

    public static String getDiscordID() {
        return discordID;
    }

    public static DiscordRichPresence getDiscordRichPresence() {
        return discordRichPresence;
    }

    public static DiscordRPC getDiscordRPC() {
        return discordRPC;
    }
}
