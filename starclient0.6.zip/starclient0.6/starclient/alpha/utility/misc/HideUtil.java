package starclient.alpha.utility.misc;

import java.util.Arrays;
import starclient.alpha.utility.misc.ReflectionsUtility;

public class HideUtil {
    public static void zeroMemory(String string) {
        try {
            Object object = ReflectionsUtility.getValueFromVirtualField(string, String.class.getDeclaredField("value"));
            if (object instanceof byte[]) {
                Arrays.fill((byte[])object, (byte)0);
            } else {
                Arrays.fill((char[])object, '\u0000');
            }
        }
        catch (Throwable throwable) {
            throw new RuntimeException(throwable);
        }
    }
}
