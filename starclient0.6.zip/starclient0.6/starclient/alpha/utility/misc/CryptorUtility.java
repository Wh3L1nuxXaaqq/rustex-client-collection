package starclient.alpha.utility.misc;

import java.security.Key;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptorUtility {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final int IV_LENGTH = 16;

    public static String encrypt(String string, String string2) {
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(string2.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            SecureRandom secureRandom = new SecureRandom();
            byte[] byArray = new byte[16];
            secureRandom.nextBytes(byArray);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(byArray);
            cipher.init(1, (Key)secretKeySpec, ivParameterSpec);
            byte[] byArray2 = cipher.doFinal(string.getBytes());
            byte[] byArray3 = new byte[16 + byArray2.length];
            System.arraycopy(byArray, 0, byArray3, 0, 16);
            System.arraycopy(byArray2, 0, byArray3, 16, byArray2.length);
            return Base64.getEncoder().encodeToString(byArray3);
        }
        catch (Exception exception) {
            System.err.println("Encryption error: " + exception.getMessage());
            return null;
        }
    }

    public static String decrypt(String string, String string2) {
        try {
            byte[] byArray = Base64.getDecoder().decode(string);
            SecretKeySpec secretKeySpec = new SecretKeySpec(string2.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            byte[] byArray2 = new byte[16];
            System.arraycopy(byArray, 0, byArray2, 0, 16);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(byArray2);
            cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
            byte[] byArray3 = cipher.doFinal(byArray, 16, byArray.length - 16);
            return new String(byArray3);
        }
        catch (Exception exception) {
            System.err.println("Decryption error: " + exception.getMessage());
            return null;
        }
    }

    public static String adjustKeyLength(String object) {
        int n = 32;
        if (((String)object).length() < n) {
            while (((String)object).length() < n) {
                object = (String)object + "0";
            }
        } else if (((String)object).length() > n) {
            object = ((String)object).substring(0, n);
        }
        return object;
    }
}
