package starclient.alpha.utility.misc;

import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import net.minecraft.util.ResourceLocation;
import starclient.alpha.utility.Utility;

public class SoundUtility
implements Utility {
    public static synchronized void playSound(String string, float f) {
        try {
            Clip clip = AudioSystem.getClip();
            InputStream inputStream = mc.getResourceManager().getResource(new ResourceLocation("starclient/sounds/" + string)).getInputStream();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(bufferedInputStream);
            clip.open(audioInputStream);
            FloatControl floatControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
            float f2 = (float)(20.0 * Math.log10(f));
            floatControl.setValue(f2);
            clip.start();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}
