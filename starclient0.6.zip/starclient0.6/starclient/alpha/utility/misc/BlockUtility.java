package starclient.alpha.utility.misc;

import com.jhlabs.vecmath.Vector3f;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.BlockFarmland;
import net.minecraft.block.BlockGrass;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.utility.Utility;

public class BlockUtility
implements Utility {
    public static Block getBlock(int n, int n2, int n3) {
        return BlockUtility.mc.world.getBlockState(new BlockPos(n, n2, n3)).getBlock();
    }

    public static Block getBlock(BlockPos blockPos) {
        return BlockUtility.getState(blockPos).getBlock();
    }

    public static IBlockState getState(BlockPos blockPos) {
        return BlockUtility.mc.world.getBlockState(blockPos);
    }

    public static BlockPos getPlayerPosLocal() {
        if (BlockUtility.mc.player == null) {
            return BlockPos.ORIGIN;
        }
        return new BlockPos(Math.floor(BlockUtility.mc.player.posX), Math.floor(BlockUtility.mc.player.posY), Math.floor(BlockUtility.mc.player.posZ));
    }

    public static boolean insideBlock() {
        for (int i = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minX); i < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxX) + 1; ++i) {
            for (int j = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minY); j < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxY) + 1; ++j) {
                for (int k = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minZ); k < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxZ) + 1; ++k) {
                    Block block = BlockUtility.mc.world.getBlockState(new BlockPos(i, j, k)).getBlock();
                    if (block == null || block instanceof BlockAir) continue;
                    AxisAlignedBB axisAlignedBB = block.getCollisionBoundingBox(BlockUtility.mc.world.getBlockState(new BlockPos(i, j, k)), BlockUtility.mc.world, new BlockPos(i, j, k));
                    if (block instanceof BlockHopper) {
                        axisAlignedBB = new AxisAlignedBB(i, j, k, i + 1, j + 1, k + 1);
                    }
                    if (axisAlignedBB == null || !BlockUtility.mc.player.getEntityBoundingBox().intersectsWith(axisAlignedBB)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean blockIsSlipperiness() {
        return BlockUtility.mc.world.getBlockState((BlockPos)new BlockPos((double)BlockUtility.mc.player.posX, (double)(BlockUtility.mc.player.posY - 1.0), (double)BlockUtility.mc.player.posZ)).getBlock().slipperiness == 0.98f;
    }

    public static boolean rayTrace(BlockPos blockPos, float f, float f2) {
        Vec3d vec3d = BlockUtility.mc.player.getPositionEyes(1.0f);
        Vec3d vec3d2 = Entity.getVectorForRotation(f2, f);
        Vec3d vec3d3 = vec3d.add(vec3d2.x * 5.0, vec3d2.y * 5.0, vec3d2.z * 5.0);
        RayTraceResult rayTraceResult = BlockUtility.mc.world.rayTraceBlocks(vec3d, vec3d3, false);
        return rayTraceResult != null && rayTraceResult.typeOfHit == RayTraceResult.Type.BLOCK && blockPos.equals(rayTraceResult.getBlockPos());
    }

    public static boolean isAboveLiquid(Entity entity, double d) {
        if (entity == null) {
            return false;
        }
        double d2 = entity.posY + d;
        for (int i = MathHelper.floor(entity.posX); i < MathHelper.ceil(entity.posX); ++i) {
            for (int j = MathHelper.floor(entity.posZ); j < MathHelper.ceil(entity.posZ); ++j) {
                if (!(BlockUtility.mc.world.getBlockState(new BlockPos(i, (int)d2, j)).getBlock() instanceof BlockLiquid)) continue;
                return true;
            }
        }
        return false;
    }

    public static boolean collideBlock(AxisAlignedBB axisAlignedBB, float f, ICollide iCollide) {
        for (int i = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minX); i < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxX) + 1; ++i) {
            for (int j = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minZ); j < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxZ) + 1; ++j) {
                Block block = BlockUtility.getBlock(new BlockPos((double)i, axisAlignedBB.minY + (double)f, (double)j));
                if (iCollide.collideBlock(block)) continue;
                return false;
            }
        }
        return true;
    }

    public static boolean collideBlockIntersects(AxisAlignedBB axisAlignedBB, ICollide iCollide) {
        for (int i = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minX); i < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxX) + 1; ++i) {
            for (int j = MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().minZ); j < MathHelper.floor(BlockUtility.mc.player.getEntityBoundingBox().maxZ) + 1; ++j) {
                AxisAlignedBB axisAlignedBB2;
                BlockPos blockPos = new BlockPos((double)i, axisAlignedBB.minY, (double)j);
                Block block = BlockUtility.getBlock(blockPos);
                if (block == null || !iCollide.collideBlock(block) || (axisAlignedBB2 = block.getCollisionBoundingBox(BlockUtility.getState(blockPos), BlockUtility.mc.world, blockPos)) == null || !BlockUtility.mc.player.getEntityBoundingBox().intersectsWith(axisAlignedBB2)) continue;
                return true;
            }
        }
        return false;
    }

    public static Vector3f getBlock(float f, int n) {
        Vector3f vector3f = null;
        float f2 = f;
        for (float f3 = f; f3 >= -f; f3 -= 1.0f) {
            for (float f4 = -f; f4 <= f; f4 += 1.0f) {
                for (float f5 = f; f5 >= -f; f5 -= 1.0f) {
                    int n2 = (int)(BlockUtility.mc.player.posX + (double)f3);
                    int n3 = (int)(BlockUtility.mc.player.posY + (double)f4);
                    int n4 = (int)(BlockUtility.mc.player.posZ + (double)f5);
                    float f6 = (float)BlockUtility.mc.player.getDistance(n2, n3, n4);
                    if (Block.getIdFromBlock(BlockUtility.getBlock(n2, n3 - 1, n4)) != n || !(BlockUtility.getBlock(n2, n3, n4) instanceof BlockAir) || !(f6 <= f2)) continue;
                    f2 = f6;
                    vector3f = new Vector3f(n2, n3, n4);
                }
            }
        }
        return vector3f;
    }

    public static boolean IsValidBlockPos(BlockPos blockPos) {
        IBlockState iBlockState = BlockUtility.mc.world.getBlockState(blockPos);
        if (iBlockState.getBlock() instanceof BlockDirt || iBlockState.getBlock() instanceof BlockGrass && !(iBlockState.getBlock() instanceof BlockFarmland)) {
            return BlockUtility.mc.world.getBlockState(blockPos.up()).getBlock() == Blocks.AIR;
        }
        return false;
    }

    public static List<BlockPos> getSphere(BlockPos blockPos, float f, int n, boolean bl, boolean bl2, int n2) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        int n3 = blockPos.getX();
        int n4 = blockPos.getY();
        int n5 = blockPos.getZ();
        int n6 = n3 - (int)f;
        while ((float)n6 <= (float)n3 + f) {
            int n7 = n5 - (int)f;
            while ((float)n7 <= (float)n5 + f) {
                int n8 = bl2 ? n4 - (int)f : n4;
                while (true) {
                    float f2 = bl2 ? (float)n4 + f : (float)(n4 + n);
                    float f3 = f2;
                    if (!((float)n8 < f2)) break;
                    double d = (n3 - n6) * (n3 - n6) + (n5 - n7) * (n5 - n7) + (bl2 ? (n4 - n8) * (n4 - n8) : 0);
                    if (!(!(d < (double)(f * f)) || bl && d < (double)((f - 1.0f) * (f - 1.0f)))) {
                        BlockPos blockPos2 = new BlockPos(n6, n8 + n2, n7);
                        arrayList.add(blockPos2);
                    }
                    ++n8;
                }
                ++n7;
            }
            ++n6;
        }
        return arrayList;
    }

    public static ArrayList<BlockPos> getBlocks(int n, int n2, int n3) {
        if (BlockUtility.mc.player != null && BlockUtility.mc.world != null) {
            BlockPos blockPos = new BlockPos(BlockUtility.mc.player.posX - (double)n, BlockUtility.mc.player.posY - (double)n2, BlockUtility.mc.player.posZ - (double)n3);
            BlockPos blockPos2 = new BlockPos(BlockUtility.mc.player.posX + (double)n, BlockUtility.mc.player.posY + (double)n2, BlockUtility.mc.player.posZ + (double)n3);
            return BlockUtility.getAllInBox(blockPos, blockPos2);
        }
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        arrayList.add(new BlockPos(0, 0, 0));
        return arrayList;
    }

    public static ArrayList<BlockPos> getBlocks(float f, float f2, float f3) {
        if (BlockUtility.mc.player != null && BlockUtility.mc.world != null) {
            BlockPos blockPos = new BlockPos(BlockUtility.mc.player.posX - (double)f, BlockUtility.mc.player.posY - (double)f2, BlockUtility.mc.player.posZ - (double)f3);
            BlockPos blockPos2 = new BlockPos(BlockUtility.mc.player.posX + (double)f, BlockUtility.mc.player.posY + (double)f2, BlockUtility.mc.player.posZ + (double)f3);
            return BlockUtility.getAllInBox(blockPos, blockPos2);
        }
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        arrayList.add(new BlockPos(0, 0, 0));
        return arrayList;
    }

    public static ArrayList<BlockPos> getAllInBox(BlockPos blockPos, BlockPos blockPos2) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        BlockPos blockPos3 = new BlockPos(Math.min(blockPos.getX(), blockPos2.getX()), Math.min(blockPos.getY(), blockPos2.getY()), Math.min(blockPos.getZ(), blockPos2.getZ()));
        BlockPos blockPos4 = new BlockPos(Math.max(blockPos.getX(), blockPos2.getX()), Math.max(blockPos.getY(), blockPos2.getY()), Math.max(blockPos.getZ(), blockPos2.getZ()));
        for (int i = blockPos3.getX(); i <= blockPos4.getX(); ++i) {
            for (int j = blockPos3.getY(); j <= blockPos4.getY(); ++j) {
                for (int k = blockPos3.getZ(); k <= blockPos4.getZ(); ++k) {
                    arrayList.add(new BlockPos(i, j, k));
                }
            }
        }
        return arrayList;
    }

    public static interface ICollide {
        public boolean collideBlock(Block var1);
    }
}
