package starclient.alpha.utility.misc;

import java.net.InetAddress;

public class PingUtility {
    public static long ping;

    public static long getPing(String string) {
        try {
            InetAddress inetAddress = InetAddress.getByName(string);
            long l = System.currentTimeMillis();
            boolean bl = inetAddress.isReachable(5000);
            if (bl) {
                long l2 = System.currentTimeMillis();
                ping = l2 - l;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return ping;
    }
}
