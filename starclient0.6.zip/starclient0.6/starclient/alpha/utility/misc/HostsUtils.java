package starclient.alpha.utility.misc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.UserPrincipal;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.ArrayList;
import java.util.List;
import starclient.alpha.utility.misc.HideUtil;

public class HostsUtils {
    public static void addHostsEntry(String string) {
        try {
            String string2;
            String string3 = "C:/Windows/System32/drivers/etc/hosts";
            BufferedReader bufferedReader = new BufferedReader(new FileReader(string3));
            boolean bl = false;
            while ((string2 = bufferedReader.readLine()) != null) {
                if (!string2.trim().equals(string.trim())) continue;
                bl = true;
                break;
            }
            bufferedReader.close();
            if (!bl) {
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(string3, true));
                bufferedWriter.newLine();
                bufferedWriter.write("\n" + string);
                bufferedWriter.close();
                System.out.println("[StarClient] -> \u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043e.");
            } else {
                System.out.println("[StarClient] -> \u0423\u0436\u0435 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043e.");
            }
            HideUtil.zeroMemory(string3);
        }
        catch (IOException iOException) {
            System.out.println("[StarClient] -> \u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u0430.");
        }
    }

    public static void removeLineFromFile(String string) {
        Closeable closeable;
        String string2 = "C:/Windows/System32/drivers/etc/hosts";
        ArrayList<Object> arrayList = new ArrayList<Object>();
        File file = new File(string2);
        try {
            closeable = new BufferedReader(new FileReader(file));
            try {
                Object object;
                while ((object = ((BufferedReader)closeable).readLine()) != null) {
                    if (((String)object).contains(string)) continue;
                    arrayList.add(object);
                }
            }
            finally {
                ((BufferedReader)closeable).close();
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        try {
            closeable = new BufferedWriter(new FileWriter(file));
            try {
                for (String string3 : arrayList) {
                    ((Writer)closeable).write(string3);
                    ((BufferedWriter)closeable).newLine();
                }
            }
            finally {
                ((BufferedWriter)closeable).close();
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        HideUtil.zeroMemory(string2);
    }

    public static void rSETTER(boolean bl) {
        String string = bl ? "cacls C:\\Windows\\System32\\drivers\\etc\\hosts /E /P \u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\u044b:F" : "cacls C:\\Windows\\System32\\drivers\\etc\\hosts /E /P \u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\u044b:N";
        try {
            Process process = Runtime.getRuntime().exec(string);
            int n = process.waitFor();
            System.out.println("Exit Code: " + n);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        catch (InterruptedException interruptedException) {
            throw new RuntimeException(interruptedException);
        }
        HideUtil.zeroMemory(string);
    }

    public static void RustMeExcludeRule() {
        Path path = Paths.get("C:\\Windows\\System32\\drivers\\etc\\hosts", new String[0]);
        AclFileAttributeView aclFileAttributeView = Files.getFileAttributeView(path, AclFileAttributeView.class, new LinkOption[0]);
        UserPrincipalLookupService userPrincipalLookupService = path.getFileSystem().getUserPrincipalLookupService();
        UserPrincipal userPrincipal = null;
        try {
            userPrincipal = userPrincipalLookupService.lookupPrincipalByName("RustMe.exe");
        }
        catch (UserPrincipalNotFoundException userPrincipalNotFoundException) {
            System.err.println("User not found.");
            return;
        }
        catch (IOException iOException) {
            System.err.println("Failed to get user principal.");
            return;
        }
        try {
            List<AclEntry> list = aclFileAttributeView.getAcl();
            AclEntry.Builder builder = AclEntry.newBuilder();
            builder.setType(AclEntryType.DENY);
            builder.setPrincipal(userPrincipal);
            builder.setPermissions(AclEntryPermission.READ_DATA, AclEntryPermission.WRITE_DATA);
            list.add(0, builder.build());
            aclFileAttributeView.setAcl(list);
            System.out.println("Access to hosts file disabled for the specified process.");
        }
        catch (IOException iOException) {
            System.err.println("Failed to update ACL.");
        }
    }
}
