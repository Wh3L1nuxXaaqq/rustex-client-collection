package starclient.alpha.utility.misc;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import sun.misc.Unsafe;

public class ReflectionsUtility {
    private static final Unsafe UNSAFE;

    public static Object getValueFromStaticField(Field field) {
        long l = UNSAFE.staticFieldOffset(field);
        Object object = UNSAFE.staticFieldBase(field);
        return UNSAFE.getObject(object, l);
    }

    public static Object getValueFromVirtualField(Object object, Field field) {
        long l = UNSAFE.objectFieldOffset(field);
        return UNSAFE.getObject(object, l);
    }

    public static MethodHandles.Lookup obtainAllMightyLookup() throws NoSuchFieldException {
        Field field = MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP");
        return (MethodHandles.Lookup)ReflectionsUtility.getValueFromStaticField(field);
    }

    static {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            UNSAFE = (Unsafe)field.get(null);
        }
        catch (IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            throw new RuntimeException(reflectiveOperationException);
        }
    }
}
