package starclient.alpha.utility.misc;

import java.io.IOException;

public class ProcessUtil {
    public static void killProcess(String string) throws IOException {
        Runtime.getRuntime().exec("taskkill /f /im " + string);
    }

    public static void dispatchCommand(String string) throws IOException {
        Runtime.getRuntime().exec(string);
    }
}
