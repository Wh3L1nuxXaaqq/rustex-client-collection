package starclient.alpha.utility.misc;

public class TimerHelper {
    private long lastMS = System.currentTimeMillis();

    public boolean hasReached(double d) {
        return (double)(System.currentTimeMillis() - this.lastMS) >= d;
    }

    public boolean hasReached(boolean bl, double d) {
        return bl || this.hasReached(d);
    }

    public long getLastMS() {
        return this.lastMS;
    }

    public void reset() {
        this.lastMS = System.currentTimeMillis();
    }

    public long getTimePassed() {
        return System.currentTimeMillis() - this.lastMS;
    }

    public long getCurrentTime() {
        return System.nanoTime() / 1000000L;
    }

    public void setTime(long l) {
        this.lastMS = l;
    }
}
