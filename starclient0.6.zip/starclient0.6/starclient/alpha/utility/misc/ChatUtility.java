package starclient.alpha.utility.misc;

import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.utility.Utility;

public class ChatUtility
implements Utility {
    public static String chatPrefix = String.valueOf((Object)TextFormatting.BLUE) + StarClient.NAME + String.valueOf((Object)TextFormatting.GRAY) + " >>> " + String.valueOf((Object)TextFormatting.RESET);

    public static void addChatMessage(String string) {
        ChatUtility.mc.player.addChatMessage(new TextComponentString(chatPrefix + string));
    }

    public static void sendChatMessage(String string) {
        ChatUtility.mc.player.sendChatMessage(string);
    }
}
