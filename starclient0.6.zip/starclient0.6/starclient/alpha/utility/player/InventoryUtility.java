package starclient.alpha.utility.player;

import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import starclient.alpha.utility.Utility;

public class InventoryUtility
implements Utility {
    public static boolean doesHotbarHaveAxe() {
        for (int i = 0; i < 9; ++i) {
            InventoryUtility.mc.player.inventory.getStackInSlot(i);
            if (!(InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemAxe)) continue;
            return true;
        }
        return false;
    }

    public static int getAxe() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtility.mc.player.inventory.getStackInSlot(i);
            if (!(itemStack.getItem() instanceof ItemAxe)) continue;
            return i;
        }
        return 1;
    }

    public static int getItemSlot(Item item, boolean bl) {
        for (int i = 0; i < (bl ? 9 : 45); ++i) {
            if (InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem() != item) continue;
            return i;
        }
        return -1;
    }

    public static int getItemSlot(Item item) {
        if (item == InventoryUtility.mc.player.getHeldItemOffhand().getItem()) {
            return -2;
        }
        for (int i = 36; i >= 0; --i) {
            Item item2 = InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem();
            if (item2 != item) continue;
            if (i < 9) {
                i += 36;
            }
            return i;
        }
        return -1;
    }
}
