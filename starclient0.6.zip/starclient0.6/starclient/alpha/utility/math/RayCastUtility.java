package starclient.alpha.utility.math;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.util.vector.Vector2f;
import starclient.alpha.utility.Utility;

public class RayCastUtility
implements Utility {
    public static Entity getPointedEntity(Vector2f vector2f, double d, float f, boolean bl, Entity entity) {
        double d2;
        EntityPlayerSP entityPlayerSP = RayCastUtility.mc.player;
        RayTraceResult rayTraceResult = RayCastUtility.rayTrace(d, vector2f.x, vector2f.y, bl);
        Vec3d vec3d = entityPlayerSP.getPositionEyes(1.0f);
        boolean bl2 = false;
        double d3 = d;
        if (rayTraceResult != null) {
            d3 = rayTraceResult.hitVec.distanceTo(vec3d);
        }
        Vec3d vec3d2 = RayCastUtility.getLook(vector2f.x, vector2f.y);
        Vec3d vec3d3 = vec3d.add(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d);
        Entity entity2 = null;
        Vec3d vec3d4 = null;
        double d4 = d3;
        float f2 = entity.width;
        float f3 = entity.height;
        AxisAlignedBB axisAlignedBB = entity.getEntityBoundingBox().grow(entity.getCollisionBorderSize());
        RayTraceResult rayTraceResult2 = axisAlignedBB.calculateIntercept(vec3d, vec3d3);
        if (axisAlignedBB.contains(vec3d)) {
            if (d3 >= 0.0) {
                entity2 = entity;
                vec3d4 = rayTraceResult2 == null ? vec3d : rayTraceResult2.hitVec;
                d4 = 0.0;
            }
        } else if (rayTraceResult2 != null && ((d2 = vec3d.distanceTo(rayTraceResult2.hitVec)) < d3 || d3 == 0.0)) {
            boolean bl3 = false;
            if (!bl3 && entity.getLowestRidingEntity() == entityPlayerSP.getLowestRidingEntity()) {
                if (d3 == 0.0) {
                    entity2 = entity;
                    vec3d4 = rayTraceResult2.hitVec;
                }
            } else {
                entity2 = entity;
                vec3d4 = rayTraceResult2.hitVec;
                d4 = d2;
            }
        }
        if (entity2 != null && bl2 && vec3d.distanceTo(vec3d4) > d) {
            entity2 = null;
            rayTraceResult = new RayTraceResult(RayTraceResult.Type.MISS, vec3d4, null, new BlockPos(vec3d4));
        }
        if (entity2 != null && (d4 < d3 || rayTraceResult == null)) {
            rayTraceResult = new RayTraceResult(entity2, vec3d4);
        }
        return rayTraceResult != null ? (rayTraceResult.entityHit instanceof Entity ? rayTraceResult.entityHit : null) : null;
    }

    public static RayTraceResult rayTrace(double d, float f, float f2, boolean bl) {
        if (!bl) {
            return null;
        }
        Vec3d vec3d = RayCastUtility.mc.player.getPositionEyes(1.0f);
        Vec3d vec3d2 = RayCastUtility.getLook(f, f2);
        Vec3d vec3d3 = vec3d.add(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d);
        return RayCastUtility.mc.world.rayTraceBlocks(vec3d, vec3d3, true, true, true);
    }

    static Vec3d getVectorForRotation(float f, float f2) {
        float f3 = MathHelper.cos(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f4 = MathHelper.sin(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f5 = -MathHelper.cos(-f * ((float)Math.PI / 180));
        float f6 = MathHelper.sin(-f * ((float)Math.PI / 180));
        return new Vec3d(f4 * f5, f6, f3 * f5);
    }

    static Vec3d getLook(float f, float f2) {
        return RayCastUtility.getVectorForRotation(f2, f);
    }
}
