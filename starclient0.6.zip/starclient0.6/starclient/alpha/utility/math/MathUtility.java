package starclient.alpha.utility.math;

import java.math.BigDecimal;
import java.math.RoundingMode;
import starclient.alpha.utility.Utility;

public class MathUtility
implements Utility {
    public static float clamp(float f, float f2, float f3) {
        if (f <= f2) {
            f = f2;
        }
        if (f >= f3) {
            f = f3;
        }
        return f;
    }

    public static double round(double d, double d2) {
        double d3 = (double)Math.round(d / d2) * d2;
        BigDecimal bigDecimal = new BigDecimal(d3);
        bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

    public static float randomizeFloat(float f, float f2) {
        return (float)(Math.random() * (double)(f2 - f)) + f;
    }

    public static double getDistance(double d, double d2, double d3, double d4) {
        return Math.sqrt(Math.pow(d3 - d, 2.0) + Math.pow(d4 - d2, 2.0));
    }

    public static float lerp(float f, float f2, float f3) {
        return f + f3 * (f2 - f);
    }

    public static int getMiddle(int n, int n2) {
        return (n + n2) / 2;
    }

    public static int getRandomInRange(int n, int n2) {
        return (int)(Math.random() * (double)(n2 - n) + (double)n);
    }

    public static boolean inRange(int n, int n2, int n3) {
        return n3 >= n && n3 <= n2;
    }
}
