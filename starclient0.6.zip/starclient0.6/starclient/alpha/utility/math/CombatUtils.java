package starclient.alpha.utility.math;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.StarClient;
import starclient.alpha.event.misc.EventDetectBot;
import starclient.alpha.module.impl.combat.TestAim;

public class CombatUtils {
    public static EntityLivingBase target;
    public static ArrayList<Entity> bots;
    public static ArrayList<String> friends;
    public static Minecraft mc;
    public static Vec3d hitBoxResult;

    private static Entity getTarget() {
        try {
            float f = TestAim.fov_range.get();
            boolean bl = TestAim.smart_hitbox.get();
            boolean bl2 = TestAim.prediction.get();
            if (CombatUtils.mc.world == null || CombatUtils.mc.player == null || !StarClient.getInstance().getModuleManager().getModule(TestAim.class).isEnabled()) {
                return null;
            }
            ArrayList<EntityLivingBase> arrayList = new ArrayList<EntityLivingBase>();
            for (Entity entity : CombatUtils.mc.world.loadedEntityList) {
                if (!(entity instanceof EntityLivingBase) || entity instanceof EntityAnimal || entity instanceof EntityArmorStand) continue;
                arrayList.add((EntityLivingBase)entity);
            }
            for (EntityLivingBase entityLivingBase : arrayList) {
                boolean bl3;
                hitBoxResult = null;
                if (entityLivingBase == null || entityLivingBase == CombatUtils.mc.player || CombatUtils.isFriend(entityLivingBase) || CombatUtils.isBot(entityLivingBase) || entityLivingBase.isDead || entityLivingBase.getHealth() <= 0.0f || !entityLivingBase.isEntityAlive()) continue;
                float f2 = CombatUtils.mc.player.getDistanceToEntity(entityLivingBase);
                if (TestAim.fov.get() && CombatUtils.mc.player.getDistanceToEntity(entityLivingBase) > TestAim.no_fov_distance.get()) {
                    float[] fArray = CombatUtils.rotationsPro(entityLivingBase, false, false, false, 0.0f, bl2 ? TestAim.xPredict : 1.0f, bl2 ? TestAim.yPredict : 1.0f);
                    float f3 = Math.abs(fArray[1] - CombatUtils.mc.player.rotationPitch);
                    float f4 = Math.abs(fArray[0] - CombatUtils.mc.player.rotationYaw);
                    boolean bl4 = Math.abs(CombatUtils.distance2D(new Vec2f(f4, f3), new Vec2f(0.0f, 0.0f))) <= f / 85.0f * CombatUtils.mc.gameSettings.fovSetting;
                    if (!bl4) continue;
                }
                if (bl) {
                    hitBoxResult = CombatUtils.getSeeHitboxResult(entityLivingBase, true, TestAim.points_h.get(), TestAim.points_v.get(), bl2 ? TestAim.xPredict : 0.0f, bl2 ? TestAim.yPredict : 0.0f);
                }
                if (!(bl3 = hitBoxResult != null || !bl && CombatUtils.getAimPos(entityLivingBase, true, bl2 ? TestAim.xPredict : 0.0f, bl2 ? TestAim.yPredict : 0.0f) != null)) continue;
                return entityLivingBase;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
        return null;
    }

    public static float[] rotations(Entity entity, boolean bl, boolean bl2, float f, float f2, float f3) {
        if (entity == null) {
            return new float[]{CombatUtils.mc.player.rotationYaw, CombatUtils.mc.player.rotationPitch};
        }
        try {
            Vec3d vec3d = bl ? CombatUtils.getSeeHitboxResult(entity, bl2, TestAim.points_h.get(), TestAim.points_v.get(), f2, f3) : CombatUtils.getAimPos(entity, bl2, f2, f3);
            double d = vec3d.xCoord - CombatUtils.mc.player.posX;
            double d2 = vec3d.yCoord - CombatUtils.mc.player.posY + (double)f - 1.625;
            double d3 = vec3d.zCoord - CombatUtils.mc.player.posZ;
            double d4 = MathHelper.sqrt(d * d + d3 * d3);
            float f4 = (float)(MathHelper.atan2(d3, d) * 57.29577951308232 - 90.0);
            float f5 = (float)(-MathHelper.atan2(d2, d4) * 57.29577951308232);
            return new float[]{f4, f5};
        }
        catch (Exception exception) {
            return new float[]{CombatUtils.mc.player.rotationYaw, CombatUtils.mc.player.rotationPitch};
        }
    }

    public static float[] rotationsPro(Entity entity, boolean bl, boolean bl2, boolean bl3, float f, float f2, float f3) {
        if (entity == null) {
            return new float[]{CombatUtils.mc.player.rotationYaw, CombatUtils.mc.player.rotationPitch};
        }
        float f4 = bl ? CombatUtils.mc.player.rotationYawHead : CombatUtils.mc.player.rotationYaw;
        float[] fArray = CombatUtils.rotations(entity, bl2, bl3, f, f2, f3);
        float f5 = MathHelper.wrapDegrees(f4 - fArray[0]);
        return new float[]{f4 - f5, fArray[1]};
    }

    public static float distance2D(Vec2f vec2f, Vec2f vec2f2) {
        float f = vec2f.x - vec2f2.x;
        float f2 = vec2f.y - vec2f2.y;
        return (float)Math.sqrt(f * f + f2 * f2);
    }

    public static Vec3d getAimPos(Entity entity, boolean bl, float f, float f2) {
        double d = entity.posX + (entity.posX - entity.lastTickPosX) * (double)f;
        double d2 = entity.posY + (entity.posY - entity.lastTickPosY) * (double)f2 + (double)entity.getEyeHeight();
        double d3 = entity.posZ + (entity.posZ - entity.lastTickPosZ) * (double)f;
        if (!bl) {
            return new Vec3d(d, d2, d3);
        }
        return CombatUtils.mc.player.canEntityBeSeen(d, d2, d3) ? new Vec3d(d, d2, d3) : null;
    }

    public static Vec3d getSeeHitboxResult(Entity entity, boolean bl, float f, float f2, float f3, float f4) {
        AxisAlignedBB axisAlignedBB = entity.getEntityBoundingBox();
        double d = (entity.posX - entity.lastTickPosX) * (double)f3;
        double d2 = (entity.posY - entity.lastTickPosY) * (double)f4;
        double d3 = (entity.posZ - entity.lastTickPosZ) * (double)f3;
        double d4 = axisAlignedBB.minX + d;
        double d5 = axisAlignedBB.minY + d2;
        double d6 = axisAlignedBB.minZ + d3;
        double d7 = axisAlignedBB.maxX + d;
        double d8 = d5 + (axisAlignedBB.maxY - d5) * (double)TestAim.y_priority.get() + d2;
        double d9 = axisAlignedBB.maxZ + d3;
        double d10 = d4 + (d7 - d4) / 2.0;
        double d11 = d6 + (d9 - d6) / 2.0;
        double d12 = entity.width / (float)((int)f);
        double d13 = entity.height / (float)((int)f2);
        Vec3d vec3d = null;
        ArrayList<Vec3d> arrayList = new ArrayList<Vec3d>();
        double d14 = CombatUtils.mc.player.posX - entity.posX;
        double d15 = CombatUtils.mc.player.posZ - entity.posZ;
        double d16 = entity.posY + (double)(entity.height / 2.0f) + (double)(entity.height / 2.0f) * 0.5;
        for (double d17 = d8; d17 >= d5; d17 -= d13) {
            double d18;
            for (d18 = d4; d18 <= d7; d18 += d12) {
                if (d15 >= 0.0) {
                    if (!CombatUtils.mc.player.canEntityBeSeen(d18, d17, d9) && bl) continue;
                    arrayList.add(new Vec3d(d18, d17, d9));
                    continue;
                }
                if (!CombatUtils.mc.player.canEntityBeSeen(d18, d17, d6) && bl) continue;
                arrayList.add(new Vec3d(d18, d17, d6));
            }
            for (d18 = d6; d18 <= d9; d18 += d12) {
                if (d14 >= 0.0) {
                    if (!CombatUtils.mc.player.canEntityBeSeen(d7, d17, d18) && bl) continue;
                    arrayList.add(new Vec3d(d7, d17, d18));
                    continue;
                }
                if (!CombatUtils.mc.player.canEntityBeSeen(d4, d17, d18) && bl) continue;
                arrayList.add(new Vec3d(d4, d17, d18));
            }
            Vec3d vec3d2 = new Vec3d(CombatUtils.mc.player.posX, CombatUtils.mc.player.posY + (double)CombatUtils.mc.player.getEyeHeight(), CombatUtils.mc.player.posZ);
            boolean bl2 = Math.abs(CombatUtils.mc.player.posX - d7) < Math.abs(CombatUtils.mc.player.posZ - d9);
            boolean bl3 = Math.abs(CombatUtils.mc.player.posX - d4) < Math.abs(CombatUtils.mc.player.posZ - d6);
            for (Vec3d vec3d3 : arrayList) {
                if (vec3d == null) {
                    vec3d = vec3d3;
                    continue;
                }
                if ((!(Math.abs(vec3d3.xCoord - d10) < Math.abs(vec3d.xCoord - d10)) || !bl3 && !bl2) && (!(Math.abs(vec3d3.zCoord - d11) < Math.abs(vec3d.zCoord - d11)) || bl3 && bl2)) continue;
                vec3d = vec3d3;
            }
            if (vec3d == null) continue;
            return new Vec3d(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
        }
        return null;
    }

    public static void updateTarget() {
        hitBoxResult = null;
        target = (EntityLivingBase)CombatUtils.getTarget();
    }

    public static boolean detectBot(Entity entity, boolean bl, float f) {
        if (CombatUtils.isBot(entity)) {
            return false;
        }
        if (((EventCancellable)EventManager.call(new EventDetectBot(entity, f))).isCancelled()) {
            return false;
        }
        bots.add(entity);
        if (bl) {
            CombatUtils.mc.world.removeEntity(entity);
        }
        return false;
    }

    public static boolean isBot(Entity entity) {
        for (Entity entity2 : bots) {
            if (!entity2.equals(entity)) continue;
            return true;
        }
        return false;
    }

    public static boolean isFriend(Entity entity) {
        for (String string : friends) {
            if (!string.equalsIgnoreCase(entity.getName())) continue;
            return true;
        }
        return false;
    }

    public static boolean isFriend(String string) {
        for (String string2 : friends) {
            if (!string2.equalsIgnoreCase(string)) continue;
            return true;
        }
        return false;
    }

    public static void addFriend(String string) {
        if (!CombatUtils.isFriend(string)) {
            friends.add(string);
        }
    }

    public static void removeFriend(String string) {
        friends.removeIf(string2 -> string2.equals(string));
    }

    static {
        bots = new ArrayList();
        friends = new ArrayList();
        mc = Minecraft.getMinecraft();
    }
}
