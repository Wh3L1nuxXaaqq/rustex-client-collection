package starclient.alpha.utility.math;

import java.util.Random;

public class RandomUtility {
    private static final Random random = new Random();

    public static String randomString(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        char[] cArray = "qwertyuiopasdfghjklzxcvbnm1234567890".toCharArray();
        for (int i = 0; i < n; ++i) {
            String string = new String(new char[]{cArray[random.nextInt(cArray.length)]});
            stringBuilder.append(random.nextBoolean() ? string : string.toUpperCase());
        }
        return stringBuilder.toString();
    }

    public static String randomString() {
        return RandomUtility.randomString(random.nextInt(10));
    }
}
