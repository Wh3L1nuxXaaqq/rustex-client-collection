package starclient.alpha.utility.math;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.utility.Utility;

public class AdvancedCast
implements Utility {
    public static AdvancedCast instance = new AdvancedCast();

    public Entity getMouseOver(Entity entity, float f, float f2, double d, boolean bl) {
        Minecraft minecraft = Minecraft.getMinecraft();
        Entity entity2 = minecraft.getRenderViewEntity();
        if (entity2 != null && minecraft.world != null) {
            double d2;
            RayTraceResult rayTraceResult = bl ? null : this.rayTrace(d, f, f2);
            Vec3d vec3d = entity2.getPositionEyes(1.0f);
            boolean bl2 = false;
            double d3 = d;
            if (d > 3.0) {
                bl2 = true;
            }
            if (rayTraceResult != null) {
                d3 = rayTraceResult.hitVec.distanceTo(vec3d);
            }
            Vec3d vec3d2 = this.getVectorForRotation(f2, f);
            Vec3d vec3d3 = vec3d.add(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d);
            Entity entity3 = null;
            Vec3d vec3d4 = null;
            double d4 = d3;
            AxisAlignedBB axisAlignedBB = entity.getEntityBoundingBox().grow(entity.getCollisionBorderSize());
            RayTraceResult rayTraceResult2 = axisAlignedBB.calculateIntercept(vec3d, vec3d3);
            if (axisAlignedBB.contains(vec3d)) {
                if (d3 >= 0.0) {
                    entity3 = entity;
                    vec3d4 = rayTraceResult2 == null ? vec3d : rayTraceResult2.hitVec;
                    d4 = 0.0;
                }
            } else if (rayTraceResult2 != null && ((d2 = vec3d.distanceTo(rayTraceResult2.hitVec)) < d3 || d3 == 0.0)) {
                boolean bl3 = false;
                if (!bl3 && entity.getLowestRidingEntity() == entity2.getLowestRidingEntity()) {
                    if (d3 == 0.0) {
                        entity3 = entity;
                        vec3d4 = rayTraceResult2.hitVec;
                    }
                } else {
                    entity3 = entity;
                    vec3d4 = rayTraceResult2.hitVec;
                    d4 = d2;
                }
            }
            if (entity3 != null && bl2 && vec3d.distanceTo(vec3d4) > d) {
                entity3 = null;
                rayTraceResult = new RayTraceResult(RayTraceResult.Type.MISS, vec3d4, null, new BlockPos(vec3d4));
            }
            if (entity3 != null && (d4 < d3 || rayTraceResult == null)) {
                rayTraceResult = new RayTraceResult(entity3, vec3d4);
            }
            return rayTraceResult == null ? null : rayTraceResult.entityHit;
        }
        return null;
    }

    public RayTraceResult rayTrace(double d, float f, float f2) {
        Vec3d vec3d = Minecraft.getMinecraft().player.getPositionEyes(1.0f);
        Vec3d vec3d2 = this.getVectorForRotation(f2, f);
        Vec3d vec3d3 = vec3d.add(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d);
        return Minecraft.getMinecraft().world.rayTraceBlocks(vec3d, vec3d3, true, true, true);
    }

    protected final Vec3d getVectorForRotation(float f, float f2) {
        float f3 = MathHelper.cos(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f4 = MathHelper.sin(-f2 * ((float)Math.PI / 180) - (float)Math.PI);
        float f5 = -MathHelper.cos(-f * ((float)Math.PI / 180));
        float f6 = MathHelper.sin(-f * ((float)Math.PI / 180));
        return new Vec3d(f4 * f5, f6, f3 * f5);
    }
}
