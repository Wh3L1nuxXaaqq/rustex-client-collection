package starclient.alpha.utility.math;

import starclient.alpha.utility.Utility;

public class TimerUtility
implements Utility {
    private long ms = this.getCurrentMS();

    private long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public boolean hasReached(double d) {
        return (double)(this.getCurrentMS() - this.ms) > d;
    }

    public void reset() {
        this.ms = this.getCurrentMS();
    }

    public long getTime() {
        return this.getCurrentMS() - this.ms;
    }

    public boolean hasTimeElapsed(long l) {
        return false;
    }

    public long getLastMS() {
        return 0L;
    }

    public boolean hasPassed(int n) {
        return false;
    }

    public long getMs() {
        return this.ms;
    }
}
