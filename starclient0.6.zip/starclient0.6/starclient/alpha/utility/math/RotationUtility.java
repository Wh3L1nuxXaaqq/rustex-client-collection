package starclient.alpha.utility.math;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.util.vector.Vector2f;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.math.GCDFixUtility;
import starclient.alpha.utility.math.MathUtility;

public class RotationUtility
implements Utility {
    public static Vector2f getDeltaForCoord(Vector2f vector2f, Vec3d vec3d) {
        EntityPlayerSP entityPlayerSP = Minecraft.getMinecraft().player;
        double d = vec3d.x - entityPlayerSP.posX;
        double d2 = vec3d.y - entityPlayerSP.getPositionEyes((float)1.0f).y;
        double d3 = vec3d.z - entityPlayerSP.posZ;
        double d4 = Math.sqrt(Math.pow(d, 2.0) + Math.pow(d3, 2.0));
        float f = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(d3, d)) - 90.0);
        float f2 = (float)(-Math.toDegrees(Math.atan2(d2, d4)));
        float f3 = MathHelper.wrapDegrees(f - vector2f.x);
        float f4 = f2 - vector2f.y;
        return new Vector2f(f3, f4);
    }

    public static Vector2f getRotationForCoord(Vec3d vec3d) {
        EntityPlayerSP entityPlayerSP = Minecraft.getMinecraft().player;
        double d = vec3d.x - entityPlayerSP.posX;
        double d2 = vec3d.y - entityPlayerSP.getPositionEyes((float)1.0f).y;
        double d3 = vec3d.z - entityPlayerSP.posZ;
        double d4 = Math.sqrt(Math.pow(d, 2.0) + Math.pow(d3, 2.0));
        float f = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(d3, d)) - 90.0);
        float f2 = (float)(-Math.toDegrees(Math.atan2(d2, d4)));
        return new Vector2f(f, f2);
    }

    public static float[] getCorrectRotation(Vec3d vec3d, boolean bl, float f) {
        Vec3d vec3d2 = new Vec3d(RotationUtility.mc.player.posX, RotationUtility.mc.player.getEntityBoundingBox().minY + (double)RotationUtility.mc.player.getEyeHeight(), RotationUtility.mc.player.posZ);
        double d = vec3d.x - vec3d2.x;
        double d2 = vec3d.y - (RotationUtility.mc.player.posY + (double)RotationUtility.mc.player.getEyeHeight() - (double)f);
        double d3 = vec3d.z - vec3d2.z;
        double d4 = Math.sqrt(d * d + d3 * d3);
        float f2 = (float)(Math.toDegrees(Math.atan2(d3, d)) - 90.0) + (float)(bl ? MathUtility.getRandomInRange(-2, 2) : 0);
        float f3 = (float)(-Math.toDegrees(Math.atan2(d2, d4))) + (float)(bl ? MathUtility.getRandomInRange(-2, 2) : 0);
        f2 = RotationUtility.mc.player.rotationYaw + GCDFixUtility.getFixedRotation(MathHelper.wrapDegrees(f2 - RotationUtility.mc.player.rotationYaw));
        f3 = RotationUtility.mc.player.rotationPitch + GCDFixUtility.getFixedRotation(MathHelper.wrapDegrees(f3 - RotationUtility.mc.player.rotationPitch));
        f3 = MathHelper.clamp(f3, -90.0f, 90.0f);
        return new float[]{f2, f3};
    }
}
