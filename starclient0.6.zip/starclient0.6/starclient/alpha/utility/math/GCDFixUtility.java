package starclient.alpha.utility.math;

import starclient.alpha.utility.Utility;

public class GCDFixUtility
implements Utility {
    public static float getFixedRotation(float f) {
        return GCDFixUtility.getDeltaMouse(f) * GCDFixUtility.getGCDValue();
    }

    public static float getGCDValue() {
        return (float)((double)GCDFixUtility.getGCD() * 0.15);
    }

    public static float getGCD() {
        float f = (float)((double)GCDFixUtility.mc.gameSettings.mouseSensitivity * 0.6 + 0.2);
        return f * f * f * 8.0f;
    }

    public static float getDeltaMouse(float f) {
        return Math.round(f / GCDFixUtility.getGCDValue());
    }
}
