package starclient.alpha.event.misc;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;

public class EventDetectBot
extends EventCancellable
implements Event {
    Entity entity;
    float chance;

    public EventDetectBot(Entity entity, float f) {
        this.entity = entity;
        this.chance = f;
    }
}
