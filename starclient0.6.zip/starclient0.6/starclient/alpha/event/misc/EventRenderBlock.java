package starclient.alpha.event.misc;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;

public class EventRenderBlock
implements Event {
    BlockPos pos;
    IBlockState state;

    public EventRenderBlock(BlockPos blockPos, IBlockState iBlockState) {
        this.pos = blockPos;
        this.state = iBlockState;
    }

    public BlockPos getPos() {
        return this.pos;
    }

    public IBlockState getState() {
        return this.state;
    }
}
