package starclient.alpha.event.misc;

import com.darkmagician6.eventapi.events.Event;

public class EventKeyBoard
implements Event {
    int key;

    public EventKeyBoard(int n) {
        this.key = n;
    }

    public int getKey() {
        return this.key;
    }
}
