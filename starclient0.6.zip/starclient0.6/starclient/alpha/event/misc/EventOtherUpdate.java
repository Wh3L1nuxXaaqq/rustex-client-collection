package starclient.alpha.event.misc;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.PotionEffect;

public class EventOtherUpdate
extends EventCancellable {

    public class Potion
    extends EventOtherUpdate {
        public PotionEffect effect;
        public net.minecraft.potion.Potion potion;
        public EntityLivingBase entity;

        public Potion(net.minecraft.potion.Potion potion, PotionEffect potionEffect, EntityLivingBase entityLivingBase) {
            this.potion = potion;
            this.effect = potionEffect;
            this.entity = entityLivingBase;
        }

        public void removeEffect() {
            this.effect.getPotion().removeAttributesModifiersFromEntity(this.entity, this.entity.getAttributeMap(), this.effect.getAmplifier());
        }
    }

    public class Post
    extends EventOtherUpdate {
    }

    public class Pre
    extends EventOtherUpdate {
    }
}
