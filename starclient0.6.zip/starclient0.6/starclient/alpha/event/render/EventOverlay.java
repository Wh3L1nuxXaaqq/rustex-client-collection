package starclient.alpha.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventOverlay
extends EventCancellable {
    private final OverlayType overlayType;

    public OverlayType getOverlayType() {
        return this.overlayType;
    }

    public EventOverlay(OverlayType overlayType) {
        this.overlayType = overlayType;
    }

    public static enum OverlayType {
        CAMERA_CLIP,
        HURT_CAM;

    }
}
