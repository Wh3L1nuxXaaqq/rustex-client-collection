package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.Event;

public class EventHit
implements Event {
    private boolean sprintState;

    public EventHit(boolean bl) {
        this.sprintState = bl;
    }

    public void setSprintState(boolean bl) {
        this.sprintState = bl;
    }

    public boolean getSprintState() {
        return this.sprintState;
    }
}
