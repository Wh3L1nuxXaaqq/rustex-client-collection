package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventMotion
extends EventCancellable
implements Event {
    private float yaw;
    private float pitch;
    private double posX;
    private double posY;
    private double posZ;
    private boolean onGround;

    public EventMotion(float f, float f2, double d, double d2, double d3, boolean bl) {
        this.yaw = f;
        this.pitch = f2;
        this.posX = d;
        this.posY = d2;
        this.posZ = d3;
        this.onGround = bl;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float f) {
        this.yaw = f;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float f) {
        this.pitch = f;
    }

    public double getPosX() {
        return this.posX;
    }

    public void setPosX(double d) {
        this.posX = d;
    }

    public double getPosY() {
        return this.posY;
    }

    public void setPosY(double d) {
        this.posY = d;
    }

    public double getPosZ() {
        return this.posZ;
    }

    public void setPosZ(double d) {
        this.posZ = d;
    }

    public boolean isOnGround() {
        return this.onGround;
    }

    public void setOnGround(boolean bl) {
        this.onGround = bl;
    }
}
