package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class EventInteractBlock
extends EventCancellable {
    private BlockPos pos;
    private EnumFacing face;

    public BlockPos getPos() {
        return this.pos;
    }

    public EnumFacing getFace() {
        return this.face;
    }

    public void setPos(BlockPos blockPos) {
        this.pos = blockPos;
    }

    public void setFace(EnumFacing enumFacing) {
        this.face = enumFacing;
    }

    public EventInteractBlock(BlockPos blockPos, EnumFacing enumFacing) {
        this.pos = blockPos;
        this.face = enumFacing;
    }
}
