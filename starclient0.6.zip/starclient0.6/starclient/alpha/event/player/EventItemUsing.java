package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventItemUsing
extends EventCancellable {
}
