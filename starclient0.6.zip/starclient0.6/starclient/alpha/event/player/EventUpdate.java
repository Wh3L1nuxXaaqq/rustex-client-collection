package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventUpdate
extends EventCancellable
implements Event {
    double posX;
    double posY;
    double posZ;
    float rotationYaw;
    float rotationPitch;
    boolean onGround;

    public EventUpdate(double d, double d2, double d3, float f, float f2, boolean bl) {
        this.posX = d;
        this.posY = d2;
        this.posZ = d3;
        this.rotationYaw = f;
        this.rotationPitch = f2;
        this.onGround = bl;
    }

    public double getPosY() {
        return this.posY;
    }

    public double getPosX() {
        return this.posX;
    }

    public double getPosZ() {
        return this.posZ;
    }

    public float getRotationPitch() {
        return this.rotationPitch;
    }

    public float getRotationYaw() {
        return this.rotationYaw;
    }

    public boolean isOnGround() {
        return this.onGround;
    }

    public void setPosY(double d) {
        this.posY = d;
    }

    public void setPosX(double d) {
        this.posX = d;
    }

    public void setOnGround(boolean bl) {
        this.onGround = bl;
    }

    public void setPosZ(double d) {
        this.posZ = d;
    }

    public void setRotationPitch(float f) {
        this.rotationPitch = f;
    }

    public void setRotationYaw(float f) {
        this.rotationYaw = f;
    }
}
