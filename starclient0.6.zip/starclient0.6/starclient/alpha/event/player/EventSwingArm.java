package starclient.alpha.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.EnumHand;

public class EventSwingArm
extends EventCancellable
implements Event {
    EnumHand hand;

    public EventSwingArm(EnumHand enumHand) {
        this.hand = enumHand;
    }

    public EnumHand getHand() {
        return this.hand;
    }
}
