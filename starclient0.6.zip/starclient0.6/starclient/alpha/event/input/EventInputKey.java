package starclient.alpha.event.input;

import com.darkmagician6.eventapi.events.Event;

public class EventInputKey
implements Event {
    private int key;

    public EventInputKey(int n) {
        this.key = n;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int n) {
        this.key = n;
    }
}
