package starclient.alpha.event.input;

import com.darkmagician6.eventapi.events.Event;

public class EventMouse
implements Event {
    private int button;

    public int getButton() {
        return this.button;
    }

    public EventMouse(int n) {
        this.button = n;
    }
}
