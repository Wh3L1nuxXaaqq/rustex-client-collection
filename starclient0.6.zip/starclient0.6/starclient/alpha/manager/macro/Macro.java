package starclient.alpha.manager.macro;

public class Macro {
    private String message;
    private int key;

    public String getMessage() {
        return this.message;
    }

    public int getKey() {
        return this.key;
    }

    public Macro(String string, int n) {
        this.message = string;
        this.key = n;
    }
}
