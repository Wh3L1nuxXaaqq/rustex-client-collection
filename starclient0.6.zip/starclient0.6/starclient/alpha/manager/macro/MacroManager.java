package starclient.alpha.manager.macro;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import starclient.alpha.manager.macro.Macro;

public class MacroManager {
    public List<Macro> macros = new ArrayList<Macro>();
    private static final File macroFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\macro.star");

    public void init() throws IOException {
        if (!macroFile.exists()) {
            macroFile.createNewFile();
        } else {
            this.readMacro();
        }
    }

    public void addMacros(Macro macro) {
        this.macros.add(macro);
        this.updateFile();
    }

    public void deleteMacro(int n) {
        this.macros.removeIf(macro -> macro.getKey() == n);
        this.updateFile();
    }

    public void onKeyPressed(int n) {
        this.macros.stream().filter(macro -> macro.getKey() == n).forEach(macro -> Minecraft.getMinecraft().player.sendChatMessage(macro.getMessage()));
    }

    public void onMousePressed(int n) {
        this.macros.stream().filter(macro -> macro.getKey() == n - 100).forEach(macro -> Minecraft.getMinecraft().player.sendChatMessage(macro.getMessage()));
    }

    public void updateFile() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            this.macros.forEach(macro -> stringBuilder.append(macro.getMessage()).append(":").append(String.valueOf(macro.getKey()).toUpperCase()).append("\n"));
            Files.write(macroFile.toPath(), stringBuilder.toString().getBytes(), new OpenOption[0]);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void readMacro() {
        try {
            String string;
            FileInputStream fileInputStream = new FileInputStream(macroFile.getAbsolutePath());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new DataInputStream(fileInputStream)));
            while ((string = bufferedReader.readLine()) != null) {
                String string2 = string.trim();
                String string3 = string2.split(":")[0];
                String string4 = string2.split(":")[1];
                this.macros.add(new Macro(string3, Integer.parseInt(string4)));
            }
            bufferedReader.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public List<Macro> getMacros() {
        return this.macros;
    }
}
