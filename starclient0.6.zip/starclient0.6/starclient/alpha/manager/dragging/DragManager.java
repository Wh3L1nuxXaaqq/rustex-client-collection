package starclient.alpha.manager.dragging;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.HashMap;
import net.minecraft.client.Minecraft;
import starclient.alpha.manager.dragging.Draggable;
import starclient.alpha.module.Module;

public class DragManager {
    private static final HashMap<String, Draggable> draggables = new HashMap();
    public static final File dragablesFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\elements.star");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();

    public void init() throws IOException {
        if (!dragablesFile.exists()) {
            dragablesFile.createNewFile();
        } else {
            this.load();
        }
    }

    public void save() {
        try {
            Files.write(dragablesFile.toPath(), GSON.toJson(draggables.values()).getBytes(StandardCharsets.UTF_8), new OpenOption[0]);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public void load() {
        try {
            Draggable[] draggableArray;
            Draggable[] draggableArray2 = draggableArray = GSON.fromJson(new String(Files.readAllBytes(dragablesFile.toPath()), StandardCharsets.UTF_8), Draggable[].class);
            int n = draggableArray.length;
            for (int i = 0; i < n; ++i) {
                Draggable draggable = draggableArray2[i];
                if (draggable == null) {
                    return;
                }
                Draggable draggable2 = draggables.get(draggable.getName());
                if (draggable2 == null) continue;
                draggable2.setX(draggable.getX());
                draggable2.setY(draggable.getY());
                draggables.put(draggable.getName(), draggable2);
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public static Draggable create(Module module, String string, int n, int n2) {
        Draggable draggable = new Draggable(module, string, n, n2);
        draggables.put(string, draggable);
        return draggable;
    }

    public static HashMap<String, Draggable> getDraggables() {
        return draggables;
    }
}
