package starclient.alpha.manager.dragging;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import starclient.alpha.module.Module;
import starclient.alpha.utility.render.RenderUtility;

public class Draggable {
    @Expose
    @SerializedName(value="x")
    private int x;
    @Expose
    @SerializedName(value="y")
    private int y;
    public int initialXVal;
    public int initialYVal;
    private int startX;
    private int startY;
    private boolean dragging;
    private float width;
    private float height;
    @Expose
    @SerializedName(value="name")
    private String name;
    private final Module module;

    public Draggable(Module module, String string, int n, int n2) {
        this.module = module;
        this.name = string;
        this.x = n;
        this.y = n2;
        this.initialXVal = n;
        this.initialYVal = n2;
    }

    public final void onDraw(int n, int n2) {
        if (this.dragging) {
            this.x = n - this.startX;
            this.y = n2 - this.startY;
        }
    }

    public final void onClick(int n, int n2, int n3) {
        if (n3 == 0 && RenderUtility.isHovered(n, n2, this.x, this.y, this.width, this.height)) {
            this.dragging = true;
            this.startX = n - this.x;
            this.startY = n2 - this.y;
        }
    }

    public final void onRelease(int n) {
        if (n == 0) {
            this.dragging = false;
        }
    }

    public int getX() {
        return this.x;
    }

    public void setX(int n) {
        this.x = n;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int n) {
        this.y = n;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public void setWidth(float f) {
        this.width = f;
    }

    public void setHeight(float f) {
        this.height = f;
    }

    public String getName() {
        return this.name;
    }

    public Module getModule() {
        return this.module;
    }
}
