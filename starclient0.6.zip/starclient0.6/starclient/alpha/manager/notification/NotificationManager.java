package starclient.alpha.manager.notification;

import java.util.concurrent.CopyOnWriteArrayList;
import starclient.alpha.StarClient;
import starclient.alpha.manager.notification.Notification;
import starclient.alpha.manager.notification.NotificationType;
import starclient.alpha.module.impl.render.Notifications;

public class NotificationManager {
    private static float defaultTime = 250.0f;
    private static final CopyOnWriteArrayList<Notification> notifications = new CopyOnWriteArrayList();

    public static void notify(NotificationType notificationType, String string, String string2) {
        NotificationManager.notify(new Notification(notificationType, string, string2));
    }

    public static void notify(NotificationType notificationType, String string, String string2, float f) {
        NotificationManager.notify(new Notification(notificationType, string, string2, f));
    }

    private static void notify(Notification notification) {
        if (StarClient.getInstance().getModuleManager().getModule(Notifications.class).isEnabled()) {
            notifications.add(notification);
        }
    }

    public static float getDefaultTime() {
        return defaultTime;
    }

    public static void setDefaultTime(float f) {
        defaultTime = f;
    }

    public static CopyOnWriteArrayList<Notification> getNotifications() {
        return notifications;
    }
}
