package starclient.alpha.manager.notification;

import java.awt.Color;
import starclient.alpha.StarClient;
import starclient.alpha.manager.notification.NotificationManager;
import starclient.alpha.manager.notification.NotificationType;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.utility.misc.TimerHelper;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;
import starclient.alpha.utility.render.font.Fonts;

public class Notification {
    private final NotificationType type;
    private final String title;
    private final String description;
    private final float time;
    private final TimerHelper timerHelper = new TimerHelper();
    private final Animation animation;

    public Notification(NotificationType notificationType, String string, String string2) {
        this(notificationType, string, string2, NotificationManager.getDefaultTime());
    }

    public Notification(NotificationType notificationType, String string, String string2, float f) {
        this.type = notificationType;
        this.title = string;
        this.description = string2;
        this.time = f;
        this.animation = new DecelerateAnimation(200, 1.0f);
    }

    public void render(float f, float f2, float f3, float f4, float f5) {
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        int n = StarClient.getInstance().getC(0).getRGB();
        int n2 = StarClient.getInstance().getC(500).getRGB();
        int n3 = bl ? new Color(255, 255, 255).getRGB() : new Color(44, 44, 44).getRGB();
        int n4 = bl ? new Color(30, 30, 30, 240).getRGB() : new Color(255, 255, 255, 230).getRGB();
        float f6 = f2 + (1.0f - this.animation.getOutput()) * f4;
        RenderUtility.drawGradientGlow(f + 5.5f, f6 + 12.0f, f3 - 12.0f, f4 - 10.0f, 6, n, n2, n, n2);
        RenderUtility.drawRoundedRect(f + 5.5f, f6 + 12.0f, f3 - 12.0f, f4 - 10.0f, 5.0f, n4);
        Fonts.nunitoBold15.drawString(this.description, f + 20.0f, f6 + 18.5f, n3);
        Fonts.iconsnur.drawString("R", f + 8.0f, f6 + 19.5f, n3);
    }

    public NotificationType getType() {
        return this.type;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public float getTime() {
        return this.time;
    }

    public TimerHelper getTimerHelper() {
        return this.timerHelper;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}
