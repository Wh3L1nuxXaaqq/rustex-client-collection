package starclient.alpha.manager.friend;

public class Friend {
    private String name;

    public String getName() {
        return this.name;
    }

    public Friend(String string) {
        this.name = string;
    }
}
