package starclient.alpha.manager.friend;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import starclient.alpha.manager.friend.Friend;

public class FriendManager {
    private final List<Friend> friends = new ArrayList<Friend>();
    public static final File friendsFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\friends.star");

    public void init() throws IOException {
        if (!friendsFile.exists()) {
            friendsFile.createNewFile();
        } else {
            this.readFriends();
        }
    }

    public void addFriend(String string) {
        this.friends.add(new Friend(string));
        this.updateFile();
    }

    public Optional<Friend> getFriend(String string) {
        return this.friends.stream().filter(friend -> friend.getName().equals(string)).findFirst();
    }

    public boolean isFriend(String string) {
        return this.friends.stream().anyMatch(friend -> friend.getName().equals(string));
    }

    public void removeFriend(String string) {
        this.friends.removeIf(friend -> friend.getName().equalsIgnoreCase(string));
    }

    public void clearFriend() {
        this.friends.clear();
        this.updateFile();
    }

    public void updateFile() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            this.friends.forEach(friend -> stringBuilder.append(friend.getName()).append("\n"));
            Files.write(friendsFile.toPath(), stringBuilder.toString().getBytes(), new OpenOption[0]);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void readFriends() {
        try {
            String string;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(friendsFile.getAbsolutePath()))));
            while ((string = bufferedReader.readLine()) != null) {
                this.friends.add(new Friend(string));
            }
            bufferedReader.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public List<Friend> getFriends() {
        return this.friends;
    }
}
