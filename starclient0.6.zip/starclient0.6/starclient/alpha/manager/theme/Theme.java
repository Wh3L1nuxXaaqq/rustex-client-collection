package starclient.alpha.manager.theme;

import java.awt.Color;

public class Theme {
    private final String name;
    private final ThemeType type;
    private final Color[] colors;

    public Theme(String string, ThemeType themeType, Color ... colorArray) {
        this.name = string;
        this.type = themeType;
        this.colors = colorArray;
    }

    public String getName() {
        return this.name;
    }

    public ThemeType getType() {
        return this.type;
    }

    public Color[] getColors() {
        return this.colors;
    }

    public static enum ThemeType {
        GUI,
        STYLE;

    }
}
