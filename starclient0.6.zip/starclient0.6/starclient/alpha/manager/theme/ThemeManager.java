package starclient.alpha.manager.theme;

import starclient.alpha.manager.theme.Theme;
import starclient.alpha.manager.theme.Themes;

public class ThemeManager {
    private Theme currentGuiTheme = Themes.DARK.getTheme();
    private Theme currentStyleTheme = Themes.PURPLE.getTheme();

    public Theme getCurrentGuiTheme() {
        return this.currentGuiTheme;
    }

    public void setCurrentGuiTheme(Theme theme) {
        this.currentGuiTheme = theme;
    }

    public Theme getCurrentStyleTheme() {
        return this.currentStyleTheme;
    }

    public void setCurrentStyleTheme(Theme theme) {
        this.currentStyleTheme = theme;
    }
}
