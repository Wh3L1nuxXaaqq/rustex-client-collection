package starclient.alpha.manager.theme;

import java.awt.Color;
import java.util.HashMap;
import starclient.alpha.manager.theme.Theme;

public enum Themes {
    DARK(new Theme("Black", Theme.ThemeType.GUI, new Color(30, 30, 30), new Color(25, 25, 25), new Color(75, 75, 75), new Color(65, 65, 65), new Color(42, 42, 42), new Color(37, 37, 37, 200))),
    WHITE(new Theme("White", Theme.ThemeType.GUI, new Color(245, 245, 245), new Color(225, 225, 225), new Color(195, 195, 195), new Color(195, 195, 195), new Color(215, 215, 215), new Color(205, 205, 205, 200))),
    PURPLE(new Theme("Purple", Theme.ThemeType.STYLE, new Color(8605083), new Color(13651670))),
    NIGHT(new Theme("Sea", Theme.ThemeType.STYLE, new Color(1869258), new Color(1654871))),
    ELECTRIC(new Theme("Electric", Theme.ThemeType.STYLE, new Color(4683494), new Color(9327849))),
    SIKON(new Theme("Christmas", Theme.ThemeType.STYLE, new Color(0xFF0000), new Color(0xFFFFFF))),
    FasaKok(new Theme("Moon", Theme.ThemeType.STYLE, new Color(0xFFFFFF), new Color(9327849))),
    MONTE_CARLO(new Theme("Monte Carlo", Theme.ThemeType.STYLE, new Color(13407680), new Color(0xDBD4B4))),
    ARGON(new Theme("Argon", Theme.ThemeType.STYLE, new Color(9520298), new Color(3539036))),
    LOL2(new Theme("Police", Theme.ThemeType.STYLE, new Color(0xFF0000), new Color(6143))),
    LOL3(new Theme("Green", Theme.ThemeType.STYLE, new Color(4783872), new Color(870144))),
    LOL4(new Theme("Red", Theme.ThemeType.STYLE, new Color(0xFF0000), new Color(0x470000))),
    LOL5(new Theme("Blue", Theme.ThemeType.STYLE, new Color(57855), new Color(12871))),
    LOL(new Theme("Candy", Theme.ThemeType.STYLE, new Color(65535), new Color(0xFF00FA))),
    WATERMELON(new Theme("Watermelon", Theme.ThemeType.STYLE, new Color(4783872), new Color(65513))),
    BOBA(new Theme("Boba", Theme.ThemeType.STYLE, new Color(0x2200FF), new Color(0xFF00FB))),
    BOBANEW(new Theme("BobaNew", Theme.ThemeType.STYLE, new Color(0x9900FF), new Color(16748800))),
    DARKI(new Theme("Darki", Theme.ThemeType.STYLE, new Color(0), new Color(-1, true))),
    DUSTY(new Theme("Dusty", Theme.ThemeType.STYLE, new Color(15660549), new Color(-1309692, true))),
    FASIK(new Theme("Fasik", Theme.ThemeType.STYLE, new Color(390894), new Color(-16711692, true))),
    BURBY(new Theme("Burby", Theme.ThemeType.STYLE, new Color(15518196), new Color(-5241094, true))),
    GOLD(new Theme("Gold", Theme.ThemeType.STYLE, new Color(16762447), new Color(16751900))),
    AngeLok(new Theme("AngeLok", Theme.ThemeType.STYLE, new Color(0xFF0000), new Color(325359))),
    Kotik(new Theme("Kit-Kotik", Theme.ThemeType.STYLE, new Color(13304056), new Color(325359))),
    BLOODY(new Theme("Bloody Mary", Theme.ThemeType.STYLE, new Color(16732463), new Color(14492790))),
    ROSE_WATER(new Theme("Rose Water", Theme.ThemeType.STYLE, new Color(15031687), new Color(6276068))),
    WIRETAP(new Theme("Wiretap", Theme.ThemeType.STYLE, new Color(9053063), new Color(15286359))),
    RAINBOW_BLUE(new Theme("Rainbow Blue", Theme.ThemeType.STYLE, new Color(62048), new Color(357862))),
    ORANGE_FUN(new Theme("Orange Fun", Theme.ThemeType.STYLE, new Color(16534042), new Color(16234291))),
    HYDROGEN(new Theme("Hydrogen", Theme.ThemeType.STYLE, new Color(6716854), new Color(33480))),
    VELVET_SUN(new Theme("Velvet Sun", Theme.ThemeType.STYLE, new Color(14806723), new Color(15749203))),
    KING_YNA(new Theme("King Yna", Theme.ThemeType.STYLE, new Color(1714796), new Color(16628525))),
    KIMOBY(new Theme("Kimoby", Theme.ThemeType.STYLE, new Color(3762940), new Color(2705663))),
    SUBU(new Theme("Subu", Theme.ThemeType.STYLE, new Color(846827), new Color(2155442))),
    TELEGRAM(new Theme("Telegram", Theme.ThemeType.STYLE, new Color(1872594), new Color(15924478))),
    SCOOTER(new Theme("Scooter", Theme.ThemeType.STYLE, new Color(3592668), new Color(5998309))),
    MERIDIAN(new Theme("Meridian", Theme.ThemeType.STYLE, new Color(2636934), new Color(4563527))),
    COAL(new Theme("Coal", Theme.ThemeType.STYLE, new Color(15423319), new Color(0))),
    CELESTIAL(new Theme("Celestial", Theme.ThemeType.STYLE, new Color(12793700), new Color(1910385))),
    DREAM(new Theme("Dream", Theme.ThemeType.STYLE, new Color(3467422), new Color(996419))),
    CANDY(new Theme("Candy", Theme.ThemeType.STYLE, new Color(28, 167, 222), new Color(236, 133, 209))),
    SUMMER(new Theme("Summer", Theme.ThemeType.STYLE, new Color(34, 193, 195), new Color(253, 187, 45))),
    RIVER(new Theme("River", Theme.ThemeType.STYLE, new Color(4443810), new Color(1596061))),
    GLORIA(new Theme("Gloria", Theme.ThemeType.STYLE, new Color(641745), new Color(6363340))),
    LOLLIPOP(new Theme("Lollipop", Theme.ThemeType.STYLE, new Color(16234331), new Color(15476088))),
    JESIC(new Theme("Jesic", Theme.ThemeType.STYLE, new Color(12189542), new Color(7049291))),
    SHINE(new Theme("Shine", Theme.ThemeType.STYLE, new Color(11760581), new Color(7170255))),
    HERON(new Theme("Heron", Theme.ThemeType.STYLE, new Color(15893890), new Color(6855044))),
    DOUP(new Theme("Doup", Theme.ThemeType.STYLE, new Color(14412429), new Color(8225371))),
    LEEN(new Theme("Leen", Theme.ThemeType.STYLE, new Color(10285765), new Color(4291953))),
    CRIMSON(new Theme("Crimson", Theme.ThemeType.STYLE, new Color(215, 60, 67), new Color(140, 23, 39))),
    SUNDAE(new Theme("Windy", Theme.ThemeType.STYLE, new Color(11319013), new Color(8846824))),
    ORANGE(new Theme("Orange", Theme.ThemeType.STYLE, new Color(242, 201, 76), new Color(241, 143, 56))),
    ATLAS(new Theme("Atlas", Theme.ThemeType.STYLE, new Color(16690270), new Color(4964552))),
    SUBLIME(new Theme("Sublime", Theme.ThemeType.STYLE, new Color(16538749), new Color(6980347))),
    AZURE(new Theme("Azure", Theme.ThemeType.STYLE, new Color(239, 50, 217), new Color(137, 255, 253))),
    MAGIC(new Theme("Magic", Theme.ThemeType.STYLE, new Color(5882227), new Color(6104769))),
    ORCA(new Theme("Orca", Theme.ThemeType.STYLE, new Color(4497549), new Color(1006685))),
    EMERALD(new Theme("Emerald", Theme.ThemeType.STYLE, new Color(3731325), new Color(1153422))),
    WITCHERY(new Theme("Witchery", Theme.ThemeType.STYLE, new Color(12784690), new Color(6430354))),
    FLARE(new Theme("Flare", Theme.ThemeType.STYLE, new Color(15804177), new Color(16101145))),
    FALLING(new Theme("Falling", Theme.ThemeType.STYLE, new Color(12993134), new Color(6564723))),
    MOONLIGHT(new Theme("Moonlight", Theme.ThemeType.STYLE, new Color(10986455), new Color(0x595999))),
    DEEPBLUE(new Theme("Deep Blue", Theme.ThemeType.STYLE, new Color(1981554), new Color(2773656)));

    private final Theme theme;
    private static final HashMap<String, Theme> map;

    private Themes(Theme theme) {
        this.theme = theme;
    }

    public static Theme findByName(String string) {
        return map.get(string);
    }

    public Theme getTheme() {
        return this.theme;
    }

    static {
        map = new HashMap();
        for (Themes themes : Themes.values()) {
            map.put(themes.theme.getName(), themes.theme);
        }
    }
}
