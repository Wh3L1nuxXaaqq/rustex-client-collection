package starclient.alpha.manager.lastAccount;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;
import starclient.alpha.utility.Utility;

public class LastAccountManager
implements Utility {
    public static final File lastAccountFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\lastAccount.star");

    public void init() throws IOException {
        if (!lastAccountFile.exists()) {
            lastAccountFile.createNewFile();
        } else {
            this.load();
        }
    }

    private void load() {
        try {
            FileInputStream fileInputStream = new FileInputStream(lastAccountFile.getAbsolutePath());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new DataInputStream(fileInputStream)));
            String string = bufferedReader.readLine();
            LastAccountManager.mc.session = new Session(string.trim(), "", "", "mojang");
            bufferedReader.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void save() {
        try {
            Files.write(lastAccountFile.toPath(), LastAccountManager.mc.session.getUsername().getBytes(), new OpenOption[0]);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}
