package starclient.alpha.manager.config;

import com.darkmagician6.eventapi.EventManager;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import starclient.alpha.StarClient;
import starclient.alpha.command.CommandManager;
import starclient.alpha.manager.config.ConfigManager;
import starclient.alpha.manager.config.ConfigUpdater;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Module;

public class Config
implements ConfigUpdater {
    private final String name;
    private final File file;

    public Config(String string) {
        this.name = string;
        this.file = new File(ConfigManager.configDirectory, string + ".star");
        if (!this.file.exists()) {
            try {
                this.file.createNewFile();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    @Override
    public JsonObject save() {
        JsonObject jsonObject = new JsonObject();
        JsonObject jsonObject2 = new JsonObject();
        for (Module module : StarClient.getInstance().getModuleManager().getModules()) {
            jsonObject2.add(module.name, module.save());
        }
        jsonObject.addProperty("Prefix", CommandManager.getPrefix());
        jsonObject.addProperty("GuiTheme", StarClient.getInstance().getThemeManager().getCurrentGuiTheme().getName());
        jsonObject.addProperty("StyleTheme", StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getName());
        jsonObject.add("Modules", jsonObject2);
        return jsonObject;
    }

    @Override
    public void load(JsonObject jsonObject) {
        if (jsonObject.has("Prefix")) {
            CommandManager.setPrefix(jsonObject.get("Prefix").getAsString());
        }
        if (jsonObject.has("GuiTheme")) {
            StarClient.getInstance().getThemeManager().setCurrentGuiTheme(Themes.findByName(jsonObject.get("GuiTheme").getAsString()));
        }
        if (jsonObject.has("StyleTheme")) {
            StarClient.getInstance().getThemeManager().setCurrentStyleTheme(Themes.findByName(jsonObject.get("StyleTheme").getAsString()));
        }
        if (jsonObject.has("Prefix")) {
            CommandManager.setPrefix(jsonObject.get("Prefix").getAsString());
        }
        if (jsonObject.has("Modules")) {
            JsonObject jsonObject2 = jsonObject.getAsJsonObject("Modules");
            for (Module module : StarClient.getInstance().getModuleManager().getModules()) {
                EventManager.unregister(module);
                module.load(jsonObject2.getAsJsonObject(module.name));
            }
        }
    }

    public String getName() {
        return this.name;
    }

    public File getFile() {
        return this.file;
    }
}
