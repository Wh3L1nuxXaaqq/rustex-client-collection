package starclient.alpha.manager.config;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import org.apache.commons.io.FilenameUtils;
import starclient.alpha.manager.config.Config;
import starclient.alpha.manager.config.Manager;

public class ConfigManager
extends Manager<Config> {
    public static final File configDirectory = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\configs");
    private static final ArrayList<Config> loadedConfigs = new ArrayList();

    public ConfigManager() {
        this.setContents(ConfigManager.loadConfigs());
        configDirectory.mkdirs();
    }

    private static ArrayList<Config> loadConfigs() {
        File[] fileArray = configDirectory.listFiles();
        if (fileArray != null) {
            File[] fileArray2 = fileArray;
            int n = fileArray.length;
            for (int i = 0; i < n; ++i) {
                File file = fileArray2[i];
                if (!FilenameUtils.getExtension((String)file.getName()).equals("dc")) continue;
                loadedConfigs.add(new Config(FilenameUtils.removeExtension((String)file.getName())));
            }
        }
        return loadedConfigs;
    }

    public void load() {
        if (!configDirectory.exists()) {
            configDirectory.mkdirs();
        }
        if (configDirectory != null) {
            File[] fileArray;
            File[] fileArray2 = fileArray = configDirectory.listFiles(file -> !file.isDirectory() && FilenameUtils.getExtension((String)file.getName()).equals("ar"));
            int n = fileArray.length;
            for (int i = 0; i < n; ++i) {
                File file2 = fileArray2[i];
                Config config = new Config(FilenameUtils.removeExtension((String)file2.getName()).replace(" ", ""));
                loadedConfigs.add(config);
            }
        }
    }

    public boolean loadConfig(String string) {
        if (string == null) {
            return false;
        }
        Config config = this.findConfig(string);
        if (config == null) {
            return false;
        }
        try {
            FileReader fileReader = new FileReader(config.getFile());
            JsonParser jsonParser = new JsonParser();
            JsonObject jsonObject = (JsonObject)jsonParser.parse(fileReader);
            config.load(jsonObject);
            return true;
        }
        catch (FileNotFoundException fileNotFoundException) {
            return false;
        }
    }

    public boolean saveConfig(String string) {
        Object object;
        if (string == null) {
            return false;
        }
        Config config = this.findConfig(string);
        if (config == null) {
            config = new Config(string);
            object = config;
            this.getContents().add(object);
        }
        object = new GsonBuilder().setPrettyPrinting().create().toJson(config.save());
        try {
            FileWriter fileWriter = new FileWriter(config.getFile());
            fileWriter.write((String)object);
            fileWriter.close();
            return true;
        }
        catch (IOException iOException) {
            return false;
        }
    }

    public Config findConfig(String string) {
        Config config;
        if (string == null) {
            return null;
        }
        Iterator iterator = this.getContents().iterator();
        do {
            if (iterator.hasNext()) continue;
            if (new File(configDirectory, string + ".star").exists()) {
                return new Config(string);
            }
            return null;
        } while (!(config = (Config)iterator.next()).getName().equalsIgnoreCase(string));
        return config;
    }

    public boolean deleteConfig(String string) {
        if (string == null) {
            return false;
        }
        Config config = this.findConfig(string);
        if (config == null) {
            return false;
        }
        File file = config.getFile();
        this.getContents().remove(config);
        return file.exists() && file.delete();
    }

    public static ArrayList<Config> getLoadedConfigs() {
        return loadedConfigs;
    }
}
