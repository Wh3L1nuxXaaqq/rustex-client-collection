package starclient.alpha.manager.config;

import com.google.gson.JsonObject;

public interface ConfigUpdater {
    public JsonObject save();

    public void load(JsonObject var1);
}
