package starclient.alpha.ui.menu.main.newgui;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.lwjgl.opengl.GL20;

public class GLSL {
    private final int programId;
    private final int timeUniform;
    private final int mouseUniform;
    private final int resolutionUniform;

    public GLSL(String string) throws IOException {
        int n = GL20.glCreateProgram();
        GL20.glAttachShader((int)n, (int)this.createShader(GLSL.class.getResourceAsStream("/minecraft/starclient/shaders/passthrough.vsh"), 35633));
        GL20.glAttachShader((int)n, (int)this.createShader(GLSL.class.getResourceAsStream(string), 35632));
        GL20.glLinkProgram((int)n);
        int n2 = GL20.glGetProgrami((int)n, (int)35714);
        if (n2 == 0) {
            System.err.println(GL20.glGetProgramInfoLog((int)n, (int)GL20.glGetProgrami((int)n, (int)35716)));
            throw new IllegalStateException("Shader failed to link");
        }
        this.programId = n;
        GL20.glUseProgram((int)n);
        this.timeUniform = GL20.glGetUniformLocation((int)n, (CharSequence)"time");
        this.mouseUniform = GL20.glGetUniformLocation((int)n, (CharSequence)"mouse");
        this.resolutionUniform = GL20.glGetUniformLocation((int)n, (CharSequence)"resolution");
        GL20.glUseProgram((int)0);
    }

    public void useShader(int n, int n2, float f, float f2, float f3) {
        GL20.glUseProgram((int)this.programId);
        GL20.glUniform2f((int)this.resolutionUniform, (float)n, (float)n2);
        GL20.glUniform2f((int)this.mouseUniform, (float)(f / (float)n), (float)(1.0f - f2 / (float)n2));
        GL20.glUniform1f((int)this.timeUniform, (float)f3);
    }

    public int createShader(InputStream inputStream, int n) throws IOException {
        int n2 = GL20.glCreateShader((int)n);
        GL20.glShaderSource((int)n2, (CharSequence)this.readStreamToString(inputStream));
        GL20.glCompileShader((int)n2);
        int n3 = GL20.glGetShaderi((int)n2, (int)35713);
        if (n3 == 0) {
            System.err.println(GL20.glGetShaderInfoLog((int)n2, (int)GL20.glGetShaderi((int)n2, (int)35716)));
            throw new IllegalStateException("Failed to compile shader");
        }
        return n2;
    }

    public String readStreamToString(InputStream inputStream) throws IOException {
        int n;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] byArray = new byte[512];
        while ((n = inputStream.read(byArray, 0, byArray.length)) != -1) {
            byteArrayOutputStream.write(byArray, 0, n);
        }
        return new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);
    }
}
