package starclient.alpha.ui.menu.main.newgui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.ui.menu.altmanager.GuiAltManager;
import starclient.alpha.ui.menu.widgets.newbuttons.NewButtons;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;
import starclient.alpha.utility.render.particle.Particle;

public class NewMainMenu
extends GuiScreen {
    final ResourceLocation WALL = new ResourceLocation("starclient/image/wall.jpg");
    private final ArrayList<Particle> particles = new ArrayList();

    @Override
    public void initGui() {
        int n;
        this.width = new ScaledResolution(mc).getScaledWidth();
        this.height = new ScaledResolution(mc).getScaledHeight();
        this.particles.clear();
        for (n = 0; n < 150; ++n) {
            this.particles.add(new Particle());
        }
        n = 120;
        int n2 = 20;
        int n3 = -10;
        this.addButton(new NewButtons(0, this.width / 2 - n / 2, this.height / 2 - 44, n, n2, "\u041e\u0434\u0438\u043d\u043e\u0447\u043d\u0430\u044f \u0438\u0433\u0440\u0430"));
        this.addButton(new NewButtons(1, this.width / 2 - n / 2, this.height / 2 - 20, n, n2, "\u0412\u044b\u0431\u043e\u0440 \u0441\u0435\u0440\u0432\u0435\u0440\u0430"));
        this.addButton(new NewButtons(2, this.width / 2 - n / 2, this.height / 2 + 14 + n3, n, n2, "AltManager"));
        this.addButton(new NewButtons(3, this.width / 2 - n / 2, this.height / 2 + 48 + n3 * 2, n, n2, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"));
        this.addButton(new NewButtons(4, this.width / 2 - n / 2, this.height / 2 + 82 + n3 * 3, n, n2, "\u0412\u044b\u0439\u0442\u0438"));
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n3 = scaledResolution.getScaledWidth();
        int n4 = scaledResolution.getScaledHeight();
        RenderUtility.drawImage(this.WALL, 0, 0, this.width, this.height, -1);
        GlStateManager.pushMatrix();
        this.particles.forEach(particle -> {
            particle.update(n, n2, n3, n4);
            particle.draw(this.particles, n, n2);
        });
        Color[] colorArray = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().getColors();
        int n5 = StarClient.getInstance().getC(0).getRGB();
        int n6 = StarClient.getInstance().getC(500).getRGB();
        RenderUtility.drawGradientGlow((float)n3 / 2.0f - 70.0f, (float)n4 / 2.0f - 90.0f, 140.0f, 180.0f, 8, new Color(n5), new Color(n6));
        RenderUtility.drawRoundedRect((float)n3 / 2.0f - 70.0f, (float)n4 / 2.0f - 90.0f, 140.0f, 180.0f, 8.0f, colorArray[0].getRGB());
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        int n7 = bl ? new Color(255, 255, 255).getRGB() : new Color(0, 0, 0).getRGB();
        float f2 = -56.0f;
        float f3 = 70.0f;
        float f4 = (float)n3 / 2.0f + f2;
        float f5 = (float)n4 / 2.0f - f3;
        Fonts.tenacityBold45.drawGradientString(StarClient.NAME, f4 + 4.0f, f5 - 5.0f, new Color(n5), new Color(n6));
        Fonts.mntsb18.drawString("v" + StarClient.VERSION, f4 + 95.0f, f5 - 8.0f, n7);
        super.drawScreen(n, n2, f);
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        switch (guiButton.id) {
            case 0: {
                mc.displayGuiScreen(new GuiWorldSelection(this));
                break;
            }
            case 1: {
                mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            }
            case 2: {
                mc.displayGuiScreen(new GuiAltManager());
                break;
            }
            case 3: {
                mc.displayGuiScreen(new GuiOptions(this, NewMainMenu.mc.gameSettings));
                break;
            }
            case 4: {
                mc.shutdown();
            }
        }
        super.actionPerformed(guiButton);
    }
}
