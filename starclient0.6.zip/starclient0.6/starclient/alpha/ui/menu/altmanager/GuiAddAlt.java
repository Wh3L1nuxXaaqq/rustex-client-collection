package starclient.alpha.ui.menu.altmanager;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.awt.Color;
import java.io.IOException;
import java.net.Proxy;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import starclient.alpha.ui.menu.altmanager.GuiAltManager;
import starclient.alpha.ui.menu.altmanager.alt.Alt;
import starclient.alpha.ui.menu.altmanager.alt.AltManager;
import starclient.alpha.ui.menu.widgets.PasswordField;
import starclient.alpha.ui.menu.widgets.TextField;
import starclient.alpha.ui.menu.widgets.newbuttons.NewButtons;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;
import starclient.alpha.utility.render.particle.Particle;

public class GuiAddAlt
extends GuiScreen {
    private TextField nameField;
    private PasswordField passwordField;
    private final ArrayList<Particle> particles = new ArrayList();
    private String status = String.valueOf((Object)TextFormatting.GRAY) + "Add Alt";
    private final GuiAltManager guiAltManager = new GuiAltManager();

    protected GuiAddAlt() {
    }

    @Override
    public void initGui() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n = scaledResolution.getScaledWidth();
        int n2 = scaledResolution.getScaledHeight();
        this.particles.clear();
        for (int i = 0; i < 100; ++i) {
            this.particles.add(new Particle());
        }
        Keyboard.enableRepeatEvents((boolean)true);
        this.nameField = new TextField(this.eventButton, Fonts.mntsb17, n / 2 - 100, n2 / 2 - 40, 200, 20);
        this.passwordField = new PasswordField(this.eventButton, Fonts.mntsb17, n / 2 - 100, n2 / 2 + 5, 200, 20);
        this.addButton(new NewButtons(0, n / 2 - 102, n2 / 2 + 40, 98, 22, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c"));
        this.addButton(new NewButtons(1, n / 2 + 4, n2 / 2 + 40, 98, 22, "\u0412\u0435\u0440\u043d\u0443\u0442\u0441\u044f"));
        super.initGui();
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n3 = scaledResolution.getScaledWidth();
        int n4 = scaledResolution.getScaledHeight();
        GlStateManager.pushMatrix();
        RenderUtility.drawRect(0.0f, 0.0f, n3, n4, new Color(20, 20, 20).getRGB());
        this.particles.forEach(particle -> {
            particle.update(n, n2, n3, n4);
            particle.draw(this.particles, n, n2);
        });
        Fonts.mntsb17.drawStringWithShadow("\u041d\u0438\u043a", (float)n3 / 2.0f - 100.0f, (float)n4 / 2.0f - 52.0f, -7829368);
        this.nameField.drawTextBox();
        Fonts.mntsb17.drawStringWithShadow("\u041f\u0430\u0440\u043e\u043b\u044c", (float)n3 / 2.0f - 100.0f, (float)n4 / 2.0f - 7.0f, -7829368);
        this.passwordField.drawTextBox();
        Fonts.mntsb17.drawCenteredString(this.status, (float)n3 / 2.0f, 10.0f, -1);
        super.drawScreen(n, n2, f);
        GlStateManager.popMatrix();
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        this.nameField.mouseClicked(n, n2, n3);
        this.passwordField.mouseClicked(n, n2, n3);
        super.mouseClicked(n, n2, n3);
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        if (n == 1) {
            mc.displayGuiScreen(new GuiAltManager());
        } else {
            this.nameField.textboxKeyTyped(c, n);
            this.passwordField.textboxKeyTyped(c, n);
            if (c == '\t' && (this.nameField.isFocused() || this.passwordField.isFocused())) {
                this.nameField.setFocused(!this.nameField.isFocused());
                this.passwordField.setFocused(!this.passwordField.isFocused());
            }
            super.keyTyped(c, n);
        }
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        switch (guiButton.id) {
            case 0: {
                AddAltThread addAltThread = new AddAltThread(this.nameField.getText(), this.passwordField.getText());
                addAltThread.start();
                break;
            }
            case 1: {
                mc.displayGuiScreen(this.guiAltManager);
            }
        }
        super.actionPerformed(guiButton);
    }

    private static void setStatus(GuiAddAlt guiAddAlt, String string) {
        guiAddAlt.status = string;
    }

    private class AddAltThread
    extends Thread {
        private final String password;
        private final String username;

        AddAltThread(String string, String string2) {
            this.username = string;
            this.password = string2;
            GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.GRAY) + "Add Alt");
        }

        private void checkAndAddAlt(String string, String string2) {
            try {
                YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
                YggdrasilUserAuthentication yggdrasilUserAuthentication = (YggdrasilUserAuthentication)yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT);
                yggdrasilUserAuthentication.setUsername(string);
                yggdrasilUserAuthentication.setPassword(string2);
                try {
                    yggdrasilUserAuthentication.logIn();
                    AltManager.addAccount(new Alt(string, string2, yggdrasilUserAuthentication.getSelectedProfile().getName(), Alt.Status.Working, Alt.getCurrentDate()));
                    GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.GREEN) + "\u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0430\u043a\u043a\u0430\u0443\u043d\u0442 - " + String.valueOf((Object)TextFormatting.RED) + this.username + String.valueOf((Object)TextFormatting.WHITE) + " (Mojang)");
                }
                catch (AuthenticationException authenticationException) {
                    GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.RED) + "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f!");
                    authenticationException.printStackTrace();
                }
            }
            catch (Throwable throwable) {
                GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.RED) + "\u041e\u0448\u0438\u0431\u043a\u0430!");
                throwable.printStackTrace();
            }
        }

        @Override
        public void run() {
            if (this.password.equals("")) {
                AltManager.addAccount(new Alt(this.username, "", Alt.getCurrentDate()));
                GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.GREEN) + "\u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0430\u043a\u043a\u0430\u0443\u043d\u0442 - " + String.valueOf((Object)TextFormatting.RED) + this.username + String.valueOf((Object)TextFormatting.WHITE) + " (\u0431\u0435\u0437 \u043b\u0438\u0446\u0435\u043d\u0437\u0438\u0438)");
            } else {
                GuiAddAlt.setStatus(GuiAddAlt.this, String.valueOf((Object)TextFormatting.AQUA) + "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435...");
                this.checkAndAddAlt(this.username, this.password);
            }
        }
    }
}
