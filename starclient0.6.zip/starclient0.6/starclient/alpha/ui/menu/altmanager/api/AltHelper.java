package starclient.alpha.ui.menu.altmanager.api;

import java.lang.reflect.Field;

public class AltHelper {
    private String className;
    private Class<?> clazz;

    public AltHelper(String string) {
        try {
            this.clazz = Class.forName(string);
        }
        catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        }
    }

    public void setStaticField(String string, Object object) throws NoSuchFieldException, IllegalAccessException {
        Field field = this.clazz.getDeclaredField(string);
        field.setAccessible(true);
        Field field2 = Field.class.getDeclaredField("modifiers");
        field2.setAccessible(true);
        field2.setInt(field, field.getModifiers() & 0xFFFFFFEF);
        field.set(null, object);
    }
}
