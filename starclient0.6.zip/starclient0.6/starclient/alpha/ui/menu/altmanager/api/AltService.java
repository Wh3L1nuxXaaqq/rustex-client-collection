package starclient.alpha.ui.menu.altmanager.api;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import starclient.alpha.ui.menu.altmanager.api.AltHelper;

public class AltService {
    private final AltHelper userAuthentication = new AltHelper("com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication");
    private final AltHelper minecraftSession = new AltHelper("com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService");
    private EnumAltService currentService;

    public void switchService(EnumAltService enumAltService) throws NoSuchFieldException, IllegalAccessException {
        if (this.currentService != enumAltService) {
            this.reflectionFields(enumAltService.hostname);
            this.currentService = enumAltService;
        }
    }

    private void reflectionFields(String string2) throws NoSuchFieldException, IllegalAccessException {
        HashMap<String, URL> hashMap = new HashMap<String, URL>();
        String string3 = string2.contains("thealtening") ? "http" : "https";
        hashMap.put("ROUTE_AUTHENTICATE", this.constantURL(string3 + "://authserver." + string2 + ".com/authenticate"));
        hashMap.put("ROUTE_INVALIDATE", this.constantURL(string3 + "://authserver" + string2 + "com/invalidate"));
        hashMap.put("ROUTE_REFRESH", this.constantURL(string3 + "://authserver." + string2 + ".com/refresh"));
        hashMap.put("ROUTE_VALIDATE", this.constantURL(string3 + "://authserver." + string2 + ".com/validate"));
        hashMap.put("ROUTE_SIGNOUT", this.constantURL(string3 + "://authserver." + string2 + ".com/signout"));
        hashMap.forEach((string, uRL) -> {
            try {
                this.userAuthentication.setStaticField((String)string, uRL);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        });
        this.userAuthentication.setStaticField("BASE_URL", string3 + "://authserver." + string2 + ".com/");
        this.minecraftSession.setStaticField("BASE_URL", string3 + "://sessionserver." + string2 + ".com/session/minecraft/");
        this.minecraftSession.setStaticField("JOIN_URL", this.constantURL(string3 + "://sessionserver." + string2 + ".com/session/minecraft/join"));
        this.minecraftSession.setStaticField("CHECK_URL", this.constantURL(string3 + "://sessionserver." + string2 + ".com/session/minecraft/hasJoined"));
        this.minecraftSession.setStaticField("WHITELISTED_DOMAINS", new String[]{".minecraft.net", ".mojang.com", ".thealtening.com"});
    }

    private URL constantURL(String string) {
        try {
            return new URL(string);
        }
        catch (MalformedURLException malformedURLException) {
            return null;
        }
    }

    public static enum EnumAltService {
        MOJANG("MOJANG", 0, "mojang"),
        THEALTENING("THEALTENING", 1, "thealtening");

        String hostname;

        private EnumAltService(String string2, int n2, String string3) {
            this.hostname = string3;
        }
    }
}
