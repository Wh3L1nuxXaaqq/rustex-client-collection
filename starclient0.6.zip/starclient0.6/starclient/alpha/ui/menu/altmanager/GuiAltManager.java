package starclient.alpha.ui.menu.altmanager;

import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import net.minecraft.util.StringUtils;
import net.minecraft.util.text.TextFormatting;
import org.apache.commons.lang3.RandomStringUtils;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.ui.menu.altmanager.GuiAddAlt;
import starclient.alpha.ui.menu.altmanager.alt.Alt;
import starclient.alpha.ui.menu.altmanager.alt.AltLoginThread;
import starclient.alpha.ui.menu.altmanager.alt.AltManager;
import starclient.alpha.ui.menu.main.newgui.NewMainMenu;
import starclient.alpha.ui.menu.widgets.CustomButton;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.StencilUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.EaseInOutQuad;
import starclient.alpha.utility.render.font.Fonts;

public class GuiAltManager
extends GuiScreen {
    public Alt selectedAlt = null;
    private AltLoginThread loginThread;
    public int scrollY = 0;
    private ResourceLocation resourceLocation;
    private Animation openAnimation;

    @Override
    public void initGui() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n = scaledResolution.getScaledWidth();
        int n2 = scaledResolution.getScaledHeight();
        this.addButton(new CustomButton(0, n / 2 - 121, n2 - 48, 57, 20, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c"));
        this.addButton(new CustomButton(1, n / 2 - 59, n2 - 48, 57, 20, "\u0421\u043b\u0443\u0447\u0430\u0439\u043d\u044b\u0439"));
        this.addButton(new CustomButton(2, n / 2 + 3, n2 - 48, 57, 20, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"));
        this.addButton(new CustomButton(3, n / 2 + 65, n2 - 48, 57, 20, "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c"));
        this.addButton(new CustomButton(4, n / 2 - 121, n2 - 24, 243, 20, "\u0412\u0435\u0440\u043d\u0443\u0442\u044c\u0441\u044f"));
        super.initGui();
    }

    private void getDownloadImageSkin(Alt alt, String string) {
        TextureManager textureManager = mc.getTextureManager();
        textureManager.getTexture(alt.getSkin());
        ThreadDownloadImageData threadDownloadImageData = new ThreadDownloadImageData(null, String.format("https://minotar.net/skin/%s", StringUtils.stripControlCodes(string)), DefaultPlayerSkin.getDefaultSkin(AbstractClientPlayer.getOfflineUUID(string)), new ImageBufferDownload());
        textureManager.loadTexture(alt.getSkin(), threadDownloadImageData);
    }

    @Override
    protected void actionPerformed(GuiButton guiButton) throws IOException {
        switch (guiButton.id) {
            case 0: {
                mc.displayGuiScreen(new GuiAddAlt());
                break;
            }
            case 1: {
                String string = "StarC" + RandomStringUtils.randomNumeric((int)6);
                AltManager.addAccount(new Alt(string, "", Alt.getCurrentDate()));
                this.openAnimation = new EaseInOutQuad(300, 1.0f, Direction.FORWARDS);
                GuiAltManager.mc.session = new Session(string, "", "", "mojang");
                break;
            }
            case 2: {
                if (this.loginThread != null) {
                    this.loginThread = null;
                }
                AltManager.removeAccount(this.selectedAlt);
                this.selectedAlt = null;
                break;
            }
            case 3: {
                AltManager.clearAccounts();
                break;
            }
            case 4: {
                mc.displayGuiScreen(new NewMainMenu());
            }
        }
        super.actionPerformed(guiButton);
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n3 = scaledResolution.getScaledWidth();
        int n4 = scaledResolution.getScaledHeight();
        int n5 = StarClient.getInstance().getC(0).getRGB();
        int n6 = StarClient.getInstance().getC(500).getRGB();
        GlStateManager.pushMatrix();
        RenderUtility.drawRect(0.0f, 0.0f, n3, n4, new Color(20, 20, 20).getRGB());
        int n7 = this.scrollY = (int)((float)this.scrollY + (float)Mouse.getDWheel() / 10.0f);
        StencilUtility.initStencilToWrite();
        RenderUtility.drawRect((float)n3 / 2.0f - 100.5f, 0.0f, 201.0f, n4 - 50, 3);
        StencilUtility.readStencilBuffer(1);
        for (Alt alt : AltManager.registry) {
            if (alt.equals(this.selectedAlt)) {
                RenderUtility.drawRoundedGradientRect((float)n3 / 2.0f - 100.5f, (float)(20 + n7) - 0.5f, 201.0f, 36.0f, 7.0f, 1.0f, n5, n5, n6, n6);
            }
            RenderUtility.drawRoundedRect((float)n3 / 2.0f - 100.0f, 20 + n7, 200.0f, 35.0f, 6.0f, new Color(30, 30, 30).getRGB());
            GlStateManager.pushMatrix();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            if (alt.getSkin() == null) {
                alt.setSkin(AbstractClientPlayer.getLocationSkin(alt.getUsername()));
                this.getDownloadImageSkin(alt, alt.getUsername());
            } else {
                mc.getTextureManager().bindTexture(alt.getSkin());
                GlStateManager.enableTexture2D();
                Gui.drawScaledCustomSizeModalRect(n3 / 2 - 95, 25 + n7, 8.0f, 8.0f, 8, 8, 25, 25, 64.0f, 64.0f);
            }
            GlStateManager.popMatrix();
            Object object = alt.getUsername();
            if (((String)object).equalsIgnoreCase(GuiAltManager.mc.session.getUsername())) {
                object = String.valueOf((Object)TextFormatting.GREEN) + (String)object;
            }
            Fonts.mntsb16.drawString((String)object, (float)n3 / 2.0f - 65.0f, 30 + n7, -1);
            Fonts.mntsb13.drawString(alt.getDate(), (float)n3 / 2.0f - 65.0f, 42.5f + (float)n7, -1);
            n7 += 40;
        }
        StencilUtility.uninitStencilBuffer();
        super.drawScreen(n, n2, f);
        GlStateManager.popMatrix();
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n4 = scaledResolution.getScaledHeight();
        int n5 = scaledResolution.getScaledWidth();
        int n6 = this.scrollY = (int)((float)this.scrollY + (float)Mouse.getDWheel() / 10.0f);
        for (Alt alt : AltManager.registry) {
            if (RenderUtility.isHovered(n, n2, (float)n5 / 2.0f - 100.0f, 20 + n6, 200.0f, 35.0f)) {
                if (this.selectedAlt == alt) {
                    this.loginThread = new AltLoginThread(this.selectedAlt);
                    this.loginThread.start();
                    return;
                }
                this.selectedAlt = alt;
            }
            n6 += 40;
        }
        super.mouseClicked(n, n2, n3);
    }
}
