package starclient.alpha.ui.menu.altmanager.alt;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.net.Proxy;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.ui.menu.altmanager.alt.Alt;

public class AltLoginThread
extends Thread {
    private final Alt alt;
    private final Minecraft mc = Minecraft.getMinecraft();
    private String status;

    public AltLoginThread(Alt alt) {
        this.alt = alt;
        this.status = "\u0420\u2019\u0412\u00a77Waiting...";
    }

    public Session login(String string, String string2) {
        YggdrasilUserAuthentication yggdrasilUserAuthentication;
        YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
        YggdrasilUserAuthentication yggdrasilUserAuthentication2 = yggdrasilUserAuthentication = new YggdrasilUserAuthentication(yggdrasilAuthenticationService, Agent.MINECRAFT);
        yggdrasilUserAuthentication2.setUsername(string);
        yggdrasilUserAuthentication2.setPassword(string2);
        try {
            yggdrasilUserAuthentication2.logIn();
            return new Session(yggdrasilUserAuthentication2.getSelectedProfile().getName(), yggdrasilUserAuthentication2.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication2.getAuthenticatedToken(), "mojang");
        }
        catch (AuthenticationException authenticationException) {
            return null;
        }
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String string) {
        this.status = string;
    }

    @Override
    public void run() {
        if (this.alt.getPassword().equals("")) {
            this.mc.session = new Session(this.alt.getUsername(), "", "", "mojang");
            this.status = String.valueOf((Object)TextFormatting.GREEN) + "Logged in - " + String.valueOf((Object)TextFormatting.WHITE) + this.alt.getUsername() + String.valueOf((Object)TextFormatting.BOLD) + String.valueOf((Object)TextFormatting.RED) + " (Not License)";
        } else {
            this.status = "Logging in...";
            Session session = this.login(this.alt.getUsername(), this.alt.getPassword());
            if (session == null) {
                this.status = "Connect failed!";
                if (this.alt.getStatus().equals((Object)Alt.Status.Unchecked)) {
                    this.alt.setStatus(Alt.Status.NotWorking);
                }
            } else {
                this.status = String.valueOf((Object)TextFormatting.GREEN) + "Logged in - " + String.valueOf((Object)TextFormatting.WHITE) + session.getUsername() + String.valueOf((Object)TextFormatting.BOLD) + String.valueOf((Object)TextFormatting.RED) + " (License)";
                this.alt.setMask(session.getUsername());
                this.mc.session = session;
            }
        }
    }
}
