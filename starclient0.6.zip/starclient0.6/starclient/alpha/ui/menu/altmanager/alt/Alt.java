package starclient.alpha.ui.menu.altmanager.alt;

import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class Alt {
    private final String username;
    private String mask;
    private String password;
    private Status status;
    private String date;
    private ResourceLocation skin;

    public Alt(String string, String string2, String string3) {
        this(string, string2, Status.Unchecked, string3);
    }

    public Alt(String string, String string2, Status status, String string3) {
        this(string, string2, "", status, string3);
    }

    public Alt(String string, String string2, String string3, Status status, String string4) {
        this.username = string;
        this.password = string2;
        this.mask = string3;
        this.status = status;
        this.date = string4;
    }

    public static String getCurrentDate() {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
    }

    public String getUsername() {
        return this.username;
    }

    public String getMask() {
        return this.mask;
    }

    public void setMask(String string) {
        this.mask = string;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String string) {
        this.password = string;
    }

    public Status getStatus() {
        return this.status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String string) {
        this.date = string;
    }

    public ResourceLocation getSkin() {
        return this.skin;
    }

    public void setSkin(ResourceLocation resourceLocation) {
        this.skin = resourceLocation;
    }

    public static enum Status {
        Working(String.valueOf((Object)((Object)TextFormatting.GREEN)) + "Working"),
        Banned(String.valueOf((Object)((Object)TextFormatting.RED)) + "Banned"),
        Unchecked(String.valueOf((Object)((Object)TextFormatting.YELLOW)) + "Unchecked"),
        NotWorking(String.valueOf((Object)((Object)TextFormatting.RED)) + "Not Working");

        private final String formatted;

        private Status(String string2) {
            this.formatted = string2;
        }

        public String toFormatted() {
            return this.formatted;
        }
    }
}
