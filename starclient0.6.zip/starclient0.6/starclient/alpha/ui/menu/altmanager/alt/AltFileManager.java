package starclient.alpha.ui.menu.altmanager.alt;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import net.minecraft.client.Minecraft;
import starclient.alpha.ui.menu.altmanager.alt.Alt;
import starclient.alpha.ui.menu.altmanager.alt.AltManager;

public class AltFileManager {
    private static final File altsFile = new File(Minecraft.getMinecraft().mcDataDir, "\\StarClient\\alts.star");

    public void init() throws IOException {
        if (!altsFile.exists()) {
            altsFile.createNewFile();
        } else {
            this.readAlts();
        }
    }

    private void readAlts() {
        try {
            String string;
            FileInputStream fileInputStream = new FileInputStream(altsFile.getAbsolutePath());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new DataInputStream(fileInputStream)));
            while ((string = bufferedReader.readLine()) != null) {
                String string2 = string.trim();
                String string3 = string2.split(";")[0];
                String string4 = string2.split(";")[1];
                String string5 = string2.split(";")[2];
                AltManager.registry.add(new Alt(string3, string4, string5));
            }
            bufferedReader.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void saveAll() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            AltManager.registry.forEach(alt -> stringBuilder.append(alt.getUsername()).append(";").append(alt.getPassword()).append(";").append(alt.getDate()).append("\n"));
            Files.write(altsFile.toPath(), stringBuilder.toString().getBytes(), new OpenOption[0]);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}
