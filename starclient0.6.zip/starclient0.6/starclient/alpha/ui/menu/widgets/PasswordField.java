package starclient.alpha.ui.menu.widgets;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPageButtonList;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.math.MathHelper;
import starclient.alpha.StarClient;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.FontRenderer;
import starclient.alpha.utility.render.font.Fonts;

public class PasswordField
extends Gui {
    private final int id;
    private final FontRenderer fontRendererInstance;
    public int xPosition;
    public int yPosition;
    private final int width;
    private final int height;
    private String text = "";
    private int maxStringLength = 32;
    private int cursorCounter;
    private boolean enableBackgroundDrawing = true;
    private boolean canLoseFocus = true;
    private boolean isFocused;
    private boolean isEnabled = true;
    private int lineScrollOffset;
    private int cursorPosition;
    private int selectionEnd;
    private int enabledColor = 0xE0E0E0;
    private int disabledColor = 0x707070;
    private boolean visible = true;
    private GuiPageButtonList.GuiResponder guiResponder;
    private Predicate<String> validator = Predicates.alwaysTrue();

    public PasswordField(int n, FontRenderer fontRenderer, int n2, int n3, int n4, int n5) {
        this.id = n;
        this.fontRendererInstance = fontRenderer;
        this.xPosition = n2;
        this.yPosition = n3;
        this.width = n4;
        this.height = n5;
    }

    public void setGuiResponder(GuiPageButtonList.GuiResponder guiResponder) {
        this.guiResponder = guiResponder;
    }

    public void updateCursorCounter() {
        ++this.cursorCounter;
    }

    public void setText(String string) {
        if (this.validator.apply(string)) {
            this.text = string.length() > this.maxStringLength ? string.substring(0, this.maxStringLength) : string;
            this.setCursorPositionEnd();
        }
    }

    public String getText() {
        return this.text;
    }

    public String getSelectedText() {
        int n = this.cursorPosition < this.selectionEnd ? this.cursorPosition : this.selectionEnd;
        int n2 = this.cursorPosition < this.selectionEnd ? this.selectionEnd : this.cursorPosition;
        return this.text.substring(n, n2);
    }

    public void setValidator(Predicate<String> predicate) {
        this.validator = predicate;
    }

    public void writeText(String string) {
        int n;
        Object object = "";
        String string2 = ChatAllowedCharacters.filterAllowedCharacters(string);
        int n2 = this.cursorPosition < this.selectionEnd ? this.cursorPosition : this.selectionEnd;
        int n3 = this.cursorPosition < this.selectionEnd ? this.selectionEnd : this.cursorPosition;
        int n4 = this.maxStringLength - this.text.length() - (n2 - n3);
        if (!this.text.isEmpty()) {
            object = (String)object + this.text.substring(0, n2);
        }
        if (n4 < string2.length()) {
            object = (String)object + string2.substring(0, n4);
            n = n4;
        } else {
            object = (String)object + string2;
            n = string2.length();
        }
        if (!this.text.isEmpty() && n3 < this.text.length()) {
            object = (String)object + this.text.substring(n3);
        }
        if (this.validator.apply((String)object)) {
            this.text = object;
            this.moveCursorBy(n2 - this.selectionEnd + n);
            this.func_190516_a(this.id, this.text);
        }
    }

    public void func_190516_a(int n, String string) {
        if (this.guiResponder != null) {
            this.guiResponder.setEntryValue(n, string);
        }
    }

    public void deleteWords(int n) {
        if (!this.text.isEmpty()) {
            if (this.selectionEnd != this.cursorPosition) {
                this.writeText("");
            } else {
                this.deleteFromCursor(this.getNthWordFromCursor(n) - this.cursorPosition);
            }
        }
    }

    public void deleteFromCursor(int n) {
        if (!this.text.isEmpty()) {
            if (this.selectionEnd != this.cursorPosition) {
                this.writeText("");
            } else {
                boolean bl = n < 0;
                int n2 = bl ? this.cursorPosition + n : this.cursorPosition;
                int n3 = bl ? this.cursorPosition : this.cursorPosition + n;
                Object object = "";
                if (n2 >= 0) {
                    object = this.text.substring(0, n2);
                }
                if (n3 < this.text.length()) {
                    object = (String)object + this.text.substring(n3);
                }
                if (this.validator.apply((String)object)) {
                    this.text = object;
                    if (bl) {
                        this.moveCursorBy(n);
                    }
                    this.func_190516_a(this.id, this.text);
                }
            }
        }
    }

    public int getId() {
        return this.id;
    }

    public int getNthWordFromCursor(int n) {
        return this.getNthWordFromPos(n, this.getCursorPosition());
    }

    public int getNthWordFromPos(int n, int n2) {
        return this.getNthWordFromPosWS(n, n2, true);
    }

    public int getNthWordFromPosWS(int n, int n2, boolean bl) {
        int n3 = n2;
        boolean bl2 = n < 0;
        int n4 = Math.abs(n);
        for (int i = 0; i < n4; ++i) {
            if (!bl2) {
                int n5 = this.text.length();
                if ((n3 = this.text.indexOf(32, n3)) == -1) {
                    n3 = n5;
                    continue;
                }
                while (bl && n3 < n5 && this.text.charAt(n3) == ' ') {
                    ++n3;
                }
                continue;
            }
            while (bl && n3 > 0 && this.text.charAt(n3 - 1) == ' ') {
                --n3;
            }
            while (n3 > 0 && this.text.charAt(n3 - 1) != ' ') {
                --n3;
            }
        }
        return n3;
    }

    public void moveCursorBy(int n) {
        this.setCursorPosition(this.selectionEnd + n);
    }

    public void setCursorPosition(int n) {
        this.cursorPosition = n;
        int n2 = this.text.length();
        this.cursorPosition = MathHelper.clamp(this.cursorPosition, 0, n2);
        this.setSelectionPos(this.cursorPosition);
    }

    public void setCursorPositionZero() {
        this.setCursorPosition(0);
    }

    public void setCursorPositionEnd() {
        this.setCursorPosition(this.text.length());
    }

    public boolean textboxKeyTyped(char c, int n) {
        if (!this.isFocused) {
            return false;
        }
        if (GuiScreen.isKeyComboCtrlA(n)) {
            this.setCursorPositionEnd();
            this.setSelectionPos(0);
            return true;
        }
        if (GuiScreen.isKeyComboCtrlC(n)) {
            GuiScreen.setClipboardString(this.getSelectedText());
            return true;
        }
        if (GuiScreen.isKeyComboCtrlV(n)) {
            if (this.isEnabled) {
                this.writeText(GuiScreen.getClipboardString());
            }
            return true;
        }
        if (GuiScreen.isKeyComboCtrlX(n)) {
            GuiScreen.setClipboardString(this.getSelectedText());
            if (this.isEnabled) {
                this.writeText("");
            }
            return true;
        }
        switch (n) {
            case 14: {
                if (GuiScreen.isCtrlKeyDown()) {
                    if (this.isEnabled) {
                        this.deleteWords(-1);
                    }
                } else if (this.isEnabled) {
                    this.deleteFromCursor(-1);
                }
                return true;
            }
            case 199: {
                if (GuiScreen.isShiftKeyDown()) {
                    this.setSelectionPos(0);
                } else {
                    this.setCursorPositionZero();
                }
                return true;
            }
            case 203: {
                if (GuiScreen.isShiftKeyDown()) {
                    if (GuiScreen.isCtrlKeyDown()) {
                        this.setSelectionPos(this.getNthWordFromPos(-1, this.getSelectionEnd()));
                    } else {
                        this.setSelectionPos(this.getSelectionEnd() - 1);
                    }
                } else if (GuiScreen.isCtrlKeyDown()) {
                    this.setCursorPosition(this.getNthWordFromCursor(-1));
                } else {
                    this.moveCursorBy(-1);
                }
                return true;
            }
            case 205: {
                if (GuiScreen.isShiftKeyDown()) {
                    if (GuiScreen.isCtrlKeyDown()) {
                        this.setSelectionPos(this.getNthWordFromPos(1, this.getSelectionEnd()));
                    } else {
                        this.setSelectionPos(this.getSelectionEnd() + 1);
                    }
                } else if (GuiScreen.isCtrlKeyDown()) {
                    this.setCursorPosition(this.getNthWordFromCursor(1));
                } else {
                    this.moveCursorBy(1);
                }
                return true;
            }
            case 207: {
                if (GuiScreen.isShiftKeyDown()) {
                    this.setSelectionPos(this.text.length());
                } else {
                    this.setCursorPositionEnd();
                }
                return true;
            }
            case 211: {
                if (GuiScreen.isCtrlKeyDown()) {
                    if (this.isEnabled) {
                        this.deleteWords(1);
                    }
                } else if (this.isEnabled) {
                    this.deleteFromCursor(1);
                }
                return true;
            }
        }
        if (ChatAllowedCharacters.isAllowedCharacter(c)) {
            if (this.isEnabled) {
                this.writeText(Character.toString(c));
            }
            return true;
        }
        return false;
    }

    public boolean mouseClicked(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = bl = n >= this.xPosition && n < this.xPosition + this.width && n2 >= this.yPosition && n2 < this.yPosition + this.height;
        if (this.canLoseFocus) {
            this.setFocused(bl);
        }
        if (this.isFocused && bl && n3 == 0) {
            int n4 = n - this.xPosition;
            if (this.enableBackgroundDrawing) {
                n4 -= 4;
            }
            String string = this.fontRendererInstance.trimStringToWidth(this.text.substring(this.lineScrollOffset), this.getWidth(), true);
            this.setCursorPosition(this.fontRendererInstance.trimStringToWidth(string, n4, true).length() + this.lineScrollOffset);
            return true;
        }
        return false;
    }

    public void drawTextBox() {
        if (this.getVisible()) {
            int n;
            int n2;
            int n3;
            if (this.getEnableBackgroundDrawing()) {
                n3 = StarClient.getInstance().getC(0).getRGB();
                n2 = StarClient.getInstance().getC(500).getRGB();
                RenderUtility.drawGradientGlow((float)this.xPosition, (float)this.yPosition, (float)this.width, (float)this.height, 5, n3, n3, n2, n2);
                RenderUtility.drawRoundedRect(this.xPosition, this.yPosition, this.width, this.height, 5.0f, new Color(30, 30, 30).getRGB());
            }
            n3 = this.isEnabled ? this.enabledColor : this.disabledColor;
            n2 = this.cursorPosition - this.lineScrollOffset;
            int n4 = this.selectionEnd - this.lineScrollOffset;
            String string = this.fontRendererInstance.trimStringToWidth(this.text.substring(this.lineScrollOffset), this.getWidth(), true);
            boolean bl = n2 >= 0 && n2 <= string.length();
            boolean bl2 = this.isFocused && this.cursorCounter / 6 % 2 == 0 && bl;
            int n5 = this.enableBackgroundDrawing ? this.xPosition + 4 : this.xPosition;
            int n6 = this.enableBackgroundDrawing ? this.yPosition + (this.height - 8) / 2 : this.yPosition;
            int n7 = n5;
            if (n4 > string.length()) {
                n4 = string.length();
            }
            if (!string.isEmpty()) {
                String string2 = bl ? string.substring(0, n2) : string;
                n7 = (int)this.fontRendererInstance.drawStringWithShadow(string2.replaceAll("(?s).", "*"), n5, (float)n6 + 1.5f, n3);
            }
            boolean bl3 = this.cursorPosition < this.text.length() || this.text.length() >= this.getMaxStringLength();
            int n8 = n7;
            if (!bl) {
                n8 = n2 > 0 ? n5 + this.width : n5;
            } else if (bl3) {
                n8 = n7 - 1;
                --n7;
            }
            if (!string.isEmpty() && bl && n2 < string.length()) {
                n = (int)this.fontRendererInstance.drawStringWithShadow(string.substring(n2), n7, (float)n6 + 1.5f, n3);
            }
            if (bl2) {
                if (bl3) {
                    Gui.drawRect(n8, n6 - 1, n8 + 1, n6 + 1 + this.fontRendererInstance.getFontHeight(), -3092272);
                } else {
                    Fonts.mntsb17.drawStringWithShadow("_", (float)n8 + 1.0f, (float)n6 + 1.5f, n3);
                }
            }
            if (n4 != n2) {
                n = n5 + this.fontRendererInstance.getStringWidth(string.substring(0, n4));
                this.drawCursorVertical(n8, n6 - 1, n - 1, n6 + 1 + this.fontRendererInstance.getFontHeight());
            }
        }
    }

    private void drawCursorVertical(int n, int n2, int n3, int n4) {
        int n5;
        if (n < n3) {
            n5 = n;
            n = n3;
            n3 = n5;
        }
        if (n2 < n4) {
            n5 = n2;
            n2 = n4;
            n4 = n5;
        }
        if (n3 > this.xPosition + this.width) {
            n3 = this.xPosition + this.width;
        }
        if (n > this.xPosition + this.width) {
            n = this.xPosition + this.width;
        }
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        GlStateManager.color(0.0f, 0.0f, 255.0f, 255.0f);
        GlStateManager.disableTexture2D();
        GlStateManager.enableColorLogic();
        GlStateManager.colorLogicOp(GlStateManager.LogicOp.OR_REVERSE);
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferBuilder.pos(n, n4, 0.0).endVertex();
        bufferBuilder.pos(n3, n4, 0.0).endVertex();
        bufferBuilder.pos(n3, n2, 0.0).endVertex();
        bufferBuilder.pos(n, n2, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.disableColorLogic();
        GlStateManager.enableTexture2D();
    }

    public void setMaxStringLength(int n) {
        this.maxStringLength = n;
        if (this.text.length() > n) {
            this.text = this.text.substring(0, n);
        }
    }

    public int getMaxStringLength() {
        return this.maxStringLength;
    }

    public int getCursorPosition() {
        return this.cursorPosition;
    }

    public boolean getEnableBackgroundDrawing() {
        return this.enableBackgroundDrawing;
    }

    public void setEnableBackgroundDrawing(boolean bl) {
        this.enableBackgroundDrawing = bl;
    }

    public void setTextColor(int n) {
        this.enabledColor = n;
    }

    public void setDisabledTextColour(int n) {
        this.disabledColor = n;
    }

    public void setFocused(boolean bl) {
        if (bl && !this.isFocused) {
            this.cursorCounter = 0;
        }
        this.isFocused = bl;
        if (Minecraft.getMinecraft().currentScreen != null) {
            Minecraft.getMinecraft().currentScreen.setFocused(bl);
        }
    }

    public boolean isFocused() {
        return this.isFocused;
    }

    public void setEnabled(boolean bl) {
        this.isEnabled = bl;
    }

    public int getSelectionEnd() {
        return this.selectionEnd;
    }

    public int getWidth() {
        return this.getEnableBackgroundDrawing() ? this.width - 8 : this.width;
    }

    public void setSelectionPos(int n) {
        int n2 = this.text.length();
        if (n > n2) {
            n = n2;
        }
        if (n < 0) {
            n = 0;
        }
        this.selectionEnd = n;
        if (this.fontRendererInstance != null) {
            if (this.lineScrollOffset > n2) {
                this.lineScrollOffset = n2;
            }
            int n3 = this.getWidth();
            String string = this.fontRendererInstance.trimStringToWidth(this.text.substring(this.lineScrollOffset), n3, true);
            int n4 = string.length() + this.lineScrollOffset;
            if (n == this.lineScrollOffset) {
                this.lineScrollOffset -= this.fontRendererInstance.trimStringToWidth(this.text, n3, true).length();
            }
            if (n > n4) {
                this.lineScrollOffset += n - n4;
            } else if (n <= this.lineScrollOffset) {
                this.lineScrollOffset -= this.lineScrollOffset - n;
            }
            this.lineScrollOffset = MathHelper.clamp(this.lineScrollOffset, 0, n2);
        }
    }

    public void setCanLoseFocus(boolean bl) {
        this.canLoseFocus = bl;
    }

    public boolean getVisible() {
        return this.visible;
    }

    public void setVisible(boolean bl) {
        this.visible = bl;
    }
}
