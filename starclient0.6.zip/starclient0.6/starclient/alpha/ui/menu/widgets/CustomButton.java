package starclient.alpha.ui.menu.widgets;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;
import starclient.alpha.utility.render.font.Fonts;

public class CustomButton
extends GuiButton {
    public DecelerateAnimation animation = new DecelerateAnimation(300, 1.0f, Direction.BACKWARDS);

    public CustomButton(int n, int n2, int n3, int n4, int n5, String string) {
        super(n, n2, n3, n4, n5, string);
    }

    @Override
    public void func_191745_a(Minecraft minecraft, int n, int n2, float f) {
        if (this.visible) {
            int n3 = StarClient.getInstance().getC(0).getRGB();
            int n4 = StarClient.getInstance().getC(500).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            int n5 = bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB();
            this.hovered = n >= this.x && n2 >= this.y && n < this.x + this.width && n2 < this.y + this.height;
            this.animation.setDirection(this.hovered ? Direction.FORWARDS : Direction.BACKWARDS);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, n5);
            if (this.hovered) {
                RenderUtility.drawGradientGlow((float)this.x, (float)this.y, (float)this.width, (float)this.height, 5, ColorUtility.setAlpha(n3, this.animation.getOutput()), ColorUtility.setAlpha(n4, this.animation.getOutput()), ColorUtility.setAlpha(n3, this.animation.getOutput()), ColorUtility.setAlpha(n4, this.animation.getOutput()));
                RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, n5);
                Fonts.nunitoBold16.drawGradientCenteredString(this.displayString, (float)this.x + (float)this.width / 2.0f, (float)this.y + (float)(this.height - 8) / 2.0f + 1.0f, new Color(n3), new Color(n4));
            } else {
                Fonts.nunitoBold16.drawCenteredString(this.displayString, (float)this.x + (float)this.width / 2.0f, (float)this.y + (float)(this.height - 8) / 2.0f + 1.0f, -1);
            }
        }
    }
}
