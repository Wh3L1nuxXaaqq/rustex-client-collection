package starclient.alpha.ui.menu.widgets.newbuttons;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import starclient.alpha.utility.misc.SoundUtility;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;

public class KnopkaBINDIKI
extends Gui {
    protected static final ResourceLocation BUTTON_TEXTURES = new ResourceLocation("textures/gui/widgets.png");
    protected int width = 200;
    protected int height = 20;
    public int xPosition;
    public int x;
    public int yPosition;
    public int y;
    public String displayString;
    public int id;
    public boolean enabled = true;
    public boolean visible = true;
    protected boolean hovered;
    public DecelerateAnimation animation;

    public KnopkaBINDIKI(int n, int n2, int n3, String string) {
        this(n, n2, n3, 200, 20, string);
        this.animation = new DecelerateAnimation(300, 1.0f, Direction.BACKWARDS);
    }

    public KnopkaBINDIKI(int n, int n2, int n3, int n4, int n5, String string) {
        this.id = n;
        this.xPosition = n2;
        this.yPosition = n3;
        this.x = n2;
        this.y = n3;
        this.width = n4;
        this.height = n5;
        this.displayString = string;
        this.animation = new DecelerateAnimation(300, 1.0f, Direction.BACKWARDS);
    }

    protected int getHoverState(boolean bl) {
        int n = 1;
        if (!this.enabled) {
            n = 0;
        } else if (bl) {
            n = 2;
        }
        return n;
    }

    public void func_191745_a(Minecraft minecraft, int n, int n2, float f) {
        if (this.visible) {
            FontRenderer fontRenderer = minecraft.fontRendererObj;
            minecraft.getTextureManager().bindTexture(BUTTON_TEXTURES);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            this.hovered = n >= this.xPosition && n2 >= this.yPosition && n < this.xPosition + this.width && n2 < this.yPosition + this.height;
            int n3 = this.getHoverState(this.hovered);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + n3 * 20, this.width / 2, this.height);
            this.drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + n3 * 20, this.width / 2, this.height);
            this.mouseDragged(minecraft, n, n2);
            int n4 = 0xE0E0E0;
            if (!this.enabled) {
                n4 = 0xA0A0A0;
            } else if (this.hovered) {
                n4 = 0xFFFFA0;
            }
            this.drawCenteredString(fontRenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, n4);
        }
    }

    protected void mouseDragged(Minecraft minecraft, int n, int n2) {
    }

    public void mouseReleased(int n, int n2) {
    }

    public boolean mousePressed(Minecraft minecraft, int n, int n2) {
        return this.enabled && this.visible && n >= this.xPosition && n2 >= this.yPosition && n < this.xPosition + this.width && n2 < this.yPosition + this.height;
    }

    public boolean isMouseOver() {
        return this.hovered;
    }

    public void drawButtonForegroundLayer(int n, int n2) {
    }

    public void playPressSound(SoundHandler soundHandler) {
        SoundUtility.playSound("buttonclick.wav", 0.5f);
    }

    public int getButtonWidth() {
        return this.width;
    }

    public void setWidth(int n) {
        this.width = n;
    }
}
