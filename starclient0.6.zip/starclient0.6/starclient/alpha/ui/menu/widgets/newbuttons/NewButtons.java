package starclient.alpha.ui.menu.widgets.newbuttons;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;
import starclient.alpha.utility.render.font.Fonts;

public class NewButtons
extends GuiButton {
    public DecelerateAnimation animation = new DecelerateAnimation(300, 1.0f, Direction.BACKWARDS);

    public NewButtons(int n, int n2, int n3, int n4, int n5, String string) {
        super(n, n2, n3, n4, n5, string);
    }

    @Override
    public void func_191745_a(Minecraft minecraft, int n, int n2, float f) {
        if (this.visible) {
            int n3 = ColorUtility.applyOpacity(StarClient.getInstance().getC(0), this.animation.getOutput()).getRGB();
            int n4 = ColorUtility.applyOpacity(StarClient.getInstance().getC(500), this.animation.getOutput()).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            int n5 = bl ? new Color(30, 30, 30).getRGB() : new Color(255, 255, 255).getRGB();
            int n6 = bl ? new Color(11, 11, 11).getRGB() : new Color(175, 175, 175).getRGB();
            int n7 = bl ? new Color(255, 255, 255).getRGB() : new Color(44, 44, 44).getRGB();
            this.hovered = n >= this.x && n2 >= this.y && n < this.x + this.width && n2 < this.y + this.height;
            this.animation.setDirection(this.hovered ? Direction.FORWARDS : Direction.BACKWARDS);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            if (this.hovered) {
                RenderUtility.drawGradientGlow((float)this.x, (float)this.y, (float)this.width, (float)this.height, 10, n3, n4, n3, n4);
                RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, n5);
                RenderUtility.drawRoundedGradientRect(this.x, this.y, this.width, this.height, 5.0f, 1.0f, n3, n4, n3, n4);
            } else {
                RenderUtility.drawFixedGlow(this.x, this.y, this.width, this.height, 10, n6);
                RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, n5);
            }
            int n8 = Fonts.mntsb16.getStringWidth(this.displayString);
            int n9 = this.x + (this.width - n8) / 2;
            int n10 = this.y + (this.height - Fonts.mntsb16.getFontHeight()) / 2;
            Fonts.mntsb16.drawString(this.displayString, n9, n10, n7);
        }
    }
}
