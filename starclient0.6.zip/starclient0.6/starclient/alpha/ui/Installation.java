package starclient.alpha.ui;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import starclient.alpha.utility.render.font.Fonts;

public class Installation
extends GuiScreen {
    private static final ResourceLocation BACKGROUND = new ResourceLocation("starclient/textures/loading.png");
    private static float progress = 0.0f;
    private static String status = "Initializing...";
    private static Installation instance;

    public static void setProgress(float f) {
        progress = Math.min(f, 1.0f);
    }

    public static void setStatus(String string) {
        status = string;
    }

    public static void update() {
        try {
            if (instance == null) {
                instance = new Installation();
            }
            Minecraft minecraft = Minecraft.getMinecraft();
            if (!(minecraft.currentScreen instanceof Installation)) {
                minecraft.displayGuiScreen(instance);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int n3 = scaledResolution.getScaledWidth();
        int n4 = scaledResolution.getScaledHeight();
        mc.getTextureManager().bindTexture(BACKGROUND);
        Installation.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, n3, n4, n3, n4);
        int n5 = 400;
        int n6 = 20;
        int n7 = (n3 - n5) / 2;
        int n8 = n4 - 100;
        Installation.drawRect(n7, n8, n7 + n5, n8 + n6, new Color(50, 50, 50, 200).getRGB());
        int n9 = (int)((float)n5 * progress);
        Installation.drawRect(n7, n8, n7 + n9, n8 + n6, new Color(0, 128, 255, 200).getRGB());
        String string = String.format("%.0f%%", Float.valueOf(progress * 100.0f));
        int n10 = Fonts.sfpro18.getStringWidth(string);
        Fonts.sfpro18.drawStringWithShadow(string, n7 + (n5 - n10) / 2, n8 + (n6 - 8) / 2, Color.WHITE.getRGB());
        int n11 = (n3 - Fonts.sfpro18.getStringWidth(status)) / 2;
        int n12 = n8 + 30;
        Fonts.sfpro18.drawStringWithShadow(status, n11, n12, Color.WHITE.getRGB());
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
