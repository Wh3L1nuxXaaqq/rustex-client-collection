package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.ModuleComponent;
import starclient.alpha.utility.math.MathUtility;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.font.Fonts;

public class SliderComponent
extends Component {
    public ModuleComponent moduleComponent;
    public NumberSetting setting;
    public float animation = 0.0f;
    public boolean isDragging;

    public SliderComponent(ModuleComponent moduleComponent, NumberSetting numberSetting) {
        super(0.0f, 0.0f, 0.0f, 19.0f);
        this.moduleComponent = moduleComponent;
        this.setting = numberSetting;
    }

    @Override
    public void render(int n, int n2) {
        super.render(n, n2);
        int n3 = StarClient.getInstance().getC(0).getRGB();
        int n4 = StarClient.getInstance().getC(500).getRGB();
        int n5 = ColorUtility.interpolateColorC(n3, n4, 0.5f).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Fonts.mntssb13.drawString(this.setting.getName(), this.x + 5.0f, this.y + 4.5f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
        RenderUtility.drawRoundedRect(this.x + 5.0f, this.y + 12.0f, this.width - 10.0f, 3.5f, 2.0f, bl ? new Color(25, 25, 25).getRGB() : new Color(160, 160, 160).getRGB());
        float f = (float)(((double)this.setting.get() - this.setting.getMinValue()) / (this.setting.getMaxValue() - this.setting.getMinValue()) * (double)(this.width - 10.0f));
        this.animation = AnimationMath.fast(this.animation, f, 15.0f);
        RenderUtility.drawRoundedRect(this.x + 5.0f, this.y + 12.0f, this.animation, 3.5f, 2.0f, n5);
        RenderUtility.drawGlow(this.x + this.animation + 3.5f, this.y + 10.5f, 5.5f, 5.5f, 4, Color.BLACK);
        RenderUtility.drawRoundedRect(this.x + this.animation + 3.5f, this.y + 11.2f, 5.0f, 5.0f, 5.0f, -1);
        if (this.isDragging) {
            if (!Mouse.isButtonDown((int)0)) {
                this.isDragging = false;
            }
            float f2 = (float)MathHelper.clamp(MathUtility.round((float)((double)(((float)n - this.x - 5.0f) / (this.width - 10.0f)) * (this.setting.getMaxValue() - this.setting.getMinValue()) + this.setting.getMinValue()), this.setting.getIncrement()), this.setting.getMinValue(), this.setting.getMaxValue());
            this.setting.set(f2);
        }
        Fonts.mntssb13.drawString(String.valueOf(this.setting.get()), this.x + this.width - 7.0f - (float)Fonts.nunito12.getStringWidth(String.valueOf(this.setting.get())), this.y + 4.5f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        super.mouseClicked(d, d2, n);
        boolean bl = RenderUtility.isHovered(d, d2, (double)this.x, (double)this.y, (double)this.width, (double)this.height);
        if (bl && n == 0) {
            this.isDragging = true;
        }
    }

    @Override
    public boolean isVisible() {
        return this.setting.getVisible().get();
    }
}
