package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import java.util.Comparator;
import java.util.stream.Collectors;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.ModuleComponent;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

public class MultiBoolComponent
extends Component {
    public ModuleComponent moduleComponent;
    public MultiBooleanSetting setting;

    public MultiBoolComponent(ModuleComponent moduleComponent, MultiBooleanSetting multiBooleanSetting) {
        super(0.0f, 0.0f, 0.0f, 18.0f);
        this.moduleComponent = moduleComponent;
        this.setting = multiBooleanSetting;
    }

    @Override
    public void render(int n, int n2) {
        super.render(n, n2);
        int n3 = StarClient.getInstance().getC(0).getRGB();
        int n4 = StarClient.getInstance().getC(500).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Fonts.mntssb13.drawString(this.setting.getName(), this.x + 5.0f, this.y + 3.0f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
        float f = this.width - 10.0f;
        float f2 = 2.0f;
        float f3 = 6.0f;
        float f4 = 3.5f;
        for (String string : this.setting.values.stream().sorted(Comparator.comparingDouble(this::getEnabledWidth)).collect(Collectors.toList())) {
            float f5 = this.getEnabledWidth(string);
            float f6 = Fonts.mntssb13.getFontHeight() + 6;
            if (f2 + f5 > f) {
                f2 = 2.0f;
                f3 += f6 + f4;
            }
            if (this.setting.selectedValues.get(this.setting.values.indexOf(string)).booleanValue()) {
                RenderUtility.drawRoundedGradientRect(this.x + 3.0f + f2, this.y + (float)Fonts.mntssb13.getFontHeight() + f3, f5, f6, 3.0f, 1.0f, StarClient.getInstance().getC(0).getRGB(), StarClient.getInstance().getC(0).getRGB(), StarClient.getInstance().getC(500).getRGB(), StarClient.getInstance().getC(500).getRGB());
            } else {
                RenderUtility.drawRoundedRect(this.x + 3.0f + f2, this.y + (float)Fonts.mntssb13.getFontHeight() + f3, f5, f6, 3.0f, bl ? new Color(52, 52, 52).getRGB() : new Color(160, 160, 160).getRGB());
            }
            Fonts.mntssb13.drawString(string, this.x + 5.0f + f2, this.y + 3.5f + (float)Fonts.mntssb13.getFontHeight() + f3, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
            f2 += f5 + f4;
        }
        this.height = 18.0f + f3;
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        super.mouseClicked(d, d2, n);
        float f = this.width - 10.0f;
        float f2 = 2.0f;
        float f3 = 4.0f;
        float f4 = 3.0f;
        for (String string : this.setting.values.stream().sorted(Comparator.comparingDouble(this::getEnabledWidth)).collect(Collectors.toList())) {
            float f5 = this.getEnabledWidth(string);
            float f6 = Fonts.mntssb13.getFontHeight() + 6;
            if (f2 + f5 > f) {
                f2 = 2.0f;
                f3 += f6 + f4;
            }
            if (RenderUtility.isHovered(d, d2, (double)(this.x + 3.0f + f2), (double)(this.y + (float)Fonts.mntssb13.getFontHeight() + f3), (double)f5, (double)f6)) {
                int n2 = this.setting.values.indexOf(string);
                this.setting.selectedValues.set(n2, this.setting.selectedValues.get(n2) == false);
            }
            f2 += f5 + f4;
        }
    }

    private float getEnabledWidth(String string) {
        return Fonts.mntssb13.getStringWidth(string) + 4;
    }

    @Override
    public boolean isVisible() {
        return this.setting.getVisible().get();
    }
}
