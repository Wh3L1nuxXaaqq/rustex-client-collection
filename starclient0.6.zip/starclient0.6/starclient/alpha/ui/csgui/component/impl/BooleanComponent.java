package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.ModuleComponent;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.font.Fonts;

public class BooleanComponent
extends Component {
    public ModuleComponent moduleComponent;
    public BooleanSetting setting;
    public float animation = 0.0f;

    public BooleanComponent(ModuleComponent moduleComponent, BooleanSetting booleanSetting) {
        super(0.0f, 0.0f, 0.0f, 14.0f);
        this.moduleComponent = moduleComponent;
        this.setting = booleanSetting;
    }

    @Override
    public void render(int n, int n2) {
        super.render(n, n2);
        int n3 = StarClient.getInstance().getC(0).getRGB();
        int n4 = StarClient.getInstance().getC(500).getRGB();
        int n5 = ColorUtility.interpolateColorC(n3, n4, 0.5f).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        this.animation = AnimationMath.fast(this.animation, this.setting.state ? -1.0f : 0.0f, 15.0f);
        Fonts.mntssb13.drawString(this.setting.getName(), this.x + 5.0f, this.y + 6.5f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
        RenderUtility.drawRoundedRect(this.x + this.width - 25.0f, this.y + 2.0f, 20.0f, 10.0f, 6.0f, bl ? new Color(25, 25, 25).getRGB() : new Color(160, 160, 160).getRGB());
        Color color = ColorUtility.interpolateColorC(new Color(34, 34, 34).getRGB(), n5, Math.abs(this.animation));
        RenderUtility.drawRoundedRect(this.x + this.width - 23.5f - this.animation * 10.0f, this.y + 3.5f, 7.0f, 7.0f, 6.0f, color.getRGB());
        float f = Math.abs(this.animation);
        int n6 = (int)(f * 255.0f);
        Color color2 = new Color(new Color(n5).getRed(), new Color(n5).getGreen(), new Color(n5).getBlue(), n6);
        RenderUtility.drawGradientGlow(this.x + this.width - 22.8f - this.animation * 10.0f, this.y + 3.8f, 6.0f, 6.0f, 4, color2, color2);
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        super.mouseClicked(d, d2, n);
        boolean bl = RenderUtility.isHovered(d, d2, (double)this.x, (double)this.y, (double)this.width, (double)this.height);
        if (bl && n == 0) {
            this.setting.state = !this.setting.get();
        }
    }

    @Override
    public boolean isVisible() {
        return this.setting.getVisible().get();
    }
}
