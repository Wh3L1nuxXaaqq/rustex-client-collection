package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Theme;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

public class ThemeComponent
extends Component {
    private final Theme theme;

    public ThemeComponent(Theme theme, float f, float f2) {
        super(0.0f, 0.0f, f, f2);
        this.theme = theme;
    }

    @Override
    public void render(int n, int n2) {
        int n3 = 0;
        int n4 = StarClient.getInstance().getC(n3 += 25).getRGB();
        int n5 = StarClient.getInstance().getC(500 + n3).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        if (StarClient.getInstance().getThemeManager().getCurrentStyleTheme().equals(this.theme) || StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(this.theme)) {
            RenderUtility.drawGradientGlow(this.x - 1.0f, this.y - 1.0f, this.width + 2.0f, this.height - 2.0f, 8, n4, n5, n4, n5);
        } else {
            RenderUtility.drawGlow(this.x - 1.0f, this.y - 1.0f, this.width + 2.0f, this.height - 2.0f, 8, bl ? new Color(0, 0, 0, 179).getRGB() : new Color(45, 45, 45).getRGB());
        }
        if (this.theme.getType().equals((Object)Theme.ThemeType.GUI)) {
            RenderUtility.Cornered(this.x, this.y, this.width, 11.0f, 7.0f, 0.0f, 7.0f, 0.0f, 1.0f, bl ? new Color(45, 45, 45).getRGB() : Color.WHITE.getRGB());
            RenderUtility.CorneredGradient(this.x, this.y + 10.0f, this.width, this.height - 15.0f, 0.0f, 7.0f, 0.0f, 7.0f, 1.0f, this.theme.getColors()[0].getRGB(), this.theme.getColors()[0].getRGB(), this.theme.getColors()[0].getRGB(), this.theme.getColors()[0].getRGB());
        } else {
            RenderUtility.Cornered(this.x, this.y, this.width, 11.0f, 7.0f, 0.0f, 7.0f, 0.0f, bl ? new Color(45, 45, 45).getRGB() : Color.WHITE.getRGB());
            RenderUtility.CorneredGradient(this.x, this.y + 10.0f, this.width, this.height - 15.0f, 0.0f, 7.0f, 0.0f, 7.0f, 1.0f, this.getC(0).getRGB(), this.getC(0).getRGB(), this.getC(250).getRGB(), this.getC(250).getRGB());
        }
        Fonts.mntssb14.drawCenteredString(this.theme.getName(), this.x + this.width / 2.0f, this.y + 3.0f, bl ? Color.WHITE.getRGB() : new Color(65, 65, 65).getRGB());
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        if (RenderUtility.isHovered(d, d2, (double)this.x, (double)this.y, (double)this.width, (double)this.height)) {
            if (this.theme.getType().equals((Object)Theme.ThemeType.GUI)) {
                StarClient.getInstance().getThemeManager().setCurrentGuiTheme(this.theme);
            } else {
                StarClient.getInstance().getThemeManager().setCurrentStyleTheme(this.theme);
            }
        }
    }

    public Theme getTheme() {
        return this.theme;
    }

    public Color getC(int n) {
        Color color = this.theme.getColors()[0];
        Color color2 = this.theme.getColors()[1];
        Arraylist cfr_ignored_0 = StarClient.getInstance().getModuleManager().arraylist;
        return ColorUtility.TwoColorEffect(color, color2, Arraylist.colorSpeed.get(), n);
    }
}
