package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.input.Keyboard;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Module;
import starclient.alpha.module.setting.Setting;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.ui.csgui.CsGui;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.BooleanComponent;
import starclient.alpha.ui.csgui.component.impl.ColorComponent;
import starclient.alpha.ui.csgui.component.impl.ModeComponent;
import starclient.alpha.ui.csgui.component.impl.MultiBoolComponent;
import starclient.alpha.ui.csgui.component.impl.SliderComponent;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.font.Fonts;

public class ModuleComponent
extends Component {
    private final Module module;
    public boolean binding;
    public List<Component> elements = new ArrayList<Component>();
    public float enableAnimation = 0.0f;

    public ModuleComponent(Module module, float f, float f2) {
        super(0.0f, 0.0f, f, f2);
        this.module = module;
        for (Setting setting : module.getSettings()) {
            if (setting instanceof BooleanSetting) {
                this.elements.add(new BooleanComponent(this, (BooleanSetting)setting));
                continue;
            }
            if (setting instanceof NumberSetting) {
                this.elements.add(new SliderComponent(this, (NumberSetting)setting));
                continue;
            }
            if (setting instanceof ModeSetting) {
                this.elements.add(new ModeComponent(this, (ModeSetting)setting));
                continue;
            }
            if (setting instanceof MultiBooleanSetting) {
                this.elements.add(new MultiBoolComponent(this, (MultiBooleanSetting)setting));
                continue;
            }
            if (!(setting instanceof ColorSetting)) continue;
            this.elements.add(new ColorComponent(this, (ColorSetting)setting));
        }
    }

    @Override
    public void render(int n, int n2) {
        Object object;
        int n3 = 0;
        for (Component component : this.elements) {
            if (!component.isVisible()) continue;
            n3 = (int)((float)n3 + component.height);
        }
        float f = this.height + (float)n3;
        int n4 = StarClient.getInstance().getC(0).getRGB();
        int n5 = StarClient.getInstance().getC(500).getRGB();
        int n6 = ColorUtility.interpolateColorC(n4, n5, 0.55f).getRGB();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Color[] colorArray = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().getColors();
        int n7 = colorArray[0].getRGB();
        RenderUtility.drawFixedGlow(this.x, this.y, this.width, f, 5, n7);
        RenderUtility.drawRoundedRect(this.x, this.y, this.width, f, 5.0f, n7);
        Fonts.mntssb14.drawString(this.binding ? "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u043a\u043b\u0430\u0432\u0438\u0448\u0443.. " : this.module.getName(), this.x + 5.0f, this.y + 6.0f, bl ? Color.WHITE.getRGB() : new Color(40, 40, 40).getRGB());
        if (this.module.isPremium() && !this.binding) {
            Fonts.mntssb14.drawString("\u00a76PREMIUM", this.x + this.width - (float)(Fonts.mntssb14.getStringWidth("PREMIUM") + 4), this.y + 6.0f, bl ? Color.WHITE.getRGB() : new Color(40, 40, 40).getRGB());
        }
        if (this.binding) {
            object = this.module.bind < 0 ? "MOUSE " + this.module.getMouseBind() : Keyboard.getKeyName((int)this.module.getBind());
            RenderUtility.drawRoundedRect(this.x + this.width - 10.0f - (float)Fonts.nunitoBold14.getStringWidth((String)(this.module.bind == 0 ? "R" : object)), this.y + 2.0f, this.module.bind == 0 ? (float)(Fonts.nunitoBold14.getStringWidth("R") + 5) : (float)(Fonts.nunitoBold14.getStringWidth((String)object) + 5), 10.0f, 4.0f, bl ? new Color(27, 27, 27).getRGB() : new Color(180, 180, 180).getRGB());
            if (this.module.bind != 0) {
                Fonts.nunitoBold14.drawString((String)object, this.x + this.width - 10.0f - (float)Fonts.nunitoBold14.getStringWidth((String)object) + 2.4f, this.y + 5.0f, bl ? Color.WHITE.getRGB() : new Color(40, 40, 40).getRGB());
            }
        }
        RenderUtility.drawRect(this.x + 5.0f, this.y + 5.0f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 3.0f, this.width - 10.0f, 1.0f, bl ? new Color(54, 54, 54).getRGB() : new Color(170, 170, 170).getRGB());
        Fonts.mntssb13.drawString("\u0412\u043a\u043b\u044e\u0447\u0435\u043d", this.x + 5.0f, this.y + 6.0f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 9.0f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
        this.enableAnimation = AnimationMath.fast(this.enableAnimation, this.module.enabled ? -1.0f : 0.0f, 15.0f);
        RenderUtility.drawRoundedRect(this.x + this.width - 25.0f, this.y + 5.0f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 6.0f, 20.0f, 10.0f, 6.0f, bl ? new Color(25, 25, 25).getRGB() : new Color(160, 160, 160).getRGB());
        object = ColorUtility.interpolateColorC(new Color(34, 34, 34).getRGB(), n6, Math.abs(this.enableAnimation));
        RenderUtility.drawRoundedRect(this.x + this.width - 23.5f - this.enableAnimation * 10.0f, this.y + 6.5f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 6.0f, 7.0f, 7.0f, 6.0f, ((Color)object).getRGB());
        if (this.module.enabled) {
            RenderUtility.drawGradientGlow(this.x + this.width - 22.8f - this.enableAnimation * 10.0f, this.y + 6.5f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 6.4f, 6.0f, 6.0f, 4, new Color(n6), new Color(n6));
        }
        n3 = 0;
        for (Component component : this.elements) {
            if (!component.isVisible()) continue;
            component.x = this.x;
            component.y = this.y + 29.0f + (float)n3;
            component.width = this.width;
            component.render(n, n2);
            n3 = (int)((float)n3 + component.height);
        }
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        super.mouseClicked(d, d2, n);
        if (this.binding && n > 2) {
            this.module.bind = n - 100;
            this.binding = false;
        }
        boolean bl = RenderUtility.isHovered(d, d2, (double)(this.x + this.width - 25.0f), (double)(this.y + 5.0f + (float)Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 6.0f), 20.0, 10.0);
        boolean bl2 = RenderUtility.isHovered(d, d2, (double)this.x, (double)this.y, (double)this.width, (double)(Fonts.nunitoBold14.getStringHeight(this.module.getName()) + 8));
        if (bl && n == 0) {
            this.module.toggle();
        } else if (bl2 && n == 2) {
            this.binding = !this.binding;
        }
        for (Component component : this.elements) {
            if (!component.isVisible()) continue;
            component.mouseClicked(d, d2, n);
        }
    }

    @Override
    public void keyTyped(int n) {
        super.keyTyped(n);
        if (this.binding) {
            if (n == 1) {
                CsGui.escapeInUse = true;
                this.binding = false;
                return;
            }
            this.module.bind = n == 211 ? 0 : n;
            this.binding = false;
        }
    }

    public Module getModule() {
        return this.module;
    }
}
