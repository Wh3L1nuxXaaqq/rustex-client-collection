package starclient.alpha.ui.csgui.component.impl;

import java.awt.Color;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.ui.csgui.CsGui;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.ModuleComponent;
import starclient.alpha.ui.csgui.window.ColorPickerWindow;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

public class ColorComponent
extends Component {
    public ModuleComponent moduleComponent;
    public ColorSetting setting;

    public ColorComponent(ModuleComponent moduleComponent, ColorSetting colorSetting) {
        super(0.0f, 0.0f, 0.0f, 14.0f);
        this.moduleComponent = moduleComponent;
        this.setting = colorSetting;
    }

    @Override
    public void render(int n, int n2) {
        super.render(n, n2);
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Fonts.mntssb13.drawString(this.setting.getName(), this.x + 5.0f, this.y + 6.5f, bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
        RenderUtility.drawRoundedRect(this.x + this.width - 16.0f, this.y + 1.5f, 11.0f, 11.0f, 10.0f, bl ? new Color(60, 60, 60).getRGB() : new Color(190, 190, 190).getRGB());
        RenderUtility.drawRoundedRect(this.x + this.width - 15.0f, this.y + 2.5f, 9.0f, 9.0f, 8.0f, bl ? new Color(34, 34, 34).getRGB() : new Color(240, 240, 240).getRGB());
        RenderUtility.drawRoundedRect(this.x + this.width - 14.0f, this.y + 3.5f, 7.0f, 7.0f, 6.0f, this.setting.get());
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        super.mouseClicked(d, d2, n);
        if (RenderUtility.isHovered(d, d2, (double)(this.x + this.width - 16.0f), (double)(this.y + 1.5f), 11.0, 11.0) && (CsGui.colorPicker == null || !CsGui.colorPicker.getColorSetting().equals(this.setting))) {
            CsGui.colorPicker = new ColorPickerWindow((float)(d + 5.0), (float)(d2 + 5.0), 80.0f, 80.0f, this.setting);
        }
    }

    @Override
    public boolean isVisible() {
        return this.setting.getVisible().get();
    }
}
