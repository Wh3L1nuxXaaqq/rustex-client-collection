package starclient.alpha.ui.csgui.component.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.utility.misc.ChatUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

public class ConfigComponent
extends Component {
    private final String name;
    private final List<String> buttons = Arrays.asList("Load", "Save", "Delete");

    public ConfigComponent(String string, float f, float f2) {
        super(0.0f, 0.0f, f, f2);
        this.name = string;
    }

    @Override
    public void render(int n, int n2) {
        Color color = StarClient.getInstance().getC(0);
        Color color2 = StarClient.getInstance().getC(500);
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Color[] colorArray = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().getColors();
        int n3 = colorArray[0].getRGB();
        Color color3 = bl ? new Color(34, 34, 34) : new Color(240, 240, 240);
        RenderUtility.drawFixedGlow(this.x, this.y, this.width, this.height, 5, n3);
        RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, n3);
        Fonts.nunitoBold16.drawString(this.name, this.x + 5.0f, this.y + 5.0f, bl ? Color.WHITE.getRGB() : new Color(40, 40, 40).getRGB());
        float f = 5.0f;
        float f2 = 3.0f;
        for (String string : this.buttons) {
            float f3 = this.getEnabledWidth(string);
            float f4 = Fonts.nunitoBold16.getFontHeight() + 4;
            RenderUtility.drawRoundedRect(this.x + f - 2.0f, this.y + 12.0f + (float)Fonts.nunitoBold14.getFontHeight(), f3, f4 - 2.0f, 3.0f, colorArray[4].getRGB());
            Fonts.nunitoBold14.drawString(string, this.x + f, this.y + 14.0f + (float)Fonts.nunitoBold14.getFontHeight(), bl ? Color.WHITE.getRGB() : new Color(55, 55, 55).getRGB());
            f += f3 + f2;
        }
    }

    public boolean mouseBoolClicked(double d, double d2, int n) {
        float f = 5.0f;
        float f2 = 3.0f;
        for (String string : this.buttons) {
            float f3 = this.getEnabledWidth(string);
            float f4 = Fonts.nunitoBold14.getFontHeight() + 4;
            if (RenderUtility.isHovered(d, d2, (double)(this.x + f - 2.0f), (double)(this.y + 12.0f + (float)Fonts.nunitoBold14.getFontHeight()), (double)f3, (double)(f4 - 2.0f))) {
                int n2 = -1;
                switch (string.hashCode()) {
                    case 2373894: {
                        if (!string.equals("Load")) break;
                        n2 = 0;
                        break;
                    }
                    case 2569629: {
                        if (!string.equals("Save")) break;
                        n2 = 1;
                        break;
                    }
                    case 2043376075: {
                        if (!string.equals("Delete")) break;
                        n2 = 2;
                    }
                }
                switch (n2) {
                    case 0: {
                        StarClient.getInstance().getConfigManager().loadConfig(this.name);
                        ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + this.name + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u0430.");
                        break;
                    }
                    case 1: {
                        StarClient.getInstance().getConfigManager().saveConfig(this.name);
                        ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + this.name + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0430.");
                        break;
                    }
                    case 2: {
                        StarClient.getInstance().getConfigManager().deleteConfig(this.name);
                        ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f " + String.valueOf((Object)TextFormatting.GOLD) + this.name + String.valueOf(ChatFormatting.GRAY) + " \u0431\u044b\u043b\u0430 \u0443\u0434\u0430\u043b\u0435\u043d\u0430.");
                        return true;
                    }
                }
            }
            f += f3 + f2;
        }
        return false;
    }

    private float getEnabledWidth(String string) {
        return Fonts.nunitoBold14.getStringWidth(string) + 4;
    }

    public String getName() {
        return this.name;
    }
}
