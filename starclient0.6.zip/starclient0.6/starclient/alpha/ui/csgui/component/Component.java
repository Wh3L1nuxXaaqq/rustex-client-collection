package starclient.alpha.ui.csgui.component;

public class Component {
    public float x;
    public float y;
    public float width;
    public float height;

    public Component(float f, float f2, float f3, float f4) {
        this.x = f;
        this.y = f2;
        this.width = f3;
        this.height = f4;
    }

    public void render(int n, int n2) {
    }

    public void mouseClicked(double d, double d2, int n) {
    }

    public void mouseReleased(double d, double d2, int n) {
    }

    public void keyTyped(int n) {
    }

    public boolean isVisible() {
        return true;
    }

    public void setX(float f) {
        this.x = f;
    }

    public void setY(float f) {
        this.y = f;
    }

    public void setWidth(float f) {
        this.width = f;
    }

    public void setHeight(float f) {
        this.height = f;
    }
}
