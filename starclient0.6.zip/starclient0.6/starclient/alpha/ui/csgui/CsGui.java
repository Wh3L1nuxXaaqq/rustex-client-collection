package starclient.alpha.ui.csgui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.manager.config.Config;
import starclient.alpha.manager.config.ConfigManager;
import starclient.alpha.manager.theme.Theme;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.impl.render.ClickGuiModule;
import starclient.alpha.ui.csgui.component.Component;
import starclient.alpha.ui.csgui.component.impl.ConfigComponent;
import starclient.alpha.ui.csgui.component.impl.ModuleComponent;
import starclient.alpha.ui.csgui.component.impl.ThemeComponent;
import starclient.alpha.ui.csgui.window.ColorPickerWindow;
import starclient.alpha.ui.menu.widgets.SearchField;
import starclient.alpha.utility.misc.SoundUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.StencilUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;
import starclient.alpha.utility.render.animation.impl.EaseInOutQuad;
import starclient.alpha.utility.render.font.Fonts;

public class CsGui
extends GuiScreen {
    public int x;
    public int y;
    public static Category selected;
    public static ColorPickerWindow colorPicker;
    public static List<ModuleComponent> modules;
    private boolean FirstMode = true;
    public static List<ModuleComponent> modules2;
    public static List<ThemeComponent> guiThemes;
    public static List<ThemeComponent> themes;
    public static List<ConfigComponent> configs;
    public static List<ConfigComponent> configs2;
    private Animation openAnimation;
    private static final Animation moduleAnimation;
    public static SearchField search;
    public static boolean escapeInUse;
    public boolean isClosed;
    public float scrollY = 32.5f;
    private float text1Y = 0.0f;
    private float text2Y = 0.0f;
    public static boolean dragging;
    public int prevMouseX;
    public int prevMouseY;
    public int sasokX;
    public int sasokY;
    private int searchWidth = 326;
    private int searchHeight = 20;
    private int searchOffsetX = 99;
    private int searchOffsetY = 5;

    public CsGui() {
        Themes[] themesArray;
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        this.x = scaledResolution.getScaledWidth() / 2 - this.width / 2;
        this.y = scaledResolution.getScaledHeight() / 2 - this.height / 2;
        this.width = 960;
        this.height = 509;
        search = new SearchField(0, Fonts.mntssb16, this.x + this.searchOffsetX, this.y + this.searchOffsetY, this.searchWidth, this.searchHeight);
        StarClient.getInstance().getModuleManager().getModules().forEach(module -> {
            if (StarClient.getInstance().getModuleManager().getModules().indexOf(module) % 2 == 0) {
                modules.add(new ModuleComponent((Module)module, 155.0f, 30.0f));
            }
            if (StarClient.getInstance().getModuleManager().getModules().indexOf(module) % 2 != 0) {
                modules2.add(new ModuleComponent((Module)module, 155.0f, 30.0f));
            }
        });
        for (Themes themes : themesArray = Themes.values()) {
            if (themes.getTheme().getType().equals((Object)Theme.ThemeType.GUI)) {
                guiThemes.add(new ThemeComponent(themes.getTheme(), 55.0f, 30.0f));
                continue;
            }
            CsGui.themes.add(new ThemeComponent(themes.getTheme(), 55.0f, 30.0f));
        }
    }

    @Override
    public void initGui() {
        super.initGui();
        search.updatePosition(this.x + this.searchOffsetX, this.y + this.searchOffsetY, this.searchWidth, this.searchHeight);
        this.openAnimation = new EaseInOutQuad(300, 1.0f, Direction.FORWARDS);
        if (colorPicker != null) {
            colorPicker.init();
        }
        CsGui.updateConfigComponents();
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        super.drawScreen(n, n2, f);
        this.width = 960;
        this.height = 440;
        this.sasokX = n;
        this.sasokY = n2;
        this.updateMouse(n, n2);
        Color[] colorArray = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().getColors();
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        Color color = new Color(colorArray[4].getRed(), colorArray[4].getGreen(), colorArray[4].getBlue());
        if (this.isClosed) {
            mc.displayGuiScreen(null);
            this.isClosed = false;
        }
        int n3 = StarClient.getInstance().getC(0).getRGB();
        int n4 = StarClient.getInstance().getC(500).getRGB();
        if (ClickGuiModule.glow.get()) {
            RenderUtility.drawGradientGlow(this.x, this.y, 430.0f, 235.0f, 8, new Color(n3), new Color(n4));
        }
        RenderUtility.drawRoundedRect(this.x, this.y, 430.0f, 235.0f, 8.0f, colorArray[0].getRGB());
        Fonts.tenacityBold35.drawGradientString("StarClient", (float)this.x + 10.0f, (float)this.y + 6.5f, new Color(n3), new Color(n4));
        Category[] categoryArray = Category.values();
        int n5 = categoryArray.length;
        RenderUtility.drawRoundedRect(this.x + 100, this.y + 28, this.width - 635, (float)this.height - 239.0f, 10.0f, color.getRGB());
        RenderUtility.drawRoundedRect(this.x + 5, this.y + 28, this.width / 2 - 390, (float)this.height - 276.0f, 10.0f, color.getRGB());
        if (this.FirstMode) {
            for (int i = 0; i < n5; ++i) {
                Category category = categoryArray[i];
                category.getAnimation().setDirection(selected.equals((Object)category) ? Direction.FORWARDS : Direction.BACKWARDS);
                int n6 = 7;
                int n7 = 30;
                boolean bl2 = RenderUtility.isHovered(n, n2, this.x + n6, this.y + n7 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f, 17.5f);
                if (selected.equals((Object)category)) {
                    RenderUtility.drawRoundedGradientRect(this.x + n6, this.y + n7 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f * category.getAnimation().getOutput(), 17.5f, 6.0f, 1.0f, n3, n3, n4, n4);
                    RenderUtility.drawGradientGlow(this.x + n6, this.y + n7 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f * category.getAnimation().getOutput(), 17.5f, 8, new Color(n3), new Color(n4));
                } else if (bl2) {
                    RenderUtility.drawRoundedRect(this.x + n6, this.y + n7 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f, 17.5f, 6.0f, new Color(0, 0, 0, 115).getRGB());
                } else {
                    RenderUtility.drawRoundedRect(this.x + n6, this.y + n7 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f * category.getAnimation().getOutput(), 17.5f, 4.0f, 3);
                }
                Fonts.ace16.drawString(category.getName(), (float)this.x + 22.5f + (float)n6, (float)(this.y + n7 + 20 * category.ordinal()) + 7.5f + (float)(category.isBottom() ? 15 : 0), bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
                Fonts.nw20.drawString(String.valueOf(category.getIcon()), this.x + 5 + n6, (float)(this.y + n7 + 20 * category.ordinal()) + 8.0f + (float)(category.isBottom() ? 15 : 0), bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
            }
            ResourceLocation resourceLocation = new ResourceLocation("starclient/star64.png");
            RenderUtility.drawRoundedRect(this.x + 5, this.y + 199, this.width / 2 - 390, (float)this.height - 410.0f, 10.0f, color.getRGB());
            RenderUtility.applyRound(25.0f, 25.0f, 12.0f, 255.0f, () -> RenderUtility.drawImage(resourceLocation, this.x + 8, (int)((float)this.y + 201.5f), 25, 25, n3));
            int n8 = Math.min(StarClient.getInstance().getUserInfo().getName().length(), 10);
            Fonts.ace16.drawString(StarClient.getInstance().getUserInfo().getName().substring(0, n8), this.x + 36, (float)this.y + 206.5f, bl ? new Color(255, 255, 255, 255).getRGB() : new Color(0, 0, 0, 230).getRGB());
            Fonts.ace16.drawString("UID:1337", this.x + 36, (float)this.y + 216.5f, bl ? new Color(255, 255, 255, 255).getRGB() : new Color(0, 0, 0, 230).getRGB());
            StencilUtility.initStencilToWrite();
            RenderUtility.drawRect((float)this.x + 92.5f, (float)this.y + 28.0f, 330.0f, 201.0f, -1);
            StencilUtility.readStencilBuffer(1);
            if (selected.equals((Object)Category.THEMES)) {
                this.drawThemes(n, n2);
            } else if (selected.equals((Object)Category.CONFIG)) {
                this.drawConfigs(n, n2);
            } else if (selected.equals((Object)Category.HOME)) {
                this.drawHome(n, n2);
            } else {
                this.drawComponents(n, n2);
            }
            StencilUtility.uninitStencilBuffer();
            if (colorPicker != null) {
                colorPicker.render(n, n2);
            }
            GlStateManager.popMatrix();
        }
        search.updatePosition(this.x + this.searchOffsetX, this.y + this.searchOffsetY, this.searchWidth, this.searchHeight);
        search.drawTextBox();
    }

    private boolean isMouseOverBackground(int n, int n2) {
        float f = this.x + 100;
        float f2 = this.y + 28;
        float f3 = this.width - 635;
        float f4 = (float)this.height - 239.0f;
        return (float)n >= f && (float)n <= f + f3 && (float)n2 >= f2 && (float)n2 <= f2 + f4;
    }

    private void drawHome(int n, int n2) {
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        this.scrollY += (float)Mouse.getDWheel() / 10.0f;
        float f = this.scrollY;
        float f2 = 0.0f;
        float f3 = 0.0f;
        this.text1Y = AnimationMath.fast(this.text1Y, (float)this.y + f, 15.0f);
        Fonts.nunitoBold20.drawCenteredString("\u0414\u043e\u0431\u0440\u043e \u041f\u043e\u0436\u0430\u043b\u043e\u0432\u0430\u0442\u044c \u0432 " + StarClient.NAME, this.x + 260, this.text1Y + 68.0f + 12.0f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
        Fonts.nunitoBold20.drawCenteredString("\u0412\u0435\u0440\u0441\u0438\u044f \u041a\u043b\u0438\u0435\u043d\u0442\u0430: " + StarClient.VERSION, this.x + 260, this.text1Y + 82.0f + 12.0f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
        this.text2Y = AnimationMath.fast(this.text2Y, (float)(this.y + 49) + f, 15.0f);
        float f4 = Math.max(f2, f3);
        this.scrollY = f4 > 250.0f ? MathHelper.clamp(this.scrollY, -f4, 32.5f) : 32.5f;
    }

    private void drawThemes(int n, int n2) {
        int n3;
        boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        int n4 = 0;
        this.scrollY += (float)Mouse.getDWheel() / 10.0f;
        float f = this.scrollY;
        float f2 = 0.0f;
        float f3 = 0.0f;
        this.text1Y = AnimationMath.fast(this.text1Y, (float)this.y + f, 15.0f);
        Fonts.nunitoBold18.drawString("\u0426\u0432\u0435\u0442 \u0441\u0442\u0438\u043b\u044f", this.x + 110, this.text1Y, bl ? new Color(255, 255, 255, 255).getRGB() : new Color(30, 30, 30, 230).getRGB());
        for (ThemeComponent themeComponent : guiThemes) {
            n3 = guiThemes.indexOf(themeComponent);
            themeComponent.setX((float)(this.x + 110) + (float)n4 * (themeComponent.width + 8.0f));
            themeComponent.setY(AnimationMath.fast(themeComponent.y, (float)(this.y + 15) + f, 15.0f));
            themeComponent.render(this.sasokX, this.sasokY);
            ++n4;
            if ((n3 + 1) % 5 == 0) {
                f += themeComponent.height + 7.0f;
                n4 = 0;
            }
            f2 += themeComponent.height + 7.0f;
        }
        this.text2Y = AnimationMath.fast(this.text2Y, (float)(this.y + 49) + f, 15.0f);
        Fonts.nunitoBold18.drawString("\u0426\u0432\u0435\u0442 \u0442\u0435\u043c\u044b", this.x + 110, this.text2Y, bl ? new Color(255, 255, 255, 255).getRGB() : new Color(30, 30, 30, 230).getRGB());
        n4 = 0;
        f = this.scrollY;
        for (ThemeComponent themeComponent : themes) {
            n3 = themes.indexOf(themeComponent);
            themeComponent.setX((float)(this.x + 110) + (float)n4 * (themeComponent.width + 8.0f));
            themeComponent.setY(AnimationMath.fast(themeComponent.y, (float)(this.y + 61) + f, 15.0f));
            themeComponent.render(this.sasokX, this.sasokY);
            ++n4;
            if ((n3 + 1) % 5 == 0) {
                f += themeComponent.height + 7.0f;
                n4 = 0;
            }
            f3 += themeComponent.height + 7.0f;
        }
        float f4 = Math.max(f2, f3);
        this.scrollY = f4 > 250.0f ? MathHelper.clamp(this.scrollY, -f4, 32.5f) : 32.5f;
    }

    private void drawConfigs(int n, int n2) {
        this.scrollY += (float)Mouse.getDWheel() / 10.0f;
        float f = this.scrollY - 22.0f;
        float f2 = 32.5f;
        float f3 = 32.5f;
        for (ConfigComponent configComponent : configs) {
            configComponent.setX(this.x + 105);
            configComponent.setY(AnimationMath.fast(configComponent.y, (float)this.y + f, 15.0f));
            configComponent.render(this.sasokX, this.sasokY);
            f += configComponent.height + 5.0f;
            f2 += configComponent.height + 5.0f;
        }
        f = 11.0f;
        for (ConfigComponent configComponent : configs2) {
            configComponent.setX(this.x + 265);
            configComponent.setY(AnimationMath.fast(configComponent.y, (float)this.y + f, 15.0f));
            configComponent.render(this.sasokX, this.sasokY);
            f += configComponent.height + 5.0f;
            f3 += configComponent.height + 5.0f;
        }
        float f4 = Math.max(f2, f3);
        this.scrollY = f4 > 250.0f ? MathHelper.clamp(this.scrollY, -f4 + 277.0f, 32.5f) : 32.5f;
    }

    private void drawComponents(int n, int n2) {
        List list = modules.stream().filter(moduleComponent -> moduleComponent.getModule().getCategory().equals((Object)selected) && moduleComponent.getModule().isSearched()).collect(Collectors.toList());
        List list2 = modules2.stream().filter(moduleComponent -> moduleComponent.getModule().getCategory().equals((Object)selected) && moduleComponent.getModule().isSearched()).collect(Collectors.toList());
        this.scrollY += (float)Mouse.getDWheel() / 10.0f;
        float f = this.scrollY;
        float f2 = 32.5f;
        float f3 = 32.5f;
        Iterator iterator = list.iterator();
        while (true) {
            ModuleComponent moduleComponent2;
            if (!iterator.hasNext()) {
                f = this.scrollY;
                iterator = list2.iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        float f4 = Math.max(f2, f3);
                        this.scrollY = f4 > 250.0f ? MathHelper.clamp(this.scrollY, -f4 + 277.0f, 32.5f) : 32.5f;
                        return;
                    }
                    moduleComponent2 = (ModuleComponent)iterator.next();
                    moduleComponent2.setX(this.x + 265);
                    moduleComponent2.setY(AnimationMath.fast(moduleComponent2.y, (float)this.y + f, 15.0f));
                    if (!moduleComponent2.getModule().isSearched()) continue;
                    for (Component component : moduleComponent2.elements) {
                        if (!component.isVisible()) continue;
                        f += component.height;
                        f3 += component.height;
                    }
                    moduleComponent2.render(this.sasokX, this.sasokY);
                    f += moduleComponent2.height + 5.0f;
                    f3 += moduleComponent2.height + 10.0f;
                }
            }
            moduleComponent2 = (ModuleComponent)iterator.next();
            moduleComponent2.setX(this.x + 105);
            moduleComponent2.setY(AnimationMath.fast(moduleComponent2.y, (float)this.y + f, 15.0f));
            if (!moduleComponent2.getModule().isSearched()) continue;
            for (Component component : moduleComponent2.elements) {
                if (!component.isVisible()) continue;
                f += component.height;
                f2 += component.height;
            }
            moduleComponent2.render(this.sasokX, this.sasokY);
            f += moduleComponent2.height + 5.0f;
            f2 += moduleComponent2.height + 20.0f;
        }
    }

    public static void updateConfigComponents() {
        configs.clear();
        configs2.clear();
        ArrayList<Config> arrayList = ConfigManager.getLoadedConfigs();
        for (Config config : arrayList) {
            if (arrayList.indexOf(config) % 2 == 0) {
                configs.add(new ConfigComponent(config.getName(), 155.0f, 30.0f));
            }
            if (arrayList.indexOf(config) % 2 == 0) continue;
            configs2.add(new ConfigComponent(config.getName(), 155.0f, 30.0f));
        }
    }

    @Override
    protected void mouseClicked(int n, int n2, int n3) throws IOException {
        super.mouseClicked(this.sasokX, this.sasokY, n3);
        float f = (float)this.x + 12.0f;
        float f2 = (float)this.y + 6.5f;
        float f3 = Fonts.tenacityBold35.getStringWidth("StarClient");
        float f4 = Fonts.tenacityBold35.getFontHeight();
        boolean bl = RenderUtility.isHovered(this.sasokX, this.sasokY, f, f2, f3, f4);
        if (colorPicker == null && bl && n3 == 0) {
            this.prevMouseX = this.x - this.sasokX;
            this.prevMouseY = this.y - this.sasokY;
            dragging = true;
            return;
        }
        if (n3 == 0) {
            Category[] object = Category.values();
            Category[] object2 = object;
            int configComponent = object2.length;
            for (int i = 0; i < configComponent; ++i) {
                int n4 = 7;
                int n5 = 30;
                Category category = object2[i];
                boolean bl2 = RenderUtility.isHovered(this.sasokX, this.sasokY, this.x + n4, this.y + n5 + 20 * category.ordinal() + 1 + (category.isBottom() ? 15 : 0), 85.0f, 17.5f);
                if (!bl2 || selected.equals((Object)category)) continue;
                dragging = false;
                selected = category;
                this.scrollY = 32.5f;
                moduleAnimation.reset();
            }
        }
        search.mouseClicked(this.sasokX, this.sasokY, n3);
        if (colorPicker != null) {
            colorPicker.mouseClicked(this.sasokX, this.sasokY, n3);
        } else {
            for (ModuleComponent moduleComponent : modules) {
                if (!moduleComponent.getModule().getCategory().equals((Object)selected) || !moduleComponent.getModule().isSearched() || !this.isMouseOverBackground(this.sasokX, this.sasokY)) continue;
                moduleComponent.mouseClicked(this.sasokX, this.sasokY, n3);
                dragging = false;
            }
            for (ModuleComponent moduleComponent : modules2) {
                if (!moduleComponent.getModule().getCategory().equals((Object)selected) || !moduleComponent.getModule().isSearched() || !this.isMouseOverBackground(this.sasokX, this.sasokY)) continue;
                moduleComponent.mouseClicked(this.sasokX, this.sasokY, n3);
                dragging = false;
            }
            if (selected.equals((Object)Category.THEMES)) {
                for (ThemeComponent themeComponent : guiThemes) {
                    if (!this.isMouseOverBackground(this.sasokX, this.sasokY)) continue;
                    themeComponent.mouseClicked(this.sasokX, this.sasokY, n3);
                    dragging = false;
                }
                for (ThemeComponent themeComponent : themes) {
                    if (!this.isMouseOverBackground(this.sasokX, this.sasokY)) continue;
                    themeComponent.mouseClicked(this.sasokX, this.sasokY, n3);
                    dragging = false;
                }
            }
            if (selected.equals((Object)Category.CONFIG)) {
                for (ConfigComponent configComponent : configs) {
                    if (!this.isMouseOverBackground(this.sasokX, this.sasokY) || !configComponent.mouseBoolClicked(this.sasokX, this.sasokY, n3)) continue;
                    CsGui.updateConfigComponents();
                    dragging = true;
                    break;
                }
                for (ConfigComponent configComponent : configs2) {
                    if (!this.isMouseOverBackground(this.sasokX, this.sasokY) || !configComponent.mouseBoolClicked(this.sasokX, this.sasokY, n3)) continue;
                    CsGui.updateConfigComponents();
                    dragging = true;
                    break;
                }
            }
        }
    }

    @Override
    protected void mouseReleased(int n, int n2, int n3) {
        super.mouseReleased(this.sasokX, this.sasokY, n3);
        if (colorPicker != null) {
            colorPicker.mouseReleased(this.sasokX, this.sasokY, n3);
        }
        dragging = false;
    }

    public void updateMouse(int n, int n2) {
        if (dragging && colorPicker == null) {
            this.x = this.sasokX + this.prevMouseX;
            this.y = this.sasokY + this.prevMouseY;
            search.updatePosition(this.x + this.searchOffsetX, this.y + this.searchOffsetY, this.searchWidth, this.searchHeight);
        }
    }

    @Override
    protected void keyTyped(char c, int n) throws IOException {
        for (ModuleComponent moduleComponent : modules) {
            if (!moduleComponent.getModule().getCategory().equals((Object)selected) || !moduleComponent.getModule().isSearched()) continue;
            moduleComponent.keyTyped(n);
        }
        for (ModuleComponent moduleComponent : modules2) {
            if (!moduleComponent.getModule().getCategory().equals((Object)selected) || !moduleComponent.getModule().isSearched()) continue;
            moduleComponent.keyTyped(n);
        }
        search.textboxKeyTyped(c, n);
        if (n == 1 && !escapeInUse) {
            search.setFocused(false);
            this.openAnimation.setDirection(Direction.BACKWARDS);
            this.openAnimation.setDuration(300);
            this.isClosed = true;
            if (ClickGuiModule.sounds.get()) {
                SoundUtility.playSound("guidisabledev2.wav", 0.5f);
            }
        } else {
            escapeInUse = false;
        }
    }

    @Override
    public void onGuiClosed() {
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    public static float getAnimationAlpha() {
        return moduleAnimation.getOutput();
    }

    static {
        dragging = false;
        selected = Category.HOME;
        modules = new ArrayList<ModuleComponent>();
        modules2 = new ArrayList<ModuleComponent>();
        guiThemes = new ArrayList<ThemeComponent>();
        themes = new ArrayList<ThemeComponent>();
        configs = new ArrayList<ConfigComponent>();
        configs2 = new ArrayList<ConfigComponent>();
        moduleAnimation = new DecelerateAnimation(500, 1.0f, Direction.BACKWARDS);
    }
}
