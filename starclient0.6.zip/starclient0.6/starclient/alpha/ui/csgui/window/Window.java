package starclient.alpha.ui.csgui.window;

import net.minecraft.client.Minecraft;

public class Window {
    public float x;
    public float y;
    public float width;
    public float height;
    public final Minecraft mc = Minecraft.getMinecraft();

    public Window(float f, float f2, float f3, float f4) {
        this.x = f;
        this.y = f2;
        this.width = f3;
        this.height = f4;
    }

    public void init() {
    }

    public void render(int n, int n2) {
    }

    public void mouseClicked(double d, double d2, int n) {
    }

    public void mouseReleased(double d, double d2, int n) {
    }

    public void keyTyped(int n) {
    }

    public void setX(float f) {
        this.x = f;
    }

    public void setY(float f) {
        this.y = f;
    }

    public void setWidth(float f) {
        this.width = f;
    }

    public void setHeight(float f) {
        this.height = f;
    }
}
