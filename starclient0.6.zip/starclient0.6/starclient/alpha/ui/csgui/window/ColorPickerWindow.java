package starclient.alpha.ui.csgui.window;

import java.awt.Color;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.ui.csgui.CsGui;
import starclient.alpha.ui.csgui.window.Window;
import starclient.alpha.utility.math.MathUtility;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.EaseInOutQuad;

public class ColorPickerWindow
extends Window {
    private final ColorSetting colorSetting;
    private Animation animation = new EaseInOutQuad(250, 1.0f, Direction.FORWARDS);
    private final NumberSetting hueSlider = new NumberSetting("Hue", 1.0f, 1.0f, 360.0f, 1.0f);
    private boolean isHueDragging;
    private int hueValue;
    private float circleX;
    private float circleY;

    public ColorPickerWindow(float f, float f2, float f3, float f4, ColorSetting colorSetting) {
        super(f, f2, f3, f4);
        this.colorSetting = colorSetting;
        float[] fArray = ColorUtility.getRGBAf(colorSetting.get());
        float[] fArray2 = Color.RGBtoHSB((int)(fArray[0] * 255.0f), (int)(fArray[1] * 255.0f), (int)(fArray[2] * 255.0f), fArray);
        this.hueValue = (int)(fArray2[0] * 360.0f);
        this.circleX = this.x + 5.0f + (this.width - 10.0f) / 2.0f;
        this.circleY = this.y + 5.0f + (this.height - 20.0f) / 2.0f;
    }

    @Override
    public void init() {
        this.animation = new EaseInOutQuad(250, 1.0f, Direction.FORWARDS);
    }

    @Override
    public void render(int n, int n2) {
        if (this.animation.finished(Direction.BACKWARDS)) {
            CsGui.colorPicker = null;
        } else {
            float f;
            float f2;
            Color color = StarClient.getInstance().getC(0);
            Color color2 = StarClient.getInstance().getC(500);
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            RenderUtility.scaleStart(this.x + this.width / 2.0f, this.y + this.height / 2.0f, this.animation.getOutput());
            RenderUtility.drawGradientGlow(this.x, this.y, this.width, this.height, 7, color, color2);
            RenderUtility.drawRoundedRect(this.x, this.y, this.width, this.height, 5.0f, new Color(30, 30, 30).getRGB());
            int n3 = ColorUtility.HUEtoRGB(this.hueValue);
            RenderUtility.drawRoundedGradientRect(this.x + 5.0f, this.y + 5.0f, this.width - 10.0f, this.height - 20.0f, 0.0f, 0.0f, Color.WHITE.getRGB(), Color.BLACK.getRGB(), n3, Color.BLACK.getRGB());
            int n4 = 0;
            if (RenderUtility.isHovered(n, n2, this.x + 5.0f, this.y + 5.0f, this.width - 10.0f, this.height - 20.0f) && !this.isHueDragging && Mouse.isButtonDown((int)0)) {
                f2 = ((float)n - (this.x + 5.0f)) / (this.width - 10.0f);
                f = ((float)n2 - (this.y + 5.0f)) / (this.height - 20.0f);
                this.circleX = this.x + 5.0f + (this.width - 10.0f) * f2;
                this.circleY = this.y + 5.0f + (this.height - 20.0f) * f;
                this.circleX = Math.max(this.x + 5.0f, Math.min(this.circleX, this.x + this.width - 5.0f));
                this.circleY = Math.max(this.y + 5.0f, Math.min(this.circleY, this.y + this.height - 15.0f));
                n4 = Color.HSBtoRGB((float)this.hueValue / 360.0f, f2, 1.0f - f);
            }
            if (n4 != 0) {
                this.colorSetting.setColor(n4);
            }
            if (this.isHueDragging) {
                this.hueValue = this.getSliderValue(this.hueSlider, this.x + 5.0f, n);
            }
            f2 = 0.2f;
            f = 1.0f / f2;
            float f3 = this.x + 5.0f;
            float f4 = (this.width - 10.0f) / f;
            int n5 = 0;
            while ((float)n5 < f) {
                boolean bl2;
                boolean bl3 = bl2 = (float)n5 == f - 1.0f;
                if (bl2) {
                    f4 -= 1.0f;
                }
                RenderUtility.drawGradientRect(f3, this.y + this.height - 10.0f, f4, 5.0f, Color.HSBtoRGB(f2 * (float)n5, 1.0f, 1.0f), Color.HSBtoRGB(f2 * (float)(n5 + 1), 1.0f, 1.0f), Color.HSBtoRGB(f2 * (float)(n5 + 1), 1.0f, 1.0f), Color.HSBtoRGB(f2 * (float)n5, 1.0f, 1.0f));
                if (!bl2) {
                    f3 += f4;
                }
                ++n5;
            }
            RenderUtility.drawRoundedRect(this.x + 4.0f + (float)this.getPos(this.hueSlider, this.hueValue), this.y + this.height - 11.0f, 2.0f, 7.0f, 1.0f, -1);
            RenderUtility.drawCircle(this.circleX, this.circleY, 3.0f, Color.BLACK.getRGB());
            RenderUtility.drawCircle(this.circleX, this.circleY, 2.5f, Color.WHITE.getRGB());
            RenderUtility.scaleEnd();
        }
    }

    @Override
    public void mouseClicked(double d, double d2, int n) {
        if (!RenderUtility.isHovered(d, d2, (double)this.x, (double)this.y, (double)this.width, (double)this.height) && this.animation.isDone()) {
            this.animation.setDirection(Direction.BACKWARDS);
            this.animation.setDuration(225);
        }
        if (RenderUtility.isHovered(d, d2, (double)(this.x + 5.0f), (double)(this.y + this.height - 10.0f), (double)(this.width - 10.0f), 5.0) && n == 0) {
            this.isHueDragging = true;
        }
    }

    @Override
    public void mouseReleased(double d, double d2, int n) {
        this.isHueDragging = false;
    }

    public int getSliderValue(NumberSetting numberSetting, float f, int n) {
        int n2 = (int)(numberSetting.getMaxValue() - numberSetting.getMinValue());
        float f2 = (float)n - f;
        float f3 = f2 / (this.width - 10.0f);
        float f4 = (float)(numberSetting.getMinValue() + (double)((float)n2 * f3));
        return (int)MathUtility.clamp((int)MathUtility.round(f4, numberSetting.getIncrement()), (float)numberSetting.getMinValue(), (float)numberSetting.getMaxValue());
    }

    public int getPos(NumberSetting numberSetting, int n) {
        int n2 = (int)(numberSetting.getMaxValue() - numberSetting.getMinValue());
        return (int)((double)(this.width - 10.0f) * ((double)n - numberSetting.getMinValue()) / (double)n2);
    }

    public ColorSetting getColorSetting() {
        return this.colorSetting;
    }
}
