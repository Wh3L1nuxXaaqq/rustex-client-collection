package starclient.alpha.module;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.impl.combat.AimBotDayz;
import starclient.alpha.module.impl.combat.AimSync;
import starclient.alpha.module.impl.combat.AntiBot;
import starclient.alpha.module.impl.combat.HitSoundDayz;
import starclient.alpha.module.impl.combat.NSR;
import starclient.alpha.module.impl.combat.TriggerBot;
import starclient.alpha.module.impl.movement.AirStuck;
import starclient.alpha.module.impl.movement.AutoPeek;
import starclient.alpha.module.impl.movement.AutoSprint;
import starclient.alpha.module.impl.movement.NoClip;
import starclient.alpha.module.impl.movement.NoSlow;
import starclient.alpha.module.impl.movement.SpeedDayz;
import starclient.alpha.module.impl.movement.TickShift;
import starclient.alpha.module.impl.movement.Timer;
import starclient.alpha.module.impl.movement.WaterSpeed;
import starclient.alpha.module.impl.player.AntiAFK;
import starclient.alpha.module.impl.player.AutoTPAccept;
import starclient.alpha.module.impl.player.FreeCam;
import starclient.alpha.module.impl.player.InventoryMove;
import starclient.alpha.module.impl.player.ItemScroller;
import starclient.alpha.module.impl.player.ItemSwapFix;
import starclient.alpha.module.impl.player.MCF;
import starclient.alpha.module.impl.player.NoAction;
import starclient.alpha.module.impl.player.NoPush;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.module.impl.render.Arrows;
import starclient.alpha.module.impl.render.Chams;
import starclient.alpha.module.impl.render.ChinaHat;
import starclient.alpha.module.impl.render.ChunkAnimator;
import starclient.alpha.module.impl.render.ClickGuiModule;
import starclient.alpha.module.impl.render.Crosshair;
import starclient.alpha.module.impl.render.ExpInfo;
import starclient.alpha.module.impl.render.FullBright;
import starclient.alpha.module.impl.render.Hud;
import starclient.alpha.module.impl.render.ItemESP;
import starclient.alpha.module.impl.render.JumpCircle;
import starclient.alpha.module.impl.render.NameTags;
import starclient.alpha.module.impl.render.Notifications;
import starclient.alpha.module.impl.render.PenisESP;
import starclient.alpha.module.impl.render.PlayerESP;
import starclient.alpha.module.impl.render.SwingAnimations;
import starclient.alpha.module.impl.render.TargetESP;
import starclient.alpha.module.impl.render.Tracers;
import starclient.alpha.module.impl.render.Trails;
import starclient.alpha.module.impl.render.ViewModel;
import starclient.alpha.module.impl.render.WallHack;
import starclient.alpha.module.impl.render.Wings;
import starclient.alpha.module.impl.render.WorldColor;
import starclient.alpha.module.impl.render.WorldTime;
import starclient.alpha.module.impl.render.ZombaESP;
import starclient.alpha.module.impl.util.BetterChat;
import starclient.alpha.module.impl.util.BetterTab;
import starclient.alpha.module.impl.util.ChestStealer;
import starclient.alpha.module.impl.util.ClientSounds;
import starclient.alpha.module.impl.util.DeathCoordinates;
import starclient.alpha.module.impl.util.FakeLags;
import starclient.alpha.module.impl.util.FakePlayer;
import starclient.alpha.module.impl.util.FastPeek;
import starclient.alpha.module.impl.util.GPS;
import starclient.alpha.module.impl.util.Indicators;
import starclient.alpha.module.impl.util.KillMessage;
import starclient.alpha.module.impl.util.NameProtect;
import starclient.alpha.module.impl.util.NoAntiSpam;
import starclient.alpha.module.impl.util.Optimizer;
import starclient.alpha.module.impl.util.PasswordHider;
import starclient.alpha.module.impl.util.Spectator;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();
    public Timer timer;
    public Arraylist arraylist;

    public ModuleManager() {
        this.registerModule(new AutoSprint());
        this.registerModule(new AntiBot());
        this.registerModule(new KillMessage());
        this.registerModule(new Indicators());
        this.registerModule(new NSR());
        this.registerModule(new WaterSpeed());
        this.registerModule(new Optimizer());
        this.registerModule(new Arrows());
        this.registerModule(new NoSlow());
        this.registerModule(new Spectator());
        this.registerModule(new TickShift());
        this.timer = new Timer();
        this.registerModule(this.timer);
        this.registerModule(new ExpInfo());
        this.arraylist = new Arraylist();
        this.registerModule(this.arraylist);
        this.registerModule(new TargetESP());
        this.registerModule(new Hud());
        this.registerModule(new ClickGuiModule());
        this.registerModule(new ChunkAnimator());
        this.registerModule(new Trails());
        this.registerModule(new ChinaHat());
        this.registerModule(new FullBright());
        this.registerModule(new JumpCircle());
        this.registerModule(new WallHack());
        this.registerModule(new WorldTime());
        this.registerModule(new Wings());
        this.registerModule(new NameTags());
        this.registerModule(new PlayerESP());
        this.registerModule(new ItemESP());
        this.registerModule(new Tracers());
        this.registerModule(new ItemSwapFix());
        this.registerModule(new Crosshair());
        this.registerModule(new Notifications());
        this.registerModule(new AntiAFK());
        this.registerModule(new AutoTPAccept());
        this.registerModule(new InventoryMove());
        this.registerModule(new MCF());
        this.registerModule(new NoClip());
        this.registerModule(new FreeCam());
        this.registerModule(new NameProtect());
        this.registerModule(new BetterChat());
        this.registerModule(new BetterTab());
        this.registerModule(new DeathCoordinates());
        this.registerModule(new PasswordHider());
        this.registerModule(new SwingAnimations());
        this.registerModule(new ViewModel());
        this.registerModule(new NoAction());
        this.registerModule(new FakePlayer());
        this.registerModule(new ZombaESP());
        this.registerModule(new ItemScroller());
        this.registerModule(new PenisESP());
        this.registerModule(new Chams());
        this.registerModule(new WorldColor());
        this.registerModule(new AutoPeek());
        this.registerModule(new ClientSounds());
        this.registerModule(new NoAntiSpam());
        this.registerModule(new AirStuck());
        this.registerModule(new AimSync());
        this.registerModule(new NoPush());
        this.registerModule(new FastPeek());
        this.registerModule(new TriggerBot());
        this.registerModule(new AimBotDayz());
        this.registerModule(new FakeLags());
        this.registerModule(new SpeedDayz());
        this.registerModule(new ChestStealer());
        this.registerModule(new HitSoundDayz());
        this.registerModule(new GPS());
    }

    public void registerModule(Module module) {
        this.modules.add(module);
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public Module[] getModulesFromCategory(Category category) {
        return (Module[])this.modules.stream().filter(module -> module.category == category).toArray(Module[]::new);
    }

    public Module getModule(Class<? extends Module> clazz) {
        Module module;
        Iterator<Module> iterator = this.modules.iterator();
        do {
            if (iterator.hasNext()) continue;
            return null;
        } while ((module = iterator.next()) == null || module.getClass() != clazz);
        return module;
    }

    public Module getModule(String string) {
        Module module;
        Iterator<Module> iterator = this.modules.iterator();
        do {
            if (iterator.hasNext()) continue;
            return null;
        } while ((module = iterator.next()) == null || !module.getName().equalsIgnoreCase(string));
        return module;
    }
}
