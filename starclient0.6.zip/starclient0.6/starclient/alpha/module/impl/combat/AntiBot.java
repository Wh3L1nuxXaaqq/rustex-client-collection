package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.EntityPlayer;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="AntiBot", category=Category.COMBAT)
public class AntiBot
extends Module {
    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        for (int i = 0; i < AntiBot.mc.world.loadedEntityList.size(); ++i) {
            EntityPlayer entityPlayer;
            if (!(AntiBot.mc.world.loadedEntityList.get(i) instanceof EntityPlayer) || !(entityPlayer = (EntityPlayer)AntiBot.mc.world.loadedEntityList.get(i)).isInvisible() || entityPlayer == AntiBot.mc.player) continue;
            AntiBot.mc.world.removeEntity(entityPlayer);
        }
    }
}
