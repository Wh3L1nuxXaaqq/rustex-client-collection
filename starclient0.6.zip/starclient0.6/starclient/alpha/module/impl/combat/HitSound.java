package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketTitle;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.utility.misc.SoundUtility;

@ModuleAnnotation(name="HitSound", category=Category.COMBAT)
public class HitSound
extends Module {
    private ModeSetting mode = new ModeSetting("\u0417\u0432\u0443\u043a", "Bonk", "Bonk", "Bell", "Bubble", "Crime", "Rust", "Hit", "UwU", "Bam-bam", "Kit-glop", "Csgo", "Skeet");

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketTitle sPacketTitle;
        String string;
        if (eventReceivePacket.getPacket() instanceof SPacketTitle && (string = (sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket()).getMessage().getUnformattedText()).contains("HP)")) {
            SoundUtility.playSound(this.mode.get().toLowerCase() + ".wav", 0.5f);
        }
    }
}
