package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketTitle;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.impl.combat.TimerUtils;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.utility.misc.ChatUtility;
import starclient.alpha.utility.render.animation.Animation;

@ModuleAnnotation(name="DamageLog", category=Category.COMBAT)
public class DamageLog
extends Module {
    public ModeSetting mode = new ModeSetting("Mode", "Chat", "TeamChat", "Chat");
    public TimerUtils timer = new TimerUtils();
    public Animation animation;

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (!StarClient.getInstance().getModuleManager().getModule(AimBot.class).isEnabled()) {
            return;
        }
        if (eventReceivePacket.getPacket() instanceof SPacketTitle) {
            SPacketTitle sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket();
            String string = sPacketTitle.getMessage().getUnformattedText();
            if (!string.contains("HP)")) {
                return;
            }
            try {
                int n = string.indexOf(45);
                int n2 = string.indexOf(32, n);
                int n3 = Integer.parseInt(string.substring(n, n2).trim());
                int n4 = string.indexOf(40, n2) + 1;
                int n5 = string.indexOf(32, n4);
                int n6 = Integer.parseInt(string.substring(n4, n5));
                String string2 = AimBot.lastTarget != null && AimBot.lastTarget.getTarget() != null ? AimBot.lastTarget.getTarget().getName() : "Unknown";
                String string3 = n6 <= 30 ? "\u041b\u043e\u0443 \u0445\u043f >> " : "\u0414\u0430\u043b \u0434\u0430\u043c\u0430\u0433 >> ";
                String string4 = String.format("%s-%d (%d HP) >> %s", string3, Math.abs(n3), n6, string2);
                switch (this.mode.get()) {
                    case "Chat": {
                        ChatUtility.addChatMessage(string4);
                        break;
                    }
                    case "TeamChat": {
                        ChatUtility.sendChatMessage("@ " + string4.replace("\u00a7c", ""));
                    }
                }
            }
            catch (Exception exception) {
                String string5 = "\u00a74...\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u043a\u0435 \u0443\u0440\u043e\u043d\u0430.";
                if (this.mode.get().equals("TeamChat")) {
                    ChatUtility.sendChatMessage("@ " + string5);
                }
                ChatUtility.addChatMessage(string5);
            }
        }
    }
}
