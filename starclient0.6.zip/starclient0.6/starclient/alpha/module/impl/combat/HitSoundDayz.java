package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketTitle;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.misc.SoundUtility;

@ModuleAnnotation(name="HitSoundDayz", category=Category.COMBAT)
public class HitSoundDayz
extends Module {
    private ModeSetting mode = new ModeSetting("\u0417\u0432\u0443\u043a", "Bonk", "Bonk", "Bell", "Bubble", "Crime", "Rust", "Hit", "UwU", "Bam-bam", "Kit-glop", "Csgo", "Skeet");
    public static NumberSetting volume = new NumberSetting("Volume", 0.5f, 0.0f, 1.0f, 0.1f);

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketTitle sPacketTitle;
        String string;
        if (eventReceivePacket.getPacket() instanceof SPacketTitle && ((string = (sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket()).getMessage().getUnformattedText()).contains("\u0412 \u0433\u043e\u043b\u043e\u0432\u0443!") || string.contains("\u0412 \u0442\u0435\u043b\u043e!"))) {
            SoundUtility.playSound(this.mode.get().toLowerCase() + ".wav", volume.get());
        }
    }
}
