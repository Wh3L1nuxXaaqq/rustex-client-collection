package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.util.math.BlockPos;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.setting.impl.ModeSetting;

@ModuleAnnotation(name="HitEffect", category=Category.COMBAT)
public class HitEffect
extends Module {
    public ModeSetting effect = new ModeSetting("\u042d\u0444\u0444\u0435\u043a\u0442", "\u041c\u043e\u043b\u043d\u0438\u044f", "\u041c\u043e\u043b\u043d\u0438\u044f", "\u0412\u0437\u0440\u044b\u0432 \u043a\u0440\u043e\u0432\u0438");

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketTitle sPacketTitle;
        String string;
        if (eventReceivePacket.getPacket() instanceof SPacketTitle && (string = (sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket()).getMessage().getUnformattedText()).contains("HP)")) {
            EntityLivingBase entityLivingBase = AimBot.lastTarget.getTarget();
            if (this.effect.get().equals("\u041c\u043e\u043b\u043d\u0438\u044f")) {
                HitEffect.mc.world.addWeatherEffect(new EntityLightningBolt(HitEffect.mc.world, entityLivingBase.posX, entityLivingBase.posY, entityLivingBase.posZ, true));
            } else if (this.effect.get().equals("\u0412\u0437\u0440\u044b\u0432 \u043a\u0440\u043e\u0432\u0438")) {
                HitEffect.mc.renderGlobal.playEvent(HitEffect.mc.player, 2001, new BlockPos(entityLivingBase.posX, entityLivingBase.posY + (double)entityLivingBase.getEyeHeight(), entityLivingBase.posZ), 152);
            }
        }
    }
}
