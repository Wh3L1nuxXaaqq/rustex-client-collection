package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="Hitbox", category=Category.COMBAT)
public class Hitbox
extends Module {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final WeakHashMap<Entity, float[]> originalSizes = new WeakHashMap();
    public BooleanSetting players = new BooleanSetting("Players", true);
    public BooleanSetting mobs = new BooleanSetting("Mobs", true);
    public NumberSetting size = new NumberSetting("Size", 0.2f, -0.9f, 2.0f, 0.1f);

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        for (Entity entity : this.mc.world.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase) || !this.isValidEntity(entity)) continue;
            this.adjustHitbox((EntityLivingBase)entity);
        }
    }

    private boolean isValidEntity(Entity entity) {
        if (entity == this.mc.player) {
            return false;
        }
        return this.players.get() && entity instanceof EntityPlayer || this.mobs.get() && entity instanceof EntityMob;
    }

    private void adjustHitbox(EntityLivingBase entityLivingBase) {
        if (!this.originalSizes.containsKey(entityLivingBase)) {
            this.originalSizes.put(entityLivingBase, new float[]{entityLivingBase.width, entityLivingBase.height});
        }
        float f = this.size.get();
        float[] fArray = this.originalSizes.get(entityLivingBase);
        float f2 = fArray[0] * (1.0f + f);
        float f3 = fArray[1] * (1.0f + f);
        entityLivingBase.width = f2;
        entityLivingBase.height = f3;
        double d = f2 / 2.0f;
        entityLivingBase.setEntityBoundingBox(new AxisAlignedBB(entityLivingBase.posX - d, entityLivingBase.posY, entityLivingBase.posZ - d, entityLivingBase.posX + d, entityLivingBase.posY + (double)f3, entityLivingBase.posZ + d));
    }

    @Override
    public void onDisable() {
        for (Entity entity : this.originalSizes.keySet()) {
            if (!(entity instanceof EntityLivingBase)) continue;
            EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            float[] fArray = this.originalSizes.get(entity);
            entityLivingBase.width = fArray[0];
            entityLivingBase.height = fArray[1];
            entityLivingBase.setEntityBoundingBox(new AxisAlignedBB(entityLivingBase.posX - (double)(fArray[0] / 2.0f), entityLivingBase.posY, entityLivingBase.posZ - (double)(fArray[0] / 2.0f), entityLivingBase.posX + (double)(fArray[0] / 2.0f), entityLivingBase.posY + (double)fArray[1], entityLivingBase.posZ + (double)(fArray[0] / 2.0f)));
        }
        this.originalSizes.clear();
        super.onDisable();
    }
}
