package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.movement.Timer;
import starclient.alpha.module.impl.render.Hud;
import starclient.alpha.utility.MathUtility;
import starclient.alpha.utility.misc.TimerHelper;

@ModuleAnnotation(name="AimSync", category=Category.COMBAT)
public class AimSync
extends Module {
    private final TimerHelper timeDelay = new TimerHelper();
    private final ArrayDeque<Float> tpsResult = new ArrayDeque(20);
    private long time;
    private static long tickTime;
    public static float TICK_TIMER;
    private static float tps;

    public static float getTPS() {
        return AimSync.round2(tps);
    }

    public static float getTPS2() {
        return AimSync.round2(20.0f * ((float)tickTime / 1000.0f));
    }

    public static float round2(double d) {
        BigDecimal bigDecimal = new BigDecimal(d);
        bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_UP);
        return bigDecimal.floatValue();
    }

    @EventTarget
    public void onPacketReceive(EventReceivePacket eventReceivePacket) {
        if (!(eventReceivePacket.getPacket() instanceof SPacketChat)) {
            this.timeDelay.reset();
        }
        if (eventReceivePacket.getPacket() instanceof SPacketTimeUpdate) {
            if (this.time != 0L) {
                tickTime = System.currentTimeMillis() - this.time;
                if (this.tpsResult.size() > 20) {
                    this.tpsResult.poll();
                }
                this.tpsResult.add(Float.valueOf(20.0f * (1000.0f / (float)tickTime)));
                float f = 0.0f;
                for (Float f2 : this.tpsResult) {
                    f += MathUtility.clamp(f2.floatValue(), 0.0f, 20.0f);
                }
                tps = f / (float)this.tpsResult.size();
            }
            this.time = System.currentTimeMillis();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (!StarClient.getInstance().getModuleManager().getModule(Timer.class).isEnabled()) {
            TICK_TIMER = AimSync.getTPS() > 1.0f ? AimSync.getTPS() / 20.0f : 1.0f;
        }
    }

    @Override
    public void onDisable() {
        TICK_TIMER = 1.0f;
        Hud.TPSSyncMessageDisplayed = false;
        super.onDisable();
    }

    static {
        TICK_TIMER = 1.0f;
    }
}
