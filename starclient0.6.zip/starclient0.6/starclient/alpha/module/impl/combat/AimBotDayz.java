package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Comparator;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiSleepMP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import starclient.alpha.AnimationUtils;
import starclient.alpha.StarClient;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.impl.combat.TargetResult;
import starclient.alpha.module.impl.combat.TimerUtils;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="AimBotDayz", category=Category.COMBAT)
public class AimBotDayz
extends Module {
    public static boolean work = false;
    public static TargetResult lastTarget;
    public static TargetResult target;
    int ticks = 0;
    public TimerUtils timer = new TimerUtils();
    public TimerUtils timerLastSee = new TimerUtils();
    public boolean reloading;
    private final AnimationUtils animPosX;
    private final AnimationUtils animPosY;
    private final AnimationUtils animEndX;
    private final AnimationUtils animEndY;
    private final IntBuffer viewport;
    private final FloatBuffer modelview;
    private final FloatBuffer projection;
    private final FloatBuffer vector;
    public BooleanSetting zombie = new BooleanSetting("Zombie", true);
    public BooleanSetting silent = new BooleanSetting("Silent", true);
    public BooleanSetting multipoint = new BooleanSetting("MultiPoints", true);
    public static NumberSetting accuracy;
    public static NumberSetting fov;
    public static NumberSetting maxDistance;
    public BooleanSetting radius = new BooleanSetting("Fov", true);
    public BooleanSetting autoPredict = new BooleanSetting("Auto-Predict", true);
    public NumberSetting predict = new NumberSetting("Predict", 5.5f, 0.0f, 10.0f, 0.1f);
    public NumberSetting pretarget = new NumberSetting("Corrector-Predict", 5.5f, 0.0f, 10.0f, 0.1f);
    public BooleanSetting block = new BooleanSetting("Block", true);
    public NumberSetting blocks = new NumberSetting("Blocks", 30.0f, 1.0f, 300.0f, 1.0f);
    public NumberSetting addpredict = new NumberSetting("ADDPredict", 2.0f, 0.0f, 10.0f, 0.1f);
    public BooleanSetting stay = new BooleanSetting("Stay-Delay", true);
    public NumberSetting staydelay = new NumberSetting("Stay", 120.0f, 0.0f, 1000.0f, 10.0f);
    public static final BooleanSetting renderFirePos;
    public BooleanSetting autoShoot = new BooleanSetting("AutoShoot", false);
    public NumberSetting cps = new NumberSetting("CPS", 20.0f, 1.0f, 20.0f, 1.0f);
    public static boolean ishandcontainbow;
    private TimerUtils stayTimer = new TimerUtils();
    private EntityLivingBase currentTargetEntity;
    private long startMovingTime = 0L;
    private boolean wasStanding = false;

    public AimBotDayz() {
        this.predict.setVisible(() -> !this.autoPredict.get());
        accuracy.setVisible(() -> this.multipoint.get());
        this.cps.setVisible(() -> this.autoShoot.get());
        this.blocks.setVisible(() -> this.block.get());
        this.addpredict.setVisible(() -> this.block.get());
        this.staydelay.setVisible(() -> this.stay.get());
        this.animPosX = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.animPosY = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.animEndX = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.animEndY = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.viewport = GLAllocation.createDirectIntBuffer(16);
        this.modelview = GLAllocation.createDirectFloatBuffer(16);
        this.projection = GLAllocation.createDirectFloatBuffer(16);
        this.vector = GLAllocation.createDirectFloatBuffer(4);
    }

    @EventTarget
    public void render2D(EventRender2D eventRender2D) {
        int n;
        if (target != null && renderFirePos.get()) {
            GL11.glPushMatrix();
            float f = mc.getRenderPartialTicks();
            n = ScaledResolution.getScaleFactor();
            double d = (double)n / Math.pow(n, 2.0);
            GL11.glScaled((double)d, (double)d, (double)d);
            RenderManager renderManager = mc.getRenderManager();
            EntityRenderer entityRenderer = AimBotDayz.mc.entityRenderer;
            double d2 = AimBotDayz.target.getTarget().posX + AimBotDayz.target.getPos().xCoord - (AimBotDayz.target.getTarget().lastTickPosX - AimBotDayz.target.getTarget().posX) * (double)this.predict.get();
            double d3 = AimBotDayz.target.getTarget().posY + AimBotDayz.target.getPos().yCoord - 0.1;
            double d4 = AimBotDayz.target.getTarget().posZ + AimBotDayz.target.getPos().zCoord - (AimBotDayz.target.getTarget().lastTickPosZ - AimBotDayz.target.getTarget().posZ) * (double)this.predict.get();
            double d5 = 0.1;
            double d6 = 0.1;
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB(d2 - d5, d3 - d6, d4 - d5, d2 + d5, d3 + d6, d4 + d5);
            Vector3d[] vector3dArray = new Vector3d[]{new Vector3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ)};
            entityRenderer.setupCameraTransform(f, 0);
            Vector4d vector4d = null;
            for (Vector3d vector3d : vector3dArray) {
                vector3d = this.project2D(n, vector3d.x - renderManager.viewerPosX, vector3d.y - renderManager.viewerPosY, vector3d.z - renderManager.viewerPosZ);
                if (vector3d == null || !(vector3d.z >= 0.0) || !(vector3d.z < 1.0)) continue;
                if (vector4d == null) {
                    vector4d = new Vector4d(vector3d.x, vector3d.y, vector3d.z, 0.0);
                }
                vector4d.x = Math.min(vector3d.x, vector4d.x);
                vector4d.y = Math.min(vector3d.y, vector4d.y);
                vector4d.z = Math.max(vector3d.x, vector4d.z);
                vector4d.w = Math.max(vector3d.y, vector4d.w);
            }
            if (vector4d != null) {
                entityRenderer.setupOverlayRendering();
                double d7 = (vector4d.x + vector4d.z) / 2.0;
                double d8 = (vector4d.y + vector4d.w) / 2.0;
                this.animPosX.to = (float)d7;
                this.animPosY.to = (float)d8;
                this.animEndX.to = (float)d7;
                this.animEndY.to = (float)d8;
                Fonts.hitmarker.drawCenteredStringWithOutline("\u0430", (int)this.animPosX.getAnim(), (int)this.animPosY.getAnim(), -1);
            }
            GL11.glPopMatrix();
            GL11.glEnable((int)2929);
            GlStateManager.enableBlend();
            entityRenderer.setupOverlayRendering();
        }
        if (this.radius.get()) {
            ScaledResolution scaledResolution = new ScaledResolution(mc);
            n = scaledResolution.getScaledWidth() / 2;
            int n2 = scaledResolution.getScaledHeight() / 2;
            float f = fov.get();
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableTexture2D();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            if (target != null) {
                GL11.glColor4f((float)1.0f, (float)0.0f, (float)0.0f, (float)1.0f);
            } else {
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            }
            GL11.glLineWidth((float)3.0f);
            GL11.glBegin((int)2);
            for (int i = 0; i < 360; ++i) {
                double d = Math.toRadians(i);
                double d9 = (double)n + Math.cos(d) * (double)f;
                double d10 = (double)n2 + Math.sin(d) * (double)f;
                GL11.glVertex2d((double)d9, (double)d10);
            }
            GL11.glEnd();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
        }
    }

    private Vector3d[] getVectors(AxisAlignedBB axisAlignedBB) {
        return new Vector3d[]{new Vector3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vector3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ)};
    }

    private double[] calculateTargetPosition() {
        double d = AimBotDayz.target.getTarget().posX + AimBotDayz.target.getPos().x - (AimBotDayz.target.getTarget().lastTickPosX - AimBotDayz.target.getTarget().posX) * (double)this.predict.get();
        double d2 = AimBotDayz.target.getTarget().posY + AimBotDayz.target.getPos().y;
        double d3 = AimBotDayz.target.getTarget().posZ + AimBotDayz.target.getPos().z - (AimBotDayz.target.getTarget().lastTickPosZ - AimBotDayz.target.getTarget().posZ) * (double)this.predict.get();
        return new double[]{d, d2, d3};
    }

    private Vector3d project2D(int n, double d, double d2, double d3) {
        GL11.glGetFloat((int)2982, (FloatBuffer)this.modelview);
        GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
        GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
        return GLU.gluProject((float)((float)d), (float)((float)d2), (float)((float)d3), (FloatBuffer)this.modelview, (FloatBuffer)this.projection, (IntBuffer)this.viewport, (FloatBuffer)this.vector) ? new Vector3d(this.vector.get(0) / (float)n, ((float)Display.getHeight() - this.vector.get(1)) / (float)n, this.vector.get(2)) : null;
    }

    @Override
    public void onDisable() {
        target = null;
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        float f = this.calculateTotalPredict();
        target = this.getTarget(f);
        if (target != null) {
            boolean bl;
            if (target.getTarget() != this.currentTargetEntity) {
                this.currentTargetEntity = target.getTarget();
                this.wasStanding = false;
                this.startMovingTime = 0L;
            }
            boolean bl2 = bl = Math.abs(this.currentTargetEntity.posX - this.currentTargetEntity.lastTickPosX) > 0.001 || Math.abs(this.currentTargetEntity.posY - this.currentTargetEntity.lastTickPosY) > 0.001 || Math.abs(this.currentTargetEntity.posZ - this.currentTargetEntity.lastTickPosZ) > 0.001;
            if (bl) {
                if (this.wasStanding) {
                    this.startMovingTime = System.currentTimeMillis();
                    this.wasStanding = false;
                }
            } else {
                this.wasStanding = true;
            }
        } else {
            this.currentTargetEntity = null;
            this.wasStanding = false;
            this.startMovingTime = 0L;
        }
        boolean bl = ishandcontainbow = AimBotDayz.mc.player.getHeldItemMainhand().getItem() == Items.BOW || AimBotDayz.mc.player.getHeldItemMainhand().itemDamage == 440;
        if (AimBotDayz.mc.currentScreen instanceof GuiSleepMP) {
            this.setToggled(false);
        }
        lastTarget = target;
        if (target == null) {
            work = false;
            this.ticks = 0;
        } else {
            this.timerLastSee.reset();
            work = true;
            ++this.ticks;
            this.aim(target, eventUpdate);
            if (this.autoShoot.get() && this.ticks > 1 && this.timer.hasReached((long)(1000.0f / this.cps.get()))) {
                this.shoot(target.getTarget());
            }
        }
    }

    private float calculateTotalPredict() {
        float f;
        float f2 = f = this.autoPredict.get() ? (float)mc.getConnection().getPlayerInfo(AimBotDayz.mc.player.getUniqueID()).getResponseTime() / 20.0f : this.predict.get();
        if (this.block.get() && target != null && target.getDistance() <= (double)this.blocks.get()) {
            f += this.addpredict.get();
        }
        return f;
    }

    public void shoot(EntityLivingBase entityLivingBase) {
        if (AimBotDayz.mc.player.getCooldownTracker().getCooldown(AimBotDayz.mc.player.inventory.getCurrentItem().getItem(), mc.getRenderPartialTicks()) == 0.0f) {
            AimBotDayz.mc.playerController.clickBlock(new BlockPos(AimBotDayz.mc.player.posX, AimBotDayz.mc.player.posY + 1.0, AimBotDayz.mc.player.posZ), EnumFacing.UP);
            AimBotDayz.mc.player.swingArm(EnumHand.MAIN_HAND);
            this.timer.reset();
        }
    }

    public float getBowOffset(Entity entity) {
        double d = Math.abs(AimBotDayz.mc.player.posY - entity.posY) * Math.abs(AimBotDayz.mc.player.posY - entity.posY) / 36.0;
        return (float)((double)(AimBotDayz.mc.player.getDistanceToEntity(entity) * AimBotDayz.mc.player.getDistanceToEntity(entity)) / 1980.0 + (ishandcontainbow ? d : 0.0));
    }

    public void aim(TargetResult targetResult, EventUpdate eventUpdate) {
        float f = this.calculateTotalPredict();
        long l = System.currentTimeMillis();
        float f2 = this.stay.get() && this.currentTargetEntity != null && this.startMovingTime > 0L && (float)(l - this.startMovingTime) < this.staydelay.get() ? 0.0f : f;
        float[] fArray = this.getAim(targetResult, f2);
        if (this.silent.get()) {
            eventUpdate.setRotationYaw(fArray[0]);
            eventUpdate.setRotationPitch(fArray[1]);
            AimBotDayz.mc.player.rotationYawHead = fArray[0];
            AimBotDayz.mc.player.rotationPitchHead = fArray[1];
            AimBotDayz.mc.player.renderYawOffset = fArray[0];
        } else {
            AimBotDayz.mc.player.rotationYaw = fArray[0];
            AimBotDayz.mc.player.rotationPitch = fArray[1];
        }
    }

    public float[] getAim(TargetResult targetResult, float f) {
        double d;
        double d2;
        EntityLivingBase entityLivingBase = targetResult.getTarget();
        Vec3d vec3d = new Vec3d(AimBotDayz.mc.player.posX - AimBotDayz.mc.player.lastTickPosX, AimBotDayz.mc.player.posY - AimBotDayz.mc.player.lastTickPosY, AimBotDayz.mc.player.posZ - AimBotDayz.mc.player.lastTickPosZ);
        Vec3d vec3d2 = new Vec3d(entityLivingBase.posX - entityLivingBase.lastTickPosX, entityLivingBase.posY - entityLivingBase.lastTickPosY, entityLivingBase.posZ - entityLivingBase.lastTickPosZ);
        double d3 = vec3d.dotProduct(vec3d2);
        double d4 = Math.toDegrees(Math.acos(d3 / ((d2 = vec3d.lengthVector()) * (d = vec3d2.lengthVector()))));
        if (d4 < 90.0 && d2 > 0.1 && d > 0.1) {
            f += this.pretarget.get();
        }
        float f2 = ishandcontainbow ? this.getBowOffset(targetResult.getTarget()) : 0.0f;
        double d5 = (entityLivingBase.lastTickPosX - entityLivingBase.posX) * (double)(f += ishandcontainbow ? AimBotDayz.mc.player.getDistanceToEntity(targetResult.getTarget()) / 5.0f : 0.0f);
        double d6 = (entityLivingBase.lastTickPosZ - entityLivingBase.posZ) * (double)f;
        double d7 = (double)f2 - (double)0.1f;
        return Utils.getNeededRotations(entityLivingBase.posX - d5 + targetResult.getPos().xCoord, entityLivingBase.posY + targetResult.getPos().yCoord + d7, entityLivingBase.posZ - d6 + targetResult.getPos().zCoord, AimBotDayz.mc.player.posX, AimBotDayz.mc.player.posY + (double)AimBotDayz.mc.player.getEyeHeight(), AimBotDayz.mc.player.posZ);
    }

    public Vec3d getMultipointPos(EntityLivingBase entityLivingBase, float f) {
        if (AimBotDayz.mc.player.canEntityBeSeen(entityLivingBase)) {
            return new Vec3d(0.0, (double)entityLivingBase.getEyeHeight() - 0.1, 0.0);
        }
        ArrayList<Vec3d> arrayList = new ArrayList<Vec3d>();
        double d = (entityLivingBase.lastTickPosX - entityLivingBase.posX) * (double)f;
        double d2 = (entityLivingBase.lastTickPosZ - entityLivingBase.posZ) * (double)f;
        if (AimBotDayz.mc.player.canEntityBeSeen(entityLivingBase.posX - d, entityLivingBase.posY + (double)entityLivingBase.getEyeHeight(), entityLivingBase.posZ - d2)) {
            return new Vec3d(0.0, (double)entityLivingBase.getEyeHeight() - 0.1, 0.0);
        }
        if (!this.multipoint.get()) {
            return null;
        }
        int n = 100;
        for (float f2 = -(entityLivingBase.width / 2.0f); f2 < entityLivingBase.width / 2.0f; f2 += accuracy.get()) {
            for (float f3 = -0.3f; f3 < entityLivingBase.height; f3 += accuracy.get()) {
                for (float f4 = -(entityLivingBase.width / 2.0f); f4 < entityLivingBase.width / 2.0f; f4 += accuracy.get()) {
                    if (AimBotDayz.mc.player.canEntityBeSeen(entityLivingBase.posX - d + (double)f2, entityLivingBase.posY + (double)f3 + (double)entityLivingBase.getEyeHeight() - 0.1, entityLivingBase.posZ - d2 + (double)f4)) {
                        arrayList.add(new Vec3d(f2, f3, f4));
                    }
                    if (arrayList.size() >= n) break;
                }
                if (arrayList.size() >= n) break;
            }
            if (arrayList.size() >= n) break;
        }
        if (!arrayList.isEmpty()) {
            arrayList.sort(Comparator.comparingDouble(vec3d -> this.getDistance((Vec3d)vec3d, new Vec3d(0.0, entityLivingBase.getEyeHeight(), 0.0))));
            return (Vec3d)arrayList.get(0);
        }
        return null;
    }

    public TargetResult getTarget(float f) {
        ArrayList<TargetResult> arrayList = new ArrayList<TargetResult>();
        for (Entity entity : AimBotDayz.mc.world.loadedEntityList) {
            Vec3d vec3d;
            boolean bl;
            if (!(entity instanceof EntityLivingBase)) continue;
            EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            if (entity == AimBotDayz.mc.player || entity.isInvisible() || entityLivingBase.getHealth() <= 0.0f) continue;
            double d = AimBotDayz.mc.player.getDistanceToEntity(entity);
            float f2 = f;
            if (this.block.get() && d <= (double)this.blocks.get()) {
                f2 += this.addpredict.get();
            }
            if (!(bl = this.zombie.get() && (entity instanceof EntityPlayer || entity instanceof EntityZombie) || !this.zombie.get() && entity instanceof EntityPlayer) || !this.fov(entity, fov.get()) || d > (double)maxDistance.get() || entityLivingBase.height < 1.5f || StarClient.getInstance().getFriendManager().isFriend(entity.getName()) || (vec3d = this.getMultipointPos(entityLivingBase, f2)) == null) continue;
            arrayList.add(new TargetResult(entityLivingBase, vec3d, d));
        }
        if (!arrayList.isEmpty()) {
            arrayList.sort(Comparator.comparingDouble(TargetResult::getDistance));
            return (TargetResult)arrayList.get(0);
        }
        return null;
    }

    public double getDistance(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d.xCoord - vec3d2.xCoord;
        double d2 = vec3d.yCoord - vec3d2.yCoord;
        double d3 = vec3d.zCoord - vec3d2.zCoord;
        return d * d + d2 * d2 + d3 * d3;
    }

    public boolean fov(Entity entity, float f) {
        f = (float)((double)f * 0.5);
        double d = ((double)(Minecraft.getMinecraft().player.rotationYaw - this.fovToEntity(entity)) % 360.0 + 540.0) % 360.0 - 180.0;
        return d >= 0.0 && d <= (double)f || (double)(-f) <= d && d <= 0.0;
    }

    public float fovToEntity(Entity entity) {
        double d = entity.posX - Minecraft.getMinecraft().player.posX;
        double d2 = entity.posZ - Minecraft.getMinecraft().player.posZ;
        double d3 = Math.atan2(d, d2) * 57.2957795;
        return (float)(d3 * -1.0);
    }

    static {
        accuracy = new NumberSetting("Accuracy", 0.15f, 0.1f, 0.3f, 0.01f);
        fov = new NumberSetting("Radius", 100.0f, 10.0f, 360.0f, 1.0f);
        maxDistance = new NumberSetting("Distance", 100.0f, 1.0f, 300.0f, 1.0f);
        renderFirePos = new BooleanSetting("HitMarker", true);
    }
}
