package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;

@ModuleAnnotation(name="TriggerBot", category=Category.COMBAT)
public class TriggerBot
extends Module {
    private final Minecraft mc = Minecraft.getMinecraft();
    public BooleanSetting jump = new BooleanSetting("\u0410\u0432\u0442\u043e-\u043f\u0440\u044b\u0436\u043e\u043a", false);
    public BooleanSetting mobs = new BooleanSetting("\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0430", true);
    public BooleanSetting players = new BooleanSetting("\u0418\u0433\u0440\u043e\u043a\u0438", true);

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (this.mc.objectMouseOver == null || this.mc.objectMouseOver.typeOfHit != RayTraceResult.Type.ENTITY) {
            return;
        }
        Entity entity = this.mc.objectMouseOver.entityHit;
        if (this.isValidTarget(entity)) {
            this.attack(entity);
            if (this.jump.get() && this.mc.player.onGround) {
                this.mc.player.jump();
            }
        }
    }

    private boolean isValidTarget(Entity entity) {
        if (!(entity instanceof EntityLivingBase)) {
            return false;
        }
        if (entity == this.mc.player) {
            return false;
        }
        if (this.mc.player.getDistanceToEntity(entity) > 3.0f) {
            return false;
        }
        if (((EntityLivingBase)entity).getHealth() <= 0.0f) {
            return false;
        }
        boolean bl = entity instanceof EntityPlayer;
        if (bl && !this.players.get()) {
            return false;
        }
        return bl || this.mobs.get();
    }

    private void attack(Entity entity) {
        if (this.mc.player.getCooledAttackStrength(0.0f) < 1.0f) {
            return;
        }
        this.mc.playerController.attackEntity(this.mc.player, entity);
        this.mc.player.swingArm(EnumHand.MAIN_HAND);
    }
}
