package starclient.alpha.module.impl.combat;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public class TargetResult {
    private final EntityLivingBase target;
    private final Vec3d pos;
    private final double distance;

    public TargetResult(EntityLivingBase entityLivingBase, Vec3d vec3d, double d) {
        this.target = entityLivingBase;
        this.pos = vec3d;
        this.distance = d;
    }

    public EntityLivingBase getTarget() {
        return this.target;
    }

    public Vec3d getPos() {
        return this.pos;
    }

    public double getDistance() {
        return this.distance;
    }
}
