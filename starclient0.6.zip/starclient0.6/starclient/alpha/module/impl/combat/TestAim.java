package starclient.alpha.module.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.AnimationUtils;
import starclient.alpha.event.player.EventSwingArm;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.TimerUtils;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.math.CombatUtils;
import starclient.alpha.utility.math.MathUtility;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="AimBot-TEST", category=Category.COMBAT)
public class TestAim
extends Module {
    public TimerUtils shootDelay = new TimerUtils();
    public AnimationUtils[] pointAnim = new AnimationUtils[]{new AnimationUtils(0.0f, 0.0f, 0.1f), new AnimationUtils(0.0f, 0.0f, 0.1f), new AnimationUtils(0.0f, 0.0f, 0.1f)};
    public float tick = 0.0f;
    public static float xPredict;
    public static float yPredict;
    public BooleanSetting silent = new BooleanSetting("Silent", true);
    public static BooleanSetting prediction;
    public BooleanSetting show_prediction = new BooleanSetting("Show-prediction", false);
    public BooleanSetting auto_shoot = new BooleanSetting("Auto-shoot", false);
    public static BooleanSetting fov;
    public BooleanSetting auto_predict = new BooleanSetting("Auto-predict", false);
    public static BooleanSetting smart_hitbox;
    public NumberSetting shoot_delay = new NumberSetting("Shoot-delay", 0.5f, 0.1f, 1.0f, 0.1f, () -> this.auto_shoot.get());
    public static NumberSetting fov_range;
    public static NumberSetting no_fov_distance;
    public NumberSetting predict = new NumberSetting("Predict", 6.0f, 0.0f, 20.0f, 0.01f, () -> !this.auto_predict.get());
    public static NumberSetting y_priority;
    public static NumberSetting points_h;
    public static NumberSetting points_v;
    public static boolean ishandcontainbow;

    @EventTarget
    public void on3D(EventRender3D eventRender3D) {
        float f;
        EntityLivingBase entityLivingBase = CombatUtils.target;
        if (TestAim.mc.player == null || TestAim.mc.world == null || entityLivingBase == null || !this.show_prediction.get()) {
            return;
        }
        float f2 = f = ishandcontainbow ? this.getBowOffset(entityLivingBase) : 0.0f;
        if (CombatUtils.hitBoxResult != null) {
            this.pointAnim[0].to = (float)CombatUtils.hitBoxResult.xCoord;
            this.pointAnim[1].to = (float)CombatUtils.hitBoxResult.yCoord + f;
            this.pointAnim[2].to = (float)CombatUtils.hitBoxResult.zCoord;
        } else {
            Vec3d vec3d = CombatUtils.getAimPos(entityLivingBase, false, xPredict, yPredict);
            this.pointAnim[0].to = (float)vec3d.xCoord;
            this.pointAnim[1].to = (float)vec3d.yCoord + f;
            this.pointAnim[2].to = (float)vec3d.zCoord;
        }
        this.drawPoint(new Vec3d(this.pointAnim[0].getAnim(), this.pointAnim[1].getAnim(), this.pointAnim[2].getAnim()));
    }

    @EventTarget
    public void onSwing(EventSwingArm eventSwingArm) {
        if (TestAim.mc.player == null || TestAim.mc.world == null) {
            return;
        }
        this.shootDelay.reset();
    }

    @EventTarget
    public void onTick(EventUpdate eventUpdate) {
        boolean bl = this.auto_shoot.get();
        float f = this.shoot_delay.get();
        EntityLivingBase entityLivingBase = CombatUtils.target;
        boolean bl2 = ishandcontainbow = MathUtility.inRange(440, 459, TestAim.mc.player.getHeldItemMainhand().itemDamage) || MathUtility.inRange(470, 479, TestAim.mc.player.getHeldItemMainhand().itemDamage);
        if (TestAim.mc.player == null || TestAim.mc.world == null || entityLivingBase == null) {
            return;
        }
        if (this.auto_predict.get()) {
            try {
                xPredict = (float)((double)mc.getConnection().getPlayerInfo(TestAim.mc.player.getUniqueID()).getResponseTime() / 19.23076923076923);
            }
            catch (Exception exception) {
                xPredict = this.predict.get();
            }
        } else {
            xPredict = this.predict.get();
        }
        yPredict = entityLivingBase.fallDistance > 0.0f ? (xPredict += ishandcontainbow ? TestAim.mc.player.getDistanceToEntity(entityLivingBase) / 5.0f : 0.0f) / 2.0f : 0.0f;
        this.aim(entityLivingBase);
        if (bl && this.shootDelay.hasReached((int)(f * 1000.0f))) {
            this.shoot(entityLivingBase);
        }
    }

    public void aim(EntityLivingBase entityLivingBase) {
        float[] fArray = this.getPredictRotation(entityLivingBase);
        float f = fArray[0];
        float f2 = fArray[1];
        if (this.silent.get()) {
            TestAim.mc.player.rotationYawHead = f;
            TestAim.mc.player.rotationPitchHead = f2;
            TestAim.mc.player.renderYawOffset = TestAim.mc.player.rotationYawHead;
            TestAim.mc.player.rotationPitchHead = MathUtility.clamp(TestAim.mc.player.rotationPitchHead, -90.0f, 90.0f);
        } else {
            TestAim.mc.player.rotationYaw = f;
            TestAim.mc.player.rotationPitch = f2;
        }
    }

    public void shoot(EntityLivingBase entityLivingBase) {
        TestAim.mc.playerController.clickBlock(new BlockPos(TestAim.mc.player.posX, TestAim.mc.player.posY + 1.0, TestAim.mc.player.posZ), EnumFacing.UP);
        TestAim.mc.player.swingArm(EnumHand.MAIN_HAND);
    }

    public float[] getPredictRotation(Entity entity) {
        return CombatUtils.rotationsPro(entity, true, smart_hitbox.get(), true, ishandcontainbow ? this.getBowOffset(entity) : 0.0f, xPredict, yPredict);
    }

    public float getBowOffset(Entity entity) {
        double d = Math.abs(TestAim.mc.player.posY - entity.posY) * Math.abs(TestAim.mc.player.posY - entity.posY) / 36.0;
        return (float)((double)(TestAim.mc.player.getDistanceToEntity(entity) * TestAim.mc.player.getDistanceToEntity(entity)) / 1980.0 + (ishandcontainbow ? d : 0.0));
    }

    @EventTarget
    public void onRender2d(EventRender2D eventRender2D) {
        if (!fov.get()) {
            return;
        }
        EntityLivingBase entityLivingBase = CombatUtils.target;
        float f = fov_range.get() * 5.0f - 5.0f;
        int n = new Color(255, 255, 255).getRGB();
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        RenderUtility.drawFov(scaledResolution.getScaledWidth() / 2, scaledResolution.getScaledHeight() / 2, f, 1, n);
    }

    public void drawPoint(Vec3d vec3d) {
        int n = 2;
        double[] dArray = new double[]{vec3d.xCoord - TestAim.mc.getRenderManager().viewerPosX, vec3d.yCoord - TestAim.mc.getRenderManager().viewerPosY, vec3d.zCoord - TestAim.mc.getRenderManager().viewerPosZ};
        float f = 5.0f;
        GlStateManager.disableDepth();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2832);
        GL11.glLineWidth((float)f);
        GL11.glPointSize((float)10.0f);
        GL11.glPushMatrix();
        int n2 = ScaledResolution.getScaleFactor();
        double d = (double)n2 / Math.pow(n2, 2.0);
        GL11.glTranslated((double)dArray[0], (double)dArray[1], (double)dArray[2]);
        GlStateManager.rotate(-TestAim.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(TestAim.mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
        GL11.glScaled((double)d, (double)d, (double)0.0);
        RenderUtility.glColor(Integer.MIN_VALUE);
        GL11.glBegin((int)n);
        GL11.glVertex3d((double)-0.05f, (double)-0.05f, (double)0.0);
        GL11.glVertex3d((double)0.05f, (double)0.05f, (double)0.0);
        GL11.glEnd();
        GL11.glBegin((int)n);
        GL11.glVertex3d((double)0.05f, (double)-0.05f, (double)0.0);
        GL11.glVertex3d((double)-0.05f, (double)0.05f, (double)0.0);
        GL11.glEnd();
        RenderUtility.glColor(-1);
        GL11.glLineWidth((float)1.0f);
        GL11.glBegin((int)n);
        GL11.glVertex3d((double)-0.045f, (double)-0.045f, (double)0.0);
        GL11.glVertex3d((double)0.045f, (double)0.045f, (double)0.0);
        GL11.glEnd();
        GL11.glBegin((int)n);
        GL11.glVertex3d((double)0.045f, (double)-0.045f, (double)0.0);
        GL11.glVertex3d((double)-0.045f, (double)0.045f, (double)0.0);
        GL11.glEnd();
        RenderUtility.glColor(-1);
        GL11.glLineWidth((float)1.0f);
        GL11.glPopMatrix();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
    }

    public String getInfo() {
        return String.format("%.2f", Float.valueOf(xPredict));
    }

    static {
        prediction = new BooleanSetting("Prediction", false);
        fov = new BooleanSetting("Fov", true);
        smart_hitbox = new BooleanSetting("Smart-hitbox", false);
        fov_range = new NumberSetting("Fov-range", 90.0f, 20.0f, 180.0f, 1.0f, () -> fov.get());
        no_fov_distance = new NumberSetting("No-fov-distance", 3.0f, 0.0f, 20.0f, 0.5f, () -> fov.get());
        y_priority = new NumberSetting("Y-Priority", 0.95f, 0.0f, 1.0f, 0.01f, () -> smart_hitbox.get());
        points_h = new NumberSetting("Points-h", 6.0f, 1.0f, 10.0f, 1.0f, () -> smart_hitbox.get());
        points_v = new NumberSetting("Points-v", 6.0f, 1.0f, 10.0f, 1.0f, () -> smart_hitbox.get());
        ishandcontainbow = false;
    }
}
