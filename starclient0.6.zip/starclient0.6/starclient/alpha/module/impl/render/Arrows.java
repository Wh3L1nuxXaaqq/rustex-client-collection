package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.move.MoveUtil;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="Arrows", category=Category.RENDER)
public class Arrows
extends Module {
    public float animationStep;
    private float lastYaw;
    private float lastPitch;
    private float animatedYaw;
    private float animatedPitch;
    public static BooleanSetting distance = new BooleanSetting("\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0434\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044e", true);
    public static NumberSetting radius = new NumberSetting("\u041e\u0442\u0441\u0442\u0443\u043f \u043e\u0442 \u043f\u0440\u0438\u0446\u0435\u043b\u0430", 70.0f, 50.0f, 100.0f, 1.0f);
    private final Pattern NAME_REGEX = Pattern.compile("^[A-z\u0410-\u044f0-9_]{3,16}$");

    @EventTarget
    public void onDisplay(EventRender2D eventRender2D) {
        if (Arrows.mc.player == null || Arrows.mc.world == null) {
            return;
        }
        this.animatedYaw = this.fast(this.animatedYaw, Arrows.mc.player.moveStrafing * 10.0f, 5.0f);
        this.animatedPitch = this.fast(this.animatedPitch, Arrows.mc.player.moveForward * 10.0f, 5.0f);
        float f = radius.get();
        if (Arrows.mc.currentScreen instanceof GuiInventory) {
            f += 80.0f;
        }
        if (MoveUtil.isMoving()) {
            f += 10.0f;
        }
        this.animationStep = this.fast(this.animationStep, f, 6.0f);
        if (Arrows.mc.gameSettings.thirdPersonView == 0) {
            for (Entity entity : Arrows.mc.world.loadedEntityList) {
                if (!(entity instanceof EntityPlayer) || entity == Arrows.mc.player || !this.isRealPlayer((EntityPlayer)entity)) continue;
                EntityPlayer entityPlayer = (EntityPlayer)entity;
                double d = entityPlayer.lastTickPosX + (entityPlayer.posX - entityPlayer.lastTickPosX) * (double)mc.getRenderPartialTicks() - Arrows.mc.getRenderManager().renderPosX;
                double d2 = entityPlayer.lastTickPosZ + (entityPlayer.posZ - entityPlayer.lastTickPosZ) * (double)mc.getRenderPartialTicks() - Arrows.mc.getRenderManager().renderPosZ;
                double d3 = MathHelper.cos((float)((double)Arrows.mc.player.rotationYaw * (Math.PI / 180)));
                double d4 = MathHelper.sin((float)((double)Arrows.mc.player.rotationYaw * (Math.PI / 180)));
                double d5 = -(d2 * d3 - d * d4);
                double d6 = -(d * d3 + d2 * d4);
                float f2 = (float)(Math.atan2(d5, d6) * 180.0 / Math.PI);
                double d7 = (double)(this.animationStep * MathHelper.cos((float)Math.toRadians(f2))) + (double)new ScaledResolution(mc).getScaledWidth() / 2.0;
                double d8 = (double)(this.animationStep * MathHelper.sin((float)Math.toRadians(f2))) + (double)new ScaledResolution(mc).getScaledHeight() / 2.0;
                GlStateManager.pushMatrix();
                GlStateManager.disableBlend();
                GL11.glTranslated((double)(d7 += (double)this.animatedYaw), (double)(d8 += (double)this.animatedPitch), (double)0.0);
                GlStateManager.rotate(f2, 0.0f, 0.0f, 1.0f);
                int n = StarClient.getInstance().getFriendManager().isFriend(entityPlayer.getName()) ? new Color(55, 255, 55).getRGB() : StarClient.getInstance().getC(0).getRGB();
                Arrows.drawTriangle(-4.0f, -1.0f, 5.0f, 8.0f, new Color(0, 0, 0, 32));
                Arrows.drawTriangle(-3.0f, 0.0f, 4.0f, 6.0f, new Color(n));
                GlStateManager.enableBlend();
                GlStateManager.popMatrix();
                if (!distance.get()) continue;
                double d9 = Arrows.mc.player.getDistance(entityPlayer);
                String string = String.format("%.0fm", d9);
                float f3 = (float)d7 - (float)Fonts.nunitoBold16.getStringWidth(string) / 2.0f;
                float f4 = (float)d8 + 10.0f;
                Fonts.nunitoBold16.drawStringWithShadow(string, f3, f4, Color.WHITE.getRGB());
            }
        }
        this.lastYaw = Arrows.mc.player.rotationYaw;
        this.lastPitch = Arrows.mc.player.rotationPitch;
    }

    private boolean isRealPlayer(EntityPlayer entityPlayer) {
        UUID uUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + entityPlayer.getName()).getBytes(StandardCharsets.UTF_8));
        return entityPlayer.getUniqueID().equals(uUID);
    }

    public static void drawTriangle(float f, float f2, float f3, float f4, Color color) {
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        Arrows.enableSmoothLine(1.0f);
        GL11.glRotatef((float)270.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glBegin((int)9);
        ColorUtility.setColor(color.getRGB());
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glEnd();
        GL11.glBegin((int)9);
        ColorUtility.setColor(color.brighter().getRGB());
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3 * 2.0f), (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glEnd();
        GL11.glBegin((int)3);
        ColorUtility.setColor(color.getRGB());
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glEnd();
        GL11.glBegin((int)3);
        ColorUtility.setColor(color.brighter().getRGB());
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3 * 2.0f), (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glEnd();
        Arrows.disableSmoothLine();
        GL11.glEnable((int)3553);
        GL11.glRotatef((float)-270.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static void enableSmoothLine(float f) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
    }

    private static void disableSmoothLine() {
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4354);
    }

    public float fast(float f, float f2, float f3) {
        return (1.0f - MathHelper.clamp((float)(this.deltaTime() * (double)f3), 0.0f, 1.0f)) * f + MathHelper.clamp((float)(this.deltaTime() * (double)f3), 0.0f, 1.0f) * f2;
    }

    public double deltaTime() {
        return Minecraft.getDebugFPS() > 0 ? 1.0 / (double)Minecraft.getDebugFPS() : 1.0;
    }
}
