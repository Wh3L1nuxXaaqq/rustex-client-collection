package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.vecmath.Vector4d;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.impl.render.Trails;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.math.MathUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.AnimationMath;

@ModuleAnnotation(name="Particles", category=Category.RENDER)
public class Particles
extends Module {
    public ModeSetting type = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "\u041a\u0440\u0435\u0441\u0442\u0438\u043a\u0438", "\u041a\u0440\u0435\u0441\u0442\u0438\u043a\u0438", "\u041a\u0440\u0443\u0433\u0438");
    public NumberSetting count = new NumberSetting("\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e", 3.0f, 1.0f, 50.0f, 1.0f);
    public List<Point> pointList = new ArrayList<Point>();
    public ArrayList<Trails.Point> p = new ArrayList();

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketTitle sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket();
        String string = sPacketTitle.getMessage().getUnformattedText();
        EntityLivingBase entityLivingBase = AimBot.lastTarget.getTarget();
        if (string.contains("HP)")) {
            int n = 0;
            while ((float)n < this.count.get()) {
                this.pointList.add(new Point(entityLivingBase.posX, entityLivingBase.posY, entityLivingBase.posZ));
                ++n;
            }
        }
    }

    @EventTarget
    public void onDisplay(EventRender2D eventRender2D) {
        this.pointList.removeIf(point -> System.currentTimeMillis() - point.time > 4410L);
        for (Point point2 : this.pointList) {
            point2.updatePhysics();
            double d = point2.x;
            double d2 = point2.y + 1.0;
            double d3 = point2.z;
            double d4 = 0.0;
            double d5 = 0.0;
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB(d - d4, d2, d3 - d4, d + d4, d2 + d5, d3 + d4);
            List<Vec3d> list = Arrays.asList(new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ));
            Particles.mc.entityRenderer.setupCameraTransform(mc.getRenderPartialTicks(), 0);
            ScaledResolution scaledResolution = eventRender2D.getResolution();
            Vector4d vector4d = null;
            for (Vec3d vec3d : list) {
                vec3d = RenderUtility.vectorTo2D(2, vec3d.x - Particles.mc.getRenderManager().renderPosX, vec3d.y - Particles.mc.getRenderManager().renderPosY, vec3d.z - Particles.mc.getRenderManager().renderPosZ);
                if (vec3d == null || !(vec3d.z > 0.0) || !(vec3d.z < 1.0)) continue;
                if (vector4d == null) {
                    vector4d = new Vector4d(vec3d.x, vec3d.y, vec3d.z, 0.0);
                }
                vector4d.x = Math.min(vec3d.x, vector4d.x);
                vector4d.y = Math.min(vec3d.y, vector4d.y);
                vector4d.z = Math.max(vec3d.x, vector4d.z);
                vector4d.w = Math.max(vec3d.y, vector4d.w);
            }
            if (vector4d != null) {
                Color color;
                float f;
                Particles.mc.entityRenderer.setupOverlayRendering(2);
                double d6 = vector4d.x;
                double d7 = vector4d.y;
                if (this.type.is("\u041a\u0440\u0435\u0441\u0442\u0438\u043a\u0438")) {
                    f = (float)(5000L - (System.currentTimeMillis() - point2.time)) / 5000.0f;
                    color = new Color(StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getRed(), StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getGreen(), StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getBlue(), (int)(f * 255.0f));
                    RenderUtility.drawFixedGlow((float)(d6 - 3.0), (float)(d7 - 3.0), 7.0f, 7.0f, 15, color.getRGB());
                    RenderUtility.drawLine(d6 - 2.0, d7 - 2.0, d6 + 4.0, d7 + 4.0, 3.0f, color.getRGB());
                    RenderUtility.drawLine(d6 + 4.0, d7 - 2.0, d6 - 2.0, d7 + 4.0, 3.0f, color.getRGB());
                }
                if (this.type.is("\u041a\u0440\u0443\u0433\u0438")) {
                    f = (float)(5000L - (System.currentTimeMillis() - point2.time)) / 5000.0f;
                    color = new Color(StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getRed(), StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getGreen(), StarClient.getInstance().getC(this.pointList.indexOf(point2) * 10).getBlue(), (int)(f * 128.0f));
                    RenderUtility.drawGlow((float)(d6 - 6.5), (float)(d7 - 6.5), 6.0f, 6.0f, 6, color.getRGB());
                    RenderUtility.drawRoundCircle((float)(d6 - 3.0), (float)(d7 - 3.0), 5.0f, 5.0f, color.getRGB());
                }
            }
            GlStateManager.enableBlend();
            Particles.mc.entityRenderer.setupOverlayRendering();
        }
    }

    public class Point {
        double x;
        double y;
        double z;
        double motionX;
        double motionY;
        double motionZ;
        long time;

        public Point(double d, double d2, double d3) {
            this.x = d;
            this.y = d2;
            this.z = d3;
            this.time = System.currentTimeMillis();
            this.motionX = MathUtility.randomizeFloat(-0.01f, 0.01f);
            this.motionY = MathUtility.randomizeFloat(-0.01f, 0.01f);
            this.motionZ = MathUtility.randomizeFloat(-0.01f, 0.01f);
        }

        public void updatePhysics() {
            if (Utility.mc.world.getBlockState(new BlockPos(this.x, this.y + 1.0, this.z)).getBlock() != Blocks.AIR) {
                this.motionY += (double)0.001f;
                this.motionX *= (double)1.1f;
                this.motionZ *= (double)1.1f;
            } else {
                this.motionY -= 5.0E-5;
            }
            this.motionX = AnimationMath.fast((float)this.motionX, 0.0f, 1.0f);
            this.motionY = AnimationMath.fast((float)this.motionY, 0.0f, 1.0f);
            this.motionZ = AnimationMath.fast((float)this.motionZ, 0.0f, 1.0f);
            this.x += this.motionX;
            this.y += this.motionY;
            this.z += this.motionZ;
        }
    }
}
