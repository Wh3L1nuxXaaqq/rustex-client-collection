package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.jhlabs.vecmath.Vector4f;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.impl.combat.AimBotDayz;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.AnimationMath;

@ModuleAnnotation(name="Target ESP", category=Category.RENDER)
public class TargetESP
extends Module {
    public ModeSetting mode = new ModeSetting("\u041c\u043e\u0434", "\u041e\u0431\u044b\u0447\u043d\u044b\u0439", "\u041e\u0431\u044b\u0447\u043d\u044b\u0439", "\u041d\u043e\u0432\u044b\u0439", "\u041a\u0432\u0430\u0434\u0440\u0430\u0442");
    public NumberSetting circleSpeed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 2.0f, 1.0f, 10.0f, 0.1f);
    public NumberSetting size1 = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440", 50.0f, 20.0f, 200.0f, 1.0f);
    public static double prevCircleStep;
    public static double circleStep;
    private EntityLivingBase currentTarget = null;

    public TargetESP() {
        this.size1.setVisible(() -> this.mode.is("\u041d\u043e\u0432\u044b\u0439") || this.mode.is("\u041a\u0432\u0430\u0434\u0440\u0430\u0442"));
        this.circleSpeed.setVisible(() -> this.mode.is("\u041e\u0431\u044b\u0447\u043d\u044b\u0439"));
    }

    @EventTarget
    public void onRender(EventRender3D eventRender3D) {
        if (this.mode.get().equals("\u041e\u0431\u044b\u0447\u043d\u044b\u0439")) {
            EntityLivingBase entityLivingBase = null;
            if (AimBotDayz.target != null) {
                entityLivingBase = AimBotDayz.target.getTarget();
            } else if (AimBot.target != null) {
                entityLivingBase = AimBot.target.getTarget();
            }
            if (entityLivingBase != null) {
                Color color;
                int n;
                prevCircleStep = circleStep;
                circleStep += (double)this.circleSpeed.get() * AnimationMath.deltaTime();
                float f = entityLivingBase.getEyeHeight();
                if (entityLivingBase.isSneaking()) {
                    f -= 0.2f;
                }
                double d = prevCircleStep + (circleStep - prevCircleStep) * (double)mc.getRenderPartialTicks();
                double d2 = Math.abs(1.0 + Math.sin(d - 0.5)) / 2.0;
                double d3 = Math.abs(1.0 + Math.sin(d)) / 2.0;
                double d4 = entityLivingBase.lastTickPosX + (entityLivingBase.posX - entityLivingBase.lastTickPosX) * (double)mc.getRenderPartialTicks() - TargetESP.mc.getRenderManager().renderPosX;
                double d5 = entityLivingBase.lastTickPosY + (entityLivingBase.posY - entityLivingBase.lastTickPosY) * (double)mc.getRenderPartialTicks() - TargetESP.mc.getRenderManager().renderPosY + d2 * (double)f;
                double d6 = entityLivingBase.lastTickPosZ + (entityLivingBase.posZ - entityLivingBase.lastTickPosZ) * (double)mc.getRenderPartialTicks() - TargetESP.mc.getRenderManager().renderPosZ;
                double d7 = entityLivingBase.lastTickPosY + (entityLivingBase.posY - entityLivingBase.lastTickPosY) * (double)mc.getRenderPartialTicks() - TargetESP.mc.getRenderManager().renderPosY + d3 * (double)f;
                GL11.glPushMatrix();
                GL11.glDisable((int)2884);
                GL11.glDisable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)3008);
                GL11.glShadeModel((int)7425);
                GL11.glBegin((int)8);
                for (n = 0; n <= 360; ++n) {
                    color = Arraylist.getColor(n);
                    GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)5.6f);
                    GL11.glVertex3d((double)(d4 + Math.cos(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8), (double)d7, (double)(d6 + Math.sin(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8));
                    GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.01f);
                    GL11.glVertex3d((double)(d4 + Math.cos(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8), (double)d5, (double)(d6 + Math.sin(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8));
                }
                GL11.glEnd();
                GL11.glEnable((int)2848);
                GL11.glBegin((int)2);
                for (n = 0; n <= 360; ++n) {
                    color = Arraylist.getColor(n);
                    GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.8f);
                    GL11.glVertex3d((double)(d4 + Math.cos(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8), (double)d7, (double)(d6 + Math.sin(Math.toRadians(n)) * (double)entityLivingBase.width * 0.8));
                }
                GL11.glEnd();
                GL11.glDisable((int)2848);
                GL11.glEnable((int)3553);
                GL11.glEnable((int)3008);
                GL11.glEnable((int)2929);
                GL11.glShadeModel((int)7424);
                GL11.glDisable((int)3042);
                GL11.glEnable((int)2884);
                GL11.glPopMatrix();
                GlStateManager.resetColor();
            }
        }
    }

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        EntityLivingBase entityLivingBase = null;
        if (AimBotDayz.target != null) {
            entityLivingBase = AimBotDayz.target.getTarget();
        } else if (AimBot.target != null) {
            entityLivingBase = AimBot.target.getTarget();
        }
        if (entityLivingBase != null && RenderUtility.isInViewFrustum(entityLivingBase)) {
            double d = entityLivingBase.lastTickPosX + (entityLivingBase.posX - entityLivingBase.lastTickPosX) * (double)mc.getRenderPartialTicks();
            double d2 = entityLivingBase.lastTickPosY + (entityLivingBase.posY - entityLivingBase.lastTickPosY) * (double)mc.getRenderPartialTicks();
            double d3 = entityLivingBase.lastTickPosZ + (entityLivingBase.posZ - entityLivingBase.lastTickPosZ) * (double)mc.getRenderPartialTicks();
            double d4 = entityLivingBase.width / 2.0f;
            double d5 = entityLivingBase.height / 1.5f;
            float f = this.size1.get();
            Color color = ColorUtility.getColor(30);
            Color color2 = ColorUtility.getColor(180);
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB(d - d4, d2 + d5, d3 - d4, d + d4, d2 + d5, d3 + d4);
            Vec3d[] vec3dArray = new Vec3d[]{new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ)};
            TargetESP.mc.entityRenderer.setupCameraTransform(eventRender2D.getPartialTicks(), 0);
            Vector4f vector4f = null;
            for (Vec3d vec3d : vec3dArray) {
                vec3d = RenderUtility.project2D(2, vec3d.x - TargetESP.mc.getRenderManager().viewerPosX, vec3d.y - TargetESP.mc.getRenderManager().viewerPosY, vec3d.z - TargetESP.mc.getRenderManager().viewerPosZ);
                if (vec3d == null || !(vec3d.z >= 0.0) || !(vec3d.z < 1.0)) continue;
                if (vector4f == null) {
                    vector4f = new Vector4f((float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 1.0f);
                }
                vector4f.x = (float)Math.min(vec3d.x, (double)vector4f.x);
                vector4f.y = (float)Math.min(vec3d.y, (double)vector4f.y);
                vector4f.z = (float)Math.max(vec3d.x, (double)vector4f.z);
                vector4f.w = (float)Math.max(vec3d.y, (double)vector4f.w);
            }
            if (vector4f != null) {
                TargetESP.mc.entityRenderer.setupOverlayRendering(2);
                double d6 = vector4f.x;
                double d7 = vector4f.y;
                double d8 = vector4f.z;
                double d9 = vector4f.w;
                double d10 = d6 + (d8 - d6) / 2.0;
                double d11 = d7 + (d9 - d7) / 2.0;
                GL11.glPushMatrix();
                GL11.glTranslated((double)d10, (double)d11, (double)0.0);
                GL11.glRotated((double)(Math.sin(Math.toRadians((double)System.currentTimeMillis() / 15.0)) * 360.0), (double)0.0, (double)0.0, (double)1.0);
                GL11.glTranslated((double)(-d10), (double)(-d11), (double)0.0);
                if (this.mode.is("\u041a\u0432\u0430\u0434\u0440\u0430\u0442")) {
                    RenderUtility.applyGradientMask((float)(d10 - (double)(f / 2.0f)), (float)(d11 - (double)(f / 2.0f)), f, f, 0.8f, color, color, color, color, () -> RenderUtility.drawImage(new ResourceLocation("starclient/textures/target.png"), (float)(d10 - (double)(f / 2.0f)), (float)(d11 - (double)(f / 2.0f)), f, f));
                } else if (this.mode.is("\u041d\u043e\u0432\u044b\u0439")) {
                    RenderUtility.applyGradientMask((float)(d10 - (double)(f / 2.0f)), (float)(d11 - (double)(f / 2.0f)), f, f, 0.8f, color, color, color, color, () -> RenderUtility.drawImage(new ResourceLocation("starclient/textures/target2.png"), (float)(d10 - (double)(f / 2.0f)), (float)(d11 - (double)(f / 2.0f)), f, f));
                }
                GL11.glPopMatrix();
                GlStateManager.disableBlend();
                TargetESP.mc.entityRenderer.setupOverlayRendering();
            }
        }
    }
}
