package starclient.alpha.module.impl.render;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="Wings", category=Category.PLAYER)
public class Wings
extends Module {
    public static NumberSetting scale = new NumberSetting("Scale", 1.0f, 0.75f, 1.5f, 0.25f);
}
