package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.AntiAliasingUtility;

@ModuleAnnotation(name="ChinaHat", category=Category.PLAYER)
public class ChinaHat
extends Module {
    public BooleanSetting outline = new BooleanSetting("\u041e\u0431\u0432\u043e\u0434\u043a\u0430", true);
    public NumberSetting lineWidth = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440 \u043e\u0431\u0432\u043e\u0434\u043a\u0438", 1.0f, 0.1f, 5.0f, 0.1f, () -> this.outline.get());

    @EventTarget
    public void onRender(EventRender3D eventRender3D) {
        if (ChinaHat.mc.gameSettings.thirdPersonView != 0 && ChinaHat.mc.player.isEntityAlive()) {
            Color color;
            double d;
            double d2;
            int n;
            double d3 = -(ChinaHat.mc.player.lastTickPosX + (ChinaHat.mc.player.posX - ChinaHat.mc.player.lastTickPosX) * (double)eventRender3D.getPartialTicks());
            double d4 = -(ChinaHat.mc.player.lastTickPosY + (ChinaHat.mc.player.posY - ChinaHat.mc.player.lastTickPosY) * (double)eventRender3D.getPartialTicks());
            double d5 = -(ChinaHat.mc.player.lastTickPosZ + (ChinaHat.mc.player.posZ - ChinaHat.mc.player.lastTickPosZ) * (double)eventRender3D.getPartialTicks());
            float f = (float)(ChinaHat.mc.player.lastTickPosX + (ChinaHat.mc.player.posX - ChinaHat.mc.player.lastTickPosX) * (double)eventRender3D.getPartialTicks());
            float f2 = (float)(ChinaHat.mc.player.lastTickPosY + (ChinaHat.mc.player.posY - ChinaHat.mc.player.lastTickPosY) * (double)eventRender3D.getPartialTicks()) + ChinaHat.mc.player.height + 0.01f - (ChinaHat.mc.player.isSneaking() ? 0.2f : 0.0f);
            float f3 = (float)(ChinaHat.mc.player.lastTickPosZ + (ChinaHat.mc.player.posZ - ChinaHat.mc.player.lastTickPosZ) * (double)eventRender3D.getPartialTicks());
            GlStateManager.pushMatrix();
            GL11.glDepthMask((boolean)false);
            GlStateManager.enableDepth();
            GL11.glRotatef((float)(-ChinaHat.mc.player.rotationYaw), (float)0.0f, (float)1.0f, (float)0.0f);
            ChinaHat.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 2);
            GlStateManager.translate(d3, d4, d5);
            GlStateManager.enableBlend();
            GL11.glBlendFunc((int)770, (int)771);
            GlStateManager.disableTexture2D();
            GL11.glDisable((int)2884);
            GL11.glShadeModel((int)7425);
            GL11.glDisable((int)3008);
            AntiAliasingUtility.hook(true, false, false);
            GlStateManager.alphaFunc(516, 0.0f);
            GL11.glBegin((int)6);
            Color color2 = Arraylist.getColor(1);
            GL11.glColor4f((float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)0.39215687f);
            GL11.glVertex3f((float)f, (float)(f2 + 0.35f), (float)f3);
            for (n = 0; n <= 360; ++n) {
                d2 = Math.cos((double)n * Math.PI / 180.0) * 0.66;
                d = Math.sin((double)n * Math.PI / 180.0) * 0.66;
                color = Arraylist.getColor(n);
                GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.39215687f);
                GL11.glVertex3d((double)((double)f + d2), (double)f2, (double)((double)f3 + d));
            }
            GL11.glEnd();
            if (this.outline.get()) {
                GL11.glLineWidth((float)this.lineWidth.get());
                GL11.glBegin((int)2);
                for (n = 0; n <= 360; ++n) {
                    d2 = Math.cos((double)n * Math.PI / 180.0) * 0.66;
                    d = Math.sin((double)n * Math.PI / 180.0) * 0.66;
                    color = Arraylist.getColor(n);
                    GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)1.0f);
                    GL11.glVertex3d((double)((double)f + d2), (double)f2, (double)((double)f3 + d));
                }
                GL11.glEnd();
            }
            AntiAliasingUtility.unhook(true, false, false);
            GL11.glEnable((int)3008);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GL11.glEnable((int)2884);
            ChinaHat.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 0);
            GlStateManager.resetColor();
            GL11.glDepthMask((boolean)true);
            GlStateManager.popMatrix();
        }
    }
}
