package starclient.alpha.module.impl.render;

import java.awt.Color;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="FogColor", category=Category.RENDER)
public class FogColor
extends Module {
    public static ColorSetting color = new ColorSetting("Color", Color.WHITE.getRGB());
    public static NumberSetting distance = new NumberSetting("Fog Distance", 1.0f, 0.2f, 1.5f, 0.01f);
}
