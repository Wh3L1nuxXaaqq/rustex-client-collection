package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="Crosshair", category=Category.RENDER)
public class Crosshair
extends Module {
    public ModeSetting type = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "Cross", "Cross", "\u0422\u043e\u0447\u043a\u0430", "Swastika");
    public BooleanSetting cooldown = new BooleanSetting("\u041a\u0443\u043b\u0434\u0430\u0443\u043d", true);
    public BooleanSetting highlightEntities = new BooleanSetting("\u042d\u043d\u0442\u0438\u0442\u0438", true);
    public BooleanSetting tShaped = new BooleanSetting("\u0422-\u043e\u0431\u0440\u0430\u0437\u043d\u044b\u0439", false);
    public NumberSetting radius = new NumberSetting("\u0420\u0430\u0434\u0438\u0443\u0441", 3.0f, 3.0f, 6.0f, 0.5f);
    public NumberSetting razmer = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440", 2.0f, 2.0f, 4.0f, 0.5f);

    public Crosshair() {
        this.cooldown.setVisible(() -> this.type.is("Cross"));
        this.tShaped.setVisible(() -> this.type.is("Cross"));
        this.radius.setVisible(() -> this.type.is("Cross"));
        this.razmer.setVisible(() -> this.type.is("\u0422\u043e\u0447\u043a\u0430"));
    }

    @EventTarget
    public void onRender(EventRender2D eventRender2D) {
        if (Crosshair.mc.player == null || Crosshair.mc.gameSettings.thirdPersonView != 0) {
            return;
        }
        int n = this.highlightEntities.get() && Crosshair.mc.objectMouseOver != null && Crosshair.mc.objectMouseOver.typeOfHit == RayTraceResult.Type.ENTITY ? Color.RED.getRGB() : Color.WHITE.getRGB();
        float f = (float)eventRender2D.getResolution().getScaledWidth() / 2.0f;
        float f2 = (float)eventRender2D.getResolution().getScaledHeight() / 2.0f;
        if (this.type.is("Swastika")) {
            this.drawSwastika(f, f2, n);
        } else if (this.type.is("Cross")) {
            this.drawCross(f, f2, n);
        } else if (this.type.is("\u0422\u043e\u0447\u043a\u0430")) {
            this.drawDot(f, f2, n);
        }
    }

    private void drawSwastika(float f, float f2, int n) {
        long l = System.currentTimeMillis() % 3000L;
        float f3 = l < 1500L ? (float)l / 1500.0f * 360.0f : 360.0f - (float)(l - 1500L) / 1500.0f * 360.0f;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)f, (float)f2, (float)0.0f);
        GL11.glRotatef((float)f3, (float)0.0f, (float)0.0f, (float)1.0f);
        float f4 = 8.0f;
        float f5 = 1.0f;
        float f6 = f5 / 2.0f;
        float f7 = f4;
        RenderUtility.drawRect(f6, -f4, f7, f5, n);
        RenderUtility.drawRect(f4 - f5, f6, f5, f7, n);
        RenderUtility.drawRect(-f7, f6 + 6.5f, f7, f5, n);
        RenderUtility.drawRect(-f4, -f4 + f5 - 1.0f, f5, f7, n);
        RenderUtility.drawRect(-f6, -f4, f5, f4 * 2.0f, n);
        RenderUtility.drawRect(-f4, -f6, f4 * 2.0f, f5, n);
        GL11.glPopMatrix();
    }

    private void drawCross(float f, float f2, int n) {
        float f3 = this.radius.get() + (this.cooldown.get() ? (1.0f - Crosshair.mc.player.getCooledAttackStrength(0.5f)) * 10.0f : 0.0f);
        RenderUtility.drawRectWithOutline(f - f3 - 2.0f, f2, 3.0f, 1.0f, n, -16777216);
        RenderUtility.drawRectWithOutline(f + f3, f2, 3.0f, 1.0f, n, -16777216);
        RenderUtility.drawRectWithOutline(f, f2 + f3, 1.0f, 3.0f, n, -16777216);
        RenderUtility.drawRectWithOutline(f, f2, 1.0f, 1.0f, n, -16777216);
        if (!this.tShaped.get()) {
            RenderUtility.drawRectWithOutline(f, f2 - f3 - 2.0f, 1.0f, 3.0f, n, -16777216);
        }
    }

    private void drawDot(float f, float f2, int n) {
        RenderUtility.drawRoundCircle(f, f2, this.razmer.get(), this.razmer.get(), n);
    }
}
