package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.chunk.RenderChunk;
import starclient.alpha.event.render.EventRenderChunk;
import starclient.alpha.event.render.EventRenderChunkContainer;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="ChunkAnimator", category=Category.RENDER)
public class ChunkAnimator
extends Module {
    private final WeakHashMap<RenderChunk, AtomicLong> renderChunkMap = new WeakHashMap();

    private double easeOutCubic(double d) {
        return (d -= 1.0) * d * d + 1.0;
    }

    @EventTarget
    private void onRenderChunk(EventRenderChunk eventRenderChunk) {
        if (ChunkAnimator.mc.player != null && ChunkAnimator.mc.world != null && !this.renderChunkMap.containsKey(eventRenderChunk.getRenderChunk())) {
            this.renderChunkMap.put(eventRenderChunk.getRenderChunk(), new AtomicLong(-1L));
        }
    }

    @EventTarget
    private void onRenderChunkContainer(EventRenderChunkContainer eventRenderChunkContainer) {
        if (this.renderChunkMap.containsKey(eventRenderChunkContainer.getRenderChunk())) {
            long l;
            AtomicLong atomicLong = this.renderChunkMap.get(eventRenderChunkContainer.getRenderChunk());
            long l2 = atomicLong.get();
            if (l2 == -1L) {
                l2 = System.currentTimeMillis();
                atomicLong.set(l2);
            }
            if ((float)(l = System.currentTimeMillis() - l2) <= 600.0f) {
                double d = eventRenderChunkContainer.getRenderChunk().getPosition().getY();
                double d2 = d * this.easeOutCubic((float)l / 600.0f);
                GlStateManager.translate(0.0, -d + d2, 0.0);
            }
        }
    }
}
