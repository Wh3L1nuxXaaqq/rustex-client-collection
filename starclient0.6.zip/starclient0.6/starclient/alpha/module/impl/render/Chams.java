package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;

@ModuleAnnotation(name="Chams", category=Category.PLAYER)
public class Chams
extends Module {
    public static BooleanSetting friends = new BooleanSetting("\u0414\u0440\u0443\u0437\u044c\u044f", false);

    void render(Entity entity, float f) {
        try {
            if (entity == null || entity == Chams.mc.player) {
                return;
            }
            if (entity == mc.getRenderViewEntity() && Chams.mc.gameSettings.thirdPersonView == 0) {
                return;
            }
            Chams.mc.entityRenderer.disableLightmap();
            mc.getRenderManager().renderEntityStatic(entity, f, false);
            Chams.mc.entityRenderer.enableLightmap();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        GlStateManager.clear(256);
        RenderHelper.enableStandardItemLighting();
        for (Entity entity : Chams.mc.world.loadedEntityList) {
            if (!(entity instanceof EntityPlayer) || entity == mc.getRenderViewEntity()) continue;
            if (StarClient.getInstance().getFriendManager().isFriend(entity.getName()) && friends.get()) {
                this.render(entity, mc.getRenderPartialTicks());
                continue;
            }
            this.render(entity, mc.getRenderPartialTicks());
        }
    }
}
