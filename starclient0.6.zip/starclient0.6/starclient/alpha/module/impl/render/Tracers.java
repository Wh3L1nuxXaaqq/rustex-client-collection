package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.AntiAliasingUtility;

@ModuleAnnotation(name="Tracers", category=Category.RENDER)
public class Tracers
extends Module {
    public NumberSetting lineWidth = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440 \u043b\u0438\u043d\u0438\u0438", 1.0f, 0.1f, 2.0f, 0.1f);
    public ColorSetting colorSetting = new ColorSetting("\u0426\u0432\u0435\u0442", Color.WHITE.getRGB());
    public ColorSetting friendColorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u0434\u0440\u0443\u0433\u0430", Color.GREEN.getRGB());

    @EventTarget
    public void onRender(EventRender3D eventRender3D) {
        for (Entity entity : Tracers.mc.world.loadedEntityList) {
            EntityPlayer entityPlayer;
            if (entity == Tracers.mc.player || !(entity instanceof EntityPlayer) || !this.isRealPlayer(entityPlayer = (EntityPlayer)entity)) continue;
            Color color = StarClient.getInstance().getFriendManager().isFriend(entityPlayer.getName()) ? this.friendColorSetting.getColor() : this.colorSetting.getColor();
            double d = entityPlayer.lastTickPosX + (entityPlayer.posX - entityPlayer.lastTickPosX) * (double)mc.getRenderPartialTicks() - Tracers.mc.getRenderManager().renderPosX;
            double d2 = entityPlayer.lastTickPosY + (entityPlayer.posY - entityPlayer.lastTickPosY) * (double)mc.getRenderPartialTicks() - Tracers.mc.getRenderManager().renderPosY;
            double d3 = entityPlayer.lastTickPosZ + (entityPlayer.posZ - entityPlayer.lastTickPosZ) * (double)mc.getRenderPartialTicks() - Tracers.mc.getRenderManager().renderPosZ;
            float f = (float)color.getRed() / 255.0f;
            float f2 = (float)color.getGreen() / 255.0f;
            float f3 = (float)color.getBlue() / 255.0f;
            float f4 = (float)color.getAlpha() / 255.0f;
            GL11.glPushMatrix();
            boolean bl = Tracers.mc.gameSettings.viewBobbing;
            Tracers.mc.gameSettings.viewBobbing = false;
            Tracers.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 2);
            Tracers.mc.gameSettings.viewBobbing = bl;
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)3042);
            GL11.glLineWidth((float)this.lineWidth.get());
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            AntiAliasingUtility.hook(true, false, false);
            GL11.glDepthMask((boolean)false);
            GlStateManager.color(f, f2, f3, f4);
            GL11.glBegin((int)3);
            Vec3d vec3d = new Vec3d(0.0, 0.0, 1.0).rotatePitch((float)(-Math.toRadians(Tracers.mc.player.rotationPitch))).rotateYaw((float)(-Math.toRadians(Tracers.mc.player.rotationYaw)));
            GL11.glVertex3d((double)vec3d.x, (double)(vec3d.y + (double)Tracers.mc.player.getEyeHeight()), (double)vec3d.z);
            GL11.glVertex3d((double)d, (double)d2, (double)d3);
            GL11.glEnd();
            AntiAliasingUtility.unhook(true, false, false);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
            GlStateManager.resetColor();
        }
    }

    private boolean isRealPlayer(EntityPlayer entityPlayer) {
        UUID uUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + entityPlayer.getName()).getBytes(StandardCharsets.UTF_8));
        return entityPlayer.getUniqueID().equals(uUID);
    }
}
