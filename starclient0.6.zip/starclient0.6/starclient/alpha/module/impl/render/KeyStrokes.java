package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import org.lwjgl.input.Keyboard;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.dragging.DragManager;
import starclient.alpha.manager.dragging.Draggable;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="KeyStrokes", category=Category.RENDER)
public class KeyStrokes
extends Module {
    private final Draggable keyStrokes = DragManager.create(this, "keyStrokes", 400, 200);
    private final Draggable KeyStrokesDraggable = DragManager.create(this, "KeyStrokes", 300, 21);
    int width = 20;
    public float realOffset = 0.0f;
    int color = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[0].getRGB();
    int color2 = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[1].getRGB();
    private float wAlpha = 0.0f;
    private float sAlpha = 0.0f;
    private float aAlpha = 0.0f;
    private float dAlpha = 0.0f;
    private float spaceAlpha = 0.0f;

    public KeyStrokes() {
        this.KeyStrokesDraggable.setWidth(65.0f);
        this.KeyStrokesDraggable.setHeight(75.0f);
        this.keyStrokes.setWidth(65.0f);
        this.keyStrokes.setHeight(75.0f);
    }

    @EventTarget
    public void onRender3D(EventRender2D eventRender2D) {
        boolean bl = Keyboard.isKeyDown((int)17);
        boolean bl2 = Keyboard.isKeyDown((int)31);
        boolean bl3 = Keyboard.isKeyDown((int)30);
        boolean bl4 = Keyboard.isKeyDown((int)32);
        boolean bl5 = Keyboard.isKeyDown((int)57);
        boolean bl6 = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
        int n = bl6 ? new Color(30, 30, 30, 100).getRGB() : new Color(255, 255, 255, 75).getRGB();
        Color color = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[1];
        Color color2 = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[0];
        this.wAlpha = bl5 ? Math.min(1.0f, this.wAlpha + 0.05f) : Math.max(0.0f, this.wAlpha - 0.05f);
        this.sAlpha = bl3 ? Math.min(1.0f, this.sAlpha + 0.05f) : Math.max(0.0f, this.sAlpha - 0.05f);
        this.aAlpha = bl4 ? Math.min(1.0f, this.aAlpha + 0.05f) : Math.max(0.0f, this.aAlpha - 0.05f);
        this.dAlpha = bl2 ? Math.min(1.0f, this.dAlpha + 0.05f) : Math.max(0.0f, this.dAlpha - 0.05f);
        this.spaceAlpha = bl ? Math.min(1.0f, this.spaceAlpha + 0.05f) : Math.max(0.0f, this.spaceAlpha - 0.05f);
        RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 54, this.width + 45, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.wAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.wAlpha * 255.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.wAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.wAlpha * 255.0f)));
        RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.sAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.sAlpha * 255.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.sAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.sAlpha * 255.0f)));
        RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 44, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.aAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.aAlpha * 255.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.aAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.aAlpha * 255.0f)));
        RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.dAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.dAlpha * 255.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.dAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.dAlpha * 255.0f)));
        RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 10, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.spaceAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.spaceAlpha * 255.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.spaceAlpha * 255.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.spaceAlpha * 255.0f)));
        RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 10, this.width, 20.0f, 7.0f, n);
        Fonts.tenacityBold18.drawString("W", this.KeyStrokesDraggable.getX() + 27, (float)this.KeyStrokesDraggable.getY() + 16.5f, -1);
        RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n);
        Fonts.tenacityBold18.drawString("S", this.KeyStrokesDraggable.getX() + 30, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
        RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n);
        Fonts.tenacityBold18.drawString("A", this.KeyStrokesDraggable.getX() + 7, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
        RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 44, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n);
        Fonts.tenacityBold18.drawString("D", (float)this.KeyStrokesDraggable.getX() + 51.5f, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
        RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 54, (float)this.width + 45.0f, 20.0f, 7.0f, n);
        Fonts.tenacityBold18.drawCenteredString("SPACE", (float)(this.KeyStrokesDraggable.getX() + this.width) + 13.0f, (float)this.KeyStrokesDraggable.getY() + 60.5f, -1);
    }

    private boolean aBolen() {
        return KeyStrokes.mc.gameSettings.keyBindLeft.isKeyDown();
    }

    private boolean sBolen() {
        return KeyStrokes.mc.gameSettings.keyBindBack.isKeyDown();
    }

    private boolean dBolen() {
        return KeyStrokes.mc.gameSettings.keyBindRight.isKeyDown();
    }

    private boolean wBolen() {
        return KeyStrokes.mc.gameSettings.keyBindForward.isKeyDown();
    }

    private boolean spacBolen() {
        return KeyStrokes.mc.gameSettings.keyBindJump.isKeyDown();
    }

    private boolean mouseBolen() {
        return KeyStrokes.mc.gameSettings.keyBindAttack.isKeyDown();
    }
}
