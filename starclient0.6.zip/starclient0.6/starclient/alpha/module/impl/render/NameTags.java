package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.jhlabs.vecmath.Vector4f;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.lang.invoke.LambdaMetafactory;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.Hud;
import starclient.alpha.module.impl.util.NameProtect;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="NameTags", category=Category.RENDER)
public class NameTags
extends Module {
    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @EventTarget
    public void onRender(EventRender2D var1_1) {
        var2_2 = NameTags.mc.getRenderManager();
        var3_3 = NameTags.mc.entityRenderer;
        var4_4 = NameTags.mc.world.playerEntities.iterator();
        while (true) {
            if (!var4_4.hasNext()) {
                return;
            }
            var5_5 = (EntityPlayer)var4_4.next();
            if (NameTags.mc.player == var5_5 && NameTags.mc.gameSettings.thirdPersonView == 0) continue;
            GlStateManager.pushMatrix();
            if (RenderUtility.isInViewFrustum(var5_5)) {
                block18: {
                    var6_6 = var5_5.lastTickPosX + (var5_5.posX - var5_5.lastTickPosX) * (double)var1_1.getPartialTicks();
                    var8_7 = var5_5.lastTickPosY + (var5_5.posY - var5_5.lastTickPosY) * (double)var1_1.getPartialTicks();
                    var10_8 = var5_5.lastTickPosZ + (var5_5.posZ - var5_5.lastTickPosZ) * (double)var1_1.getPartialTicks();
                    var12_9 = (double)var5_5.width / 1.5;
                    var14_10 = var5_5.height + 0.2f - (var5_5.isSneaking() != false ? 0.2f : 0.0f);
                    var16_11 = new AxisAlignedBB(var6_6 - var12_9, var8_7, var10_8 - var12_9, var6_6 + var12_9, var8_7 + var14_10, var10_8 + var12_9);
                    var17_12 = new Vec3d[]{new Vec3d(var16_11.minX, var16_11.minY, var16_11.minZ), new Vec3d(var16_11.minX, var16_11.maxY, var16_11.minZ), new Vec3d(var16_11.maxX, var16_11.minY, var16_11.minZ), new Vec3d(var16_11.maxX, var16_11.maxY, var16_11.minZ), new Vec3d(var16_11.minX, var16_11.minY, var16_11.maxZ), new Vec3d(var16_11.minX, var16_11.maxY, var16_11.maxZ), new Vec3d(var16_11.maxX, var16_11.minY, var16_11.maxZ), new Vec3d(var16_11.maxX, var16_11.maxY, var16_11.maxZ)};
                    var3_3.setupCameraTransform(var1_1.getPartialTicks(), 0);
                    var18_13 = null;
                    var19_14 = var17_12;
                    var20_15 = var17_12.length;
                    for (var21_16 = 0; var21_16 < var20_15; ++var21_16) {
                        var22_18 = var19_14[var21_16];
                        var22_18 = RenderUtility.project2D(2, var22_18.x - var2_2.viewerPosX, var22_18.y - var2_2.viewerPosY, var22_18.z - var2_2.viewerPosZ);
                        if (var22_18 == null || !(var22_18.z >= 0.0) || !(var22_18.z < 1.0)) continue;
                        if (var18_13 == null) {
                            var18_13 = new Vector4f((float)var22_18.x, (float)var22_18.y, (float)var22_18.z, 1.0f);
                        }
                        var18_13.x = (float)Math.min(var22_18.x, (double)var18_13.x);
                        var18_13.y = (float)Math.min(var22_18.y, (double)var18_13.y);
                        var18_13.z = (float)Math.max(var22_18.x, (double)var18_13.z);
                        var18_13.w = (float)Math.max(var22_18.y, (double)var18_13.w);
                    }
                    if (var18_13 != null) {
                        NameTags.mc.entityRenderer.setupOverlayRendering(2);
                        var21_17 = var18_13.x;
                        var23_19 = var18_13.y;
                        var25_20 = var18_13.z;
                        var27_21 = (float)(var21_17 + (var25_20 - var21_17) / 2.0);
                        var28_22 = StarClient.getInstance().getModuleManager().getModule(NameProtect.class).isEnabled() ? (StarClient.getInstance().getFriendManager().isFriend(var5_5.getName()) || var5_5.getName().equals(NameTags.mc.player.getName()) ? String.valueOf(ChatFormatting.GREEN) + "[F] " + (String)(var5_5.isPotionActive(Potion.getPotionById(2)) != false ? String.valueOf(ChatFormatting.RED) + "[ZOOMED] " + String.valueOf(ChatFormatting.RESET) : "") + String.valueOf(ChatFormatting.RESET) + NameProtect.protectedNick : (String)(var5_5.isPotionActive(Potion.getPotionById(2)) != false ? String.valueOf(ChatFormatting.RED) + "[ZOOMED] " + String.valueOf(ChatFormatting.RESET) : "") + var5_5.getName()) : (StarClient.getInstance().getFriendManager().isFriend(var5_5.getName()) != false ? String.valueOf(ChatFormatting.GREEN) + "[F] " + (String)(var5_5.isPotionActive(Potion.getPotionById(2)) != false ? String.valueOf(ChatFormatting.RED) + "[ZOOMED] " + String.valueOf(ChatFormatting.RESET) : "") + String.valueOf(ChatFormatting.RESET) + var5_5.getName() : (String)(var5_5.isPotionActive(Potion.getPotionById(2)) != false ? String.valueOf(ChatFormatting.RED) + "[ZOOMED] " + String.valueOf(ChatFormatting.RESET) : "") + var5_5.getName());
                        if (!var5_5.getUniqueID().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + var5_5.getName()).getBytes(StandardCharsets.UTF_8)))) {
                            var28_22 = String.valueOf(ChatFormatting.RED) + "[BOT] " + String.valueOf(ChatFormatting.RESET) + var5_5.getName();
                        }
                        var29_23 = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
                        var30_24 = StarClient.getInstance().getC(0).getRGB();
                        var31_25 = StarClient.getInstance().getC(500).getRGB();
                        v0 = var32_26 = var29_23 != false ? new Color(255, 255, 255).getRGB() : new Color(28, 28, 28).getRGB();
                        if (StarClient.getInstance().getFriendManager().isFriend(var5_5.getName())) {
                            var32_26 = var29_23 != false ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB();
                        }
                        var33_27 = var29_23 != false ? new Color(28, 28, 28, 230).getRGB() : new Color(255, 255, 255, 220).getRGB();
                        var34_28 = Fonts.nunitoBold14.getStringWidth(var28_22) + 3;
                        GlStateManager.disableDepth();
                        RenderUtility.drawCenteredRoundedRect(var27_21, (float)var23_19 - 13.0f, (float)var34_28, (float)(Fonts.nunitoBold14.getStringHeight(var28_22) + 3), 5.0f, var33_27);
                        Fonts.nunitoBold14.drawCenteredString(var28_22, var27_21, (float)var23_19 - 11.0f, var32_26);
                        GlStateManager.enableDepth();
                        RenderUtility.drawCenteredRoundedRect(var27_21, (float)var23_19 - 13.0f, (float)var34_28, (float)(Fonts.nunitoBold14.getStringHeight(var28_22) + 3), 5.0f, var33_27);
                        Fonts.nunitoBold14.drawCenteredString(var28_22, var27_21, (float)var23_19 - 11.0f, var32_26);
                        var35_29 = new ArrayList<ItemStack>(Arrays.asList(new ItemStack[]{var5_5.getHeldItemMainhand(), var5_5.getHeldItemOffhand()}));
                        var5_5.getArmorInventoryList().forEach((Consumer<ItemStack>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, add(E ), (Lnet/minecraft/item/ItemStack;)V)(var35_29));
                        var35_29.removeIf((Predicate<ItemStack>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$onRender$0(net.minecraft.item.ItemStack ), (Lnet/minecraft/item/ItemStack;)Z)());
                        var36_30 = var35_29.size() * 10;
                        var37_31 = 0;
                        var38_32 = var35_29.iterator();
                        block2: while (true) {
                            if (!var38_32.hasNext()) {
                                var40_34 = new ArrayList<String>();
                                for (PotionEffect var43_39 : var5_5.getActivePotionEffects()) {
                                    var42_37 = Hud.getPotionPower(var43_39);
                                    var44_41 = null;
                                    if (var43_39.getDuration() < 200) {
                                        var44_41 = ChatFormatting.RED;
                                    } else if (var43_39.getDuration() < 400) {
                                        var44_41 = ChatFormatting.GOLD;
                                    } else if (var43_39.getDuration() > 400) {
                                        var44_41 = ChatFormatting.GREEN;
                                    }
                                    if (var43_39.getDuration() == 0 || var43_39.getPotion() == Potion.getPotionById(2)) continue;
                                    var40_34.add(I18n.format(var43_39.getPotion().getName(), new Object[0]) + " " + (String)var42_37 + String.valueOf((Object)TextFormatting.GRAY) + " " + String.valueOf(var44_41) + Hud.getDuration(var43_39));
                                }
                                var43_38 = 0.0f;
                                for (Object var42_37 : var40_34) {
                                    Fonts.nunitoBold14.drawString((String)var42_37, var25_20 + 5.0, var23_19 + 10.0 + (double)var43_38, -1);
                                    var43_38 += 10.0f;
                                }
                                break block18;
                            }
                            var39_33 = (ItemStack)var38_32.next();
                            if (var39_33 == null) continue;
                            GlStateManager.pushMatrix();
                            GlStateManager.translate((double)(var27_21 + (float)(var37_31 * 20) - (float)var36_30 + 2.0f), var23_19 - 35.0, 0.0);
                            RenderUtility.drawItemStack(var39_33, 0, 0);
                            GlStateManager.popMatrix();
                            ++var37_31;
                            var40_34 = new ArrayList<E>();
                            NameTags.getEnchantment(var40_34, var39_33);
                            var41_36 = 0;
                            var42_37 = var40_34.iterator();
lbl104:
                            // 2 sources

                            while (true) {
                                if (var42_37.hasNext()) break block2;
                                continue block2;
                                break;
                            }
                            break;
                        }
                        var43_40 = (String)var42_37.next();
                        Fonts.nunito12.drawCenteredStringWithShadow(var43_40, var27_21 + (float)(var37_31 * 20) - (float)var36_30 - 10.0f, (float)var23_19 - 37.5f - 6.0f - (float)(var41_36 * 7), -1);
                        ++var41_36;
                        ** continue;
                    }
                }
                NameTags.mc.entityRenderer.setupOverlayRendering();
            }
            GlStateManager.popMatrix();
        }
    }

    public static void getEnchantment(ArrayList<String> arrayList, ItemStack itemStack) {
        Item item = itemStack.getItem();
        int n = EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, itemStack);
        int n2 = EnchantmentHelper.getEnchantmentLevel(Enchantments.THORNS, itemStack);
        int n3 = EnchantmentHelper.getEnchantmentLevel(Enchantments.UNBREAKING, itemStack);
        int n4 = EnchantmentHelper.getEnchantmentLevel(Enchantments.MENDING, itemStack);
        int n5 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FEATHER_FALLING, itemStack);
        int n6 = EnchantmentHelper.getEnchantmentLevel(Enchantments.DEPTH_STRIDER, itemStack);
        int n7 = EnchantmentHelper.getEnchantmentLevel(Enchantments.field_190940_C, itemStack);
        int n8 = EnchantmentHelper.getEnchantmentLevel(Enchantments.field_190941_k, itemStack);
        int n9 = EnchantmentHelper.getEnchantmentLevel(Enchantments.field_191530_r, itemStack);
        int n10 = EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, itemStack);
        int n11 = EnchantmentHelper.getEnchantmentLevel(Enchantments.LOOTING, itemStack);
        int n12 = EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, itemStack);
        int n13 = EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, itemStack);
        int n14 = EnchantmentHelper.getEnchantmentLevel(Enchantments.PUNCH, itemStack);
        int n15 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FLAME, itemStack);
        int n16 = EnchantmentHelper.getEnchantmentLevel(Enchantments.KNOCKBACK, itemStack);
        int n17 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FIRE_ASPECT, itemStack);
        int n18 = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, itemStack);
        int n19 = EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, itemStack);
        int n20 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, itemStack);
        int n21 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FIRE_PROTECTION, itemStack);
        int n22 = EnchantmentHelper.getEnchantmentLevel(Enchantments.BLAST_PROTECTION, itemStack);
        if (item instanceof ItemAxe) {
            if (n10 > 0) {
                arrayList.add("Shr" + n10);
            }
            if (n18 > 0) {
                arrayList.add("Eff" + n18);
            }
            if (n3 > 0) {
                arrayList.add("Unb" + n3);
            }
        }
        if (item instanceof ItemArmor) {
            if (n7 > 0) {
                arrayList.add("Vanish ");
            }
            if (n21 > 0) {
                arrayList.add("Firp" + n21);
            }
            if (n22 > 0) {
                arrayList.add("Bla" + n22);
            }
            if (n8 > 0) {
                arrayList.add("\u0412\u00a7cBindi ");
            }
            if (n6 > 0) {
                arrayList.add("Dep" + n6);
            }
            if (n5 > 0) {
                arrayList.add("Fea" + n5);
            }
            if (n > 0) {
                arrayList.add("Pro" + n);
            }
            if (n2 > 0) {
                arrayList.add("Thr" + n2);
            }
            if (n4 > 0) {
                arrayList.add("Men ");
            }
            if (n3 > 0) {
                arrayList.add("Unb" + n3);
            }
        }
        if (item instanceof ItemBow) {
            if (n7 > 0) {
                arrayList.add("Vanish ");
            }
            if (n8 > 0) {
                arrayList.add("Binding ");
            }
            if (n12 > 0) {
                arrayList.add("Inf" + n12);
            }
            if (n13 > 0) {
                arrayList.add("Pow" + n13);
            }
            if (n14 > 0) {
                arrayList.add("Pun" + n14);
            }
            if (n4 > 0) {
                arrayList.add("Men ");
            }
            if (n15 > 0) {
                arrayList.add("Fla" + n15);
            }
            if (n3 > 0) {
                arrayList.add("Unb" + n3);
            }
        }
        if (item instanceof ItemSword) {
            if (n7 > 0) {
                arrayList.add("Vanish ");
            }
            if (n11 > 0) {
                arrayList.add("Loot" + n11);
            }
            if (n8 > 0) {
                arrayList.add("Bindi ");
            }
            if (n9 > 0) {
                arrayList.add("Swe" + n9);
            }
            if (n10 > 0) {
                arrayList.add("Shr" + n10);
            }
            if (n16 > 0) {
                arrayList.add("Kno" + n16);
            }
            if (n17 > 0) {
                arrayList.add("Fir" + n17);
            }
            if (n3 > 0) {
                arrayList.add("Unb" + n3);
            }
            if (n4 > 0) {
                arrayList.add("Men ");
            }
        }
        if (item instanceof ItemTool) {
            if (n3 > 0) {
                arrayList.add("Unb" + n3);
            }
            if (n4 > 0) {
                arrayList.add("Men ");
            }
            if (n7 > 0) {
                arrayList.add("Vanish ");
            }
            if (n8 > 0) {
                arrayList.add("Binding ");
            }
            if (n18 > 0) {
                arrayList.add("Eff" + n18);
            }
            if (n19 > 0) {
                arrayList.add("Sil" + n19);
            }
            if (n20 > 0) {
                arrayList.add("For" + n20);
            }
        }
    }

    private static /* synthetic */ boolean lambda$onRender$0(ItemStack itemStack) {
        return itemStack.getItem() instanceof ItemAir;
    }
}
