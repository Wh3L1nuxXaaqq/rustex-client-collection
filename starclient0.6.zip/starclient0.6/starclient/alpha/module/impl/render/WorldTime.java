package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ModeSetting;

@ModuleAnnotation(name="WorldTime", category=Category.RENDER)
public class WorldTime
extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Day", "Day", "Night", "Sunrise", "Sunset");

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        switch (this.mode.get()) {
            case "Day": {
                WorldTime.mc.world.setWorldTime(5000L);
                break;
            }
            case "Night": {
                WorldTime.mc.world.setWorldTime(17000L);
                break;
            }
            case "Sunrise": {
                WorldTime.mc.world.setWorldTime(0L);
                break;
            }
            case "Sunset": {
                WorldTime.mc.world.setWorldTime(13000L);
            }
        }
    }

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketTimeUpdate) {
            eventReceivePacket.setCancelled(true);
        }
    }
}
