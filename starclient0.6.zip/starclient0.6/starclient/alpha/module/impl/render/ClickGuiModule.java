package starclient.alpha.module.impl.render;

import java.awt.Color;
import starclient.alpha.StarClient;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.utility.misc.SoundUtility;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="ClickGui", category=Category.RENDER)
public class ClickGuiModule
extends Module {
    public static BooleanSetting sounds = new BooleanSetting("Sound", true);
    public static BooleanSetting glow = new BooleanSetting("Glow", true);
    private float x;
    private float y;
    int color = StarClient.getInstance().getC(25).getRGB();
    int color2 = StarClient.getInstance().getC(500).getRGB();

    public ClickGuiModule() {
        this.bind = 54;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        mc.displayGuiScreen(StarClient.getInstance().getCsGui());
        if (sounds.get()) {
            SoundUtility.playSound("guienabledev2.wav", 1.0f);
        }
        if (glow.get()) {
            RenderUtility.drawGradientGlow(this.x, this.y, 430.0f, 235.0f, 8, new Color(this.color), new Color(this.color2));
        }
        StarClient.getInstance().getModuleManager().getModule(ClickGuiModule.class).setToggled(false);
    }
}
