package starclient.alpha.module.impl.render;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="ViewModel", category=Category.PLAYER)
public class ViewModel
extends Module {
    public static NumberSetting rightX = new NumberSetting("\u041f\u0440\u0430\u0432\u044b\u0439 X", 0.0f, -10.0f, 10.0f, 0.1f);
    public static NumberSetting rightY = new NumberSetting("\u041f\u0440\u0430\u0432\u044b\u0439 Y", 0.0f, -10.0f, 10.0f, 0.1f);
    public static NumberSetting rightZ = new NumberSetting("\u041f\u0440\u0430\u0432\u044b\u0439 Z", 0.0f, -10.0f, 10.0f, 0.1f);
    public static NumberSetting leftX = new NumberSetting("\u041b\u0435\u0432\u044b\u0439 X", 0.0f, -10.0f, 2.0f, 0.1f);
    public static NumberSetting leftY = new NumberSetting("\u041b\u0435\u0432\u044b\u0439 Y", 0.0f, -10.0f, 2.0f, 0.1f);
    public static NumberSetting leftZ = new NumberSetting("\u041b\u0435\u0432\u044b\u0439 Z", 0.0f, -10.0f, 2.0f, 0.1f);
    public static NumberSetting sizeX = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440 X", 1.0f, 1.0f, 20.0f, 0.1f);
    public static NumberSetting sizeY = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440 Y", 1.0f, 1.0f, 20.0f, 0.1f);
    public static NumberSetting sizeZ = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440 Z", 1.0f, 1.0f, 20.0f, 0.1f);
    public static BooleanSetting onlyAura = new BooleanSetting("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u0430\u0438\u043c\u0431\u043e\u0442\u043e\u043c", false);
    public static NumberSetting size = new NumberSetting("\u0420\u0430\u0437\u043c\u0435\u0440", 1.0f, 0.1f, 5.0f, 0.05f);
}
