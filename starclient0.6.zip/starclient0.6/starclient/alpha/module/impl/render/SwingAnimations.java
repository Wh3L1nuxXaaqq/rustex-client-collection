package starclient.alpha.module.impl.render;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="SwingAnimations", category=Category.RENDER)
public class SwingAnimations
extends Module {
    public static ModeSetting mode = new ModeSetting("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f", "\u041f\u043b\u0430\u0432\u043d\u044b\u0439", "\u041f\u043b\u0430\u0432\u043d\u044b\u0439", "\u041d\u0430 \u0441\u0435\u0431\u044f", "\u0411\u043b\u043e\u043a", "\u0421\u0442\u0430\u0440\u044b\u0439 \u0431\u043b\u043e\u043a");
    public static NumberSetting angle = new NumberSetting("\u0423\u0433\u043e\u043b", 100.0f, 0.0f, 360.0f, 1.0f, () -> mode.is("\u041d\u0430 \u0441\u0435\u0431\u044f") || mode.is("\u0411\u043b\u043e\u043a"));
    public static NumberSetting swipePower = new NumberSetting("\u0421\u0438\u043b\u0430 \u0441\u0432\u0430\u0439\u043f\u0430", 70.0f, 10.0f, 100.0f, 5.0f, () -> mode.is("\u041d\u0430 \u0441\u0435\u0431\u044f") || mode.is("\u0411\u043b\u043e\u043a"));
    public static NumberSetting swipeSpeed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0441\u0432\u0430\u0439\u043f\u0430", 6.0f, 1.0f, 20.0f, 1.0f);
    public static BooleanSetting onlyAura = new BooleanSetting("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u0430\u0438\u043c\u043e\u043c", false);
    public static BooleanSetting spin = new BooleanSetting("\u041a\u0440\u0443\u0442\u0438\u0442\u044c", false);
    public static ModeSetting spinMode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c \u043a\u0440\u0443\u0447\u0435\u043d\u0438\u044f", "\u0413\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u044c\u043d\u044b\u0439", () -> spin.get(), "\u0413\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u044c\u043d\u044b\u0439", "\u0412\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u044c\u043d\u044b\u0439", "\u041f\u0440\u0438\u0431\u043b\u0438\u0436\u0435\u043d\u0438\u0435");
    public static ModeSetting spinHand = new ModeSetting("\u041f\u043e\u0432\u043e\u0440\u0430\u0447\u0438\u0432\u0430\u0442\u044c \u0440\u0443\u043a\u0443", "\u0412\u0441\u0435", () -> spin.get(), "\u0412\u0441\u0435", "\u041b\u0435\u0432\u0443\u044e", "\u041f\u0440\u0430\u0432\u0443\u044e");
    public static NumberSetting spinSpeed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043a\u0440\u0443\u0447\u0435\u043d\u0438\u044f", 8.0f, 1.0f, 15.0f, 1.0f, () -> spin.get());
    public static BooleanSetting stopOnHit = new BooleanSetting("\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u0441 \u0430\u0438\u043c\u043e\u043c", true, () -> spin.get());
}
