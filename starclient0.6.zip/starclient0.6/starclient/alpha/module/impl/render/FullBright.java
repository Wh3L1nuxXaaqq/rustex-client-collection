package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="FullBright", category=Category.RENDER)
public class FullBright
extends Module {
    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        FullBright.mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 6000, 1));
    }

    @Override
    public void onDisable() {
        if (FullBright.mc.player != null) {
            FullBright.mc.player.removeActivePotionEffect(MobEffects.NIGHT_VISION);
        }
        super.onDisable();
    }
}
