package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import starclient.alpha.StarClient;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.misc.BlockUtility;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="OreESP", category=Category.RENDER)
public class OreESP
extends Module {
    public static ArrayList<BlockPos> blocksToCheck = new ArrayList();
    public static ArrayList<Block> blocksToRender = new ArrayList();

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        for (BlockPos blockPos : blocksToCheck) {
            for (Block block : blocksToRender) {
                Block block2 = OreESP.mc.world.getBlockState(blockPos).getBlock();
                int n = OreESP.mc.world.getBlockState((BlockPos)blockPos).getMapColor((IBlockAccess)OreESP.mc.world, (BlockPos)blockPos).colorIndex;
                if (block2 == block) {
                    RenderUtility.drawBlockBox(blockPos, StarClient.getInstance().getC(0), 255);
                }
                if (n == 38 || n == 46 || n == 46) {
                    RenderUtility.drawBlockBox(blockPos, new Color(0.8901961f, 0.8666667f, 0.22745098f), 255);
                }
                if (n == 36 || n == 44 || n == 40) {
                    RenderUtility.drawBlockBox(blockPos, new Color(0, 0, 0), 255);
                }
                if (n != 45 && n != 41 && n != 37) continue;
                RenderUtility.drawBlockBox(blockPos, new Color(0.6156863f, 0.6117647f, 0.5647059f), 255);
            }
        }
    }

    @Override
    public void onEnable() {
        if (OreESP.mc.world == null || OreESP.mc.player == null) {
            this.setToggled(false);
            return;
        }
        if (blocksToCheck != null) {
            blocksToCheck.clear();
        }
        blocksToRender.addAll(Arrays.asList(Blocks.field_190980_do, Blocks.field_190988_dw, Blocks.field_190978_dm, Blocks.field_190990_dy, Blocks.field_190975_dA));
        for (BlockPos blockPos : BlockUtility.getBlocks(25, 25, 25)) {
            for (Block block : blocksToRender) {
                int n = OreESP.mc.world.getBlockState((BlockPos)blockPos).getMapColor((IBlockAccess)OreESP.mc.world, (BlockPos)blockPos).colorIndex;
                if (OreESP.mc.world.getBlockState(blockPos).getBlock() != block && n != 38 && n != 46 && n != 46 && n != 36 && n != 44 && n != 40 && n != 45 && n != 41 && n != 37) continue;
                blocksToCheck.add(blockPos);
            }
        }
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        new Thread(() -> {
            try {
                Thread.sleep(3000L);
            }
            catch (InterruptedException interruptedException) {
                throw new RuntimeException(interruptedException);
            }
        }).start();
    }
}
