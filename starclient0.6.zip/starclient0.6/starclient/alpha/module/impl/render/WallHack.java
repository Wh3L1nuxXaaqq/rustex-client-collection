package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="WallHack", category=Category.RENDER)
public class WallHack
extends Module {
    public ArrayList<EntityArmorStand> list = new ArrayList();

    void render(Entity entity, float f) {
        try {
            if (entity == null || entity == WallHack.mc.player) {
                return;
            }
            if (entity == mc.getRenderViewEntity() && WallHack.mc.gameSettings.thirdPersonView == 0) {
                return;
            }
            WallHack.mc.entityRenderer.disableLightmap();
            mc.getRenderManager().renderEntityStatic(entity, f, false);
            WallHack.mc.entityRenderer.enableLightmap();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (WallHack.mc.player == null || WallHack.mc.world == null) {
            return;
        }
        for (Entity entity : WallHack.mc.world.loadedEntityList) {
            if (entity == null || !(entity instanceof EntityArmorStand)) continue;
            if (this.list.contains(entity)) {
                this.list.remove(entity);
            }
            this.list.add((EntityArmorStand)entity);
        }
        for (EntityArmorStand entityArmorStand : this.list) {
            if (!(WallHack.mc.player.getDistanceToEntity(entityArmorStand) >= 75.0f)) continue;
            this.list.remove(entityArmorStand);
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        if (WallHack.mc.player == null || WallHack.mc.world == null) {
            return;
        }
        GlStateManager.disableDepth();
        for (EntityArmorStand entityArmorStand : this.list) {
            this.render(entityArmorStand, eventRender3D.getPartialTicks());
        }
        GlStateManager.enableDepth();
    }
}
