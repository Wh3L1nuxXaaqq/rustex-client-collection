package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityZombie;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="BotESP", category=Category.RENDER)
public class ZombaESP
extends Module {
    public static ColorSetting defaultBot = new ColorSetting("\u0426\u0432\u0435\u0442", new Color(13, 65, 236, 140).getRGB());
    public static NumberSetting lineWidth = new NumberSetting("\u0428\u0438\u0440\u0438\u043d\u0430 \u043b\u0438\u043d\u0438\u0439", 0.1f, 0.1f, 2.0f, 0.1f);
    public static BooleanSetting fill = new BooleanSetting("\u0417\u0430\u043b\u0438\u0432\u043a\u0430", false);
    public static BooleanSetting outline = new BooleanSetting("\u041e\u0431\u0432\u043e\u0434\u043a\u0430", true);

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        for (Entity entity : ZombaESP.mc.world.loadedEntityList) {
            if (entity == null) {
                return;
            }
            if (entity instanceof EntityZombie) {
                RenderUtility.drawBoxESP(entity.getEntityBoundingBox(), defaultBot.getColor(), lineWidth.get(), outline.get(), fill.get(), defaultBot.getColor().getAlpha(), defaultBot.getColor().getAlpha());
            }
            if (!(entity instanceof EntityPigZombie)) continue;
            RenderUtility.drawBoxESP(entity.getEntityBoundingBox(), defaultBot.getColor(), lineWidth.get(), outline.get(), fill.get(), defaultBot.getColor().getAlpha(), defaultBot.getColor().getAlpha());
        }
    }
}
