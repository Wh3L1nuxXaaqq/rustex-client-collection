package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.dragging.DragManager;
import starclient.alpha.manager.dragging.Draggable;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.SmartScissor;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="Keybinds", category=Category.RENDER)
public class Keybinds
extends Module {
    private final Draggable keybindsDraggable = DragManager.create(this, "Keybinds", 200, 200);
    public float realOffset = 0.0f;

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        if (!Keybinds.mc.gameSettings.showDebugInfo) {
            GlStateManager.pushMatrix();
            List list = StarClient.getInstance().getModuleManager().getModules().stream().filter(module -> module.getBind() != 0 && module.isEnabled()).sorted(Comparator.comparing(module -> Fonts.nunitoBold15.getStringWidth(module.getName()), Comparator.reverseOrder())).collect(Collectors.toList());
            int n = StarClient.getInstance().getC(0).getRGB();
            int n2 = StarClient.getInstance().getC(500).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            int n3 = -1;
            int n4 = 105;
            if (!list.isEmpty()) {
                n4 = list.stream().max(Comparator.comparingInt(module -> Fonts.nunitoBold15.getStringWidth(this.getText((Module)module)))).map(module -> Fonts.nunitoBold15.getStringWidth(this.getText((Module)module))).get() + 11;
                if (n4 < 105) {
                    n4 = 105;
                }
                n3 = 0;
                for (Module module2 : list) {
                    n3 += 11;
                }
            }
            this.realOffset = AnimationMath.fast(this.realOffset, n3, 15.0f);
            this.keybindsDraggable.setWidth(n4);
            this.keybindsDraggable.setHeight(19 + n3);
            int n5 = bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB();
            int n6 = n4;
            RenderUtility.drawBlur(() -> RenderUtility.Cornered(this.keybindsDraggable.getX(), this.keybindsDraggable.getY(), n6, 14.0f + this.realOffset * 1.09f, 5.0f, 0.0f, 5.0f, 0.0f, n5), 8.0f);
            RenderUtility.Cornered(this.keybindsDraggable.getX(), this.keybindsDraggable.getY(), n4, 14.0f, 5.0f, 0.0f, 5.0f, 0.0f, n5);
            Fonts.newicons24.drawString("B", this.keybindsDraggable.getX() + 4, (float)this.keybindsDraggable.getY() + 7.0f - (float)Fonts.mntsb16.getFontHeight() / 2.0f, new Color(15, 148, 216, 255).getRGB());
            Fonts.nunitoBold18.drawCenteredString("Binds", this.keybindsDraggable.getX() + n4 / 2 - 22, (float)this.keybindsDraggable.getY() + 3.5f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
            SmartScissor.push();
            SmartScissor.setFromComponentCoordinates((double)this.keybindsDraggable.getX(), (double)this.keybindsDraggable.getY(), (double)n4, 16.0f + this.realOffset);
            n3 = -1;
            for (Module module2 : list) {
                Fonts.nunitoBold16.drawString(module2.getName(), this.keybindsDraggable.getX() + 5, (float)this.keybindsDraggable.getY() + 18.0f + (float)n3, bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB());
                String string = " [" + (String)(module2.bind < 0 ? "MOUSE " + module2.getMouseBind() : Keyboard.getKeyName((int)module2.getBind())) + "]";
                Fonts.nunitoBold16.drawString(string, this.keybindsDraggable.getX() + n4 - Fonts.nunitoBold15.getStringWidth(string) - 5, (float)this.keybindsDraggable.getY() + 18.0f + (float)n3, bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB());
                n3 += 11;
            }
            SmartScissor.unset();
            SmartScissor.pop();
            GlStateManager.popMatrix();
        }
    }

    private String getText(Module module) {
        return module.getName() + " [" + (String)(module.bind < 0 ? "MOUSE " + module.getMouseBind() : Keyboard.getKeyName((int)module.getBind())) + "]";
    }
}
