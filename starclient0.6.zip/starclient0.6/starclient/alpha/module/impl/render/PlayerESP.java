package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.jhlabs.vecmath.Vector4f;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.util.NameProtect;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="PlayerESP", category=Category.RENDER)
public class PlayerESP
extends Module {
    public final List<Entity> collectedEntities = new ArrayList<Entity>();
    private final IntBuffer viewport = GLAllocation.createDirectIntBuffer(16);
    private final FloatBuffer modelview = GLAllocation.createDirectFloatBuffer(16);
    private final FloatBuffer projection = GLAllocation.createDirectFloatBuffer(16);
    private final FloatBuffer vector = GLAllocation.createDirectFloatBuffer(4);
    public MultiBooleanSetting elements = new MultiBooleanSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", Arrays.asList("\u0411\u043e\u043a\u0441", "\u041d\u0438\u043a", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442", "\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435"));

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        int n = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[0].getRGB();
        int n2 = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[1].getRGB();
        RenderManager renderManager = mc.getRenderManager();
        EntityRenderer entityRenderer = PlayerESP.mc.entityRenderer;
        for (EntityPlayer entityPlayer : PlayerESP.mc.world.playerEntities) {
            if (PlayerESP.mc.player == entityPlayer && PlayerESP.mc.gameSettings.thirdPersonView == 0 || entityPlayer.isDead || !RenderUtility.isInViewFrustum(entityPlayer)) continue;
            double d = entityPlayer.lastTickPosX + (entityPlayer.posX - entityPlayer.lastTickPosX) * (double)eventRender2D.getPartialTicks();
            double d2 = entityPlayer.lastTickPosY + (entityPlayer.posY - entityPlayer.lastTickPosY) * (double)eventRender2D.getPartialTicks();
            double d3 = entityPlayer.lastTickPosZ + (entityPlayer.posZ - entityPlayer.lastTickPosZ) * (double)eventRender2D.getPartialTicks();
            double d4 = (double)entityPlayer.width / 1.5;
            double d5 = entityPlayer.height + 0.2f - (entityPlayer.isSneaking() ? 0.2f : 0.0f);
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB(d - d4, d2, d3 - d4, d + d4, d2 + d5, d3 + d4);
            Vec3d[] vec3dArray = new Vec3d[]{new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ)};
            entityRenderer.setupCameraTransform(eventRender2D.getPartialTicks(), 0);
            Vector4f vector4f = null;
            for (Vec3d vec3d : vec3dArray) {
                vec3d = RenderUtility.project2D(2, vec3d.x - renderManager.viewerPosX, vec3d.y - renderManager.viewerPosY, vec3d.z - renderManager.viewerPosZ);
                if (vec3d == null || !(vec3d.z >= 0.0) || !(vec3d.z < 1.0)) continue;
                if (vector4f == null) {
                    vector4f = new Vector4f((float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 1.0f);
                }
                vector4f.x = (float)Math.min(vec3d.x, (double)vector4f.x);
                vector4f.y = (float)Math.min(vec3d.y, (double)vector4f.y);
                vector4f.z = (float)Math.max(vec3d.x, (double)vector4f.z);
                vector4f.w = (float)Math.max(vec3d.y, (double)vector4f.w);
            }
            if (vector4f == null) continue;
            PlayerESP.mc.entityRenderer.setupOverlayRendering(2);
            double d6 = vector4f.x;
            double d7 = vector4f.y;
            double d8 = vector4f.z;
            double d9 = vector4f.w;
            if (this.elements.get(0)) {
                RenderUtility.drawRectNoWH(d6 - 1.0, d7, d6 + 0.5, d9 + 0.5, Color.black.getRGB());
                RenderUtility.drawRectNoWH(d6 - 1.0, d7 - 0.5, d8 + 0.5, d7 + 0.5 + 0.5, Color.black.getRGB());
                RenderUtility.drawRectNoWH(d8 - 0.5 - 0.5, d7, d8 + 0.5, d9 + 0.5, Color.black.getRGB());
                RenderUtility.drawRectNoWH(d6 - 1.0, d9 - 0.5 - 0.5, d8 + 0.5, d9 + 0.5, Color.black.getRGB());
                RenderUtility.drawRectNoWH(d6 - 0.5, d7, d6 + 0.5 - 0.5, d9, -1);
                RenderUtility.drawRectNoWH(d6, d9 - 0.5, d8, d9, -1);
                RenderUtility.drawRectNoWH(d6 - 0.5, d7, d8, d7 + 0.5, -1);
                RenderUtility.drawRectNoWH(d8 - 0.5, d7, d8, d9, -1);
            }
            double d10 = entityPlayer.getHealth() / entityPlayer.getMaxHealth();
            double d11 = (d9 - d7) * d10;
            double d12 = d9 - d7;
            double d13 = (d8 - d6) / 2.0;
            double d14 = Fonts.nunito12.getStringWidth(entityPlayer.getName());
            if (this.elements.get(1)) {
                NameProtect nameProtect = (NameProtect)StarClient.getInstance().getModuleManager().getModule(NameProtect.class);
                String string = nameProtect.isEnabled() && (StarClient.getInstance().getFriendManager().isFriend(entityPlayer.getName()) || entityPlayer.getName().equals(PlayerESP.mc.player.getName())) ? ChatFormatting.stripFormatting((String)NameProtect.protectedNick) : ChatFormatting.stripFormatting((String)entityPlayer.getName());
                double d15 = Fonts.nunito12.getStringWidth(string);
                double d16 = d6 + d13 - d15 / 2.0;
                double d17 = d7 - 5.0;
                Fonts.nunito12.drawStringWithOutline(string, d16, d17, -1);
            }
            if (this.elements.get(3)) {
                RenderUtility.drawRectNoWH((float)(d6 - 3.5), (float)(d9 + 0.5), (float)(d6 - 1.5), (float)(d9 - d12 - 0.5), new Color(0, 0, 0, 255).getRGB());
                RenderUtility.drawVGradientRect((float)(d6 - 3.0), (float)d9, (float)(d6 - 2.0), (float)(d9 - d12), n, n2);
                RenderUtility.drawRectNoWH(d6 - 3.5, d7, d6 - 1.5, d9 - d11, new Color(0, 0, 0, 255).getRGB());
            }
            if (!entityPlayer.getHeldItemMainhand().isEmpty() && this.elements.get(2)) {
                Fonts.nunito12.drawCenteredStringWithOutline(ChatFormatting.stripFormatting((String)entityPlayer.getHeldItemMainhand().getDisplayName()), (float)(d6 + (d8 - d6) / 2.0), (float)(d9 + 0.5) + 4.0f, -1);
            }
            PlayerESP.mc.entityRenderer.setupOverlayRendering();
        }
    }

    private boolean isValid(Entity entity) {
        if (entity == PlayerESP.mc.player && PlayerESP.mc.gameSettings.thirdPersonView == 0) {
            return false;
        }
        return !entity.isDead;
    }

    private void collectEntities() {
        this.collectedEntities.clear();
        for (EntityPlayer entityPlayer : PlayerESP.mc.world.playerEntities) {
            if (!this.isValid(entityPlayer)) continue;
            this.collectedEntities.add(entityPlayer);
        }
    }

    private Vec3d project2D(int n, double d, double d2, double d3) {
        GL11.glGetFloat((int)2982, (FloatBuffer)this.modelview);
        GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
        GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
        return GLU.gluProject((float)((float)d), (float)((float)d2), (float)((float)d3), (FloatBuffer)this.modelview, (FloatBuffer)this.projection, (IntBuffer)this.viewport, (FloatBuffer)this.vector) ? new Vec3d(this.vector.get(0) / (float)n, ((float)Display.getHeight() - this.vector.get(1)) / (float)n, this.vector.get(2)) : null;
    }

    public static int getHealthColor(EntityLivingBase entityLivingBase, int n, int n2) {
        float f = entityLivingBase.getHealth();
        float f2 = entityLivingBase.getMaxHealth();
        float f3 = f / f2;
        int n3 = (int)((float)(n2 >> 16 & 0xFF) * f3 + (float)(n >> 16 & 0xFF) * (1.0f - f3));
        int n4 = (int)((float)(n2 >> 8 & 0xFF) * f3 + (float)(n >> 8 & 0xFF) * (1.0f - f3));
        int n5 = (int)((float)(n2 & 0xFF) * f3 + (float)(n & 0xFF) * (1.0f - f3));
        return new Color(n3, n4, n5).getRGB();
    }
}
