package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.jhlabs.vecmath.Vector4f;
import java.util.Iterator;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="ItemESP", category=Category.RENDER)
public class ItemESP
extends Module {
    @EventTarget
    public void onDisplay(EventRender2D eventRender2D) {
        Iterator iterator = ItemESP.mc.world.loadedEntityList.iterator();
        while (iterator.hasNext()) {
            Entity entity = (Entity)iterator.next();
            if (!(entity instanceof EntityItem) || !RenderUtility.isInViewFrustum(entity)) continue;
            double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)mc.getRenderPartialTicks();
            double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)mc.getRenderPartialTicks();
            double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)mc.getRenderPartialTicks();
            double d4 = (double)entity.width / 1.5;
            double d5 = entity.height + 0.2f;
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB(d - d4, d2, d3 - d4, d + d4, d2 + d5, d3 + d4);
            Vec3d[] vec3dArray = new Vec3d[]{new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ), new Vec3d(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ)};
            ItemESP.mc.entityRenderer.setupCameraTransform(mc.getRenderPartialTicks(), 0);
            ScaledResolution scaledResolution = eventRender2D.getResolution();
            Vector4f vector4f = null;
            Vec3d[] vec3dArray2 = vec3dArray;
            int n = vec3dArray.length;
            for (int i = 0; i < n; ++i) {
                Vec3d vec3d = vec3dArray2[i];
                vec3d = RenderUtility.project2D(2, vec3d.x - ItemESP.mc.getRenderManager().renderPosX, vec3d.y - ItemESP.mc.getRenderManager().renderPosY, vec3d.z - ItemESP.mc.getRenderManager().renderPosZ);
                if (vec3d == null || !(vec3d.z > 0.0) || !(vec3d.z < 1.0)) continue;
                if (vector4f == null) {
                    vector4f = new Vector4f((float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 0.0f);
                }
                vector4f.x = (float)Math.min(vec3d.x, (double)vector4f.x);
                vector4f.y = (float)Math.min(vec3d.y, (double)vector4f.y);
                vector4f.z = (float)Math.max(vec3d.x, (double)vector4f.z);
                vector4f.w = (float)Math.max(vec3d.y, (double)vector4f.w);
            }
            if (vector4f != null) {
                ItemESP.mc.entityRenderer.setupOverlayRendering(2);
                double d6 = vector4f.x;
                double d7 = vector4f.y;
                double d8 = vector4f.z;
                int n2 = -1;
                String string = ((EntityItem)entity).getEntityItem().getDisplayName() + (String)(((EntityItem)entity).getEntityItem().stackSize < 1 ? "" : " x" + ((EntityItem)entity).getEntityItem().stackSize);
                Fonts.nunito12.drawStringWithOutline(string, (float)(d6 + (d8 - d6) / 2.0 - (double)(Fonts.nunito12.getStringWidth(string) / 2)), (float)(d7 - 10.0), n2);
            }
            GL11.glEnable((int)2929);
            GlStateManager.enableBlend();
            ItemESP.mc.entityRenderer.setupOverlayRendering();
        }
        return;
    }
}
