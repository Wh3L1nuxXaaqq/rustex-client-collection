package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.renderer.GlStateManager;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.notification.Notification;
import starclient.alpha.manager.notification.NotificationManager;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="Notifications", category=Category.RENDER)
public class Notifications
extends Module {
    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        float f = 14.0f;
        float f2 = 28.0f;
        int n = eventRender2D.getResolution().getScaledWidth();
        int n2 = eventRender2D.getResolution().getScaledHeight();
        GlStateManager.pushMatrix();
        for (Notification notification : NotificationManager.getNotifications()) {
            Animation animation = notification.getAnimation();
            animation.setDirection(notification.getTimerHelper().hasReached(notification.getTime()) ? Direction.BACKWARDS : Direction.FORWARDS);
            if (animation.finished(Direction.BACKWARDS)) {
                NotificationManager.getNotifications().remove(notification);
                continue;
            }
            float f3 = Math.max(Fonts.tenacityBold18.getStringWidth(notification.getTitle()), Fonts.nunitoBold15.getStringWidth(notification.getDescription())) + 30;
            float f4 = (float)n - (f3 + 0.5f) * animation.getOutput();
            float f5 = (float)n2 - (f + 5.0f + f2);
            notification.render(f4, f5, f3, f2, animation.getOutput());
            f += (f2 - 5.0f) * animation.getOutput() * animation.getOutput();
        }
        GlStateManager.popMatrix();
    }
}
