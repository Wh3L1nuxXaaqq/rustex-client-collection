package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.google.common.collect.Lists;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.StringUtils;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.dragging.DragManager;
import starclient.alpha.manager.dragging.Draggable;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.impl.combat.AimBotDayz;
import starclient.alpha.module.impl.movement.Timer;
import starclient.alpha.module.impl.util.NameProtect;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.SmartScissor;
import starclient.alpha.utility.render.StencilUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.AnimationMath;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="Hud", category=Category.RENDER)
public class Hud
extends Module {
    public static final MultiBooleanSetting elements = new MultiBooleanSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", Arrays.asList("\u041b\u043e\u0433\u043e\u0442\u0438\u043f", "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b", "\u0418\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u044c", "\u0411\u0440\u043e\u043d\u044f", "\u0422\u0430\u0440\u0433\u0435\u0442 \u0445\u0443\u0434", "\u0422\u0430\u0439\u043c\u0435\u0440", "\u0411\u0438\u043d\u0434\u044b", "\u0421\u043f\u0438\u0441\u043e\u043a \u0438\u0433\u0440\u043e\u043a\u043e\u0432", "\u041d\u0430\u0436\u0430\u0442\u0438\u044f \u043a\u043b\u0430\u0432\u0438\u0448"));
    public BooleanSetting background = new BooleanSetting("Potato mode", true);
    public static boolean TPSSyncMessageDisplayed;
    private final Draggable invViewDraggable = DragManager.create(this, "Inventory View", 10, 100);
    private final Draggable targetHudDraggable = DragManager.create(this, "Target HUD", 300, 10);
    private final Draggable armorHudDraggable = DragManager.create(this, "Armor HUD", 414, 331);
    private final Draggable timerHudDraggable = DragManager.create(this, "Timer HUD", new ScaledResolution(mc).getScaledWidth() / 2 - 30, new ScaledResolution(mc).getScaledHeight() - 40);
    private final Draggable keybindsDraggable = DragManager.create(this, "Keybinds", 200, 200);
    private final Draggable playerListDraggable = DragManager.create(this, "PlayerList", 250, 100);
    private final Draggable KeyStrokesDraggable = DragManager.create(this, "KeyStrokes", 300, 21);
    private static final double MAX_DISTANCE = 30.0;
    private float wAlpha = 0.0f;
    private float sAlpha = 0.0f;
    private float aAlpha = 0.0f;
    private float dAlpha = 0.0f;
    private float spaceAlpha = 0.0f;
    int width = 20;
    public float realOffset = 0.0f;
    private EntityLivingBase currentTarget = null;
    private final Animation animation = new DecelerateAnimation(175, 1.0f, Direction.BACKWARDS);
    private double hp;

    public Hud() {
        this.invViewDraggable.setWidth(170.0f);
        this.invViewDraggable.setHeight(72.0f);
        this.targetHudDraggable.setWidth(112.0f);
        this.targetHudDraggable.setHeight(38.0f);
        this.timerHudDraggable.setWidth(60.0f);
        this.timerHudDraggable.setHeight(8.0f);
        this.armorHudDraggable.setWidth(75.0f);
        this.armorHudDraggable.setHeight(30.0f);
        this.KeyStrokesDraggable.setWidth(65.0f);
        this.KeyStrokesDraggable.setHeight(75.0f);
    }

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        if (!Hud.mc.gameSettings.showDebugInfo) {
            int n7;
            Object object2;
            int n8;
            List<ItemStack> list;
            Object object3;
            int n9;
            n6 = 0;
            ScaledResolution scaledResolution = eventRender2D.getResolution();
            n5 = scaledResolution.getScaledWidth();
            n4 = eventRender2D.getResolution().getScaledHeight();
            n3 = StarClient.getInstance().getC(n6 += 25).getRGB();
            n2 = StarClient.getInstance().getC(500 + n6).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            int n10 = n9 = bl ? new Color(255, 255, 255, 240).getRGB() : new Color(255, 255, 255, 230).getRGB();
            if (elements.get(0)) {
                object3 = "| delay - " + mc.getConnection().getPlayerInfo(Hud.mc.player.getUniqueID()).getResponseTime() + "ms | v" + StarClient.VERSION;
                list = " " + (String)object3 + " ";
                n8 = Fonts.mntssb14.getStringWidth((String)((Object)list)) + Fonts.nunitoBold18.getStringWidth("starclient") + 5;
                RenderUtility.drawGradientGlow(4.0f, 6.0f, (float)n8 + 0.5f, 14.0f, 6, n3, n2, n3, n2);
                RenderUtility.drawRoundedRect(4.0f, 6.0f, n8, 14.0f, 5.0f, bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB());
                Fonts.mntssb14.drawString((String)((Object)list), 13 + Fonts.mntssb14.getStringWidth("starclient"), 11.3f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
                Fonts.nunitoBold18.drawGradientString("starclient", 7.0, 9.5, new Color(n3), new Color(n2));
            }
            if (elements.get(1)) {
                object3 = eventRender2D.getResolution();
                int n11 = Hud.mc.currentScreen instanceof GuiChat ? 9 : 0;
                Fonts.nunitoBold15.drawStringWithOutline("FPS: " + Minecraft.getDebugFPS(), 6.0, n4 - 28 - n11, -1);
                Fonts.nunitoBold15.drawStringWithOutline("BPS: " + String.format("%.1f", Math.hypot(Hud.mc.player.posX - Hud.mc.player.prevPosX, Hud.mc.player.posZ - Hud.mc.player.prevPosZ) * 20.0), 6.0, n4 - 20 - n11, -1);
                Fonts.nunitoBold15.drawStringWithOutline("XYZ: " + Hud.mc.player.getPosition().getX() + ", " + Hud.mc.player.getPosition().getY() + ", " + Hud.mc.player.getPosition().getZ(), 6.0, n4 - 12 - n11, -1);
                String string = StarClient.username + " - " + StarClient.uid;
                Fonts.nunitoBold15.drawStringWithOutline(string, ((ScaledResolution)object3).getScaledWidth() - Fonts.nunitoBold15.getStringWidth(string) - 5, ((ScaledResolution)object3).getScaledHeight() - 12 - n11, -1);
            }
            if (elements.get(2)) {
                if (this.background.get()) {
                    RenderUtility.Cornered(this.invViewDraggable.getX(), this.invViewDraggable.getY(), this.invViewDraggable.getWidth(), this.invViewDraggable.getHeight(), 5.0f, 5.0f, 5.0f, 5.0f, n9, bl ? new Color(30, 30, 30, 76).getRGB() : new Color(255, 255, 255, 77).getRGB());
                } else {
                    RenderUtility.drawBlur(() -> RenderUtility.Cornered(this.invViewDraggable.getX(), this.invViewDraggable.getY(), this.invViewDraggable.getWidth(), this.invViewDraggable.getHeight(), 5.0f, 5.0f, 5.0f, 5.0f, n9, bl ? new Color(30, 30, 30, 76).getRGB() : new Color(255, 255, 255, 77).getRGB()), 8.0f);
                }
                RenderUtility.Cornered(this.invViewDraggable.getX(), this.invViewDraggable.getY(), 170.0f, 14.0f, 5.0f, 0.0f, 5.0f, 0.0f, n9, bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB());
                Fonts.newicons20.drawString("A", (float)(this.invViewDraggable.getX() + 85) - 81.0f, (float)this.invViewDraggable.getY() + 8.0f - (float)(Fonts.mntsb16.getFontHeight() / 2), new Color(15, 148, 216, 255).getRGB());
                Fonts.nunitoBold18.drawCenteredString("Inventory", (float)(this.invViewDraggable.getX() + 85) - 47.0f, (float)this.invViewDraggable.getY() + 3.5f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
                for (n = 9; n < 36; ++n) {
                    object3 = Hud.mc.player.inventory.getStackInSlot(n);
                    if (((ItemStack)object3).isEmpty()) continue;
                    int n12 = n - 9;
                    RenderUtility.drawItemStack((ItemStack)object3, this.invViewDraggable.getX() + 5 + n12 % 9 * 18, this.invViewDraggable.getY() + 16 + n12 / 9 * 18);
                }
            }
            if (elements.get(6)) {
                GlStateManager.pushMatrix();
                object3 = StarClient.getInstance().getModuleManager().getModules().stream().filter(module -> module.getBind() != 0 && module.isEnabled()).sorted(Comparator.comparing(module -> Fonts.nunitoBold15.getStringWidth(module.getName()), Comparator.reverseOrder())).collect(Collectors.toList());
                int n13 = -1;
                n8 = 105;
                if (!object3.isEmpty()) {
                    n8 = object3.stream().max(Comparator.comparingInt(module -> Fonts.nunitoBold15.getStringWidth(this.getText((Module)module)))).map(module -> Fonts.nunitoBold15.getStringWidth(this.getText((Module)module))).get() + 11;
                    if (n8 < 105) {
                        n8 = 105;
                    }
                    n13 = 0;
                    object2 = object3.iterator();
                    while (object2.hasNext()) {
                        Module object4 = (Module)object2.next();
                        n13 += 11;
                    }
                }
                this.realOffset = AnimationMath.fast(this.realOffset, n13, 15.0f);
                this.keybindsDraggable.setWidth(n8);
                this.keybindsDraggable.setHeight(19 + n13);
                n7 = n8;
                if (this.background.get()) {
                    RenderUtility.Cornered(this.keybindsDraggable.getX(), this.keybindsDraggable.getY(), n7, 14.0f + this.realOffset * 1.09f, 5.0f, 0.0f, 5.0f, 0.0f, n9, bl ? new Color(30, 30, 30, 76).getRGB() : new Color(255, 255, 255, 77).getRGB());
                } else {
                    RenderUtility.drawBlur(() -> RenderUtility.Cornered(this.keybindsDraggable.getX(), this.keybindsDraggable.getY(), n7, 14.0f + this.realOffset * 1.09f, 5.0f, 0.0f, 5.0f, 0.0f, n9), 8.0f);
                }
                RenderUtility.Cornered(this.keybindsDraggable.getX(), this.keybindsDraggable.getY(), n8, 14.0f, 5.0f, 0.0f, 5.0f, 0.0f, bl ? new Color(30, 30, 30, 240).getRGB() : new Color(255, 255, 255, 230).getRGB());
                Fonts.newicons24.drawString("B", this.keybindsDraggable.getX() + 4, (float)this.keybindsDraggable.getY() + 7.0f - (float)Fonts.mntsb16.getFontHeight() / 2.0f, new Color(15, 148, 216, 255).getRGB());
                Fonts.nunitoBold18.drawCenteredString("Binds", this.keybindsDraggable.getX() + n8 / 2 - 22, (float)this.keybindsDraggable.getY() + 3.5f, bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
                SmartScissor.push();
                SmartScissor.setFromComponentCoordinates((double)this.keybindsDraggable.getX(), (double)this.keybindsDraggable.getY(), (double)n8, 16.0f + this.realOffset);
                n13 = -1;
                object2 = object3.iterator();
                while (object2.hasNext()) {
                    Module entityPlayerSP = (Module)object2.next();
                    Fonts.nunitoBold16.drawString(entityPlayerSP.getName(), this.keybindsDraggable.getX() + 5, (float)this.keybindsDraggable.getY() + 18.0f + (float)n13, bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB());
                    String string = " [" + (String)(entityPlayerSP.bind < 0 ? "MOUSE " + entityPlayerSP.getMouseBind() : Keyboard.getKeyName((int)entityPlayerSP.getBind())) + "]";
                    Fonts.nunitoBold16.drawString(string, this.keybindsDraggable.getX() + n8 - Fonts.nunitoBold15.getStringWidth(string) - 5, (float)this.keybindsDraggable.getY() + 18.0f + (float)n13, bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB());
                    n13 += 11;
                }
                SmartScissor.unset();
                SmartScissor.pop();
                GlStateManager.popMatrix();
            }
            if (elements.get(4)) {
                EntityLivingBase entityLivingBase;
                list = AimBot.target != null ? AimBot.target.getTarget() : null;
                EntityLivingBase entityLivingBase2 = entityLivingBase = AimBotDayz.target != null ? AimBotDayz.target.getTarget() : null;
                if (entityLivingBase != null) {
                    this.currentTarget = entityLivingBase;
                } else if (list != null) {
                    this.currentTarget = list;
                } else if (Hud.mc.currentScreen instanceof GuiChat) {
                    this.currentTarget = Hud.mc.player;
                }
                if (this.currentTarget != null) {
                    if (list == null && entityLivingBase == null && !(Hud.mc.currentScreen instanceof GuiChat)) {
                        this.animation.setDirection(Direction.BACKWARDS);
                    } else {
                        this.animation.setDirection(Direction.FORWARDS);
                    }
                    RenderUtility.scaleStart(this.targetHudDraggable.getX() + 56, this.targetHudDraggable.getY() + 19, this.animation.getOutput());
                    RenderUtility.drawGradientGlow((float)this.targetHudDraggable.getX(), (float)this.targetHudDraggable.getY(), 112.0f, 38.0f, 5, bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220));
                    RenderUtility.drawRoundedRect(this.targetHudDraggable.getX(), this.targetHudDraggable.getY(), 112.0f, 38.0f, 5.0f, bl ? new Color(30, 30, 30, 180).getRGB() : new Color(255, 255, 255, 220).getRGB());
                    if (this.currentTarget instanceof EntityPlayer) {
                        StencilUtility.initStencilToWrite();
                        RenderUtility.drawRoundedRect(this.targetHudDraggable.getX() + 4, this.targetHudDraggable.getY() + 4, 30.0f, 30.0f, 5.0f, -1);
                        StencilUtility.readStencilBuffer(1);
                        float f = Hud.getHurtPercent(this.currentTarget);
                        GlStateManager.color(1.0f, 1.0f - f, 1.0f - f, 1.0f);
                        mc.getTextureManager().bindTexture(((AbstractClientPlayer)this.currentTarget).getLocationSkin());
                        GlStateManager.enableTexture2D();
                        GlStateManager.pushMatrix();
                        Gui.drawScaledCustomSizeModalRect(this.targetHudDraggable.getX() + 4, this.targetHudDraggable.getY() + 4, 8.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
                        GlStateManager.popMatrix();
                        StencilUtility.uninitStencilBuffer();
                    } else {
                        Fonts.tenacityBold28.drawCenteredString("?", this.targetHudDraggable.getX() + 19, (float)(this.targetHudDraggable.getY() + 19) - (float)Fonts.tenacityBold28.getFontHeight() / 2.0f, bl ? Color.WHITE.getRGB() : Color.BLACK.getRGB());
                    }
                    StencilUtility.initStencilToWrite();
                    RenderUtility.drawGradientGlow((float)this.targetHudDraggable.getX(), (float)this.targetHudDraggable.getY(), 112.0f, 38.0f, 5, bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220), bl ? new Color(30, 30, 30, 180) : new Color(255, 255, 255, 220));
                    RenderUtility.drawRoundedRect(this.targetHudDraggable.getX(), this.targetHudDraggable.getY(), 112.0f, 38.0f, 5.0f, bl ? new Color(30, 30, 30, 180).getRGB() : new Color(255, 255, 255, 220).getRGB());
                    StencilUtility.readStencilBuffer(1);
                    object2 = StarClient.getInstance().getModuleManager().getModule(NameProtect.class);
                    Fonts.tenacityBold18.drawSubstring(TextFormatting.getTextWithoutFormattingCodes(((Module)object2).isEnabled() ? this.currentTarget.getName().replaceAll(Hud.mc.player.getName(), NameProtect.protectedNick) : this.currentTarget.getName()), this.targetHudDraggable.getX() + 38, this.targetHudDraggable.getY() + 4, bl ? Color.WHITE.getRGB() : Color.BLACK.getRGB(), 56.0f);
                    StencilUtility.uninitStencilBuffer();
                    n = 38;
                    for (ItemStack itemStack : this.currentTarget.getEquipmentAndArmor()) {
                        RenderUtility.drawRoundedRect(this.targetHudDraggable.getX() + n, this.targetHudDraggable.getY() + 14, 10.0f, 10.0f, 4.0f, bl ? new Color(22, 22, 22).getRGB() : new Color(175, 175, 175).getRGB());
                        if (!itemStack.isEmpty()) {
                            GlStateManager.pushMatrix();
                            GlStateManager.translate(this.targetHudDraggable.getX() + n + 1, this.targetHudDraggable.getY() + 15, 0.0f);
                            GlStateManager.scale(0.5, 0.5, 0.5);
                            RenderUtility.drawItemStack(itemStack, 0, 0);
                            GL11.glPopMatrix();
                        }
                        n += 12;
                    }
                    this.hp = Hud.mc.player.getDistanceToEntity(this.currentTarget) * 1.0f;
                    String string = String.valueOf((int)Math.floor(this.hp));
                    Fonts.mntssb14.drawCenteredString(string + " \u0431\u043b\u043e\u043a\u043e\u0432", this.targetHudDraggable.getX() + 69, this.targetHudDraggable.getY() + 29, bl ? Color.WHITE.getRGB() : Color.BLACK.getRGB());
                    RenderUtility.scaleEnd();
                }
            }
            GlStateManager.popMatrix();
            if (elements.get(3)) {
                list = Lists.reverse(Hud.mc.player.inventory.armorInventory);
                for (int i = 0; i < 4; ++i) {
                    RenderUtility.drawItemStack(list.get(i), this.armorHudDraggable.getX() + i * 18, this.armorHudDraggable.getY());
                }
            }
            if (elements.get(5) && !Hud.mc.gameSettings.showDebugInfo && Timer.smart.get()) {
                float f = this.timerHudDraggable.getX();
                float f2 = this.timerHudDraggable.getY();
                GlStateManager.pushMatrix();
                float f3 = (float)Timer.getProgress();
                float f4 = Math.max(f3 * 75.0f, 1.0f);
                Timer.animWidth = (float)MathHelper.clampedLerp(Timer.animWidth, f4, 10.0 * AnimationMath.deltaTime());
                RenderUtility.drawRoundedRect(f, f2, 75.0f, 10.0f, 2.0f, new Color(25, 25, 25, 110).getRGB());
                RenderUtility.drawGradientGlow(f, f2, Timer.animWidth, 10.0f, 5, n3, n2, n3, n2);
                RenderUtility.drawRoundedGradientRect(f, f2, Timer.animWidth, 10.0f, 2.0f, 2.0f, n3, n2, n3, n2);
                n7 = (int)(f3 * 100.0f);
                Fonts.mntssb14.drawCenteredStringWithShadow(n7 + "%", f + 39.0f, f2 + 3.4f, -1);
                GlStateManager.popMatrix();
            }
            if (elements.get(7)) {
                GlStateManager.pushMatrix();
                int n14 = bl ? new Color(255, 255, 255).getRGB() : new Color(30, 30, 30, 230).getRGB();
                int n15 = bl ? new Color(30, 30, 30, 152).getRGB() : new Color(255, 255, 255, 152).getRGB();
                int n16 = bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB();
                EntityPlayerSP entityPlayerSP = Minecraft.getMinecraft().player;
                List list2 = Minecraft.getMinecraft().world.playerEntities.stream().filter(entityPlayer2 -> entityPlayer2 != entityPlayerSP).filter(entityPlayer -> !this.isBot((EntityPlayer)entityPlayer)).filter(entityPlayer2 -> this.isPlayerNearby(entityPlayerSP, (EntityPlayer)entityPlayer2) || this.isPlayerLoaded((EntityPlayer)entityPlayer2)).sorted((entityPlayer, entityPlayer2) -> Boolean.compare(this.isFriend((EntityPlayer)entityPlayer2), this.isFriend((EntityPlayer)entityPlayer))).collect(Collectors.toList());
                int n11 = 125;
                int n12 = 15;
                int n13 = 16;
                int n17 = n12 + list2.size() * n13 + 4;
                this.playerListDraggable.setWidth(n11);
                this.playerListDraggable.setHeight(n17);
                int n18 = n11 - 17;
                int n19 = n17 - 4;
                if (this.background.get()) {
                    RenderUtility.Cornered(this.playerListDraggable.getX(), this.playerListDraggable.getY(), n18, n19, 5.0f, 0.0f, 5.0f, 0.0f, n15);
                } else {
                    RenderUtility.drawBlur(() -> RenderUtility.Cornered(this.playerListDraggable.getX(), this.playerListDraggable.getY(), n21, n22, 5.0f, 0.0f, 5.0f, 0.0f, n15), 8.0f);
                }
                RenderUtility.Cornered(this.playerListDraggable.getX(), this.playerListDraggable.getY(), n18, n12, 5.0f, 0.0f, 5.0f, 0.0f, n16);
                Fonts.newicons24.drawString("D", this.playerListDraggable.getX() + 3, this.playerListDraggable.getY() + (n12 - Fonts.newicons24.getFontHeight()) / 2 + 1, new Color(15, 148, 216, 255).getRGB());
                Fonts.nunitoBold18.drawString("Player List", this.playerListDraggable.getX() + 16, this.playerListDraggable.getY() + (n12 - Fonts.nunitoBold18.getFontHeight()) / 2 + 1, n14);
                int n20 = n12 + 2;
                for (EntityPlayer entityPlayer3 : list2) {
                    String string = entityPlayer3.getName();
                    double d = entityPlayerSP.getDistance(entityPlayer3);
                    String string2 = Math.round(d) + "m";
                    NameProtect nameProtect = (NameProtect)StarClient.getInstance().getModuleManager().getModule(NameProtect.class);
                    String string3 = nameProtect.isEnabled() ? this.formatNameWithProtection(string) : this.formatNameWithoutProtection(string);
                    float f = this.playerListDraggable.getY() + n20 + (n13 - Fonts.nunitoBold16.getFontHeight()) / 2;
                    Fonts.nunitoBold16.drawString(string3, this.playerListDraggable.getX() + 3, f, new Color(255, 255, 255, 220).getRGB());
                    int n21 = Fonts.mntssb14.getStringWidth(string2);
                    Fonts.mntssb14.drawString(string2, this.playerListDraggable.getX() + n18 - n21 - 3, f + 1.0f, new Color(255, 255, 255, 220).getRGB());
                    n20 += n13;
                }
                GlStateManager.popMatrix();
            }
        }
        if (elements.get(8)) {
            n = Keyboard.isKeyDown((int)17);
            n6 = Keyboard.isKeyDown((int)31) ? 1 : 0;
            boolean bl = Keyboard.isKeyDown((int)30);
            n5 = Keyboard.isKeyDown((int)32) ? 1 : 0;
            n4 = Keyboard.isKeyDown((int)57) ? 1 : 0;
            n3 = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme()) ? 1 : 0;
            n2 = n3 != 0 ? new Color(30, 30, 30, 100).getRGB() : new Color(255, 255, 255, 75).getRGB();
            Color color = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[1];
            Color color2 = StarClient.getInstance().getThemeManager().getCurrentStyleTheme().getColors()[0];
            this.wAlpha = n4 != 0 ? Math.min(1.0f, this.wAlpha + 0.05f) : Math.max(0.0f, this.wAlpha - 0.05f);
            this.sAlpha = bl ? Math.min(1.0f, this.sAlpha + 0.05f) : Math.max(0.0f, this.sAlpha - 0.05f);
            this.aAlpha = n5 != 0 ? Math.min(1.0f, this.aAlpha + 0.05f) : Math.max(0.0f, this.aAlpha - 0.05f);
            this.dAlpha = n6 != 0 ? Math.min(1.0f, this.dAlpha + 0.05f) : Math.max(0.0f, this.dAlpha - 0.05f);
            this.spaceAlpha = n != 0 ? Math.min(1.0f, this.spaceAlpha + 0.05f) : Math.max(0.0f, this.spaceAlpha - 0.05f);
            RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 10, this.width, 20.0f, 7.0f, n2);
            RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n2);
            RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n2);
            RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX() + 44, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, n2);
            RenderUtility.drawRoundedRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 54, (float)this.width + 45.0f, 20.0f, 7.0f, n2);
            RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 54, this.width + 45, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.wAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.wAlpha * 200.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.wAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.wAlpha * 200.0f)));
            RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.sAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.sAlpha * 200.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.sAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.sAlpha * 200.0f)));
            RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 44, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.aAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.aAlpha * 200.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.aAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.aAlpha * 200.0f)));
            RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.dAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.dAlpha * 200.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.dAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.dAlpha * 200.0f)));
            RenderUtility.drawRoundedGradientRect(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 10, this.width, 20.0f, 7.0f, 1.0f, ColorUtility.setAlpha(color.getRGB(), (int)(this.spaceAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.spaceAlpha * 200.0f)), ColorUtility.setAlpha(color.getRGB(), (int)(this.spaceAlpha * 200.0f)), ColorUtility.setAlpha(color2.getRGB(), (int)(this.spaceAlpha * 200.0f)));
            if (n4 != 0) {
                RenderUtility.drawGradientGlow(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 54, this.width + 45, 20.0f, 8, color, color2);
            }
            if (bl) {
                RenderUtility.drawGradientGlow(this.KeyStrokesDraggable.getX(), this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 8, color, color2);
            }
            if (n5 != 0) {
                RenderUtility.drawGradientGlow(this.KeyStrokesDraggable.getX() + 44, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 8, color, color2);
            }
            if (n6 != 0) {
                RenderUtility.drawGradientGlow(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 32, this.width, 20.0f, 8, color, color2);
            }
            if (n != 0) {
                RenderUtility.drawGradientGlow(this.KeyStrokesDraggable.getX() + 22, this.KeyStrokesDraggable.getY() + 10, this.width, 20.0f, 8, color, color2);
            }
            Fonts.tenacityBold18.drawString("W", this.KeyStrokesDraggable.getX() + 27, (float)this.KeyStrokesDraggable.getY() + 16.5f, -1);
            Fonts.tenacityBold18.drawString("S", this.KeyStrokesDraggable.getX() + 30, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
            Fonts.tenacityBold18.drawString("A", this.KeyStrokesDraggable.getX() + 7, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
            Fonts.tenacityBold18.drawString("D", (float)this.KeyStrokesDraggable.getX() + 51.5f, (float)this.KeyStrokesDraggable.getY() + 38.5f, -1);
            Fonts.tenacityBold18.drawCenteredString("SPACE", (float)(this.KeyStrokesDraggable.getX() + this.width) + 13.0f, (float)this.KeyStrokesDraggable.getY() + 60.5f, -1);
        }
    }

    private boolean aBolen() {
        return Hud.mc.gameSettings.keyBindLeft.isKeyDown();
    }

    private boolean sBolen() {
        return Hud.mc.gameSettings.keyBindBack.isKeyDown();
    }

    private boolean dBolen() {
        return Hud.mc.gameSettings.keyBindRight.isKeyDown();
    }

    private boolean wBolen() {
        return Hud.mc.gameSettings.keyBindForward.isKeyDown();
    }

    private boolean spacBolen() {
        return Hud.mc.gameSettings.keyBindJump.isKeyDown();
    }

    private boolean mouseBolen() {
        return Hud.mc.gameSettings.keyBindAttack.isKeyDown();
    }

    private String formatNameWithProtection(String string) {
        if (StarClient.getInstance().getFriendManager().isFriend(string) || string.equals(Hud.mc.player.getName())) {
            return String.valueOf(ChatFormatting.GREEN) + "[F] " + String.valueOf(ChatFormatting.RESET) + NameProtect.protectedNick;
        }
        return String.valueOf(ChatFormatting.RED) + "[B] " + String.valueOf(ChatFormatting.RESET) + string;
    }

    private String formatNameWithoutProtection(String string) {
        return StarClient.getInstance().getFriendManager().isFriend(string) ? String.valueOf(ChatFormatting.GREEN) + "[F] " + String.valueOf(ChatFormatting.RESET) + string : string;
    }

    private boolean isBot(EntityPlayer entityPlayer) {
        UUID uUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + entityPlayer.getName()).getBytes(StandardCharsets.UTF_8));
        return !entityPlayer.getUniqueID().equals(uUID);
    }

    private boolean isPlayerNearby(EntityPlayer entityPlayer, EntityPlayer entityPlayer2) {
        return entityPlayer.getDistance(entityPlayer2) <= 30.0;
    }

    private boolean isFriend(EntityPlayer entityPlayer) {
        return StarClient.getInstance().getFriendManager().isFriend(entityPlayer.getName());
    }

    private boolean isPlayerLoaded(EntityPlayer entityPlayer) {
        return Minecraft.getMinecraft().world.loadedEntityList.contains(entityPlayer);
    }

    public static String getPotionPower(PotionEffect potionEffect) {
        if (potionEffect.getAmplifier() == 1) {
            return "II";
        }
        if (potionEffect.getAmplifier() == 2) {
            return "III";
        }
        if (potionEffect.getAmplifier() == 3) {
            return "IV";
        }
        if (potionEffect.getAmplifier() == 4) {
            return "V";
        }
        if (potionEffect.getAmplifier() == 5) {
            return "VI";
        }
        if (potionEffect.getAmplifier() == 6) {
            return "VII";
        }
        if (potionEffect.getAmplifier() == 7) {
            return "VIII";
        }
        if (potionEffect.getAmplifier() == 8) {
            return "IX";
        }
        return potionEffect.getAmplifier() == 9 ? "X" : "";
    }

    public static String getDuration(PotionEffect potionEffect) {
        return potionEffect.getIsPotionDurationMax() ? "**:**" : StringUtils.ticksToElapsedTime(potionEffect.getDuration());
    }

    private static float getHurtPercent(EntityLivingBase entityLivingBase) {
        return ((float)entityLivingBase.hurtTime - (entityLivingBase.hurtTime != 0 ? Hud.mc.timer.field_194148_c : 0.0f)) / 10.0f;
    }

    private String getText(Module module) {
        return module.getName() + " [" + (String)(module.bind < 0 ? "MOUSE " + module.getMouseBind() : Keyboard.getKeyName((int)module.getBind())) + "]";
    }
}
