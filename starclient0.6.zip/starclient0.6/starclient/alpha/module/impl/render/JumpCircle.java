package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.utility.render.AntiAliasingUtility;
import starclient.alpha.utility.render.animation.AnimationMath;

@ModuleAnnotation(name="JumpCircle", category=Category.RENDER)
public class JumpCircle
extends Module {
    public static ArrayList<Circle> circles = new ArrayList();

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        circles.removeIf(circle -> circle.age > 990.0);
    }

    @EventTarget
    public void onRender(EventRender3D eventRender3D) {
        for (Circle circle : circles) {
            this.renderCircle(circle, eventRender3D.getPartialTicks());
            circle.age = AnimationMath.fast((float)circle.age, 1000.0f, 2.0f);
        }
    }

    private void renderCircle(Circle circle, float f) {
        if (!(circle.age >= 1000.0)) {
            double d;
            double d2;
            Color color;
            int n;
            double d3 = -(JumpCircle.mc.player.lastTickPosX + (JumpCircle.mc.player.posX - JumpCircle.mc.player.lastTickPosX) * (double)f);
            double d4 = -(JumpCircle.mc.player.lastTickPosY + (JumpCircle.mc.player.posY - JumpCircle.mc.player.lastTickPosY) * (double)f);
            double d5 = -(JumpCircle.mc.player.lastTickPosZ + (JumpCircle.mc.player.posZ - JumpCircle.mc.player.lastTickPosZ) * (double)f);
            GlStateManager.pushMatrix();
            GL11.glDepthMask((boolean)false);
            GlStateManager.enableDepth();
            GlStateManager.translate(d3, d4, d5);
            GlStateManager.enableBlend();
            GL11.glBlendFunc((int)770, (int)771);
            GlStateManager.disableTexture2D();
            GL11.glDisable((int)2884);
            GL11.glShadeModel((int)7425);
            GL11.glDisable((int)3008);
            AntiAliasingUtility.hook(true, false, false);
            GlStateManager.alphaFunc(516, 0.0f);
            GL11.glBegin((int)8);
            for (n = 0; n <= 360; ++n) {
                color = Arraylist.getColor(n);
                d2 = Math.cos((double)n * Math.PI / 180.0);
                d = Math.sin((double)n * Math.PI / 180.0);
                GL11.glColor4d((double)((float)new Color(color.getRGB()).getRed() / 255.0f), (double)((float)new Color(color.getRGB()).getGreen() / 255.0f), (double)((float)new Color(color.getRGB()).getBlue() / 255.0f), (double)0.0);
                GL11.glVertex3d((double)(circle.x + d2 * circle.age / 1000.0 * 1.5), (double)circle.y, (double)(circle.z + d * circle.age / 1000.0 * 1.5));
                GL11.glColor4d((double)((float)new Color(color.getRGB()).getRed() / 255.0f), (double)((float)new Color(color.getRGB()).getGreen() / 255.0f), (double)((float)new Color(color.getRGB()).getBlue() / 255.0f), (double)(0.5 - circle.age / 2000.0));
                GL11.glVertex3d((double)(circle.x + d2 * (circle.age / 1000.0)), (double)circle.y, (double)(circle.z + d * (circle.age / 1000.0)));
            }
            GL11.glEnd();
            GL11.glBegin((int)8);
            for (n = 0; n <= 360; ++n) {
                color = Arraylist.getColor(n);
                d2 = Math.cos((double)n * Math.PI / 180.0);
                d = Math.sin((double)n * Math.PI / 180.0);
                GL11.glColor4d((double)((float)new Color(color.getRGB()).getRed() / 255.0f), (double)((float)new Color(color.getRGB()).getGreen() / 255.0f), (double)((float)new Color(color.getRGB()).getBlue() / 255.0f), (double)(0.9 - circle.age / 1100.0));
                GL11.glVertex3d((double)(circle.x + d2 * (circle.age / 1000.0)), (double)circle.y, (double)(circle.z + d * (circle.age / 1000.0)));
                GL11.glColor4d((double)((float)new Color(color.getRGB()).getRed() / 255.0f), (double)((float)new Color(color.getRGB()).getGreen() / 255.0f), (double)((float)new Color(color.getRGB()).getBlue() / 255.0f), (double)0.0);
                GL11.glVertex3d((double)(circle.x + d2 * circle.age / 1000.0 * 0.5), (double)circle.y, (double)(circle.z + d * circle.age / 1000.0 * 0.5));
            }
            GL11.glEnd();
            AntiAliasingUtility.unhook(true, false, false);
            GL11.glEnable((int)3008);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GL11.glEnable((int)2884);
            GlStateManager.resetColor();
            GL11.glDepthMask((boolean)true);
            GlStateManager.popMatrix();
        }
    }

    public static class Circle {
        double x;
        double y;
        double z;
        double age;

        public Circle(double d, double d2, double d3) {
            this.x = d;
            this.y = d2;
            this.z = d3;
            this.age = 0.0;
        }
    }
}
