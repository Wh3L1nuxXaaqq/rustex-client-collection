package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketCustomSound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.AnimationUtils;
import starclient.alpha.StarClient;
import starclient.alpha.event.misc.EventKeyBoard;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.manager.dragging.DragManager;
import starclient.alpha.manager.dragging.Draggable;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.AntiAliasingUtility;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="ExpInfo", category=Category.RENDER)
public class ExpInfo
extends Module {
    public static ModeSetting tracerMode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c \u043f\u0440\u043e\u0435\u043a\u0446\u0438\u0438", "\u041b\u0438\u043d\u0438\u0438", "\u041b\u0438\u043d\u0438\u0438", "\u0421\u0442\u0440\u0435\u043b\u043a\u0438");
    public BooleanSetting background = new BooleanSetting("Potato mode", true);
    private final Draggable siDraggable = DragManager.create(this, "Exp Info", 250, 100);
    int chouse = -1;
    AnimationUtils animChouse;
    AnimationUtils animSize;
    ArrayList<Ex> exes = new ArrayList();

    public ExpInfo() {
        this.animChouse = new AnimationUtils(0.0f, 0.0f, 0.1f);
        this.animSize = new AnimationUtils(15.0f, 15.0f, 0.1f);
    }

    @EventTarget
    public void keyBoard(EventKeyBoard eventKeyBoard) {
        if (this.exes.size() > 0) {
            if (eventKeyBoard.getKey() == 200) {
                this.chouse = this.chouse == -1 ? this.exes.size() - 1 : --this.chouse;
            }
            if (eventKeyBoard.getKey() == 208) {
                this.chouse = this.chouse == this.exes.size() - 1 ? -1 : ++this.chouse;
            }
            if (eventKeyBoard.getKey() == 203) {
                if (this.chouse == -1) {
                    for (Ex ex : this.exes) {
                        ex.remove();
                    }
                } else {
                    this.exes.get(this.chouse).remove();
                }
            }
            if (eventKeyBoard.getKey() == 205 && this.chouse != -1) {
                this.exes.get((int)this.chouse).use = !this.exes.get((int)this.chouse).use;
            }
        }
    }

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketCustomSound sPacketCustomSound;
        if (eventReceivePacket.getPacket() instanceof SPacketCustomSound && ExpInfo.mc.player.getDistanceSq((sPacketCustomSound = (SPacketCustomSound)eventReceivePacket.getPacket()).getX(), sPacketCustomSound.getY(), sPacketCustomSound.getZ()) > 5.0 && (sPacketCustomSound.getSoundName().contains("shoot") || sPacketCustomSound.getSoundName().contains("explosion") || sPacketCustomSound.getSoundName().contains("separate") && sPacketCustomSound.getSoundName().contains("grenade_launcher")) && !sPacketCustomSound.getSoundName().contains("prepare") && !sPacketCustomSound.getSoundName().contains("fail") && !sPacketCustomSound.getSoundName().contains("rocket_launcher")) {
            if (this.exes.size() > 0) {
                boolean bl = true;
                for (Ex ex : this.exes) {
                    if (!ex.id.replaceAll(".3p", "").equals(sPacketCustomSound.getSoundName().replaceAll(".3p", ""))) continue;
                    Vec3d vec3d = new Vec3d(sPacketCustomSound.getX(), sPacketCustomSound.getY(), sPacketCustomSound.getZ());
                    if (!(Utils.getDistance(vec3d, ex.pos) < 80.0)) continue;
                    ++ex.count;
                    bl = false;
                }
                if (bl && this.exes.size() <= 20) {
                    this.exes.add(new Ex(new Vec3d(sPacketCustomSound.getX(), sPacketCustomSound.getY(), sPacketCustomSound.getZ()), sPacketCustomSound.getSoundName()));
                }
            } else if (this.exes.size() <= 20) {
                this.exes.add(new Ex(new Vec3d(sPacketCustomSound.getX(), sPacketCustomSound.getY(), sPacketCustomSound.getZ()), sPacketCustomSound.getSoundName()));
            }
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        this.siDraggable.setWidth(125.0f);
        if (tracerMode.is("\u041b\u0438\u043d\u0438\u0438")) {
            RenderUtility.glColor(Color.white.getRGB());
            ExpInfo.mc.gameSettings.viewBobbing = false;
            ExpInfo.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 2);
            GL11.glPushMatrix();
            GL11.glEnable((int)2848);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2896);
            GL11.glDepthMask((boolean)false);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glLineWidth((float)1.0E-6f);
            for (Ex ex : this.exes) {
                if (!ex.use) continue;
                Color color = Color.ORANGE;
                double d = ex.pos.xCoord - ExpInfo.mc.getRenderManager().viewerPosX;
                double d2 = ex.pos.yCoord - ExpInfo.mc.getRenderManager().viewerPosY;
                double d3 = ex.pos.zCoord - ExpInfo.mc.getRenderManager().viewerPosZ;
                float f = (float)color.getRed() / 255.0f;
                float f2 = (float)color.getGreen() / 255.0f;
                float f3 = (float)color.getBlue() / 255.0f;
                float f4 = (float)color.getAlpha() / 255.0f;
                GL11.glPushMatrix();
                boolean bl = ExpInfo.mc.gameSettings.viewBobbing;
                ExpInfo.mc.gameSettings.viewBobbing = false;
                ExpInfo.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 2);
                ExpInfo.mc.gameSettings.viewBobbing = bl;
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glEnable((int)3042);
                GL11.glLineWidth((float)1.0f);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2929);
                AntiAliasingUtility.hook(true, false, false);
                GL11.glDepthMask((boolean)false);
                GlStateManager.color(f, f2, f3, f4);
                GL11.glBegin((int)3);
                Vec3d vec3d = new Vec3d(0.0, 0.0, 1.0).rotatePitch((float)(-Math.toRadians(ExpInfo.mc.player.rotationPitch))).rotateYaw((float)(-Math.toRadians(ExpInfo.mc.player.rotationYaw)));
                GL11.glVertex3d((double)vec3d.xCoord, (double)(vec3d.yCoord + (double)ExpInfo.mc.player.getEyeHeight()), (double)vec3d.zCoord);
                GL11.glVertex3d((double)d, (double)d2, (double)d3);
                GL11.glEnd();
                AntiAliasingUtility.unhook(true, false, false);
                GL11.glEnable((int)3553);
                GL11.glEnable((int)2929);
                GL11.glDepthMask((boolean)true);
                GL11.glDisable((int)3042);
                GL11.glPopMatrix();
                GlStateManager.resetColor();
            }
            GL11.glDisable((int)3042);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)2848);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glPopMatrix();
            RenderUtility.glColor(Color.white.getRGB());
        }
    }

    @EventTarget
    public void render2D(EventRender2D eventRender2D) {
        if (tracerMode.is("\u0421\u0442\u0440\u0435\u043b\u043a\u0438")) {
            for (Ex ex : this.exes) {
                if (!ex.use) continue;
                GlStateManager.pushMatrix();
                double d = Math.toDegrees(Math.atan2(ex.pos.zCoord - ExpInfo.mc.player.posZ, ex.pos.xCoord - ExpInfo.mc.player.posX)) - (double)ExpInfo.mc.player.rotationYaw - 90.0;
                GL11.glTranslated((double)((double)new ScaledResolution(mc).getScaledWidth() / 2.0 + 1.0), (double)((double)new ScaledResolution(mc).getScaledHeight() / 2.0), (double)0.0);
                GL11.glTranslated((double)(Math.cos(Math.toRadians(d - 90.0)) * 20.0), (double)(Math.sin(Math.toRadians(d - 90.0)) * 20.0), (double)0.0);
                GL11.glRotated((double)d, (double)0.0, (double)0.0, (double)1.0);
                RenderUtility.drawImage(new ResourceLocation("starclient/textures/triangle.png"), -9, -10, 17, 17, -1);
                GlStateManager.popMatrix();
            }
        }
        if (!ExpInfo.mc.gameSettings.showDebugInfo) {
            int n = StarClient.getInstance().getC(0).getRGB();
            int n2 = StarClient.getInstance().getC(500).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            float f = this.siDraggable.getX();
            float f2 = this.siDraggable.getY();
            if (this.chouse > this.exes.size() - 1) {
                this.chouse = this.exes.size() > 0 ? this.exes.size() - 1 : -1;
            }
            for (int i = 0; i < this.exes.size(); ++i) {
                if (this.exes.get((int)i).anim.getAnim() != 0.0f || this.exes.get((int)i).anim.to != 0.0f) continue;
                this.exes.remove(i);
            }
            this.siDraggable.setHeight(15 + this.exes.size() * 16 + 4);
            this.animSize.to = this.siDraggable.getHeight();
            if (this.background.get()) {
                RenderUtility.Cornered(this.siDraggable.getX(), this.siDraggable.getY(), this.siDraggable.getWidth() - 17.0f, this.siDraggable.getHeight() - 4.0f, 5.0f, 0.0f, 5.0f, 0.0f, bl ? new Color(30, 30, 30, 153).getRGB() : new Color(255, 255, 255, 153).getRGB());
            } else {
                RenderUtility.drawBlur(() -> RenderUtility.Cornered(this.siDraggable.getX(), this.siDraggable.getY(), this.siDraggable.getWidth() - 17.0f, this.siDraggable.getHeight() - 4.0f, 5.0f, 0.0f, 5.0f, 0.0f, bl ? new Color(30, 30, 30, 153).getRGB() : new Color(255, 255, 255, 153).getRGB()), 8.0f);
            }
            RenderUtility.Cornered(this.siDraggable.getX(), this.siDraggable.getY(), 108.0f, 15.0f, 5.0f, 0.0f, 5.0f, 0.0f, bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB());
            Fonts.newicons20.drawString("E", f + this.siDraggable.getWidth() / 2.0f - 58.0f, (f2 += 3.0f) + 3.0f + 1.5f - (float)(Fonts.mntsb16.getFontHeight() / 2), new Color(15, 148, 216, 255).getRGB());
            Fonts.nunitoBold18.drawCenteredString("ExpInfo", f + this.siDraggable.getWidth() / 2.0f - 29.0f, f2 + 3.0f - (float)(Fonts.mntsb16.getFontHeight() / 2), bl ? new Color(255, 255, 255, 220).getRGB() : new Color(30, 30, 30, 230).getRGB());
            this.animChouse.to = this.chouse * 16;
            float f3 = 15.0f;
            for (Ex ex : this.exes) {
                ex.render(f, f3 + f2);
                f3 += ex.getFontHeight();
            }
            if (this.chouse != -1) {
                int n3 = ColorUtility.interpolateColorC(n, n2, 0.5f).getRGB();
                RenderUtility.drawGradientGlow(f, f2 + 10.0f + this.animChouse.getAnim() + 6.5f, 1.0f, 8.0f, 8, new Color(n), new Color(n2));
                RenderUtility.drawGradientGlow(f + 107.0f, f2 + 10.0f + this.animChouse.getAnim() + 6.5f, 1.0f, 8.0f, 8, new Color(n), new Color(n2));
                RenderUtility.drawRect(f, f2 + 10.0f + this.animChouse.getAnim() + 6.5f, 1.0f, 8.0f, n3);
                RenderUtility.drawRect(f + 107.0f, f2 + 10.0f + this.animChouse.getAnim() + 6.5f, 1.0f, 8.0f, n3);
            }
        }
    }

    public class Ex {
        Vec3d pos;
        String id;
        int count = 1;
        long time;
        boolean discontinuous = false;
        boolean use = false;
        AnimationUtils anim = new AnimationUtils(0.0f, 1.0f, 0.05f);

        public Ex(Vec3d vec3d, String string) {
            this.pos = vec3d;
            this.id = string;
            this.time = System.currentTimeMillis();
        }

        public void render(float f, float f2) {
            int n = new Color(35, 35, 35).getRGB();
            int n2 = StarClient.getInstance().getC(0).getRGB();
            int n3 = StarClient.getInstance().getC(500).getRGB();
            int n4 = ColorUtility.interpolateColorC(n2, n3, 0.5f).getRGB();
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            GL11.glPushMatrix();
            ItemStack itemStack = new ItemStack(Items.DIAMOND_SHOVEL);
            String string = this.id;
            if (this.id.contains("shoot") || this.id.contains("separate")) {
                int n5 = 0;
                if (this.id.contains("bow") && !this.id.contains("prepare")) {
                    n5 = 720;
                    string = "\u041b\u0443\u043a";
                } else if (this.id.contains("semi_auto_rifle")) {
                    n5 = 713;
                    string = "\u0411\u0435\u0440\u0434\u0430\u043d\u043a\u0430";
                } else if (this.id.contains("smg")) {
                    n5 = 710;
                    string = "SMG";
                } else if (this.id.contains("thompson")) {
                    n5 = 714;
                    string = "\u0422\u043e\u043c\u0438\u043a";
                } else if (this.id.contains("python")) {
                    n5 = 716;
                    string = "\u041f\u0438\u0442\u043e\u043d";
                } else if (this.id.contains("assault_rifle")) {
                    n5 = 702;
                    string = "\u041a\u0430\u043b\u0430\u0448";
                } else if (this.id.contains("double")) {
                    n5 = 722;
                    string = "\u0414\u0432\u0443\u0448\u043a\u0430";
                } else if (this.id.contains("spas12")) {
                    n5 = 707;
                    string = "Spas-12";
                } else if (this.id.contains("mp5")) {
                    n5 = 709;
                    string = "MP5";
                } else if (this.id.contains("pump")) {
                    n5 = 717;
                    string = "\u041f\u043e\u043c\u043f";
                } else if (this.id.contains("pipe")) {
                    n5 = 700;
                    string = "\u041f\u0430\u0439\u043f";
                } else if (this.id.contains("bolt")) {
                    n5 = 703;
                    string = "\u0411\u043e\u043b\u0442";
                } else if (this.id.contains("revolver")) {
                    n5 = 711;
                    string = "\u0420\u0435\u0432\u0438\u043a";
                } else if (this.id.contains("hmlmg")) {
                    n5 = 724;
                    string = "HMLMG";
                } else if (this.id.contains("grenade_launcher") || this.id.contains("start")) {
                    n5 = 725;
                    string = "\u0413\u0440\u0430\u043d\u0430\u0442\u043e\u043c\u0451\u0442";
                } else if (this.id.contains("semi_auto_pistol")) {
                    n5 = 701;
                    string = "\u041f\u0435\u0448\u043a\u0430";
                } else if (this.id.contains("m39")) {
                    n5 = 719;
                    string = "M39";
                } else if (this.id.contains("prototype")) {
                    n5 = 727;
                    string = "\u0413\u043b\u043e\u043a-17";
                } else if (this.id.contains("l96")) {
                    n5 = 715;
                    string = "L96";
                } else if (this.id.contains("nailgun")) {
                    n5 = 712;
                    string = "\u0413\u0432\u043e\u0437\u0434\u0438\u043a";
                } else if (this.id.contains("m249")) {
                    n5 = 724;
                    string = "M249";
                } else if (this.id.contains("lr300")) {
                    n5 = 706;
                    string = "LR-300";
                } else if (this.id.contains("m92")) {
                    n5 = 705;
                    string = "M92";
                } else if (this.id.contains("eoka")) {
                    n5 = 704;
                    string = "\u0421\u0430\u043c\u043e\u043f\u0430\u043b";
                } else if (this.id.contains("speargun") || this.id.contains("guntrap")) {
                    n5 = 16;
                    string = "\u0413\u0430\u043d\u0442\u0440\u0430\u043f";
                } else if (this.id.contains("m4_shotgun") || this.id.contains("gun.m4")) {
                    n5 = 749;
                    string = "\u0414\u0440\u043e\u0431\u043e\u0432\u0438\u043a \u041c4";
                }
                itemStack.itemDamage = n5;
            } else if (this.id.contains("explosion")) {
                if (this.id.contains("explosive_rifle_bullet")) {
                    itemStack = new ItemStack(Items.field_190930_cZ);
                    string = "Explosive";
                }
                if (this.id.contains("satchel_charge")) {
                    itemStack = new ItemStack(Items.FLINT);
                    string = "Satchel Charge";
                }
                if (this.id.contains("grenade_f1")) {
                    itemStack = new ItemStack(Items.BOOK);
                    string = "F1 Grenade";
                }
                if (this.id.contains("beancan_grenade")) {
                    itemStack = new ItemStack(Items.SPECKLED_MELON);
                    string = "Beancan Grenade";
                }
                if (this.id.contains("timed_explosive_charge")) {
                    itemStack = new ItemStack(Items.SLIME_BALL);
                    string = "C4";
                }
                if (this.id.contains("rocket")) {
                    itemStack = new ItemStack(Items.PRISMARINE_SHARD);
                    string = "Rocket";
                }
                if (this.id.contains("grenade_40mm_he")) {
                    itemStack = new ItemStack(Items.DIAMOND_PICKAXE);
                    string = "HE Grenade";
                    itemStack.itemDamage = 725;
                }
            }
            if (this.id.contains("explosive_rifle_bullet")) {
                GL11.glPushMatrix();
                GL11.glPopMatrix();
            }
            Fonts.mntssb14.drawString(string, f + 3.0f - 100.0f + this.anim.getAnim() * 100.0f + 0.5f, f2 + 5.0f - (float)(Fonts.mntssb14.getFontHeight() / 2) + 0.7f, this.use ? n2 : (bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB()));
            String string2 = Math.round(Utility.mc.player.getDistance(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord)) + "m";
            if (this.count > 1) {
                string2 = string2 + " x" + this.count;
            }
            Fonts.mntssb14.drawString(string2, f + 22.0f + this.anim.getAnim() * 85.0f - (float)Fonts.mntssb14.getStringWidth(string2 + " "), f2 + 5.0f - (float)(Fonts.mntssb14.getFontHeight() / 2) + 0.7f, this.use ? n2 : (bl ? Color.WHITE.getRGB() : Color.WHITE.getRGB()));
            GL11.glPopMatrix();
        }

        public void remove() {
            this.anim.to = 0.0f;
        }

        public float getFontHeight() {
            return 16.0f * this.anim.getAnim();
        }
    }
}
