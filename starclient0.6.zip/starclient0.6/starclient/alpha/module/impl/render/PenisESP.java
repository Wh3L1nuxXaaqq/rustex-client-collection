package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.glu.Sphere;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="PiskaPokazat", category=Category.RENDER)
public class PenisESP
extends Module {
    public void esp(EntityPlayer entityPlayer, double d, double d2, double d3) {
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)true);
        GL11.glLineWidth((float)1.0f);
        GL11.glTranslated((double)d, (double)d2, (double)d3);
        GL11.glRotatef((float)(-entityPlayer.rotationYaw), (float)0.0f, (float)entityPlayer.height, (float)0.0f);
        GL11.glTranslated((double)(-d), (double)(-d2), (double)(-d3));
        GL11.glTranslated((double)d, (double)(d2 + (double)(entityPlayer.height / 2.0f) - (double)0.225f), (double)d3);
        GL11.glColor4f((float)1.38f, (float)0.55f, (float)2.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.075f);
        Cylinder cylinder = new Cylinder();
        cylinder.setDrawStyle(100013);
        cylinder.draw(0.1f, 0.11f, StarClient.role.endsWith("+") ? 5.4f : 0.4f, 25, 20);
        GL11.glColor4f((float)1.38f, (float)0.85f, (float)1.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)-0.12500000298023223);
        GL11.glTranslated((double)-0.09000000074505805, (double)0.0, (double)0.0);
        Sphere sphere = new Sphere();
        sphere.setDrawStyle(100013);
        sphere.draw(0.14f, 10, 20);
        GL11.glTranslated((double)0.16000000149011612, (double)0.0, (double)0.0);
        Sphere sphere2 = new Sphere();
        sphere2.setDrawStyle(100013);
        sphere2.draw(0.14f, 15, 50);
        GL11.glColor4f((float)1.35f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)-0.07000000074505806, (double)0.0, (double)(StarClient.role.endsWith("+") ? 5.589999952316284 : 0.589999952316284));
        Sphere sphere3 = new Sphere();
        sphere3.setDrawStyle(100013);
        sphere3.draw(0.13f, 15, 20);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onRender3d(EventRender3D eventRender3D) {
        for (Entity entity : PenisESP.mc.world.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            EntityPlayer entityPlayer = (EntityPlayer)entity;
            double d = entityPlayer.posX;
            mc.getRenderManager();
            double d2 = d - Minecraft.getMinecraft().getRenderManager().viewerPosX;
            double d3 = entityPlayer.posY;
            mc.getRenderManager();
            double d4 = d3 - Minecraft.getMinecraft().getRenderManager().viewerPosY;
            double d5 = entityPlayer.posZ;
            mc.getRenderManager();
            double d6 = d5 - Minecraft.getMinecraft().getRenderManager().viewerPosZ;
            GL11.glPushMatrix();
            RenderHelper.disableStandardItemLighting();
            this.esp(entityPlayer, d2, d4, d6);
            RenderHelper.enableStandardItemLighting();
            GL11.glPopMatrix();
        }
    }
}
