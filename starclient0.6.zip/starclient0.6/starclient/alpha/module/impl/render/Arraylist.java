package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.renderer.GlStateManager;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.manager.theme.Themes;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.Hud;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.font.FontRenderer;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="Arraylist", category=Category.RENDER)
public class Arraylist
extends Module {
    public BooleanSetting hideRender = new BooleanSetting("Hide Render", false);
    public BooleanSetting shadow = new BooleanSetting("Shadow", true);
    public BooleanSetting line = new BooleanSetting("Line", true);
    public BooleanSetting box = new BooleanSetting("Box", true);
    public BooleanSetting lowerCase = new BooleanSetting("Lower Case", false);
    public static NumberSetting colorSpeed = new NumberSetting("Color speed", 6.0f, 1.0f, 9.0f, 1.0f);
    public ModeSetting mode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "\u041d\u043e\u0432\u044b\u0439", "\u041d\u043e\u0432\u044b\u0439", "\u0420\u0430\u0437\u0434\u0435\u043b\u044c\u043d\u044b\u0439");

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        if (!Arraylist.mc.gameSettings.showDebugInfo) {
            Animation animation;
            String string;
            float f = 5.0f;
            float f2 = StarClient.getInstance().getModuleManager().getModule(Hud.class).isEnabled() && Hud.elements.get(0) ? 24.0f : 5.0f;
            int n = 0;
            int n2 = 0;
            boolean bl = StarClient.getInstance().getThemeManager().getCurrentGuiTheme().equals(Themes.DARK.getTheme());
            GlStateManager.pushMatrix();
            List<Module> list = this.getSortedModules();
            if (this.hideRender.get()) {
                for (Module module : list) {
                    if (this.hideRender.get() && module.getCategory() == Category.RENDER || this.hideRender.get() && module.getCategory() == Category.PLAYER) continue;
                    string = this.lowerCase.get() ? module.getName().toLowerCase() : module.getName();
                    animation = module.getAnimation();
                    animation.setDirection(module.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);
                    if (!module.isEnabled() && animation.finished(Direction.FORWARDS)) continue;
                    if (!animation.isDone()) {
                        RenderUtility.scaleStart(f - 1.0f + (float)(this.getFont().getStringWidth(string) + 8 + (this.getFont().equals(Fonts.mntssb13) ? 1 : 0)) / 2.0f, f2 + (float)n - 1.0f + 6.5f, animation.getOutput());
                        RenderUtility.scaleEnd();
                    }
                    n = (int)((float)n + animation.getOutput() * 9.0f);
                    ++n2;
                }
            }
            n = 0;
            n2 = 0;
            for (Module module : list) {
                if (this.hideRender.get() && module.getCategory() == Category.RENDER || this.hideRender.get() && module.getCategory() == Category.PLAYER) continue;
                string = this.lowerCase.get() ? module.getName().toLowerCase() : module.getName();
                animation = module.getAnimation();
                animation.setDirection(module.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);
                if (!module.isEnabled() && animation.finished(Direction.BACKWARDS)) continue;
                GlStateManager.disableBlend();
                GlStateManager.popMatrix();
                if (this.mode.is("\u041d\u043e\u0432\u044b\u0439")) {
                    GlStateManager.pushMatrix();
                    var12_12 = animation.getOutput();
                    var13_13 = (1.0f - var12_12) * -20.0f;
                    GlStateManager.translate(var13_13, 0.0f, 0.0f);
                    GlStateManager.enableBlend();
                    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                    GlStateManager.color(1.0f, 1.0f, 1.0f, var12_12);
                    var14_14 = 0;
                    var15_15 = StarClient.getInstance().getC(var14_14 += 25).getRGB();
                    var16_16 = StarClient.getInstance().getC(500 + var14_14).getRGB();
                    float f3 = var17_17 = this.line.get() ? 1.0f : 0.0f;
                    if (this.shadow.get()) {
                        RenderUtility.drawGradientGlow(f + var17_17 - 1.0f, f2 + (float)n + 0.5f, (float)(this.getFont().getStringWidth(string) + 5), 9.5f, 10, var15_15, var16_16, var15_15, var16_16);
                    }
                    if (this.box.get()) {
                        RenderUtility.Cornered(f + var17_17, f2 + (float)n, this.getFont().getStringWidth(string) + 4, 11.0f, 0.0f, 0.0f, 5.0f, 5.0f, bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB());
                    }
                    this.getFont().drawGradientString(string, f + 2.0f + var17_17 + (float)(this.getFont().equals(Fonts.minecraft13) ? 1 : 0), f2 + (float)n + (11.0f - (float)this.getFont().getStringHeight(string)) / 2.0f + 1.0f, new Color(var15_15).brighter(), new Color(var16_16).brighter());
                    if (this.line.get()) {
                        RenderUtility.drawVGradientRect(f + 1.0f, f2 + (float)n, f - 1.0f, f2 + (float)n + 11.0f, var15_15, var16_16);
                    }
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.disableBlend();
                    GlStateManager.popMatrix();
                    n = (int)((float)n + var12_12 * 1.0f);
                    if (!animation.isDone()) {
                        RenderUtility.scaleEnd();
                        GlStateManager.popMatrix();
                    }
                    n = (int)((float)n + animation.getOutput() * 10.0f);
                } else if (this.mode.is("\u0420\u0430\u0437\u0434\u0435\u043b\u044c\u043d\u044b\u0439")) {
                    GlStateManager.pushMatrix();
                    var12_12 = animation.getOutput();
                    var13_13 = (1.0f - var12_12) * -20.0f;
                    GlStateManager.translate(var13_13, 0.0f, 0.0f);
                    GlStateManager.enableBlend();
                    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                    GlStateManager.color(1.0f, 1.0f, 1.0f, var12_12);
                    var14_14 = 0;
                    var15_15 = StarClient.getInstance().getC(var14_14 += 25).getRGB();
                    var16_16 = StarClient.getInstance().getC(500 + var14_14).getRGB();
                    float f4 = var17_17 = this.line.get() ? 1.0f : 0.0f;
                    if (this.shadow.get()) {
                        RenderUtility.drawFixedGlow(f + var17_17, f2 + (float)n, this.getFont().getStringWidth(string) + 4, 11.0f, 10, var15_15);
                    }
                    if (this.box.get()) {
                        RenderUtility.Cornered(f + var17_17, f2 + (float)n, this.getFont().getStringWidth(string) + 4, 11.0f, 0.0f, 0.0f, 5.0f, 5.0f, bl ? new Color(30, 30, 30, 230).getRGB() : new Color(255, 255, 255, 220).getRGB());
                    }
                    if (this.line.get()) {
                        RenderUtility.drawVGradientRect(f + 2.0f, f2 + (float)n, f - 0.5f, f2 + (float)n + 11.0f, var15_15, var16_16);
                    }
                    this.getFont().drawGradientString(string, f + 2.0f + var17_17 + (float)(this.getFont().equals(Fonts.minecraft13) ? 1 : 0), f2 + (float)n + (11.0f - (float)this.getFont().getStringHeight(string)) / 2.0f + 1.0f, new Color(var15_15), new Color(var16_16));
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.disableBlend();
                    GlStateManager.popMatrix();
                    if (!animation.isDone()) {
                        RenderUtility.scaleEnd();
                        GlStateManager.popMatrix();
                    }
                    n = (int)((float)n + animation.getOutput() * 12.0f);
                }
                ++n2;
            }
        }
    }

    public List<Module> getSortedModules() {
        return StarClient.getInstance().getModuleManager().getModules().stream().sorted((module, module2) -> {
            float f = this.getFont().getStringWidth(this.lowerCase.get() ? module.getName().toLowerCase() : module.getName());
            float f2 = this.getFont().getStringWidth(this.lowerCase.get() ? module2.getName().toLowerCase() : module2.getName());
            return Float.compare(f2, f);
        }).collect(Collectors.toList());
    }

    public FontRenderer getFont() {
        return Fonts.mntssb16;
    }

    public static Color getColor(int n) {
        Color color = StarClient.getInstance().getC(0);
        Color color2 = StarClient.getInstance().getC(500);
        return ColorUtility.gradient((int)(10.0f - colorSpeed.get()), n * 2, color, color2);
    }

    public static Color getArrayColor(int n) {
        Color color = StarClient.getInstance().getC(0);
        Color color2 = StarClient.getInstance().getC(500);
        return ColorUtility.gradient((int)(10.0f - colorSpeed.get()), n * 20, color, color2);
    }
}
