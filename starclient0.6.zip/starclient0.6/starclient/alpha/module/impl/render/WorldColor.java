package starclient.alpha.module.impl.render;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ColorSetting;

@ModuleAnnotation(name="WorldColor", category=Category.RENDER)
public class WorldColor
extends Module {
    public ColorSetting color = new ColorSetting("\u0426\u0432\u0435\u0442", -1);
}
