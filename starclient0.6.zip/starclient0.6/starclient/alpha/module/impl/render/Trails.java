package starclient.alpha.module.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.Arraylist;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.AntiAliasingUtility;
import starclient.alpha.utility.render.ColorUtility;

@ModuleAnnotation(name="Trails", category=Category.PLAYER)
public class Trails
extends Module {
    private final NumberSetting removeTicks = new NumberSetting("\u0412\u0440\u0435\u043c\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f", 100.0f, 100.0f, 500.0f, 1.0f);
    public ArrayList<Point> points = new ArrayList();

    @EventTarget
    public void onRender(EventRender3D eventRender3D) {
        if (Trails.mc.gameSettings.thirdPersonView != 0 && Trails.mc.player.isEntityAlive()) {
            boolean bl = Trails.mc.gameSettings.viewBobbing;
            Trails.mc.gameSettings.viewBobbing = false;
            Trails.mc.entityRenderer.setupCameraTransform(eventRender3D.getPartialTicks(), 2);
            Trails.mc.gameSettings.viewBobbing = bl;
            if (!Trails.mc.gameSettings.showDebugInfo) {
                int n;
                Point point2;
                float f;
                Color color;
                double d = -(Trails.mc.player.lastTickPosX + (Trails.mc.player.posX - Trails.mc.player.lastTickPosX) * (double)eventRender3D.getPartialTicks());
                double d2 = -(Trails.mc.player.lastTickPosY + (Trails.mc.player.posY - Trails.mc.player.lastTickPosY) * (double)eventRender3D.getPartialTicks());
                double d3 = -(Trails.mc.player.lastTickPosZ + (Trails.mc.player.posZ - Trails.mc.player.lastTickPosZ) * (double)eventRender3D.getPartialTicks());
                float f2 = (float)(Trails.mc.player.lastTickPosX + (Trails.mc.player.posX - Trails.mc.player.lastTickPosX) * (double)eventRender3D.getPartialTicks());
                float f3 = (float)(Trails.mc.player.lastTickPosY + (Trails.mc.player.posY - Trails.mc.player.lastTickPosY) * (double)eventRender3D.getPartialTicks());
                float f4 = (float)(Trails.mc.player.lastTickPosZ + (Trails.mc.player.posZ - Trails.mc.player.lastTickPosZ) * (double)eventRender3D.getPartialTicks());
                if (Trails.mc.player.motionX != 0.0 && Trails.mc.player.motionZ != 0.0) {
                    this.points.add(new Point(new Vec3d(f2, f3, f4)));
                }
                this.points.removeIf(point -> (float)point.time >= this.removeTicks.get());
                GlStateManager.pushMatrix();
                GL11.glDepthMask((boolean)false);
                GlStateManager.translate(d, d2, d3);
                GlStateManager.enableBlend();
                GL11.glBlendFunc((int)770, (int)771);
                GlStateManager.disableTexture2D();
                GL11.glDisable((int)2884);
                GL11.glShadeModel((int)7425);
                GL11.glDisable((int)3008);
                GlStateManager.alphaFunc(516, 0.0f);
                AntiAliasingUtility.hook(true, false, false);
                GL11.glBegin((int)8);
                for (Point point3 : this.points) {
                    color = Arraylist.getColor(this.points.indexOf(point3));
                    if (this.points.indexOf(point3) >= this.points.size() - 1) continue;
                    f = 100.0f * ((float)this.points.indexOf(point3) / (float)this.points.size());
                    point2 = this.points.get(this.points.indexOf(point3) + 1);
                    n = ColorUtility.setAlpha(new Color(color.getRGB()).getRGB(), (int)f);
                    ColorUtility.setColor(n);
                    GL11.glVertex3d((double)point2.pos.x, (double)point2.pos.y, (double)point2.pos.z);
                    GL11.glVertex3d((double)point2.pos.x, (double)(point2.pos.y + (double)Trails.mc.player.height - 0.1), (double)point2.pos.z);
                    ++point3.time;
                }
                GL11.glEnd();
                GL11.glLineWidth((float)2.0f);
                GL11.glBegin((int)3);
                for (Point point3 : this.points) {
                    color = Arraylist.getColor(this.points.indexOf(point3));
                    if (this.points.indexOf(point3) >= this.points.size() - 1) continue;
                    f = (float)new Color(color.getRGB()).getAlpha() * ((float)this.points.indexOf(point3) / (float)this.points.size());
                    point2 = this.points.get(this.points.indexOf(point3) + 1);
                    n = ColorUtility.setAlpha(ColorUtility.fade(5, this.points.indexOf(point3) * 10, new Color(color.getRGB()), 1.0f).brighter().getRGB(), (int)f);
                    ColorUtility.setColor(n);
                    GL11.glVertex3d((double)point2.pos.x, (double)point2.pos.y, (double)point2.pos.z);
                    ++point3.time;
                }
                GL11.glEnd();
                GL11.glBegin((int)3);
                for (Point point3 : this.points) {
                    color = Arraylist.getColor(this.points.indexOf(point3));
                    if (this.points.indexOf(point3) >= this.points.size() - 1) continue;
                    f = (float)new Color(color.getRGB()).getAlpha() * ((float)this.points.indexOf(point3) / (float)this.points.size());
                    point2 = this.points.get(this.points.indexOf(point3) + 1);
                    n = ColorUtility.setAlpha(ColorUtility.fade(5, this.points.indexOf(point3) * 10, new Color(color.getRGB()), 1.0f).brighter().getRGB(), (int)f);
                    ColorUtility.setColor(n);
                    GL11.glVertex3d((double)point2.pos.x, (double)(point2.pos.y + (double)Trails.mc.player.height - 0.1), (double)point2.pos.z);
                    ++point3.time;
                }
                GL11.glEnd();
                AntiAliasingUtility.unhook(true, false, false);
                GL11.glEnable((int)3008);
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
                GL11.glEnable((int)2884);
                GlStateManager.resetColor();
                GL11.glDepthMask((boolean)true);
                GlStateManager.popMatrix();
            }
        }
    }

    public static class Point {
        public Vec3d pos;
        public long time;

        public Point(Vec3d vec3d) {
            this.pos = vec3d;
        }
    }
}
