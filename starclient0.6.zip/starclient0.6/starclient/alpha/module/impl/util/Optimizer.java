package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="Optimizer", category=Category.UTIL)
public class Optimizer
extends Module {
    public static boolean a;

    @Override
    public void onEnable() {
        a = true;
    }

    @Override
    public void onDisable() {
        a = false;
    }
}
