package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.TimerUtils;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.math.MathUtility;

@ModuleAnnotation(name="FakeLags", category=Category.UTIL)
public class FakeLags
extends Module {
    public NumberSetting cooldown = new NumberSetting("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 50.0f, 10.0f, 250.0f, 10.0f);
    float ticks = 3.0f;
    TimerUtils timer = new TimerUtils();
    int state = 0;
    ArrayList<Packet> packets = new ArrayList();
    Vec3d pos = new Vec3d(0.0, 0.0, 0.0);
    public EntityPlayer player;
    public static int direction;
    float range = 0.2f;

    public void setMotion(double d, float f, double d2, double d3) {
        double d4 = d3;
        double d5 = d2;
        float f2 = f;
        if (d3 != 0.0) {
            if (d2 > 0.0) {
                f2 = f + (float)(d3 > 0.0 ? -45 : 45);
            } else if (d2 < 0.0) {
                f2 = f + (float)(d3 > 0.0 ? 45 : -45);
            }
            d5 = 0.0;
            if (d3 > 0.0) {
                d4 = 1.0;
            } else if (d3 < 0.0) {
                d4 = -1.0;
            }
        }
        if (d5 > 0.0) {
            d5 = 1.0;
        } else if (d5 < 0.0) {
            d5 = -1.0;
        }
        double d6 = Math.cos(Math.toRadians(f2 + 90.0f));
        double d7 = Math.sin(Math.toRadians(f2 + 90.0f));
        this.player.motionX = d4 * d * d6 + d5 * d * d7;
        this.player.motionZ = d4 * d * d7 - d5 * d * d6;
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        FakeLags.mc.player.noClip = true;
        boolean bl = true;
        if (FakeLags.mc.currentScreen != null) {
            this.state = 0;
        }
        if (this.timer.hasReached((long)this.ticks * (long)this.cooldown.getInt())) {
            this.state = 0;
            this.timer.reset();
            this.ticks = MathUtility.getRandomInRange(10, 5);
        }
        if (this.state == 0) {
            for (Packet packet : this.packets) {
                mc.getConnection().sendPacket(packet);
            }
            this.packets.clear();
            this.state = 1;
            this.player.setPosition(FakeLags.mc.player.posX, FakeLags.mc.player.posY, FakeLags.mc.player.posZ);
            this.pos = new Vec3d(FakeLags.mc.player.posX, FakeLags.mc.player.posY, FakeLags.mc.player.posZ);
        }
        FakeLags.mc.player.noClip = true;
    }

    @EventTarget
    public void sendPacket(EventSendPacket eventSendPacket) {
        boolean bl = true;
        if (FakeLags.mc.player != null && this.state == 1 && !(eventSendPacket.getPacket() instanceof CPacketAnimation)) {
            this.packets.add(eventSendPacket.getPacket());
            eventSendPacket.setCancelled(true);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Packet packet : this.packets) {
            mc.getConnection().sendPacket(packet);
        }
        if (this.player != null && FakeLags.mc.world != null) {
            FakeLags.mc.world.removeEntityFromWorld(-7777);
            this.player = null;
        }
        this.packets.clear();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (FakeLags.mc.world != null && FakeLags.mc.player != null) {
            this.player = new EntityOtherPlayerMP(FakeLags.mc.world, new GameProfile(UUID.fromString("6714531a-1c69-438e-b7d6-d6d41ca6838b"), "FakeLags"));
            this.player.copyLocationAndAnglesFrom(FakeLags.mc.player);
            this.player.inventory.copyInventory(FakeLags.mc.player.inventory);
            FakeLags.mc.world.addEntityToWorld(-7777, this.player);
        } else {
            this.setToggled(false);
        }
    }
}
