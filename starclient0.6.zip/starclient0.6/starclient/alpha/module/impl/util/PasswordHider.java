package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="PasswordHider", category=Category.UTIL)
public class PasswordHider
extends Module {
}
