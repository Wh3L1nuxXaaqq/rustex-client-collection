package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.misc.SoundUtility;

@ModuleAnnotation(name="ClientSounds", category=Category.UTIL)
public class ClientSounds
extends Module {
    public static ModeSetting modeSetting = new ModeSetting("Sound-Mode", "Sigma", "Discord", "Sigma", "Nurik", "Bubbles", "Pop", "Heavy");
    public static NumberSetting volume = new NumberSetting("Volume", 0.5f, 0.0f, 1.0f, 0.1f);

    @Override
    public void onEnable() {
        super.onEnable();
        this.playSoundOnEnable();
    }

    @Override
    public void onDisable() {
        this.playSoundOnDisable();
        super.onDisable();
    }

    private void playSoundOnEnable() {
        ClientSounds.playSound("enable");
    }

    private void playSoundOnDisable() {
        ClientSounds.playSound("disable");
    }

    public static void playSound(String string) {
        float f = volume.get();
        switch (modeSetting.get()) {
            case "Discord": {
                ClientSounds.playDiscordSound(string, f);
                break;
            }
            case "Sigma": {
                ClientSounds.playSigmaSound(string, f);
                break;
            }
            case "Nurik": {
                ClientSounds.playNurikSound(string, f);
                break;
            }
            case "Bubbles": {
                ClientSounds.playBubblesSound(string, f);
                break;
            }
            case "Pop": {
                ClientSounds.playPopSound(string, f);
                break;
            }
            case "Heavy": {
                ClientSounds.playHeavySound(string, f);
                break;
            }
        }
    }

    private static void playDiscordSound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("discord_enable.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("discord_disable.wav", f);
        }
    }

    private static void playSigmaSound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("sigma_enable.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("sigma_disable.wav", f);
        }
    }

    private static void playNurikSound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("new_enable.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("new_disable.wav", f);
        }
    }

    private static void playBubblesSound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("enable_bubbles.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("disable_bubbles.wav", f);
        }
    }

    private static void playPopSound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("enablepop.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("disablepop.wav", f);
        }
    }

    private static void playHeavySound(String string, float f) {
        if (string.equals("enable")) {
            SoundUtility.playSound("heavyenable.wav", f);
        } else if (string.equals("disable")) {
            SoundUtility.playSound("heavydisable.wav", f);
        }
    }
}
