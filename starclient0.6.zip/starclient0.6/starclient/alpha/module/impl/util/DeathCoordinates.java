package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketOpenWindow;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.misc.ChatUtility;

@ModuleAnnotation(name="DeathCoordinates", category=Category.UTIL)
public class DeathCoordinates
extends Module {
    @EventTarget
    public void onPiski(EventReceivePacket eventReceivePacket) {
        SPacketOpenWindow sPacketOpenWindow;
        String string;
        if (eventReceivePacket.getPacket() instanceof SPacketOpenWindow && ((string = (sPacketOpenWindow = (SPacketOpenWindow)eventReceivePacket.getPacket()).getWindowTitle().getUnformattedText()).contains("\u0420\u2019\u0421\u2039 \u0420\u0458\u0420\u00b5\u0421\u0402\u0421\u201a\u0420\u0406\u0421\u2039") || string.contains("Dead"))) {
            String string2 = DeathCoordinates.mc.player.getPosition().getX() + ", " + DeathCoordinates.mc.player.getPosition().getY() + ", " + DeathCoordinates.mc.player.getPosition().getZ();
            ChatUtility.addChatMessage(string2);
        }
    }
}
