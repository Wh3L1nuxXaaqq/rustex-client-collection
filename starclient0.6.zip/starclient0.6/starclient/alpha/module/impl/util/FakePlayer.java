package starclient.alpha.module.impl.util;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="FakePlayer", category=Category.UTIL)
public class FakePlayer
extends Module {
    public EntityPlayer player;

    @Override
    public void onEnable() {
        if (FakePlayer.mc.player != null && FakePlayer.mc.world != null) {
            this.player = new EntityOtherPlayerMP(FakePlayer.mc.world, new GameProfile(UUID.fromString("6714531a-1c69-438e-b7d6-d6d41ca6838b"), "FakePlayer"));
            this.player.copyLocationAndAnglesFrom(FakePlayer.mc.player);
            this.player.inventory.copyInventory(FakePlayer.mc.player.inventory);
            FakePlayer.mc.world.addEntityToWorld(-9151, this.player);
        }
    }

    @Override
    public void onDisable() {
        if (FakePlayer.mc.player != null && FakePlayer.mc.world != null) {
            FakePlayer.mc.world.removeEntityFromWorld(-9151);
        }
    }
}
