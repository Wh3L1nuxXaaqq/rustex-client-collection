package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventSwingArm;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="FastPeek", category=Category.UTIL)
public class FastPeek
extends Module {
    int state = 0;
    ArrayList<Packet> packets = new ArrayList();
    Vec3d pos = new Vec3d(0.0, 0.0, 0.0);
    public NumberSetting radius = new NumberSetting("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f", 1.5f, 0.1f, 5.0f, 0.1f);
    public EntityPlayer player;

    @EventTarget
    public void onSwing(EventSwingArm eventSwingArm) {
        if (eventSwingArm.getHand() == EnumHand.MAIN_HAND) {
            this.state = 0;
        }
    }

    @EventTarget
    public void render3D(EventRender3D eventRender3D) {
        int n = StarClient.getInstance().getC(0).getRGB();
        int n2 = StarClient.getInstance().getC(500).getRGB();
        int n3 = ColorUtility.interpolateColorC(n, n2, 0.5f).getRGB();
        RenderUtility.drawCircle3D(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord, this.radius.get(), n3);
    }

    @EventTarget
    public void sendPacket(EventSendPacket eventSendPacket) {
        if (FastPeek.mc.player != null && this.state == 1 && !(eventSendPacket.getPacket() instanceof CPacketAnimation)) {
            this.packets.add(eventSendPacket.getPacket());
            eventSendPacket.setCancelled(true);
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (FastPeek.mc.player.getDistance(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord) != 0.0) {
            this.state = 1;
        }
        if (FastPeek.mc.player.getDistance(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord) > (double)this.radius.get()) {
            this.state = 0;
        }
        if (FastPeek.mc.currentScreen != null) {
            this.state = 0;
        }
        if (this.state == 0) {
            for (Packet packet : this.packets) {
                mc.getConnection().sendPacket(packet);
            }
            this.packets.clear();
            this.state = 1;
            this.player.setPosition(FastPeek.mc.player.posX, FastPeek.mc.player.posY, FastPeek.mc.player.posZ);
            this.pos = new Vec3d(FastPeek.mc.player.posX, FastPeek.mc.player.posY, FastPeek.mc.player.posZ);
            this.setToggled(false);
        }
        FastPeek.mc.player.noClip = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Packet packet : this.packets) {
            mc.getConnection().sendPacket(packet);
        }
        if (this.player != null && FastPeek.mc.world != null) {
            FastPeek.mc.world.removeEntityFromWorld(-7777);
            this.player = null;
        }
        this.packets.clear();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.pos = new Vec3d(FastPeek.mc.player.posX, FastPeek.mc.player.posY, FastPeek.mc.player.posZ);
        this.state = 3;
        this.player = new EntityOtherPlayerMP(FastPeek.mc.world, new GameProfile(UUID.fromString("6714531a-1c69-438e-b7d6-d6d41ca6838b"), "FastPeek"));
        this.player.copyLocationAndAnglesFrom(FastPeek.mc.player);
        this.player.inventory.copyInventory(FastPeek.mc.player.inventory);
        FastPeek.mc.world.addEntityToWorld(-7777, this.player);
    }
}
