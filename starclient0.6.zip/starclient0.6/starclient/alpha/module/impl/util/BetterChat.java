package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;

@ModuleAnnotation(name="BetterChat", category=Category.UTIL)
public class BetterChat
extends Module {
    public static BooleanSetting chatHistory = new BooleanSetting("\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u044c \u0438\u0441\u0442\u043e\u0440\u0438\u044e", true);
    public static BooleanSetting chatAnimation = new BooleanSetting("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f \u0447\u0430\u0442\u0430", true);
    public static BooleanSetting background = new BooleanSetting("\u0423\u0431\u0440\u0430\u0442\u044c \u0444\u043e\u043d", true);
    public static BooleanSetting changeChat = new BooleanSetting("\u0418\u0437\u043c\u0435\u043d\u044f\u0442\u044c \u0447\u0430\u0442", true);
}
