package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import org.lwjgl.input.Mouse;
import starclient.alpha.StarClient;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.math.GCDFixUtility;
import starclient.alpha.utility.math.MathUtility;

@ModuleAnnotation(name="AntiAim", category=Category.UTIL)
public class AntiAim
extends Module {
    float rotation = 0.0f;
    float rotationp = 0.0f;
    public ModeSetting antiAimsMode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "Spin", "Spin", "Backwards");
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 50.0f, 10.0f, 150.0f, 1.0f);

    public AntiAim() {
        this.speed.setVisible(() -> this.antiAimsMode.is("Spin"));
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        boolean bl;
        boolean bl2 = StarClient.getInstance().getModuleManager().getModule(AimBot.class).isEnabled() ? !AimBot.work : (bl = true);
        if (bl && !Mouse.isButtonDown((int)0) && !Mouse.isButtonDown((int)1)) {
            if (this.antiAimsMode.is("Spin")) {
                eventUpdate.setRotationYaw(this.rotation);
                eventUpdate.setRotationPitch(this.rotationp);
                AntiAim.mc.player.rotationYawHead = this.rotation;
                AntiAim.mc.player.renderYawOffset = this.rotation;
                AntiAim.mc.player.rotationPitchHead = 180.0f;
                this.rotation += this.speed.get() / 2.0f;
                if (this.rotation > 180.0f) {
                    this.rotation = -180.0f;
                }
                this.rotationp += this.speed.get() / 2.0f;
                if (this.rotation > 180.0f) {
                    this.rotationp = -180.0f;
                }
            } else if (this.antiAimsMode.is("Backwards")) {
                float f = AntiAim.mc.player.rotationYaw + 180.0f + (AntiAim.mc.player.ticksExisted % 8 < 4 ? MathUtility.randomizeFloat(-90.0f, 90.0f) : -MathUtility.randomizeFloat(90.0f, -90.0f));
                eventUpdate.setRotationYaw(GCDFixUtility.getFixedRotation(f));
                AntiAim.mc.player.renderYawOffset = f;
                AntiAim.mc.player.rotationYawHead = f;
                AntiAim.mc.player.rotationPitchHead = -90.0f;
            }
        }
    }
}
