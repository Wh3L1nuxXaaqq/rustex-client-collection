package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;

@ModuleAnnotation(name="BetterTab", category=Category.UTIL)
public class BetterTab
extends Module {
    public static BooleanSetting animation = new BooleanSetting("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f", true);
    public static BooleanSetting changeTab = new BooleanSetting("\u0418\u0437\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0430\u0431", true);
}
