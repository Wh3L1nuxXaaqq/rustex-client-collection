package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.Items;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.ChatType;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.utility.render.RenderUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="GunHelper", category=Category.UTIL)
public class Indicators
extends Module {
    public float width;
    public String govno;
    public String ammo;
    public boolean reloading;
    public BooleanSetting reloadIndicator = new BooleanSetting("\u0418\u043d\u0434\u0438\u043a\u0430\u0442\u043e\u0440 \u043f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0434\u043a\u0438", true);
    public BooleanSetting ammoIndicator = new BooleanSetting("\u0418\u043d\u0434\u0438\u043a\u0430\u0442\u043e\u0440 \u043f\u0430\u0442\u0440\u043e\u043d\u043e\u0432", true);
    public boolean valid;

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketChat) {
            SPacketChat sPacketChat = (SPacketChat)eventReceivePacket.getPacket();
            String string = sPacketChat.getChatComponent().getUnformattedText();
            if (sPacketChat.getChatType() == ChatType.GAME_INFO) {
                this.width = this.getReloadWidth(string);
                if (string.contains("\u041f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0436\u0430\u044e") && this.reloadIndicator.get()) {
                    eventReceivePacket.setCancelled(true);
                    this.reloading = true;
                } else if (string.startsWith("\u00a7a") && this.ammoIndicator.get()) {
                    eventReceivePacket.setCancelled(true);
                }
            }
        }
        mc.addScheduledTask(() -> {
            if (Indicators.mc.player != null) {
                NBTTagList nBTTagList = Indicators.mc.player.getHeldItemMainhand().func_190925_c("display").getTagList("Lore", 8);
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < nBTTagList.tagCount(); ++i) {
                    String string = nBTTagList.getStringTagAt(i);
                    if (!string.contains("\u041f\u0430\u0442\u0440\u043e\u043d\u044b")) continue;
                    stringBuilder.append(nBTTagList.getStringTagAt(i)).append("\n");
                }
                this.ammo = stringBuilder.toString().replaceAll(".*\u00a77\\| ", "");
            }
        });
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (Indicators.mc.player.getHeldItemMainhand().getItem() != Items.DIAMOND_AXE || Indicators.mc.player.isDead) {
            this.reloading = false;
        }
    }

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if (this.ammoIndicator.get() && this.ammo != null) {
            Fonts.mntsb16.drawCenteredString(this.ammo, scaledResolution.getScaledWidth() / 2, scaledResolution.getScaledHeight() / 2 + 15, -1);
        }
        if (this.reloading && this.reloadIndicator.get()) {
            boolean bl;
            boolean bl2 = bl = !this.govno.equals("0");
            if (bl) {
                int n = StarClient.getInstance().getC(0).getRGB();
                int n2 = StarClient.getInstance().getC(500).getRGB();
                Fonts.mntsb16.drawCenteredString("\u041f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0436\u0430\u044e.. " + this.govno + "%", scaledResolution.getScaledWidth() / 2, scaledResolution.getScaledHeight() / 2 + 25, -1);
                RenderUtility.drawRoundedRect(scaledResolution.getScaledWidth() / 2 - 50, bl ? (float)(scaledResolution.getScaledHeight() / 2 + 35) : (float)(scaledResolution.getScaledHeight() / 2 + 25), 100.0f, 5.0f, 3.0f, new Color(22, 22, 22).getRGB());
                RenderUtility.drawRoundedGradientRect(scaledResolution.getScaledWidth() / 2 - 50, bl ? (float)(scaledResolution.getScaledHeight() / 2 + 35) : (float)(scaledResolution.getScaledHeight() / 2 + 25), this.width, 5.0f, 3.0f, 1.0f, n, n2, n, n);
                RenderUtility.drawGradientGlow((float)(scaledResolution.getScaledWidth() / 2 - 50), bl ? (float)(scaledResolution.getScaledHeight() / 2 + 35) : (float)(scaledResolution.getScaledHeight() / 2 + 25), this.width, 5.0f, 5, n, n2, n, n2);
            }
        }
    }

    public float getReloadWidth(String string) {
        if (string.contains("\u00a7a|||||||||||||||||||\u00a72|")) {
            this.govno = "5";
            return 5.0f;
        }
        if (string.contains("\u00a7a||||||||||||||||||\u00a72||")) {
            this.govno = "10";
            return 10.0f;
        }
        if (string.contains("\u00a7a|||||||||||||||||\u00a72|||")) {
            this.govno = "15";
            return 15.0f;
        }
        if (string.contains("\u00a7a||||||||||||||||\u00a72||||")) {
            this.govno = "20";
            return 20.0f;
        }
        if (string.contains("\u00a7a|||||||||||||||\u00a72|||||")) {
            this.govno = "25";
            return 25.0f;
        }
        if (string.contains("\u00a7a||||||||||||||\u00a72||||||")) {
            this.govno = "30";
            return 30.0f;
        }
        if (string.contains("\u00a7a|||||||||||||\u00a72|||||||")) {
            this.govno = "35";
            return 35.0f;
        }
        if (string.contains("\u00a7a||||||||||||\u00a72||||||||")) {
            this.govno = "40";
            return 40.0f;
        }
        if (string.contains("\u00a7a|||||||||||\u00a72|||||||||")) {
            this.govno = "45";
            return 45.0f;
        }
        if (string.contains("\u00a7a||||||||||\u00a72||||||||||")) {
            this.govno = "50";
            return 50.0f;
        }
        if (string.contains("\u00a7a|||||||||\u00a72|||||||||||")) {
            this.govno = "55";
            return 55.0f;
        }
        if (string.contains("\u00a7a||||||||\u00a72||||||||||||")) {
            this.govno = "60";
            return 60.0f;
        }
        if (string.contains("\u00a7a|||||||\u00a72|||||||||||||")) {
            this.govno = "65";
            return 65.0f;
        }
        if (string.contains("\u00a7a||||||\u00a72||||||||||||||")) {
            this.govno = "70";
            return 70.0f;
        }
        if (string.contains("\u00a7a|||||\u00a72|||||||||||||||")) {
            this.govno = "75";
            return 75.0f;
        }
        if (string.contains("\u00a7a||||\u00a72||||||||||||||||")) {
            this.govno = "80";
            return 80.0f;
        }
        if (string.contains("\u00a7a|||\u00a72|||||||||||||||||")) {
            this.govno = "85";
            return 85.0f;
        }
        if (string.contains("\u00a7a||\u00a72||||||||||||||||||")) {
            this.govno = "90";
            return 90.0f;
        }
        if (string.contains("\u00a7a|\u00a72|||||||||||||||||||")) {
            this.govno = "95";
            return 95.0f;
        }
        if (string.contains("\u00a7a\u00a72||||||||||||||||||||")) {
            this.govno = "100";
            this.reloading = false;
            return 100.0f;
        }
        this.govno = "0";
        return 0.0f;
    }
}
