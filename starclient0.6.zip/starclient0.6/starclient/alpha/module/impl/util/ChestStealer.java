package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Iterator;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.Slot;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.misc.TimerHelper;

@ModuleAnnotation(name="ChestStealer", category=Category.UTIL)
public class ChestStealer
extends Module {
    public NumberSetting cooldown = new NumberSetting("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 10.0f, 0.0f, 200.0f, 1.0f);
    private final TimerHelper timer = new TimerHelper();
    private boolean stealing;

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        ContainerChest containerChest;
        Iterator<Slot> iterator;
        String object2;
        if (!(ChestStealer.mc.currentScreen instanceof GuiContainer)) {
            this.stealing = false;
            return;
        }
        GuiContainer guiContainer = (GuiContainer)ChestStealer.mc.currentScreen;
        Container container = guiContainer.inventorySlots;
        if (container instanceof ContainerChest && ((object2 = (iterator = (containerChest = (ContainerChest)container).getLowerChestInventory()).getDisplayName().getUnformattedText()).equals("\u0421\u0445\u0440\u043e\u043d") || object2.equals("\u00a74\u0421\u0443\u043d\u0434\u0443\u043a \u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0430") || object2.equals("\u0425\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0430") || object2.equals("Ender Chest"))) {
            this.stealing = false;
            return;
        }
        boolean bl = false;
        for (Slot slot : container.inventorySlots) {
            if (slot.inventory == ChestStealer.mc.player.inventory || slot.getStack().isEmpty()) continue;
            bl = true;
            break;
        }
        if (!bl) {
            ChestStealer.mc.player.closeScreen();
            this.stealing = false;
            return;
        }
        this.stealing = true;
        if (this.timer.hasReached(this.cooldown.get())) {
            for (Slot slot : container.inventorySlots) {
                if (slot.inventory == ChestStealer.mc.player.inventory || slot.getStack().isEmpty()) continue;
                ChestStealer.mc.playerController.windowClick(container.windowId, slot.slotNumber, 0, ClickType.QUICK_MOVE, ChestStealer.mc.player);
                this.timer.reset();
                return;
            }
        }
    }
}
