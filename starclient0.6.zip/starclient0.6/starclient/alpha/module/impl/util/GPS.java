package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;
import starclient.alpha.StarClient;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.font.Fonts;

@ModuleAnnotation(name="GPS", category=Category.UTIL)
public class GPS
extends Module {
    public static double x = 0.0;
    public static double z = 0.0;
    public static String mode = "off";

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        if (mode.equalsIgnoreCase("on")) {
            ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            int n = scaledResolution.getScaledWidth() / 2;
            int n2 = scaledResolution.getScaledHeight() / 2;
            double d = Minecraft.getMinecraft().player.getDistance(x, Minecraft.getMinecraft().player.posY, z);
            String string = String.format("%.0fm", d);
            Fonts.nunitoBold16.drawStringWithShadow(string, (float)n - (float)Fonts.nunitoBold16.getStringWidth(string) / 2.0f, n2 + 40, Color.WHITE.getRGB());
            GL11.glPushMatrix();
            GL11.glTranslatef((float)n, (float)(n2 + 25), (float)0.0f);
            float f = this.getAngle(new BlockPos(x, 0.0, z));
            GL11.glRotatef((float)f, (float)0.0f, (float)0.0f, (float)1.0f);
            int n3 = StarClient.getInstance().getC(0).getRGB();
            GPS.drawTriangle(-4.0f, -1.0f, 5.0f, 8.0f, new Color(0, 0, 0, 32));
            GPS.drawTriangle(-3.0f, 0.0f, 4.0f, 6.0f, new Color(n3));
            GL11.glPopMatrix();
        }
    }

    private float getAngle(BlockPos blockPos) {
        double d = (double)blockPos.getX() - Minecraft.getMinecraft().player.posX;
        double d2 = (double)blockPos.getZ() - Minecraft.getMinecraft().player.posZ;
        float f = Minecraft.getMinecraft().player.rotationYaw;
        double d3 = Math.toDegrees(Math.atan2(d2, d)) - (double)f - 180.0;
        return (float)d3;
    }

    public static void drawTriangle(float f, float f2, float f3, float f4, Color color) {
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GPS.enableSmoothLine(1.0f);
        GL11.glRotatef((float)270.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glBegin((int)9);
        ColorUtility.setColor(color.getRGB());
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glEnd();
        GL11.glBegin((int)9);
        ColorUtility.setColor(color.brighter().getRGB());
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3 * 2.0f), (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glEnd();
        GL11.glBegin((int)3);
        ColorUtility.setColor(color.getRGB());
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glEnd();
        GL11.glBegin((int)3);
        ColorUtility.setColor(color.brighter().getRGB());
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)(f + f3 * 2.0f), (float)(f2 - 2.0f));
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glEnd();
        GPS.disableSmoothLine();
        GL11.glEnable((int)3553);
        GL11.glRotatef((float)-270.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static void enableSmoothLine(float f) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
    }

    private static void disableSmoothLine() {
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4354);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }
}
