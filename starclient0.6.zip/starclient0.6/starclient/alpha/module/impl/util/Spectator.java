package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Objects;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.misc.ChatUtility;

@ModuleAnnotation(name="Spectator", category=Category.UTIL)
public class Spectator
extends Module {
    private float old;
    private double oldX;
    private double oldY;
    private double oldZ;
    public static String playerName = "null";

    @Override
    public void onDisable() {
        if (Spectator.mc.player != null) {
            Spectator.mc.player.capabilities.isFlying = false;
            Spectator.mc.player.capabilities.setFlySpeed(this.old);
            Spectator.mc.player.noClip = false;
            Spectator.mc.renderGlobal.loadRenderers();
            Spectator.mc.player.setPositionAndRotation(this.oldX, this.oldY, this.oldZ, Spectator.mc.player.rotationYaw, Spectator.mc.player.rotationPitch);
            Spectator.mc.world.removeEntityFromWorld(-7776);
            Spectator.mc.player.motionZ = 0.0;
            Spectator.mc.player.motionX = 0.0;
        }
        super.onDisable();
    }

    @Override
    public void onEnable() {
        if (Spectator.mc.player != null) {
            this.oldX = Spectator.mc.player.posX;
            this.oldY = Spectator.mc.player.posY;
            this.oldZ = Spectator.mc.player.posZ;
            Spectator.mc.player.noClip = true;
            EntityOtherPlayerMP entityOtherPlayerMP = new EntityOtherPlayerMP(Spectator.mc.world, Spectator.mc.player.getGameProfile());
            entityOtherPlayerMP.copyLocationAndAnglesFrom(Spectator.mc.player);
            entityOtherPlayerMP.posY -= 0.0;
            entityOtherPlayerMP.rotationYawHead = Spectator.mc.player.rotationYawHead;
            Spectator.mc.world.addEntityToWorld(-7776, entityOtherPlayerMP);
        }
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (Spectator.mc.world.getPlayerEntityByName(playerName) == null) {
            ChatUtility.addChatMessage("\u0418\u0433\u0440\u043e\u043a\u0430 \u043d\u0435\u0442\u0443 \u0440\u044f\u0434\u043e\u043c \u0438\u043b\u0438 \u043e\u0435 \u0432\u044b\u0448\u0435\u043b \u0438\u0437 \u0437\u043e\u043d\u044b \u0432\u0438\u0434\u0438\u043c\u043e\u0441\u0442\u0438!");
            this.setToggled(false);
        }
        Spectator.mc.player.posX = Objects.requireNonNull(Spectator.mc.world.getPlayerEntityByName((String)Spectator.playerName)).posX;
        Spectator.mc.player.posY = Objects.requireNonNull(Spectator.mc.world.getPlayerEntityByName((String)Spectator.playerName)).posY;
        Spectator.mc.player.posZ = Objects.requireNonNull(Spectator.mc.world.getPlayerEntityByName((String)Spectator.playerName)).posZ;
        Spectator.mc.player.rotationYaw = Objects.requireNonNull(Spectator.mc.world.getPlayerEntityByName((String)Spectator.playerName)).rotationYaw;
        Spectator.mc.player.rotationPitch = Objects.requireNonNull(Spectator.mc.world.getPlayerEntityByName((String)Spectator.playerName)).rotationPitch;
        eventUpdate.setPosX(this.oldX);
        eventUpdate.setPosY(this.oldY);
        eventUpdate.setPosZ(this.oldZ);
    }

    @EventTarget
    public void onReceivePacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketPlayerPosLook) {
            eventReceivePacket.setCancelled(true);
        }
    }

    @EventTarget
    public void onSendPacket(EventSendPacket eventSendPacket) {
    }
}
