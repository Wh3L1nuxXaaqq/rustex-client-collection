package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.client.CPacketChatMessage;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="NoAntiSpam", category=Category.UTIL)
public class NoAntiSpam
extends Module {
    @EventTarget
    public void onPacketSend(EventSendPacket eventSendPacket) {
        if (eventSendPacket.getPacket() instanceof CPacketChatMessage) {
            CPacketChatMessage cPacketChatMessage = (CPacketChatMessage)eventSendPacket.getPacket();
            cPacketChatMessage.message = cPacketChatMessage.message.toLowerCase().replaceAll("\u0430", "a").replaceAll("\u0435", "e").replaceAll("\u0438", "u").replaceAll("\u043a", "k").replaceAll("\u043c", "m").replaceAll("\u043e", "o").replaceAll("\u0440", "p").replaceAll("\u0441", "c").replaceAll("\u0443", "y").replaceAll("\u0431", "6").replaceAll("\u0442", "t").replaceAll("\u0445", "x").replaceAll("\u0439", "u");
        }
    }
}
