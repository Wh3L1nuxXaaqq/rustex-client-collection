package starclient.alpha.module.impl.util;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.SPacketTitle;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.combat.AimBot;
import starclient.alpha.utility.misc.BullingUtility;
import starclient.alpha.utility.misc.ChatUtility;

@ModuleAnnotation(name="KillMessage", category=Category.UTIL)
public class KillMessage
extends Module {
    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketTitle) {
            SPacketTitle sPacketTitle = (SPacketTitle)eventReceivePacket.getPacket();
            String string2 = sPacketTitle.getMessage().getUnformattedText();
            StringBuilder stringBuilder = new StringBuilder();
            char[] cArray = string2.toCharArray();
            for (int i = 0; i < cArray.length; ++i) {
                if (cArray[i] == '\u00a7') {
                    ++i;
                    continue;
                }
                stringBuilder.append(cArray[i]);
            }
            if (string2.contains("(2 HP)") || string2.contains("(1 HP)") || string2.contains("(0 HP)")) {
                BullingUtility.bull().thenAccept(string -> {
                    if (string != null) {
                        ChatUtility.sendChatMessage("!" + AimBot.lastTarget.getTarget().getName() + " " + string);
                    }
                });
            }
        }
    }
}
