package starclient.alpha.module.impl.util;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="NameProtect", category=Category.UTIL)
public class NameProtect
extends Module {
    public static String protectedNick = "Zavarka";
}
