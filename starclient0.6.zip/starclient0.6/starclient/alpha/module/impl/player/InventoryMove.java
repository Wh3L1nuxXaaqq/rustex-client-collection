package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="InventoryMove", category=Category.UTIL)
public class InventoryMove
extends Module {
    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        KeyBinding[] keyBindingArray;
        for (KeyBinding keyBinding : keyBindingArray = new KeyBinding[]{InventoryMove.mc.gameSettings.keyBindForward, InventoryMove.mc.gameSettings.keyBindJump, InventoryMove.mc.gameSettings.keyBindBack, InventoryMove.mc.gameSettings.keyBindRight, InventoryMove.mc.gameSettings.keyBindLeft, InventoryMove.mc.gameSettings.keyBindSprint}) {
            if (InventoryMove.mc.currentScreen instanceof GuiChat || InventoryMove.mc.currentScreen instanceof GuiEditSign) {
                return;
            }
            keyBinding.pressed = Keyboard.isKeyDown((int)keyBinding.getKeyCode());
        }
    }
}
