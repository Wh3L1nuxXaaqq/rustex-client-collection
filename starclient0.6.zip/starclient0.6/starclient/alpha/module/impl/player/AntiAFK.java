package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Arrays;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;

@ModuleAnnotation(name="AntiAFK", category=Category.MOVEMENT)
public class AntiAFK
extends Module {
    public MultiBooleanSetting actions = new MultiBooleanSetting("\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044f", Arrays.asList("\u041d\u0430\u0436\u0430\u043d\u0438\u0435", "\u041f\u0440\u044b\u0436\u043e\u043a", "\u0421\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435"));

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (!AntiAFK.mc.player.isDead && AntiAFK.mc.player.getHealth() > 0.0f) {
            if (this.actions.get(0) && AntiAFK.mc.player.ticksExisted % 60 == 0) {
                mc.clickMouse();
            }
            if (this.actions.get(1) && AntiAFK.mc.player.ticksExisted % 40 == 0 && !AntiAFK.mc.gameSettings.keyBindJump.pressed && AntiAFK.mc.player.onGround) {
                AntiAFK.mc.player.jump();
            }
            if (this.actions.get(2) && AntiAFK.mc.player.ticksExisted % 400 == 0) {
                AntiAFK.mc.player.sendChatMessage("/hlep");
            }
        }
    }
}
