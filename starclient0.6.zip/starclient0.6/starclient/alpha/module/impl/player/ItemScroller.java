package starclient.alpha.module.impl.player;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="ItemScroller", category=Category.UTIL)
public class ItemScroller
extends Module {
    public static NumberSetting delay = new NumberSetting("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 80.0f, 0.0f, 1000.0f, 1.0f);
}
