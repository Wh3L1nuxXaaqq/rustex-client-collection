package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import starclient.alpha.StarClient;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.utility.misc.TimerHelper;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="AutoFarm", category=Category.MOVEMENT)
public class AutoFarm
extends Module {
    TimerHelper timer = new TimerHelper();
    BlockPos blockPos;

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
        RenderUtility.blockEspFrame(this.blockPos, (float)StarClient.getInstance().getC(0).getRed() / 255.0f, (float)StarClient.getInstance().getC(0).getGreen() / 255.0f, (float)StarClient.getInstance().getC(0).getBlue() / 255.0f);
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        for (final Entity entity : AutoFarm.mc.world.loadedEntityList) {
            if (!(entity.getDistanceToEntity(AutoFarm.mc.player) <= 4.0f) || !(entity instanceof EntityArmorStand)) continue;
            ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
            int n = (int)entity.posX;
            int n2 = (int)entity.posZ;
            for (int i = -2; i < 2; ++i) {
                for (int j = -2; j < 2; ++j) {
                    Block block = AutoFarm.mc.world.getBlockState(new BlockPos((double)(n + i), entity.posY, (double)(n2 + j))).getBlock();
                    if (block == Blocks.AIR || block != Blocks.STAINED_HARDENED_CLAY && block != Blocks.LOG && block != Blocks.LOG2) continue;
                    arrayList.add(new BlockPos((double)(n + i), entity.posY, (double)(n2 + j)));
                }
            }
            arrayList.sort(new Comparator<BlockPos>(){

                @Override
                public int compare(BlockPos blockPos, BlockPos blockPos2) {
                    return (int)(entity.getDistanceSq(blockPos) - entity.getDistanceSq(blockPos2));
                }
            });
            this.blockPos = (BlockPos)arrayList.get(0);
            if (this.blockPos == null) continue;
            if (AutoFarm.mc.player.getCooldownTracker().getCooldown(AutoFarm.mc.player.getHeldItemMainhand().getItem(), mc.getRenderPartialTicks()) == 0.0f) {
                AutoFarm.mc.player.swingArm(EnumHand.MAIN_HAND);
                EntityArmorStand entityArmorStand = (EntityArmorStand)entity;
                mc.getConnection().sendPacket(new CPacketUseEntity(entity, EnumHand.MAIN_HAND));
                mc.getConnection().sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.blockPos, EnumFacing.UP));
                this.timer.reset();
            }
            float[] fArray = Utils.getNeededRotations(entity.posX, entity.posY + (double)0.37f, entity.posZ, (float)AutoFarm.mc.player.posX, (float)AutoFarm.mc.player.posY + AutoFarm.mc.player.getEyeHeight(), (float)AutoFarm.mc.player.posZ);
            eventUpdate.setRotationYaw(fArray[0]);
            eventUpdate.setRotationPitch(fArray[1]);
        }
    }
}
