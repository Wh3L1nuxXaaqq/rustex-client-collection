package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketHeldItemChange;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="ItemSwapFix", category=Category.UTIL)
public class ItemSwapFix
extends Module {
    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        SPacketHeldItemChange sPacketHeldItemChange;
        if (eventReceivePacket.getPacket() instanceof SPacketHeldItemChange && (sPacketHeldItemChange = (SPacketHeldItemChange)eventReceivePacket.getPacket()).getHeldItemHotbarIndex() != ItemSwapFix.mc.player.inventory.currentItem) {
            ItemSwapFix.mc.player.connection.sendPacket(new CPacketHeldItemChange(ItemSwapFix.mc.player.inventory.currentItem));
            eventReceivePacket.setCancelled(true);
        }
    }
}
