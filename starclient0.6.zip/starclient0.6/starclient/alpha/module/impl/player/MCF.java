package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.text.TextFormatting;
import starclient.alpha.StarClient;
import starclient.alpha.event.input.EventMouse;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.misc.ChatUtility;

@ModuleAnnotation(name="MCF", category=Category.PLAYER)
public class MCF
extends Module {
    @EventTarget
    public void onMouse(EventMouse eventMouse) {
        if (eventMouse.getButton() == 2 && MCF.mc.pointedEntity instanceof EntityLivingBase) {
            String string = MCF.mc.pointedEntity.getName();
            if (StarClient.getInstance().getFriendManager().isFriend(string)) {
                StarClient.getInstance().getFriendManager().removeFriend(string);
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + string + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430 \u0434\u0440\u0443\u0437\u0435\u0439.");
            } else {
                StarClient.getInstance().getFriendManager().addFriend(string);
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + string + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0434\u0440\u0443\u0437\u044c\u044f!");
            }
        }
    }
}
