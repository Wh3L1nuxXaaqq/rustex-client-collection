package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.server.SPacketChat;
import starclient.alpha.StarClient;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.manager.friend.Friend;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.utility.misc.ChatUtility;

@ModuleAnnotation(name="AutoAccept", category=Category.UTIL)
public class AutoTPAccept
extends Module {
    private final MultiBooleanSetting che = new MultiBooleanSetting("\u041f\u0440\u0438\u043d\u0438\u043c\u0430\u0442\u044c", Arrays.asList("\u0417\u0430\u043f\u0440\u043e\u0441 \u043d\u0430 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0430\u0446\u0438\u044e", "\u0417\u0430\u043f\u0440\u043e\u0441 \u0432 \u0434\u0440\u0443\u0437\u044c\u044f", "\u0417\u0430\u043f\u0440\u043e\u0441 \u043d\u0430 \u0442\u0440\u0435\u0439\u0434"));
    public static BooleanSetting autoAccept = new BooleanSetting("\u041f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0442\u044c \u0442\u0440\u0435\u0439\u0434", true);

    public AutoTPAccept() {
        autoAccept.setVisible(() -> this.che.get(2));
    }

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketChat) {
            SPacketChat sPacketChat = (SPacketChat)eventReceivePacket.getPacket();
            String string = sPacketChat.getChatComponent().getUnformattedText();
            for (Friend friend : StarClient.getInstance().getFriendManager().getFriends()) {
                if (string.contains("/tpa") && this.che.get(0) && string.contains(friend.getName())) {
                    ChatUtility.sendChatMessage("/tpa");
                    continue;
                }
                if (string.contains("/friends") && this.che.get(1) && string.contains(friend.getName())) {
                    ChatUtility.sendChatMessage("/friends accept");
                    continue;
                }
                if (!string.contains("/trade") || !this.che.get(2) || !string.contains(friend.getName())) continue;
                ChatUtility.sendChatMessage("/trade accept");
                if (!autoAccept.get()) continue;
                CompletableFuture.runAsync(() -> {
                    try {
                        Thread.sleep(500L);
                    }
                    catch (InterruptedException interruptedException) {
                        throw new RuntimeException(interruptedException);
                    }
                    AutoTPAccept.mc.playerController.windowClick(AutoTPAccept.mc.player.openContainer.windowId, 49, 0, ClickType.PICKUP, AutoTPAccept.mc.player);
                });
            }
        }
    }
}
