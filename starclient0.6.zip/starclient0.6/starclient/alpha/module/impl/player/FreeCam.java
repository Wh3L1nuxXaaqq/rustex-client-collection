package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import starclient.alpha.event.misc.EventFullCube;
import starclient.alpha.event.misc.EventPush;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="FreeCam", category=Category.PLAYER)
public class FreeCam
extends Module {
    private float old;
    private double oldX;
    private double oldY;
    private double oldZ;
    private NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 1.0f, 0.1f, 5.0f, 0.05f);

    @Override
    public void onDisable() {
        if (FreeCam.mc.player != null) {
            FreeCam.mc.player.capabilities.isFlying = false;
            FreeCam.mc.player.capabilities.setFlySpeed(this.old);
            FreeCam.mc.player.noClip = false;
            FreeCam.mc.renderGlobal.loadRenderers();
            FreeCam.mc.player.setPositionAndRotation(this.oldX, this.oldY, this.oldZ, FreeCam.mc.player.rotationYaw, FreeCam.mc.player.rotationPitch);
            FreeCam.mc.world.removeEntityFromWorld(-7776);
            FreeCam.mc.player.motionZ = 0.0;
            FreeCam.mc.player.motionX = 0.0;
        }
        super.onDisable();
    }

    @Override
    public void onEnable() {
        if (FreeCam.mc.player != null) {
            this.oldX = FreeCam.mc.player.posX;
            this.oldY = FreeCam.mc.player.posY;
            this.oldZ = FreeCam.mc.player.posZ;
            FreeCam.mc.player.noClip = true;
            EntityOtherPlayerMP entityOtherPlayerMP = new EntityOtherPlayerMP(FreeCam.mc.world, FreeCam.mc.player.getGameProfile());
            entityOtherPlayerMP.copyLocationAndAnglesFrom(FreeCam.mc.player);
            entityOtherPlayerMP.posY -= 0.0;
            entityOtherPlayerMP.rotationYawHead = FreeCam.mc.player.rotationYawHead;
            FreeCam.mc.world.addEntityToWorld(-7776, entityOtherPlayerMP);
        }
        super.onEnable();
    }

    @EventTarget
    public void onFullCube(EventFullCube eventFullCube) {
        eventFullCube.setCancelled(true);
    }

    @EventTarget
    public void onPush(EventPush eventPush) {
        eventPush.setCancelled(true);
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        FreeCam.mc.player.noClip = true;
        FreeCam.mc.player.onGround = false;
        FreeCam.mc.player.capabilities.setFlySpeed(this.speed.get() / 5.0f);
        FreeCam.mc.player.capabilities.isFlying = true;
        eventUpdate.setPosX(this.oldX);
        eventUpdate.setPosY(this.oldY);
        eventUpdate.setPosZ(this.oldZ);
    }

    @EventTarget
    public void onReceivePacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketPlayerPosLook) {
            eventReceivePacket.setCancelled(true);
        }
    }

    @EventTarget
    public void onSendPacket(EventSendPacket eventSendPacket) {
        FreeCam.mc.player.setSprinting(false);
    }
}
