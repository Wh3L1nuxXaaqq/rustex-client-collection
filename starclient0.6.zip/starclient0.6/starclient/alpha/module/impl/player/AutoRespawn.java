package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.concurrent.CompletableFuture;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;

@ModuleAnnotation(name="AutoRespawn", category=Category.UTIL)
public class AutoRespawn
extends Module {
    @EventTarget
    public void onUpdateEvent(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketOpenWindow) {
            SPacketOpenWindow sPacketOpenWindow = (SPacketOpenWindow)eventReceivePacket.getPacket();
            String string = sPacketOpenWindow.getWindowTitle().getUnformattedText();
            CompletableFuture.runAsync(() -> {
                try {
                    if (string.contains("\u0412\u044b \u043c\u0435\u0440\u0442\u0432\u044b") || string.contains("Dead")) {
                        Thread.sleep(500L);
                        AutoRespawn.mc.playerController.windowClick(AutoRespawn.mc.player.openContainer.windowId, 29, 0, ClickType.PICKUP, AutoRespawn.mc.player);
                        Thread.sleep(250L);
                        AutoRespawn.mc.playerController.clickBlock(new BlockPos(AutoRespawn.mc.player.posX, AutoRespawn.mc.player.posY + 1.0, AutoRespawn.mc.player.posZ), EnumFacing.UP);
                    }
                }
                catch (InterruptedException interruptedException) {
                    throw new RuntimeException(interruptedException);
                }
            });
        }
    }
}
