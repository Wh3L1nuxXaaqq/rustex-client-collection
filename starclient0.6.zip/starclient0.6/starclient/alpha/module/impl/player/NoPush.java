package starclient.alpha.module.impl.player;

import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;

@ModuleAnnotation(name="NoPush", category=Category.PLAYER)
public class NoPush
extends Module {
    public static BooleanSetting water = new BooleanSetting("\u0412\u043e\u0434\u0430", false, () -> false);
    public static BooleanSetting players = new BooleanSetting("\u0416\u0438\u0432\u043d\u043e\u0441\u0442\u0438", false, () -> false);
    public static BooleanSetting blocks = new BooleanSetting("\u0411\u043b\u043e\u043a\u0438", false, () -> false);
}
