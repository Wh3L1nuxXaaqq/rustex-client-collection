package starclient.alpha.module.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Arrays;
import starclient.alpha.event.player.EventMotion;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventOverlay;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;

@ModuleAnnotation(name="NoAction", category=Category.PLAYER)
public class NoAction
extends Module {
    public static MultiBooleanSetting actions = new MultiBooleanSetting("\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044f", Arrays.asList("NoHurtCam", "CameraClip", "NoJumpDelay", "NoClickDelay"));

    @EventTarget
    public void onPush(EventMotion eventMotion) {
        if (actions.get(0)) {
            eventMotion.setCancelled(true);
        }
    }

    @EventTarget
    public void onOverlayRender(EventOverlay eventOverlay) {
        if (eventOverlay.getOverlayType().equals((Object)EventOverlay.OverlayType.HURT_CAM) && actions.get(1)) {
            eventOverlay.setCancelled(true);
        }
        if (eventOverlay.getOverlayType().equals((Object)EventOverlay.OverlayType.CAMERA_CLIP) && actions.get(2)) {
            eventOverlay.setCancelled(true);
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (actions.get(3)) {
            NoAction.mc.player.jumpTicks = 1;
        }
        if (actions.get(4)) {
            NoAction.mc.rightClickDelayTimer = 0;
        }
    }

    @Override
    public void onDisable() {
        if (NoAction.mc.player != null) {
            NoAction.mc.player.jumpTicks = 10;
            NoAction.mc.rightClickDelayTimer = 6;
        }
    }
}
