package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.MathHelper;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.move.MoveUtil;

@ModuleAnnotation(name="Timer", category=Category.MOVEMENT)
public class Timer
extends Module {
    public static NumberSetting timerAmount = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.5f, 0.5f, 2.0f, 0.1f);
    public static BooleanSetting smart = new BooleanSetting("\u041e\u043f\u0442\u0438\u043c\u0430\u043b\u044c\u043d\u043e\u0435 \u0432\u0440\u0435\u043c\u044f", true);
    public static NumberSetting movingUp = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f", 0.01f, 0.0f, 1.0f, 0.01f);
    public static long lastUpdateTime;
    public static double value;
    public static float animWidth;
    public double x;
    public double y;
    public double z;
    public double yaw;
    public double pitch;
    public boolean onGround;

    public Timer() {
        movingUp.setVisible(() -> smart.get());
    }

    public static int getMin() {
        return -15;
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (Timer.mc.player.onGround) {
            Utils.setSpeed(0.22f);
        } else {
            Utils.setSpeed(0.25);
        }
        if (!smart.get() || Timer.canEnableTimer(timerAmount.get() + 0.2f)) {
            Timer.mc.timer.field_194147_b = Math.max(timerAmount.get() + (Timer.mc.player.ticksExisted % 2 == 0 ? -0.2f : 0.2f), 0.1f);
        } else {
            Timer.mc.timer.field_194147_b = 1.0f;
            this.toggle();
        }
    }

    public static double getProgress() {
        double d = (10.0 - value) / (double)(Math.abs(Timer.getMin()) + 10);
        return MathHelper.clamp(d, 0.0, 1.0);
    }

    public static boolean canEnableTimer(float f) {
        double d = (50.0 - 50.0 / (double)f) / 50.0;
        return d + value < (double)(10.0f - timerAmount.get()) && value < 10.0;
    }

    @Override
    public void onDisable() {
        Timer.mc.timer.field_194147_b = 1.0f;
        super.onDisable();
    }

    public static void m() {
        long l = System.currentTimeMillis();
        long l2 = l - lastUpdateTime;
        lastUpdateTime = l;
        value += (50.0 - (double)l2) / 23.0;
        value = MoveUtil.isMoving() ? (value -= (double)movingUp.get()) : (value -= 0.001);
        value = MathHelper.clamp(value, (double)Timer.getMin(), 10.0);
    }
}
