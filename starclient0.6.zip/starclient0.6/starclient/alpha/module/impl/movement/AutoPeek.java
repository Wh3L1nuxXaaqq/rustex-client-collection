package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import starclient.alpha.StarClient;
import starclient.alpha.event.player.EventSwingArm;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.render.ColorUtility;
import starclient.alpha.utility.render.RenderUtility;

@ModuleAnnotation(name="AutoPeek", category=Category.MOVEMENT)
public class AutoPeek
extends Module {
    public Vec3d pos;
    public double motionX;
    public double motionZ;
    boolean teleport = false;
    public BooleanSetting timer = new BooleanSetting("\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435", true);
    public NumberSetting timerPower = new NumberSetting("\u0421\u0438\u043b\u0430 \u0443\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u044f", 0.6f, 0.1f, 2.0f, 0.1f);
    public ModeSetting mode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "\u0412\u044b\u0441\u0442\u0440\u0435\u043b", "\u0412\u044b\u0441\u0442\u0440\u0435\u043b", "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f");
    public NumberSetting radius = new NumberSetting("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f", 1.5f, 0.5f, 5.0f, 0.1f);

    public AutoPeek() {
        this.timerPower.setVisible(() -> this.timer.get());
        this.radius.setVisible(() -> this.mode.is("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f"));
    }

    @EventTarget
    public void onSwing(EventSwingArm eventSwingArm) {
        if (this.mode.is("\u0412\u044b\u0441\u0442\u0440\u0435\u043b") && eventSwingArm.getHand() == EnumHand.MAIN_HAND) {
            this.teleport = true;
        }
    }

    @EventTarget
    public void render3D(EventRender3D eventRender3D) {
        int n = StarClient.getInstance().getC(0).getRGB();
        int n2 = StarClient.getInstance().getC(500).getRGB();
        int n3 = ColorUtility.interpolateColorC(n, n2, 0.5f).getRGB();
        RenderUtility.drawCircle3D(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord, this.mode.is("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f") ? this.radius.get() : 0.3f, n3);
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (AutoPeek.mc.player.getDistance(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord) > (double)this.radius.get() && this.mode.is("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f")) {
            this.teleport = true;
        }
        if (this.teleport) {
            double d;
            if (this.timer.get()) {
                AutoPeek.mc.timer.field_194147_b = this.timerPower.get();
            }
            if ((d = AutoPeek.mc.player.getDistance(this.pos.xCoord, this.pos.yCoord, this.pos.zCoord)) != 0.0) {
                AutoPeek.mc.player.motionX = -(AutoPeek.mc.player.posX - this.pos.xCoord) / d * (double)0.3f;
                AutoPeek.mc.player.motionZ = -(AutoPeek.mc.player.posZ - this.pos.zCoord) / d * (double)0.3f;
            }
            if (d <= (double)0.3f) {
                this.teleport = false;
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.pos = new Vec3d(AutoPeek.mc.player.posX, AutoPeek.mc.player.posY, AutoPeek.mc.player.posZ);
        this.teleport = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.teleport = false;
    }
}
