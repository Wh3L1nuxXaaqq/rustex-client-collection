package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="TickUp", category=Category.MOVEMENT)
public class TickUp
extends Module {
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.4f, 0.1f, 25.0f, 0.1f);

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if ((TickUp.mc.player.isInWater() || TickUp.mc.player.isInLava()) && TickUp.mc.gameSettings.keyBindJump.isKeyDown()) {
            TickUp.mc.player.motionY = this.speed.get() / 15.0f;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }
}
