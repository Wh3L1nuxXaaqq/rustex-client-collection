package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.io.IOException;
import net.minecraft.network.play.client.CPacketEntityAction;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.utility.move.MovementUtility;

@ModuleAnnotation(name="AutoSprint", category=Category.MOVEMENT)
public class AutoSprint
extends Module {
    public BooleanSetting omnidirectional = new BooleanSetting("\u0412\u043e \u0432\u0441\u0435 \u0441\u0442\u043e\u0440\u043e\u043d\u044b", false);

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (AutoSprint.mc.player != null && AutoSprint.mc.player.getFoodStats().getFoodLevel() > 6 && !AutoSprint.mc.player.isSneaking() && !AutoSprint.mc.player.isCollidedHorizontally) {
            AutoSprint.mc.player.setSprinting(this.omnidirectional.get() ? MovementUtility.isMoving() : AutoSprint.mc.player.movementInput.forwardKeyDown);
        }
    }

    @EventTarget
    public void onSendPacket(EventSendPacket eventSendPacket) {
        if (this.omnidirectional.get() && eventSendPacket.getPacket() instanceof CPacketEntityAction) {
            CPacketEntityAction cPacketEntityAction = (CPacketEntityAction)eventSendPacket.getPacket();
            if (cPacketEntityAction.getAction() == CPacketEntityAction.Action.START_SPRINTING) {
                eventSendPacket.setCancelled(true);
            }
            if (cPacketEntityAction.getAction() == CPacketEntityAction.Action.STOP_SPRINTING) {
                eventSendPacket.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onrp(EventReceivePacket eventReceivePacket) throws IOException {
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (AutoSprint.mc.player != null) {
            AutoSprint.mc.player.setSprinting(false);
        }
    }
}
