package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.play.client.CPacketPlayer;
import starclient.alpha.event.player.EventMove;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.misc.TimeV3D;
import starclient.alpha.utility.move.MovementUtility;

@ModuleAnnotation(name="SpeedRustme", category=Category.MOVEMENT)
public class SpeedRustme
extends Module {
    private CPacketPlayer.Position startingOutOfBoundsPos;
    private final ArrayList<CPacketPlayer> packets = new ArrayList();
    private final Map<Integer, TimeV3D> posLooks = new ConcurrentHashMap<Integer, TimeV3D>();
    double speedX;
    double speedY;
    double speedZ;
    private static final Random random = new Random();
    public static NumberSetting speedfly = new NumberSetting("SpeedRustme", 0.1f, 0.1f, 20.0f, 0.1f);
    public static NumberSetting tiki = new NumberSetting("\u0422\u0438\u043a\u0438", 35.0f, 1.0f, 100.0f, 1.0f);

    public double randomHorizontal() {
        int n = random.nextInt(29000000) + 500;
        return random.nextBoolean() ? (double)n : (double)(-n);
    }

    @Override
    public void onEnable() {
        SpeedRustme.mc.player.capabilities.isFlying = false;
        SpeedRustme.mc.player.capabilities.setFlySpeed(speedfly.get());
        SpeedRustme.mc.player.motionY = 0.0;
        SpeedRustme.mc.player.motionX = 0.0;
        SpeedRustme.mc.player.motionZ = 0.0;
        this.packets.clear();
        this.posLooks.clear();
        this.speedX = 0.0;
        this.speedY = 0.0;
        this.speedZ = 0.0;
        this.startingOutOfBoundsPos = null;
        this.startingOutOfBoundsPos = new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), SpeedRustme.mc.player.onGround);
        this.packets.add(this.startingOutOfBoundsPos);
        SpeedRustme.mc.player.connection.sendPacket(this.startingOutOfBoundsPos);
        SpeedRustme.mc.player.setSprinting(false);
        SpeedRustme.mc.player.onGround = true;
        super.onEnable();
    }

    @EventTarget
    public void onTick(EventMove eventMove) {
        SpeedRustme.mc.timer.field_194147_b = 2.0f;
        if (MovementUtility.isMoving()) {
            if ((float)SpeedRustme.mc.player.ticksExisted % tiki.get() == 0.0f) {
                SpeedRustme.mc.timer.field_194147_b = 2.0f;
                SpeedRustme.mc.player.capabilities.isFlying = false;
                SpeedRustme.mc.player.capabilities.setFlySpeed(speedfly.get());
                SpeedRustme.mc.player.motionY = 0.0;
                SpeedRustme.mc.player.motionX = 0.0;
                SpeedRustme.mc.player.motionZ = 0.0;
                this.packets.clear();
                this.posLooks.clear();
                this.speedX = 0.0;
                this.speedY = 0.0;
                this.speedZ = 0.0;
                this.startingOutOfBoundsPos = null;
                this.startingOutOfBoundsPos = new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), SpeedRustme.mc.player.onGround);
                this.packets.add(this.startingOutOfBoundsPos);
                SpeedRustme.mc.player.connection.sendPacket(this.startingOutOfBoundsPos);
                SpeedRustme.mc.player.setSprinting(false);
                SpeedRustme.mc.player.onGround = true;
            } else {
                SpeedRustme.mc.player.setSprinting(false);
                SpeedRustme.mc.player.onGround = true;
                SpeedRustme.mc.timer.field_194147_b = 0.85003f;
            }
        }
    }
}
