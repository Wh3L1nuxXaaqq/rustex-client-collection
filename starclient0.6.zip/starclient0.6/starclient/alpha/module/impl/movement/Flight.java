package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventMove;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.math.TimerUtility;

@ModuleAnnotation(name="Flight", category=Category.MOVEMENT)
public class Flight
extends Module {
    private int teleportId;
    private CPacketPlayer.Position startingOutOfBoundsPos;
    private ArrayList<CPacketPlayer> packets = new ArrayList();
    private Map<Integer, TimeVec3d> posLooks = new ConcurrentHashMap<Integer, TimeVec3d>();
    private int vDelay;
    private int hDelay;
    double speedX;
    double speedY;
    double speedZ;
    private int factorCounter;
    private Random random = new Random();
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.26f, 0.01f, 4.0f, 0.01f);
    public BooleanSetting bounds = new BooleanSetting("\u0411\u043e\u0443\u043d\u0434\u0441", false);
    public BooleanSetting stric = new BooleanSetting("\u0421\u0442\u0440\u0438\u043a", false);
    public BooleanSetting bypass = new BooleanSetting("\u041e\u0431\u0445\u043e\u0434", false);
    public TimerUtility timer = new TimerUtility();
    public int times;
    private double y;

    @Override
    public void onDisable() {
        if (Flight.mc.player != null) {
            Flight.mc.player.setVelocity(0.0, 0.0, 0.0);
        }
        super.onDisable();
    }

    @EventTarget
    public void onPacket(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketPlayerPosLook && !(Flight.mc.currentScreen instanceof GuiDownloadTerrain)) {
            SPacketPlayerPosLook sPacketPlayerPosLook = (SPacketPlayerPosLook)eventReceivePacket.getPacket();
            if (Flight.mc.player == null) {
                return;
            }
            Packet<?> packet = eventReceivePacket.getPacket();
            if (packet instanceof SPacketPlayerPosLook) {
                SPacketPlayerPosLook sPacketPlayerPosLook2 = (SPacketPlayerPosLook)packet;
                packet = this.posLooks.remove(sPacketPlayerPosLook2.getTeleportId());
                if (Flight.mc.player.isEntityAlive() && packet != null && ((TimeVec3d)((Object)packet)).x == sPacketPlayerPosLook2.getX() && ((TimeVec3d)((Object)packet)).y == sPacketPlayerPosLook2.getY() && ((TimeVec3d)((Object)packet)).z == sPacketPlayerPosLook2.getZ()) {
                    eventReceivePacket.setCancelled(true);
                    return;
                }
                sPacketPlayerPosLook2.yaw = Flight.mc.player.rotationYaw;
                sPacketPlayerPosLook2.pitch = Flight.mc.player.rotationPitch;
                this.teleportId = sPacketPlayerPosLook2.getTeleportId();
            }
        }
    }

    @EventTarget
    public void onMove(EventMove eventMove) {
        if (this.teleportId <= 0) {
            return;
        }
        eventMove.set(this.speedX, this.speedY, this.speedZ);
        Flight.mc.player.noClip = true;
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        double[] dArray;
        if (Flight.mc.player == null || Flight.mc.world == null) {
            this.setToggled(false);
            return;
        }
        if (Flight.mc.player.ticksExisted % 20 == 0) {
            this.cleanPosLooks();
        }
        Flight.mc.player.setVelocity(0.0, 0.0, 0.0);
        if (this.teleportId <= 0) {
            this.startingOutOfBoundsPos = new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), Flight.mc.player.onGround);
            this.packets.add(this.startingOutOfBoundsPos);
            Flight.mc.player.connection.sendPacket(this.startingOutOfBoundsPos);
            return;
        }
        this.speedX = 0.0;
        this.speedY = 0.0;
        this.speedZ = 0.0;
        if (Flight.mc.gameSettings.keyBindJump.isKeyDown() && this.hDelay < 1) {
            this.speedY = Flight.mc.player.ticksExisted % 20 == 0 ? -0.032 : 0.042;
            this.vDelay = 5;
        } else if (Flight.mc.gameSettings.keyBindSneak.isKeyDown() && this.hDelay < 1) {
            this.speedY = -0.062;
            this.vDelay = 5;
        }
        if (!(Flight.mc.gameSettings.keyBindSneak.isKeyDown() && Flight.mc.gameSettings.keyBindJump.isKeyDown() || !Flight.isPlayerMoving() || (dArray = Flight.directionSpeed(this.checkCollisionBox() ? 0.06 : (double)this.speed.get()))[0] == 0.0 && dArray[1] == 0.0 || this.vDelay >= 1)) {
            this.speedX = dArray[0] * 0.5;
            this.speedZ = dArray[1] * 0.5;
            this.hDelay = 5;
        }
        Flight.mc.player.setVelocity(this.speedX, this.speedY, this.speedZ);
        this.sendPackets(this.speedX, this.speedY, this.speedZ);
        this.speedX = Flight.mc.player.motionX;
        this.speedY = Flight.mc.player.motionY;
        this.speedZ = Flight.mc.player.motionZ;
        --this.vDelay;
        --this.hDelay;
    }

    private boolean checkCollisionBox() {
        return !Flight.mc.world.getCollisionBoxes(Flight.mc.player, Flight.mc.player.getEntityBoundingBox().offset(0.0, 0.0, 0.0)).isEmpty() || !Flight.mc.world.getCollisionBoxes(Flight.mc.player, Flight.mc.player.getEntityBoundingBox().offset(0.0, 0.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty();
    }

    public double randomHorizontal() {
        int n = this.random.nextInt(29000000) + 500;
        return this.random.nextBoolean() ? (double)n : (double)(-n);
    }

    public double randomHorizontals() {
        int n = this.random.nextInt(this.bounds.get() ? 80 : (Flight.mc.player.ticksExisted % 2 == 0 ? 480 : 100)) + (this.bounds.get() ? 5 : 500);
        if (this.random.nextBoolean()) {
            return n;
        }
        return -n;
    }

    @EventTarget
    public void onPacketSend(EventSendPacket eventSendPacket) {
        Packet<?> packet;
        if (eventSendPacket.getPacket() instanceof CPacketPlayer && !(eventSendPacket.getPacket() instanceof CPacketPlayer.Position)) {
            eventSendPacket.setCancelled(true);
        }
        if ((packet = eventSendPacket.getPacket()) instanceof CPacketPlayer) {
            CPacketPlayer cPacketPlayer = (CPacketPlayer)packet;
            if (this.packets.contains(cPacketPlayer)) {
                this.packets.remove(cPacketPlayer);
                return;
            }
            eventSendPacket.setCancelled(true);
        }
    }

    private void cleanPosLooks() {
        this.posLooks.forEach((n, timeVec3d) -> {
            if (System.currentTimeMillis() - timeVec3d.getTime() > TimeUnit.SECONDS.toMillis(30L)) {
                this.posLooks.remove(n);
            }
        });
    }

    @Override
    public void onEnable() {
        this.packets.clear();
        this.posLooks.clear();
        this.teleportId = 0;
        this.vDelay = 0;
        this.hDelay = 0;
        this.speedX = 0.0;
        this.speedY = 0.0;
        this.speedZ = 0.0;
        this.startingOutOfBoundsPos = null;
        this.startingOutOfBoundsPos = new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), Flight.mc.player.onGround);
        this.packets.add(this.startingOutOfBoundsPos);
        Flight.mc.player.connection.sendPacket(this.startingOutOfBoundsPos);
        super.onEnable();
    }

    public Vec3d getVectorByMode(Vec3d vec3d, Vec3d vec3d2) {
        Vec3d vec3d3 = vec3d.add(vec3d2);
        vec3d3 = vec3d3.add(0.0, 1337.0, 0.0);
        return vec3d3;
    }

    public void sendPackets(Vec3d vec3d, boolean bl) {
        Vec3d vec3d2 = Flight.mc.player.getPositionVector().add(vec3d);
        Vec3d vec3d3 = this.getVectorByMode(vec3d, vec3d2);
        CPacketPlayer.Position position = new CPacketPlayer.Position(vec3d2.x, vec3d2.y, vec3d2.z, Flight.mc.player.onGround);
        this.packets.add(position);
        Flight.mc.player.connection.sendPacket(position);
        CPacketPlayer.Position position2 = new CPacketPlayer.Position(vec3d3.x, vec3d3.y, vec3d3.z, Flight.mc.player.onGround);
        this.packets.add(position2);
        Flight.mc.player.connection.sendPacket(position2);
        if (bl) {
            Flight.mc.player.connection.sendPacket(new CPacketConfirmTeleport(++this.teleportId));
            this.posLooks.put(this.teleportId, new TimeVec3d(vec3d2.x, vec3d2.y, vec3d2.z, System.currentTimeMillis()));
        }
    }

    private void sendPackets(double d, double d2, double d3) {
        Vec3d vec3d = new Vec3d(Flight.mc.player.posX + d, Flight.mc.player.posY + d2, Flight.mc.player.posZ + d3);
        Vec3d vec3d2 = this.getBoundsVec(d, d3);
        CPacketPlayer.Position position = new CPacketPlayer.Position(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord, Flight.mc.player.onGround);
        this.packets.add(position);
        Flight.mc.player.connection.sendPacket(position);
        CPacketPlayer.Position position2 = new CPacketPlayer.Position(vec3d2.xCoord, vec3d2.yCoord, vec3d2.zCoord, Flight.mc.player.onGround);
        this.packets.add(position2);
        Flight.mc.player.connection.sendPacket(position2);
        ++this.teleportId;
        Flight.mc.player.connection.sendPacket(new CPacketConfirmTeleport(this.teleportId));
        this.posLooks.put(this.teleportId, new TimeVec3d(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord, System.currentTimeMillis()));
    }

    private Vec3d getBoundsVec(double d, double d2) {
        if (this.bypass.get()) {
            return new Vec3d(this.bounds.get() ? Flight.mc.player.posX + this.randomHorizontal() : this.randomHorizontal(), this.stric.get() ? Math.max(Flight.mc.player.posY, 2.0) : Flight.mc.player.posY, this.bounds.get() ? Flight.mc.player.posZ + this.randomHorizontal() : this.randomHorizontal());
        }
        return new Vec3d(Flight.mc.player.posX + d, this.bounds.get() ? (double)(this.stric.get() ? 1 : 0) : Flight.mc.player.posY - 1337.0, Flight.mc.player.posZ + d2);
    }

    public static boolean isPlayerMoving() {
        return Flight.mc.gameSettings.keyBindForward.isKeyDown() || Flight.mc.gameSettings.keyBindBack.isKeyDown() || Flight.mc.gameSettings.keyBindRight.isKeyDown() || Flight.mc.gameSettings.keyBindLeft.isKeyDown();
    }

    public static double[] directionSpeed(double d) {
        MovementInput cfr_ignored_0 = Flight.mc.player.movementInput;
        float f = MovementInput.field_192832_b;
        MovementInput cfr_ignored_1 = Flight.mc.player.movementInput;
        float f2 = MovementInput.moveStrafe;
        float f3 = Flight.mc.player.prevRotationYaw + (Flight.mc.player.rotationYaw - Flight.mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        double d4 = (double)f * d * d3 + (double)f2 * d * d2;
        double d5 = (double)f * d * d2 - (double)f2 * d * d3;
        return new double[]{d4, d5};
    }

    public static final class TimeVec3d
    extends Vec3d {
        private final long time;

        public TimeVec3d(double d, double d2, double d3, long l) {
            super(d, d2, d3);
            this.time = l;
        }

        public TimeVec3d(Vec3i vec3i, long l) {
            super(vec3i);
            this.time = l;
        }

        public long getTime() {
            return this.time;
        }
    }
}
