package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.player.EventMove;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.math.TimerUtility;
import starclient.alpha.utility.move.MovementUtility;

@ModuleAnnotation(name="SpeedDayz", category=Category.MOVEMENT)
public class SpeedDayz
extends Module {
    private int ticks = 0;
    private String mode = "Vulcan";
    public TimerUtility timer = new TimerUtility();
    public int times;

    @EventTarget
    public void onMove(EventMove eventMove) {
        if (this.mode.equalsIgnoreCase("Vulcan")) {
            ++this.ticks;
            SpeedDayz.mc.timer.timerSpeed = 1.0f;
            boolean bl = false;
            if (MovementUtility.getMotion() < 0.215f && !SpeedDayz.mc.player.onGround) {
                MovementUtility.strafe(0.215f);
            }
            if (SpeedDayz.mc.player.onGround && MovementUtility.isMoving()) {
                this.ticks = 0;
                if (!SpeedDayz.mc.player.isAirBorne) {
                    return;
                }
                SpeedDayz.mc.timer.timerSpeed = 1.2f;
                bl = true;
                if (MovementUtility.getMotion() < 0.48f) {
                    MovementUtility.strafe(0.48f);
                } else {
                    MovementUtility.strafe((float)((double)MovementUtility.getMotion() * 0.985));
                }
            } else if (!MovementUtility.isMoving()) {
                SpeedDayz.mc.timer.timerSpeed = 1.0f;
                SpeedDayz.mc.player.motionX = 0.0;
                SpeedDayz.mc.player.motionZ = 0.0;
            }
        }
    }

    @Override
    public void onEnable() {
        this.ticks = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        SpeedDayz.mc.timer.timerSpeed = 1.0f;
        super.onDisable();
    }
}
