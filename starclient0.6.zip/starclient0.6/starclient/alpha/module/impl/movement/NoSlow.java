package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;

@ModuleAnnotation(name="NoSlow", category=Category.MOVEMENT)
public class NoSlow
extends Module {
    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        boolean bl = NoSlow.mc.player.isPotionActive(Potion.getPotionById(2));
        boolean bl2 = this.isEating();
        if (bl || bl2) {
            if (NoSlow.mc.player.onGround) {
                Utils.setSpeed(0.22f);
            } else {
                Utils.setSpeed(0.25);
            }
        }
    }

    private boolean isEating() {
        if (NoSlow.mc.player == null) {
            return false;
        }
        ItemStack itemStack = NoSlow.mc.player.getActiveItemStack();
        return itemStack != null && itemStack.getItem() instanceof ItemFood && NoSlow.mc.player.getItemInUseCount() > 0;
    }
}
