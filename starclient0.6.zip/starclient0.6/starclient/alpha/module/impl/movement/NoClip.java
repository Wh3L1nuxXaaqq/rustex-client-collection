package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.misc.EventFullCube;
import starclient.alpha.event.misc.EventPush;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="NoClip", category=Category.MOVEMENT)
public class NoClip
extends Module {
    public NumberSetting perdun = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.6f, 0.1f, 1.5f, 0.1f);

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @EventTarget
    public void onFullCube(EventFullCube eventFullCube) {
        if (NoClip.mc.world != null) {
            eventFullCube.setCancelled(true);
        }
    }

    @EventTarget
    public void onPush(EventPush eventPush) {
        eventPush.setCancelled(true);
    }

    @EventTarget
    public void onLivingUpdate(EventUpdate eventUpdate) {
        if (NoClip.mc.player != null) {
            NoClip.mc.player.noClip = true;
            NoClip.mc.player.motionY = 0.0;
            NoClip.mc.player.onGround = false;
            NoClip.mc.player.capabilities.isFlying = false;
            Utils.setSpeed(this.perdun.get());
            if (NoClip.mc.gameSettings.keyBindJump.isKeyDown()) {
                NoClip.mc.player.motionY += 0.1;
            }
            if (NoClip.mc.gameSettings.keyBindSneak.isKeyDown()) {
                NoClip.mc.player.motionY -= 0.1;
            }
            eventUpdate.setCancelled(false);
        }
    }
}
