package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.math.TimerUtility;

@ModuleAnnotation(name="TickShift", category=Category.MOVEMENT)
public class TickShift
extends Module {
    TimerUtility timer = new TimerUtility();
    public NumberSetting delay = new NumberSetting("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 0.05f, 0.0f, 5.0f, 0.01f);
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 1.0f, 1.0f, 10.0f, 0.1f);
    private BooleanSetting skipTick = new BooleanSetting("\u041f\u0440\u043e\u043f\u0443\u0441\u043a\u0430\u0442\u044c \u0442\u0438\u043a", false);

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (this.timer.hasReached(this.delay.get() * 500.0f)) {
            TickShift.mc.timer.field_194147_b = 1.0f;
            this.setToggled(false);
        } else {
            TickShift.mc.timer.field_194147_b = this.skipTick.get() ? 100.0f : this.speed.get();
        }
    }

    @Override
    public void onDisable() {
        TickShift.mc.timer.field_194147_b = 1.0f;
        super.onDisable();
    }

    @Override
    public void onEnable() {
        this.timer.reset();
        super.onEnable();
    }
}
