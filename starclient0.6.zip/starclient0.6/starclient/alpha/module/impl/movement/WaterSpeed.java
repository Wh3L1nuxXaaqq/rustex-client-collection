package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.BlockAir;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="WaterSpeed", category=Category.MOVEMENT)
public class WaterSpeed
extends Module {
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.4f, 0.1f, 25.0f, 0.1f);
    public NumberSetting speedLimit = new NumberSetting("\u041b\u0438\u043c\u0438\u0442 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438", 2.0f, 0.1f, 25.0f, 0.1f);
    public NumberSetting addSpeed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043d\u0430\u043a\u043e\u043f\u043b\u0435\u043d\u0438\u044f", 0.5f, 0.1f, 5.0f, 0.01f);
    public ModeSetting mode = new ModeSetting("\u0420\u0435\u0436\u0438\u043c", "\u041f\u043b\u0430\u0432\u043d\u044b\u0439", "\u041f\u043b\u0430\u0432\u043d\u044b\u0439", "\u0420\u0435\u0437\u043a\u0438\u0439");
    public float newSpeed;

    public WaterSpeed() {
        this.speed.setVisible(() -> this.mode.is("\u0420\u0435\u0437\u043a\u0438\u0439"));
        this.speedLimit.setVisible(() -> this.mode.is("\u041f\u043b\u0430\u0432\u043d\u044b\u0439"));
        this.addSpeed.setVisible(() -> this.mode.is("\u041f\u043b\u0430\u0432\u043d\u044b\u0439"));
    }

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (this.mode.is("\u0420\u0435\u0437\u043a\u0438\u0439")) {
            ArrayList<ItemStack> arrayList = new ArrayList<ItemStack>();
            WaterSpeed.mc.player.getArmorInventoryList().forEach(arrayList::add);
            arrayList.removeIf(itemStack -> itemStack.getItem() instanceof ItemAir);
            WaterSpeed.mc.player.setSprinting(false);
            if (!WaterSpeed.mc.player.isInWater()) {
                return;
            }
            if (WaterSpeed.mc.gameSettings.keyBindJump.isKeyDown() && !WaterSpeed.mc.player.isSneaking() && !(WaterSpeed.mc.world.getBlockState(WaterSpeed.mc.player.getPosition().add(0, 1, 0)).getBlock() instanceof BlockAir)) {
                WaterSpeed.mc.player.motionY = 0.12f;
            }
            if (WaterSpeed.mc.gameSettings.keyBindSneak.isKeyDown()) {
                WaterSpeed.mc.player.motionY = -0.12f;
            }
            if (WaterSpeed.mc.world.getBlockState(WaterSpeed.mc.player.getPosition().add(0, 1, 0)).getBlock() instanceof BlockAir && WaterSpeed.mc.gameSettings.keyBindJump.isKeyDown()) {
                WaterSpeed.mc.player.setSneaking(true);
                WaterSpeed.mc.player.motionY = 0.12f;
            }
            Utils.setSpeed(this.speed.get());
            WaterSpeed.mc.player.setSneaking(true);
        } else if (this.mode.is("\u041f\u043b\u0430\u0432\u043d\u044b\u0439")) {
            ArrayList<ItemStack> arrayList = new ArrayList<ItemStack>();
            WaterSpeed.mc.player.getArmorInventoryList().forEach(arrayList::add);
            arrayList.removeIf(itemStack -> itemStack.getItem() instanceof ItemAir);
            WaterSpeed.mc.player.setSprinting(false);
            if (!WaterSpeed.mc.player.isInWater()) {
                return;
            }
            if (WaterSpeed.mc.gameSettings.keyBindJump.isKeyDown() && !WaterSpeed.mc.player.isSneaking() && !(WaterSpeed.mc.world.getBlockState(WaterSpeed.mc.player.getPosition().add(0, 1, 0)).getBlock() instanceof BlockAir)) {
                WaterSpeed.mc.player.motionY = 0.12f;
            }
            if (WaterSpeed.mc.gameSettings.keyBindSneak.isKeyDown()) {
                WaterSpeed.mc.player.motionY = -0.12f;
            }
            if (WaterSpeed.mc.world.getBlockState(WaterSpeed.mc.player.getPosition().add(0, 1, 0)).getBlock() instanceof BlockAir && WaterSpeed.mc.gameSettings.keyBindJump.isKeyDown()) {
                WaterSpeed.mc.player.setSneaking(true);
                WaterSpeed.mc.player.motionY = 0.12f;
            }
            if (this.newSpeed >= this.speedLimit.get()) {
                this.newSpeed = this.speedLimit.get();
            }
            Utils.setSpeed(this.newSpeed);
            WaterSpeed.mc.player.setSneaking(true);
        }
    }

    @Override
    public void onDisable() {
        this.newSpeed = 0.6f;
        super.onDisable();
    }

    @Override
    public void onEnable() {
        this.newSpeed = 0.6f;
        CompletableFuture.runAsync(() -> {
            try {
                while (true) {
                    this.newSpeed += this.addSpeed.get();
                    Thread.sleep(1000L);
                }
            }
            catch (InterruptedException interruptedException) {
                throw new RuntimeException(interruptedException);
            }
        });
        super.onEnable();
    }
}
