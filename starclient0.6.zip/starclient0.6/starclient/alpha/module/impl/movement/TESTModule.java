package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.io.IOException;
import net.minecraft.network.play.server.SPacketDisconnect;
import starclient.alpha.event.packet.EventReceivePacket;
import starclient.alpha.event.packet.EventSendPacket;
import starclient.alpha.event.player.EventMove;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.event.render.EventRender2D;
import starclient.alpha.event.render.EventRender3D;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.utility.math.TimerUtility;

@ModuleAnnotation(name="TESTModule", category=Category.MOVEMENT)
public class TESTModule
extends Module {
    TimerUtility timer = new TimerUtility();

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
    }

    @EventTarget
    public void onMove(EventMove eventMove) {
    }

    @EventTarget
    public void onPacketReceive(EventReceivePacket eventReceivePacket) {
        if (eventReceivePacket.getPacket() instanceof SPacketDisconnect) {
            SPacketDisconnect sPacketDisconnect = (SPacketDisconnect)eventReceivePacket.getPacket();
            System.out.println(sPacketDisconnect.getReason().getFormattedText());
        }
    }

    public static String uploadToHastebin(String string) throws IOException {
        return string;
    }

    @EventTarget
    public void onPacketSend(EventSendPacket eventSendPacket) {
    }

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
    }

    @EventTarget
    public void onRender3D(EventRender3D eventRender3D) {
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }
}
