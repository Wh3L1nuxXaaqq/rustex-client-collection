package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;

@ModuleAnnotation(name="Strafe", category=Category.MOVEMENT)
public class Strafe
extends Module {
    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (Strafe.mc.player.onGround) {
            Utils.setSpeed(0.22f);
        } else {
            Utils.setSpeed(0.25);
        }
    }
}
