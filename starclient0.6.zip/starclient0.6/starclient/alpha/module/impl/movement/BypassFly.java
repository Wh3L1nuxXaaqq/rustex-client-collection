package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.play.client.CPacketPlayer;
import starclient.alpha.event.player.EventMove;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.utility.misc.TimeV3D;
import starclient.alpha.utility.move.MovementUtility;

@ModuleAnnotation(name="BypassFly", category=Category.MOVEMENT)
public class BypassFly
extends Module {
    public NumberSetting speed = new NumberSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.8f, 0.0f, 3.0f, 0.1f);
    private static final Random random = new Random();
    private CPacketPlayer.Position startingOutOfBoundsPos;
    private final ArrayList<CPacketPlayer> packets = new ArrayList();
    private final Map<Integer, TimeV3D> posLooks = new ConcurrentHashMap<Integer, TimeV3D>();
    private double speedX;
    private double speedY;
    private double speedZ;

    public double randomHorizontal() {
        int n = random.nextInt(29000000) + 63;
        return random.nextBoolean() ? (double)n : (double)(-n);
    }

    @Override
    public void onEnable() {
        this.resetPlayerMovement();
        super.onEnable();
    }

    private void resetPlayerMovement() {
        BypassFly.mc.player.capabilities.isFlying = false;
        BypassFly.mc.player.capabilities.setFlySpeed(0.05f);
        BypassFly.mc.player.motionY = 0.0;
        BypassFly.mc.player.motionX = 0.0;
        BypassFly.mc.player.motionZ = 0.0;
        this.packets.clear();
        this.posLooks.clear();
        this.speedZ = 0.0;
        this.speedY = 0.0;
        this.speedX = 0.0;
        this.startingOutOfBoundsPos = new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), BypassFly.mc.player.onGround);
        this.packets.add(this.startingOutOfBoundsPos);
        BypassFly.mc.player.connection.sendPacket(this.startingOutOfBoundsPos);
        BypassFly.mc.player.setSprinting(true);
        BypassFly.mc.player.onGround = true;
    }

    @EventTarget
    public void onTick(EventMove eventMove) {
        if (MovementUtility.isMoving()) {
            BypassFly.mc.timer.field_194147_b = this.speed.get();
            if (BypassFly.mc.player.ticksExisted % 35 == 0) {
                this.resetPlayerMovement();
            } else {
                BypassFly.mc.timer.field_194147_b = this.speed.get();
                BypassFly.mc.player.setSprinting(true);
                BypassFly.mc.player.onGround = true;
            }
        }
    }
}
