package starclient.alpha.module.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import starclient.alpha.event.player.EventUpdate;
import starclient.alpha.module.Category;
import starclient.alpha.module.Module;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.Utils;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;

@ModuleAnnotation(name="AirStuck", category=Category.MOVEMENT)
public class AirStuck
extends Module {
    public BooleanSetting allowMove = new BooleanSetting("Allow Move", true);
    public NumberSetting speed = new NumberSetting("SpeedRustme", 0.1f, 0.1f, 10.0f, 0.1f, () -> this.allowMove.get());

    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (this.allowMove.get()) {
            AirStuck.mc.player.motionY = AirStuck.mc.gameSettings.keyBindJump.isKeyDown() ? 0.5 : (AirStuck.mc.gameSettings.keyBindSneak.isKeyDown() ? -0.5 : -0.005);
            Utils.setSpeed(this.speed.get());
        } else {
            AirStuck.mc.player.motionX = -0.0;
            AirStuck.mc.player.motionY = -0.0;
            AirStuck.mc.player.motionZ = -0.0;
        }
    }
}
