package starclient.alpha.module.setting;

import java.util.function.Supplier;

public class Setting {
    private String name;
    private Object value;
    protected Supplier<Boolean> visible;

    public Setting(String string, Object object) {
        this.name = string;
        this.value = object;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String string) {
        this.name = string;
    }

    public Object getValue() {
        return this.value;
    }

    public void setValue(Object object) {
        this.value = object;
    }

    public Supplier<Boolean> getVisible() {
        return this.visible;
    }

    public void setVisible(Supplier<Boolean> supplier) {
        this.visible = supplier;
    }

    public boolean isEnabled() {
        return false;
    }
}
