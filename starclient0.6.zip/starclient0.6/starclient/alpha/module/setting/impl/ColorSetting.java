package starclient.alpha.module.setting.impl;

import java.awt.Color;
import java.util.function.Supplier;
import starclient.alpha.module.setting.Setting;

public class ColorSetting
extends Setting {
    private int color;

    public ColorSetting(String string, int n, Supplier<Boolean> supplier) {
        super(string, n);
        this.color = n;
        this.setVisible(supplier);
    }

    public ColorSetting(String string, int n) {
        super(string, n);
        this.color = n;
        this.setVisible(() -> true);
    }

    public int get() {
        return this.color;
    }

    public Color getColor() {
        return new Color(this.color);
    }

    public void setColor(int n) {
        this.color = n;
    }
}
