package starclient.alpha.module.setting.impl;

import java.util.function.Supplier;
import starclient.alpha.module.setting.Setting;

public class BooleanSetting
extends Setting {
    public boolean state;

    public BooleanSetting(String string, boolean bl) {
        super(string, bl);
        this.state = bl;
        this.setVisible(() -> true);
    }

    public BooleanSetting(String string, boolean bl, Supplier<Boolean> supplier) {
        super(string, bl);
        this.state = bl;
        this.setVisible(supplier);
    }

    public boolean get() {
        return this.state;
    }

    public void set(boolean bl) {
        this.state = bl;
    }
}
