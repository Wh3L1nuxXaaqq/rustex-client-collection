package starclient.alpha.module.setting.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import starclient.alpha.module.setting.Setting;

public class MultiBooleanSetting
extends Setting {
    public List<Boolean> selectedValues = new ArrayList<Boolean>();
    public List<String> values;

    public MultiBooleanSetting(String string, List<String> list) {
        this(string, list, null);
        this.setVisible(() -> true);
    }

    public MultiBooleanSetting(String string, List<String> list, Supplier<Boolean> supplier) {
        super(string, supplier);
        this.values = list;
        for (int i = 0; i < list.size(); ++i) {
            this.selectedValues.add(false);
        }
        this.setVisible(supplier);
    }

    public MultiBooleanSetting(String string, List<String> list, boolean bl, Supplier<Boolean> supplier) {
        super(string, supplier);
        this.values = list;
        for (int i = 0; i < list.size(); ++i) {
            this.selectedValues.add(bl);
        }
        this.setVisible(supplier);
    }

    public boolean get(int n) {
        return this.selectedValues.get(n);
    }

    public void set(int n, Boolean bl) {
        this.selectedValues.set(n, bl);
    }
}
