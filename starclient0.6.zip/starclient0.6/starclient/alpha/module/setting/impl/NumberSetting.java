package starclient.alpha.module.setting.impl;

import java.util.function.Supplier;
import starclient.alpha.module.setting.Setting;

public class NumberSetting
extends Setting {
    public float current;
    public float min;
    public float max;
    public float increment;

    public NumberSetting(String string, float f, float f2, float f3, float f4) {
        super(string, Float.valueOf(f));
        this.min = f2;
        this.max = f3;
        this.current = f;
        this.increment = f4;
        this.setVisible(() -> true);
    }

    public NumberSetting(String string, float f, float f2, float f3, float f4, Supplier<Boolean> supplier) {
        super(string, Float.valueOf(f));
        this.min = f2;
        this.max = f3;
        this.current = f;
        this.increment = f4;
        this.setVisible(supplier);
    }

    public double getMinValue() {
        return this.min;
    }

    public void setMinValue(float f) {
        this.min = f;
    }

    public double getMaxValue() {
        return this.max;
    }

    public void setMaxValue(float f) {
        this.max = f;
    }

    public float get() {
        return this.current;
    }

    public int getInt() {
        return (int)this.current;
    }

    public void set(float f) {
        this.current = f;
    }

    public double getIncrement() {
        return this.increment;
    }

    public void setIncrement(float f) {
        this.increment = f;
    }
}
