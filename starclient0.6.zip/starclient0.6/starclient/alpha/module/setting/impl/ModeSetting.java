package starclient.alpha.module.setting.impl;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import starclient.alpha.module.setting.Setting;

public class ModeSetting
extends Setting {
    public final List<String> modes;
    public String currentMode;
    public int index;

    public ModeSetting(String string, String string2, String ... stringArray) {
        super(string, string2);
        this.modes = Arrays.asList(stringArray);
        this.index = this.modes.indexOf(string2);
        this.currentMode = this.modes.get(this.index);
        this.setVisible(() -> true);
    }

    public ModeSetting(String string, String string2, Supplier<Boolean> supplier, String ... stringArray) {
        super(string, string2);
        this.modes = Arrays.asList(stringArray);
        this.index = this.modes.indexOf(string2);
        this.currentMode = this.modes.get(this.index);
        this.setVisible(supplier);
    }

    public boolean is(String string) {
        return this.currentMode.equals(string);
    }

    public boolean isIgnoreCase(String string) {
        return this.currentMode.equalsIgnoreCase(string);
    }

    public String get() {
        return this.currentMode;
    }

    public void set(String string) {
        this.currentMode = string;
        this.index = this.modes.indexOf(string);
    }

    public List<String> getModes() {
        return this.modes;
    }

    public String getOptions() {
        return this.modes.get(this.index);
    }
}
