package starclient.alpha.module;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import starclient.alpha.module.Category;

@Retention(value=RetentionPolicy.RUNTIME)
public @interface ModuleAnnotation {
    public String name();

    public Category category();
}
