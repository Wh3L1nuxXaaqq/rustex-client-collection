package starclient.alpha.module;

import java.awt.Desktop;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Utils {
    public static Minecraft mc = Minecraft.getMinecraft();

    public static void setSpeed(double d) {
        double d2 = MovementInput.field_192832_b;
        double d3 = MovementInput.moveStrafe;
        float f = Utils.mc.player.rotationYaw;
        if (d2 == 0.0 && d3 == 0.0) {
            Utils.mc.player.motionX = 0.0;
            Utils.mc.player.motionZ = 0.0;
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            Utils.mc.player.motionX = d2 * d * Math.cos(Math.toRadians(f + 90.0f)) + d3 * d * Math.sin(Math.toRadians(f + 90.0f));
            Utils.mc.player.motionZ = d2 * d * Math.sin(Math.toRadians(f + 90.0f)) - d3 * d * Math.cos(Math.toRadians(f + 90.0f));
        }
    }

    public static void setTimer(float f) {
        Minecraft.getMinecraft().timer.field_194147_b = f;
    }

    public static void openWebpage(String string) {
        try {
            Desktop.getDesktop().browse(new URL(string).toURI());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static double fovFromEntity(Entity entity) {
        return ((double)(Minecraft.getMinecraft().player.rotationYaw - Utils.fovToEntity(entity)) % 360.0 + 540.0) % 360.0 - 180.0;
    }

    public static float fovToEntity(Entity entity) {
        double d = entity.posX - Minecraft.getMinecraft().player.posX;
        double d2 = entity.posZ - Minecraft.getMinecraft().player.posZ;
        double d3 = Math.atan2(d, d2) * 57.2957795;
        return (float)(d3 * -1.0);
    }

    public static ArrayList<File> listFilesForFolder(File file) {
        ArrayList<File> arrayList = new ArrayList<File>();
        for (File file2 : file.listFiles()) {
            if (file2.isDirectory()) continue;
            arrayList.add(file2);
        }
        return arrayList;
    }

    public static boolean fov(Entity entity, float f) {
        f = (float)((double)f * 0.5);
        double d = ((double)(Minecraft.getMinecraft().player.rotationYaw - Utils.fovToEntity(entity)) % 360.0 + 540.0) % 360.0 - 180.0;
        return d >= 0.0 && d <= (double)f || (double)(-f) <= d && d <= 0.0;
    }

    public static boolean canEntityBeSeen(Vec3d vec3d, Vec3d vec3d2) {
        return Utils.mc.world.rayTraceBlocks(new Vec3d(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord), new Vec3d(vec3d2.xCoord, vec3d2.yCoord, vec3d2.zCoord), false, true, false) == null;
    }

    public static double getDistance(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d.xCoord - vec3d2.xCoord;
        double d2 = vec3d.yCoord - vec3d2.yCoord;
        double d3 = vec3d.zCoord - vec3d2.zCoord;
        return d * d + d2 * d2 + d3 * d3;
    }

    public static Vec3d interpolateEntity(Entity entity) {
        double d = Minecraft.getMinecraft().getRenderPartialTicks();
        return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * d, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * d, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * d);
    }

    public static float[] getNeededRotations(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d - d4;
        double d8 = d3 - d6;
        double d9 = d2 - d5;
        double d10 = MathHelper.sqrt(d7 * d7 + d8 * d8);
        float f = (float)(Math.atan2(d8, d7) * 180.0 / Math.PI - 90.0);
        float f2 = (float)(-(Math.atan2(d9, d10) * 180.0 / Math.PI));
        f2 = MathHelper.clamp(f2, -90.0f, 90.0f);
        return new float[]{f, f2};
    }

    public static double[] getDirection(float f) {
        return new double[]{-Math.sin(Math.toRadians(f)), Math.cos(Math.toRadians(f))};
    }
}
