package starclient.alpha.module;

import com.darkmagician6.eventapi.EventManager;
import com.google.gson.JsonObject;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import starclient.alpha.StarClient;
import starclient.alpha.manager.notification.NotificationManager;
import starclient.alpha.manager.notification.NotificationType;
import starclient.alpha.module.Category;
import starclient.alpha.module.ModuleAnnotation;
import starclient.alpha.module.impl.render.ClickGuiModule;
import starclient.alpha.module.impl.util.ClientSounds;
import starclient.alpha.module.setting.Setting;
import starclient.alpha.module.setting.impl.BooleanSetting;
import starclient.alpha.module.setting.impl.ColorSetting;
import starclient.alpha.module.setting.impl.ModeSetting;
import starclient.alpha.module.setting.impl.MultiBooleanSetting;
import starclient.alpha.module.setting.impl.NumberSetting;
import starclient.alpha.ui.csgui.CsGui;
import starclient.alpha.utility.Utility;
import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.Direction;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;

public class Module
implements Utility {
    protected ModuleAnnotation info = this.getClass().getAnnotation(ModuleAnnotation.class);
    public String name;
    public Category category;
    public boolean enabled = false;
    public int bind = 0;
    public boolean premiumModule;
    private final Animation animation = new DecelerateAnimation(250, 1.0f, Direction.BACKWARDS);

    public Module() {
        this.name = this.info.name();
        this.category = this.info.category();
        this.premiumModule = false;
    }

    public Module(boolean bl) {
        this.name = this.info.name();
        this.category = this.info.category();
        this.premiumModule = bl;
    }

    public boolean isSearched() {
        return CsGui.search.getText().isEmpty() || this.name.toLowerCase().toLowerCase().contains(CsGui.search.getText());
    }

    public void setToggled(boolean bl) {
        if (bl) {
            this.onEnable();
        } else {
            this.onDisable();
        }
        this.enabled = bl;
    }

    public void toggle() {
        boolean bl = this.enabled = !this.enabled;
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public int getMouseBind() {
        return this.bind + 100;
    }

    public boolean isPremium() {
        return this.premiumModule;
    }

    public void onEnable() {
        EventManager.register(this);
        if (!(this instanceof ClickGuiModule)) {
            if (StarClient.getInstance().getModuleManager().getModule(ClientSounds.class).isEnabled()) {
                ClientSounds.playSound("enable");
                NotificationManager.notify(NotificationType.INFO, "\u041c\u043e\u0434\u0443\u043b\u0438", this.name + " \u0431\u044b\u043b " + String.valueOf(ChatFormatting.GREEN) + "\u0432\u043a\u043b\u044e\u0447\u0435\u043d" + String.valueOf(ChatFormatting.RESET), 1000.0f);
            } else {
                NotificationManager.notify(NotificationType.INFO, "\u041c\u043e\u0434\u0443\u043b\u0438", this.name + " \u0431\u044b\u043b " + String.valueOf(ChatFormatting.GREEN) + "\u0432\u043a\u043b\u044e\u0447\u0435\u043d" + String.valueOf(ChatFormatting.RESET), 1000.0f);
            }
        }
    }

    public void onDisable() {
        EventManager.unregister(this);
        if (!(this instanceof ClickGuiModule)) {
            if (StarClient.getInstance().getModuleManager().getModule(ClientSounds.class).isEnabled()) {
                ClientSounds.playSound("disable");
                NotificationManager.notify(NotificationType.INFO, "\u041c\u043e\u0434\u0443\u043b\u0438", this.name + " \u0431\u044b\u043b " + String.valueOf(ChatFormatting.RED) + "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d" + String.valueOf(ChatFormatting.RESET), 1000.0f);
            } else {
                NotificationManager.notify(NotificationType.INFO, "\u041c\u043e\u0434\u0443\u043b\u0438", this.name + " \u0431\u044b\u043b " + String.valueOf(ChatFormatting.RED) + "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d" + String.valueOf(ChatFormatting.RESET), 1000.0f);
            }
        }
    }

    public List<Setting> getSettings() {
        return Arrays.stream(this.getClass().getDeclaredFields()).map(field -> {
            try {
                field.setAccessible(true);
                return field.get(this);
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
                return null;
            }
        }).filter(object -> object instanceof Setting).map(object -> (Setting)object).collect(Collectors.toList());
    }

    public JsonObject save() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("enabled", this.enabled);
        jsonObject.addProperty("bind", this.bind);
        JsonObject jsonObject2 = new JsonObject();
        for (Setting setting : this.getSettings()) {
            if (setting instanceof BooleanSetting) {
                jsonObject2.addProperty(setting.getName(), ((BooleanSetting)setting).get());
                continue;
            }
            if (setting instanceof ModeSetting) {
                jsonObject2.addProperty(setting.getName(), ((ModeSetting)setting).get());
                continue;
            }
            if (setting instanceof NumberSetting) {
                jsonObject2.addProperty(setting.getName(), Float.valueOf(((NumberSetting)setting).get()));
                continue;
            }
            if (setting instanceof ColorSetting) {
                jsonObject2.addProperty(setting.getName(), ((ColorSetting)setting).get());
                continue;
            }
            if (!(setting instanceof MultiBooleanSetting)) continue;
            StringBuilder stringBuilder = new StringBuilder();
            int n = 0;
            for (String string : ((MultiBooleanSetting)setting).values) {
                if (((MultiBooleanSetting)setting).selectedValues.get(n).booleanValue()) {
                    stringBuilder.append(string).append("\n");
                }
                ++n;
            }
            jsonObject2.addProperty(setting.getName(), stringBuilder.toString());
        }
        jsonObject.add("Settings", jsonObject2);
        return jsonObject;
    }

    /*
     * Unable to fully structure code
     */
    public void load(JsonObject var1_1) {
        if (var1_1 != null) {
            if (var1_1.has("enabled")) {
                this.setToggled(var1_1.get("enabled").getAsBoolean());
            }
            if (var1_1.has("bind")) {
                this.bind = var1_1.get("bind").getAsInt();
            }
            var2_2 = this.getSettings().iterator();
            block0: while (true) {
                if (!var2_2.hasNext()) {
                    return;
                }
                var3_3 = var2_2.next();
                var4_4 = var1_1.getAsJsonObject("Settings");
                if (var3_3 == null || var4_4 == null || !var4_4.has(var3_3.getName())) continue;
                if (var3_3 instanceof BooleanSetting) {
                    ((BooleanSetting)var3_3).state = var4_4.get(var3_3.getName()).getAsBoolean();
                    continue;
                }
                if (var3_3 instanceof ModeSetting) {
                    ((ModeSetting)var3_3).set(var4_4.get(var3_3.getName()).getAsString());
                    continue;
                }
                if (var3_3 instanceof NumberSetting) {
                    ((NumberSetting)var3_3).current = var4_4.get(var3_3.getName()).getAsFloat();
                    continue;
                }
                if (var3_3 instanceof ColorSetting) {
                    ((ColorSetting)var3_3).setColor(var4_4.get(var3_3.getName()).getAsInt());
                    continue;
                }
                if (!(var3_3 instanceof MultiBooleanSetting)) continue;
                for (var5_5 = 0; var5_5 < ((MultiBooleanSetting)var3_3).selectedValues.size(); ++var5_5) {
                    ((MultiBooleanSetting)var3_3).selectedValues.set(var5_5, false);
                }
                var5_5 = 0;
                var6_6 = var4_4.get(var3_3.getName()).getAsString().split("\n");
                var7_7 = ((MultiBooleanSetting)var3_3).values.iterator();
                while (true) {
                    if (var7_7.hasNext()) ** break;
                    continue block0;
                    var8_8 = var7_7.next();
                    var9_9 = var6_6;
                    var10_10 = var6_6.length;
                    for (var11_11 = 0; var11_11 < var10_10; ++var11_11) {
                        var12_12 = var9_9[var11_11];
                        if (!var12_12.equalsIgnoreCase(var8_8)) continue;
                        ((MultiBooleanSetting)var3_3).selectedValues.set(var5_5, true);
                    }
                    ++var5_5;
                }
                break;
            }
        }
    }

    public String getName() {
        return this.name;
    }

    public Category getCategory() {
        return this.category;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public int getBind() {
        return this.bind;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}
