package starclient.alpha.module;

import starclient.alpha.utility.render.animation.Animation;
import starclient.alpha.utility.render.animation.impl.DecelerateAnimation;

public enum Category {
    HOME("Menu", "a"),
    COMBAT("Combat", "b"),
    MOVEMENT("Movements", "c"),
    RENDER("Render", "d"),
    PLAYER("Player", "e"),
    UTIL("Utils", "f"),
    THEMES("Themes", "i"),
    CONFIG("Configs", "h");

    private final String name;
    private final String icon;
    private boolean bottom = false;
    private final Animation animation = new DecelerateAnimation(1000, 1.0f);

    private Category(String string2, String string3) {
        this.name = string2;
        this.icon = string3;
    }

    private Category(String string2, String string3, boolean bl) {
        this.name = string2;
        this.icon = string3;
        this.bottom = bl;
    }

    public String getName() {
        return this.name;
    }

    public String getIcon() {
        return this.icon;
    }

    public boolean isBottom() {
        return this.bottom;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}
