package recode.space.horizon.events.event;

import recode.space.horizon.events.event.Event;

public class EventUpdate
extends Event {
    double posX;
    double posY;
    double posZ;
    float rotationYaw;
    float rotationPitch;
    boolean onGround;

    public EventUpdate(double posX, double posY, double posZ, float rotationYaw, float rotationPitch, boolean onGround) {
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.rotationYaw = rotationYaw;
        this.rotationPitch = rotationPitch;
        this.onGround = onGround;
    }

    public double getPosY() {
        return this.posY;
    }

    public double getPosX() {
        return this.posX;
    }

    public double getPosZ() {
        return this.posZ;
    }

    public float getRotationPitch() {
        return this.rotationPitch;
    }

    public float getRotationYaw() {
        return this.rotationYaw;
    }

    public boolean isOnGround() {
        return this.onGround;
    }

    public void setPosY(double posY) {
        this.posY = posY;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }

    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
    }

    public void setPosZ(double posZ) {
        this.posZ = posZ;
    }

    public void setRotationPitch(float rotationPitch) {
        this.rotationPitch = rotationPitch;
    }

    public void setRotationYaw(float rotationYaw) {
        this.rotationYaw = rotationYaw;
    }
}
