package recode.space.horizon.events.event;

import java.lang.reflect.InvocationTargetException;
import recode.space.horizon.Horizon;
import recode.space.horizon.events.event.ArrayHelper;
import recode.space.horizon.events.event.Data;
import recode.space.horizon.events.event.EventManager;

public abstract class Event {
    private boolean cancelled;

    public Event call() {
        this.cancelled = false;
        Event.call(this);
        return this;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    private static void call(Event event) {
        EventManager eventManager = Horizon.eventManager;
        ArrayHelper<Data> dataList = EventManager.get(event.getClass());
        if (dataList != null) {
            for (Data data : dataList) {
                try {
                    data.target.invoke(data.source, event);
                }
                catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
                catch (InvocationTargetException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }
}
