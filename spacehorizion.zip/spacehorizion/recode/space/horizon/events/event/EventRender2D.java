package recode.space.horizon.events.event;

import recode.space.horizon.events.event.Event;

public class EventRender2D
extends Event {
    float partialTicks;

    public EventRender2D(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}
