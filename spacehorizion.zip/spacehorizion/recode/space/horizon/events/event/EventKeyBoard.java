package recode.space.horizon.events.event;

import recode.space.horizon.events.event.Event;

public class EventKeyBoard
extends Event {
    int key;

    public EventKeyBoard(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }
}
