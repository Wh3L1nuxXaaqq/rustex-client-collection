package recode.space.horizon.events;

import net.minecraft.block.Block;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GetLiquidCollisionBoundingBoxEvent
extends Event {
    private AxisAlignedBB collisionBoundingBox = Block.field_185506_k;

    public AxisAlignedBB getCollisionBoundingBox() {
        return this.collisionBoundingBox;
    }

    public void setCollisionBoundingBox(AxisAlignedBB collisionBoundingBox) {
        this.collisionBoundingBox = collisionBoundingBox;
    }
}
