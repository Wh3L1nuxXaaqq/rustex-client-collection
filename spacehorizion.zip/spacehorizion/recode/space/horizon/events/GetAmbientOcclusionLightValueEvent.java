package recode.space.horizon.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GetAmbientOcclusionLightValueEvent
extends Event {
    private float lightValue;

    public GetAmbientOcclusionLightValueEvent(IBlockState state) {
        this.lightValue = state.func_177230_c().func_185485_f(state);
    }

    public float getLightValue() {
        return this.lightValue;
    }

    public void setLightValue(float lightValue) {
        this.lightValue = lightValue;
    }
}
