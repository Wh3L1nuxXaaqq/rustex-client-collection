package recode.space.horizon.Menu;

import net.minecraft.client.renderer.GlStateManager;
import recode.space.horizon.utils.Font.CastomFontUtils;

public class drawLogo {
    public static void drawString(double scale, String text, float x, float y, int color) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179139_a((double)scale, (double)scale, (double)scale);
        CastomFontUtils.fr4.drawStringWithShadow(text, x, y, color);
        GlStateManager.func_179121_F();
    }
}
