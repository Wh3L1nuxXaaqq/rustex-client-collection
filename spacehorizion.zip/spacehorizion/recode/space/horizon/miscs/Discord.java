package recode.space.horizon.miscs;

import flip.guard.annotations.Native;
import recode.space.horizon.miscs.discordhelper.DiscordEventHandlers;
import recode.space.horizon.miscs.discordhelper.DiscordRPC;
import recode.space.horizon.miscs.discordhelper.DiscordRichPresence;

@Native
public class Discord {
    public static String discordID = "1294220154930069535";
    public static DiscordRichPresence discordRichP = new DiscordRichPresence();
    public static DiscordRPC discordRPC = DiscordRPC.INSTANCE;

    public static void startRPC() {
        DiscordEventHandlers eventHandlers = new DiscordEventHandlers();
        eventHandlers.disconnected = (var1, var2) -> System.out.println("Discord RPC disconnected, var1:" + var1 + ", var2: " + var2);
        discordRPC.Discord_Initialize(discordID, eventHandlers, true, null);
        Discord.discordRichP.startTimestamp = System.currentTimeMillis() / 1000L;
        Discord.discordRichP.details = "Build: Free";
        Discord.discordRichP.largeImageText = "Space-Horizon";
        Discord.discordRichP.state = "https://t.me/MoonBezna";
        discordRPC.Discord_UpdatePresence(discordRichP);
    }

    public static void stopRPC() {
        discordRPC.Discord_Shutdown();
        discordRPC.Discord_ClearPresence();
    }
}
