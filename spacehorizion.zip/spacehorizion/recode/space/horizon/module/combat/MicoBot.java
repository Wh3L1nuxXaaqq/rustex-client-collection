package recode.space.horizon.module.combat;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.combat.AimBot;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.FovUtils;
import recode.space.horizon.utils.TimerUtils;

public class MicoBot
extends Module {
    public float[] facing;
    public String[] gunlist = new String[]{""};
    public TimerUtils timer = new TimerUtils();
    public TimerUtils timer2 = new TimerUtils();

    public MicoBot() {
        super("MicoBot", Category.COMBAT);
        Horizon.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 0.0, 300.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Predict", this, 4.8f, 0.0, 7.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("VPredict", this, 300.0, 0.0, 300.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("BAimDistance", this, 10.0, -1.0, 50.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("FOV", this, 90.0, 1.0, 360.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Wall", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Silent", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("AutoShoot", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("AutoShootDeley", this, 100.0, 2.0, 500.0, true));
    }

    public float[] getPredict(Entity e) {
        float VPredict = (float)Horizon.instance.settingsManager.getSettingByName(this, "VPredict").getValDouble();
        float Predict = (float)Horizon.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        float Range = (float)Horizon.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        double xDiff = e.field_70165_t - e.field_70169_q;
        double zDiff = e.field_70161_v - e.field_70166_s;
        float predict = Predict + this.getDistance(e) / Range;
        double WillPosX = e.field_70165_t + xDiff * (double)predict;
        double WillPosZ = e.field_70161_v + zDiff * (double)predict;
        double WillPosY = VPredict != 0.0f ? e.field_70163_u - (double)e.field_70143_R + (double)(this.getDistance(e) / VPredict) : e.field_70163_u;
        return new float[]{(float)WillPosX, (float)WillPosZ, (float)WillPosY};
    }

    public float[] faceHead(float posX, float posY, float posZ, float p_706252, float p_706253, boolean miss) {
        double offset = Horizon.instance.settingsManager.getSettingByName(this, "BAimDistance").getValDouble();
        double var4 = (double)posX - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double var5 = (double)posZ - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double var6 = (double)posY + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        if (offset == -1.0) {
            var6 = (double)posY + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        } else {
            float distance = MicoBot.getDistance(new BlockPos((double)posX, (double)posY, (double)posZ));
            if ((double)distance <= offset) {
                var6 = (double)posY + 1.1 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
            }
        }
        double var7 = MathHelper.func_76133_a((double)(var4 * var4 + var5 * var5));
        float var8 = (float)(Math.atan2(var5, var4) * 180.0 / Math.PI) - 90.0f;
        float var9 = (float)(-(Math.atan2(var6 - 0.15, var7) * 180.0 / Math.PI));
        float f = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        float pitch = MicoBot.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70125_A, var9, p_706253);
        float yaw = MicoBot.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70177_z, var8, p_706252);
        yaw -= yaw % gcd;
        pitch -= pitch % gcd;
        return new float[]{yaw, pitch};
    }

    public static float updateRotation(float current, float intended, float speed) {
        float f = MathHelper.func_76142_g((float)(intended - current));
        if (f > speed) {
            f = speed;
        }
        if (f < -speed) {
            f = -speed;
        }
        return current + f;
    }

    private boolean lambdagetTarget(Entity entity) {
        return this.attackCheck(entity);
    }

    public Entity getTarget() {
        try {
            if (AimBot.mc.field_71439_g != null && !AimBot.mc.field_71439_g.field_70128_L) {
                List list = AimBot.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity != AimBot.mc.field_71439_g).filter(entity -> AimBot.mc.field_71439_g.func_70032_d(entity) <= 200.0f).filter(entity -> !entity.field_70128_L).filter(this::lambdagetTarget).sorted(Comparator.comparing(entity -> Float.valueOf(AimBot.mc.field_71439_g.func_70032_d(entity)))).collect(Collectors.toList());
                return list.size() > 0 ? (Entity)list.get(0) : null;
            }
            return null;
        }
        catch (Throwable var2) {
            return null;
        }
    }

    public boolean attackCheck(Entity target) {
        boolean Walls = Horizon.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        if (Walls) {
            return target instanceof EntityPlayer && !FriendManager.FRIENDS.contains(target.func_70005_c_());
        }
        return !Walls && AimBot.mc.field_71439_g.func_70685_l(target) && target instanceof EntityPlayer && !FriendManager.FRIENDS.contains(target.func_70005_c_());
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) {
        boolean Wall = Horizon.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        float Range = (float)Horizon.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        boolean AutoShoot = Horizon.instance.settingsManager.getSettingByName(this, "AutoShoot").getValBoolean();
        float AutoShootDeley = (float)Horizon.instance.settingsManager.getSettingByName(this, "AutoShootDeley").getValDouble();
        EntityPlayer target = (EntityPlayer)this.getTarget();
        if (target != null && !FriendManager.FRIENDS.contains(target.func_70005_c_()) && FovUtils.isInAttackFOV((Entity)target, (int)Horizon.instance.settingsManager.getSettingByName(this, "FOV").getValDouble())) {
            this.facing = this.getPredict((Entity)target);
            this.facing = this.faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0f, 360.0f, false);
            float f = this.facing[0];
            float f2 = this.facing[1];
            if (!Horizon.instance.settingsManager.getSettingByName(this, "Silent").getValBoolean() && this.timer2.isDelay(1L)) {
                AimBot.mc.field_71439_g.field_70177_z = this.facing[0];
                AimBot.mc.field_71439_g.field_70125_A = this.facing[1];
                this.timer2.setLastMS();
                if (Minecraft.func_71410_x().field_71462_r == null && this.timer.isDelay((long)AutoShootDeley) && AutoShoot) {
                    AimBot.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    this.timer.setLastMS();
                }
            }
        }
    }

    private float getDistance(Entity entityIn) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - entityIn.field_70165_t);
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - entityIn.field_70161_v);
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    private static float getDistance(BlockPos blockPos) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n());
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p());
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }
}
