package recode.space.horizon.module.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.Horizon;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.TimerUtils;

public class AimBot
extends Module {
    private float lastYaw;
    private float lastPitch;
    private List<String> middleClickEntities = new ArrayList<String>();
    private EntityPlayer currentTarget;
    private float rotationSpeed = 0.0f;
    private final TimerUtils timer = new TimerUtils();

    public AimBot() {
        super("AimBot", Category.COMBAT);
        Horizon.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 1.0, 300.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Predict", this, 4.8, 0.1, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Vpredict", this, 0.0, -10.0, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("FOV", this, 48.0, 1.0, 180.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Smooth", this, 5.0, 1.0, 20.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("InstantLock", this, false));
    }

    @Override
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || Minecraft.func_71410_x().field_71441_e == null || Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        double range = Horizon.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        boolean instantLock = Horizon.instance.settingsManager.getSettingByName(this, "InstantLock").getValBoolean();
        float smoothValue = (float)Horizon.instance.settingsManager.getSettingByName(this, "Smooth").getValDouble();
        EntityPlayer target = Minecraft.func_71410_x().field_71441_e.field_73010_i.stream().filter(entityPlayer -> entityPlayer != Minecraft.func_71410_x().field_71439_g).filter(entityPlayer -> (double)entityPlayer.func_70032_d((Entity)Minecraft.func_71410_x().field_71439_g) <= range).filter(this::isInFieldOfView).filter(entityPlayer -> !this.middleClickEntities.contains(entityPlayer.func_70005_c_())).filter(this::attackCheck).min(Comparator.comparing(entityPlayer -> Float.valueOf(entityPlayer.func_70032_d((Entity)Minecraft.func_71410_x().field_71439_g)))).orElse(null);
        if (target != null && Minecraft.func_71410_x().field_71439_g.func_70685_l((Entity)target) && !FriendManager.isFriend(target.func_70005_c_())) {
            double[] predictedPos = this.predictPosition(target);
            float[] rotations = this.faceHead(predictedPos[0], predictedPos[1], predictedPos[2], 360.0f, 360.0f);
            if (instantLock) {
                Minecraft.func_71410_x().field_71439_g.field_70177_z = rotations[0];
                Minecraft.func_71410_x().field_71439_g.field_70125_A = rotations[1];
            } else if (this.timer.isDelay(1L)) {
                float scaledSmoothValue = smoothValue / 100.0f;
                float lerpedYaw = this.lerp(Minecraft.func_71410_x().field_71439_g.field_70177_z, rotations[0], scaledSmoothValue);
                float lerpedPitch = this.lerp(Minecraft.func_71410_x().field_71439_g.field_70125_A, rotations[1], scaledSmoothValue);
                Minecraft.func_71410_x().field_71439_g.field_70177_z = lerpedYaw;
                Minecraft.func_71410_x().field_71439_g.field_70125_A = lerpedPitch;
                this.timer.setLastMS();
            }
            this.lastYaw = Minecraft.func_71410_x().field_71439_g.field_70177_z;
            this.lastPitch = Minecraft.func_71410_x().field_71439_g.field_70125_A;
            this.currentTarget = target;
        } else {
            this.currentTarget = null;
        }
    }

    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        double fovSetting = Horizon.instance.settingsManager.getSettingByName(this, "FOV").getValDouble();
        ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
        this.drawFovCircle(sr.func_78326_a() / 2, sr.func_78328_b() / 2, (int)(fovSetting * 2.0));
    }

    private float lerp(float start, float end, float percent) {
        return start + percent * (end - start);
    }

    private float[] faceHead(double posX, double posY, double posZ, float yawSpeed, float pitchSpeed) {
        double deltaX = posX - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double deltaZ = posZ - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double heightOffset = 1.86;
        double deltaY = posY + heightOffset - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        double distance = MathHelper.func_76133_a((double)(deltaX * deltaX + deltaZ * deltaZ));
        float yaw = (float)(Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(deltaY - 0.15, distance) * 180.0 / Math.PI));
        float mouseSensitivity = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        float gcd = mouseSensitivity * mouseSensitivity * mouseSensitivity * 1.2f;
        float newPitch = this.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70125_A, pitch, pitchSpeed);
        float newYaw = this.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70177_z, yaw, yawSpeed);
        newYaw -= newYaw % gcd;
        newPitch -= newPitch % gcd;
        return new float[]{newYaw, newPitch};
    }

    private float updateRotation(float current, float intended, float speed) {
        float delta = MathHelper.func_76142_g((float)(intended - current));
        if (delta > speed) {
            delta = speed;
        }
        if (delta < -speed) {
            delta = -speed;
        }
        return current + delta;
    }

    private double[] predictPosition(EntityPlayer target) {
        double predictFactor = Horizon.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        double vPredictFactor = Horizon.instance.settingsManager.getSettingByName(this, "Vpredict").getValDouble();
        double deltaX = target.field_70165_t - target.field_70169_q;
        double deltaZ = target.field_70161_v - target.field_70166_s;
        double predictedX = target.field_70165_t + deltaX * predictFactor;
        double predictedY = target.field_70163_u + (double)target.func_70047_e() + vPredictFactor;
        double predictedZ = target.field_70161_v + deltaZ * predictFactor;
        return new double[]{predictedX, predictedY, predictedZ};
    }

    private boolean isInFieldOfView(EntityPlayer target) {
        double fovSetting = Horizon.instance.settingsManager.getSettingByName(this, "FOV").getValDouble();
        float[] targetRotations = this.faceHead(target.field_70165_t, target.field_70163_u + (double)target.func_70047_e(), target.field_70161_v, 360.0f, 360.0f);
        float yawDiff = MathHelper.func_76142_g((float)(targetRotations[0] - Minecraft.func_71410_x().field_71439_g.field_70177_z));
        return (double)Math.abs(yawDiff) <= fovSetting / 2.0;
    }

    private void drawFovCircle(float x, float y, int radius) {
        GL11.glPushAttrib((int)1048575);
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glLineWidth((float)2.0f);
        GL11.glColor4f((float)1.0f, (float)0.0f, (float)0.0f, (float)0.5f);
        GL11.glBegin((int)2);
        for (int i = 0; i <= 360; ++i) {
            double angle = Math.toRadians(i);
            GL11.glVertex2d((double)((double)x + Math.cos(angle) * (double)radius), (double)((double)y + Math.sin(angle) * (double)radius));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }

    public boolean attackCheck(Entity target) {
        if (!(target instanceof EntityPlayer)) {
            return false;
        }
        EntityPlayer player = (EntityPlayer)target;
        return !FriendManager.isFriend(player.func_70005_c_()) && Minecraft.func_71410_x().field_71439_g.func_70685_l((Entity)player) && !player.func_70644_a(MobEffects.field_76441_p) && player.field_70163_u <= 100.0;
    }
}
