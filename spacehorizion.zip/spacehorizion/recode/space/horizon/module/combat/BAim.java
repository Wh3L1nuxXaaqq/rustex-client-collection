package recode.space.horizon.module.combat;

import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class BAim
extends Module {
    public BAim() {
        super("BAim", Category.COMBAT);
    }
}
