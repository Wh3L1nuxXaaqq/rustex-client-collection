package recode.space.horizon.module.combat;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.combat.AimBots.RotationSpeed;

public class AimTest
extends Module {
    private final Minecraft mc = Minecraft.func_71410_x();
    private final RotationSpeed rotationSettings = new RotationSpeed(0.4f, 4.5f, 0.1f);
    private EntityLivingBase target;
    private final Random random = new Random();

    public AimTest() {
        super("AimTest", Category.COMBAT);
    }

    @Override
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || this.mc.field_71439_g == null || this.mc.field_71441_e == null) {
            return;
        }
        this.target = this.findTarget();
        if (this.target == null) {
            return;
        }
        float[] rotations = this.calculateRotations(this.target);
        float targetYaw = rotations[0];
        float targetPitch = rotations[1];
        float currentYaw = this.mc.field_71439_g.field_70177_z;
        float currentPitch = this.mc.field_71439_g.field_70125_A;
        float newYaw = this.lerpAngle(currentYaw, targetYaw, this.rotationSettings.speed);
        float newPitch = this.lerpAngle(currentPitch, targetPitch, this.rotationSettings.speed);
        this.mc.field_71439_g.field_70177_z = newYaw += (this.random.nextFloat() - 0.5f) * this.rotationSettings.randomFactor * 2.0f;
        this.mc.field_71439_g.field_70125_A = MathHelper.func_76131_a((float)(newPitch += (this.random.nextFloat() - 0.5f) * this.rotationSettings.randomFactor * 2.0f), (float)-90.0f, (float)90.0f);
    }

    private EntityLivingBase findTarget() {
        List entities = this.mc.field_71441_e.field_72996_f;
        return entities.stream().filter(entity -> entity instanceof EntityLivingBase).filter(entity -> entity != this.mc.field_71439_g).filter(entity -> !entity.field_70128_L).filter(entity -> this.mc.field_71439_g.func_70032_d(entity) <= this.rotationSettings.range).filter(entity -> this.mc.field_71439_g.func_70685_l(entity)).map(entity -> (EntityLivingBase)entity).min(Comparator.comparingDouble(entity -> this.mc.field_71439_g.func_70032_d((Entity)entity))).orElse(null);
    }

    private float[] calculateRotations(EntityLivingBase target) {
        double deltaX = target.field_70165_t - this.mc.field_71439_g.field_70165_t;
        double deltaY = target.field_70163_u + (double)target.func_70047_e() - (this.mc.field_71439_g.field_70163_u + (double)this.mc.field_71439_g.func_70047_e());
        double deltaZ = target.field_70161_v - this.mc.field_71439_g.field_70161_v;
        double distance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float)(Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(deltaY, distance) * 180.0 / Math.PI));
        return new float[]{MathHelper.func_76142_g((float)yaw), MathHelper.func_76131_a((float)pitch, (float)-90.0f, (float)90.0f)};
    }

    private float lerpAngle(float from, float to, float speed) {
        float delta = MathHelper.func_76142_g((float)(to - from));
        return from + delta * speed;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.target = null;
    }
}
