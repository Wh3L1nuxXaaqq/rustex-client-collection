package recode.space.horizon.module.combat;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.Horizon;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.FovUtils;
import recode.space.horizon.utils.TimerUtils;

public class AimBot2
extends Module {
    private float[] facing;
    private float[] lastFacing;
    private final TimerUtils timer = new TimerUtils();
    private final TimerUtils timer2 = new TimerUtils();
    private final String[] gunlist = new String[]{""};

    public AimBot2() {
        super("AimBot2", Category.COMBAT);
        Horizon.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 0.0, 300.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Predict", this, 6.1, 0.0, 7.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("VPredict", this, 300.0, 0.0, 300.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("FOV", this, 48.0, 1.0, 360.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Smooth", this, 5.0, 1.0, 20.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("InstantLock", this, true));
        this.lastFacing = new float[]{0.0f, 0.0f};
    }

    public float[] getPredict(Entity entity) {
        float vPredict = (float)Horizon.instance.settingsManager.getSettingByName(this, "VPredict").getValDouble();
        float predict = (float)Horizon.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        float range = (float)Horizon.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        double partialTicks = Minecraft.func_71410_x().func_184121_ak();
        double posX = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * partialTicks;
        double posY = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * partialTicks;
        double posZ = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * partialTicks;
        double xDiff = entity.field_70165_t - entity.field_70169_q;
        double zDiff = entity.field_70161_v - entity.field_70166_s;
        float predictFactor = predict + this.getDistance(entity) / range;
        double willPosX = posX + xDiff * (double)predictFactor;
        double willPosZ = posZ + zDiff * (double)predictFactor;
        double willPosY = vPredict != 0.0f ? posY + (double)(this.getDistance(entity) / vPredict) : posY;
        return new float[]{(float)willPosX, (float)willPosZ, (float)willPosY};
    }

    private float getDistance(Entity entity) {
        double deltaX = entity.field_70165_t - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double deltaY = entity.field_70163_u - Minecraft.func_71410_x().field_71439_g.field_70163_u;
        double deltaZ = entity.field_70161_v - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        return (float)Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
    }

    public static float[] faceHead(float posX, float posY, float posZ, float yawSpeed, float pitchSpeed) {
        double deltaX = (double)posX - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double deltaZ = (double)posZ - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double heightOffset = Horizon.moduleManager.getModule("BAim").isToggled() ? 1.5 : 1.86;
        double deltaY = (double)posY + heightOffset - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        double distance = MathHelper.func_76133_a((double)(deltaX * deltaX + deltaZ * deltaZ));
        float yaw = (float)(Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(deltaY - 0.15, distance) * 180.0 / Math.PI));
        float mouseSensitivity = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        float gcd = mouseSensitivity * mouseSensitivity * mouseSensitivity * 1.2f;
        float newPitch = AimBot2.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70125_A, pitch, pitchSpeed);
        float newYaw = AimBot2.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70177_z, yaw, yawSpeed);
        newYaw -= newYaw % gcd;
        newPitch -= newPitch % gcd;
        return new float[]{newYaw, newPitch};
    }

    public static float updateRotation(float current, float intended, float speed) {
        float delta = MathHelper.func_76142_g((float)(intended - current));
        if (delta > speed) {
            delta = speed;
        }
        if (delta < -speed) {
            delta = -speed;
        }
        return current + delta;
    }

    private boolean attackCheck(Entity target) {
        return target instanceof EntityPlayer && !FriendManager.FRIENDS.contains(target.func_70005_c_()) && Minecraft.func_71410_x().field_71439_g.func_70685_l(target);
    }

    public Entity getTarget() {
        if (Minecraft.func_71410_x().field_71439_g != null && !Minecraft.func_71410_x().field_71439_g.field_70128_L) {
            List list = Minecraft.func_71410_x().field_71441_e.field_72996_f.stream().filter(entity -> entity != Minecraft.func_71410_x().field_71439_g).filter(entity -> !entity.field_70128_L).filter(this::attackCheck).sorted(Comparator.comparing(FovUtils::getDistanceFromMouse)).collect(Collectors.toList());
            return list.isEmpty() ? null : (Entity)list.get(0);
        }
        return null;
    }

    private float lerp(float start, float end, float percent) {
        return start + percent * (end - start);
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        EntityPlayer target = (EntityPlayer)this.getTarget();
        if (target != null && !FriendManager.FRIENDS.contains(target.func_70005_c_()) && FovUtils.isInAttackFOV((Entity)target, (int)Horizon.instance.settingsManager.getSettingByName(this, "FOV").getValDouble())) {
            this.facing = this.getPredict((Entity)target);
            this.facing = AimBot2.faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0f, 360.0f);
            boolean instantLock = Horizon.instance.settingsManager.getSettingByName(this, "InstantLock").getValBoolean();
            if (instantLock) {
                Minecraft.func_71410_x().field_71439_g.field_70177_z = this.facing[0];
                Minecraft.func_71410_x().field_71439_g.field_70125_A = this.facing[1];
            } else if (this.timer2.isDelay(1L)) {
                float smoothValue = (float)Horizon.instance.settingsManager.getSettingByName(this, "Smooth").getValDouble();
                float scaledSmoothValue = smoothValue / 100.0f;
                float lerpedYaw = this.lerp(Minecraft.func_71410_x().field_71439_g.field_70177_z, this.facing[0], scaledSmoothValue);
                float lerpedPitch = this.lerp(Minecraft.func_71410_x().field_71439_g.field_70125_A, this.facing[1], scaledSmoothValue);
                Minecraft.func_71410_x().field_71439_g.field_70177_z = lerpedYaw;
                Minecraft.func_71410_x().field_71439_g.field_70125_A = lerpedPitch;
                this.timer2.setLastMS();
            }
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        double fov = Horizon.instance.settingsManager.getSettingByName(this, "FOV").getValDouble() / (double)Minecraft.func_71410_x().field_71474_y.field_74334_X;
        ScaledResolution scaledResolution = event.getResolution();
        AimBot2.drawCircle228((float)scaledResolution.func_78326_a() / 2.0f, (float)scaledResolution.func_78328_b() / 2.0f, (int)(fov * 485.0), Color.RED.getRGB(), 360, 0.5f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawCircle228(float x, float y, float radius, int color, int segments, float lineWidth) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        boolean wasBlendEnabled = GL11.glIsEnabled((int)3042);
        boolean wasLineSmoothEnabled = GL11.glIsEnabled((int)2848);
        boolean wasTextureEnabled = GL11.glIsEnabled((int)3553);
        if (!wasBlendEnabled) {
            GL11.glEnable((int)3042);
        }
        if (!wasLineSmoothEnabled) {
            GL11.glEnable((int)2848);
        }
        if (wasTextureEnabled) {
            GL11.glDisable((int)3553);
        }
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)alpha);
        GL11.glLineWidth((float)lineWidth);
        GL11.glBegin((int)2);
        for (int i = 0; i <= segments; ++i) {
            double angle = (double)i * Math.PI / 180.0;
            GL11.glVertex2d((double)((double)x + Math.sin(angle) * (double)radius), (double)((double)y + Math.cos(angle) * (double)radius));
        }
        GL11.glEnd();
        if (wasTextureEnabled) {
            GL11.glEnable((int)3553);
        }
        if (!wasLineSmoothEnabled) {
            GL11.glDisable((int)2848);
        }
        if (!wasBlendEnabled) {
            GL11.glDisable((int)3042);
        }
    }
}
