package recode.space.horizon.module.combat.AimBots;

public class RotationSpeed {
    public float speed;
    public float range;
    public float randomFactor;

    public RotationSpeed() {
        this.speed = 0.4f;
        this.range = 4.5f;
        this.randomFactor = 0.1f;
    }

    public RotationSpeed(float speed, float range, float randomFactor) {
        this.speed = Math.max(0.0f, Math.min(1.0f, speed));
        this.range = Math.max(1.0f, range);
        this.randomFactor = Math.max(0.0f, Math.min(0.5f, randomFactor));
    }
}
