package recode.space.horizon.module.hud;

import flip.guard.annotations.Native;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.ColorUtils;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.Font.CustomFontRenderer;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.RenderUtils;

@Native
public class Watermark
extends Module {
    public static List<String> Modes = new ArrayList<String>(Arrays.asList("Anim", "Horizon"));
    private final Minecraft mc = Minecraft.func_71410_x();
    private final String NO_NAME = "NameProtect";
    private final String[] texts = new String[]{"Versions:1.0.1", "t.me/MoonBezna"};
    private int currentTextIndex = 0;
    private long currentTextStartTime = 0L;
    private final long textDisplayDuration = 2000L;
    private final long textWaitDuration = 1000L;
    private final CustomFontRenderer fr4 = CastomFontUtils.fr4;

    public Watermark() {
        super("Watermark", Category.HUD);
        Horizon.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "Horizon", (ArrayList<String>)((ArrayList)Modes)));
        Horizon.instance.settingsManager.rSetting(new Setting("ShowName", this, true));
    }

    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent.Text event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.TEXT || this.mc.field_71439_g == null) {
            return;
        }
        String mode = Horizon.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        boolean showName = Horizon.instance.settingsManager.getSettingByName(this, "ShowName").getValBoolean();
        String playerName = showName ? this.mc.field_71439_g.func_70005_c_() : "NameProtect";
        String ms = this.mc.func_147104_D() != null ? "" + this.mc.func_147104_D().field_78844_e : "N/A";
        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        int fontHeight = this.fr4.getHeight();
        int[] array = new int[]{1};
        int astolfoColors = ColorUtils.astolfoColors(array[0] * 15, fontHeight + 20);
        int backgroundColor = new Color(37, 37, 37, 255).getRGB();
        int textColor = Color.WHITE.getRGB();
        if (mode.equals("Anim")) {
            String[] animations = new String[]{"S ", "Sp ", "Spa ", "Spac ", "Space", "Space-H", "Space-Ho", "Space-Hor", "Space-Hori", "Space-Horiz", "Space-Horizo", "Space-Horizon", "Space-Horizo", "Space-Horiz", "Space-Hori", "Space-Hor", "Space-Ho", "Space-H", "Space", "Spac", "Spa", "Sp"};
            String animatedText = animations[(int)(System.currentTimeMillis() / 200L % (long)animations.length)];
            String displayText = String.format("%s | %s | MS: %s | %s", animatedText, playerName, ms, time);
            int width = this.fr4.getStringWidth(displayText) + 40;
            int height = fontHeight + 20;
            int leftPadding = 3;
            RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(15 - leftPadding, 5.0f, 15 + width, 5 + height, 3.0f, 0.0f, backgroundColor, backgroundColor, backgroundColor, backgroundColor, false, true, false);
            RenderUtil.drawCircle(25.0f, 15.0f, 5.0f, astolfoColors);
            this.fr4.drawStringWithShadow(displayText, 35.0f, 10.0f, textColor);
            long currentTime = System.currentTimeMillis();
            if (this.currentTextStartTime == 0L || currentTime - this.currentTextStartTime >= 3000L) {
                this.currentTextIndex = (this.currentTextIndex + 1) % this.texts.length;
                this.currentTextStartTime = currentTime;
            }
            String vkText = this.texts[this.currentTextIndex];
            if (currentTime - this.currentTextStartTime < 2000L) {
                String animatedVKText = this.animateText(vkText, currentTime);
                this.fr4.drawStringWithShadow(animatedVKText, 35.0f, 20.0f, textColor);
            } else if (currentTime - this.currentTextStartTime < 3000L) {
                this.fr4.drawStringWithShadow(vkText, 35.0f, 20.0f, textColor);
            }
        } else if (mode.equals("Horizon")) {
            Watermark watermark = this;
            int fps = watermark.mc.func_175610_ah();
            ResourceLocation sIcon = new ResourceLocation("", "s.png");
            ResourceLocation mIcon = new ResourceLocation("", "m.png");
            ResourceLocation fIcon = new ResourceLocation("", "f.png");
            int iconSize = 12;
            int padding = 5;
            int spacing = 5;
            int x = 10;
            int y = 5;
            textColor = Color.WHITE.getRGB();
            backgroundColor = new Color(37, 37, 37, 200).getRGB();
            int normalTextWidth = this.fr4.getStringWidth("Space-Horizon");
            int boldTimeWidth = this.fr4.getStringWidth("Time: " + time);
            int boldFPSWidth = this.fr4.getStringWidth("FPS: " + fps);
            int blockWidth = iconSize + spacing + normalTextWidth + spacing + iconSize + spacing + boldTimeWidth + spacing + iconSize + spacing + boldFPSWidth + padding * 2;
            int blockHeight = Math.max(this.fr4.getHeight(), iconSize) + padding * 2;
            RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(x, y, x + blockWidth, y + blockHeight, 2.0f, 0.0f, backgroundColor, backgroundColor, backgroundColor, backgroundColor, false, true, false);
            int currentX = x + padding;
            int iconY = y + (blockHeight - iconSize) / 2;
            int textY = iconY + (iconSize - this.fr4.getHeight()) / 2;
            this.mc.func_110434_K().func_110577_a(sIcon);
            RenderUtil.drawImage(sIcon, currentX, iconY, iconSize, iconSize);
            this.fr4.drawString("Space-Horizon", currentX += iconSize + spacing, textY, textColor);
            this.mc.func_110434_K().func_110577_a(mIcon);
            RenderUtil.drawImage(mIcon, currentX += normalTextWidth + spacing, iconY, iconSize, iconSize);
            this.fr4.drawString("Time: " + time, currentX += iconSize + spacing, textY, textColor);
            this.mc.func_110434_K().func_110577_a(fIcon);
            RenderUtil.drawImage(fIcon, currentX += boldTimeWidth + spacing, iconY, iconSize, iconSize);
            this.fr4.drawString("FPS: " + fps, currentX += iconSize + spacing, textY, textColor);
        }
        array[0] = array[0] + 1;
    }

    private String animateText(String text, long currentTime) {
        long elapsedTime = currentTime - this.currentTextStartTime;
        int maxLength = text.length();
        int length = Math.min(maxLength, (int)(elapsedTime / (2000L / (long)maxLength)));
        return text.substring(0, length);
    }
}
