package recode.space.horizon.module.hud;

import com.google.common.base.Strings;
import flip.guard.annotations.Native;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.ColorUtils;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.Font.CustomFontRenderer;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.animation.Translate;

@Native
public class ModuleList
extends Module {
    private final CustomFontRenderer fr4 = CastomFontUtils.fr4;
    private ArrayList<Module> modulesSorted;
    private static final RenderItem itemRender = Minecraft.func_71410_x().func_175599_af();
    private final Translate animation = new Translate(0.0f, 0.0f);

    public ModuleList() {
        super("ModuleList", Category.HUD);
    }

    public void sortList() {
        this.modulesSorted = new ArrayList<Module>(Horizon.moduleManager.getModuleList());
        this.modulesSorted.sort(ModuleList::lambda$sortList$0);
    }

    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent.Text event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
            return;
        }
        Minecraft mc = Minecraft.func_71410_x();
        ScaledResolution sr = new ScaledResolution(mc);
        double targetX = this.isToggled() ? 0.0 : (double)sr.func_78326_a();
        this.animation.interpolate(targetX, 0.0, 0.1);
        if (!this.isToggled() && this.animation.getX() >= (double)(sr.func_78326_a() - 1)) {
            return;
        }
        this.sortList();
        ArrayList<Module> visibleModules = new ArrayList<Module>();
        for (Module module : this.modulesSorted) {
            if (module.getName().equalsIgnoreCase("ModuleList") || !module.visible || !module.isToggled()) continue;
            visibleModules.add(module);
        }
        int FONT_HEIGHT = this.fr4.getHeight();
        int MODULE_HEIGHT = FONT_HEIGHT + 6;
        int PADDING = 5;
        int LINE_WIDTH = 2;
        int totalHeight = visibleModules.size() * MODULE_HEIGHT;
        int yPos = 5;
        int[] colorIndex = new int[]{1};
        for (Module module : visibleModules) {
            String name = module.getName();
            if (Strings.isNullOrEmpty(name)) continue;
            int color = ColorUtils.astolfoColors(colorIndex[0] * 15, totalHeight);
            Horizon.color = new Color(color);
            int textWidth = this.fr4.getStringWidth(name);
            int xPos = (int)((double)(sr.func_78326_a() - textWidth - 5 - 2) - this.animation.getX());
            int bgX = xPos - 3;
            RenderUtil.drawRect(bgX, yPos, xPos + textWidth + 5, yPos + MODULE_HEIGHT, Integer.MIN_VALUE);
            Gui.func_73734_a((int)(xPos + textWidth + 5), (int)yPos, (int)(xPos + textWidth + 5 + 2), (int)(yPos + MODULE_HEIGHT), (int)color);
            this.fr4.drawStringWithShadow(name, xPos, yPos + (MODULE_HEIGHT - FONT_HEIGHT) / 2, color);
            yPos += MODULE_HEIGHT;
            colorIndex[0] = colorIndex[0] + 1;
        }
        this.modulesSorted.clear();
    }

    private static int lambda$sortList$0(Module module, Module module2) {
        int w1 = CastomFontUtils.fr4.getStringWidth(module.getName());
        int w2 = CastomFontUtils.fr4.getStringWidth(module2.getName());
        return Integer.compare(w2, w1);
    }
}
