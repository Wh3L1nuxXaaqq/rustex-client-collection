package recode.space.horizon.module.hud;

import Caesium.Panel;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.ColourUtils;

public class ClickGUI
extends Module {
    public static int red;
    public static int green;
    public static int blue;
    public static int color;
    public static List<String> Modes;

    public ClickGUI() {
        super("ClickGUI", Category.HUD);
        this.setKey(54);
        Modes.add("Castom");
        Horizon.instance.settingsManager.rSetting(new Setting("Gui", (Module)this, "Castom", (ArrayList<String>)((ArrayList)Modes)));
        Horizon.instance.settingsManager.rSetting(new Setting("Rainbow", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Red", this, 225.0, 0.0, 225.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Green", this, 0.0, 0.0, 225.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Blue", this, 0.0, 0.0, 225.0, true));
    }

    public static int getColor() {
        boolean setcolor = Horizon.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        int rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        int red = (int)Horizon.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        int green = (int)Horizon.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        int blue = (int)Horizon.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 255);
        int TheColor = setcolor ? ColourUtils.genRainbow() : color;
        return TheColor;
    }

    public static int getColor2() {
        boolean setcolor = Horizon.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        int rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        int red = (int)Horizon.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        int green = (int)Horizon.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        int blue = (int)Horizon.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 195);
        int TheColor = setcolor ? ColourUtils.genRainbowShadow() : color;
        return TheColor;
    }

    public static float getColor3() {
        boolean setcolor = Horizon.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        float rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        float red = (float)Horizon.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        float green = (float)Horizon.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        float blue = (float)Horizon.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 255.0f);
        float TheColor = setcolor ? (float)ColourUtils.genRainbowShadow() : (float)color;
        return TheColor;
    }

    @Override
    public void onEnable() {
        String Mode;
        switch (Mode = Horizon.instance.settingsManager.getSettingByName(this, "Gui").getValString()) {
            case "New": {
                mc.func_147108_a((GuiScreen)new Panel("Caesium", 22));
                break;
            }
            case "Castom": {
                mc.func_147108_a((GuiScreen)Horizon.CastomGui);
            }
        }
        super.onEnable();
        this.setToggled(false);
    }

    static {
        Modes = new ArrayList<String>();
    }
}
