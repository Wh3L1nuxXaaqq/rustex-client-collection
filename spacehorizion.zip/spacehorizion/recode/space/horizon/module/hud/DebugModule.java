package recode.space.horizon.module.hud;

import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class DebugModule
extends Module {
    private static final Logger LOGGER = LogManager.getLogger((String)"DebugModule");

    public DebugModule() {
        super("DebugModule", Category.HUD);
    }

    @SubscribeEvent
    public void onClientChatReceived(ClientChatReceivedEvent event) {
        if (this.isToggled()) {
            ITextComponent message = event.getMessage();
            String formattedText = message.func_150254_d();
            String unformattedText = message.func_150260_c();
            LOGGER.info("[DebugModule] Server message - Formatted: {}", (Object)formattedText);
            LOGGER.info("[DebugModule] Server message - Unformatted: {}", (Object)unformattedText);
        }
    }
}
