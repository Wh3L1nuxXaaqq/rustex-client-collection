package recode.space.horizon.module.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.notifications.notifications;

public class Notifications
extends Module {
    private static RenderItem itemRender;
    private Entity target;

    public Notifications() {
        super("Notifications", Category.HUD);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
            return;
        }
        notifications.show();
    }
}
