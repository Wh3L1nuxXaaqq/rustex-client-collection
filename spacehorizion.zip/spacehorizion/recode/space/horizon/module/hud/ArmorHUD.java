package recode.space.horizon.module.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class ArmorHUD
extends Module {
    private static RenderItem itemRender = Minecraft.func_71410_x().func_175599_af();

    public ArmorHUD() {
        super("ArmorHUD", Category.HUD);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        GlStateManager.func_179098_w();
        ScaledResolution resolution = new ScaledResolution(mc);
        int i = resolution.func_78326_a() / 2;
        int iteration = 0;
        int y = resolution.func_78328_b() - 55 - 10;
        for (ItemStack is : ArmorHUD.mc.field_71439_g.field_71071_by.field_70460_b) {
            ++iteration;
            if (is.func_190926_b()) continue;
            int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.func_179126_j();
            ArmorHUD.itemRender.field_77023_b = 200.0f;
            itemRender.func_180450_b(is, x, y);
            itemRender.func_180453_a(ArmorHUD.mc.field_71466_p, is, x, y, "");
            ArmorHUD.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            String s = is.func_190916_E() > 1 ? is.func_190916_E() + "" : "";
            ArmorHUD.mc.field_71466_p.func_175063_a(s, (float)(x + 19 - 2 - ArmorHUD.mc.field_71466_p.func_78256_a(s)), (float)(y + 9), 0xFFFFFF);
            float green = ((float)is.func_77958_k() - (float)is.func_77952_i()) / (float)is.func_77958_k();
            float red = 1.0f - green;
            int dmg = 100 - (int)(red * 100.0f);
            ArmorHUD.mc.field_71466_p.func_175063_a(dmg + "", (float)(x + 8 - ArmorHUD.mc.field_71466_p.func_78256_a(dmg + "") / 2), (float)(y - 11), ArmorHUD.toHex((int)(red * 255.0f), (int)(green * 255.0f), 0));
        }
        GlStateManager.func_179126_j();
        GlStateManager.func_179140_f();
    }

    public static int toHex(int r, int g, int b) {
        return 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
    }
}
