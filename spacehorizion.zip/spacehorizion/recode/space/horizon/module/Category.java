package recode.space.horizon.module;

public enum Category {
    HOME,
    COMBAT,
    MOVEMENT,
    RENDER,
    OUTHER,
    HUD;

}
