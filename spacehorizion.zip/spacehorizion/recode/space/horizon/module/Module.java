package recode.space.horizon.module;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.misc.SelfDestruct;
import recode.space.horizon.notifications.Type;
import recode.space.horizon.notifications.notifications;
import recode.space.horizon.settings.Setting;

public abstract class Module {
    protected static Minecraft mc = Minecraft.func_71410_x();
    private String name;
    private String description;
    private int key;
    private Category category;
    private boolean toggled;
    int posX;
    int posY;
    public boolean visible = true;
    private boolean hud;
    private Setting parent = null;

    public Module(String name, Category category) {
        this.name = name;
        this.description = this.description;
        this.key = 0;
        this.category = category;
        this.toggled = false;
    }

    public int getPosY() {
        return this.posY;
    }

    public int getPosX() {
        return this.posX;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public void setToggled(boolean toggled) {
        if (this.toggled == toggled) {
            return;
        }
        this.toggled = toggled;
        if (!SelfDestruct.self) {
            if (this.toggled) {
                this.onEnable();
            } else {
                this.onDisable();
            }
        }
    }

    public void toggle() {
        boolean bl = this.toggled = !this.toggled;
        if (!SelfDestruct.self) {
            if (this.toggled) {
                this.onEnableR();
            } else {
                this.onDisableR();
                this.onDisable();
            }
        }
    }

    public void onEnable() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        notifications.add(this.name, "Enable!", Type.Green);
    }

    public boolean onEnableR() {
        this.onEnable();
        return false;
    }

    public void onDisableR() {
        this.onDisable();
    }

    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        notifications.add(this.name, "Disable!", Type.Red);
    }

    public void onClientTick(TickEvent.ClientTickEvent event) {
    }

    public String getName() {
        return this.name;
    }

    public Category getCategory() {
        return this.category;
    }

    protected void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
    }

    public boolean isToggler() {
        return this.toggled;
    }

    public boolean isHud() {
        return this.hud;
    }

    public void setHud(boolean hud) {
        this.hud = hud;
    }
}
