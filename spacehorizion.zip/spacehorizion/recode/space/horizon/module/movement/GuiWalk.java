package recode.space.horizon.module.movement;

import Bobr.BobrGui;
import Caesium.ClickGui;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import recode.space.horizon.Castom.CastomGui;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class GuiWalk
extends Module {
    public GuiWalk() {
        super("GuiWalk", Category.MOVEMENT);
        Horizon.instance.settingsManager.rSetting(new Setting("Sneak", this, false));
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @SubscribeEvent
    public void onKeyUpdate(InputUpdateEvent event) {
        boolean sneakSetting = Horizon.instance.settingsManager.getSettingByName(this, "Sneak").getValBoolean();
        if (GuiWalk.mc.field_71441_e != null && GuiWalk.mc.field_71439_g != null && (GuiWalk.mc.field_71462_r instanceof GuiContainer || GuiWalk.mc.field_71462_r instanceof GuiIngameMenu || GuiWalk.mc.field_71462_r instanceof GuiOptions || GuiWalk.mc.field_71462_r instanceof BobrGui || GuiWalk.mc.field_71462_r instanceof ClickGui || GuiWalk.mc.field_71462_r instanceof CastomGui)) {
            MovementInput movementInput;
            if (Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74351_w.func_151463_i())) {
                movementInput = GuiWalk.mc.field_71439_g.field_71158_b;
                movementInput.field_192832_b += 1.0f;
                GuiWalk.mc.field_71439_g.field_71158_b.field_187255_c = true;
            }
            if (Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74368_y.func_151463_i())) {
                movementInput = GuiWalk.mc.field_71439_g.field_71158_b;
                movementInput.field_192832_b -= 1.0f;
                GuiWalk.mc.field_71439_g.field_71158_b.field_187256_d = true;
            }
            if (Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74366_z.func_151463_i())) {
                movementInput = GuiWalk.mc.field_71439_g.field_71158_b;
                movementInput.field_78902_a -= 1.0f;
                GuiWalk.mc.field_71439_g.field_71158_b.field_187258_f = true;
            }
            if (Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74370_x.func_151463_i())) {
                movementInput = GuiWalk.mc.field_71439_g.field_71158_b;
                movementInput.field_78902_a += 1.0f;
                GuiWalk.mc.field_71439_g.field_71158_b.field_187257_e = true;
            }
            GuiWalk.mc.field_71439_g.field_71158_b.field_78901_c = Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74314_A.func_151463_i());
            boolean bl = GuiWalk.mc.field_71439_g.field_71158_b.field_78899_d = sneakSetting && Keyboard.isKeyDown((int)GuiWalk.mc.field_71474_y.field_74311_E.func_151463_i());
            if (GuiWalk.mc.field_71439_g.field_71158_b.field_78899_d) {
                GuiWalk.mc.field_71439_g.field_71158_b.field_78902_a *= 0.3f;
                GuiWalk.mc.field_71439_g.field_71158_b.field_192832_b *= 0.3f;
            }
            if (GuiWalk.mc.field_71439_g.func_70051_ag()) {
                GuiWalk.mc.field_71439_g.func_70031_b(false);
            }
        }
    }
}
