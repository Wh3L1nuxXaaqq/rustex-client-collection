package recode.space.horizon.module.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class NoClip
extends Module {
    public NoClip() {
        super("NoClip", Category.MOVEMENT);
        Horizon.instance.settingsManager.rSetting(new Setting("Forward", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Up", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("UpSpeed", this, 0.2, 0.1, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Down", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("DownSpeed", this, 0.2, 0.1, 10.0, false));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        boolean forward = Horizon.instance.settingsManager.getSettingByName(this, "Forward").getValBoolean();
        boolean up = Horizon.instance.settingsManager.getSettingByName(this, "Up").getValBoolean();
        double upspeed = Horizon.instance.settingsManager.getSettingByName(this, "UpSpeed").getValDouble();
        boolean down = Horizon.instance.settingsManager.getSettingByName(this, "Down").getValBoolean();
        double downspeed = Horizon.instance.settingsManager.getSettingByName(this, "DownSpeed").getValDouble();
        if (NoClip.mc.field_71439_g.field_70123_F && forward && (NoClip.mc.field_71474_y.field_74351_w.func_151470_d() || NoClip.mc.field_71474_y.field_74366_z.func_151470_d() || NoClip.mc.field_71474_y.field_74370_x.func_151470_d() || NoClip.mc.field_71474_y.field_74368_y.func_151470_d())) {
            double newX = NoClip.mc.field_71439_g.field_70165_t + Math.sin(Math.toRadians(NoClip.mc.field_71439_g.field_70177_z)) * 2.0;
            double newZ = NoClip.mc.field_71439_g.field_70161_v - Math.cos(Math.toRadians(NoClip.mc.field_71439_g.field_70177_z)) * 2.0;
            NoClip.mc.field_71439_g.func_70107_b(newX, NoClip.mc.field_71439_g.field_70163_u, newZ);
        }
        if (up && NoClip.mc.field_71474_y.field_74314_A.func_151470_d()) {
            NoClip.mc.field_71439_g.field_70145_X = true;
            NoClip.mc.field_71439_g.func_70107_b(NoClip.mc.field_71439_g.field_70165_t, NoClip.mc.field_71439_g.field_70163_u + upspeed, NoClip.mc.field_71439_g.field_70161_v);
            NoClip.mc.field_71439_g.field_70145_X = false;
        }
        if (down && NoClip.mc.field_71474_y.field_74311_E.func_151470_d()) {
            NoClip.mc.field_71439_g.field_70145_X = true;
            NoClip.mc.field_71439_g.func_70107_b(NoClip.mc.field_71439_g.field_70165_t, NoClip.mc.field_71439_g.field_70163_u - downspeed, NoClip.mc.field_71439_g.field_70161_v);
            NoClip.mc.field_71439_g.field_70145_X = false;
        }
    }
}
