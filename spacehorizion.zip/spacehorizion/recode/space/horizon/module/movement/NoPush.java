package recode.space.horizon.module.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class NoPush
extends Module {
    public NoPush() {
        super("NoPush", Category.MOVEMENT);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        NoPush.mc.field_71439_g.field_70144_Y = 0.0f;
    }
}
