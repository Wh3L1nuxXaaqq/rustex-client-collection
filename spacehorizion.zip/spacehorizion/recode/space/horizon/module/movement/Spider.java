package recode.space.horizon.module.movement;

import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class Spider
extends Module {
    private final Minecraft mc = Minecraft.func_71410_x();

    public Spider() {
        super("Spider", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (this.mc.field_71439_g != null) {
            this.mc.field_71439_g.field_71075_bZ.field_75100_b = true;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (this.mc.field_71439_g != null) {
            this.mc.field_71439_g.field_71075_bZ.field_75100_b = false;
            this.mc.field_71439_g.field_70159_w = 0.0;
            this.mc.field_71439_g.field_70181_x = 0.0;
            this.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        boolean isMoving;
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player == null || this.mc.field_71441_e == null) {
            return;
        }
        if (player.func_70090_H() || player.func_180799_ab() || this.mc.field_71441_e.func_180495_p(new BlockPos(player.field_70165_t, player.field_70163_u - 0.1, player.field_70161_v)).func_177230_c().func_149688_o(this.mc.field_71441_e.func_180495_p(new BlockPos(player.field_70165_t, player.field_70163_u - 0.1, player.field_70161_v))).equals(Material.field_151595_p)) {
            return;
        }
        float moveSpeed = 0.01f;
        float verticalSpeed = 0.01f;
        boolean bl = isMoving = player.field_71158_b.field_187255_c || player.field_71158_b.field_187256_d || player.field_71158_b.field_187257_e || player.field_71158_b.field_187258_f;
        player.field_70181_x = player.field_71158_b.field_78901_c ? (double)verticalSpeed : (player.field_71158_b.field_78899_d ? (double)(-verticalSpeed) : 0.0);
        if (isMoving) {
            float forward;
            float yaw = player.field_70177_z;
            float f = player.field_71158_b.field_187255_c ? 1.0f : (forward = player.field_71158_b.field_187256_d ? -1.0f : 0.0f);
            float strafe = player.field_71158_b.field_187258_f ? -1.0f : (player.field_71158_b.field_187257_e ? 1.0f : 0.0f);
            player.field_70159_w = (-Math.sin(Math.toRadians(yaw)) * (double)forward - Math.cos(Math.toRadians(yaw)) * (double)strafe) * (double)moveSpeed;
            player.field_70179_y = (Math.cos(Math.toRadians(yaw)) * (double)forward - Math.sin(Math.toRadians(yaw)) * (double)strafe) * (double)moveSpeed;
        } else {
            player.field_70159_w = 0.0;
            player.field_70179_y = 0.0;
        }
        player.field_70160_al = true;
    }
}
