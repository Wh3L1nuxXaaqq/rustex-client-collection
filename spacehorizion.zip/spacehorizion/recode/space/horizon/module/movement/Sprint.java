package recode.space.horizon.module.movement;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class Sprint
extends Module {
    private boolean omnidirectional = true;

    public Sprint() {
        super("Sprint", Category.MOVEMENT);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.player != null && event.player == Sprint.mc.field_71439_g) {
            if (Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() > 6 && !Sprint.mc.field_71439_g.func_70093_af() && !Sprint.mc.field_71439_g.field_70123_F) {
                boolean isMoving;
                boolean bl = isMoving = this.omnidirectional ? this.isPlayerMoving() : Sprint.mc.field_71474_y.field_74351_w.func_151470_d();
                if (isMoving) {
                    KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)true);
                } else {
                    KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)false);
                }
            } else {
                KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)false);
            }
        }
    }

    private boolean isPlayerMoving() {
        return Sprint.mc.field_71439_g.field_191988_bg != 0.0f || Sprint.mc.field_71439_g.field_70702_br != 0.0f;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        KeyBinding.func_74510_a((int)Sprint.mc.field_71474_y.field_151444_V.func_151463_i(), (boolean)false);
    }
}
