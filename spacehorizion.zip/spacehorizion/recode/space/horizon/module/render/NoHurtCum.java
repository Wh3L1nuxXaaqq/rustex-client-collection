package recode.space.horizon.module.render;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class NoHurtCum
extends Module {
    public NoHurtCum() {
        super("NoHurtCum", Category.RENDER);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        NoHurtCum.mc.field_71439_g.field_70737_aN = 0;
        NoHurtCum.mc.field_71439_g.field_70172_ad = 0;
        NoHurtCum.mc.field_71439_g.field_70771_an = 0;
        NoHurtCum.mc.field_71439_g.field_70738_aO = 0;
    }
}
