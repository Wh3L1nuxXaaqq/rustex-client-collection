package recode.space.horizon.module.render;

import recode.space.horizon.utils.TimerUtils;

public class trail {
    private final double x;
    private final double y;
    private final double z;
    private final TimerUtils timer;

    public trail(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.timer = new TimerUtils();
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    public TimerUtils getTimer() {
        return this.timer;
    }
}
