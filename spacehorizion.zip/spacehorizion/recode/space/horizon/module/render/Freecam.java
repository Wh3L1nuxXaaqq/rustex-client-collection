package recode.space.horizon.module.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import recode.space.horizon.Horizon;
import recode.space.horizon.events.SendPacketEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class Freecam
extends Module {
    private int lastThirdPerson;
    private final Minecraft mc = Minecraft.func_71410_x();
    public static final Freecam INSTANCE = new Freecam();
    private boolean activeThisSession = false;
    public EntityOtherPlayerMP camera;

    @Override
    public void onEnable() {
        super.onEnable();
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.activeThisSession = true;
        this.mc.field_71438_f.func_72712_a();
    }

    @SubscribeEvent
    public void onInput(InputUpdateEvent inputUpdateEvent) {
        float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "horizontalSpeed").getValDouble();
        float n2 = (float)Horizon.instance.settingsManager.getSettingByName(this, "verticalSpeed").getValDouble();
        if (this.camera == null) {
            return;
        }
        MovementInput movementInput = inputUpdateEvent.getMovementInput();
        Vec3d rotateYaw = new Vec3d((double)((movementInput.field_187257_e ? n : 0.0f) - (movementInput.field_187258_f ? n : 0.0f)), (double)((movementInput.field_78901_c ? n2 : 0.0f) - (movementInput.field_78899_d ? n2 : 0.0f)), (double)((movementInput.field_187255_c ? n : 0.0f) - (movementInput.field_187256_d ? n : 0.0f))).func_178785_b((float)(-Math.toRadians(this.camera.field_70759_as)));
        this.camera.func_180426_a(this.camera.field_70165_t + rotateYaw.field_72450_a, this.camera.field_70163_u + rotateYaw.field_72448_b, this.camera.field_70161_v + rotateYaw.field_72449_c, this.camera.field_70759_as, this.camera.field_70125_A, 3, false);
        if (movementInput instanceof MovementInputFromOptions) {
            this.mc.field_71439_g.field_70701_bs = 0.0f;
            this.mc.field_71439_g.field_70702_br = 0.0f;
            this.mc.field_71439_g.field_191988_bg = 0.0f;
            this.mc.field_71439_g.func_70637_d(false);
        }
    }

    public Freecam() {
        super("Freecam", Category.OUTHER);
        Horizon.instance.settingsManager.rSetting(new Setting("verticalspeed", this, 3.5, 1.0, 12.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("horizontalspeed", this, 3.5, 1.0, 12.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("rotationspeed", this, 3.0, 1.0, 20.0, false));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
        if (this.mc.field_71441_e == null || !this.mc.field_71441_e.field_72995_K) {
            this.camera = null;
            return;
        }
        if (this.camera == null) {
            this.lastThirdPerson = this.mc.field_71474_y.field_74320_O;
            this.camera = new EntityOtherPlayerMP((World)this.mc.field_71441_e, this.mc.func_110432_I().func_148256_e());
            this.mc.field_71441_e.func_73027_a(333393333, (Entity)this.camera);
            this.camera.func_82149_j((Entity)this.mc.field_71439_g);
            this.mc.func_175607_a((Entity)this.camera);
            this.camera.field_70145_X = true;
        }
        this.camera.field_70759_as = MathHelper.func_76142_g((float)this.mc.field_71439_g.field_70759_as);
        this.camera.field_70177_z = this.mc.field_71439_g.field_70177_z;
        this.camera.field_70125_A = MathHelper.func_76142_g((float)this.mc.field_71439_g.field_70125_A);
        this.mc.field_71439_g.field_70759_as = this.camera.field_70759_as;
        this.mc.field_71439_g.field_70177_z = this.camera.field_70177_z;
        this.mc.field_71439_g.field_70125_A = this.camera.field_70125_A;
        this.mc.field_71474_y.field_74320_O = 0;
        this.camera.field_71071_by = this.mc.field_71439_g.field_71071_by;
        this.camera.func_70606_j(this.mc.field_71439_g.func_110143_aJ());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        if (this.mc.field_71441_e != null && this.mc.field_71441_e.field_72995_K) {
            this.mc.func_175607_a((Entity)this.mc.field_71439_g);
            if (this.activeThisSession) {
                this.mc.field_71474_y.field_74320_O = this.lastThirdPerson;
                this.mc.field_71441_e.func_72900_e((Entity)this.camera);
            }
        }
        this.camera = null;
        this.activeThisSession = false;
    }

    @SubscribeEvent
    public void onKeyUpdate(InputUpdateEvent event) {
        float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "rotationspeed").getValDouble();
        if (Keyboard.isKeyDown((int)203)) {
            this.camera.field_70759_as -= n;
            this.camera.field_70177_z -= n;
        }
        if (Keyboard.isKeyDown((int)205)) {
            this.camera.field_70759_as += n;
            this.camera.field_70177_z += n;
        }
        if (Keyboard.isKeyDown((int)200)) {
            this.camera.field_70125_A -= n;
        }
        if (Keyboard.isKeyDown((int)208)) {
            this.camera.field_70125_A += n;
        }
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent sendPacketEvent) {
        if (sendPacketEvent.getPacket() instanceof CPacketUseEntity && ((CPacketUseEntity)sendPacketEvent.getPacket()).func_149564_a((World)this.mc.field_71441_e) == this.mc.field_71439_g) {
            sendPacketEvent.setCanceled(true);
        }
    }
}
