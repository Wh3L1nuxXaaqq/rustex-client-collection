package recode.space.horizon.module.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.Horizon;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.ColorUtils;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.RenderUtils;

public class NameTags
extends Module {
    public static List Modes = new ArrayList();
    private FontRenderer fontRenderer;

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        block31: {
            String valString;
            block32: {
                block30: {
                    valString = Horizon.instance.settingsManager.getSettingByName(this, "Modes").getValString();
                    if (!Objects.equals(valString, "Blood")) break block30;
                    for (Entity entity : NameTags.mc.field_71441_e.field_72996_f) {
                        if (!(entity instanceof EntityPlayer) || entity == NameTags.mc.field_71439_g) continue;
                        double n = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - NameTags.mc.func_175598_ae().field_78730_l;
                        double n2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - NameTags.mc.func_175598_ae().field_78731_m;
                        double n3 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - NameTags.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glDisable((int)2929);
                        GL11.glDisable((int)3553);
                        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                        GlStateManager.func_179140_f();
                        GlStateManager.func_179147_l();
                        float n4 = Math.min(Math.max(1.2f * (NameTags.mc.field_71439_g.func_70032_d(entity) * 0.15f), 1.25f), 6.0f) * 0.015f;
                        GL11.glTranslatef((float)((float)n), (float)((float)n2 + entity.field_70131_O + 0.7f), (float)((float)n3));
                        GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
                        GlStateManager.func_179114_b((float)(-NameTags.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                        GlStateManager.func_179114_b((float)NameTags.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                        GL11.glScalef((float)(-n4), (float)(-n4), (float)(-n4));
                        String str = "Space-Horizon";
                        if (FriendManager.FRIENDS.contains(entity.func_70005_c_())) {
                            int i = (int)(((EntityPlayer)entity).func_110143_aJ() / ((EntityPlayer)entity).func_110138_aP() * 100.0f);
                            Gui.func_73734_a((int)(-NameTags.mc.field_71466_p.func_78256_a(String.valueOf(new StringBuilder().append("Space-Horizon").append(" ").append(i).append("%"))) / 2 - 2), (int)-2, (int)(NameTags.mc.field_71466_p.func_78256_a("Space-Horizon") / 2 + 16), (int)10, (int)(FriendManager.FRIENDS.contains(entity.func_70005_c_()) ? Color.green.getRGB() : Integer.MIN_VALUE));
                            NameTags.mc.field_71466_p.func_78276_b(String.valueOf(new StringBuilder().append("Space-Horizon").append(" ").append(TextFormatting.GREEN).append(i).append("%")), -this.center(String.valueOf(new StringBuilder().append("Space-Horizon").append(" ").append(TextFormatting.DARK_GREEN).append(i).append("%"))), 1, -1);
                            int n5 = -NameTags.mc.field_71466_p.func_78256_a(entity.func_70005_c_()) / 2 - 8;
                            if (Item.func_150891_b((Item)((EntityPlayer)entity).field_71071_by.func_70448_g().func_77973_b()) != 0) {
                                NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                                mc.func_175599_af().func_175042_a(((EntityPlayer)entity).field_71071_by.func_70448_g(), n5 - 2, -20);
                                NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                                int n6 = -30;
                                for (Enchantment enchantment : EnchantmentHelper.func_82781_a((ItemStack)((EntityPlayer)entity).field_71071_by.func_70448_g()).keySet()) {
                                    int getEnchantmentLevel = EnchantmentHelper.func_77506_a((Enchantment)enchantment, (ItemStack)((EntityPlayer)entity).field_71071_by.func_70448_g());
                                    NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel)), (float)(n5 + 6 - this.center(String.valueOf(new StringBuilder().append(String.valueOf(enchantment.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel)))), (float)n6, -1);
                                    n6 -= 12;
                                }
                                n5 += 15;
                            }
                            for (Object itemStack : entity.func_184193_aE()) {
                                NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                                mc.func_175599_af().func_175042_a(new ItemStack(itemStack.func_77973_b()), n5, -20);
                                NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                                int n7 = -30;
                                for (Enchantment enchantment2 : EnchantmentHelper.func_82781_a((ItemStack)itemStack).keySet()) {
                                    int getEnchantmentLevel2 = EnchantmentHelper.func_77506_a((Enchantment)enchantment2, (ItemStack)itemStack);
                                    NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment2.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel2)), (float)(n5 + 9 - this.center(enchantment2.func_77320_a().substring(12).charAt(0) + getEnchantmentLevel2)), (float)n7, -1);
                                    n7 -= 12;
                                }
                                n5 += 17;
                            }
                            GL11.glEnable((int)2929);
                            GL11.glPopMatrix();
                            continue;
                        }
                        int j = (int)(((EntityPlayer)entity).func_110143_aJ() / ((EntityPlayer)entity).func_110138_aP() * 100.0f);
                        Gui.func_73734_a((int)(-NameTags.mc.field_71466_p.func_78256_a(String.valueOf(new StringBuilder().append(entity.func_70005_c_()).append(" ").append(j).append("%"))) / 2 - 2), (int)-2, (int)(NameTags.mc.field_71466_p.func_78256_a(entity.func_70005_c_()) / 2 + 16), (int)10, (int)(FriendManager.FRIENDS.contains(entity.func_70005_c_()) ? Color.green.getRGB() : Integer.MIN_VALUE));
                        NameTags.mc.field_71466_p.func_78276_b(String.valueOf(new StringBuilder().append(entity.func_70005_c_()).append(" ").append(TextFormatting.GREEN).append(j).append("%")), -this.center(String.valueOf(new StringBuilder().append(entity.func_70005_c_()).append(" ").append(TextFormatting.DARK_GREEN).append(j).append("%"))), 1, -1);
                        int n8 = -NameTags.mc.field_71466_p.func_78256_a(entity.func_70005_c_()) / 2 - 8;
                        if (Item.func_150891_b((Item)((EntityPlayer)entity).field_71071_by.func_70448_g().func_77973_b()) != 0) {
                            Object itemStack;
                            NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                            mc.func_175599_af().func_175042_a(((EntityPlayer)entity).field_71071_by.func_70448_g(), n8 - 2, -20);
                            NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                            int n9 = -30;
                            itemStack = EnchantmentHelper.func_82781_a((ItemStack)((EntityPlayer)entity).field_71071_by.func_70448_g()).keySet().iterator();
                            while (itemStack.hasNext()) {
                                Enchantment enchantment3 = (Enchantment)itemStack.next();
                                int getEnchantmentLevel3 = EnchantmentHelper.func_77506_a((Enchantment)enchantment3, (ItemStack)((EntityPlayer)entity).field_71071_by.func_70448_g());
                                NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment3.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel3)), (float)(n8 + 6 - this.center(String.valueOf(new StringBuilder().append(String.valueOf(enchantment3.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel3)))), (float)n9, -1);
                                n9 -= 12;
                            }
                            n8 += 15;
                        }
                        for (ItemStack itemStack2 : entity.func_184193_aE()) {
                            NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                            mc.func_175599_af().func_175042_a(new ItemStack(itemStack2.func_77973_b()), n8, -20);
                            NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                            int n10 = -30;
                            for (Enchantment enchantment4 : EnchantmentHelper.func_82781_a((ItemStack)itemStack2).keySet()) {
                                int getEnchantmentLevel4 = EnchantmentHelper.func_77506_a((Enchantment)enchantment4, (ItemStack)itemStack2);
                                NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment4.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel4)), (float)(n8 + 9 - this.center(enchantment4.func_77320_a().substring(12).charAt(0) + getEnchantmentLevel4)), (float)n10, -1);
                                n10 -= 12;
                            }
                            n8 += 17;
                        }
                        GL11.glEnable((int)2929);
                        GL11.glPopMatrix();
                    }
                    break block31;
                }
                if (!Objects.equals(valString, "BloodV1")) break block32;
                for (Entity entity2 : NameTags.mc.field_71441_e.field_72996_f) {
                    if (!(entity2 instanceof EntityPlayer) || entity2 == NameTags.mc.field_71439_g) continue;
                    double n11 = entity2.field_70142_S + (entity2.field_70165_t - entity2.field_70142_S) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78730_l;
                    double n12 = entity2.field_70137_T + (entity2.field_70163_u - entity2.field_70137_T) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78731_m;
                    double n13 = entity2.field_70136_U + (entity2.field_70161_v - entity2.field_70136_U) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78728_n;
                    GL11.glPushMatrix();
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)3553);
                    GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                    GlStateManager.func_179140_f();
                    GlStateManager.func_179147_l();
                    float n14 = Math.min(Math.max(1.2f * (NameTags.mc.field_71439_g.func_70032_d(entity2) * 0.15f), 1.25f), 6.0f) * 0.015f;
                    GL11.glTranslatef((float)((float)n11), (float)((float)n12 + entity2.field_70131_O + 0.6f), (float)((float)n13));
                    GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
                    GlStateManager.func_179114_b((float)(-NameTags.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                    GlStateManager.func_179114_b((float)NameTags.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                    GL11.glScalef((float)(-n14), (float)(-n14), (float)(-n14));
                    if (FriendManager.FRIENDS.contains(entity2.func_70005_c_())) {
                        int n15 = (int)(((EntityPlayer)entity2).func_110143_aJ() / ((EntityPlayer)entity2).func_110138_aP() * 100.0f);
                        int n16 = (int)((float)(NameTags.mc.field_71466_p.func_78256_a(entity2.func_70005_c_()) / 2 + 16 - (-NameTags.mc.field_71466_p.func_78256_a(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(n15).append("%"))) / 2 - 2)) / ((EntityPlayer)entity2).func_110138_aP());
                        RenderUtil.drawSmoothRect(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append("Protect ").append(n15).append("%"))) / 2 - 2, -2.0f, this.fontRenderer.func_78256_a("Protect") / 2 + 16, 10.0f, Integer.MIN_VALUE);
                        RenderUtil.drawSmoothRect(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append("Protect ").append(n15).append("%"))) / 2 - 2, 10.0f, (float)(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append("Protect ").append(n15).append("%"))) / 2) + (float)n16 * ((EntityPlayer)entity2).func_110143_aJ(), 12.0f, ColorUtils.getHealthColor((EntityLivingBase)entity2).getRGB());
                        this.fontRenderer.func_78276_b(String.valueOf(new StringBuilder().append("Protect ").append(TextFormatting.GREEN).append(n15).append("%")), 0 - this.getcenter(String.valueOf(new StringBuilder().append("Protect ").append(TextFormatting.GREEN).append(n15).append("%"))), 1, -1);
                        int n17 = -NameTags.mc.field_71466_p.func_78256_a(entity2.func_70005_c_()) / 2 - 8;
                        if (Item.func_150891_b((Item)((EntityPlayer)entity2).field_71071_by.func_70448_g().func_77973_b()) != 0) {
                            NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                            mc.func_175599_af().func_175042_a(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND), n17 - 2, -20);
                            NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                            int n18 = -30;
                            for (Enchantment enchantment5 : EnchantmentHelper.func_82781_a((ItemStack)((EntityPlayer)entity2).field_71071_by.func_70448_g()).keySet()) {
                                int getEnchantmentLevel5 = EnchantmentHelper.func_77506_a((Enchantment)enchantment5, (ItemStack)((EntityPlayer)entity2).field_71071_by.func_70448_g());
                                NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment5.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel5)), (float)(n17 + 6 - this.getcenter(String.valueOf(new StringBuilder().append(String.valueOf(enchantment5.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel5)))), (float)n18, -1);
                                n18 -= 12;
                            }
                            n17 += 15;
                        }
                        for (Object itemStack3 : entity2.func_184193_aE()) {
                            NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                            mc.func_175599_af().func_175042_a((ItemStack)itemStack3, n17, -20);
                            NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                            int n19 = -30;
                            for (Enchantment enchantment6 : EnchantmentHelper.func_82781_a((ItemStack)itemStack3).keySet()) {
                                int getEnchantmentLevel6 = EnchantmentHelper.func_77506_a((Enchantment)enchantment6, (ItemStack)itemStack3);
                                NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment6.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel6)), (float)(n17 + 9 - this.getcenter(enchantment6.func_77320_a().substring(12).charAt(0) + getEnchantmentLevel6)), (float)n19, -1);
                                n19 -= 12;
                            }
                            n17 += 17;
                        }
                        boolean n20 = false;
                        GL11.glEnable((int)2929);
                        GL11.glPopMatrix();
                        continue;
                    }
                    int n21 = (int)(((EntityPlayer)entity2).func_110143_aJ() / ((EntityPlayer)entity2).func_110138_aP() * 100.0f);
                    int n22 = (int)((float)(NameTags.mc.field_71466_p.func_78256_a(entity2.func_70005_c_()) / 2 + 16 - (-NameTags.mc.field_71466_p.func_78256_a(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(n21).append("%"))) / 2 - 2)) / ((EntityPlayer)entity2).func_110138_aP());
                    RenderUtil.drawSmoothRect(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(n21).append("%"))) / 2 - 2, -2.0f, this.fontRenderer.func_78256_a(entity2.func_70005_c_()) / 2 + 16, 10.0f, Integer.MIN_VALUE);
                    RenderUtil.drawSmoothRect(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(n21).append("%"))) / 2 - 2, 10.0f, (float)(-this.fontRenderer.func_78256_a(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(n21).append("%"))) / 2) + (float)n22 * ((EntityPlayer)entity2).func_110143_aJ(), 12.0f, ColorUtils.getHealthColor((EntityLivingBase)entity2).getRGB());
                    this.fontRenderer.func_78276_b(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(TextFormatting.GREEN).append(n21).append("%")), 0 - this.getcenter(String.valueOf(new StringBuilder().append(entity2.func_70005_c_()).append(" ").append(TextFormatting.GREEN).append(n21).append("%"))), 1, -1);
                    int n23 = -NameTags.mc.field_71466_p.func_78256_a(entity2.func_70005_c_()) / 2 - 8;
                    if (Item.func_150891_b((Item)((EntityPlayer)entity2).field_71071_by.func_70448_g().func_77973_b()) != 0) {
                        Object itemStack3;
                        NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                        mc.func_175599_af().func_175042_a(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND), n23 - 2, -20);
                        NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                        int n24 = -30;
                        itemStack3 = EnchantmentHelper.func_82781_a((ItemStack)((EntityPlayer)entity2).field_71071_by.func_70448_g()).keySet().iterator();
                        while (itemStack3.hasNext()) {
                            Enchantment enchantment7 = (Enchantment)itemStack3.next();
                            int getEnchantmentLevel7 = EnchantmentHelper.func_77506_a((Enchantment)enchantment7, (ItemStack)((EntityPlayer)entity2).field_71071_by.func_70448_g());
                            NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment7.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel7)), (float)(n23 + 6 - this.getcenter(String.valueOf(new StringBuilder().append(String.valueOf(enchantment7.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel7)))), (float)n24, -1);
                            n24 -= 12;
                        }
                        n23 += 15;
                    }
                    for (ItemStack itemStack4 : entity2.func_184193_aE()) {
                        NameTags.mc.func_175599_af().field_77023_b = -100.0f;
                        mc.func_175599_af().func_175042_a(itemStack4, n23, -20);
                        NameTags.mc.func_175599_af().field_77023_b = 0.0f;
                        int n25 = -30;
                        for (Enchantment enchantment8 : EnchantmentHelper.func_82781_a((ItemStack)itemStack4).keySet()) {
                            int getEnchantmentLevel8 = EnchantmentHelper.func_77506_a((Enchantment)enchantment8, (ItemStack)itemStack4);
                            NameTags.mc.field_71466_p.func_175063_a(String.valueOf(new StringBuilder().append(String.valueOf(enchantment8.func_77320_a().substring(12).charAt(0)).toUpperCase()).append(getEnchantmentLevel8)), (float)(n23 + 9 - this.getcenter(enchantment8.func_77320_a().substring(12).charAt(0) + getEnchantmentLevel8)), (float)n25, -1);
                            n25 -= 12;
                        }
                        n23 += 17;
                    }
                    boolean n26 = false;
                    GL11.glEnable((int)2929);
                    GL11.glPopMatrix();
                }
                break block31;
            }
            if (!Objects.equals(valString, "ZOV")) break block31;
            for (Entity entity3 : NameTags.mc.field_71441_e.field_72996_f) {
                if (!(entity3 instanceof EntityPlayer) || entity3 == NameTags.mc.field_71439_g) continue;
                double n27 = entity3.field_70142_S + (entity3.field_70165_t - entity3.field_70142_S) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78730_l;
                double n28 = entity3.field_70137_T + (entity3.field_70163_u - entity3.field_70137_T) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78731_m;
                double n29 = entity3.field_70136_U + (entity3.field_70161_v - entity3.field_70136_U) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78728_n;
                GL11.glPushMatrix();
                GL11.glDisable((int)2929);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                float n30 = Math.min(Math.max(1.2f * NameTags.mc.field_71439_g.func_70032_d(entity3) * 0.15f, 1.25f), 6.0f) * 0.015f;
                GL11.glTranslatef((float)((float)n27), (float)((float)n28 + entity3.field_70131_O + 0.6f), (float)((float)n29));
                GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)(-NameTags.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)NameTags.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                GL11.glScalef((float)(-n30), (float)(-n30), (float)(-n30));
                float n31 = CastomFontUtils.fr4.getStringWidth(String.valueOf(new StringBuilder().append(entity3.func_145748_c_().func_150260_c()).append(TextFormatting.GREEN).append("").append(""))) + 10;
                RenderUtils.drawShadowRect(-(n31 / 2.0f), 0.0, n31 / 2.0f, 15.0, 3);
                RenderUtil.drawSmoothRect(-(n31 / 2.0f), 0.0f, n31 / 2.0f, 15.0f, new Color(0, 0, 0, 255).getRGB());
                int n32 = (int)(n31 - 4.0f);
                if (FriendManager.FRIENDS.contains(entity3.func_70005_c_())) {
                    Object e2;
                    this.fontRenderer.func_78276_b(String.valueOf(new StringBuilder().append(entity3.func_70005_c_()).append(TextFormatting.GREEN).append("").append("")), 0 - this.getcenter(String.valueOf(new StringBuilder().append(entity3.func_70005_c_()).append(TextFormatting.GREEN).append("").append(""))), 1, -1);
                    ArrayList<ItemStack> list = new ArrayList<ItemStack>();
                    if (!(((EntityPlayer)entity3).func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemAir)) {
                        list.add(((EntityPlayer)entity3).func_184586_b(EnumHand.MAIN_HAND));
                    }
                    for (Object e2 : entity3.func_184193_aE()) {
                        if (e2.func_77973_b() instanceof ItemAir) continue;
                        list.add((ItemStack)e2);
                    }
                    if (!(((EntityPlayer)entity3).func_184586_b(EnumHand.OFF_HAND).func_77973_b() instanceof ItemAir)) {
                        list.add(((EntityPlayer)entity3).func_184586_b(EnumHand.OFF_HAND));
                    }
                    int n33 = -(list.size() * 16 / 2);
                    e2 = list.iterator();
                    while (e2.hasNext()) {
                        ItemStack itemStack5 = (ItemStack)e2.next();
                        RenderItem getRenderItem = mc.func_175599_af();
                        GlStateManager.func_179094_E();
                        GlStateManager.func_179147_l();
                        RenderHelper.func_74519_b();
                        getRenderItem.field_77023_b = -100.0f;
                        getRenderItem.func_175042_a(itemStack5, n33, -20);
                        getRenderItem.field_77023_b = 0.0f;
                        RenderHelper.func_74518_a();
                        GlStateManager.func_179141_d();
                        GlStateManager.func_179084_k();
                        GlStateManager.func_179140_f();
                        GlStateManager.func_179121_F();
                        GlStateManager.func_179094_E();
                        GlStateManager.func_179140_f();
                        GlStateManager.func_179097_i();
                        GlStateManager.func_179121_F();
                        n33 += 16;
                    }
                    GL11.glEnable((int)2929);
                    GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                    GL11.glEnable((int)2929);
                    GL11.glPopMatrix();
                    continue;
                }
                this.fontRenderer.func_78276_b(String.valueOf(new StringBuilder().append(entity3.func_145748_c_().func_150260_c())), 0 - this.getcenter(String.valueOf(new StringBuilder().append(entity3.func_70005_c_()).append("").append(TextFormatting.GREEN).append("").append(""))), 1, -1);
                ArrayList<ItemStack> list2 = new ArrayList<ItemStack>();
                if (!(((EntityPlayer)entity3).func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemAir)) {
                    list2.add(((EntityPlayer)entity3).func_184586_b(EnumHand.MAIN_HAND));
                }
                for (ItemStack e2 : entity3.func_184193_aE()) {
                    if (e2.func_77973_b() instanceof ItemAir) continue;
                    list2.add(e2);
                }
                if (!(((EntityPlayer)entity3).func_184586_b(EnumHand.OFF_HAND).func_77973_b() instanceof ItemAir)) {
                    list2.add(((EntityPlayer)entity3).func_184586_b(EnumHand.OFF_HAND));
                }
                int n34 = -(list2.size() * 16 / 2);
                for (ItemStack itemStack6 : list2) {
                    RenderItem getRenderItem2 = mc.func_175599_af();
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179147_l();
                    RenderHelper.func_74519_b();
                    getRenderItem2.field_77023_b = -100.0f;
                    getRenderItem2.func_175042_a(itemStack6, n34, -20);
                    getRenderItem2.field_77023_b = 0.0f;
                    RenderHelper.func_74518_a();
                    GlStateManager.func_179141_d();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179140_f();
                    GlStateManager.func_179121_F();
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179140_f();
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179121_F();
                    n34 += 16;
                }
                GL11.glEnable((int)2929);
                GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                GL11.glEnable((int)2929);
                GL11.glPopMatrix();
            }
        }
    }

    public int getcenter(String s) {
        return NameTags.mc.field_71466_p.func_78256_a(s) / 2;
    }

    public int getcenter(int i) {
        return NameTags.mc.field_71466_p.func_78256_a(String.valueOf(i)) / 2;
    }

    public int center(String s) {
        return NameTags.mc.field_71466_p.func_78256_a(s) / 2;
    }

    public NameTags() {
        super("NameTags", Category.RENDER);
        this.fontRenderer = Minecraft.func_71410_x().field_71466_p;
        Modes.add("ZOV");
        Horizon.instance.settingsManager.rSetting(new Setting("Modes", (Module)this, "ZOV", (ArrayList<String>)((ArrayList)Modes)));
    }

    public int center(int i) {
        return NameTags.mc.field_71466_p.func_78256_a(String.valueOf(i)) / 2;
    }
}
