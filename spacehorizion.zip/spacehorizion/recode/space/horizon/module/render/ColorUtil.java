package recode.space.horizon.module.render;

import java.awt.Color;

public class ColorUtil {
    public static int RGBtoHex(int n, int n2, int n3) {
        return n << 16 | n2 << 8 | n3;
    }

    public static int toRGBA(float[] array) {
        if (array.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return ColorUtil.toRGBA(array[0], array[1], array[2], array[3]);
    }

    public static int toARGB(int r, int g, int b, int a) {
        return new Color(r, g, b, a).getRGB();
    }

    public static int toRGBA(int n, int n2, int n3) {
        return ColorUtil.toRGBA(n, n2, n3, 255);
    }

    public static int toRGBA(Color color) {
        return ColorUtil.toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int toRGBA(int n, int n2, int n3, int n4) {
        return (n << 16) + (n2 << 8) + n3 + (n4 << 24);
    }

    public static int[] getRainbow(int n, float n2) {
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        float n6 = 6.0f * (float)((System.currentTimeMillis() - (long)Math.round(n2 * 1000.0f)) % (long)(n * 1000)) / (float)(n * 1000);
        int round = Math.round(255.0f * (n6 - (float)Math.floor(n6)));
        if (n6 < 1.0f) {
            n3 = 255;
            n4 = round;
        } else if (n6 < 2.0f) {
            n3 = 255 - round;
            n4 = 255;
        } else if (n6 < 3.0f) {
            n4 = 255;
            n5 = round;
        } else if (n6 < 4.0f) {
            n4 = 255 - round;
            n5 = 255;
        } else if (n6 < 5.0f) {
            n3 = round;
            n5 = 255;
        } else if (n6 < 6.0f) {
            n3 = 255;
            n5 = 255 - round;
        }
        return new int[]{n3, n4, n5};
    }

    public static int toRGBA(double[] array) {
        if (array.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return ColorUtil.toRGBA((float)array[0], (float)array[1], (float)array[2], (float)array[3]);
    }

    public static int toRGBA(float n, float n2, float n3, float n4) {
        return ColorUtil.toRGBA((int)(n * 255.0f), (int)(n2 * 255.0f), (int)(n3 * 255.0f), (int)(n4 * 255.0f));
    }
}
