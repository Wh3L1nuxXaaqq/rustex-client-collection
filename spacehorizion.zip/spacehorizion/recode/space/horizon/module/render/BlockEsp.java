package recode.space.horizon.module.render;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.RenderUtils;
import recode.space.horizon.utils.search.Blockinfo;
import recode.space.horizon.utils.search.Search;

public class BlockEsp
extends Module {
    public static boolean trace;
    public static CopyOnWriteArrayList<Blockinfo> render;
    public static ArrayList<IBlockState> search_blocks;
    public static ArrayList<Block> search_blocks1;
    Thread search;

    public BlockEsp() {
        super("BlockESP", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("UpdateTime", this, 2.0, 0.1, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Trace", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "ore", new ArrayList<String>(){
            {
                this.add("ore");
                this.add("cloth");
                this.add("barriers");
                this.add("food");
                this.add("collector");
            }
        }));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        render = new CopyOnWriteArrayList();
        this.search = new Search();
        this.search.start();
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        trace = Horizon.instance.settingsManager.getSettingByName(this, "Trace").getValBoolean();
        try {
            ArrayList<Blockinfo> render = new ArrayList<Blockinfo>(BlockEsp.render);
            for (Blockinfo bi : render) {
                RenderUtils.blockEspFrame(new BlockPos(bi.getX(), bi.getY(), bi.getZ()), bi.getR(), bi.getG(), bi.getB());
                if (!trace) continue;
                RenderUtils.trace(mc, bi);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.search.interrupt();
    }

    static {
        render = new CopyOnWriteArrayList();
        search_blocks = new ArrayList();
        search_blocks1 = new ArrayList();
    }
}
