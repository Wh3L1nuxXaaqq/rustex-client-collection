package recode.space.horizon.module.render;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import recode.space.horizon.utils.util.Wrapper;

public class BlockUtils {
    private static Minecraft mc = Minecraft.func_71410_x();

    public static List getBlocksInDistance(float n) {
        ArrayList list = new ArrayList();
        Iterable getAllInBox = BlockPos.func_177980_a((BlockPos)new BlockPos(BlockUtils.mc.field_71439_g.field_70165_t - (double)n, BlockUtils.mc.field_71439_g.field_70163_u - (double)n, BlockUtils.mc.field_71439_g.field_70161_v - (double)n), (BlockPos)new BlockPos(BlockUtils.mc.field_71439_g.field_70165_t + (double)n, BlockUtils.mc.field_71439_g.field_70163_u + (double)n, BlockUtils.mc.field_71439_g.field_70161_v + (double)n));
        ArrayList list2 = list;
        list2.getClass();
        getAllInBox.forEach(list2::add);
        return list;
    }

    public static LinkedList findBlocksNearEntity(EntityLivingBase entityLivingBase, int n, int n2, int n3) {
        LinkedList<BlockPos> list = new LinkedList<BlockPos>();
        for (int i = (int)Wrapper.INSTANCE.player().field_70165_t - n3; i <= (int)Wrapper.INSTANCE.player().field_70165_t + n3; ++i) {
            for (int j = (int)Wrapper.INSTANCE.player().field_70161_v - n3; j <= (int)Wrapper.INSTANCE.player().field_70161_v + n3; ++j) {
                int getHeight = Wrapper.INSTANCE.world().func_189649_b(i, j);
                for (int k = 0; k <= getHeight; ++k) {
                    BlockPos blockPos = new BlockPos(i, k, j);
                    IBlockState getBlockState = Wrapper.INSTANCE.world().func_180495_p(blockPos);
                    if (n == -1 || n2 == -1) {
                        list.add(blockPos);
                        continue;
                    }
                    int getIdFromBlock = Block.func_149682_b((Block)getBlockState.func_177230_c());
                    int getMetaFromState = getBlockState.func_177230_c().func_176201_c(getBlockState);
                    if (getIdFromBlock != n || getMetaFromState != n2) continue;
                    list.add(blockPos);
                }
            }
        }
        return list;
    }

    public float[] getRotations(BlockPos blockPos) {
        double x = (double)blockPos.func_177958_n() - BlockUtils.mc.field_71439_g.field_70165_t;
        double y = (double)blockPos.func_177952_p() - BlockUtils.mc.field_71439_g.field_70161_v;
        double n = (double)blockPos.func_177956_o() - (BlockUtils.mc.field_71439_g.field_70163_u + (double)BlockUtils.mc.field_71439_g.func_70047_e());
        double x2 = MathHelper.func_76133_a((double)(x * x + y * y));
        float n2 = (float)(Math.atan2(y, x) * 180.0 / Math.PI);
        return new float[]{n2, (float)(-(Math.atan2(n2, x2) * 180.0 / Math.PI))};
    }
}
