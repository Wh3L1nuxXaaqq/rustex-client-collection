package recode.space.horizon.module.render;

import recode.space.horizon.events.event.Event;

public class EventFogColor
extends Event {
    public float red;
    public int alpha;
    public float blue;
    public float green;

    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }

    public int getAlpha() {
        return this.alpha;
    }

    public float getBlue() {
        return this.blue;
    }

    public float getGreen() {
        return this.green;
    }

    public static void setGreen(float n) {
    }

    public static void setRed(float n) {
    }

    public float getRed() {
        return this.red;
    }

    public static void setBlue(float n) {
    }

    public EventFogColor(float red, float green, float blue, int alpha) {
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.alpha = alpha;
    }
}
