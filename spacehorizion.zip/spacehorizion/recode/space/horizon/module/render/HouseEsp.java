package recode.space.horizon.module.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class HouseEsp
extends Module {
    public HouseEsp() {
        super("HouseEsp", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("WH", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Glow", this, false));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity entity : HouseEsp.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || !entity.func_184202_aL()) continue;
            entity.func_184195_f(false);
        }
    }

    void render(Entity entity, float ticks) {
        try {
            if (entity == null || entity == Minecraft.func_71410_x().field_71439_g) {
                return;
            }
            if (entity != Minecraft.func_71410_x().func_175606_aa() || Minecraft.func_71410_x().field_71474_y.field_74320_O == 0) {
                // empty if block
            }
            Minecraft.func_71410_x().func_175598_ae().func_188388_a(entity, ticks, true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        GlStateManager.func_179086_m((int)256);
        RenderHelper.func_74519_b();
        boolean Wallhack = Horizon.instance.settingsManager.getSettingByName(this, "WH").getValBoolean();
        boolean Glowing = Horizon.instance.settingsManager.getSettingByName(this, "Glow").getValBoolean();
        for (Entity entity : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || entity == Minecraft.func_71410_x().func_175606_aa()) continue;
            if (Wallhack) {
                this.render(entity, event.getPartialTicks());
            }
            if (!Glowing || entity.func_184202_aL()) continue;
            entity.func_184195_f(true);
        }
    }
}
