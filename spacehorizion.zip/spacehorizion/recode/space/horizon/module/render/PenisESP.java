package recode.space.horizon.module.render;

import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.glu.Sphere;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class PenisESP
extends Module {
    public void esp(EntityPlayer entityPlayer, double n, double n2, double n3) {
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)true);
        GL11.glLineWidth((float)1.0f);
        GL11.glTranslated((double)n, (double)n2, (double)n3);
        GL11.glRotatef((float)(-entityPlayer.field_70177_z), (float)0.0f, (float)entityPlayer.field_70131_O, (float)0.0f);
        GL11.glTranslated((double)(-n), (double)(-n2), (double)(-n3));
        GL11.glTranslated((double)n, (double)(n2 + (double)(entityPlayer.field_70131_O / 2.0f) - (double)0.225f), (double)n3);
        GL11.glColor4f((float)1.38f, (float)0.55f, (float)2.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.075f);
        Cylinder cylinder = new Cylinder();
        cylinder.setDrawStyle(100013);
        cylinder.draw(0.1f, 0.11f, 0.4f, 25, 20);
        GL11.glColor4f((float)1.38f, (float)0.85f, (float)1.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)-0.12500000298023223);
        GL11.glTranslated((double)-0.09000000074505805, (double)0.0, (double)0.0);
        Sphere sphere = new Sphere();
        sphere.setDrawStyle(100013);
        sphere.draw(0.14f, 10, 20);
        GL11.glTranslated((double)0.16000000149011612, (double)0.0, (double)0.0);
        Sphere sphere2 = new Sphere();
        sphere2.setDrawStyle(100013);
        sphere2.draw(0.14f, 10, 20);
        GL11.glColor4f((float)1.35f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)-0.07000000074505806, (double)0.0, (double)0.589999952316284);
        Sphere sphere3 = new Sphere();
        sphere3.setDrawStyle(100013);
        sphere3.draw(0.13f, 15, 20);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    public PenisESP() {
        super("PenisESP", Category.RENDER);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent renderWorldLastEvent) {
        for (Entity next : PenisESP.mc.field_71441_e.field_72996_f) {
            if (!(next instanceof EntityPlayer)) continue;
            EntityPlayer entity = (EntityPlayer)next;
            double n = renderWorldLastEvent.getPartialTicks();
            double d = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * n - PenisESP.mc.func_175598_ae().field_78730_l;
            double d2 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * n - PenisESP.mc.func_175598_ae().field_78731_m;
            double d3 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * n - PenisESP.mc.func_175598_ae().field_78728_n;
            GL11.glPushMatrix();
            RenderHelper.func_74518_a();
            this.esp(entity, d, d2, d3);
            RenderHelper.func_74519_b();
            GL11.glPopMatrix();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }
}
