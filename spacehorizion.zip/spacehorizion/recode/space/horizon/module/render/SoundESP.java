package recode.space.horizon.module.render;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.Font.CustomFontRenderer;

public class SoundESP
extends Module {
    private final Map<Vec3d, SoundInfo> soundMap = new ConcurrentHashMap<Vec3d, SoundInfo>();
    private int maxTextLength = 20;
    private static final Minecraft mc = Minecraft.func_71410_x();

    public SoundESP() {
        super("SoundESP", Category.RENDER);
        CastomFontUtils.fr3 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("rerty.ttf"), 20.0f, 0), true, true);
        Horizon.instance.settingsManager.rSetting(new Setting("MaxTextLength", this, this.maxTextLength, 5.0, 100.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("TextRed", this, 255.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("TextGreen", this, 255.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("TextBlue", this, 255.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("BackgroundRed", this, 0.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("BackgroundGreen", this, 0.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("BackgroundBlue", this, 0.0, 0.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("BackgroundAlpha", this, 112.0, 0.0, 255.0, true));
    }

    @SubscribeEvent
    public void onSound(PlaySoundEvent event) {
        if (this.isToggled()) {
            Vec3d pos = new Vec3d((double)event.getSound().func_147649_g(), (double)event.getSound().func_147654_h(), (double)event.getSound().func_147651_i());
            String soundName = event.getSound().func_147650_b().toString();
            this.soundMap.put(pos, new SoundInfo(soundName));
        }
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent event) {
        if (this.isToggled()) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179090_x();
            GlStateManager.func_179097_i();
            GlStateManager.func_179147_l();
            RenderHelper.func_74518_a();
            for (Map.Entry<Vec3d, SoundInfo> entry : this.soundMap.entrySet()) {
                Vec3d pos = entry.getKey();
                String name = entry.getValue().name;
                double x = pos.field_72450_a - SoundESP.mc.func_175598_ae().field_78730_l;
                double y = pos.field_72448_b - SoundESP.mc.func_175598_ae().field_78731_m;
                double z = pos.field_72449_c - SoundESP.mc.func_175598_ae().field_78728_n;
                this.renderString(name, x, y, z);
            }
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179126_j();
            RenderHelper.func_74519_b();
            GlStateManager.func_179121_F();
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (this.isToggled() && event.phase == TickEvent.Phase.END) {
            this.soundMap.entrySet().removeIf(entry -> {
                --((SoundInfo)entry.getValue()).lifetime;
                return ((SoundInfo)entry.getValue()).lifetime <= 0;
            });
        }
    }

    private void renderString(String text, double x, double y, double z) {
        String displayText = text.substring(text.lastIndexOf(":") + 1);
        this.maxTextLength = (int)Horizon.instance.settingsManager.getSettingByName(this, "MaxTextLength").getValDouble();
        int textRed = (int)Horizon.instance.settingsManager.getSettingByName(this, "TextRed").getValDouble();
        int textGreen = (int)Horizon.instance.settingsManager.getSettingByName(this, "TextGreen").getValDouble();
        int textBlue = (int)Horizon.instance.settingsManager.getSettingByName(this, "TextBlue").getValDouble();
        int backgroundRed = (int)Horizon.instance.settingsManager.getSettingByName(this, "BackgroundRed").getValDouble();
        int backgroundGreen = (int)Horizon.instance.settingsManager.getSettingByName(this, "BackgroundGreen").getValDouble();
        int backgroundBlue = (int)Horizon.instance.settingsManager.getSettingByName(this, "BackgroundBlue").getValDouble();
        int backgroundAlpha = (int)Horizon.instance.settingsManager.getSettingByName(this, "BackgroundAlpha").getValDouble();
        if (displayText.length() > this.maxTextLength) {
            displayText = displayText.substring(0, this.maxTextLength) + "...";
        }
        float scale = 0.02f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b((double)x, (double)y, (double)z);
        GlStateManager.func_179114_b((float)(-SoundESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)SoundESP.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.func_179152_a((float)(-scale), (float)(-scale), (float)scale);
        int width = CastomFontUtils.fr3.getStringWidth(displayText);
        int height = CastomFontUtils.fr3.getHeight();
        int padding = 4;
        int backgroundColor = backgroundAlpha << 24 | backgroundRed << 16 | backgroundGreen << 8 | backgroundBlue;
        int textColor = 0xFF000000 | textRed << 16 | textGreen << 8 | textBlue;
        this.drawRect(-width / 2 - padding, -height / 2 - padding, width / 2 + padding, height / 2 + padding, backgroundColor);
        CastomFontUtils.fr3.drawString(displayText, -width / 2, -height / 2, textColor);
        GlStateManager.func_179126_j();
        GlStateManager.func_179121_F();
    }

    private void drawRect(int left, int top, int right, int bottom, int color) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187401_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179131_c((float)red, (float)green, (float)blue, (float)alpha);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferbuilder.func_181662_b((double)left, (double)bottom, 0.0).func_181675_d();
        bufferbuilder.func_181662_b((double)right, (double)bottom, 0.0).func_181675_d();
        bufferbuilder.func_181662_b((double)right, (double)top, 0.0).func_181675_d();
        bufferbuilder.func_181662_b((double)left, (double)top, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    class SoundInfo {
        String name;
        int lifetime;

        SoundInfo(String name) {
            this.name = name;
            this.lifetime = 60;
        }
    }
}
