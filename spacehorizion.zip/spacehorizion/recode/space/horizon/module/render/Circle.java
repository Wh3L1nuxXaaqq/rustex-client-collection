package recode.space.horizon.module.render;

import net.minecraft.util.math.Vec3d;

class Circle {
    private final Vec3d vec;
    private final Vec3d color;
    byte existed;

    Vec3d position() {
        return this.vec;
    }

    Circle(Vec3d vec, Vec3d color) {
        this.vec = vec;
        this.color = color;
    }

    Vec3d color() {
        return this.color;
    }

    public boolean update() {
        byte existed;
        this.existed = existed = (byte)(this.existed + 1);
        return existed > 20;
    }
}
