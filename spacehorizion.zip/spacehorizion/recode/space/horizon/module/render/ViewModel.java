package recode.space.horizon.module.render;

import net.minecraft.item.ItemMap;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class ViewModel
extends Module {
    public ViewModel() {
        super("ViewModel", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("Position X", this, 0.0, -10.0, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Position Y", this, -0.23, -10.0, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Position Z", this, -0.45, -10.0, 10.0, false));
    }

    @SubscribeEvent
    public void onRender(RenderSpecificHandEvent e) {
        if (e.getItemStack().func_77973_b() instanceof ItemMap) {
            return;
        }
        double x = Horizon.instance.settingsManager.getSettingByName(this, "Position X").getValDouble();
        double y = Horizon.instance.settingsManager.getSettingByName(this, "Position Y").getValDouble();
        double z = Horizon.instance.settingsManager.getSettingByName(this, "Position Z").getValDouble();
        GL11.glTranslated((double)x, (double)y, (double)z);
    }
}
