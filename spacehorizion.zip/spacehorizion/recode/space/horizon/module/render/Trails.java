package recode.space.horizon.module.render;

import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.ColorUtils;
import recode.space.horizon.utils.util.AntiAliasingUtility;

public class Trails
extends Module {
    public ArrayList<Point> points = new ArrayList();

    public Trails() {
        super("Trails", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("removeTicks", this, 20.0, 10.0, 500.0, true));
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (Trails.mc.field_71474_y.field_74320_O != 0 && Trails.mc.field_71439_g.func_70089_S()) {
            boolean old = Trails.mc.field_71474_y.field_74336_f;
            Trails.mc.field_71474_y.field_74336_f = false;
            Trails.mc.field_71474_y.field_74336_f = old;
            if (!Trails.mc.field_71474_y.field_74330_P) {
                int color2;
                Point temp;
                float alpha;
                int color;
                double ix = -(Trails.mc.field_71439_g.field_70142_S + (Trails.mc.field_71439_g.field_70165_t - Trails.mc.field_71439_g.field_70142_S) * (double)event.getPartialTicks());
                double iy = -(Trails.mc.field_71439_g.field_70137_T + (Trails.mc.field_71439_g.field_70163_u - Trails.mc.field_71439_g.field_70137_T) * (double)event.getPartialTicks());
                double iz = -(Trails.mc.field_71439_g.field_70136_U + (Trails.mc.field_71439_g.field_70161_v - Trails.mc.field_71439_g.field_70136_U) * (double)event.getPartialTicks());
                float x = (float)(Trails.mc.field_71439_g.field_70142_S + (Trails.mc.field_71439_g.field_70165_t - Trails.mc.field_71439_g.field_70142_S) * (double)event.getPartialTicks());
                float y = (float)(Trails.mc.field_71439_g.field_70137_T + (Trails.mc.field_71439_g.field_70163_u - Trails.mc.field_71439_g.field_70137_T) * (double)event.getPartialTicks());
                float z = (float)(Trails.mc.field_71439_g.field_70136_U + (Trails.mc.field_71439_g.field_70161_v - Trails.mc.field_71439_g.field_70136_U) * (double)event.getPartialTicks());
                if (Trails.mc.field_71439_g.field_70159_w != 0.0 || Trails.mc.field_71439_g.field_70179_y != 0.0) {
                    this.points.add(new Point(new Vec3d((double)x, (double)y, (double)z)));
                }
                double removeTicks = Horizon.instance.settingsManager.getSettingByName(this, "removeTicks").getValDouble();
                this.points.removeIf(point -> (double)point.time >= removeTicks);
                GlStateManager.func_179094_E();
                GL11.glDepthMask((boolean)false);
                GlStateManager.func_179137_b((double)ix, (double)iy, (double)iz);
                GlStateManager.func_179147_l();
                GL11.glBlendFunc((int)770, (int)771);
                GlStateManager.func_179090_x();
                GL11.glDisable((int)2884);
                GL11.glShadeModel((int)7425);
                GL11.glDisable((int)3008);
                GlStateManager.func_179092_a((int)516, (float)0.0f);
                AntiAliasingUtility.hook(true, false, false);
                GL11.glBegin((int)8);
                for (Point point2 : this.points) {
                    color = ClickGUI.getColor();
                    if (this.points.indexOf(point2) >= this.points.size() - 1) continue;
                    alpha = 100.0f * ((float)this.points.indexOf(point2) / (float)this.points.size());
                    temp = this.points.get(this.points.indexOf(point2) + 1);
                    color2 = ColorUtils.setAlpha(color, (int)alpha);
                    ColorUtils.setColor(color2);
                    GL11.glVertex3d((double)temp.pos.field_72450_a, (double)temp.pos.field_72448_b, (double)temp.pos.field_72449_c);
                    GL11.glVertex3d((double)temp.pos.field_72450_a, (double)(temp.pos.field_72448_b + (double)Trails.mc.field_71439_g.field_70131_O - 0.1), (double)temp.pos.field_72449_c);
                }
                GL11.glEnd();
                GL11.glLineWidth((float)2.0f);
                GL11.glBegin((int)3);
                for (Point point2 : this.points) {
                    color = ClickGUI.getColor();
                    if (this.points.indexOf(point2) >= this.points.size() - 1) continue;
                    alpha = (float)new Color(color).getAlpha() * ((float)this.points.indexOf(point2) / (float)this.points.size());
                    temp = this.points.get(this.points.indexOf(point2) + 1);
                    color2 = ColorUtils.setAlpha(ColorUtils.fade(new Color(color), 5, this.points.indexOf(point2) * 10).brighter().getRGB(), (int)alpha);
                    ColorUtils.setColor(color2);
                    GL11.glVertex3d((double)temp.pos.field_72450_a, (double)temp.pos.field_72448_b, (double)temp.pos.field_72449_c);
                }
                GL11.glEnd();
                GL11.glBegin((int)3);
                for (Point point2 : this.points) {
                    color = ClickGUI.getColor();
                    if (this.points.indexOf(point2) >= this.points.size() - 1) continue;
                    alpha = (float)new Color(color).getAlpha() * ((float)this.points.indexOf(point2) / (float)this.points.size());
                    temp = this.points.get(this.points.indexOf(point2) + 1);
                    color2 = ColorUtils.setAlpha(ColorUtils.fade(new Color(color), 5, this.points.indexOf(point2) * 10).brighter().getRGB(), (int)alpha);
                    ColorUtils.setColor(color2);
                    GL11.glVertex3d((double)temp.pos.field_72450_a, (double)(temp.pos.field_72448_b + (double)Trails.mc.field_71439_g.field_70131_O - 0.1), (double)temp.pos.field_72449_c);
                }
                GL11.glEnd();
                for (Point point3 : this.points) {
                    ++point3.time;
                }
                AntiAliasingUtility.unhook(true, false, false);
                GL11.glEnable((int)3008);
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GL11.glEnable((int)2884);
                GlStateManager.func_179117_G();
                GL11.glDepthMask((boolean)true);
                GlStateManager.func_179121_F();
            }
        }
    }

    public static class Point {
        public Vec3d pos;
        public long time;

        public Point(Vec3d pos) {
            this.pos = pos;
        }
    }
}
