package recode.space.horizon.module.misc;

import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.TimerUtil;
import recode.space.horizon.utils.util.Utils;

public class AutoFarm
extends Module {
    TimerUtil timer = new TimerUtil();
    BlockPos blockPos;

    public AutoFarm() {
        super("AutoFarm", Category.OUTHER);
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) throws Throwable {
        for (Entity entity : AutoFarm.mc.field_71441_e.field_72996_f) {
            if (!(entity.func_70032_d((Entity)AutoFarm.mc.field_71439_g) <= 4.0f) || !(entity instanceof EntityArmorStand) || entity == null || entity.field_70165_t == 0.0 || entity.field_70163_u == 0.0 || entity.field_70161_v == 0.0) continue;
            ArrayList<BlockPos> blockPoss = new ArrayList<BlockPos>();
            int i = (int)entity.field_70165_t;
            int j = (int)entity.field_70161_v;
            for (int x = -2; x < 2; ++x) {
                for (int z = -2; z < 2; ++z) {
                    Block block = AutoFarm.mc.field_71441_e.func_180495_p(new BlockPos((double)(i + x), entity.field_70163_u, (double)(j + z))).func_177230_c();
                    if (block == Blocks.field_150350_a || block != Blocks.field_150406_ce && block != Blocks.field_150482_ag && block != Blocks.field_150352_o && block != Blocks.field_150366_p && block != Blocks.field_150364_r && block != Blocks.field_150363_s) continue;
                    blockPoss.add(new BlockPos((double)(i + x), entity.field_70163_u, (double)(j + z)));
                }
            }
            blockPoss.sort(Comparator.comparingDouble(pos -> entity.func_174818_b(pos)));
            if (blockPoss.isEmpty()) continue;
            this.blockPos = (BlockPos)blockPoss.get(0);
            if (this.blockPos == null) continue;
            float[] rotations = Utils.getNeededRotations(entity.field_70165_t, entity.field_70163_u + (double)0.37f, entity.field_70161_v, (float)AutoFarm.mc.field_71439_g.field_70165_t, (float)AutoFarm.mc.field_71439_g.field_70163_u + AutoFarm.mc.field_71439_g.func_70047_e(), (float)AutoFarm.mc.field_71439_g.field_70161_v);
            AutoFarm.mc.field_71439_g.field_70177_z += rotations[0] - AutoFarm.mc.field_71439_g.field_70177_z;
            AutoFarm.mc.field_71439_g.field_70125_A += rotations[1] - AutoFarm.mc.field_71439_g.field_70125_A;
            if (!TimerUtil.hasReached(230.0f) || AutoFarm.mc.field_71439_g.field_71174_a == null || this.blockPos == null) continue;
            AutoFarm.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.blockPos, EnumFacing.DOWN));
            AutoFarm.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            AutoFarm autoFarm = this;
            autoFarm.timer.reset();
        }
    }
}
