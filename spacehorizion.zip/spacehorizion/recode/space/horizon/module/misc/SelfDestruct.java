package recode.space.horizon.module.misc;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class SelfDestruct
extends Module {
    public static boolean self = false;

    public SelfDestruct() {
        super("SelfDestruct", Category.OUTHER);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        mc.func_147108_a(null);
        for (Module mod : Horizon.moduleManager.getModuleList()) {
            if (mod.getName() == "SelfDestruct") continue;
        }
        self = true;
        SelfDestruct.mc.field_71439_g.field_70177_z = 0.0f;
        SelfDestruct.mc.field_71439_g.field_70125_A = 0.0f;
    }
}
