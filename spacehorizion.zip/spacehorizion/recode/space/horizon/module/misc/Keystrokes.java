package recode.space.horizon.module.misc;

import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtils;

public class Keystrokes
extends Module {
    public int color;

    public Keystrokes() {
        super("Keystrokes", Category.HUD);
        Horizon.instance.settingsManager.rSetting(new Setting("keyX", this, 1.0, 1.0, 897.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("keyY", this, 1.0, -105.0, 340.0, true));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text text) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "keyX").getValDouble();
            float n2 = (float)Horizon.instance.settingsManager.getSettingByName(this, "keyY").getValDouble();
            int n3 = 0;
            int n4 = 0;
            GlStateManager.func_179094_E();
            if (!Keystrokes.mc.field_71474_y.field_74330_P) {
                n3 = (int)n;
                n4 = (int)n2;
                this.color = Color.white.getRGB();
                RenderUtils.drawRect(n3 + 20, n4 + 111, n3 + 41, n4 + 130, -1879048192);
                RenderUtils.drawRect(n3 + 1, n4 + 130, n3 + 61, n4 + 150, -1879048192);
                if (Keystrokes.mc.field_71474_y.field_74351_w.func_151470_d()) {
                    RenderUtils.drawRect(n3 + 21, n4 + 112, n3 + 40, n4 + 130, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74368_y.func_151470_d()) {
                    RenderUtils.drawRect(n3 + 21, n4 + 131, n3 + 40, n4 + 149, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74370_x.func_151470_d()) {
                    RenderUtils.drawRect(n3 + 2, n4 + 131, n3 + 20, n4 + 149, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74366_z.func_151470_d()) {
                    RenderUtils.drawRect(n3 + 41, n4 + 131, n3 + 60, n4 + 149, this.color);
                }
                CastomFontUtils.fr6.drawString("W", n3 + 28, n4 + 117, Color.red.getRGB());
                CastomFontUtils.fr6.drawString("A", n3 + 8, n4 + 136, Color.red.getRGB());
                CastomFontUtils.fr6.drawString("S", n3 + 28, n4 + 136, Color.red.getRGB());
                CastomFontUtils.fr6.drawString("D", n3 + 48, n4 + 136, Color.red.getRGB());
            }
            GlStateManager.func_179121_F();
        }
    }
}
