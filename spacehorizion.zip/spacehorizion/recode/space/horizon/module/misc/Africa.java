package recode.space.horizon.module.misc;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.GenerateNumber;

public class Africa
extends Module {
    private int africaColor = new Color(255, 0, 0, 76).hashCode();
    private short tickTimer = 0;
    private int colorAlpha = 76;

    public Africa() {
        super("Africa", Category.OUTHER);
    }

    @Override
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (Africa.mc.field_71439_g == null || Africa.mc.field_71441_e == null) {
            return;
        }
        Africa.mc.field_71439_g.func_70015_d(1);
    }

    @SubscribeEvent
    public void onGuiRender(RenderGameOverlayEvent e) {
        if (e.getType() == RenderGameOverlayEvent.ElementType.ALL) {
            Gui.func_73734_a((int)0, (int)0, (int)e.getResolution().func_78326_a(), (int)e.getResolution().func_78328_b(), (int)this.africaColor);
            this.tickTimer = (short)(this.tickTimer + 1);
            if (this.tickTimer > 15) {
                int alpha = (int)((float)this.colorAlpha * GenerateNumber.generateFloat(0.94f, 1.05f));
                if (alpha > 110) {
                    alpha = 110;
                } else if (alpha < 50) {
                    alpha = 50;
                }
                this.colorAlpha = alpha;
                this.africaColor = new Color(255, 101, 0, alpha).hashCode();
                this.tickTimer = 0;
            }
        }
    }
}
