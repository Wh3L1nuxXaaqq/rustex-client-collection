package recode.space.horizon.module.misc;

import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class Zoom
extends Module {
    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        Zoom.mc.field_71474_y.field_74334_X = (float)Horizon.instance.settingsManager.getSettingByName(this, "range1").getValDouble();
    }

    @SubscribeEvent
    public void FOVchanger(EntityViewRenderEvent.FOVModifier fovModifier) {
        Zoom.mc.field_71474_y.field_74334_X = (float)Horizon.instance.settingsManager.getSettingByName(this, "range").getValDouble();
    }

    public Zoom() {
        super("Zoom", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("range1", this, 50.0, 50.0, 100.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("range", this, 100.0, 10.0, 150.0, false));
    }
}
