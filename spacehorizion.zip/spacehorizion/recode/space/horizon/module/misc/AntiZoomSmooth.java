package recode.space.horizon.module.misc;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class AntiZoomSmooth
extends Module {
    public AntiZoomSmooth() {
        super("AntiZoomSmooth", Category.RENDER);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent playerTickEvent) {
        AntiZoomSmooth.mc.field_71474_y.field_74326_T = false;
    }
}
