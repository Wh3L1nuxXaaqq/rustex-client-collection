package recode.space.horizon.module.misc;

import recode.space.horizon.miscs.Discord;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.ChatUtils;

public class DiscordRPC
extends Module {
    @Override
    public void onEnable() {
        super.onEnable();
        try {
            Discord.startRPC();
        }
        catch (NoClassDefFoundError | UnsatisfiedLinkError unsatisfiedLinkError) {
            ChatUtils.sendMessage("Error: not found discord-rps.dll in natives");
            this.onDisableR();
        }
    }

    public DiscordRPC() {
        super("DiscordRPC", Category.OUTHER);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        try {
            Discord.stopRPC();
        }
        catch (NoClassDefFoundError noClassDefFoundError) {
            // empty catch block
        }
    }
}
