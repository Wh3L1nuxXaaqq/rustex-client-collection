package recode.space.horizon.module.misc;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.notifications.Type;
import recode.space.horizon.notifications.notifications;

public class MiddleClick
extends Module {
    public MiddleClick() {
        super("MCF", Category.OUTHER);
    }

    @SubscribeEvent
    public void onMiddleClick(InputEvent.MouseInputEvent event) {
        if (MiddleClick.mc.field_71439_g == null || MiddleClick.mc.field_71441_e == null) {
            return;
        }
        if (Mouse.getEventButtonState() && Mouse.getEventButton() == 2 && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
            this.clickFriend();
        }
    }

    private void clickFriend() {
        String name = MiddleClick.mc.field_71476_x.field_72308_g.func_70005_c_();
        if (FriendManager.isFriend(name)) {
            FriendManager.FRIENDS.remove(name);
            notifications.add(name, "Removed!", Type.Red);
        } else {
            FriendManager.FRIENDS.add(name);
            notifications.add(name, "Added!", Type.Green);
        }
    }
}
