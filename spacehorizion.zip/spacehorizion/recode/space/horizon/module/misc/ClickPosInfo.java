package recode.space.horizon.module.misc;

import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.ChatUtils;

public class ClickPosInfo
extends Module {
    public ClickPosInfo() {
        super("ClickPosInfo", Category.OUTHER);
    }

    @SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock rightClickBlock) {
        BlockPos pos = rightClickBlock.getPos();
        ChatUtils.sendMessage((double)pos.func_177958_n() + " " + (double)pos.func_177956_o() + " " + (double)pos.func_177952_p());
        ChatUtils.sendMessage(String.valueOf(ClickPosInfo.mc.field_71441_e.func_180495_p(pos).func_177230_c()));
    }
}
