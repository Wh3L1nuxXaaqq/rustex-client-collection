package recode.space.horizon.module.misc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.TimerUtil;

public class ChestStealer
extends Module {
    private final ArrayList<BlockPos> invalidPositions = new ArrayList();

    public ChestStealer() {
        super("ChestStealer", Category.OUTHER);
        Horizon.instance.settingsManager.rSetting(new Setting("Delay", this, 50.0, 0.0, 200.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Chest", this, true));
        Horizon.instance.settingsManager.rSetting(new Setting("EnderChest", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("Aura", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("AuraRange", this, 4.0, 1.0, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("AuraWalls", this, true));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        double delay = Horizon.instance.settingsManager.getSettingByName(this, "Delay").getValDouble();
        boolean aura = Horizon.instance.settingsManager.getSettingByName(this, "Aura").getValBoolean();
        double aurarange = Horizon.instance.settingsManager.getSettingByName(this, "AuraRange").getValDouble();
        boolean walls = Horizon.instance.settingsManager.getSettingByName(this, "AuraWalls").getValBoolean();
        BlockPos pos = ChestStealer.getSphere(ChestStealer.getPlayerPos(), (float)aurarange, 6, false, true).stream().filter(this::IsValidBlockPos).min(Comparator.comparing(blockPos -> ChestStealer.getDistanceOfEntityToBlock((Entity)ChestStealer.mc.field_71439_g, blockPos))).orElse(null);
        if (pos != null && aura && ChestStealer.mc.field_71462_r == null && TimerUtil.hasReached(300.0f)) {
            if (!ChestStealer.mc.field_71441_e.func_175623_d(pos.func_177981_b(1))) {
                this.invalidPositions.add(pos);
            }
            for (Entity en : ChestStealer.mc.field_71441_e.field_72996_f) {
                if (!(en instanceof EntityEnderCrystal) || en.func_180425_c().func_177958_n() != pos.func_177958_n() || en.func_180425_c().func_177952_p() != pos.func_177952_p()) continue;
                return;
            }
            if (!this.invalidPositions.contains(pos)) {
                if (ChestStealer.mc.field_71441_e.func_147447_a(new Vec3d(ChestStealer.mc.field_71439_g.field_70165_t, ChestStealer.mc.field_71439_g.field_70163_u + (double)ChestStealer.mc.field_71439_g.func_70047_e(), ChestStealer.mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()), false, true, false) != null && !walls) {
                    return;
                }
                ChestStealer.mc.field_71442_b.func_187099_a(ChestStealer.mc.field_71439_g, ChestStealer.mc.field_71441_e, pos, EnumFacing.UP, new Vec3d((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p()), EnumHand.MAIN_HAND);
                ChestStealer.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                TimerUtil.reset();
            }
        }
        if (ChestStealer.mc.field_71439_g.field_71070_bA instanceof ContainerChest) {
            ContainerChest container = (ContainerChest)ChestStealer.mc.field_71439_g.field_71070_bA;
            for (int i = 0; i < container.field_75151_b.size(); ++i) {
                if (container.func_85151_d().func_70301_a(i).func_77973_b() != Item.func_150899_d((int)0) && TimerUtil.hasReached((float)delay)) {
                    ChestStealer.mc.field_71442_b.func_187098_a(container.field_75152_c, i, 0, ClickType.QUICK_MOVE, (EntityPlayer)ChestStealer.mc.field_71439_g);
                    TimerUtil.reset();
                    continue;
                }
                if (!this.empty((Container)container)) continue;
                ChestStealer.mc.field_71439_g.func_71053_j();
            }
        }
    }

    public boolean empty(Container container) {
        boolean voll = true;
        int slotAmount = container.field_75151_b.size() == 90 ? 54 : 27;
        for (int i = 0; i < slotAmount; ++i) {
            if (!container.func_75139_a(i).func_75216_d()) continue;
            voll = false;
        }
        return voll;
    }

    private boolean IsValidBlockPos(BlockPos pos) {
        boolean chest = Horizon.instance.settingsManager.getSettingByName(this, "Chest").getValBoolean();
        boolean enderchest = Horizon.instance.settingsManager.getSettingByName(this, "EnderChest").getValBoolean();
        IBlockState state = ChestStealer.mc.field_71441_e.func_180495_p(pos);
        if (state.func_177230_c() instanceof BlockChest && chest || state.func_177230_c() instanceof BlockEnderChest && enderchest) {
            return ChestStealer.mc.field_71441_e.func_180495_p(pos.func_177984_a()).func_177230_c() == Blocks.field_150350_a;
        }
        return false;
    }

    public static List<BlockPos> getSphere(BlockPos blockPos, float offset, int range, boolean hollow, boolean sphere) {
        ArrayList<BlockPos> blockPosList = new ArrayList<BlockPos>();
        int blockPosX = blockPos.func_177958_n();
        int blockPosY = blockPos.func_177956_o();
        int blockPosZ = blockPos.func_177952_p();
        for (float x = (float)blockPosX - offset; x <= (float)blockPosX + offset; x += 1.0f) {
            block1: for (float z = (float)blockPosZ - offset; z <= (float)blockPosZ + offset; z += 1.0f) {
                float y = sphere ? (float)blockPosY - offset : (float)blockPosY;
                while (true) {
                    float f;
                    float f2 = f = sphere ? (float)blockPosY + offset : (float)(blockPosY + range);
                    if (!(y < f)) continue block1;
                    float dist = ((float)blockPosX - x) * ((float)blockPosX - x) + ((float)blockPosZ - z) * ((float)blockPosZ - z) + (sphere ? ((float)blockPosY - y) * ((float)blockPosY - y) : 0.0f);
                    if (!(!(dist < offset * offset) || hollow && dist < offset - 1.0f * (offset - 1.0f))) {
                        BlockPos pos = new BlockPos((double)x, (double)y, (double)z);
                        blockPosList.add(pos);
                    }
                    y += 1.0f;
                }
            }
        }
        return blockPosList;
    }

    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(ChestStealer.mc.field_71439_g.field_70165_t), Math.floor(ChestStealer.mc.field_71439_g.field_70163_u), Math.floor(ChestStealer.mc.field_71439_g.field_70161_v));
    }

    public static double getDistance(double x, double y, double z, double x1, double y1, double z1) {
        double posX = x - x1;
        double posY = y - y1;
        double posZ = z - z1;
        return Math.sqrt(posX * posX + posY * posY + posZ * posZ);
    }

    public static double getDistanceOfEntityToBlock(Entity entity, BlockPos pos) {
        return ChestStealer.getDistance(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
    }
}
