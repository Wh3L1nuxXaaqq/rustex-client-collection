package recode.space.horizon.module.misc;

import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class ChatCalc
extends Module {
    public ChatCalc() {
        super("ChatCalc", Category.OUTHER);
    }

    @SubscribeEvent
    public void chatCalc(ClientChatEvent e) {
        String[] calcArgs = new String[]{"*", "+", "-", "/"};
        try {
            for (String msg : e.getMessage().split(" ")) {
                for (String s : calcArgs) {
                    if (!msg.contains(s)) continue;
                    if (s == "*") {
                        e.setMessage(e.getMessage().replace(msg, Integer.toString(Integer.parseInt(msg.split("\\*")[0]) * Integer.parseInt(msg.split("\\*")[1]))));
                    }
                    if (s == "+") {
                        e.setMessage(e.getMessage().replace(msg, Integer.toString(Integer.parseInt(msg.split("\\+")[0]) + Integer.parseInt(msg.split("\\+")[1]))));
                    }
                    if (s == "-") {
                        e.setMessage(e.getMessage().replace(msg, Integer.toString(Integer.parseInt(msg.split("-")[0]) - Integer.parseInt(msg.split("-")[1]))));
                    }
                    if (s != "/") continue;
                    e.setMessage(e.getMessage().replace(msg, Integer.toString(Integer.parseInt(msg.split("/")[0]) / Integer.parseInt(msg.split("/")[1]))));
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
