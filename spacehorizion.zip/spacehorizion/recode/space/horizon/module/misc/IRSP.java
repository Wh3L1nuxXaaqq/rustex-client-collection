package recode.space.horizon.module.misc;

import flip.guard.annotations.Native;
import java.io.File;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

@Native
public class IRSP
extends Module {
    private Thread cleanerThread;
    private volatile boolean running = false;

    public IRSP() {
        super("RPSpoofer", Category.OUTHER);
    }

    @Override
    public void onEnable() {
        this.running = true;
        this.cleanerThread = new Thread(this::cleanLoop, "RPSpoofer-Cleaner");
        this.cleanerThread.setDaemon(true);
        this.cleanerThread.start();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.running = false;
        super.onDisable();
    }

    private void cleanLoop() {
        File folder = new File(System.getProperty("user.dir"), "server-resource-packs");
        while (this.running) {
            try {
                File[] files;
                if (!folder.exists() || !folder.isDirectory() || (files = folder.listFiles()) == null) continue;
                for (File file : files) {
                    if (file.isDirectory()) {
                        this.deleteFolder(file);
                        continue;
                    }
                    file.delete();
                }
            }
            catch (Exception exception) {
            }
        }
    }

    private void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    this.deleteFolder(file);
                    continue;
                }
                file.delete();
            }
        }
    }
}
