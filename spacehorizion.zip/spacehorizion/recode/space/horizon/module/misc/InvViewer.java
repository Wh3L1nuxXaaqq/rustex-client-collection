package recode.space.horizon.module.misc;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.RenderUtils;

public class InvViewer
extends Module {
    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent renderGameOverlayEvent) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if (renderGameOverlayEvent.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "Horizontal").getValDouble();
            float n2 = (float)Horizon.instance.settingsManager.getSettingByName(this, "Vertical").getValDouble();
            GlStateManager.func_179094_E();
            RenderHelper.func_74520_c();
            RenderUtils.drawShadowRect(n, n2, n + 145.0f, n2 + 48.0f, 2);
            GlStateManager.func_179117_G();
            for (int i = 0; i < 27; ++i) {
                ItemStack itemStack = (ItemStack)InvViewer.mc.field_71439_g.field_71071_by.field_70462_a.get(i + 9);
                float n3 = n + (float)(i % 9 * 16);
                float n4 = n2 + (float)(i / 9 * 16);
                mc.func_175599_af().func_180450_b(itemStack, (int)n3, (int)n4);
                mc.func_175599_af().func_180453_a(InvViewer.mc.field_71466_p, itemStack, (int)n3, (int)n4, (String)null);
            }
            RenderHelper.func_74518_a();
            InvViewer.mc.func_175599_af().field_77023_b = 0.0f;
            GlStateManager.func_179121_F();
        }
    }

    public InvViewer() {
        super("InvViewer", Category.OUTHER);
        Horizon.instance.settingsManager.rSetting(new Setting("Horizontal", this, 387.0, 0.0, 810.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("Vertical", this, 424.0, 0.0, 490.0, true));
    }
}
