package recode.space.horizon.module.misc;

import java.util.Random;
import java.util.Timer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class Fly
extends Module {
    private Timer timer;
    private Random random;

    public Fly() {
        super("Fly", Category.MOVEMENT);
        Horizon.instance.settingsManager.rSetting(new Setting("Speed", this, 10.0, 8.0, 40.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("EnableSpeed", this, false));
        this.timer = new Timer();
        this.random = new Random();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (Fly.mc.field_71439_g != null) {
            Fly.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (!this.isToggled() || event.player != Fly.mc.field_71439_g) {
            return;
        }
        Fly.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
        float motionY = 0.0f;
        double speed = Horizon.instance.settingsManager.getSettingByName(this, "Speed").getValDouble();
        boolean enableSpeed = Horizon.instance.settingsManager.getSettingByName(this, "EnableSpeed").getValBoolean();
        if (enableSpeed) {
            if (Fly.mc.field_71439_g.field_70173_aa % (int)(speed * 2.0) == 0) {
                motionY -= 0.08f;
            } else if (Fly.mc.field_71439_g.field_71158_b.field_78901_c && Fly.mc.field_71439_g.field_70173_aa % 1 == 0) {
                motionY += 0.031f;
            }
        } else if (Fly.mc.field_71439_g.field_71158_b.field_78901_c) {
            motionY += 0.031f;
        } else if (Fly.mc.field_71439_g.field_71158_b.field_78899_d) {
            motionY -= 0.031f;
        }
        double[] direction = this.getDirectionSpeed(0.031 * speed);
        Fly.mc.field_71439_g.field_70159_w = direction[0];
        Fly.mc.field_71439_g.field_70181_x = motionY;
        Fly.mc.field_71439_g.field_70179_y = direction[1];
        if (!Fly.mc.field_71441_e.func_184143_b(Fly.mc.field_71439_g.func_174813_aQ().func_72321_a(Fly.mc.field_71439_g.field_70159_w, Fly.mc.field_71439_g.field_70181_x, Fly.mc.field_71439_g.field_70179_y))) {
            Fly.mc.field_71439_g.func_70107_b(Fly.mc.field_71439_g.field_70165_t + Fly.mc.field_71439_g.field_70159_w, Fly.mc.field_71439_g.field_70163_u + Fly.mc.field_71439_g.field_70181_x, Fly.mc.field_71439_g.field_70161_v + Fly.mc.field_71439_g.field_70179_y);
        }
    }

    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event) {
        if (!this.isToggled()) {
            return;
        }
        Fly.mc.field_71439_g.field_71158_b.field_78902_a = 0.0f;
        Fly.mc.field_71439_g.field_71158_b.field_192832_b = 0.0f;
        Fly.mc.field_71439_g.field_71158_b.field_187255_c = false;
        Fly.mc.field_71439_g.field_71158_b.field_187256_d = false;
        Fly.mc.field_71439_g.field_71158_b.field_187257_e = false;
        Fly.mc.field_71439_g.field_71158_b.field_187258_f = false;
    }

    public BlockPos getFirstSolidBlock(EntityPlayer player, int radius) {
        BlockPos playerPos = player.func_180425_c();
        for (int x = playerPos.func_177958_n() - radius; x <= playerPos.func_177958_n() + radius; ++x) {
            for (int y = playerPos.func_177956_o() - radius; y <= playerPos.func_177956_o() + radius; ++y) {
                for (int z = playerPos.func_177952_p() - radius; z <= playerPos.func_177952_p() + radius; ++z) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!player.field_70170_p.func_180495_p(pos).func_185913_b()) continue;
                    return pos;
                }
            }
        }
        return null;
    }

    public double[] getDirectionSpeed(double speed) {
        float moveStrafe = Fly.mc.field_71439_g.field_71158_b.field_78902_a;
        float moveForward = Fly.mc.field_71439_g.field_71158_b.field_192832_b;
        float rotationYaw = Fly.mc.field_71439_g.field_70126_B + (Fly.mc.field_71439_g.field_70177_z - Fly.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(rotationYaw + 90.0f));
        double cos = Math.cos(Math.toRadians(rotationYaw + 90.0f));
        double motionX = (double)moveForward * speed * cos + (double)moveStrafe * speed * sin;
        double motionZ = (double)moveForward * speed * sin - (double)moveStrafe * speed * cos;
        return new double[]{motionX, motionZ};
    }
}
