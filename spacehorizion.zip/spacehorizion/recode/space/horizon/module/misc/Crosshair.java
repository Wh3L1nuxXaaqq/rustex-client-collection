package recode.space.horizon.module.misc;

import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.util.Colors;

public class Crosshair
extends Module {
    @SubscribeEvent
    public void onUpdate(RenderGameOverlayEvent renderGameOverlayEvent) {
        if (renderGameOverlayEvent.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
            renderGameOverlayEvent.setCanceled(true);
        }
    }

    public boolean isMoving() {
        return Horizon.instance.settingsManager.getSettingByName(this, "DYNAMIC").getValBoolean() && !Crosshair.mc.field_71439_g.field_70123_F && !Crosshair.mc.field_71439_g.func_70093_af() && (Crosshair.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || Crosshair.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f);
    }

    @SubscribeEvent
    public void Crosshair(RenderGameOverlayEvent.Text text) {
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "red").getValDouble();
            float n2 = (float)Horizon.instance.settingsManager.getSettingByName(this, "green").getValDouble();
            float n3 = (float)Horizon.instance.settingsManager.getSettingByName(this, "blue").getValDouble();
            float n4 = (float)Horizon.instance.settingsManager.getSettingByName(this, "GAP").getValDouble();
            float n5 = (float)Horizon.instance.settingsManager.getSettingByName(this, "WIDTH").getValDouble();
            float n6 = (float)Horizon.instance.settingsManager.getSettingByName(this, "SIZE").getValDouble();
            int n7 = (int)n;
            int n8 = (int)n2;
            int n9 = (int)n3;
            int n10 = 255;
            double n11 = n4;
            double n12 = n5;
            double n13 = n6;
            ScaledResolution scaledResolution = new ScaledResolution(mc);
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - n12, (double)(scaledResolution.func_78328_b() / 2) - n11 - n13 - (double)(this.isMoving() ? 2 : 0), (double)((float)(scaledResolution.func_78326_a() / 2) + 1.0f) + n12, (double)(scaledResolution.func_78328_b() / 2) - n11 - (double)(this.isMoving() ? 2 : 0), 0.5, Colors.getColor(n7, n8, n9, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - n12, (double)(scaledResolution.func_78328_b() / 2) + n11 + 1.0 + (double)(this.isMoving() ? 2 : 0) - 0.15, (double)((float)(scaledResolution.func_78326_a() / 2) + 1.0f) + n12, (double)(scaledResolution.func_78328_b() / 2 + 1) + n11 + n13 + (double)(this.isMoving() ? 2 : 0) - 0.15, 0.5, Colors.getColor(n7, n8, n9, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2) - n11 - n13 - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)(scaledResolution.func_78328_b() / 2) - n12, (double)(scaledResolution.func_78326_a() / 2) - n11 - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)((float)(scaledResolution.func_78328_b() / 2) + 1.0f) + n12, 0.5, Colors.getColor(n7, n8, n9, 255), new Color(0, 0, 0, 255).getRGB());
            RenderUtil.rectangleBordered((double)(scaledResolution.func_78326_a() / 2 + 1) + n11 + (double)(this.isMoving() ? 2 : 0), (double)(scaledResolution.func_78328_b() / 2) - n12, (double)(scaledResolution.func_78326_a() / 2) + n13 + n11 + 1.0 + (double)(this.isMoving() ? 2 : 0), (double)((float)(scaledResolution.func_78328_b() / 2) + 1.0f) + n12, 0.5, Colors.getColor(n7, n8, n9, 255), new Color(0, 0, 0, 255).getRGB());
        }
    }

    public Crosshair() {
        super("Crosshair", Category.RENDER);
        Horizon.instance.settingsManager.rSetting(new Setting("red", this, 255.0, 1.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("green", this, 255.0, 1.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("blue", this, 255.0, 1.0, 255.0, true));
        Horizon.instance.settingsManager.rSetting(new Setting("DYNAMIC", this, false));
        Horizon.instance.settingsManager.rSetting(new Setting("GAP", this, 0.25, 0.0, 15.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("WIDTH", this, 0.25, 0.0, 10.0, false));
        Horizon.instance.settingsManager.rSetting(new Setting("SIZE", this, 1.0, 0.0, 15.0, false));
    }
}
