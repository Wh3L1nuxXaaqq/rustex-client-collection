package recode.space.horizon.module.misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.Setting;

public class FogColor
extends Module {
    public static List Modes = new ArrayList();
    private long spin = 0L;

    public FogColor() {
        super("FogColor", Category.OUTHER);
        Modes.add("Spin");
        Modes.add("Day");
        Modes.add("Night");
        Modes.add("Morning");
        Modes.add("Sunset");
        Horizon.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "Day", (ArrayList<String>)((ArrayList)Modes)));
        Horizon.instance.settingsManager.rSetting(new Setting("TimeSpin Speed", this, 2.0, 1.0, 10.0, false));
    }

    @SubscribeEvent
    public void onUpdate(EntityViewRenderEvent.FogColors fogColors) {
        String valString = Horizon.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        float n = (float)Horizon.instance.settingsManager.getSettingByName(this, "TimeSpin Speed").getValDouble();
        if (valString.equalsIgnoreCase("Spin")) {
            FogColor.mc.field_71441_e.func_72877_b(this.spin);
            this.spin += (long)(n * 100.0f);
        } else if (valString.equalsIgnoreCase("Day")) {
            FogColor.mc.field_71441_e.func_72877_b(5000L);
        } else if (valString.equalsIgnoreCase("Night")) {
            FogColor.mc.field_71441_e.func_72877_b(17000L);
        } else if (valString.equalsIgnoreCase("Morning")) {
            FogColor.mc.field_71441_e.func_72877_b(0L);
        } else if (valString.equalsIgnoreCase("Sunset")) {
            FogColor.mc.field_71441_e.func_72877_b(13000L);
        }
    }

    @SubscribeEvent
    public void onFogColorRender(EntityViewRenderEvent.FogColors fogColors) {
        Color hsbColor = Color.getHSBColor((float)(Math.ceil(System.currentTimeMillis() + 300L + 300L) / 15.0 % 360.0 / 360.0), 0.4f, 1.0f);
        fogColors.setRed((float)hsbColor.getRed() / 255.0f);
        fogColors.setGreen((float)hsbColor.getGreen() / 255.0f);
        fogColors.setBlue((float)hsbColor.getBlue() / 255.0f);
    }
}
