package recode.space.horizon.module.misc;

import org.lwjgl.opengl.Display;
import recode.space.horizon.Horizon;
import recode.space.horizon.manager.ModuleManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;

public class Panic
extends Module {
    public static boolean isPanic = false;

    public Panic() {
        super("Panic", Category.OUTHER);
    }

    @Override
    public void onEnable() {
        isPanic = true;
        Display.setTitle((String)"Minecraft 1.12.2");
        for (Module m : ModuleManager.modules) {
            if (m == this) continue;
            m.setToggled(false);
        }
    }

    @Override
    public void onDisable() {
        isPanic = false;
        Display.setTitle((String)Horizon.name);
    }
}
