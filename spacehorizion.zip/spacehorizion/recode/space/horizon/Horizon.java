package recode.space.horizon;

import Bobr.BobrGui;
import flip.guard.annotations.Native;
import java.awt.Color;
import java.lang.reflect.Field;
import javax.swing.JFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.util.Session;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import recode.space.horizon.Castom.CastomGui;
import recode.space.horizon.events.event.EventManager;
import recode.space.horizon.manager.ModuleManager;
import recode.space.horizon.module.Module;
import recode.space.horizon.settings.SettingsManager;
import recode.space.horizon.utils.RotationManager;
import recode.space.horizon.utils.config.ChatEvent;
import recode.space.horizon.utils.config.CommandCfg;
import recode.space.horizon.utils.config.ConfigManager;

@Native
public class Horizon {
    public static String name = "Space-Horizon 1.12.2";
    public static String FULL_name = "Space-Horizon 1.12.2";
    public static String version = "1.0.1";
    private static JFrame frame;
    public static ModuleManager moduleManager;
    public static EventManager eventManager;
    public static Horizon instance;
    public SettingsManager settingsManager;
    public ConfigManager configManager;
    private RotationManager rotationManager;
    public static Color color;
    public static BobrGui bobrGui;
    public static CastomGui CastomGui;
    private static String UID;
    private static String ROLE;
    private static String USER;

    public static void startup() {
        Display.setTitle((String)name);
    }

    public static void setSession(Session s) {
        Class<?> mc = Minecraft.func_71410_x().getClass();
        try {
            Field session = null;
            for (Field f : mc.getDeclaredFields()) {
                if (!f.getType().isInstance(s)) continue;
                session = f;
            }
            if (session == null) {
                throw new IllegalStateException("Session Null");
            }
            session.setAccessible(true);
            session.set(Minecraft.func_71410_x(), s);
            session.setAccessible(false);
            name = "Space-Horizon 1.12.2 | User: " + Horizon.getUSER();
            Display.setTitle((String)name);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Color getClientColor() {
        return color;
    }

    public static String version() {
        return version;
    }

    public RotationManager getRotationManager() {
        if (this.rotationManager == null) {
            this.rotationManager = new RotationManager();
        }
        return this.rotationManager;
    }

    public Minecraft mc() {
        return Minecraft.func_71410_x();
    }

    public void init() throws Exception {
        MinecraftForge.EVENT_BUS.register((Object)this);
        MinecraftForge.EVENT_BUS.register((Object)new ChatEvent());
        this.settingsManager = new SettingsManager();
        moduleManager = new ModuleManager();
        this.rotationManager = new RotationManager();
        this.configManager = new ConfigManager();
        ClientCommandHandler.instance.func_71560_a((ICommand)new CommandCfg());
        bobrGui = new BobrGui();
        CastomGui = new CastomGui();
    }

    public static String getUID() {
        return UID;
    }

    public static String getROLE() {
        return ROLE;
    }

    public static String getUSER() {
        return USER;
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if (Minecraft.func_71410_x().field_71441_e == null || Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        try {
            if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
                int keyCode = Keyboard.getEventKey();
                if (keyCode <= 0) {
                    return;
                }
                for (Module m : ModuleManager.modules) {
                    if (m.getKey() != keyCode || keyCode <= 0) continue;
                    m.toggle();
                }
            }
        }
        catch (Exception q) {
            q.printStackTrace();
        }
    }

    static {
        color = Color.red;
        UID = null;
        ROLE = null;
        USER = null;
    }
}
