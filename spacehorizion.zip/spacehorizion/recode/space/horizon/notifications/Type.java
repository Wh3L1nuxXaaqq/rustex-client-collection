package recode.space.horizon.notifications;

public enum Type {
    Green,
    Red,
    OK;

}
