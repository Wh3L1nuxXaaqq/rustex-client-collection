package recode.space.horizon.notifications;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.notifications.Type;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;

public class notifications {
    public static List<String> Names = new ArrayList<String>();
    public static List<String> Tests = new ArrayList<String>();
    public static List<Type> Types = new ArrayList<Type>();
    public static List<Integer> Times = new ArrayList<Integer>();
    private static float height = 30.0f;
    private static float width = 100.0f;

    public static void add(String main_input, String text_input, Type type_input) {
        Names.add(main_input);
        Tests.add(text_input);
        Types.add(type_input);
        Times.add(0);
    }

    public static void drawnotif(int i, String name, String text, Type type, int time) {
        GlStateManager.func_179098_w();
        ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
        GL11.glPushMatrix();
        if (time >= 110) {
            GL11.glTranslated((double)(sr.func_78326_a() - 110), (double)((double)sr.func_78328_b() - (double)time * 1.5 + 10.0), (double)0.0);
        } else {
            GL11.glTranslated((double)(sr.func_78326_a() - time), (double)((double)sr.func_78328_b() - (double)time * 1.5 + 10.0), (double)0.0);
        }
        int alpha = (int)(230.0 - ((double)time - 7.6));
        if (alpha >= 0) {
            if (type == Type.Green) {
                RenderUtil.drawSmoothRect(0.0f, 0.0f, width, height, new Color(35, 35, 40, 255).getRGB());
                RenderUtil.drawSmoothRect(0.0f, 0.0f, 7.0f, height, new Color(51, 255, 0, 255).getRGB());
                CastomFontUtils.fr5.drawStringWithShadow(name, 10.0f, 4.0f, ClickGUI.getColor());
                CastomFontUtils.fr5.drawString(text, 10.0f, 4 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(255, 255, 255, alpha).getRGB());
            } else if (type == Type.Red) {
                RenderUtil.drawSmoothRect(0.0f, 0.0f, width, height, new Color(35, 35, 40, 255).getRGB());
                RenderUtil.drawSmoothRect(0.0f, 0.0f, 7.0f, height, new Color(255, 0, 0, 255).getRGB());
                CastomFontUtils.fr5.drawStringWithShadow(name, 10.0f, 4.0f, ClickGUI.getColor());
                CastomFontUtils.fr5.drawString(text, 10.0f, 4 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(255, 255, 255, alpha).getRGB());
            } else if (type == Type.OK) {
                RenderUtil.drawSmoothRect(0.0f, 0.0f, width, height, new Color(35, 35, 40, 255).getRGB());
                RenderUtil.drawSmoothRect(0.0f, 0.0f, 7.0f, height, new Color(51, 255, 0, 255).getRGB());
                CastomFontUtils.fr5.drawStringWithShadow(name, 10.0f, 4.0f, ClickGUI.getColor());
                CastomFontUtils.fr5.drawString(text, 10.0f, 4 + Minecraft.func_71410_x().field_71466_p.field_78288_b, new Color(255, 255, 255, alpha).getRGB());
            }
        }
        GL11.glPopMatrix();
        GlStateManager.func_179090_x();
    }

    public static void show() {
        int i;
        for (i = 0; i < Names.size(); ++i) {
            if (Times.get(i) != 230) {
                Times.set(i, Times.get(i) + 1);
                continue;
            }
            Names.remove(i);
            Tests.remove(i);
            Types.remove(i);
            Times.remove(i);
        }
        height = 22.0f;
        for (i = 0; i < Names.size(); ++i) {
            String name = Names.get(i);
            String text = Tests.get(i);
            Type type = Types.get(i);
            int time = Times.get(i);
            notifications.drawnotif(i, name, text, type, time);
        }
    }
}
