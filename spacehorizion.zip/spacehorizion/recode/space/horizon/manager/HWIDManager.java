package recode.space.horizon.manager;

import java.util.ArrayList;
import java.util.List;
import recode.space.horizon.utils.util.DisplayUtil;
import recode.space.horizon.utils.util.NoStackTraceThrowable;
import recode.space.horizon.utils.util.SystemUtil;
import recode.space.horizon.utils.util.URLReader;

public class HWIDManager {
    public static final String pastebinURL = "\u0442\u0443\u0442 \u0432\u0430\u0448\u0430 \u0441\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u043f\u0430\u0441\u0442\u0435\u0431\u0438\u043d \u0441 \u0445\u0432\u0438\u0434\u0430m\u0435";
    public static List<String> hwids = new ArrayList<String>();

    public static void hwidCheck() {
        hwids = URLReader.readURL();
        boolean isHwidPresent = hwids.contains(SystemUtil.getSystemInfo());
        if (!isHwidPresent) {
            DisplayUtil.Display();
            throw new NoStackTraceThrowable("");
        }
    }
}
