package recode.space.horizon.manager;

import com.google.common.reflect.ClassPath;
import java.util.ArrayList;
import recode.space.horizon.font.FontUtils;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.combat.AimAssist;
import recode.space.horizon.module.combat.AimBot;
import recode.space.horizon.module.combat.AimBot2;
import recode.space.horizon.module.combat.AntiBot;
import recode.space.horizon.module.combat.BAim;
import recode.space.horizon.module.combat.MicoBot;
import recode.space.horizon.module.hud.ArmorHUD;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.module.hud.ModuleList;
import recode.space.horizon.module.hud.Notifications;
import recode.space.horizon.module.hud.Watermark;
import recode.space.horizon.module.misc.Africa;
import recode.space.horizon.module.misc.AntiZoomSmooth;
import recode.space.horizon.module.misc.AutoFarm;
import recode.space.horizon.module.misc.ChatCalc;
import recode.space.horizon.module.misc.ChestStealer;
import recode.space.horizon.module.misc.ClickPosInfo;
import recode.space.horizon.module.misc.Crosshair;
import recode.space.horizon.module.misc.DiscordRPC;
import recode.space.horizon.module.misc.Fly;
import recode.space.horizon.module.misc.FogColor;
import recode.space.horizon.module.misc.IRSP;
import recode.space.horizon.module.misc.InvViewer;
import recode.space.horizon.module.misc.Keystrokes;
import recode.space.horizon.module.misc.MiddleClick;
import recode.space.horizon.module.misc.Zoom;
import recode.space.horizon.module.movement.GuiWalk;
import recode.space.horizon.module.movement.NoClip;
import recode.space.horizon.module.movement.NoPush;
import recode.space.horizon.module.movement.Spider;
import recode.space.horizon.module.movement.Sprint;
import recode.space.horizon.module.render.BlockEsp;
import recode.space.horizon.module.render.ChinaHat;
import recode.space.horizon.module.render.ESP;
import recode.space.horizon.module.render.FakePlayer;
import recode.space.horizon.module.render.Freecam;
import recode.space.horizon.module.render.FullBright;
import recode.space.horizon.module.render.HouseEsp;
import recode.space.horizon.module.render.ItemESP;
import recode.space.horizon.module.render.NameTags;
import recode.space.horizon.module.render.NoHurtCum;
import recode.space.horizon.module.render.PenisESP;
import recode.space.horizon.module.render.SoundESP;
import recode.space.horizon.module.render.Tracers;
import recode.space.horizon.module.render.Trails;
import recode.space.horizon.module.render.ViewModel;
import recode.space.horizon.module.render.WallHack;
import recode.space.horizon.module.render.WallHackPlayer;

public class ModuleManager {
    public static ArrayList<Module> modules;

    public ModuleManager() {
        modules = new ArrayList();
        modules.clear();
        modules.add(new BlockEsp());
        modules.add(new BAim());
        modules.add(new AimBot());
        modules.add(new IRSP());
        modules.add(new Fly());
        modules.add(new Trails());
        modules.add(new ClickGUI());
        modules.add(new SoundESP());
        modules.add(new ESP());
        modules.add(new AutoFarm());
        modules.add(new AntiZoomSmooth());
        modules.add(new MicoBot());
        modules.add(new ClickPosInfo());
        modules.add(new ChestStealer());
        modules.add(new DiscordRPC());
        modules.add(new ChatCalc());
        modules.add(new HouseEsp());
        modules.add(new AimBot2());
        modules.add(new Spider());
        modules.add(new Zoom());
        modules.add(new PenisESP());
        modules.add(new ItemESP());
        modules.add(new Tracers());
        modules.add(new Crosshair());
        modules.add(new GuiWalk());
        modules.add(new NoClip());
        modules.add(new FogColor());
        modules.add(new ArmorHUD());
        modules.add(new Keystrokes());
        modules.add(new Freecam());
        modules.add(new FullBright());
        modules.add(new InvViewer());
        modules.add(new NameTags());
        modules.add(new WallHackPlayer());
        modules.add(new NoHurtCum());
        modules.add(new ModuleList());
        modules.add(new ViewModel());
        modules.add(new Notifications());
        modules.add(new FakePlayer());
        modules.add(new Africa());
        modules.add(new MiddleClick());
        modules.add(new ChinaHat());
        modules.add(new Sprint());
        modules.add(new NoPush());
        modules.add(new AimAssist());
        modules.add(new AntiBot());
        modules.add(new WallHack());
        modules.add(new Watermark());
        FontUtils.bootstrap();
        for (Module module : modules) {
        }
    }

    public static ArrayList<Class<?>> getClasses(String packageName) {
        ArrayList classes = new ArrayList();
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            for (ClassPath.ClassInfo info : ClassPath.from(loader).getAllClasses()) {
                if (!info.getName().startsWith(packageName)) continue;
                classes.add(info.load());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return classes;
    }

    public Module getModule(String name) {
        for (Module m : modules) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    public <T extends Module> T getModuleByClass(Class<T> clazz) {
        for (Module module : modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)module;
        }
        return null;
    }

    public ArrayList<Module> getModuleList() {
        return modules;
    }

    public ArrayList<Module> getModulesInCategory(Category c) {
        ArrayList<Module> mods = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getCategory() != c) continue;
            mods.add(m);
        }
        return mods;
    }

    public ArrayList<Module> getModules(Category category) {
        ArrayList<Module> modules2 = new ArrayList<Module>();
        for (Module module : modules) {
            if (module.getCategory() != category) continue;
            modules2.add(module);
        }
        return modules2;
    }
}
