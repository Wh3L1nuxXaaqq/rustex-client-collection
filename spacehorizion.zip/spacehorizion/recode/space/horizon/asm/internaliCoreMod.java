package recode.space.horizon.asm;

import java.util.Map;
import javax.annotation.Nullable;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

@IFMLLoadingPlugin.MCVersion(value="1.12.2")
@IFMLLoadingPlugin.TransformerExclusions(value={"dev.jeklout.narkozz.asm"})
public class internaliCoreMod
implements IFMLLoadingPlugin {
    public String[] getASMTransformerClass() {
        return new String[]{"dev.jeklout.narkozz.asm.InternaliClassTransformer"};
    }

    public String getModContainerClass() {
        return null;
    }

    @Nullable
    public String getSetupClass() {
        return null;
    }

    public void injectData(Map<String, Object> data) {
    }

    public String getAccessTransformerClass() {
        return null;
    }
}
