package recode.space.horizon.utils;

public class TimerHelper {
    private long previousTime = -1L;
    private long ms = this.getCurrentMS();

    public long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public long getCurrentTime() {
        return System.currentTimeMillis();
    }

    public short convert(float n) {
        return (short)(1000.0f / n);
    }

    public boolean check(float n) {
        return (float)(this.getCurrentTime() - this.previousTime) >= n;
    }

    public boolean hasReached(float n) {
        return (float)(this.getCurrentMS() - this.ms) > n;
    }

    public void reset() {
        this.previousTime = this.getCurrentTime();
    }

    public long getTime() {
        return System.currentTimeMillis() - this.previousTime;
    }

    public long get() {
        return this.previousTime;
    }
}
