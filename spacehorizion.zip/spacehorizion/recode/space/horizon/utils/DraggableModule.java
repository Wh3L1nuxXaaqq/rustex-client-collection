package recode.space.horizon.utils;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import recode.space.horizon.utils.DraggableComponent;

public class DraggableModule {
    public DraggableComponent drag;
    public int x;
    protected Minecraft mc = Minecraft.func_71410_x();
    public String name;
    public int y;

    public String getName() {
        return this.name;
    }

    public void setX2(int xPosition) {
        this.drag.setXPosition(xPosition);
    }

    public int getX2() {
        return this.x;
    }

    public DraggableModule(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.drag = new DraggableComponent(this.x, this.y, this.getWidth(), this.getHeight(), new Color(255, 255, 255, 0).getRGB());
    }

    public int getX() {
        return this.drag.getXPosition();
    }

    public void render(int n, int n2) {
        this.drag.draw(n, n2);
    }

    public int getY() {
        return this.drag.getYPosition();
    }

    public void draw() {
    }

    public int getHeight() {
        return 50;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getY2() {
        return this.y;
    }

    public void setY2(int yPosition) {
        this.drag.setYPosition(yPosition);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWidth() {
        return 50;
    }
}
