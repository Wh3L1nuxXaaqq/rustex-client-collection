package recode.space.horizon.utils;

import java.util.ArrayList;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class DraggableComponent {
    private final int height;
    private int x;
    private int lastX;
    private int color;
    private int lastY;
    private boolean canRender = true;
    private final int width;
    public static ArrayList draggableModules = new ArrayList();
    private int y;
    private boolean dragging;

    public DraggableComponent(int x, int y, int width, int height, int color) {
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
        this.color = color;
    }

    private void draggingFix(int n, int n2) {
        if (this.dragging) {
            this.x = n + this.lastX;
            this.y = n2 + this.lastY;
            if (!Mouse.isButtonDown((int)0)) {
                this.dragging = false;
            }
        }
    }

    public void draw(int n, int n2) {
        if (this.canRender) {
            this.draggingFix(n, n2);
            Gui.func_73734_a((int)this.getXPosition(), (int)(this.getYPosition() - this.getHeight() / 4), (int)(this.getXPosition() + this.getWidth()), (int)(this.getYPosition() + this.getHeight()), (int)this.getColor());
            boolean b = n >= this.getXPosition() && n <= this.getXPosition() + this.getWidth();
            boolean n3 = false;
            if (n2 < this.getYPosition() - this.getHeight() / 4 || n2 > this.getYPosition() - this.getHeight() / 4 + this.getHeight()) {
                n3 = false;
            }
            boolean n4 = n3;
            if (b && n4) {
                if (Mouse.isButtonDown((int)0)) {
                    if (!this.dragging && draggableModules.size() <= 1) {
                        this.lastX = this.x - n;
                        this.lastY = this.y - n2;
                        this.dragging = true;
                    }
                } else {
                    draggableModules.clear();
                }
            }
        }
    }

    public int getColor() {
        return this.color;
    }

    public void setXPosition(int x) {
        this.x = x;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public boolean isCanRender() {
        return this.canRender;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getYPosition() {
        return this.y;
    }

    public void setYPosition(int y) {
        this.y = y;
    }

    public boolean isDragging() {
        return this.dragging;
    }

    public void setCanRender(boolean canRender) {
        this.canRender = canRender;
    }

    public boolean isHovered(int n, int n2) {
        return n >= this.getXPosition() && n <= this.getXPosition() + this.getWidth() && n2 >= this.getYPosition() - this.getHeight() / 4 && n2 <= this.getYPosition() - this.getHeight() / 4 + this.getHeight();
    }

    public int getXPosition() {
        return this.x;
    }
}
