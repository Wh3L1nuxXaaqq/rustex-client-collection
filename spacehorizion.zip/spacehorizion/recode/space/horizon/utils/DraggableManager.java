package recode.space.horizon.utils;

import java.util.ArrayList;
import recode.space.horizon.utils.IndicatorsComponent;

public class DraggableManager {
    public ArrayList mods = new ArrayList<IndicatorsComponent>();

    public void setMods(ArrayList mods) {
        this.mods = mods;
    }

    public DraggableManager() {
        this.mods.add(new IndicatorsComponent());
    }

    public ArrayList getMods() {
        return this.mods;
    }
}
