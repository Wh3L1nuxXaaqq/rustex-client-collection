package recode.space.horizon.utils.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class URLReader {
    public static List<String> readURL() {
        ArrayList<String> s = new ArrayList<String>();
        try {
            String hwid;
            URL url = new URL("\u0442\u0443\u0442 \u0432\u0430\u0448\u0430 \u0441\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u043f\u0430\u0441\u0442\u0435\u0431\u0438\u043d \u0441 \u0445\u0432\u0438\u0434\u0430m\u0435");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
            while ((hwid = bufferedReader.readLine()) != null) {
                s.add(hwid);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return s;
    }
}
