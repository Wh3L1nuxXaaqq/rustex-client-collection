package recode.space.horizon.utils.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.Packet;

public class Wrapper {
    public static volatile Wrapper INSTANCE = new Wrapper();

    public Minecraft getMinecraft() {
        return Minecraft.func_71410_x();
    }

    public InventoryPlayer inventory() {
        return this.player().field_71071_by;
    }

    public GameSettings mcSettings() {
        return Wrapper.INSTANCE.mc().field_71474_y;
    }

    public void sendPacket(Packet packet) {
        this.player().field_71174_a.func_147297_a(packet);
    }

    public EntityPlayerSP getLocalPlayer() {
        return Wrapper.INSTANCE.getMinecraft().field_71439_g;
    }

    public GameSettings getGameSettings() {
        return Wrapper.INSTANCE.getMinecraft().field_71474_y;
    }

    public PlayerControllerMP controller() {
        return Wrapper.INSTANCE.mc().field_71442_b;
    }

    public Minecraft mc() {
        return Minecraft.func_71410_x();
    }

    public FontRenderer fontRenderer() {
        return Wrapper.INSTANCE.mc().field_71466_p;
    }

    public FontRenderer getFontRenderer() {
        return Wrapper.INSTANCE.getMinecraft().field_71466_p;
    }

    public WorldClient getWorld() {
        return Wrapper.INSTANCE.getMinecraft().field_71441_e;
    }

    public WorldClient world() {
        return Wrapper.INSTANCE.mc().field_71441_e;
    }

    public EntityPlayerSP player() {
        return Wrapper.INSTANCE.mc().field_71439_g;
    }
}
