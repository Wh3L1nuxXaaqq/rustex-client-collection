package recode.space.horizon.utils.util;

import org.lwjgl.opengl.GL11;

public class AntiAliasingUtility {
    public static void hook(boolean line, boolean polygon, boolean point) {
        if (line) {
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
        }
        if (polygon) {
            GL11.glEnable((int)2881);
            GL11.glHint((int)3155, (int)4354);
        }
        if (point) {
            GL11.glEnable((int)2832);
            GL11.glHint((int)3153, (int)4354);
        }
    }

    public static void unhook(boolean line, boolean polygon, boolean point) {
        if (line) {
            GL11.glHint((int)3154, (int)4352);
            GL11.glDisable((int)2848);
        }
        if (polygon) {
            GL11.glHint((int)3155, (int)4352);
            GL11.glDisable((int)2881);
        }
        if (point) {
            GL11.glHint((int)3153, (int)4352);
            GL11.glDisable((int)2832);
        }
    }
}
