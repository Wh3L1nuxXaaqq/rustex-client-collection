package recode.space.horizon.utils.util;

import net.minecraft.util.math.MathHelper;

public class Utils {
    public static float[] getNeededRotations(double x, double y, double z, double playerX, double playerY, double playerZ) {
        double diffX = x - playerX;
        double diffZ = z - playerZ;
        double diffY = y - playerY;
        double dist = MathHelper.func_76133_a((double)(diffX * diffX + diffZ * diffZ));
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI - 90.0);
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        pitch = MathHelper.func_76131_a((float)pitch, (float)-90.0f, (float)90.0f);
        return new float[]{yaw, pitch};
    }
}
