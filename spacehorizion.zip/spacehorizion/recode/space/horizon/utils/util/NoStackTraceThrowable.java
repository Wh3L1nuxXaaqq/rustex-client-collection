package recode.space.horizon.utils.util;

import recode.space.horizon.Horizon;

public class NoStackTraceThrowable
extends RuntimeException {
    public NoStackTraceThrowable(String msg) {
        super(msg);
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public String toString() {
        return "" + Horizon.version();
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
