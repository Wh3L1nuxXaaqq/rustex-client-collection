package recode.space.horizon.utils.util;

import java.awt.Color;

public class Colors {
    public static int getColor(int n) {
        return Colors.getColor(n, n, n, 255);
    }

    public static int getColor(int n, int n2, int n3) {
        return Colors.getColor(n, n2, n3, 255);
    }

    public static int getColor(int n, int n2, int n3, int n4) {
        return 0 | n4 << 24 | n << 16 | n2 << 8 | n3;
    }

    public static int getColor(int n, int n2) {
        return Colors.getColor(n, n, n, n2);
    }

    public static int getColor(Color color) {
        return Colors.getColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }
}
