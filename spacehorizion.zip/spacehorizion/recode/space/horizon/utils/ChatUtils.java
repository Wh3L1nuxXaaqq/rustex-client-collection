package recode.space.horizon.utils;

import flip.guard.annotations.Native;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

@Native
public class ChatUtils {
    private static final String prefix = TextFormatting.GRAY + "[" + TextFormatting.BLUE + "Space-Horizon" + TextFormatting.GRAY + "]: " + TextFormatting.WHITE;

    public static void message(String msg) {
        Minecraft.func_71410_x().field_71439_g.func_145747_a((ITextComponent)new TextComponentString(prefix + msg));
    }

    public static void sendMessage(String str) {
        Minecraft.func_71410_x().field_71439_g.func_145747_a((ITextComponent)new TextComponentString(prefix + str));
    }

    public static void say(String s) {
        Minecraft.func_71410_x().field_71439_g.func_71165_d(s);
    }
}
