package recode.space.horizon.utils;

import recode.space.horizon.utils.BasicTaskFactory;
import recode.space.horizon.utils.RotationTask;

public final class RotationTaskFactory
extends BasicTaskFactory<RotationTask> {
}
