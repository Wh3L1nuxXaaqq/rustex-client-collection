package recode.space.horizon.utils;

public class TimerUtil {
    private static long ms = TimerUtil.getCurrentMS();

    private static long getCurrentMS() {
        return System.currentTimeMillis();
    }

    public static boolean hasReached(float milliseconds) {
        return (float)(TimerUtil.getCurrentMS() - ms) > milliseconds;
    }

    public static void reset() {
        ms = TimerUtil.getCurrentMS();
    }

    public static void strafe() {
    }

    public long getTime() {
        return TimerUtil.getCurrentMS() - ms;
    }
}
