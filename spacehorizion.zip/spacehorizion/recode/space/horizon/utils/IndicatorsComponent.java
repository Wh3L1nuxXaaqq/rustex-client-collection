package recode.space.horizon.utils;

import recode.space.horizon.utils.DraggableModule;

public class IndicatorsComponent
extends DraggableModule {
    private float cooldownAnim;
    private float hurtAnim;

    public IndicatorsComponent() {
        super("IndicatorsComponent", 40, 220);
    }
}
