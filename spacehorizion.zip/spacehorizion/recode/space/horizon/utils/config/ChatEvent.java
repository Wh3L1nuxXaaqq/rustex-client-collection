package recode.space.horizon.utils.config;

import java.util.HashSet;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import recode.space.horizon.Horizon;
import recode.space.horizon.utils.ChatUtils;

public class ChatEvent {
    public static HashSet Player = new HashSet();
    private static Minecraft mc = Minecraft.func_71410_x();

    @SubscribeEvent
    public void ChatEvent(ClientChatEvent clientChatEvent) {
        clientChatEvent.getMessage();
        String lowerCase = clientChatEvent.getMessage().toLowerCase();
        if (lowerCase.startsWith("/aim")) {
            try {
                Horizon.instance.settingsManager.getSettingByName(Horizon.moduleManager.getModule("AimBot"), "Predict").setValDouble(Float.parseFloat(lowerCase.split(" ")[1]));
            }
            catch (Throwable t) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        }
        if (lowerCase.startsWith("/smooth")) {
            try {
                Horizon.instance.settingsManager.getSettingByName(Horizon.moduleManager.getModule("AimBot"), "Smooth").setValDouble(Float.parseFloat(lowerCase.split(" ")[1]));
            }
            catch (Throwable t) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        } else if (lowerCase.startsWith("/vaim")) {
            try {
                Horizon.instance.settingsManager.getSettingByName(Horizon.moduleManager.getModule("AimBot"), "VPredict").setValDouble(Float.parseFloat(lowerCase.split(" ")[1]));
            }
            catch (Throwable t2) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        } else if (lowerCase.startsWith("/range")) {
            try {
                Horizon.instance.settingsManager.getSettingByName(Horizon.moduleManager.getModule("AimBot"), "Range").setValDouble(Float.parseFloat(lowerCase.split(" ")[1]));
            }
            catch (Throwable t3) {
                ChatUtils.sendMessage("Error");
            }
            clientChatEvent.setMessage("");
        }
    }
}
