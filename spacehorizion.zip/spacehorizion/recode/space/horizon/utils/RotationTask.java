package recode.space.horizon.utils;

import recode.space.horizon.utils.BasicTask;

public final class RotationTask
extends BasicTask {
    public RotationTask(String name, int priority) {
        super(name, priority);
    }
}
