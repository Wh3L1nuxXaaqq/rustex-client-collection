package recode.space.horizon.utils.Font;

import java.awt.Font;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import recode.space.horizon.utils.Font.CustomFontRenderer;

public final class CastomFontUtils {
    public static CustomFontRenderer fr = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("font.otf"), 20.0f, 0), true, true);
    public static CustomFontRenderer fr2 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("main.ttf"), 20.0f, 0), true, true);
    public static CustomFontRenderer fr3 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("rerty.ttf"), 20.0f, 0), true, true);
    public static CustomFontRenderer fr4 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("latoregular.ttf"), 20.0f, 0), true, true);
    public static CustomFontRenderer fr5 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("blood.otf"), 20.0f, 0), true, true);
    public static CustomFontRenderer fr6 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("nigga.otf"), 30.0f, 0), true, true);
    public static CustomFontRenderer fr7 = new CustomFontRenderer(CastomFontUtils.getFontFromTTF(new ResourceLocation("slonyara.ttf"), 20.0f, 0), true, true);

    public static Font getFontFromTTF(ResourceLocation loc, float fontSize, int fontType) {
        try {
            Font output = Font.createFont(fontType, Minecraft.func_71410_x().func_110442_L().func_110536_a(loc).func_110527_b());
            output = output.deriveFont(fontSize);
            return output;
        }
        catch (Exception var5) {
            return null;
        }
    }
}
