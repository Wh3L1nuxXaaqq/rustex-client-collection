package recode.space.horizon.utils;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import recode.space.horizon.utils.ColorUtils;
import recode.space.horizon.utils.MinecraftHelper;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.Wrapper;
import recode.space.horizon.utils.search.Blockinfo;
import recode.space.horizon.utils.util.ColorHelper;

public class RenderUtils {
    private static final Frustum frustrum;
    public static boolean click;
    public static Frustum FRUSTUM;
    private float spin;
    private float cumSize;
    private static final int GL_BLEND;
    private static final int GL_DEPTH_TEST;

    public static void drawTexturedRect(float x, float y, float width, float height, float u0, float v0, float u1, float v1) {
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder buffer = tessellator.func_178180_c();
        buffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        buffer.func_181662_b((double)x, (double)(y + height), 0.0).func_187315_a((double)u0, (double)v1).func_181675_d();
        buffer.func_181662_b((double)(x + width), (double)(y + height), 0.0).func_187315_a((double)u1, (double)v1).func_181675_d();
        buffer.func_181662_b((double)(x + width), (double)y, 0.0).func_187315_a((double)u1, (double)v0).func_181675_d();
        buffer.func_181662_b((double)x, (double)y, 0.0).func_187315_a((double)u0, (double)v0).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)3042);
    }

    public static ResourceLocation drawPic(double n, double n2, double n3, double n4, ResourceLocation resourceLocation) {
        GlStateManager.func_179141_d();
        GlStateManager.func_179140_f();
        GlStateManager.func_179106_n();
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        getBuffer.func_181662_b(n, n2 + n4, 0.0).func_187315_a(0.0, 1.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        getBuffer.func_181662_b(n + n3, n2 + n4, 0.0).func_187315_a(1.0, 1.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        getBuffer.func_181662_b(n + n3, n2, 0.0).func_187315_a(1.0, 0.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        getBuffer.func_181662_b(n, n2, 0.0).func_187315_a(0.0, 0.0).func_181669_b(255, 255, 255, 255).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179118_c();
        return resourceLocation;
    }

    public static void drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(float x, float y, float x2, float y2, float round, float shadowSize, int color, int color2, int color3, int color4, boolean bloom, boolean rect, boolean shadow) {
        if (shadow) {
            RenderUtils.drawRoundedFullGradientShadow(x, y, x2, y2, round, shadowSize, color, color2, color3, color4, bloom);
        }
        if (rect) {
            RenderUtils.drawRoundedFullGradientRectPro(x, y, x2, y2, round * 2.0f, color, color2, color3, color4, bloom);
        }
    }

    public static boolean isInViewFrustum(Entity entity) {
        return RenderUtils.isInViewFrustum(entity.func_174813_aQ()) || entity.field_70158_ak;
    }

    public static Vec3d project2D(int scaleFactor, double x, double y, double z) {
        float xPos = (float)x;
        float yPos = (float)y;
        float zPos = (float)z;
        IntBuffer viewport = GLAllocation.func_74527_f((int)16);
        FloatBuffer modelview = GLAllocation.func_74529_h((int)16);
        FloatBuffer projection = GLAllocation.func_74529_h((int)16);
        FloatBuffer vector = GLAllocation.func_74529_h((int)4);
        GL11.glGetFloat((int)2982, (FloatBuffer)modelview);
        GL11.glGetFloat((int)2983, (FloatBuffer)projection);
        GL11.glGetInteger((int)2978, (IntBuffer)viewport);
        return GLU.gluProject((float)xPos, (float)yPos, (float)zPos, (FloatBuffer)modelview, (FloatBuffer)projection, (IntBuffer)viewport, (FloatBuffer)vector) ? new Vec3d((double)(vector.get(0) / (float)scaleFactor), (double)(((float)Display.getHeight() - vector.get(1)) / (float)scaleFactor), (double)vector.get(2)) : null;
    }

    private static boolean isInViewFrustum(AxisAlignedBB bb) {
        Entity current = RenderUtil.mc.func_175606_aa();
        if (current != null) {
            FRUSTUM.func_78547_a(current.field_70165_t, current.field_70163_u, current.field_70161_v);
        }
        return FRUSTUM.func_78546_a(bb);
    }

    public static void drawCroneShadow(double x, double y, int startAngle, int endAngle, float radius, float shadowSize, int color, int endColor, boolean bloom) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179103_j((int)7425);
        GL11.glDisable((int)3008);
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ZERO, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE);
        }
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)5);
        for (int i = startAngle; i <= endAngle; i += 6) {
            ColorUtils.glColor(color);
            GL11.glVertex2d((double)(x + Math.sin((double)i * Math.PI / 180.0) * (double)radius), (double)(y + Math.cos((double)i * Math.PI / 180.0) * (double)radius));
            ColorUtils.glColor(endColor);
            GL11.glVertex2d((double)(x + Math.sin((double)i * Math.PI / 180.0) * (double)(radius + shadowSize)), (double)(y + Math.cos((double)i * Math.PI / 180.0) * (double)(radius + shadowSize)));
        }
        GL11.glEnd();
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ZERO, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE);
        }
        GL11.glEnable((int)3008);
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawFullGradientRectPro(float x, float y, float x2, float y2, int color, int color2, int color3, int color4, boolean blend) {
        GlStateManager.func_179147_l();
        if (blend) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179090_x();
        GL11.glShadeModel((int)7425);
        GL11.glDisable((int)3008);
        GL11.glBegin((int)7);
        ColorUtils.glColor(color);
        GL11.glVertex2f((float)x, (float)y2);
        ColorUtils.glColor(color2);
        GL11.glVertex2f((float)x2, (float)y2);
        ColorUtils.glColor(color3);
        GL11.glVertex2f((float)x2, (float)y);
        ColorUtils.glColor(color4);
        GL11.glVertex2f((float)x, (float)y);
        GL11.glEnd();
        if (blend) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GL11.glEnable((int)3008);
        GL11.glShadeModel((int)7424);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179117_G();
    }

    public static void drawPolygonParts(double x, double y, float radius, int part, int color, int endcolor, boolean bloom) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        float alpha1 = (float)(endcolor >> 24 & 0xFF) / 255.0f;
        float red1 = (float)(endcolor >> 16 & 0xFF) / 255.0f;
        float green1 = (float)(endcolor >> 8 & 0xFF) / 255.0f;
        float blue1 = (float)(endcolor & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        } else {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(6, DefaultVertexFormats.field_181706_f);
        bufferbuilder.func_181662_b(x, y, 0.0).func_181666_a(red, green, blue, alpha).func_181675_d();
        double TWICE_PI = Math.PI * 2;
        for (int i = part * 90; i <= part * 90 + 90; ++i) {
            double angle = Math.PI * 2 * (double)i / 360.0 + Math.toRadians(180.0);
            bufferbuilder.func_181662_b(x + Math.sin(angle) * (double)radius, y + Math.cos(angle) * (double)radius, 0.0).func_181666_a(red1, green1, blue1, alpha1).func_181675_d();
        }
        tessellator.func_78381_a();
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawBloomedFullGradientRect(float xpos, float ypos, float x2pos, float y2pos, int color1, int color2, int color3, int color4, boolean bloom) {
        float w = x2pos - xpos;
        float h = y2pos - ypos;
        RenderUtils.drawFullGradientRectPro(xpos, ypos, xpos + w, ypos + h, color1, color2, color3, color4, bloom);
    }

    public static void drawRoundedFullGradientRectPro(float x, float y, float x2, float y2, float round, int color, int color2, int color3, int color4, boolean bloom) {
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        RenderUtils.drawFullGradientRectPro(x + round / 2.0f, y + round / 2.0f, x2 - round / 2.0f, y2 - round / 2.0f, color4, color3, color2, color, bloom);
        RenderUtils.drawPolygonParts(x + round / 2.0f, y + round / 2.0f, round / 2.0f, 0, color, color, bloom);
        RenderUtils.drawPolygonParts(x + round / 2.0f, y2 - round / 2.0f, round / 2.0f, 5, color4, color4, bloom);
        RenderUtils.drawPolygonParts(x2 - round / 2.0f, y + round / 2.0f, round / 2.0f, 7, color2, color2, bloom);
        RenderUtils.drawPolygonParts(x2 - round / 2.0f, y2 - round / 2.0f, round / 2.0f, 6, color3, color3, bloom);
        RenderUtils.drawBloomedFullGradientRect(x, y + round / 2.0f, x + round / 2.0f, y2 - round / 2.0f, color4, color4, color, color, bloom);
        RenderUtils.drawBloomedFullGradientRect(x + round / 2.0f, y, x2 - round / 2.0f, y + round / 2.0f, color, color2, color2, color, bloom);
        RenderUtils.drawBloomedFullGradientRect(x2 - round / 2.0f, y + round / 2.0f, x2, y2 - round / 2.0f, color3, color3, color2, color2, bloom);
        RenderUtils.drawBloomedFullGradientRect(x + round / 2.0f, y2 - round / 2.0f, x2 - round / 2.0f, y2, color4, color3, color3, color4, bloom);
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
    }

    public static void drawRoundedFullGradientShadow(float x, float y, float x2, float y2, float round, float shadowSize, int color, int color2, int color3, int color4, boolean bloom) {
        x += round;
        x2 -= round;
        y += round;
        y2 -= round;
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
        RenderUtils.drawCroneShadow(x, y, -180, -90, round, shadowSize, color, bloom ? 0 : ColorUtils.swapAlpha(color, 0), bloom);
        RenderUtils.drawFullGradientRectPro(x, y - round - shadowSize, x2, y - round, color, color2, bloom ? 0 : ColorUtils.swapAlpha(color2, 0), bloom ? 0 : ColorUtils.swapAlpha(color, 0), bloom);
        RenderUtils.drawCroneShadow(x2, y, 90, 180, round, shadowSize, color2, bloom ? 0 : ColorUtils.swapAlpha(color2, 0), bloom);
        RenderUtils.drawFullGradientRectPro(x2 + round, y, x2 + round + shadowSize, y2, color3, bloom ? 0 : ColorUtils.swapAlpha(color3, 0), bloom ? 0 : ColorUtils.swapAlpha(color2, 0), color2, bloom);
        RenderUtils.drawCroneShadow(x2, y2, 0, 90, round, shadowSize, color3, bloom ? 0 : ColorUtils.swapAlpha(color3, 0), bloom);
        RenderUtils.drawFullGradientRectPro(x, y2 + round, x2, y2 + round + shadowSize, bloom ? 0 : ColorUtils.swapAlpha(color4, 0), bloom ? 0 : ColorUtils.swapAlpha(color3, 0), color3, color4, bloom);
        RenderUtils.drawCroneShadow(x, y2, -90, 0, round, shadowSize, color4, bloom ? 0 : ColorUtils.swapAlpha(color4, 0), bloom);
        RenderUtils.drawFullGradientRectPro(x - round - shadowSize, y, x - round, y2, bloom ? 0 : ColorUtils.swapAlpha(color4, 0), color4, color, bloom ? 0 : ColorUtils.swapAlpha(color, 0), bloom);
        if (bloom) {
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        }
    }

    public static void drawCircle228(float n, float n2, float n3, int n4, int n5) {
        float n6 = (float)(n4 >> 24 & 0xFF) / 255.0f;
        float n7 = (float)(n4 >> 16 & 0xFF) / 255.0f;
        float n8 = (float)(n4 >> 8 & 0xFF) / 255.0f;
        float n9 = (float)(n4 & 0xFF) / 255.0f;
        boolean glIsEnabled = GL11.glIsEnabled((int)3042);
        boolean glIsEnabled2 = GL11.glIsEnabled((int)2848);
        boolean glIsEnabled3 = GL11.glIsEnabled((int)3553);
        if (!glIsEnabled) {
            GL11.glEnable((int)3042);
        }
        if (!glIsEnabled2) {
            GL11.glEnable((int)2848);
        }
        if (glIsEnabled3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)n7, (float)n8, (float)n9, (float)n6);
        GL11.glLineWidth((float)2.5f);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n5; ++i) {
            GL11.glVertex2d((double)((double)n + Math.sin((double)i * Math.PI / 180.0) * (double)n3), (double)((double)n2 + Math.cos((double)i * Math.PI / 180.0) * (double)n3));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (glIsEnabled3) {
            GL11.glEnable((int)3553);
        }
        if (!glIsEnabled2) {
            GL11.glDisable((int)2848);
        }
        if (!glIsEnabled) {
            GL11.glDisable((int)3042);
        }
    }

    public static void drawRectStatic(int n, int n2, int n3, int n4, Color color) {
        Gui.func_73734_a((int)n, (int)n2, (int)n3, (int)n4, (int)color.getRGB());
    }

    public static void drawSector2(double n, double n2, int n3, int n4, int n5) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)6);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)n, (double)n2);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        for (int i = n3; i <= n4; ++i) {
            GL11.glVertex2d((double)(n + Math.sin((double)i * Math.PI / 180.0) * (double)n5), (double)(n2 + Math.cos((double)i * Math.PI / 180.0) * (double)n5));
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawESP(Entity entity, float n, float n2, float n3, float n4, float n5) {
        try {
            double viewerPosX = Wrapper.mc.func_175598_ae().field_78730_l;
            double viewerPosY = Wrapper.mc.func_175598_ae().field_78731_m;
            double viewerPosZ = Wrapper.mc.func_175598_ae().field_78728_n;
            double n6 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)n5 - viewerPosX;
            double n7 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)n5 + (double)(entity.field_70131_O / 2.0f) - viewerPosY;
            double n8 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)n5 - viewerPosZ;
            float playerViewY = Wrapper.mc.func_175598_ae().field_78735_i;
            float playerViewX = Wrapper.mc.func_175598_ae().field_78732_j;
            boolean b = Wrapper.mc.func_175598_ae().field_78733_k.field_74320_O == 2;
            GL11.glPushMatrix();
            GlStateManager.func_179137_b((double)n6, (double)n7, (double)n8);
            GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)(-playerViewY), (float)0.0f, (float)1.0f, (float)0.0f);
            GlStateManager.func_179114_b((float)((float)(b ? -1 : 1) * playerViewX), (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2896);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glLineWidth((float)1.0f);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glColor4f((float)n, (float)n2, (float)n3, (float)n4);
            GL11.glBegin((int)1);
            GL11.glVertex3d((double)0.0, (double)1.0, (double)0.0);
            GL11.glVertex3d((double)-0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)1.0, (double)0.0);
            GL11.glVertex3d((double)0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
            GL11.glVertex3d((double)-0.5, (double)0.5, (double)0.0);
            GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
            GL11.glVertex3d((double)0.5, (double)0.5, (double)0.0);
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2896);
            GL11.glDisable((int)2848);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void setColor(Color color) {
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)((float)color.getAlpha() / 255.0f));
    }

    public static void drawRect(double n, double n2, double n3, double n4, int n5) {
        if (n < n3) {
            double n6 = n;
            n = n3;
            n3 = n6;
        }
        if (n2 < n4) {
            double n7 = n2;
            n2 = n4;
            n4 = n7;
        }
        float n8 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n10 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n11 = (float)(n5 & 0xFF) / 255.0f;
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)n9, (float)n10, (float)n11, (float)n8);
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b(n, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n2, 0.0).func_181675_d();
        getBuffer.func_181662_b(n, n2, 0.0).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void customScaledObject2D(float n, float n2, float n3, float n4, float n5, float n6) {
        GL11.glTranslated((double)(n3 / 2.0f), (double)(n4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-n * n5 + n + n3 / 2.0f * -n5), (double)(-n2 * n5 + n2 + n4 / 2.0f * -n5), (double)1.0);
        GL11.glScaled((double)n5, (double)n5, (double)0.0);
    }

    public static void drawDownShadow(float n, float n2, float n3, float n4) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)n3, (double)n4);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glVertex2d((double)n, (double)n2);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void drawShadowRect(double n, double n2, double n3, double n4, int n5) {
        RenderUtils.drawGradientRect(n, n2 - (double)n5, n3, n2, false, true, new Color(0, 0, 0, 150).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawGradientRect(n, n4, n3, n4 + (double)n5, false, false, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawSector2(n3, n4, 0, 90, n5);
        RenderUtils.drawSector2(n3, n2, 90, 180, n5);
        RenderUtils.drawSector2(n, n2, 180, 270, n5);
        RenderUtils.drawSector2(n, n4, 270, 360, n5);
        RenderUtils.drawGradientRect(n - (double)n5, n2, n, n4, true, true, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawGradientRect(n3, n2, n3 + (double)n5, n4, true, false, new Color(0, 0, 0, 155).getRGB(), new Color(0, 0, 0, 0).getRGB());
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void drawGradientRect(double n, double n2, double n3, double n4, boolean b, int n5, int n6) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179103_j((int)7425);
        RenderUtils.glColor(n5);
        GL11.glBegin((int)7);
        if (b) {
            GL11.glVertex2d((double)n, (double)n2);
            GL11.glVertex2d((double)n, (double)n4);
            RenderUtils.glColor(n6);
            GL11.glVertex2d((double)n3, (double)n4);
            GL11.glVertex2d((double)n3, (double)n2);
        } else {
            GL11.glVertex2d((double)n, (double)n2);
            RenderUtils.glColor(n6);
            GL11.glVertex2d((double)n, (double)n4);
            GL11.glVertex2d((double)n3, (double)n4);
            RenderUtils.glColor(n5);
            GL11.glVertex2d((double)n3, (double)n2);
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void renderItem(ItemStack itemStack, int n, int n2) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179126_j();
        RenderHelper.func_74520_c();
        MinecraftHelper.mc.func_175599_af().field_77023_b = -100.0f;
        MinecraftHelper.mc.func_175599_af().func_180450_b(itemStack, n, n2);
        MinecraftHelper.mc.func_175599_af().func_175030_a(MinecraftHelper.mc.field_71466_p, itemStack, n, n2);
        MinecraftHelper.mc.func_175599_af().field_77023_b = 0.0f;
        RenderHelper.func_74518_a();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.func_179097_i();
    }

    public static void drawRectSized(float n, float n2, float n3, float n4, int n5) {
        RenderUtils.drawRect(n, n2, n + n3, n2 + n4, n5);
    }

    public static double lerp(double n, double n2, double n3) {
        return (1.0 - n3) * n + n3 * n2;
    }

    public static void draw2DRect(int n, int n2, int n3, int n4, int n5) {
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b((double)n, (double)(n2 + n4), (double)n5).func_181675_d();
        getBuffer.func_181662_b((double)(n + n3), (double)(n2 + n4), (double)n5).func_181675_d();
        getBuffer.func_181662_b((double)(n + n3), (double)n2, (double)n5).func_181675_d();
        getBuffer.func_181662_b((double)n, (double)n2, (double)n5).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void setupColor(Color color, int n) {
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)((float)n / 255.0f));
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4, int n5) {
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.glColor(n5);
        MinecraftHelper.mc.func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GlStateManager.func_179084_k();
        GlStateManager.func_179126_j();
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawGradient(double n, double n2, double n3, double n4, int n5, int n6) {
        float n7 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n10 = (float)(n5 & 0xFF) / 255.0f;
        float n11 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n12 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n13 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n14 = (float)(n6 & 0xFF) / 255.0f;
        RenderUtil.glRenderStart();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)n8, (float)n9, (float)n10, (float)n7);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glColor4f((float)n12, (float)n13, (float)n14, (float)n11);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
        GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
        RenderUtil.glRenderStop();
    }

    public static void drawGradientRect(double n, double n2, double n3, double n4, boolean b, boolean b2, int n5, int n6) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(n5);
        if (b) {
            if (b2) {
                GL11.glVertex2d((double)n3, (double)n4);
                GL11.glVertex2d((double)n3, (double)n2);
                RenderUtils.glColor(n6);
                GL11.glVertex2d((double)n, (double)n2);
                GL11.glVertex2d((double)n, (double)n4);
            } else {
                GL11.glVertex2d((double)n, (double)n2);
                GL11.glVertex2d((double)n, (double)n4);
                RenderUtils.glColor(n6);
                GL11.glVertex2d((double)n3, (double)n4);
                GL11.glVertex2d((double)n3, (double)n2);
            }
        } else if (b2) {
            GL11.glVertex2d((double)n3, (double)n4);
            RenderUtils.glColor(n6);
            GL11.glVertex2d((double)n3, (double)n2);
            GL11.glVertex2d((double)n, (double)n2);
            RenderUtils.glColor(n5);
            GL11.glVertex2d((double)n, (double)n4);
        } else {
            GL11.glVertex2d((double)n, (double)n2);
            RenderUtils.glColor(n6);
            GL11.glVertex2d((double)n, (double)n4);
            GL11.glVertex2d((double)n3, (double)n4);
            RenderUtils.glColor(n5);
            GL11.glVertex2d((double)n3, (double)n2);
        }
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void blockEspFrame(BlockPos blockPos, float n, float n2, float n3) {
        double n4 = (double)blockPos.func_177958_n() - MinecraftHelper.mc.func_175598_ae().field_78730_l;
        double n5 = (double)blockPos.func_177956_o() - MinecraftHelper.mc.func_175598_ae().field_78731_m;
        double n6 = (double)blockPos.func_177952_p() - MinecraftHelper.mc.func_175598_ae().field_78728_n;
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GlStateManager.func_179131_c((float)n, (float)n2, (float)n3, (float)1.0f);
        RenderUtil.drawSelectionBoundingBox(new AxisAlignedBB(n4, n5, n6, n4 + 1.0, n5 + 1.0, n6 + 1.0));
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    public static void blockEspBox(BlockPos blockPos, double n, double n2, double n3) {
        double n4 = (double)blockPos.func_177958_n() - Minecraft.func_71410_x().func_175598_ae().field_78730_l;
        double n5 = (double)blockPos.func_177956_o() - Minecraft.func_71410_x().func_175598_ae().field_78731_m;
        double n6 = (double)blockPos.func_177952_p() - Minecraft.func_71410_x().func_175598_ae().field_78728_n;
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)0);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)0);
        GL11.glDisable((int)2896);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)n, (double)n2, (double)n3, (double)0.15f);
        RenderUtil.drawColorBox(new AxisAlignedBB(n4, n5, n6, n4 + 1.0, n5 + 1.0, n6 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)n, (double)n2, (double)n3, (double)0.15f);
        RenderUtil.drawColorBox(new AxisAlignedBB(n4, n5, n6, n4 + 1.0, n5 + 1.0, n6 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)0);
        GL11.glEnable((int)2896);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)0);
        GL11.glPopMatrix();
    }

    public static void trace(Minecraft minecraft, Entity entity, float n, int n2) {
        if (minecraft.func_175598_ae().field_78734_h != null) {
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2896);
            GL11.glLineWidth((float)2.0f);
            GL11.glPushMatrix();
            GL11.glDepthMask((boolean)false);
            GL11.glColor4d((double)0.0, (double)(n2 == 1 ? 1.0 : 0.0), (double)0.0, (double)1.0);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)3553);
            GL11.glBegin((int)1);
            RenderManager getRenderManager = minecraft.func_175598_ae();
            Vec3d rotateYaw = new Vec3d(0.0, 0.0, 1.0).func_178789_a(-((float)Math.toRadians(minecraft.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians(minecraft.field_71439_g.field_70177_z)));
            GL11.glVertex3d((double)rotateYaw.field_72450_a, (double)((double)minecraft.field_71439_g.func_70047_e() + rotateYaw.field_72448_b), (double)rotateYaw.field_72449_c);
            GL11.glVertex3d((double)(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)n - getRenderManager.field_78730_l), (double)(entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)n - getRenderManager.field_78731_m + 0.25), (double)(entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)n - getRenderManager.field_78728_n));
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    public static void trace(Minecraft minecraft, Blockinfo blockinfo) {
        if (minecraft.func_175598_ae().field_78734_h != null) {
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2896);
            GL11.glLineWidth((float)2.0f);
            GL11.glPushMatrix();
            GL11.glDepthMask((boolean)false);
            GL11.glColor4d((double)blockinfo.getR(), (double)blockinfo.getG(), (double)blockinfo.getB(), (double)1.0);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)3553);
            GL11.glBegin((int)1);
            RenderManager RenderManager2 = minecraft.func_175598_ae();
            Vec3d rotateYaw = new Vec3d(0.0, 0.0, 1.0).func_178789_a(-((float)Math.toRadians(minecraft.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians(minecraft.field_71439_g.field_70177_z)));
            GL11.glVertex3d((double)rotateYaw.field_72450_a, (double)((double)minecraft.field_71439_g.func_70047_e() + rotateYaw.field_72448_b), (double)rotateYaw.field_72449_c);
            GL11.glVertex3d((double)((double)blockinfo.getX() - RenderManager2.field_78730_l), (double)((double)blockinfo.getY() - RenderManager2.field_78731_m), (double)((double)blockinfo.getZ() - RenderManager2.field_78728_n));
            GL11.glEnd();
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    public static void glColor(int n) {
        GlStateManager.func_179131_c((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)((float)(n >> 24 & 0xFF) / 255.0f));
    }

    public static void drawBorderedRect(double n, double n2, double n3, double n4, float n5, int n6, int n7) {
        RenderUtils.drawRect((float)n, (float)n2, (float)n3, (float)n4, n7);
        float n8 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n9 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n10 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n11 = (float)(n6 & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)n9, (float)n10, (float)n11, (float)n8);
        GL11.glLineWidth((float)n5);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawEntityOnScreen(float n, float n2, float n3, EntityLivingBase entityLivingBase) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179142_g();
        GlStateManager.func_179109_b((float)n, (float)n2, (float)50.0f);
        GlStateManager.func_179152_a((float)(-n3), (float)n3, (float)n3);
        GlStateManager.func_179114_b((float)180.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GlStateManager.func_179114_b((float)135.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        RenderHelper.func_74519_b();
        GlStateManager.func_179114_b((float)-135.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)(-((float)Math.atan(entityLivingBase.field_70125_A / 40.0f)) * 20.0f), (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.func_179109_b((float)0.0f, (float)0.0f, (float)0.0f);
        RenderManager getRenderManager = Minecraft.func_71410_x().func_175598_ae();
        getRenderManager.func_178631_a(180.0f);
        getRenderManager.func_178633_a(false);
        getRenderManager.func_188391_a((Entity)entityLivingBase, 0.0, 0.0, 0.0, entityLivingBase.field_70177_z, 1.0f, false);
        getRenderManager.func_178633_a(true);
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77476_b);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GlStateManager.func_179097_i();
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77478_a);
        GlStateManager.func_179121_F();
    }

    public static void putVertex3d(Vec3d vec3d) {
        GL11.glVertex3d((double)vec3d.field_72450_a, (double)vec3d.field_72448_b, (double)vec3d.field_72449_c);
    }

    public static void drawRect(float n, float n2, float n3, float n4, int n5) {
        float n6 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n7 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n9 = (float)(n5 & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)n7, (float)n8, (float)n9, (float)n6);
        GL11.glBegin((int)7);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawRectWithGlow(double X, double Y, double Width, double Height, double GlowRange, double GlowMultiplier, Color color) {
        RenderUtils.drawRoundedRect99(X, Y, Width, Height, color.getRGB());
        float i = 2.0f;
        while ((double)i < GlowRange) {
            RenderUtils.drawRoundedRect99(X - (GlowRange - (double)i), Y - (GlowRange - (double)i), Width + (GlowRange - (double)i), Height + (GlowRange - (double)i), ColorHelper.injectAlpha(color, (int)Math.round((double)i * GlowMultiplier)).getRGB());
            i += 0.5f;
        }
    }

    public static void drawRoundedRect(float left, float top, float right, float bottom, int smooth, Color color) {
        Gui.func_73734_a((int)((int)left + smooth), (int)((int)top), (int)((int)right - smooth), (int)((int)bottom), (int)color.getRGB());
        Gui.func_73734_a((int)((int)left), (int)((int)top + smooth), (int)((int)right), (int)((int)bottom - smooth), (int)color.getRGB());
        RenderUtil.drawFilledCircle((int)left + smooth, (int)top + smooth, smooth, color);
        RenderUtil.drawFilledCircle((int)right - smooth, (int)top + smooth, smooth, color);
        RenderUtil.drawFilledCircle((int)right - smooth, (int)bottom - smooth, smooth, color);
        RenderUtil.drawFilledCircle((int)left + smooth, (int)bottom - smooth, smooth, color);
    }

    public static void drawRoundedRect99(double x, double y, double x1, double y1, int insideC) {
        Gui.func_73734_a((int)((int)(x + 0.5)), (int)((int)y), (int)((int)(x1 - 0.5)), (int)((int)(y + 0.5)), (int)insideC);
        Gui.func_73734_a((int)((int)(x + 0.5)), (int)((int)(y1 - 0.5)), (int)((int)(x1 - 0.5)), (int)((int)y1), (int)insideC);
        Gui.func_73734_a((int)((int)x), (int)((int)(y + 0.5)), (int)((int)x1), (int)((int)(y1 - 0.5)), (int)insideC);
    }

    public static void drawUpShadow(float n, float n2, float n3, float n4) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        GL11.glBegin((int)7);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)n, (double)n2);
        RenderUtils.glColor(new Color(0, 0, 0, 0).getRGB());
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        RenderUtils.glColor(new Color(0, 0, 0, 100).getRGB());
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glEnd();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179103_j((int)7424);
    }

    public static void enableSmoothLine(float n) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)n);
    }

    public static void FillLine(Entity entity, AxisAlignedBB box) {
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        RenderGlobal.func_189696_b((AxisAlignedBB)box, (float)0.0f, (float)1.0f, (float)0.0f, (float)0.3f);
        RenderGlobal.func_189697_a((AxisAlignedBB)box, (float)0.0f, (float)1.0f, (float)0.0f, (float)0.8f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    public static void glColor(Color color, float n) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)n);
    }

    public static void scissorRect(float n, float n2, float n3, double n4) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        int getScaleFactor = scaledResolution.func_78325_e();
        GL11.glScissor((int)((int)(n * (float)getScaleFactor)), (int)((int)(((double)scaledResolution.func_78328_b() - n4) * (double)getScaleFactor)), (int)((int)((n3 - n) * (float)getScaleFactor)), (int)((int)((n4 - (double)n2) * (double)getScaleFactor)));
    }

    public static Vec3d getRenderPos(double n, double n2, double n3) {
        return new Vec3d(n -= MinecraftHelper.mc.func_175598_ae().field_78730_l, n2 -= MinecraftHelper.mc.func_175598_ae().field_78731_m, n3 -= MinecraftHelper.mc.func_175598_ae().field_78728_n);
    }

    public static void renderEntity(EntityLivingBase entityLivingBase, int n, int n2, int n3) {
        GlStateManager.func_179098_w();
        GlStateManager.func_179132_a((boolean)true);
        GL11.glPushAttrib((int)524288);
        GL11.glDisable((int)3089);
        GlStateManager.func_179086_m((int)256);
        GL11.glPopAttrib();
        GlStateManager.func_179126_j();
        GlStateManager.func_179118_c();
        GlStateManager.func_179094_E();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GuiInventory.func_147046_a((int)n2, (int)n3, (int)n, (float)1.0f, (float)1.0f, (EntityLivingBase)entityLivingBase);
        GlStateManager.func_179121_F();
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a((boolean)false);
    }

    public static void drawEntityESP(Entity entity, Color color) {
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)0);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)0);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)0.15f);
        RenderManager getRenderManager = Minecraft.func_71410_x().func_175598_ae();
        RenderUtil.drawColorBox(new AxisAlignedBB(-0.05 - entity.field_70165_t + (entity.field_70165_t - getRenderManager.field_78730_l), -entity.field_70163_u + (entity.field_70163_u - getRenderManager.field_78731_m), -0.05 - entity.field_70161_v + (entity.field_70161_v - getRenderManager.field_78728_n), 0.05 - entity.field_70165_t + (entity.field_70165_t - getRenderManager.field_78730_l), 0.1 - entity.field_70163_u + (entity.field_70163_u - getRenderManager.field_78731_m), 0.05 - entity.field_70161_v + (entity.field_70161_v - getRenderManager.field_78728_n)), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glColor4d((double)0.0, (double)0.0, (double)0.0, (double)0.5);
        RenderUtil.drawSelectionBoundingBox(new AxisAlignedBB(-0.05 - entity.field_70165_t + (entity.field_70165_t - getRenderManager.field_78730_l), -entity.field_70163_u + (entity.field_70163_u - getRenderManager.field_78731_m), -0.05 - entity.field_70161_v + (entity.field_70161_v - getRenderManager.field_78728_n), 0.05 - entity.field_70165_t + (entity.field_70165_t - getRenderManager.field_78730_l), 0.1 - entity.field_70163_u + (entity.field_70163_u - getRenderManager.field_78731_m), 0.05 - entity.field_70161_v + (entity.field_70161_v - getRenderManager.field_78728_n)));
        GL11.glLineWidth((float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)0);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)0);
        GL11.glPopMatrix();
    }

    public static void drawboxESP5(BlockPos blockPos, Color color) {
        double n = blockPos.func_177958_n();
        double viewerPosX = Wrapper.mc.func_175598_ae().field_78730_l;
        double viewerPosY = Wrapper.mc.func_175598_ae().field_78731_m;
        double viewerPosZ = Wrapper.mc.func_175598_ae().field_78728_n;
        Minecraft.func_71410_x().func_175598_ae();
        double n2 = n - viewerPosX;
        double n3 = blockPos.func_177956_o();
        Minecraft.func_71410_x().func_175598_ae();
        double n4 = n3 - viewerPosY;
        double n5 = blockPos.func_177952_p();
        Minecraft.func_71410_x().func_175598_ae();
        double n6 = n5 - viewerPosZ;
        GL11.glBlendFunc((int)770, (int)771);
        Tessellator.func_178181_a().func_178180_c();
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)1.0f);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)0.25);
        Minecraft.func_71410_x().func_175598_ae();
        RenderUtil.drawColorBox(new AxisAlignedBB(n2, n4, n6, n2 + 1.0, n4 + 1.0, n6 + 1.0), 0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glColor4d((double)0.4f, (double)0.6f, (double)1.0, (double)1.0);
        GL11.glLineWidth((float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void customScaledObject2D(float n, float n2, float n3, float n4, float n5) {
        GL11.glTranslated((double)(n3 / 2.0f), (double)(n4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-n * n5 + n + n3 / 2.0f * -n5), (double)(-n2 * n5 + n2 + n4 / 2.0f * -n5), (double)1.0);
        GL11.glScaled((double)n5, (double)n5, (double)0.0);
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4) {
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GL11.glPopMatrix();
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawImage(ResourceLocation resourceLocation, float x, float y, float width, float height, Color color) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.setColor(color.getRGB());
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)((int)x), (int)((int)y), (float)0.0f, (float)0.0f, (int)((int)width), (int)((int)height), (float)width, (float)height);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static void setColor(int color) {
        GL11.glColor4ub((byte)((byte)(color >> 16 & 0xFF)), (byte)((byte)(color >> 8 & 0xFF)), (byte)((byte)(color & 0xFF)), (byte)((byte)(color >> 24 & 0xFF)));
    }

    public static void drawImage(ResourceLocation resourceLocation, float x, float y, float width, float height) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)0.6f, (float)0.6f, (float)0.6f, (float)1.0f);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
        Gui.func_146110_a((int)((int)x), (int)((int)y), (float)0.0f, (float)0.0f, (int)((int)width), (int)((int)height), (float)width, (float)height);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GlStateManager.func_179117_G();
    }

    public static void drawCircle(float x, float y, float start, float end, float radius, boolean filled, Color color) {
        float sin;
        float cos;
        float i;
        GlStateManager.func_179131_c((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        if (start > end) {
            float endOffset = end;
            end = start;
            start = endOffset;
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.setColor(color.getRGB());
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)2.0f);
        GL11.glBegin((int)3);
        for (i = end; i >= start; i -= 4.0f) {
            cos = (float)(Math.cos((double)i * Math.PI / 180.0) * (double)radius * 1.0);
            sin = (float)(Math.sin((double)i * Math.PI / 180.0) * (double)radius * 1.0);
            GL11.glVertex2f((float)(x + cos), (float)(y + sin));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)(filled ? 6 : 3));
        for (i = end; i >= start; i -= 4.0f) {
            cos = (float)Math.cos((double)i * Math.PI / 180.0) * radius;
            sin = (float)Math.sin((double)i * Math.PI / 180.0) * radius;
            GL11.glVertex2f((float)(x + cos), (float)(y + sin));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void drawGlow(double x, double y, double x1, double y1, int color) {
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        RenderUtil.drawVGradientRect((int)x, (int)y, (int)x1, (int)(y + (y1 - y) / 2.0), ColorHelper.injectAlpha(new Color(color), 0).getRGB(), color);
        RenderUtil.drawVGradientRect((int)x, (int)(y + (y1 - y) / 2.0), (int)x1, (int)y1, color, ColorHelper.injectAlpha(new Color(color), 0).getRGB());
        int radius = (int)((y1 - y) / 2.0);
        RenderUtil.drawPolygonPart(x, y + (y1 - y) / 2.0, radius, 0, color, ColorHelper.injectAlpha(new Color(color), 0).getRGB());
        RenderUtil.drawPolygonPart(x, y + (y1 - y) / 2.0, radius, 1, color, ColorHelper.injectAlpha(new Color(color), 0).getRGB());
        RenderUtil.drawPolygonPart(x1, y + (y1 - y) / 2.0, radius, 2, color, ColorHelper.injectAlpha(new Color(color), 0).getRGB());
        RenderUtil.drawPolygonPart(x1, y + (y1 - y) / 2.0, radius, 3, color, ColorHelper.injectAlpha(new Color(color), 0).getRGB());
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawVerticalGradientSmoothRect(float left, float top, float right, float bottom, int color, int color2) {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        RenderUtils.drawGradientRect((int)left, (int)top, (int)right, (int)bottom, color, color2);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        RenderUtils.drawGradientRect((int)(left * 2.0f - 1.0f), (int)(top * 2.0f), (int)(left * 2.0f), (int)(bottom * 2.0f - 1.0f), color, color2);
        RenderUtils.drawGradientRect((int)(left * 2.0f), (int)(top * 2.0f - 1.0f), (int)(right * 2.0f), (int)(top * 2.0f), color, color2);
        RenderUtils.drawGradientRect((int)(right * 2.0f), (int)(top * 2.0f), (int)(right * 2.0f + 1.0f), (int)(bottom * 2.0f - 1.0f), color, color2);
        RenderUtils.drawGradientRect((int)(left * 2.0f), (int)(bottom * 2.0f - 1.0f), (int)(right * 2.0f), (int)(bottom * 2.0f), color, color2);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
    }

    public static void glColor(Color color) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
    }

    public static void drawGradientRect(int i, int i1, int i2, int i3, int i4, int i5) {
    }

    static {
        GL_BLEND = 0;
        GL_DEPTH_TEST = 0;
        frustrum = new Frustum();
    }
}
