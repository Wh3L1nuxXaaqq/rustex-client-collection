package recode.space.horizon.utils;

import java.util.List;
import recode.space.horizon.utils.BasicTask;

public interface TaskFactory<T extends BasicTask> {
    public void removeTask(String var1);

    public void removeTask(T var1);

    public List<T> getTasks();
}
