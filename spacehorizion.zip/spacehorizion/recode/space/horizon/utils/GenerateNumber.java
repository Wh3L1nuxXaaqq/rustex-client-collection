package recode.space.horizon.utils;

import java.util.Random;

public class GenerateNumber {
    private static final Random random = new Random();

    public static int generateInt(int min, int max) {
        return random.nextInt(max - min + 1) + min;
    }

    public static float generateFloat(float min, float max) {
        return (float)Math.min((double)max, Math.random() * ((double)max * 1.1 - (double)min) + (double)min);
    }
}
