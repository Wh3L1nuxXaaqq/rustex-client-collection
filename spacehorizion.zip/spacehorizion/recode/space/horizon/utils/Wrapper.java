package recode.space.horizon.utils;

import net.minecraft.client.Minecraft;
import recode.space.horizon.Horizon;

public interface Wrapper {
    public static final Minecraft mc = Minecraft.func_71410_x();

    default public boolean nullCheck() {
        return Wrapper.mc.field_71439_g != null || Wrapper.mc.field_71441_e != null;
    }

    default public Horizon getCosmos() {
        return Horizon.instance;
    }
}
