package recode.space.horizon.utils;

public interface Task {
    public boolean isOnline();

    public void setOnline(boolean var1);
}
