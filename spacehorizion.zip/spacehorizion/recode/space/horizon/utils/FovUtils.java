package recode.space.horizon.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class FovUtils {
    public static boolean isInAttackFOV(Entity entity, int fov) {
        return FovUtils.getDistanceFromMouse(entity) <= fov;
    }

    public static int getDistanceFromMouse(Entity entity) {
        float[] neededRotations = FovUtils.getNeededRotations(entity);
        float neededYaw = Minecraft.func_71410_x().field_71439_g.field_70177_z - neededRotations[0];
        float neededPitch = Minecraft.func_71410_x().field_71439_g.field_70125_A - neededRotations[1];
        float distanceFromMouse = MathHelper.func_76129_c((float)(neededYaw * neededYaw + neededPitch * neededPitch));
        return (int)distanceFromMouse;
    }

    private static float[] getNeededRotations(Entity vec) {
        Minecraft mc = Minecraft.func_71410_x();
        double deltaX = vec.field_70165_t - mc.field_71439_g.field_70165_t;
        double deltaY = vec.field_70163_u + 1.86 - (mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e());
        double deltaZ = vec.field_70161_v - mc.field_71439_g.field_70161_v;
        double distanceXZ = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        double yaw = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(deltaY, distanceXZ));
        double yaw1 = (double)mc.field_71439_g.field_70177_z + MathHelper.func_76138_g((double)(yaw - (double)mc.field_71439_g.field_70177_z));
        double pitch1 = (double)mc.field_71439_g.field_70125_A + MathHelper.func_76138_g((double)(pitch - (double)mc.field_71439_g.field_70125_A));
        return new float[]{(float)yaw1, (float)pitch1};
    }
}
