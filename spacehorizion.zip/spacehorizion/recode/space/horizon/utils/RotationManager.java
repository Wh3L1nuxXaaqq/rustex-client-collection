package recode.space.horizon.utils;

import net.minecraft.client.Minecraft;
import recode.space.horizon.utils.RotationTask;
import recode.space.horizon.utils.RotationTaskFactory;

public final class RotationManager {
    private final RotationTaskFactory factory = new RotationTaskFactory();
    private float yaw;
    private float pitch;

    public void addTask(RotationTask rotationTask) {
        this.factory.addTask(rotationTask);
    }

    public void removeTask(RotationTask rotationTask) {
        this.factory.removeTask(rotationTask);
    }

    public void removeTask(String rotationTaskName) {
        this.factory.removeTask(rotationTaskName);
    }

    public void startTask(RotationTask rotationTask) {
        this.factory.startTask(rotationTask);
    }

    public void finishTask(RotationTask rotationTask) {
        this.factory.finishTask(rotationTask);
    }

    public void updateRotations() {
        this.yaw = Minecraft.func_71410_x().field_71439_g.field_70177_z;
        this.pitch = Minecraft.func_71410_x().field_71439_g.field_70125_A;
    }

    public void restoreRotations() {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = this.yaw;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = this.yaw;
        Minecraft.func_71410_x().field_71439_g.field_70125_A = this.pitch;
    }

    public void setPlayerRotations(float yaw, float pitch) {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = yaw;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = yaw;
        Minecraft.func_71410_x().field_71439_g.field_70125_A = pitch;
    }

    public void setPlayerYaw(float yaw) {
        Minecraft.func_71410_x().field_71439_g.field_70177_z = yaw;
        Minecraft.func_71410_x().field_71439_g.field_70759_as = yaw;
    }

    public void setPlayerPitch(float pitch) {
        Minecraft.func_71410_x().field_71439_g.field_70125_A = pitch;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public RotationTaskFactory getFactory() {
        return this.factory;
    }
}
