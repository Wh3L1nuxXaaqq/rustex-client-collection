package recode.space.horizon.Castom;

import flip.guard.annotations.Native;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import org.lwjgl.input.Keyboard;
import recode.space.horizon.Castom.comp.CheckBox;
import recode.space.horizon.Castom.comp.Combo;
import recode.space.horizon.Castom.comp.Comp;
import recode.space.horizon.Castom.comp.Slider;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.settings.Setting;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.RenderUtils;

@Native
public class CastomGui
extends GuiScreen {
    private float curAlpha;
    public Category selectedCategory;
    public static boolean binding;
    public double field_146294_l;
    public ArrayList<Comp> comps = new ArrayList();
    private static RenderItem itemRender;
    float anim = 0.0f;
    public int modeIndex;
    public double dragX;
    public double x;
    public double posX;
    public double posY;
    public double field_146295_m;
    public double dragY;
    public boolean dragging = false;
    public double y;
    private boolean editing;
    public static String[] animatedTexts;
    private int currentTextIndex = 0;
    private int charIndex = 0;
    private long lastUpdateTime = 0L;
    private boolean deleting = false;
    private Module selectedModule;
    public Module mod;

    public void setBinding(boolean binding) {
        CastomGui.binding = binding;
    }

    public boolean isInside(int n, int n2, double n3, double n4, double n5, double n6) {
        return (double)n > n3 && (double)n < n5 && (double)n2 > n4 && (double)n2 < n6;
    }

    protected void func_73864_a(int n, int n2, int n3) throws IOException {
        super.func_73864_a(n, n2, n3);
        if (this.isInside(n, n2, this.posX, this.posY - 10.0, this.field_146294_l, this.posY) && n3 == 0) {
            this.dragging = true;
            this.dragX = (double)n - this.posX;
            this.dragY = (double)n2 - this.posY;
        }
        int n4 = 0;
        for (Category selectedCategory : Category.values()) {
            if (this.isInside(n, n2, this.posX, this.posY + 1.0 + (double)n4, this.posX + 60.0, this.posY + 15.0 + (double)n4) && n3 == 0) {
                this.selectedCategory = selectedCategory;
                if (selectedCategory == Category.HOME) {
                    this.comps.clear();
                }
            }
            n4 += 15;
        }
        if (this.selectedCategory != Category.HOME) {
            int n5 = 0;
            ArrayList<Module> sortedModules = new ArrayList<Module>(Horizon.moduleManager.getModules(this.selectedCategory));
            sortedModules.sort((m1, m2) -> {
                int width1 = CastomFontUtils.fr3.getStringWidth(m1.getName());
                int width2 = CastomFontUtils.fr3.getStringWidth(m2.getName());
                return Integer.compare(width2, width1);
            });
            for (Module selectedModule : sortedModules) {
                if (this.isInside(n, n2, this.posX + 65.0, this.posY + 1.0 + (double)n5, this.posX + 125.0, this.posY + 15.0 + (double)n5)) {
                    if (n3 == 0) {
                        selectedModule.toggle();
                    }
                    if (n3 == 2) {
                        this.selectedModule = selectedModule;
                        this.setBinding(true);
                    }
                    if (n3 == 1) {
                        int n6 = 3;
                        this.comps.clear();
                        if (Horizon.instance.settingsManager.getSettingsByMod(selectedModule) != null) {
                            for (Setting setting : Horizon.instance.settingsManager.getSettingsByMod(selectedModule)) {
                                this.selectedModule = selectedModule;
                                if (setting.isCombo()) {
                                    this.comps.add(new Combo(275.0, n6, this, this.selectedModule, setting));
                                    n6 += 15;
                                }
                                if (setting.isCheck()) {
                                    this.comps.add(new CheckBox(275.0, n6, this, this.selectedModule, setting));
                                    n6 += 13;
                                }
                                if (!setting.isSlider()) continue;
                                this.comps.add(new Slider(275.0, n6, this, this.selectedModule, setting));
                                n6 += 18;
                            }
                        }
                    }
                }
                n5 += 15;
            }
        }
        for (Comp comp : this.comps) {
            comp.mouseClicked(n, n2, n3);
        }
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        super.func_73869_a(typedChar, keyCode);
        if (binding && this.selectedModule != null) {
            if (keyCode == 1) {
                this.setBinding(false);
                this.selectedModule = null;
            } else {
                this.selectedModule.setKey(keyCode);
                this.setBinding(false);
                this.selectedModule = null;
            }
        }
    }

    public void func_73863_a(int n, int n2, float n3) {
        super.func_73863_a(n, n2, n3);
        if (this.dragging) {
            this.posX = (double)n - this.dragX;
            this.posY = (double)n2 - this.dragY;
        }
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m = this.posY + 380.0;
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool((float)(this.posX - 1.0), (float)(this.posY - 6.0), (float)(this.field_146294_l + 1.0), (float)(this.field_146295_m + 1.0), 5.0f, 3.0f, ClickGUI.getColor(), ClickGUI.getColor(), ClickGUI.getColor(), ClickGUI.getColor(), false, true, false);
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool((float)this.posX, (float)this.posY, (float)this.field_146294_l, (float)this.field_146295_m, 5.0f, 3.0f, new Color(31, 31, 31, 250).getRGB(), new Color(31, 31, 31, 250).getRGB(), new Color(31, 31, 31, 250).getRGB(), new Color(31, 31, 31, 250).getRGB(), false, true, false);
        int n6 = 0;
        for (Category category : Category.values()) {
            RenderUtil.drawRect(this.posX, this.posY + 1.0 + (double)n6, this.posX + 60.0, this.posY + 15.0 + (double)n6, category.equals((Object)this.selectedCategory) ? new Color(46, 85, 243, 156).getRGB() : new Color(28, 28, 28, 250).getRGB());
            CastomFontUtils.fr3.drawString(category.name(), (int)this.posX + 2, (int)(this.posY + 5.0) + n6, new Color(170, 170, 170).getRGB());
            n6 += 15;
        }
        if (this.selectedCategory == Category.HOME) {
            int typingSpeed = 100;
            int pauseTime = 1000;
            long currentTime = System.currentTimeMillis();
            String fullText = animatedTexts[this.currentTextIndex];
            if (currentTime - this.lastUpdateTime > (long)typingSpeed) {
                this.lastUpdateTime = currentTime;
                if (!this.deleting) {
                    if (this.charIndex < fullText.length()) {
                        ++this.charIndex;
                    } else {
                        try {
                            Thread.sleep(pauseTime);
                        }
                        catch (InterruptedException interruptedException) {
                            // empty catch block
                        }
                        this.deleting = true;
                    }
                } else if (this.charIndex > 0) {
                    --this.charIndex;
                } else {
                    this.deleting = false;
                    this.currentTextIndex = (this.currentTextIndex + 1) % animatedTexts.length;
                }
            }
            String displayed = fullText.substring(0, Math.min(this.charIndex, fullText.length()));
            int textWidth = CastomFontUtils.fr3.getStringWidth(displayed);
            int totalWidth = (int)(this.field_146294_l - this.posX);
            int textX = (int)(this.posX + (double)(totalWidth - textWidth) / 2.0);
            int textY = (int)(this.posY + 10.0);
            CastomFontUtils.fr3.drawString(displayed, textX, textY, new Color(200, 200, 200).getRGB());
        } else {
            int n7 = 0;
            ArrayList<Module> modules = new ArrayList<Module>(Horizon.moduleManager.getModules(this.selectedCategory));
            modules.sort((m1, m2) -> {
                int width1 = CastomFontUtils.fr3.getStringWidth(m1.getName());
                int width2 = CastomFontUtils.fr3.getStringWidth(m2.getName());
                return Integer.compare(width2, width1);
            });
            for (Module module : modules) {
                String displayText;
                RenderUtil.drawRect(this.posX + 65.0, this.posY + 1.0 + (double)n7, this.posX + 150.0, this.posY + 15.0 + (double)n7, module.isToggled() ? new Color(46, 85, 234, 155).getRGB() : new Color(28, 28, 28, 249).getRGB());
                if (binding && module == this.selectedModule) {
                    displayText = "Press a key...";
                } else {
                    displayText = module.getName();
                    int key = module.getKey();
                    if (key != 0) {
                        String keyName = Keyboard.getKeyName((int)key);
                        displayText = displayText + " [" + keyName + "]";
                    }
                }
                CastomFontUtils.fr3.drawString(displayText, (int)this.posX + 67, (int)(this.posY + 5.0) + n7, new Color(170, 170, 170).getRGB());
                n7 += 15;
            }
        }
        Gui.func_73734_a((int)((int)(this.posX + 132.0)), (int)((int)(this.posY + 360.0)), (int)((int)this.posX), (int)((int)(this.posY + 320.5)), (int)new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr4.drawStringWithShadow("SpaceHorizon", (float)(this.posX + 30.0), (float)(this.posY + 329.0), ClickGUI.getColor());
        CastomFontUtils.fr4.drawStringWithShadow("Name: " + this.field_146297_k.func_110432_I().func_111285_a(), (float)(this.posX + 30.0), (float)(this.posY + 339.5), Color.WHITE.getRGB());
        try {
            this.field_146297_k.func_110434_K().func_110577_a(Objects.requireNonNull(this.field_146297_k.func_147114_u()).func_175102_a(this.field_146297_k.field_71439_g.func_110124_au()).func_178837_g());
            Gui.func_152125_a((int)((int)(this.posX + 5.0)), (int)((int)(this.posY + 330.0)), (float)8.0f, (float)8.0f, (int)8, (int)8, (int)22, (int)22, (float)64.0f, (float)64.0f);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (this.selectedCategory != Category.HOME) {
            for (Comp comp : this.comps) {
                comp.drawScreen(n, n2);
            }
        }
    }

    public ScaledResolution getScaledRes() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    public boolean isEditing() {
        return this.editing;
    }

    protected void func_146286_b(int n, int n2, int n3) {
        super.func_146286_b(n, n2, n3);
        this.dragging = false;
        for (Comp comp : this.comps) {
            comp.mouseReleased(n, n2, n3);
        }
    }

    public CastomGui() {
        binding = false;
        this.posX = this.getScaledRes().func_78326_a() / 2 - 150;
        this.posY = this.getScaledRes().func_78328_b() / 2 - 100;
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m += 380.0;
        this.selectedCategory = Category.HOME;
        this.x = 100.0;
        this.y = 200.0;
    }

    static {
        animatedTexts = new String[]{"Hello this client created by-Jeklout", "Space-Horizon Client in RustEx", "https://t.me/MoonBezna"};
        itemRender = Minecraft.func_71410_x().func_175599_af();
    }
}
