package recode.space.horizon.Castom.comp;

import recode.space.horizon.Castom.comp.Comp;

public class ColorHue
extends Comp {
}
