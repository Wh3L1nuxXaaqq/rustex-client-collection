package recode.space.horizon.Castom.comp;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import recode.space.horizon.Castom.CastomGui;
import recode.space.horizon.Castom.comp.Comp;
import recode.space.horizon.Castom.setting.Setting;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.RenderUtils;

public class Slider
extends Comp {
    private double renderWidth;
    private double renderWidth2;
    private boolean dragging = false;

    public Slider(double x, double y, CastomGui parent, Module module, Setting setting) {
        this.x = x;
        this.y = y;
        this.parent = parent;
        this.module = module;
        this.setting = setting;
    }

    private double roundToPlace(double val, int newScale) {
        if (newScale < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(val).setScale(newScale, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        double x1 = this.parent.posX + this.x - 70.0;
        double y1 = this.parent.posY + this.y + 10.0;
        double x2 = x1 + this.renderWidth2;
        double y2 = y1 + 8.0;
        if (this.isInside(mouseX, mouseY, x1, y1 - 2.0, x2, y2 + 4.0) && mouseButton == 0) {
            this.dragging = true;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        this.dragging = false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        super.drawScreen(mouseX, mouseY);
        double min = this.setting.getMin();
        double max = this.setting.getMax();
        double fullWidth = 90.0;
        this.renderWidth2 = 90.0;
        this.renderWidth = 90.0 * (this.setting.getValDouble() - min) / (max - min);
        double mouseRelative = Math.min(90.0, Math.max(0.0, (double)mouseX - (this.parent.posX + this.x - 70.0)));
        if (this.dragging) {
            if (mouseRelative == 0.0) {
                this.setting.setValDouble(this.setting.getMin());
            } else {
                this.setting.setValDouble(this.roundToPlace(mouseRelative / 90.0 * (max - min) + min, 1));
            }
        }
        float baseX = (float)(this.parent.posX + this.x - 70.0);
        float baseY = (float)(this.parent.posY + this.y + 12.0);
        float barHeight = 4.5f;
        float radius = barHeight / 2.0f;
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(baseX, baseY, baseX + (float)this.renderWidth2, baseY + barHeight, radius, 3.0f, new Color(45, 45, 45, 255).getRGB(), new Color(50, 50, 50, 255).getRGB(), new Color(40, 40, 40, 255).getRGB(), new Color(35, 35, 35, 255).getRGB(), false, true, false);
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(baseX, baseY, baseX + (float)this.renderWidth, baseY + barHeight, radius, 3.0f, new Color(255, 0, 255, 255).getRGB(), new Color(255, 0, 255, 255).getRGB(), new Color(255, 0, 255, 255).getRGB(), new Color(255, 0, 255, 255).getRGB(), false, true, false);
        float knobRadius = 4.0f;
        float knobX = baseX + (float)this.renderWidth;
        float knobY = baseY + barHeight / 2.0f;
        RenderUtil.drawCircle(knobX, knobY, knobRadius, new Color(255, 0, 255, 255).getRGB());
        String label = this.setting.getName() + ": " + this.setting.getValDouble();
        CastomFontUtils.fr2.drawString(label, (int)(this.parent.posX + this.x - 65.0), (int)(this.parent.posY + this.y + 2.0), new Color(200, 200, 200).getRGB());
    }
}
