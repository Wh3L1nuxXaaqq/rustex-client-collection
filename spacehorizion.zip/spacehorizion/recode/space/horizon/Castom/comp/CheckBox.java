package recode.space.horizon.Castom.comp;

import java.awt.Color;
import recode.space.horizon.Castom.CastomGui;
import recode.space.horizon.Castom.comp.Comp;
import recode.space.horizon.Castom.setting.Setting;
import recode.space.horizon.module.Module;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;
import recode.space.horizon.utils.RenderUtils;

public class CheckBox
extends Comp {
    private float animation = 0.0f;

    public CheckBox(double x, double y, CastomGui parent, Module module, Setting setting) {
        this.x = x;
        this.y = y;
        this.parent = parent;
        this.module = module;
        this.setting = setting;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        if (this.isInside(mouseX, mouseY, this.parent.posX + this.x - 70.0, this.parent.posY + this.y + 3.0, this.parent.posX + this.x - 70.0 + 25.0, this.parent.posY + this.y + 13.0) && button == 0) {
            this.setting.setValBoolean(!this.setting.getValBoolean());
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        super.drawScreen(mouseX, mouseY);
        boolean enabled = this.setting.getValBoolean();
        this.animation += ((enabled ? 1.0f : 0.0f) - this.animation) * 0.25f;
        float x = (float)(this.parent.posX + this.x - 70.0);
        float y = (float)(this.parent.posY + this.y + 3.0);
        float width = 25.0f;
        float height = 10.0f;
        float round = 5.0f;
        int c1 = enabled ? new Color(0, 170, 255, 255).getRGB() : new Color(70, 70, 70, 255).getRGB();
        int c2 = enabled ? new Color(0, 170, 255, 255).getRGB() : new Color(70, 70, 70, 255).getRGB();
        int c3 = enabled ? new Color(0, 170, 255, 255).getRGB() : new Color(70, 70, 70, 255).getRGB();
        int c4 = enabled ? new Color(0, 170, 255, 255).getRGB() : new Color(70, 70, 70, 255).getRGB();
        RenderUtils.drawRoundedFullGradientShadowFullGradientRoundedFullGradientRectWithBloomBool(x, y, x + width, y + height, round, 0.0f, c1, c2, c3, c4, false, true, false);
        float knobX = x + 2.0f + this.animation * 13.0f;
        RenderUtil.drawCircle(knobX + 3.0f, y + 5.0f, 4.0f, new Color(255, 255, 255, 240).getRGB());
        CastomFontUtils.fr2.drawString(this.setting.getName(), (int)(this.parent.posX + this.x - 40.0), (int)(this.parent.posY + this.y + 5.0), new Color(200, 200, 200).getRGB());
    }
}
