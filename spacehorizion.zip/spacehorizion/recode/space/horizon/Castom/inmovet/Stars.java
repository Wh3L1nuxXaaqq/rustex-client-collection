package recode.space.horizon.Castom.inmovet;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;

public class Stars {
    private ArrayList<Star> stars;
    private Random random;
    private double guiWidth;
    private double guiHeight;
    private double posX;
    private double posY;

    public Stars(int count, double width, double height, double posX, double posY) {
        this.guiWidth = width;
        this.guiHeight = height;
        this.posX = posX;
        this.posY = posY;
        this.stars = new ArrayList();
        this.random = new Random();
        for (int i = 0; i < count; ++i) {
            float x = (float)(posX + (double)this.random.nextFloat() * width);
            float y = (float)(posY + (double)this.random.nextFloat() * height);
            float size = 1.0f + this.random.nextFloat() * 2.0f;
            float speed = 0.5f + this.random.nextFloat() * 1.5f;
            this.stars.add(new Star(x, y, size, speed));
        }
    }

    public void update() {
        for (Star star : this.stars) {
            star.update();
        }
    }

    public void render() {
        for (Star star : this.stars) {
            star.render();
        }
    }

    private class Star {
        float x;
        float y;
        float size;
        float alpha;
        float speed;
        boolean increasing;

        Star(float x, float y, float size, float speed) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.alpha = 0.5f;
            this.speed = speed;
            this.increasing = true;
        }

        void update() {
            this.y += this.speed;
            if (this.increasing) {
                this.alpha += 0.02f;
                if (this.alpha >= 0.9f) {
                    this.alpha = 0.9f;
                    this.increasing = false;
                }
            } else {
                this.alpha -= 0.02f;
                if (this.alpha <= 0.4f) {
                    this.alpha = 0.4f;
                    this.increasing = true;
                }
            }
            if ((double)this.y > Stars.this.posY + Stars.this.guiHeight) {
                this.y = (float)Stars.this.posY;
                this.x = (float)(Stars.this.posX + (double)Stars.this.random.nextFloat() * Stars.this.guiWidth);
                this.speed = 0.5f + Stars.this.random.nextFloat() * 1.5f;
            }
        }

        void render() {
            GlStateManager.func_179147_l();
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)this.alpha);
            Gui.func_73734_a((int)((int)this.x), (int)((int)this.y), (int)((int)(this.x + this.size)), (int)((int)(this.y + this.size)), (int)-1);
            GlStateManager.func_179084_k();
        }
    }
}
