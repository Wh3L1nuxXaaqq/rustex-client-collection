package Bobr.buttons.setting.settings;

import Bobr.buttons.setting.CSSetting;
import Bobr.util.RenderHelper;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.gui.Gui;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.settings.Setting;

public class CSSettingCheck
extends CSSetting {
    private int animation = 20;

    public CSSettingCheck(int x, int y, int width, int height, Setting s) {
        super(x, y, width, height, s);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.fr.func_78276_b(this.displayString, this.x, this.y, Integer.MAX_VALUE);
        int stringwidth = this.fr.func_78256_a(this.displayString);
        Gui.func_73734_a((int)(this.x + stringwidth + 20), (int)this.y, (int)(this.x + stringwidth + 30), (int)(this.y + 10), (int)Color.black.getRGB());
        RenderHelper.drawFullCircle(this.x + stringwidth + 20, this.y + 5, 5.0, Color.black.getRGB());
        RenderHelper.drawFullCircle(this.x + stringwidth + 30, this.y + 5, 5.0, Color.black.getRGB());
        if (this.set.getValBoolean()) {
            RenderHelper.drawFullCircle(this.x + stringwidth + this.animation, this.y + 5, 5.0, ClickGUI.getColor());
        } else {
            RenderHelper.drawFullCircle(this.x + stringwidth + this.animation, this.y + 5, 5.0, -2);
        }
        if (this.set.getValBoolean()) {
            if (this.animation < 30) {
                ++this.animation;
            }
        } else if (this.animation > 20) {
            --this.animation;
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.isHovered(mouseX, mouseY) && mouseButton == 0) {
            this.set.setValBoolean(!this.set.getValBoolean());
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    private boolean isHovered(int mouseX, int mouseY) {
        int stringwidth = this.fr.func_78256_a(this.displayString);
        boolean hoveredx = mouseX > this.x + stringwidth + 15 && mouseX < this.x + stringwidth + 35;
        boolean hoveredy = mouseY > this.y && mouseY < this.y + 10;
        return hoveredx && hoveredy;
    }
}
