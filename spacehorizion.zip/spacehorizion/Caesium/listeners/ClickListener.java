package Caesium.listeners;

import Caesium.components.GuiButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import recode.space.horizon.Horizon;
import recode.space.horizon.module.Module;

public class ClickListener
implements ActionListener {
    private GuiButton button;

    public ClickListener(GuiButton button) {
        this.button = button;
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Module m = Horizon.moduleManager.getModule(this.button.getText());
        m.toggle();
    }
}
