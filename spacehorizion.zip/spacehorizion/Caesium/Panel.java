package Caesium;

import Caesium.ClickGui;
import Caesium.components.Frame;
import Caesium.components.GuiButton;
import Caesium.components.GuiFrame;
import Caesium.listeners.ClickListener;
import Caesium.listeners.ComponentsListener;
import Caesium.util.FramePosition;
import java.awt.Color;
import java.util.HashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import recode.space.horizon.manager.ModuleManager;
import recode.space.horizon.module.Category;
import recode.space.horizon.module.Module;
import recode.space.horizon.module.hud.ClickGUI;

public class Panel
extends ClickGui {
    public static HashMap<String, FramePosition> framePositions = new HashMap();
    public static FontRenderer fR = Minecraft.func_71410_x().field_71466_p;
    public static String theme;
    public static int FRAME_WIDTH;
    public static int color;
    public static int fontColor;
    public static int grey40_240;
    public static int black195;
    public static int black100;

    public Panel(String theme, int fontSize) {
        Panel.theme = theme;
    }

    public void ref(Category cat, int x) {
        GuiFrame frame = new GuiFrame(cat.name(), x, 50, true);
        for (Module m : ModuleManager.modules) {
            if (cat != m.getCategory() || !m.visible) continue;
            GuiButton button = new GuiButton(m.getName());
            button.addClickListener(new ClickListener(button));
            button.addExtendListener(new ComponentsListener(button));
            frame.addButton(button);
        }
        this.addFrame(frame);
    }

    @Override
    public void func_73866_w_() {
        int x = 25;
        this.ref(Category.COMBAT, x);
        this.ref(Category.MOVEMENT, x += 135);
        this.ref(Category.RENDER, x += 135);
        this.ref(Category.OUTHER, x += 135);
        this.ref(Category.HUD, x += 135);
        super.func_73866_w_();
    }

    public void func_146281_b() {
        if (!this.getFrames().isEmpty()) {
            for (Frame frame : this.getFrames()) {
                GuiFrame guiFrame = (GuiFrame)frame;
                framePositions.put(guiFrame.getTitle(), new FramePosition(guiFrame.getPosX(), guiFrame.getPosY(), guiFrame.isExpaned()));
            }
        }
    }

    static {
        FRAME_WIDTH = 100;
        color = ClickGUI.getColor();
        fontColor = Color.white.getRGB();
        grey40_240 = new Color(40, 40, 40, 100).getRGB();
        black195 = new Color(255, 255, 255, 100).getRGB();
        black100 = new Color(0, 0, 0, 255).getRGB();
    }
}
