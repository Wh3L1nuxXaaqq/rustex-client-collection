package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import recode.space.horizon.utils.Font.CastomFontUtils;

public class GuiLabel
implements GuiComponent {
    private String text;

    public GuiLabel(String text) {
        this.text = text;
    }

    @Override
    public void render(int posX, int posY, int width, int mouseX, int mouseY, int wheelY) {
        CastomFontUtils.fr4.drawStringWithShadow(this.text, posX + width / 2 - CastomFontUtils.fr4.getStringWidth(this.text) / 2, posY + 2, Panel.fontColor);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
    }

    @Override
    public void keyTyped(int keyCode, char typedChar) {
    }

    @Override
    public int getWidth() {
        return CastomFontUtils.fr4.getStringWidth(this.text) + 4;
    }

    @Override
    public int getHeight() {
        return CastomFontUtils.fr4.getHeight() + 2;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }
}
