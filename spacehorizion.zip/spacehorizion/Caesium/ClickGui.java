package Caesium;

import Caesium.Panel;
import Caesium.components.Frame;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;
import recode.space.horizon.manager.FriendManager;
import recode.space.horizon.module.hud.ClickGUI;
import recode.space.horizon.utils.Font.CastomFontUtils;
import recode.space.horizon.utils.RenderUtil;

public class ClickGui
extends GuiScreen {
    public static int compID = 0;
    private ArrayList<Frame> frames = new ArrayList();
    private final FontRenderer fr;

    public ClickGui() {
        this.fr = Minecraft.func_71410_x().field_71466_p;
        compID = 0;
    }

    protected void addFrame(Frame frame) {
        if (!this.frames.contains(frame)) {
            this.frames.add(frame);
        }
    }

    protected ArrayList<Frame> getFrames() {
        return this.frames;
    }

    public void func_73866_w_() {
        for (Frame frame : this.frames) {
            frame.initialize();
        }
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        for (Frame frame : this.frames) {
            frame.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        super.func_73869_a(typedChar, keyCode);
        for (Frame frame : this.frames) {
            frame.keyTyped(keyCode, typedChar);
        }
    }

    public void drawinfo(int mouseX, int mouseY) {
        int xpos = 600;
        int ypos = 280;
        int g = 0;
        CastomFontUtils.fr4.drawStringWithShadow("Friends", xpos + CastomFontUtils.fr4.getStringWidth("Friends") / 2, ypos - CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawRect(xpos, ypos, xpos + 100, ypos + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), new Color(50, 50, 50, 190).getRGB());
        RenderUtil.drawNewRect(xpos - 1, ypos, xpos, ypos + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawNewRect(xpos + 100 - 1, ypos, xpos + 100, ypos + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor());
        RenderUtil.drawGlow(xpos, ypos - 1, xpos + 100, ypos, ClickGUI.getColor(), 250.0);
        RenderUtil.drawGlow(xpos, ypos + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight() - 1, xpos + 100, ypos + FriendManager.FRIENDS.size() * CastomFontUtils.fr4.getHeight(), ClickGUI.getColor(), 250.0);
        for (String friends : FriendManager.FRIENDS) {
            int butX1 = 0 + xpos;
            int butX2 = 100 + xpos;
            int butY1 = g + ypos;
            int butY2 = g + this.field_146289_q.field_78288_b + ypos;
            if (mouseX > butX1 && mouseX < butX2 && mouseY > butY1 && mouseY < butY2) {
                CastomFontUtils.fr4.drawString(friends, xpos + 50 - CastomFontUtils.fr4.getStringWidth(friends) / 2, g + ypos, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(friends);
                    return;
                }
            } else {
                CastomFontUtils.fr4.drawString(friends, xpos + 50 - CastomFontUtils.fr4.getStringWidth(friends) / 2, g + ypos, Color.white.getRGB());
            }
            g += CastomFontUtils.fr4.getHeight();
        }
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sR = new ScaledResolution(this.field_146297_k);
        Gui.func_73734_a((int)64, (int)556, (int)0, (int)524, (int)new Color(37, 37, 37, 255).getRGB());
        Gui.func_73734_a((int)0, (int)525, (int)64, (int)527, (int)ClickGUI.getColor());
        CastomFontUtils.fr4.drawString("By FlipsTer", 4.0f, 529.0f, Panel.fontColor);
        for (Frame frame : this.frames) {
            frame.render(mouseX, mouseY);
            this.drawinfo(mouseX, mouseY);
        }
    }
}
