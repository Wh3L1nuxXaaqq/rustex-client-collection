import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;
import recode.space.horizon.Horizon;
import recode.space.horizon.Menu.onGuiOpenEvent;

@Mod(modid="optifune", version="1.01", name="Space-Horizon")
public class Main {
    private Logger logger;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Display.setTitle((String)("\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 " + Horizon.name));
        this.logger = event.getModLog();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) throws Exception {
        MinecraftForge.EVENT_BUS.register((Object)new onGuiOpenEvent());
        Horizon.instance = new Horizon();
        Horizon.instance.init();
        Horizon.startup();
    }
}
