package net.minecraft.util;

import net.minecraft.client.Minecraft;

public class Timer {
    public int elapsedTicks;
    public float renderPartialTicks;
    public float field_194148_c;
    private long lastSyncSysClock;
    public float timerSpeed;

    public Timer(float tps) {
        this.timerSpeed = 1000.0f / tps;
        this.lastSyncSysClock = Minecraft.getSystemTime();
    }

    public void updateTimer() {
        long i = Minecraft.getSystemTime();
        this.field_194148_c = (float)(i - this.lastSyncSysClock) / this.timerSpeed;
        this.lastSyncSysClock = i;
        this.renderPartialTicks += this.field_194148_c;
        this.elapsedTicks = (int)this.renderPartialTicks;
        this.renderPartialTicks -= (float)this.elapsedTicks;
    }
}
