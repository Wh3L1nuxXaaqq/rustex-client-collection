package net.minecraft.client.gui;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiClientTextField;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class AltLogin
extends GuiScreen {
    GuiClientTextField inputField;
    ResourceLocation backgroundImage = new ResourceLocation("stardust/wtf.png");
    private final long initTime = System.currentTimeMillis();

    @Override
    public void initGui() {
        ScaledResolution sr = new ScaledResolution(this.mc);
        int i = sr.getScaledHeight() / 4 + 48;
        this.buttonList.clear();
        this.inputField = new GuiClientTextField(1, this.fontRendererObj, sr.getScaledWidth() / 2 - 100, i + 72 - 12, 200, 20);
        this.inputField.setText("");
    }

    public static void changeName(String name) {
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            AltLogin.changeName(this.inputField.getText());
        }
    }

    @Override
    public void updateScreen() {
        this.inputField.updateCursorCounter();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(this.mc);
        this.mc.getTextureManager().bindTexture(this.backgroundImage);
        GL11.glBegin((int)7);
        GL11.glVertex2f((float)-1.0f, (float)-1.0f);
        GL11.glVertex2f((float)-1.0f, (float)1.0f);
        GL11.glVertex2f((float)1.0f, (float)1.0f);
        GL11.glVertex2f((float)1.0f, (float)-1.0f);
        GL11.glEnd();
        GL20.glUseProgram((int)0);
        GlStateManager.disableCull();
        GlStateManager.pushMatrix();
        for (int i = 0; i < this.buttonList.size(); ++i) {
            ((GuiButton)this.buttonList.get(i)).drawButton(this.mc, mouseX, mouseY, partialTicks);
        }
    }

    public static void setSession(Session s) {
    }
}
