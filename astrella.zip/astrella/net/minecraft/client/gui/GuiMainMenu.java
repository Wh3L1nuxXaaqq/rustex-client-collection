package net.minecraft.client.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AltLogin;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import wtf.astrella.Util.Render.RoundedUtility;
import wtf.astrella.Util.font.Fonts;
import wtf.astrella.Util.other.HoverUtility;

public class GuiMainMenu
extends GuiScreen {
    public static int counter = 1;
    private final long initTime = System.currentTimeMillis();
    public static int bg = 0;
    private ResourceLocation backgroundImage = new ResourceLocation("stardust/wtf.png");
    float offset;
    private List<String> buttons = new ArrayList<String>();
    private GuiWorldSelection guiWorldSelection;
    private GuiMultiplayer guiMultiplayer;
    private GuiOptions guiOptions;

    @Override
    public void initGui() {
        this.buttons.clear();
        this.buttons.addAll(Arrays.asList("\u041e\u0434\u0438\u043d\u043e\u0447\u043d\u0430\u044f \u0438\u0433\u0440\u0430", "\u0421\u0435\u0442\u0435\u0432\u0430\u044f \u0438\u0433\u0440\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        Minecraft.getMinecraft().getTextureManager().bindTexture(this.backgroundImage);
        GuiMainMenu.drawModalRectWithCustomSizedTexture(0.0f, 0.0f, 0.0f, 0.0f, sr.getScaledWidth(), sr.getScaledHeight(), sr.getScaledWidth(), sr.getScaledHeight());
        GlStateManager.disableCull();
        GlStateManager.pushMatrix();
        RoundedUtility.drawRound(sr.getScaledWidth() / 2 - 70, sr.getScaledHeight() / 2 - 40, 140.0f, 120.0f, 5.0f, new Color(0, 0, 0, 110));
        this.offset = 0.0f;
        for (String string : this.buttons) {
            Fonts.medium14.drawCenteredString(string, sr.getScaledWidth() / 2, (float)(sr.getScaledHeight() / 2 - 40 + 34 + 5) + this.offset, -1);
            RoundedUtility.drawRound(sr.getScaledWidth() / 2 - 55, (float)(sr.getScaledHeight() / 2 - 40 + 34) + this.offset, 110.0f, 15.0f, 3.0f, HoverUtility.isHovered(mouseX, mouseY, sr.getScaledWidth() / 2 - 55, (float)(sr.getScaledHeight() / 2 - 40 + 34) + this.offset, 110.0, 15.0) ? new Color(255, 255, 255, 18) : new Color(255, 255, 255, 10));
            this.offset += 20.0f;
        }
        GlStateManager.popMatrix();
        Fonts.nl20.drawCenteredString("https://t.me/goulash1ik", sr.getScaledWidth() / 2 - 350, sr.getScaledHeight() / 2 + 215, Color.cyan.getRGB());
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        this.offset = 0.0f;
        for (String string : this.buttons) {
            if (HoverUtility.isHovered(mouseX, mouseY, sr.getScaledWidth() / 2 - 55, (float)(sr.getScaledHeight() / 2 - 40 + 34) + this.offset, 110.0, 15.0)) {
                switch (string) {
                    case "\u041e\u0434\u0438\u043d\u043e\u0447\u043d\u0430\u044f \u0438\u0433\u0440\u0430": {
                        Minecraft.getMinecraft().displayGuiScreen(new GuiWorldSelection(null));
                        break;
                    }
                    case "\u0421\u0435\u0442\u0435\u0432\u0430\u044f \u0438\u0433\u0440\u0430": {
                        Minecraft.getMinecraft().displayGuiScreen(new GuiMultiplayer(null));
                        break;
                    }
                    case "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438": {
                        Minecraft.getMinecraft().displayGuiScreen(new GuiOptions(null, Minecraft.getMinecraft().gameSettings));
                        break;
                    }
                    case "\u0410\u043a\u043a\u0430\u0443\u043d\u0442\u044b": {
                        Minecraft.getMinecraft().displayGuiScreen(new AltLogin());
                    }
                }
                break;
            }
            this.offset += 20.0f;
        }
    }
}
