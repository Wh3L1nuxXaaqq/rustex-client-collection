package net.minecraft.client.gui;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import swill.client.gui.GuiAccountManager;
import swill.client.modules.misc.ClientTheme;
import swill.client.sound.MenuMusic;
import swill.client.utils.FontManager;
import swill.client.utils.RenderUtils;

public class GuiMainMenu
extends GuiScreen {
    private final List<Star> stars = new ArrayList<Star>();
    private final Random rand = new Random();

    @Override
    public void initGui() {
        MenuMusic.playMenuMusic();
        if (this.stars.isEmpty()) {
            for (int i = 0; i < 150; ++i) {
                this.stars.add(new Star(this.width, this.height, this.rand));
            }
        }
        int cx = this.width / 2;
        int cy = this.height / 2 + 50;
        int gap = 60;
        int startX = cx - gap * 2;
        this.buttonList.add(new GuiButton(1, startX, cy, 30, 30, "Single"));
        this.buttonList.add(new GuiButton(2, startX + gap, cy, 30, 30, "Multi"));
        this.buttonList.add(new GuiButton(100, startX + gap * 2, cy, 30, 30, "Alts"));
        this.buttonList.add(new GuiButton(0, startX + gap * 3, cy, 30, 30, "Config"));
        this.buttonList.add(new GuiButton(4, startX + gap * 4, cy, 30, 30, "Quit"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GuiMainMenu.drawRect(0, 0, this.width, this.height, -16777216);
        for (Star star : this.stars) {
            star.update(this.width, this.height, this.rand);
            star.draw();
        }
        SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, MMM d'th'", Locale.ENGLISH);
        Date now = new Date();
        String timeStr = timeFmt.format(now);
        String dateStr = dateFmt.format(now);
        int cx = this.width / 2;
        int cy = this.height / 2 - 30;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0.0f);
        GlStateManager.scale(3.0f, 3.0f, 1.0f);
        int tw = FontManager.getStringWidth(timeStr);
        FontManager.drawString(timeStr, (float)(-tw) / 2.0f, 0.0f, -1);
        GlStateManager.popMatrix();
        int dw = FontManager.getStringWidth(dateStr);
        FontManager.drawString(dateStr, (float)cx - (float)dw / 2.0f, (float)(cy + 30), -1);
        int gap = 60;
        int startX = cx - gap * 2;
        int iconY = this.height / 2 + 50;
        for (int i = 0; i < 5; ++i) {
            int ix = startX + i * gap + 15;
            int iy = iconY + 15;
            boolean hovered = mouseX >= startX + i * gap && mouseX <= startX + i * gap + 30 && mouseY >= iconY && mouseY <= iconY + 30;
            int color = hovered ? ClientTheme.getThemeColor(255) : -1;
            GlStateManager.pushMatrix();
            GlStateManager.translate(ix, iy, 0.0f);
            if (hovered) {
                GlStateManager.scale(1.1f, 1.1f, 1.1f);
            }
            this.drawPrimitiveIcon(i, color);
            GlStateManager.popMatrix();
        }
        FontManager.drawStringSmall("https://t.me/logovo_vajbkodera", 10, this.height - 15, 0x44FFFFFF);
    }

    private void drawPrimitiveIcon(int index, int color) {
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.color(r, g, b, 1.0f);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        GlStateManager.glLineWidth(2.0f);
        if (index == 0) {
            RenderUtils.drawCircle(0.0f, -4.0f, 4.0f, color);
            buf.begin(3, DefaultVertexFormats.POSITION);
            buf.pos(-7.0, 7.0, 0.0).endVertex();
            buf.pos(-5.0, 2.0, 0.0).endVertex();
            buf.pos(5.0, 2.0, 0.0).endVertex();
            buf.pos(7.0, 7.0, 0.0).endVertex();
            tess.draw();
        } else if (index == 1) {
            RenderUtils.drawCircle(-3.0f, -4.0f, 3.5f, color);
            RenderUtils.drawCircle(4.0f, -2.0f, 3.0f, color);
            buf.begin(3, DefaultVertexFormats.POSITION);
            buf.pos(-8.0, 7.0, 0.0).endVertex();
            buf.pos(-6.0, 3.0, 0.0).endVertex();
            buf.pos(0.0, 3.0, 0.0).endVertex();
            buf.pos(2.0, 7.0, 0.0).endVertex();
            tess.draw();
        } else if (index == 2) {
            RenderUtils.drawCircle(0.0f, 0.0f, 10.0f, color);
            RenderUtils.drawCircle(0.0f, -3.0f, 3.0f, color);
            buf.begin(3, DefaultVertexFormats.POSITION);
            buf.pos(-5.0, 6.0, 0.0).endVertex();
            buf.pos(-4.0, 2.0, 0.0).endVertex();
            buf.pos(4.0, 2.0, 0.0).endVertex();
            buf.pos(5.0, 6.0, 0.0).endVertex();
            tess.draw();
        } else if (index == 3) {
            RenderUtils.drawCircle(0.0f, 0.0f, 4.0f, color);
            buf.begin(1, DefaultVertexFormats.POSITION);
            for (int i = 0; i < 8; ++i) {
                double a = Math.toRadians(i * 45);
                buf.pos(Math.cos(a) * 4.0, Math.sin(a) * 4.0, 0.0).endVertex();
                buf.pos(Math.cos(a) * 7.0, Math.sin(a) * 7.0, 0.0).endVertex();
            }
            tess.draw();
        } else if (index == 4) {
            buf.begin(1, DefaultVertexFormats.POSITION);
            buf.pos(-7.0, -7.0, 0.0).endVertex();
            buf.pos(7.0, 7.0, 0.0).endVertex();
            buf.pos(-7.0, 7.0, 0.0).endVertex();
            buf.pos(7.0, -7.0, 0.0).endVertex();
            tess.draw();
        }
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0) {
            return;
        }
        int cx = this.width / 2;
        int gap = 60;
        int startX = cx - gap * 2;
        int iconY = this.height / 2 + 50;
        for (int i = 0; i < 5; ++i) {
            if (mouseX < startX + i * gap || mouseX > startX + i * gap + 30 || mouseY < iconY || mouseY > iconY + 30) continue;
            MenuMusic.stopMenuMusic();
            if (i == 0) {
                this.mc.displayGuiScreen(new GuiWorldSelection(this));
            } else if (i == 1) {
                this.mc.displayGuiScreen(new GuiMultiplayer(this));
            } else if (i == 2) {
                this.mc.displayGuiScreen(new GuiAccountManager(this));
            } else if (i == 3) {
                this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
            } else if (i == 4) {
                this.mc.shutdown();
            }
            return;
        }
    }

    private static class Star {
        float x;
        float y;
        float speed;
        float size;
        float alpha;

        public Star(int width, int height, Random rand) {
            this.x = rand.nextFloat() * (float)width;
            this.y = rand.nextFloat() * (float)height;
            this.speed = 0.15f + rand.nextFloat() * 0.45f;
            this.size = 0.5f + rand.nextFloat() * 2.0f;
            this.alpha = 0.1f + rand.nextFloat() * 0.4f;
        }

        public void update(int width, int height, Random rand) {
            this.y += this.speed;
            if (this.y > (float)(height + 10)) {
                this.y = -10.0f;
                this.x = rand.nextFloat() * (float)width;
                this.speed = 0.15f + rand.nextFloat() * 0.45f;
                this.size = 0.5f + rand.nextFloat() * 2.0f;
                this.alpha = 0.1f + rand.nextFloat() * 0.4f;
            }
        }

        public void draw() {
            int finalAlpha = (int)(this.alpha * 255.0f);
            if (finalAlpha <= 0) {
                return;
            }
            int argb = finalAlpha << 24 | 0xAAAAAA;
            if (this.size > 1.2f) {
                RenderUtils.drawCircle(this.x, this.y, this.size, argb);
                RenderUtils.drawCircle(this.x, this.y, this.size - 0.5f, -16777216);
            } else {
                RenderUtils.drawCircle(this.x, this.y, this.size, argb);
            }
        }
    }
}
