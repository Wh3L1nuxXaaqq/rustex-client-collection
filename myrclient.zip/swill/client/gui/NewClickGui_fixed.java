package swill.client.gui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import swill.client.gui.theme.ThemeManager;
import swill.client.modules.Module;
import swill.client.modules.ModuleManager;

public class NewClickGui_fixed
extends GuiScreen {
    private static final ResourceLocation BACKGROUND_TEXTURE = new ResourceLocation("textures/gui/demo_background.png");
    private final Minecraft mc = Minecraft.getMinecraft();
    private boolean guiOpen = false;
    private float guiAlpha = 0.0f;
    private long openTime = 0L;
    private final List<String> moduleNames = new ArrayList<String>();
    private final List<GuiPanel> panels = new ArrayList<GuiPanel>();
    private GuiPanel selectedPanel = null;
    private float backgroundBrightness = 1.0f;
    private float crosshairScale = 1.0f;
    private float openButtonY = 0.0f;

    public NewClickGui_fixed() {
        this.moduleNames.add("KillAura");
        this.moduleNames.add("AutoSprint");
        this.moduleNames.add("Reach");
        this.moduleNames.add("HitSound");
        this.moduleNames.add("Strafe");
        this.moduleNames.add("ESP");
        this.moduleNames.add("ArrayList");
        this.moduleNames.add("Hud");
        this.moduleNames.add("NewAim");
        this.moduleNames.add("Disabler");
        this.moduleNames.add("NoFall");
        this.moduleNames.add("Nametags");
    }

    @Override
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents((boolean)true);
        Mouse.setGrabbed((boolean)false);
        int panelSpacing = 160;
        int startX = (this.width - 4 * panelSpacing) / 2;
        int startY = this.height / 2 - 90;
        this.panels.clear();
        this.panels.add(new GuiPanel("Combat", startX, startY));
        this.panels.add(new GuiPanel("Movement", startX + panelSpacing, startY));
        this.panels.add(new GuiPanel("Visual", startX + panelSpacing * 2, startY));
        this.panels.add(new GuiPanel("Misc", startX + panelSpacing * 3, startY));
        if (!this.guiOpen) {
            this.guiOpen = true;
            this.openTime = System.currentTimeMillis();
            this.guiAlpha = 0.0f;
            this.backgroundBrightness = 1.0f;
            this.openButtonY = 10.0f;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        Keyboard.enableRepeatEvents((boolean)false);
        Mouse.setGrabbed((boolean)true);
        this.guiOpen = false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.updateAnimations();
        NewClickGui_fixed.drawRect(0, 0, this.width, this.height, new Color(0, 0, 0, (int)(150.0f * this.guiAlpha)).getRGB());
        this.drawMinecraftBackground();
        if (!this.guiOpen || this.guiAlpha < 0.1f) {
            this.drawHudElements(mouseX, mouseY, partialTicks);
            this.drawOpenButton(mouseX, mouseY);
        } else {
            this.drawGuiPanels(mouseX, mouseY, partialTicks);
        }
        this.drawCrosshair();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void updateAnimations() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - this.openTime;
        if (this.guiOpen) {
            float progress = Math.min(1.0f, (float)elapsed / 300.0f);
            this.guiAlpha = this.easeOutCubic(progress);
            this.backgroundBrightness = 0.7f;
            this.crosshairScale = 0.8f;
            this.openButtonY = 10.0f * (1.0f - progress);
        } else {
            float progress = Math.min(1.0f, (float)elapsed / 200.0f);
            this.guiAlpha = 1.0f - this.easeOutCubic(progress);
            this.backgroundBrightness = 0.7f + 0.3f * progress;
            this.crosshairScale = 0.8f + 0.2f * progress;
            this.openButtonY = 10.0f * progress;
        }
    }

    private float easeOutCubic(float x) {
        return (float)(1.0 - Math.pow(1.0f - x, 3.0));
    }

    private void drawMinecraftBackground() {
        ScaledResolution sr = new ScaledResolution(this.mc);
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        Color topColor = new Color(30, 60, 120, (int)(255.0f * this.guiAlpha * 0.3f));
        Color bottomColor = new Color(60, 40, 20, (int)(255.0f * this.guiAlpha * 0.3f));
        topColor = this.applyBrightness(topColor, this.backgroundBrightness);
        bottomColor = this.applyBrightness(bottomColor, this.backgroundBrightness);
        buffer.pos(0.0, 0.0, 0.0).color(topColor.getRed(), topColor.getGreen(), topColor.getBlue(), topColor.getAlpha()).endVertex();
        buffer.pos(this.width, 0.0, 0.0).color(topColor.getRed(), topColor.getGreen(), topColor.getBlue(), topColor.getAlpha()).endVertex();
        buffer.pos(this.width, this.height, 0.0).color(bottomColor.getRed(), bottomColor.getGreen(), bottomColor.getBlue(), bottomColor.getAlpha()).endVertex();
        buffer.pos(0.0, this.height, 0.0).color(bottomColor.getRed(), bottomColor.getGreen(), bottomColor.getBlue(), bottomColor.getAlpha()).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private Color applyBrightness(Color color, float brightness) {
        float r = (float)color.getRed() * brightness / 255.0f;
        float g = (float)color.getGreen() * brightness / 255.0f;
        float b = (float)color.getBlue() * brightness / 255.0f;
        r = Math.min(1.0f, r);
        g = Math.min(1.0f, g);
        b = Math.min(1.0f, b);
        return new Color(r, g, b, (float)color.getAlpha() / 255.0f);
    }

    private void drawHudElements(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(this.mc);
        this.drawArrayListHud(sr);
        this.drawHealthBar(sr);
    }

    private void drawArrayListHud(ScaledResolution sr) {
        int x = sr.getScaledWidth() - 4;
        int y = 4;
        for (int i = 0; i < this.moduleNames.size(); ++i) {
            String moduleName = this.moduleNames.get(i);
            boolean isEnabled = false;
            Module module = ModuleManager.getModuleByName(moduleName);
            if (module != null) {
                isEnabled = module.isEnabled();
            }
            if (!isEnabled) continue;
            int textWidth = this.mc.fontRendererObj.getStringWidth(moduleName);
            int posX = x - textWidth;
            float opacity = 0.9f - (float)i * 0.03f;
            opacity = Math.max(0.3f, opacity);
            int bgColor = new Color(0, 0, 0, (int)(128.0f * opacity)).getRGB();
            int borderColor = new Color(80, 130, 255, (int)(255.0f * opacity)).getRGB();
            NewClickGui_fixed.drawRect(posX - 10, y, x, y + 12, bgColor);
            NewClickGui_fixed.drawRect(x - 2, y, x, y + 12, borderColor);
            this.mc.fontRendererObj.drawStringWithShadow(moduleName, posX - 8, y + 2, new Color(255, 255, 255, (int)(255.0f * opacity)).getRGB());
            y += 13;
        }
    }

    private void drawHealthBar(ScaledResolution sr) {
        int centerX = sr.getScaledWidth() / 2;
        int y = sr.getScaledHeight() - 20;
        String hearts = "\u2665 \u2665 \u2665 \u2665 \u2665 \u2665 \u2665 \u2665 \u2665 \u2665";
        int textWidth = this.mc.fontRendererObj.getStringWidth(hearts);
        this.mc.fontRendererObj.drawStringWithShadow(hearts, centerX - textWidth / 2, y, new Color(255, 80, 80, (int)(180.0f * (1.0f - this.guiAlpha))).getRGB());
    }

    private void drawOpenButton(int mouseX, int mouseY) {
        int buttonHeight;
        int y;
        int buttonY;
        int buttonWidth;
        ScaledResolution sr = new ScaledResolution(this.mc);
        int x = sr.getScaledWidth() - 6;
        int buttonX = x - (buttonWidth = 120);
        boolean hovered = this.isHovered(buttonX, buttonY = (y = sr.getScaledHeight() - 6) - (buttonHeight = 30) - (int)this.openButtonY, buttonX + buttonWidth, buttonY + buttonHeight, mouseX, mouseY);
        Color bgColor = hovered ? new Color(40, 40, 40, 220) : new Color(20, 20, 20, 200);
        this.drawRoundedRect(buttonX, buttonY, buttonX + buttonWidth, buttonY + buttonHeight, 6, bgColor.getRGB());
        NewClickGui_fixed.drawRect(buttonX, buttonY, buttonX + buttonWidth, buttonY + 1, new Color(68, 68, 68, 255).getRGB());
        NewClickGui_fixed.drawRect(buttonX, buttonY + buttonHeight - 1, buttonX + buttonWidth, buttonY + buttonHeight, new Color(68, 68, 68, 255).getRGB());
        NewClickGui_fixed.drawRect(buttonX, buttonY, buttonX + 1, buttonY + buttonHeight, new Color(68, 68, 68, 255).getRGB());
        NewClickGui_fixed.drawRect(buttonX + buttonWidth - 1, buttonY, buttonX + buttonWidth, buttonY + buttonHeight, new Color(68, 68, 68, 255).getRGB());
        String buttonText = "Open ClickGUI";
        int textWidth = this.mc.fontRendererObj.getStringWidth(buttonText);
        this.mc.fontRendererObj.drawStringWithShadow(buttonText, buttonX + (buttonWidth - textWidth) / 2, buttonY + 10, new Color(221, 221, 221, 255).getRGB());
        String keyText = "INSERT";
        int keyWidth = this.mc.fontRendererObj.getStringWidth(keyText);
        this.mc.fontRendererObj.drawString(keyText, buttonX + (buttonWidth - keyWidth) / 2, buttonY + 22, new Color(150, 150, 150, 255).getRGB());
    }

    private void drawGuiPanels(int mouseX, int mouseY, float partialTicks) {
        for (GuiPanel panel : this.panels) {
            panel.draw(mouseX, mouseY, partialTicks, this.guiAlpha);
        }
        if (this.selectedPanel != null) {
            this.selectedPanel.drawModules(mouseX, mouseY, partialTicks, this.guiAlpha);
        }
    }

    private void drawCrosshair() {
        ScaledResolution sr = new ScaledResolution(this.mc);
        int centerX = sr.getScaledWidth() / 2;
        int centerY = sr.getScaledHeight() / 2;
        GlStateManager.pushMatrix();
        GlStateManager.translate(centerX, centerY, 0.0f);
        GlStateManager.scale(this.crosshairScale, this.crosshairScale, 1.0f);
        int color = new Color(255, 255, 255, (int)(255.0f * (1.0f - this.guiAlpha * 0.5f))).getRGB();
        NewClickGui_fixed.drawRect(-1, -9, 1, -3, color);
        NewClickGui_fixed.drawRect(-1, 3, 1, 9, color);
        NewClickGui_fixed.drawRect(-9, -1, -3, 1, color);
        NewClickGui_fixed.drawRect(3, -1, 9, 1, color);
        GlStateManager.popMatrix();
    }

    private void drawRoundedRect(int x, int y, int x2, int y2, int radius, int color) {
        NewClickGui_fixed.drawRect(x + radius, y, x2 - radius, y2, color);
        NewClickGui_fixed.drawRect(x, y + radius, x2, y2 - radius, color);
        NewClickGui_fixed.drawRect(x, y, x + radius, y + radius, color);
        NewClickGui_fixed.drawRect(x2 - radius, y, x2, y + radius, color);
        NewClickGui_fixed.drawRect(x, y2 - radius, x + radius, y2, color);
        NewClickGui_fixed.drawRect(x2 - radius, y2 - radius, x2, y2, color);
    }

    private boolean isHovered(int x, int y, int x2, int y2, int mx, int my) {
        return mx >= x && mx <= x2 && my >= y && my <= y2;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        ScaledResolution sr = new ScaledResolution(this.mc);
        int x = sr.getScaledWidth() - 6;
        int y = sr.getScaledHeight() - 6;
        int buttonWidth = 120;
        int buttonHeight = 30;
        int buttonX = x - buttonWidth;
        int buttonY = y - buttonHeight - (int)this.openButtonY;
        if (this.isHovered(buttonX, buttonY, buttonX + buttonWidth, buttonY + buttonHeight, mouseX, mouseY)) {
            this.guiOpen = !this.guiOpen;
            this.openTime = System.currentTimeMillis();
            return;
        }
        for (GuiPanel panel : this.panels) {
            if (!panel.isHovered(mouseX, mouseY)) continue;
            this.selectedPanel = panel;
            panel.onClick(mouseX, mouseY, mouseButton);
            return;
        }
        if (this.selectedPanel != null) {
            this.selectedPanel.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 210 || keyCode == 1) {
            this.guiOpen = !this.guiOpen;
            this.openTime = System.currentTimeMillis();
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private class GuiPanel {
        private final String name;
        private final int x;
        private final int y;
        private final int width = 140;
        private final int height = 180;
        private boolean hovered = false;
        private boolean selected = false;
        private final List<Module> modules = new ArrayList<Module>();

        public GuiPanel(String name, int x, int y) {
            this.name = name;
            this.x = x;
            this.y = y;
            for (Module module : ModuleManager.getModules()) {
                if (module == null || !module.getCategory().equalsIgnoreCase(name)) continue;
                this.modules.add(module);
            }
        }

        public void draw(int mouseX, int mouseY, float partialTicks, float alpha) {
            this.hovered = this.isAreaHovered(this.x, this.y, this.x + 140, this.y + 180, mouseX, mouseY);
            boolean bl = this.selected = NewClickGui_fixed.this.selectedPanel == this;
            Color bgColor = this.selected ? new Color(40, 40, 55, (int)(220.0f * alpha)) : (this.hovered ? new Color(35, 35, 50, (int)(200.0f * alpha)) : new Color(30, 30, 45, (int)(180.0f * alpha)));
            NewClickGui_fixed.this.drawRoundedRect(this.x, this.y, this.x + 140, this.y + 180, 8, bgColor.getRGB());
            Color titleColor = new Color(50, 50, 70, (int)(255.0f * alpha));
            Gui.drawRect(this.x, this.y, this.x + 140, this.y + 30, titleColor.getRGB());
            Color accentColor = ThemeManager.getCurrentTheme().getAccentColor();
            Gui.drawRect(this.x, this.y + 28, this.x + 140, this.y + 30, accentColor.getRGB());
            ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.drawStringWithShadow(this.name, this.x + 10, this.y + 10, new Color(255, 255, 255, (int)(255.0f * alpha)).getRGB());
            String countText = this.modules.size() + " modules";
            ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.drawString(countText, this.x + 140 - ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.getStringWidth(countText) - 10, this.y + 10, new Color(150, 150, 150, (int)(255.0f * alpha)).getRGB());
        }

        public void drawModules(int mouseX, int mouseY, float partialTicks, float alpha) {
            int moduleX = this.x + 140 + 20;
            int moduleY = this.y;
            int moduleWidth = 200;
            int moduleHeight = 180;
            NewClickGui_fixed.this.drawRoundedRect(moduleX, moduleY, moduleX + moduleWidth, moduleY + moduleHeight, 8, new Color(30, 30, 45, (int)(220.0f * alpha)).getRGB());
            ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.drawStringWithShadow(this.name + " Modules", moduleX + 10, moduleY + 10, new Color(255, 255, 255, (int)(255.0f * alpha)).getRGB());
            int yOffset = 40;
            for (Module module : this.modules) {
                if (module == null) continue;
                boolean moduleHovered = this.isAreaHovered(moduleX + 10, moduleY + yOffset, moduleX + moduleWidth - 10, moduleY + yOffset + 30, mouseX, mouseY);
                Color moduleBg = moduleHovered ? new Color(40, 40, 55, (int)(200.0f * alpha)) : new Color(35, 35, 50, (int)(180.0f * alpha));
                Gui.drawRect(moduleX + 10, moduleY + yOffset, moduleX + moduleWidth - 10, moduleY + yOffset + 30, moduleBg.getRGB());
                ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.drawStringWithShadow(module.getName(), moduleX + 20, moduleY + yOffset + 10, new Color(255, 255, 255, (int)(255.0f * alpha)).getRGB());
                String status = module.isEnabled() ? "ON" : "OFF";
                Color statusColor = module.isEnabled() ? new Color(85, 255, 85) : new Color(255, 85, 85);
                ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.drawString(status, moduleX + moduleWidth - ((NewClickGui_fixed)NewClickGui_fixed.this).mc.fontRendererObj.getStringWidth(status) - 20, moduleY + yOffset + 10, statusColor.getRGB());
                if ((yOffset += 35) <= moduleHeight - 40) continue;
                break;
            }
        }

        public boolean isHovered(int mouseX, int mouseY) {
            return mouseX >= this.x && mouseX <= this.x + 140 && mouseY >= this.y && mouseY <= this.y + 180;
        }

        private boolean isAreaHovered(int x1, int y1, int x2, int y2, int mx, int my) {
            return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
        }

        public void onClick(int mouseX, int mouseY, int button) {
        }

        public void mouseClicked(int mouseX, int mouseY, int button) {
            int moduleX = this.x + 140 + 20;
            int moduleY = this.y;
            int moduleWidth = 200;
            int yOffset = 40;
            for (Module module : this.modules) {
                if (module == null) continue;
                boolean moduleHovered = this.isAreaHovered(moduleX + 10, moduleY + yOffset, moduleX + moduleWidth - 10, moduleY + yOffset + 30, mouseX, mouseY);
                if (moduleHovered && button == 0) {
                    module.toggle();
                    return;
                }
                if ((yOffset += 35) <= 140) continue;
                break;
            }
        }
    }
}
