package swill.client.gui.components;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import swill.client.Components.settings.Setting;
import swill.client.SwillClient;
import swill.client.gui.theme.ThemeManager;
import swill.client.modules.Module;
import swill.client.modules.combat.AimBot;
import swill.client.modules.combat.AutoClicker;
import swill.client.modules.visual.ESP;
import swill.client.modules.visual.ItemESP;
import swill.client.modules.visual.MobESP;
import swill.client.modules.visual.NameTags;
import swill.client.visual.HUD;

public class ModuleButton {
    private Module module;
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean hovered;
    private boolean settingsOpen;
    private ArrayList<Setting> settings;
    private boolean draggingSlider = false;
    private int activeSlider = -1;
    private long lastClickTime = 0L;

    public ModuleButton(Module module, int x, int y, int width, int height) {
        this.module = module;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.settings = new ArrayList();
        if (module instanceof AimBot) {
            this.settings.add(new Setting("FOV", ((AimBot)module).getFov(), 10.0f, 180.0f));
            this.settings.add(new Setting("Range", ((AimBot)module).getRange(), 3.0f, 300.0f));
            this.settings.add(new Setting("Smoothness", ((AimBot)module).getSmoothness(), 1.0f, 20.0f));
            this.settings.add(new Setting("Aim Height", ((AimBot)module).getAimHeight(), 0.5f, 2.0f));
            this.settings.add(new Setting("Draw FOV", ((AimBot)module).isDrawFov()));
        }
        if (module instanceof HUD) {
            // empty if block
        }
        if (module instanceof ItemESP) {
            ItemESP ie = (ItemESP)module;
            this.settings.add(new Setting("Range", ie.getRange(), 10.0f, 100.0f));
            this.settings.add(new Setting("\u0422\u0435\u043a\u0441\u0442 (\u0440\u0430\u0437\u043c\u0435\u0440)", ie.getLabelScaleMul(), 0.4f, 2.5f));
            this.settings.add(new Setting("\u0414\u0430\u043b\u044c\u043d\u0438\u0439 \u0448\u0440\u0438\u0444\u0442", ie.getDistantFontBoost(), 0.0f, 3.0f));
            this.settings.add(new Setting("Draw Box", ie.isDrawBox()));
            this.settings.add(new Setting("Draw Name", ie.isDrawName()));
            this.settings.add(new Setting("Draw Distance", ie.isDrawDistance()));
        }
        if (module instanceof ESP) {
            ESP esp = (ESP)module;
            this.settings.add(new Setting("Show HP", esp.isShowHealth()));
            this.settings.add(new Setting("3D Mode", esp.isMode3d()));
            this.settings.add(new Setting("Box width", esp.getBoxWidthMul(), 0.25f, 2.5f));
        }
        if (module instanceof MobESP) {
            MobESP mob = (MobESP)module;
            this.settings.add(new Setting("Mob range", mob.getMobRange(), 8.0f, 256.0f));
            this.settings.add(new Setting("Mob name tag", mob.isShowMobNameTag()));
            this.settings.add(new Setting("Mob HP bar", mob.isShowHealth()));
        }
        if (module instanceof NameTags) {
            this.settings.add(new Setting("Players", ((NameTags)module).isShowPlayers()));
        }
        if (module instanceof AutoClicker) {
            this.settings.add(new Setting("Min CPS", ((AutoClicker)module).getMinCps(), 1.0f, 30.0f));
            this.settings.add(new Setting("Max CPS", ((AutoClicker)module).getMaxCps(), 1.0f, 50.0f));
            this.settings.add(new Setting("Left Click", ((AutoClicker)module).isLeftClick()));
            this.settings.add(new Setting("Right Click", ((AutoClicker)module).isRightClick()));
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        String bindText;
        this.hovered = mouseX > this.x && mouseX < this.x + this.width && mouseY > this.y && mouseY < this.y + this.height;
        int baseColor = this.module.isEnabled() ? -1440077270 : -1726079458;
        int hoverColor = this.module.isEnabled() ? -868599238 : -1439814098;
        int color = this.hovered ? hoverColor : baseColor;
        Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, color);
        int accentColor = ThemeManager.isRgbMode() ? ThemeManager.getRGBColor() : ThemeManager.getCurrentTheme().getAccentColor().getRGB();
        int indicatorColor = this.module.isEnabled() ? accentColor : -12303292;
        Gui.drawRect(this.x, this.y, this.x + 3, this.y + this.height, indicatorColor);
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        String displayName = this.module.getName();
        if (!this.settings.isEmpty()) {
            displayName = (this.settingsOpen ? "\u25bc " : "\u25b6 ") + displayName;
        }
        int nameColor = this.module.isEnabled() ? -1 : -5592406;
        fr.drawStringWithShadow(displayName, this.x + 8, this.y + (this.height / 2 - fr.FONT_HEIGHT / 2), nameColor);
        String string = bindText = this.module.getBind() == 0 ? "" : "[" + this.module.getBindName() + "]";
        if (!bindText.isEmpty()) {
            int bindWidth = fr.getStringWidth(bindText);
            fr.drawStringWithShadow(bindText, this.x + this.width - bindWidth - 6, this.y + (this.height / 2 - fr.FONT_HEIGHT / 2), -7829368);
        }
        Gui.drawRect(this.x, this.y + this.height - 1, this.x + this.width, this.y + this.height, 0x33111111);
        if (this.settingsOpen) {
            this.drawSettings(mouseX, mouseY, fr);
        }
        if (this.draggingSlider && this.activeSlider >= 0 && this.activeSlider < this.settings.size()) {
            this.updateSliderValue(this.settings.get(this.activeSlider), mouseX);
        }
    }

    private void drawSettings(int mouseX, int mouseY, FontRenderer fr) {
        int settingY = this.y + this.height;
        for (int i = 0; i < this.settings.size(); ++i) {
            String text;
            Setting setting = this.settings.get(i);
            boolean hover = mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= settingY && mouseY <= settingY + 18;
            int bgColor = hover ? -1439485133 : -2010634200;
            Gui.drawRect(this.x, settingY, this.x + this.width, settingY + 18, bgColor);
            if (setting.getType() == Setting.SettingType.SLIDER) {
                text = setting.getName() + ": ";
                String valueText = String.format("%.1f", Float.valueOf(setting.getValue()));
                fr.drawStringWithShadow(text, this.x + 8, settingY + 5, -5592406);
                fr.drawStringWithShadow(valueText, this.x + 8 + fr.getStringWidth(text), settingY + 5, -1);
                int sliderX = this.x + 8;
                int sliderY = settingY + 13;
                int sliderWidth = this.width - 16;
                float percent = (setting.getValue() - setting.getMin()) / (setting.getMax() - setting.getMin());
                int fillWidth = (int)((float)sliderWidth * Math.max(0.0f, Math.min(1.0f, percent)));
                Gui.drawRect(sliderX, sliderY, sliderX + sliderWidth, sliderY + 2, -12303292);
                int fillColor = ThemeManager.isRgbMode() ? ThemeManager.getRGBColor() : ThemeManager.getCurrentTheme().getAccentColor().getRGB();
                Gui.drawRect(sliderX, sliderY, sliderX + fillWidth, sliderY + 2, fillColor);
                int knobX = sliderX + fillWidth - 2;
                Gui.drawRect(knobX, sliderY - 2, knobX + 4, sliderY + 4, -1);
            } else if (setting.getType() == Setting.SettingType.CHECKBOX) {
                text = setting.getName() + ": ";
                fr.drawStringWithShadow(text, this.x + 8, settingY + 5, -5592406);
                boolean value = setting.getBoolValue();
                String status = value ? "ON" : "OFF";
                int statusColor = value ? -11141291 : -43691;
                fr.drawStringWithShadow(status, this.x + 8 + fr.getStringWidth(text), settingY + 5, statusColor);
            }
            settingY += 18;
        }
        int bindY = this.y + this.height + this.settings.size() * 18;
        boolean hoverBind = mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= bindY && mouseY <= bindY + 20;
        int bindBg = hoverBind ? -1439485133 : -2010634200;
        Gui.drawRect(this.x, bindY, this.x + this.width, bindY + 20, bindBg);
        if (SwillClient.instance != null && SwillClient.instance.isBindingMode() && SwillClient.instance.getBindingModule() == this.module) {
            String bindText = "Press any key... ESC to cancel";
            fr.drawStringWithShadow(bindText, this.x + 8, bindY + 6, -154);
        } else {
            String bindText = "Bind: " + this.module.getBindName();
            fr.drawStringWithShadow(bindText, this.x + 8, bindY + 6, -5592406);
            if (this.module.getBind() != 0) {
                fr.drawStringWithShadow("[RMB to clear]", this.x + this.width - 70, bindY + 6, -39322);
            }
        }
        Gui.drawRect(this.x, bindY + 19, this.x + this.width, bindY + 20, 0x33111111);
    }

    private void updateSliderValue(Setting setting, int mouseX) {
        int sliderX = this.x + 8;
        int sliderWidth = this.width - 16;
        float percent = (float)(mouseX - sliderX) / (float)sliderWidth;
        percent = Math.max(0.0f, Math.min(1.0f, percent));
        setting.setValue(setting.getMin() + percent * (setting.getMax() - setting.getMin()));
        this.applySetting(setting);
    }

    private void applySetting(Setting setting) {
        if (this.module instanceof AimBot) {
            AimBot aimBot = (AimBot)this.module;
            if (setting.getName().equals("FOV")) {
                aimBot.setFov(setting.getValue());
            }
            if (setting.getName().equals("Range")) {
                aimBot.setRange(setting.getValue());
            }
            if (setting.getName().equals("Smoothness")) {
                aimBot.setSmoothness(setting.getValue());
            }
            if (setting.getName().equals("Aim Height")) {
                aimBot.setAimHeight(setting.getValue());
            }
            if (setting.getName().equals("Draw FOV")) {
                aimBot.setDrawFov(setting.getBoolValue());
            }
        }
        if (this.module instanceof HUD) {
            // empty if block
        }
        if (this.module instanceof ItemESP) {
            ItemESP itemESP = (ItemESP)this.module;
            if (setting.getName().equals("Range")) {
                itemESP.setRange(setting.getValue());
            }
            if (setting.getName().equals("\u0422\u0435\u043a\u0441\u0442 (\u0440\u0430\u0437\u043c\u0435\u0440)")) {
                itemESP.setLabelScaleMul(setting.getValue());
            }
            if (setting.getName().equals("\u0414\u0430\u043b\u044c\u043d\u0438\u0439 \u0448\u0440\u0438\u0444\u0442")) {
                itemESP.setDistantFontBoost(setting.getValue());
            }
            if (setting.getName().equals("Draw Box")) {
                itemESP.setDrawBox(setting.getBoolValue());
            }
            if (setting.getName().equals("Draw Name")) {
                itemESP.setDrawName(setting.getBoolValue());
            }
            if (setting.getName().equals("Draw Distance")) {
                itemESP.setDrawDistance(setting.getBoolValue());
            }
        }
        if (this.module instanceof ESP) {
            ESP esp = (ESP)this.module;
            if (setting.getName().equals("Show HP")) {
                esp.setShowHealth(setting.getBoolValue());
            }
            if (setting.getName().equals("3D Mode")) {
                esp.setMode3d(setting.getBoolValue());
            }
            if (setting.getName().equals("Box width")) {
                esp.setBoxWidthMul(setting.getValue());
            }
        }
        if (this.module instanceof MobESP) {
            MobESP mob = (MobESP)this.module;
            if (setting.getName().equals("Mob range")) {
                mob.setMobRange(setting.getValue());
            }
            if (setting.getName().equals("Mob name tag")) {
                mob.setShowMobNameTag(setting.getBoolValue());
            }
            if (setting.getName().equals("Mob HP bar")) {
                mob.setShowHealth(setting.getBoolValue());
            }
        }
        if (this.module instanceof NameTags) {
            NameTags nameTags = (NameTags)this.module;
            if (setting.getName().equals("Players")) {
                nameTags.setShowPlayers(setting.getBoolValue());
            }
        }
        if (this.module instanceof AutoClicker) {
            AutoClicker autoClicker = (AutoClicker)this.module;
            if (setting.getName().equals("Min CPS")) {
                autoClicker.setMinCps((int)setting.getValue());
            }
            if (setting.getName().equals("Max CPS")) {
                autoClicker.setMaxCps((int)setting.getValue());
            }
            if (setting.getName().equals("Left Click")) {
                autoClicker.setLeftClick(setting.getBoolValue());
            }
            if (setting.getName().equals("Right Click")) {
                autoClicker.setRightClick(setting.getBoolValue());
            }
        }
    }

    public boolean mouseClicked(int mouseX, int mouseY, int button) {
        if (System.currentTimeMillis() - this.lastClickTime < 50L) {
            return false;
        }
        if (this.hovered && button == 2) {
            SwillClient.instance.startBinding(this.module);
            this.lastClickTime = System.currentTimeMillis();
            return true;
        }
        if (this.settingsOpen) {
            boolean hoveringBind;
            int settingY = this.y + this.height;
            for (int i = 0; i < this.settings.size(); ++i) {
                boolean hovering;
                Setting setting = this.settings.get(i);
                boolean bl = hovering = mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= settingY && mouseY <= settingY + 18;
                if (hovering) {
                    if (setting.getType() == Setting.SettingType.SLIDER && button == 0) {
                        this.draggingSlider = true;
                        this.activeSlider = i;
                        this.lastClickTime = System.currentTimeMillis();
                        return true;
                    }
                    if (setting.getType() == Setting.SettingType.CHECKBOX && button == 0) {
                        setting.setBoolValue(!setting.getBoolValue());
                        this.applySetting(setting);
                        this.lastClickTime = System.currentTimeMillis();
                        return true;
                    }
                }
                settingY += 18;
            }
            int bindY = this.y + this.height + this.settings.size() * 18;
            boolean bl = hoveringBind = mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= bindY && mouseY <= bindY + 20;
            if (hoveringBind) {
                if (button == 0 && SwillClient.instance != null) {
                    SwillClient.instance.startBinding(this.module);
                } else if (button == 1) {
                    this.module.setBind(0);
                }
                this.lastClickTime = System.currentTimeMillis();
                return true;
            }
        }
        if (this.hovered) {
            if (button == 0) {
                this.module.toggle();
                this.lastClickTime = System.currentTimeMillis();
            } else if (button == 1) {
                this.settingsOpen = !this.settingsOpen;
                this.lastClickTime = System.currentTimeMillis();
            }
            return true;
        }
        return false;
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.draggingSlider = false;
        this.activeSlider = -1;
    }

    public void mouseWheel(int wheel) {
        if (!this.settingsOpen) {
            return;
        }
        int settingY = this.y + this.height;
        for (int i = 0; i < this.settings.size(); ++i) {
            Setting setting = this.settings.get(i);
            if (setting.getType() == Setting.SettingType.SLIDER) {
                float step = (setting.getMax() - setting.getMin()) / 40.0f;
                float newValue = setting.getValue() + (wheel > 0 ? step : -step);
                newValue = Math.max(setting.getMin(), Math.min(setting.getMax(), newValue));
                setting.setValue(newValue);
                this.applySetting(setting);
            }
            settingY += 18;
        }
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
