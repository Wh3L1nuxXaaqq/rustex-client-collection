package swill.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;

public class BlackBackgroundMultiplayer
extends GuiMultiplayer {
    public BlackBackgroundMultiplayer(GuiScreen parent) {
        super(parent);
    }

    @Override
    public void initGui() {
        super.initGui();
        for (GuiButton btn : this.buttonList) {
            if (btn.id == 3) {
                btn.displayString = "add";
            }
            if (btn.id == 7) {
                btn.displayString = "edit";
            }
            if (btn.id != 2) continue;
            btn.displayString = "liv";
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        BlackBackgroundMultiplayer.drawRect(0, 0, this.width, this.height, -16777216);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
