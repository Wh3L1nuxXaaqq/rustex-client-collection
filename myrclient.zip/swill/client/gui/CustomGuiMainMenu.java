package swill.client.gui;

import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import swill.client.utils.FontManager;

public class CustomGuiMainMenu
extends GuiMainMenu {
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/title/minecraft.png"));
        int logoWidth = 256;
        int logoHeight = 44;
        int logoX = this.width / 2 - logoWidth / 2;
        int logoY = 30;
        this.drawTexturedModalRect(logoX, logoY, 0, 0, logoWidth, logoHeight);
        super.drawScreen(mouseX, mouseY, partialTicks);
        String text = "MyrClient v1.0";
        FontManager.drawString(text, 10, 10, 4886754);
    }
}
