package swill.client.modules.misc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;
import swill.client.modules.ModuleManager;
import swill.client.sound.ModSounds;

public class SoundNotification
extends Module {
    private final Setting sVolume = new Setting("Volume", 100.0f, 0.0f, 100.0f);
    private final Setting sDiffSounds = new Setting("DiffSounds", true);

    public SoundNotification() {
        super("SoundNotification", "Misc");
    }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> settings = new ArrayList<Setting>();
        settings.add(this.sVolume);
        settings.add(this.sDiffSounds);
        return settings;
    }

    @Override
    public void updateSetting(Setting setting) {
    }

    public static void playToggleSound(boolean enabled) {
        try {
            Module module = ModuleManager.getModuleByName("SoundNotification");
            if (!(module instanceof SoundNotification) || !module.isEnabled()) {
                return;
            }
            SoundNotification soundNotification = (SoundNotification)module;
            Minecraft mc = Minecraft.getMinecraft();
            if (mc == null || mc.getSoundHandler() == null) {
                return;
            }
            ResourceLocation sound = soundNotification.sDiffSounds.getBoolValue() && !enabled ? ModSounds.TOGGLE_OFF : ModSounds.TOGGLE_ON;
            mc.getSoundHandler().playSound(new PositionedSoundRecord(sound, SoundCategory.MASTER, Math.min(1.0f, soundNotification.sVolume.getValue() / 80.0f), 1.0f, false, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f));
        }
        catch (Exception e) {
            System.err.println("[SoundNotification] Failed to play custom sound: " + e.getMessage());
        }
    }
}
