package swill.client.modules.misc;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.Display;
import swill.client.gui.ClickGui;
import swill.client.modules.Module;
import swill.client.modules.ModuleManager;
import swill.client.utils.FontHook;
import swill.client.utils.GameLogger;
import swill.client.utils.LauncherFinder;

public class Panic
extends Module {
    private static boolean panicMode = false;
    private static String unlockCode = "";
    private static List<Module> savedModules = new ArrayList<Module>();
    private boolean firstLoad = true;
    private static final String HIDDEN_SUFFIX = "_hidden_tmp";
    private static final List<File> hiddenFiles = new ArrayList<File>();

    public Panic() {
        super("Panic", "Misc");
        this.setEnabled(false);
        panicMode = false;
        this.firstLoad = true;
    }

    @Override
    public void onEnable() {
        if (this.firstLoad) {
            this.firstLoad = false;
            this.setEnabled(false);
            return;
        }
        panicMode = true;
        savedModules.clear();
        hiddenFiles.clear();
        for (Module module : ModuleManager.getModules()) {
            if (module == this || !module.isEnabled()) continue;
            savedModules.add(module);
            module.setEnabled(false);
        }
        if (Minecraft.getMinecraft().currentScreen instanceof ClickGui) {
            Minecraft.getMinecraft().displayGuiScreen(null);
        }
        FontHook.removeHook();
        try {
            Display.setTitle((String)"Minecraft 1.12.2");
        }
        catch (Exception v1) {
            // empty catch block
        }
        Panic.hideCheatFiles();
        unlockCode = this.generateRandomCode();
        GameLogger.logPanicActivated(unlockCode);
        if (Minecraft.getMinecraft().player != null) {
            Minecraft.getMinecraft().player.addChatMessage(new TextComponentString((Object)((Object)TextFormatting.RED) + "!!! PANIC MODE ACTIVATED !!!"));
            Minecraft.getMinecraft().player.addChatMessage(new TextComponentString((Object)((Object)TextFormatting.GREEN) + "Type " + (Object)((Object)TextFormatting.YELLOW) + ".code " + unlockCode + (Object)((Object)TextFormatting.GREEN) + " to disable"));
        }
        this.clearChatDelayed(10000L);
    }

    @Override
    public void onDisable() {
    }

    private static void hideCheatFiles() {
        try {
            LauncherFinder.resetCache();
            File mcDir = LauncherFinder.getMinecraftDir();
            GameLogger.info("[Panic] Minecraft dir found: " + mcDir);
            GameLogger.info("[Panic] " + LauncherFinder.getDebugInfo());
            if (!mcDir.exists()) {
                GameLogger.warn("[Panic] Minecraft dir does not exist: " + mcDir);
                return;
            }
            File rpDir = new File(mcDir, "resourcepacks");
            if (rpDir.exists()) {
                GameLogger.info("[Panic] Scanning resourcepacks: " + rpDir);
                Panic.hideFilesInDir(rpDir, new String[]{"myr", "myrclient", "swill", "cheat", "hack", "client", "xray"});
            } else {
                GameLogger.warn("[Panic] resourcepacks folder not found in: " + mcDir);
            }
            Panic.hideDir(new File(mcDir, "swill"));
            Panic.hideDir(new File(mcDir, "MyrClient"));
            Panic.hideDir(new File(mcDir, "myrclient"));
            File logsDir = new File(mcDir, "logs");
            if (logsDir.exists()) {
                Panic.hideFilesInDir(logsDir, new String[]{"swill", "HujniaClient Leaked->https://t.me/logovo_vajbkodera", "cheat", "hack"});
            }
            GameLogger.info("[Panic] Hidden " + hiddenFiles.size() + " file(s)/folder(s)");
        }
        catch (Exception e) {
            GameLogger.error("[Panic] Error hiding files: " + e.getMessage());
        }
    }

    private static void restoreCheatFiles() {
        int restored = 0;
        for (File hidden : hiddenFiles) {
            try {
                if (!hidden.exists()) continue;
                String originalName = hidden.getName().replace(HIDDEN_SUFFIX, "");
                File original = new File(hidden.getParentFile(), originalName);
                if (!hidden.renameTo(original)) continue;
                ++restored;
                GameLogger.info("[Panic] Restored: " + original.getName());
            }
            catch (Exception e) {
                GameLogger.error("[Panic] Error restoring: " + hidden.getName());
            }
        }
        hiddenFiles.clear();
        GameLogger.info("[Panic] Restored " + restored + " file(s)/folder(s)");
    }

    private static void hideFilesInDir(File dir, String[] keywords) {
        if (!dir.exists() || !dir.isDirectory()) {
            return;
        }
        File[] files = dir.listFiles();
        if (files == null) {
            return;
        }
        block0: for (File f : files) {
            String nameLower = f.getName().toLowerCase();
            for (String kw : keywords) {
                if (!nameLower.contains(kw.toLowerCase())) continue;
                Panic.hideFile(f);
                continue block0;
            }
        }
    }

    private static void hideDir(File dir) {
        if (dir == null || !dir.exists()) {
            return;
        }
        Panic.hideFile(dir);
    }

    private static void hideFile(File f) {
        try {
            if (f.getName().endsWith(HIDDEN_SUFFIX)) {
                return;
            }
            File renamed = new File(f.getParentFile(), f.getName() + HIDDEN_SUFFIX);
            if (f.renameTo(renamed)) {
                hiddenFiles.add(renamed);
                GameLogger.info("[Panic] Hidden: " + f.getName() + " \u2192 " + renamed.getName());
            } else {
                GameLogger.warn("[Panic] Could not hide: " + f.getName());
            }
        }
        catch (Exception e) {
            GameLogger.error("[Panic] Error hiding " + f.getName() + ": " + e.getMessage());
        }
    }

    private void clearChatDelayed(long delay) {
        Timer timer = new Timer();
        timer.schedule(new TimerTask(){

            @Override
            public void run() {
                if (Minecraft.getMinecraft().ingameGUI != null) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().clearChatMessages(true);
                }
            }
        }, delay);
    }

    private String generateRandomCode() {
        Random random = new Random();
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 6; ++i) {
            code.append(chars.charAt(random.nextInt(chars.length())));
        }
        return code.toString();
    }

    public static boolean isPanicMode() {
        return panicMode;
    }

    public static boolean tryUnlock(String message) {
        String enteredCode;
        if (!panicMode) {
            return false;
        }
        String cleanMessage = message.trim();
        if (cleanMessage.toLowerCase().startsWith(".code ") && (enteredCode = cleanMessage.substring(6).trim()).equals(unlockCode)) {
            Panic.disablePanic();
            return true;
        }
        if (cleanMessage.equals(unlockCode)) {
            Panic.disablePanic();
            return true;
        }
        return false;
    }

    private static void disablePanic() {
        panicMode = false;
        GameLogger.logPanicDeactivated();
        try {
            Display.setTitle((String)"HujniaClient Leaked->https://t.me/logovo_vajbkodera");
        }
        catch (Exception v0) {
            // empty catch block
        }
        FontHook.restoreHook();
        Panic.restoreCheatFiles();
        for (Module module : savedModules) {
            if (module == null || module.isEnabled()) continue;
            module.setEnabled(true);
            GameLogger.info("Restored module: " + module.getName());
        }
        savedModules.clear();
        for (Module m : ModuleManager.getModules()) {
            if (m == null || !m.getName().equals("Panic") || !m.isEnabled()) continue;
            m.setEnabled(false);
            break;
        }
        if (Minecraft.getMinecraft().player != null) {
            Minecraft.getMinecraft().player.addChatMessage(new TextComponentString((Object)((Object)TextFormatting.GREEN) + "\u2713 Panic Mode Deactivated! All features restored."));
        }
        Panic.clearChatDelayedStatic(10000L);
    }

    private static void clearChatDelayedStatic(long delay) {
        Timer timer = new Timer();
        timer.schedule(new TimerTask(){

            @Override
            public void run() {
                if (Minecraft.getMinecraft().ingameGUI != null) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().clearChatMessages(true);
                }
            }
        }, delay);
    }

    public static String getUnlockCode() {
        return unlockCode;
    }
}
