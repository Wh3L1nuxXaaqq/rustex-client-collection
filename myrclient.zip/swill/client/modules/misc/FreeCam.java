package swill.client.modules.misc;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import org.lwjgl.input.Keyboard;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;

public class FreeCam
extends Module {
    private final Setting speed = new Setting("Speed", 0.3f, 0.05f, 2.0f);
    private final Minecraft mc = Minecraft.getMinecraft();
    private Entity savedRenderView;
    private CameraEntity cam;

    public FreeCam() {
        super("FreeCam", "Misc");
        this.addSetting(this.speed);
    }

    @Override
    public void onEnable() {
        if (this.mc.player == null) {
            return;
        }
        this.savedRenderView = this.mc.getRenderViewEntity();
        this.cam = new CameraEntity(this.mc);
        this.cam.setPositionAndRotation(this.mc.player.posX, this.mc.player.posY + (double)this.mc.player.getEyeHeight(), this.mc.player.posZ, this.mc.player.rotationYaw, this.mc.player.rotationPitch);
        this.mc.world.addEntityToWorld(-999, this.cam);
        this.mc.setRenderViewEntity(this.cam);
    }

    @Override
    public void onDisable() {
        if (this.savedRenderView != null) {
            this.mc.setRenderViewEntity(this.savedRenderView);
        }
        if (this.cam != null && this.mc.world != null) {
            this.mc.world.removeEntityFromWorld(-999);
            this.cam = null;
        }
        this.savedRenderView = null;
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled() || this.cam == null || this.mc.player == null) {
            return;
        }
        float sp = this.speed.getValue();
        float yaw = (float)Math.toRadians(this.cam.rotationYaw);
        float pitch = (float)Math.toRadians(this.cam.rotationPitch);
        double moveX = 0.0;
        double moveY = 0.0;
        double moveZ = 0.0;
        if (Keyboard.isKeyDown((int)17)) {
            moveX -= Math.sin(yaw) * Math.cos(pitch) * (double)sp;
            moveY -= Math.sin(pitch) * (double)sp;
            moveZ += Math.cos(yaw) * Math.cos(pitch) * (double)sp;
        }
        if (Keyboard.isKeyDown((int)31)) {
            moveX += Math.sin(yaw) * Math.cos(pitch) * (double)sp;
            moveY += Math.sin(pitch) * (double)sp;
            moveZ -= Math.cos(yaw) * Math.cos(pitch) * (double)sp;
        }
        if (Keyboard.isKeyDown((int)30)) {
            moveX -= Math.cos(yaw) * (double)sp;
            moveZ -= Math.sin(yaw) * (double)sp;
        }
        if (Keyboard.isKeyDown((int)32)) {
            moveX += Math.cos(yaw) * (double)sp;
            moveZ += Math.sin(yaw) * (double)sp;
        }
        if (Keyboard.isKeyDown((int)57)) {
            moveY += (double)sp;
        }
        if (Keyboard.isKeyDown((int)42)) {
            moveY -= (double)sp;
        }
        this.cam.setPosition(this.cam.posX + moveX, this.cam.posY + moveY, this.cam.posZ + moveZ);
        this.cam.rotationYaw = this.mc.player.rotationYaw;
        this.cam.rotationPitch = this.mc.player.rotationPitch;
    }

    public static class CameraEntity
    extends Entity {
        public CameraEntity(Minecraft mc) {
            super(mc.world);
            this.noClip = true;
            this.isImmuneToFire = true;
            this.preventEntitySpawning = true;
        }

        @Override
        protected void entityInit() {
        }

        @Override
        protected void readEntityFromNBT(NBTTagCompound nbt) {
        }

        @Override
        protected void writeEntityToNBT(NBTTagCompound nbt) {
        }
    }
}
