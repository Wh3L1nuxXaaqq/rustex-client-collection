package swill.client.modules.misc;

import swill.client.modules.Module;

public class AntiZoom
extends Module {
    public AntiZoom() {
        super("AntiZoom", "Misc");
    }
}
