package swill.client.modules.movement;

import swill.client.modules.Module;

public class Fly
extends Module {
    public Fly() {
        super("Fly", "Movement");
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mc.player == null) {
            return;
        }
        this.mc.player.capabilities.isFlying = true;
        this.mc.player.capabilities.setFlySpeed(0.1f);
    }

    @Override
    public void onDisable() {
        if (this.mc.player == null) {
            return;
        }
        this.mc.player.capabilities.isFlying = false;
        this.mc.player.capabilities.setFlySpeed(0.05f);
    }
}
