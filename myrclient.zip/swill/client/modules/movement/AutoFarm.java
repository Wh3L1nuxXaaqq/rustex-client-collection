package swill.client.modules.movement;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.util.EnumHand;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;

public class AutoFarm
extends Module {
    private float attackDelay = 10.0f;
    private float smoothness = 5.0f;
    private long lastAttackTime = 0L;
    private final List<Setting> settings = new ArrayList<Setting>();

    public AutoFarm() {
        super("AutoFarm", "Movement");
        this.settings.add(new Setting("AttackDelay", this.attackDelay, 1.0f, 20.0f));
        this.settings.add(new Setting("Smoothness", this.smoothness, 1.0f, 20.0f));
    }

    @Override
    public List<Setting> getSettings() {
        return this.settings;
    }

    @Override
    public void updateSetting(Setting setting) {
        switch (setting.getName()) {
            case "AttackDelay": {
                this.attackDelay = setting.getValue();
                break;
            }
            case "Smoothness": {
                this.smoothness = setting.getValue();
            }
        }
    }

    @Override
    public void onUpdate() {
        long delayMs;
        long now;
        if (this.mc.player == null || this.mc.world == null) {
            return;
        }
        EntityArmorStand target = this.findNearestArmorStand();
        if (target == null) {
            return;
        }
        double aimY = target.posY + 0.1;
        double dx = target.posX - this.mc.player.posX;
        double dy = aimY - (this.mc.player.posY + (double)this.mc.player.getEyeHeight());
        double dz = target.posZ - this.mc.player.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        float yawDiff = this.wrapDegrees(targetYaw - this.mc.player.rotationYaw);
        float pitchDiff = targetPitch - this.mc.player.rotationPitch;
        float step = Math.max(1.0f, this.smoothness * 0.5f);
        this.mc.player.rotationYaw += yawDiff / step;
        this.mc.player.rotationPitch += pitchDiff / step;
        if (this.mc.player.rotationPitch > 90.0f) {
            this.mc.player.rotationPitch = 90.0f;
        }
        if (this.mc.player.rotationPitch < -90.0f) {
            this.mc.player.rotationPitch = -90.0f;
        }
        if ((now = System.currentTimeMillis()) - this.lastAttackTime >= (delayMs = (long)(this.attackDelay * 50.0f))) {
            this.mc.playerController.attackEntity(this.mc.player, target);
            this.mc.player.swingArm(EnumHand.MAIN_HAND);
            this.lastAttackTime = now;
        }
    }

    private EntityArmorStand findNearestArmorStand() {
        EntityArmorStand nearest = null;
        double minDist = Double.MAX_VALUE;
        for (Entity e : this.mc.world.loadedEntityList) {
            double d;
            if (!(e instanceof EntityArmorStand) || !((d = this.mc.player.getDistanceSqToEntity(e)) < minDist) || !(d < 256.0)) continue;
            minDist = d;
            nearest = (EntityArmorStand)e;
        }
        return nearest;
    }

    private float wrapDegrees(float d) {
        if ((d %= 360.0f) >= 180.0f) {
            d -= 360.0f;
        }
        if (d < -180.0f) {
            d += 360.0f;
        }
        return d;
    }

    public float getAttackDelay() {
        return this.attackDelay;
    }

    public void setAttackDelay(float v) {
        this.attackDelay = v;
    }

    public float getSmoothness() {
        return this.smoothness;
    }

    public void setSmoothness(float v) {
        this.smoothness = v;
    }
}
