package swill.client.modules.visual;

import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import swill.client.modules.Module;

public class WallHack
extends Module {
    private List<Block> xrayBlocks;

    public WallHack() {
        super("WallHack", "Visual");
    }

    private void initXrayBlocks() {
        if (this.xrayBlocks != null) {
            return;
        }
        this.xrayBlocks = Arrays.asList(Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.GOLD_ORE, Blocks.IRON_ORE, Blocks.COAL_ORE, Blocks.LAPIS_ORE, Blocks.REDSTONE_ORE, Blocks.LIT_REDSTONE_ORE, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.MOB_SPAWNER, Blocks.OBSIDIAN);
    }

    @Override
    public void onEnable() {
        this.initXrayBlocks();
        if (this.mc.world != null) {
            this.mc.renderGlobal.loadRenderers();
        }
    }

    @Override
    public void onDisable() {
        if (this.mc.world != null) {
            this.mc.renderGlobal.loadRenderers();
        }
    }

    public boolean shouldRenderBlock(Block block) {
        if (!this.isEnabled()) {
            return true;
        }
        this.initXrayBlocks();
        return this.xrayBlocks.contains(block) || block == Blocks.AIR;
    }
}
