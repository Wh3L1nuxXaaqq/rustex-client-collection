package swill.client.modules.visual;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StringUtils;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;
import swill.client.modules.misc.Panic;
import swill.client.network.PacketHandler;
import swill.client.utils.FontManager;
import swill.client.utils.PlayerNameCache;

public class NameTags
extends Module {
    private DecimalFormat df = new DecimalFormat("#.#");
    private boolean showPlayers = true;
    private boolean showMobs = true;
    private float renderDistance = 256.0f;
    private float fontScale = 1.0f;
    private float bgOpacity = 0.85f;

    public NameTags() {
        super("NameTags", "Visual");
    }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> settings = new ArrayList<Setting>();
        settings.add(new Setting("Show Players", this.showPlayers));
        settings.add(new Setting("Show Mobs", this.showMobs));
        settings.add(new Setting("Render Distance", this.renderDistance, 10.0f, 512.0f));
        settings.add(new Setting("Mashtab", this.fontScale, 0.5f, 3.0f));
        settings.add(new Setting("BG Opacity", this.bgOpacity, 0.0f, 1.0f));
        return settings;
    }

    public boolean isShowPlayers() {
        return this.showPlayers;
    }

    public boolean isShowMobs() {
        return this.showMobs;
    }

    public void setShowPlayers(boolean showPlayers) {
        this.showPlayers = showPlayers;
    }

    public void setShowMobs(boolean showMobs) {
        this.showMobs = showMobs;
    }

    public void setRenderDistance(float distance) {
        this.renderDistance = distance;
    }

    public void setFontScale(float scale) {
        this.fontScale = scale;
    }

    public void setBgOpacity(float opacity) {
        this.bgOpacity = opacity;
    }

    public void renderNameTag(EntityPlayer player, float partialTicks) {
        if (!this.isEnabled()) {
            return;
        }
        if (!this.isShowPlayers()) {
            return;
        }
        if (Panic.isPanicMode()) {
            return;
        }
        if (player == null || player == this.mc.player) {
            return;
        }
        double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)partialTicks;
        double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)partialTicks;
        double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)partialTicks;
        x -= this.mc.getRenderManager().viewerPosX;
        y -= this.mc.getRenderManager().viewerPosY;
        z -= this.mc.getRenderManager().viewerPosZ;
        float distance = this.mc.player.getDistanceToEntity(player);
        if (distance > this.renderDistance) {
            return;
        }
        float scale = this.scaleFromDistance(distance) * this.fontScale;
        float nameRise = player.height + 0.6f;
        if (player.isSneaking()) {
            nameRise -= 0.3f;
        }
        GlStateManager.pushMatrix();
        GlStateManager.pushAttrib();
        GlStateManager.translate(x, y + (double)nameRise, z);
        GlStateManager.rotate(-this.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(this.mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-scale, -scale, scale);
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        String name = this.getRealPlayerName(player);
        if (name.equals("???")) {
            name = player.getGameProfile().getName();
        }
        name = StringUtils.stripControlCodes(name);
        String displayText = name + " " + this.df.format(distance) + "m";
        this.drawBillboardTag(displayText, player.getHealth(), player.getMaxHealth());
        this.renderArmorAndItems(player);
        GlStateManager.enableDepth();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.popAttrib();
        GlStateManager.popMatrix();
    }

    private String getRealPlayerName(EntityPlayer player) {
        if (player == null) {
            return "";
        }
        try {
            String vanillaName;
            Object skinName;
            String customName;
            String cachedName;
            UUID uuid = player.getUniqueID();
            int entityId = player.getEntityId();
            if (PlayerNameCache.hasRealNameByEntityId(entityId) && (cachedName = PlayerNameCache.getRealNameByEntityId(entityId)) != null && !cachedName.isEmpty() && !cachedName.equals("???")) {
                return cachedName;
            }
            if (player.hasCustomName() && !(customName = StringUtils.stripControlCodes(player.getCustomNameTag())).equalsIgnoreCase("Yeleha") && customName.length() >= 3) {
                return customName;
            }
            String dispName = StringUtils.stripControlCodes(player.getDisplayName().getUnformattedText());
            if (!dispName.equalsIgnoreCase("Yeleha") && !dispName.contains("Yeleha") && dispName.length() >= 3) {
                String[] parts = dispName.split(" ");
                String possibleName = parts[parts.length - 1];
                if (!possibleName.equalsIgnoreCase("Yeleha") && possibleName.length() >= 3) {
                    return possibleName;
                }
                return dispName;
            }
            if (uuid != null) {
                String cachedName2;
                if (PlayerNameCache.hasRealName(uuid) && (cachedName2 = PlayerNameCache.getRealName(uuid)) != null && !cachedName2.isEmpty() && !cachedName2.equals("???")) {
                    return cachedName2;
                }
                if (PacketHandler.hasRealName(uuid) && (cachedName2 = PacketHandler.getRealName(uuid)) != null && !cachedName2.isEmpty() && !cachedName2.equals("???")) {
                    return cachedName2;
                }
            }
            if (player.getGameProfile() != null && (skinName = PlayerNameCache.getNameFromSkinTextures(player.getGameProfile())) != null && !((String)skinName).isEmpty() && !((String)skinName).equals("???")) {
                PlayerNameCache.addRealName(entityId, uuid, (String)skinName);
                return skinName;
            }
            if (uuid != null && this.mc.getConnection() != null) {
                for (NetworkPlayerInfo info : this.mc.getConnection().getPlayerInfoMap()) {
                    String skinName2;
                    if (info.getGameProfile() == null || !uuid.equals(info.getGameProfile().getId()) || (skinName2 = PlayerNameCache.getNameFromSkinTextures(info.getGameProfile())) == null || skinName2.isEmpty() || skinName2.equals("???")) continue;
                    PlayerNameCache.addRealName(entityId, uuid, skinName2);
                    return skinName2;
                }
            }
            if (!(player.getGameProfile() == null || player.getGameProfile().getName() == null || (vanillaName = player.getGameProfile().getName()).equalsIgnoreCase("Yeleha") || vanillaName.equalsIgnoreCase("Player") || vanillaName.equalsIgnoreCase("Unknown") || vanillaName.length() < 3 || vanillaName.length() > 16)) {
                return vanillaName;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return "???";
    }

    public void renderMobNameTag(EntityLivingBase mob, float partialTicks) {
        if (!this.isEnabled()) {
            return;
        }
        if (Panic.isPanicMode()) {
            return;
        }
        if (mob == null || mob.isDead) {
            return;
        }
        if (mob instanceof EntityArmorStand) {
            return;
        }
        double x = mob.lastTickPosX + (mob.posX - mob.lastTickPosX) * (double)partialTicks;
        double y = mob.lastTickPosY + (mob.posY - mob.lastTickPosY) * (double)partialTicks;
        double z = mob.lastTickPosZ + (mob.posZ - mob.lastTickPosZ) * (double)partialTicks;
        x -= this.mc.getRenderManager().viewerPosX;
        y -= this.mc.getRenderManager().viewerPosY;
        z -= this.mc.getRenderManager().viewerPosZ;
        float distance = this.mc.player.getDistanceToEntity(mob);
        if (distance > this.renderDistance) {
            return;
        }
        float scale = this.scaleFromDistance(distance) * this.fontScale;
        String displayName = mob.hasCustomName() ? mob.getCustomNameTag() : mob.getDisplayName().getFormattedText();
        float fraction = mob.getHealth() / Math.max(mob.getMaxHealth(), 1.0E-4f);
        String nameColor = this.healthColorFraction(fraction);
        String hp = this.df.format(mob.getHealth()) + "/" + this.df.format(mob.getMaxHealth());
        String dst = this.df.format(distance) + "m";
        String displayText = nameColor + displayName + " \u00a77" + hp + " \u00a78" + dst;
        GlStateManager.pushMatrix();
        GlStateManager.pushAttrib();
        GlStateManager.translate(x, y + (double)mob.height + 0.35, z);
        GlStateManager.rotate(-this.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(this.mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-scale, -scale, scale);
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        this.drawBillboardTag(displayText, mob.getHealth(), mob.getMaxHealth());
        GlStateManager.enableDepth();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.popAttrib();
        GlStateManager.popMatrix();
    }

    private float scaleFromDistance(float distance) {
        float baseScale = 0.0018f;
        float factor = Math.max(1.0f, distance * 0.5f);
        return baseScale * factor;
    }

    private void renderArmorAndItems(EntityPlayer player) {
        ArrayList<ItemStack> items = new ArrayList<ItemStack>();
        for (int i = 3; i >= 0; --i) {
            ItemStack armor = player.inventory.armorInventory.get(i);
            if (armor == null) continue;
            items.add(armor);
        }
        if (player.getHeldItemMainhand() != null) {
            items.add(player.getHeldItemMainhand());
        }
        if (items.isEmpty()) {
            return;
        }
        int xOffset = -(items.size() * 16) / 2;
        int yOffset = -32;
        RenderHelper.enableGUIStandardItemLighting();
        for (ItemStack stack : items) {
            this.mc.getRenderItem().zLevel = -150.0f;
            this.mc.getRenderItem().renderItemAndEffectIntoGUI(stack, xOffset, yOffset);
            this.mc.getRenderItem().renderItemOverlays(this.mc.fontRendererObj, stack, xOffset, yOffset);
            this.mc.getRenderItem().zLevel = 0.0f;
            xOffset += 16;
        }
        RenderHelper.disableStandardItemLighting();
    }

    private String healthColorFraction(float hpFraction) {
        if (hpFraction > 0.66f) {
            return "\u00a7a";
        }
        if (hpFraction > 0.33f) {
            return "\u00a7e";
        }
        return "\u00a7c";
    }

    private void drawBillboardTag(String cleanText, float health, float maxHealth) {
        int b2;
        int g2;
        int r2;
        int b1;
        int g1;
        int r1;
        float f;
        int textWidth = FontManager.getStringWidthSmall(cleanText);
        int alpha = (int)(this.bgOpacity * 255.0f);
        int shadowColor = this.applyAlpha(0, alpha / 2);
        int x1 = -textWidth / 2 - 4;
        int y1 = -13;
        int x2 = textWidth / 2 + 4;
        int y2 = 2;
        this.drawRoundedBack(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 3, shadowColor);
        this.drawRoundedBack(x1, y1, x2, y2, 2, this.applyAlpha(0x202025, alpha));
        FontManager.drawStringSmall(cleanText, -textWidth / 2, -10, -1249289);
        float hpFraction = Math.max(0.0f, Math.min(1.0f, health / Math.max(1.0f, maxHealth)));
        int barW = x2 - x1;
        int hpW = (int)((float)barW * hpFraction);
        if (hpFraction > 0.5f) {
            f = (hpFraction - 0.5f) * 2.0f;
            r1 = 255;
            g1 = 255;
            b1 = 0;
            r2 = (int)(255.0f * (1.0f - f));
            g2 = 255;
            b2 = 0;
        } else {
            f = hpFraction * 2.0f;
            r1 = 255;
            g1 = 0;
            b1 = 0;
            r2 = 255;
            g2 = (int)(255.0f * f);
            b2 = 0;
        }
        int colorStart = 0xFF000000 | r1 << 16 | g1 << 8 | b1;
        int colorEnd = 0xFF000000 | r2 << 16 | g2 << 8 | b2;
        this.drawGradientRect(x1, y2 - 1, x1 + hpW, y2, colorStart, colorEnd);
    }

    private void drawRoundedBack(int x1, int y1, int x2, int y2, int r, int argb) {
        this.drawRectLocal(x1 + r, y1, x2 - r, y2, argb);
        this.drawRectLocal(x1, y1 + r, x2, y2 - r, argb);
        this.drawRectLocal(x1, y1, x1 + r, y1 + r, argb);
        this.drawRectLocal(x2 - r, y1, x2, y1 + r, argb);
        this.drawRectLocal(x1, y2 - r, x1 + r, y2, argb);
        this.drawRectLocal(x2 - r, y2 - r, x2, y2, argb);
    }

    private void drawGradientRect(int x, int y, int x2, int y2, int color1, int color2) {
        float a1 = (float)(color1 >> 24 & 0xFF) / 255.0f;
        float r1 = (float)(color1 >> 16 & 0xFF) / 255.0f;
        float g1 = (float)(color1 >> 8 & 0xFF) / 255.0f;
        float b1 = (float)(color1 & 0xFF) / 255.0f;
        float a2 = (float)(color2 >> 24 & 0xFF) / 255.0f;
        float r2 = (float)(color2 >> 16 & 0xFF) / 255.0f;
        float g2 = (float)(color2 >> 8 & 0xFF) / 255.0f;
        float b2 = (float)(color2 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bufferbuilder.pos(x2, y, 0.0).color(r1, g1, b1, a1).endVertex();
        bufferbuilder.pos(x, y, 0.0).color(r1, g1, b1, a1).endVertex();
        bufferbuilder.pos(x, y2, 0.0).color(r2, g2, b2, a2).endVertex();
        bufferbuilder.pos(x2, y2, 0.0).color(r2, g2, b2, a2).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private int applyAlpha(int argb, int alpha255) {
        return Math.min(255, Math.max(0, alpha255)) << 24 | argb & 0xFFFFFF;
    }

    private void drawRectLocal(int x, int y, int w, int h, int color) {
        int alpha = color >> 24 & 0xFF;
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color((float)r / 255.0f, (float)g / 255.0f, (float)b / 255.0f, (float)alpha / 255.0f);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(7, DefaultVertexFormats.POSITION);
        buffer.pos(x, h, 0.0).endVertex();
        buffer.pos(w, h, 0.0).endVertex();
        buffer.pos(w, y, 0.0).endVertex();
        buffer.pos(x, y, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }
}
