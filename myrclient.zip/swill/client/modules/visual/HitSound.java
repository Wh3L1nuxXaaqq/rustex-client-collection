package swill.client.modules.visual;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;
import swill.client.sound.ModSounds;

public class HitSound
extends Module {
    public static final String[] SOUND_NAMES = new String[]{"hit1", "hit2", "hit3"};
    public static final String[] SOUND_LABELS = new String[]{"Hit1", "Hit2", "Hit3"};
    private final Setting sSound1 = new Setting("Hit1", true);
    private final Setting sSound2 = new Setting("Hit2", false);
    private final Setting sSound3 = new Setting("Hit3", false);
    private final Setting sVolume = new Setting("Volume", 100.0f, 0.0f, 100.0f);
    private final Setting sPitch = new Setting("Pitch", 100.0f, 50.0f, 200.0f);
    private int selectedSound = 0;
    private int lastAttackedEntityId = -1;
    private long lastAttackTick = -1000L;

    public HitSound() {
        super("HitSound", "Visual");
    }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> settings = new ArrayList<Setting>();
        settings.add(this.sSound1);
        settings.add(this.sSound2);
        settings.add(this.sSound3);
        settings.add(this.sVolume);
        settings.add(this.sPitch);
        return settings;
    }

    @Override
    public void updateSetting(Setting setting) {
        if (setting == this.sSound1) {
            this.selectSound(0, true);
        } else if (setting == this.sSound2) {
            this.selectSound(1, true);
        } else if (setting == this.sSound3) {
            this.selectSound(2, true);
        }
    }

    public void onHit() {
        if (this.isEnabled()) {
            this.playCurrentSound();
        }
    }

    public void markAttack(EntityPlayer target) {
        if (target == null || this.mc.world == null) {
            return;
        }
        this.lastAttackedEntityId = target.getEntityId();
        this.lastAttackTick = this.mc.world.getTotalWorldTime();
    }

    public void onDamage(EntityPlayer target) {
        if (!this.isEnabled() || target == null || this.mc.world == null) {
            return;
        }
        long now = this.mc.world.getTotalWorldTime();
        if (target.getEntityId() == this.lastAttackedEntityId && now - this.lastAttackTick <= 20L) {
            this.lastAttackedEntityId = -1;
            this.playCurrentSound();
        }
    }

    public void playCurrentSound() {
        try {
            if (this.mc == null || this.mc.player == null || this.mc.getSoundHandler() == null) {
                return;
            }
            this.mc.getSoundHandler().playSound(new PositionedSoundRecord(this.getSelectedSound(), SoundCategory.MASTER, Math.min(1.0f, this.sVolume.getValue() / 80.0f), this.sPitch.getValue() / 100.0f, false, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f));
        }
        catch (Exception e) {
            System.err.println("[HitSound] Failed to play custom sound: " + e.getMessage());
        }
    }

    private ResourceLocation getSelectedSound() {
        switch (this.selectedSound) {
            case 1: {
                return ModSounds.HIT2;
            }
            case 2: {
                return ModSounds.HIT3;
            }
        }
        return ModSounds.HIT1;
    }

    private void selectSound(int index, boolean preview) {
        this.selectedSound = index;
        this.sSound1.setBoolValue(index == 0);
        this.sSound2.setBoolValue(index == 1);
        this.sSound3.setBoolValue(index == 2);
        if (preview) {
            this.playCurrentSound();
        }
    }
}
