package swill.client.modules.visual;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;

public class Crosshair
extends Module {
    private final Setting sWidth = new Setting("Width", 2.0f, 0.5f, 10.0f);
    private final Setting sLength = new Setting("Length", 8.0f, 2.0f, 30.0f);
    private final Setting sGap = new Setting("Gap", 4.0f, 0.0f, 20.0f);
    private final Setting sRed = new Setting("Red", 255.0f, 0.0f, 255.0f);
    private final Setting sGreen = new Setting("Green", 255.0f, 0.0f, 255.0f);
    private final Setting sBlue = new Setting("Blue", 255.0f, 0.0f, 255.0f);
    private final Setting sAlpha = new Setting("Alpha", 255.0f, 0.0f, 255.0f);
    private final Setting sRainbow = new Setting("Rainbow", false);
    private final Setting sRainbowSpeed = new Setting("RainbowSpeed", 1.0f, 0.1f, 5.0f);
    private final Setting sOutline = new Setting("Outline", false);
    private final Setting sDot = new Setting("Dot", false);
    private float hue = 0.0f;

    public Crosshair() {
        super("Crosshair", "Visual");
    }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> settings = new ArrayList<Setting>();
        settings.add(this.sWidth);
        settings.add(this.sLength);
        settings.add(this.sGap);
        settings.add(this.sRed);
        settings.add(this.sGreen);
        settings.add(this.sBlue);
        settings.add(this.sAlpha);
        settings.add(this.sRainbow);
        settings.add(this.sRainbowSpeed);
        settings.add(this.sOutline);
        settings.add(this.sDot);
        return settings;
    }

    @Override
    public void updateSetting(Setting s) {
    }

    @Override
    public void onEnable() {
        this.hue = 0.0f;
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        if (this.sRainbow.getBoolValue()) {
            float speed = this.sRainbowSpeed.getValue();
            this.hue += 5.0E-4f * speed;
            if (this.hue > 1.0f) {
                this.hue = 0.0f;
            }
        }
    }

    public void render() {
        if (!this.isEnabled()) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.player == null || mc.world == null || mc.gameSettings == null) {
            return;
        }
        if (mc.gameSettings.thirdPersonView != 0) {
            return;
        }
        ScaledResolution sr = new ScaledResolution(mc);
        float centerX = (float)sr.getScaledWidth() / 2.0f;
        float centerY = (float)sr.getScaledHeight() / 2.0f;
        float width = this.sWidth.getValue();
        float length = this.sLength.getValue();
        float gap = this.sGap.getValue();
        int color = this.getColor();
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        if (this.sOutline.getBoolValue()) {
            int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
            this.drawCrosshairLines(centerX, centerY, width + 1.0f, length + 1.0f, gap, outlineColor);
        }
        this.drawCrosshairLines(centerX, centerY, width, length, gap, color);
        if (this.sDot.getBoolValue()) {
            float dotSize = width;
            if (this.sOutline.getBoolValue()) {
                int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
                this.drawRect(centerX - dotSize - 0.5f, centerY - dotSize - 0.5f, centerX + dotSize + 0.5f, centerY + dotSize + 0.5f, outlineColor);
            }
            this.drawRect(centerX - dotSize, centerY - dotSize, centerX + dotSize, centerY + dotSize, color);
        }
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void drawCrosshairLines(float centerX, float centerY, float width, float length, float gap, int color) {
        float halfWidth = width / 2.0f;
        this.drawRect(centerX - halfWidth, centerY - gap - length, centerX + halfWidth, centerY - gap, color);
        this.drawRect(centerX - halfWidth, centerY + gap, centerX + halfWidth, centerY + gap + length, color);
        this.drawRect(centerX - gap - length, centerY - halfWidth, centerX - gap, centerY + halfWidth, color);
        this.drawRect(centerX + gap, centerY - halfWidth, centerX + gap + length, centerY + halfWidth, color);
    }

    private void drawRect(float left, float top, float right, float bottom, int color) {
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        GlStateManager.color(r, g, b, a);
        buffer.begin(7, DefaultVertexFormats.POSITION);
        buffer.pos(left, bottom, 0.0).endVertex();
        buffer.pos(right, bottom, 0.0).endVertex();
        buffer.pos(right, top, 0.0).endVertex();
        buffer.pos(left, top, 0.0).endVertex();
        tessellator.draw();
    }

    public void renderPreview(float centerX, float centerY, float scale) {
        float width = this.sWidth.getValue();
        float length = this.sLength.getValue();
        float gap = this.sGap.getValue();
        int color = this.getColor();
        GlStateManager.pushMatrix();
        GlStateManager.translate(centerX, centerY, 0.0f);
        GlStateManager.scale(scale, scale, scale);
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        if (this.sOutline.getBoolValue()) {
            int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
            this.drawCrosshairLines(0.0f, 0.0f, width + 1.0f, length + 1.0f, gap, outlineColor);
        }
        this.drawCrosshairLines(0.0f, 0.0f, width, length, gap, color);
        if (this.sDot.getBoolValue()) {
            float dotSize = width;
            if (this.sOutline.getBoolValue()) {
                int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
                this.drawRect(-dotSize - 0.5f, -dotSize - 0.5f, dotSize + 0.5f, dotSize + 0.5f, outlineColor);
            }
            this.drawRect(-dotSize, -dotSize, dotSize, dotSize, color);
        }
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private int getColor() {
        int alpha = (int)this.sAlpha.getValue();
        if (this.sRainbow.getBoolValue()) {
            float[] rgb = this.hueToRGB(this.hue);
            return alpha << 24 | (int)(rgb[0] * 255.0f) << 16 | (int)(rgb[1] * 255.0f) << 8 | (int)(rgb[2] * 255.0f);
        }
        int r = (int)this.sRed.getValue();
        int g = (int)this.sGreen.getValue();
        int b = (int)this.sBlue.getValue();
        return alpha << 24 | r << 16 | g << 8 | b;
    }

    private void drawCircle(float centerX, float centerY, float radius, float thickness, int color, boolean outline) {
        int segments = 32;
        float angleStep = (float)(Math.PI * 2 / (double)segments);
        if (outline) {
            int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
            this.drawCircleOutline(centerX, centerY, radius, thickness + 1.0f, outlineColor, segments, angleStep);
        }
        this.drawCircleOutline(centerX, centerY, radius, thickness, color, segments, angleStep);
    }

    private void drawCircleOutline(float centerX, float centerY, float radius, float thickness, int color, int segments, float angleStep) {
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        GlStateManager.color(r, g, b, a);
        buffer.begin(7, DefaultVertexFormats.POSITION);
        for (int i = 0; i < segments; ++i) {
            float angle1 = (float)i * angleStep;
            float angle2 = (float)(i + 1) * angleStep;
            float x1 = centerX + (float)Math.cos(angle1) * radius;
            float y1 = centerY + (float)Math.sin(angle1) * radius;
            float x2 = centerX + (float)Math.cos(angle2) * radius;
            float y2 = centerY + (float)Math.sin(angle2) * radius;
            float nx1 = (float)Math.cos(angle1) * thickness;
            float ny1 = (float)Math.sin(angle1) * thickness;
            float nx2 = (float)Math.cos(angle2) * thickness;
            float ny2 = (float)Math.sin(angle2) * thickness;
            buffer.pos(x1 + nx1, y1 + ny1, 0.0).endVertex();
            buffer.pos(x2 + nx2, y2 + ny2, 0.0).endVertex();
            buffer.pos(x2 - nx2, y2 - ny2, 0.0).endVertex();
            buffer.pos(x1 - nx1, y1 - ny1, 0.0).endVertex();
        }
        tessellator.draw();
    }

    private void drawSquare(float centerX, float centerY, float size, float thickness, int color, boolean outline) {
        float halfSize = size / 2.0f;
        if (outline) {
            int outlineColor = 0xFF000000 | (int)this.sAlpha.getValue() << 24;
            this.drawRect(centerX - halfSize - thickness - 0.5f, centerY - halfSize - thickness - 0.5f, centerX + halfSize + thickness + 0.5f, centerY + halfSize + thickness + 0.5f, outlineColor);
        }
        this.drawRect(centerX - halfSize - thickness, centerY - halfSize - thickness, centerX + halfSize + thickness, centerY - halfSize, color);
        this.drawRect(centerX - halfSize - thickness, centerY + halfSize, centerX + halfSize + thickness, centerY + halfSize + thickness, color);
        this.drawRect(centerX - halfSize - thickness, centerY - halfSize, centerX - halfSize, centerY + halfSize, color);
        this.drawRect(centerX + halfSize, centerY - halfSize, centerX + halfSize + thickness, centerY + halfSize, color);
    }

    private float[] hueToRGB(float hue) {
        float h = hue * 6.0f;
        int i = (int)Math.floor(h);
        float f = h - (float)i;
        float q = 1.0f - f;
        switch (i % 6) {
            case 0: {
                return new float[]{1.0f, f, 0.0f};
            }
            case 1: {
                return new float[]{q, 1.0f, 0.0f};
            }
            case 2: {
                return new float[]{0.0f, 1.0f, f};
            }
            case 3: {
                return new float[]{0.0f, q, 1.0f};
            }
            case 4: {
                return new float[]{f, 0.0f, 1.0f};
            }
            case 5: {
                return new float[]{1.0f, 0.0f, q};
            }
        }
        return new float[]{1.0f, 1.0f, 1.0f};
    }
}
