package swill.client.modules.visual;

import net.minecraft.client.Minecraft;
import swill.client.Components.settings.Setting;
import swill.client.modules.Module;
import swill.client.modules.ModuleManager;

public class WorldTime
extends Module {
    private final Setting timeValue = new Setting("Time", 6000.0f, 0.0f, 24000.0f);
    private final Setting locked = new Setting("Lock Time", true);
    private final Minecraft mc = Minecraft.getMinecraft();

    public WorldTime() {
        super("WorldTime", "Visual");
        this.addSetting(this.timeValue);
        this.addSetting(this.locked);
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mc.world == null) {
            return;
        }
        if (this.locked.getBoolValue()) {
            // empty if block
        }
    }

    public static long getOverriddenTime() {
        Module m = ModuleManager.getModuleByName("WorldTime");
        if (m instanceof WorldTime && m.isEnabled()) {
            WorldTime wt = (WorldTime)m;
            if (wt.locked.getBoolValue()) {
                return (long)wt.timeValue.getValue();
            }
        }
        return -1L;
    }
}
