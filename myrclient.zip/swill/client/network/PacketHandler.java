package swill.client.network;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketCloseWindow;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketSpawnPlayer;
import swill.client.modules.movement.GuiWalk;
import swill.client.utils.HealthTracker;
import swill.client.utils.PlayerNameCache;

public class PacketHandler
extends ChannelDuplexHandler {
    private static final Map<UUID, String> REAL_NAMES = new ConcurrentHashMap<UUID, String>();
    private static final List<String> NICKNAME_QUEUE = Collections.synchronizedList(new ArrayList());

    public void channelRead(ChannelHandlerContext ctx, Object packet) throws Exception {
        block14: {
            try {
                if (packet instanceof SPacketCloseWindow && GuiWalk.isModuleEnabled() && GuiWalk.isAntiCloseEnabled() && Minecraft.getMinecraft().currentScreen instanceof GuiContainer) {
                    return;
                }
                if (packet instanceof SPacketPlayerListItem) {
                    SPacketPlayerListItem listPacket = (SPacketPlayerListItem)packet;
                    for (SPacketPlayerListItem.AddPlayerData data : listPacket.getEntries()) {
                        if (data.getProfile() == null || data.getProfile().getId() == null) continue;
                        UUID uuid = data.getProfile().getId();
                        String skinName = PlayerNameCache.getNameFromSkinTextures(data.getProfile());
                        if (skinName == null || skinName.isEmpty()) continue;
                        REAL_NAMES.put(uuid, skinName);
                        if (listPacket.getAction() != SPacketPlayerListItem.Action.ADD_PLAYER) continue;
                        NICKNAME_QUEUE.add(skinName);
                    }
                }
                if (packet instanceof SPacketSpawnPlayer) {
                    SPacketSpawnPlayer spawnPacket = (SPacketSpawnPlayer)packet;
                    int entityId = spawnPacket.getEntityID();
                    UUID uuid = spawnPacket.getUniqueId();
                    String realName = REAL_NAMES.get(uuid);
                    if (realName != null) {
                        PlayerNameCache.addRealName(entityId, uuid, realName);
                    }
                }
                if (!(packet instanceof SPacketEntityMetadata)) break block14;
                SPacketEntityMetadata metaPacket = (SPacketEntityMetadata)packet;
                try {
                    Entity entity;
                    Minecraft mc = Minecraft.getMinecraft();
                    if (mc.world == null || !((entity = mc.world.getEntityByID(metaPacket.getEntityId())) instanceof EntityPlayer) || entity == mc.player) break block14;
                    EntityPlayer player = (EntityPlayer)entity;
                    Object dataField = null;
                    for (Field f : metaPacket.getClass().getDeclaredFields()) {
                        if (f.getType() != List.class) continue;
                        f.setAccessible(true);
                        List entries = (List)f.get(metaPacket);
                        if (entries != null) {
                            for (Object entry : entries) {
                                try {
                                    float hp;
                                    Method getValue = entry.getClass().getDeclaredMethod("getValue", new Class[0]);
                                    getValue.setAccessible(true);
                                    Object val = getValue.invoke(entry, new Object[0]);
                                    if (!(val instanceof Float) || !((hp = ((Float)val).floatValue()) >= 0.0f) || !(hp <= 1024.0f)) continue;
                                    HealthTracker.updateFromPacket(player.getUniqueID(), hp, player.getMaxHealth());
                                }
                                catch (Exception exception) {}
                            }
                        }
                        break;
                    }
                }
                catch (Exception exception) {
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        super.channelRead(ctx, packet);
    }

    private static void tryMatchNicknameToPlayer(String nickname) {
    }

    public static String getRealName(UUID uuid) {
        return REAL_NAMES.get(uuid);
    }

    public static void clearCache() {
        REAL_NAMES.clear();
        NICKNAME_QUEUE.clear();
    }

    public static boolean hasRealName(UUID uuid) {
        return REAL_NAMES.containsKey(uuid);
    }

    public static List<String> getNicknameQueue() {
        return new ArrayList<String>(NICKNAME_QUEUE);
    }
}
