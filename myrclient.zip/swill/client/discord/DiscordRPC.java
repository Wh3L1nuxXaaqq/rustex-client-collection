package swill.client.discord;

import java.io.RandomAccessFile;
import java.lang.management.ManagementFactory;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

public class DiscordRPC {
    private static final String APPLICATION_ID = "1505670832238887167";
    private static final AtomicBoolean running = new AtomicBoolean(false);
    private static final AtomicBoolean connected = new AtomicBoolean(false);
    private static ScheduledExecutorService scheduler = null;
    private static RandomAccessFile pipe = null;
    private static long startTimeSec = 0L;
    private static int nonce = 1;
    private static String lastSent = "";

    public static synchronized void init() {
        if (running.get()) {
            return;
        }
        running.set(true);
        startTimeSec = System.currentTimeMillis() / 1000L;
        lastSent = "";
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "DiscordRPC");
            t.setDaemon(true);
            return t;
        });
        scheduler.submit(DiscordRPC::tryConnect);
        System.out.println("[DiscordRPC] Initializing...");
    }

    public static synchronized void update() {
        if (!running.get() || scheduler == null || scheduler.isShutdown()) {
            return;
        }
        scheduler.submit(DiscordRPC::doUpdate);
    }

    public static synchronized void shutdown() {
        if (!running.get()) {
            return;
        }
        running.set(false);
        connected.set(false);
        DiscordRPC.closePipe();
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
        lastSent = "";
        System.out.println("[DiscordRPC] Shutdown");
    }

    public static boolean isConnected() {
        return connected.get();
    }

    private static void tryConnect() {
        if (!running.get()) {
            return;
        }
        for (int i = 0; i <= 9; ++i) {
            String pipePath = "\\\\.\\pipe\\discord-ipc-" + i;
            try {
                pipe = new RandomAccessFile(pipePath, "rw");
                String hsPayload = "{\"v\":1,\"client_id\":\"1505670832238887167\"}";
                DiscordRPC.writeFrame(0, hsPayload);
                byte[] resp = DiscordRPC.readFrame();
                if (resp != null) {
                    connected.set(true);
                    System.out.println("[DiscordRPC] Connected via " + pipePath);
                    DiscordRPC.doUpdate();
                }
                return;
            }
            catch (Exception ignored) {
                DiscordRPC.closePipe();
                continue;
            }
        }
        System.out.println("[DiscordRPC] Discord pipe not found \u2014 retry in 20s");
        DiscordRPC.scheduleReconnect(20);
    }

    private static void doUpdate() {
        if (!running.get()) {
            return;
        }
        if (!connected.get()) {
            DiscordRPC.tryConnect();
            return;
        }
        try {
            String details = DiscordRPC.buildDetails();
            String state = DiscordRPC.buildState();
            String key = details + "|" + state;
            if (key.equals(lastSent)) {
                return;
            }
            lastSent = key;
            String payload = "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + DiscordRPC.getPid() + ",\"activity\":{\"details\":\"" + DiscordRPC.esc(details) + "\",\"state\":\"" + DiscordRPC.esc(state) + "\",\"timestamps\":{\"start\":" + startTimeSec + "},\"assets\":{\"large_image\":\"myr_logo\",\"large_text\":\"MyrClient\",\"small_image\":\"minecraft_icon\",\"small_text\":\"Minecraft 1.12.2\"}}},\"nonce\":\"" + nonce++ + "\"}";
            DiscordRPC.writeFrame(1, payload);
            DiscordRPC.readFrame();
            System.out.println("[DiscordRPC] Updated: " + details);
        }
        catch (Exception e) {
            System.out.println("[DiscordRPC] Error sending presence: " + e.getMessage());
            connected.set(false);
            DiscordRPC.closePipe();
            DiscordRPC.scheduleReconnect(10);
        }
    }

    private static void scheduleReconnect(int delaySec) {
        if (!running.get() || scheduler == null || scheduler.isShutdown()) {
            return;
        }
        scheduler.schedule(DiscordRPC::tryConnect, (long)delaySec, TimeUnit.SECONDS);
    }

    private static String buildDetails() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.player == null) {
                return "In Menu";
            }
            String name = mc.player.getName();
            ServerData srv = mc.getCurrentServerData();
            if (srv != null) {
                String host = srv.serverName != null && !srv.serverName.isEmpty() ? srv.serverName : srv.serverIP;
                return name + " on " + host;
            }
            if (mc.isSingleplayer()) {
                return name + " \u2014 Singleplayer";
            }
            return name + " \u2014 Menu";
        }
        catch (Exception e) {
            return "Playing Minecraft";
        }
    }

    private static String buildState() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.player == null) {
                return "Idle";
            }
            int hp = (int)mc.player.getHealth();
            int food = mc.player.getFoodStats().getFoodLevel();
            return "HP: " + hp + "  Food: " + food;
        }
        catch (Exception e) {
            return "MyrClient";
        }
    }

    private static void writeFrame(int opcode, String payload) throws Exception {
        byte[] data = payload.getBytes(StandardCharsets.UTF_8);
        ByteBuffer buf = ByteBuffer.allocate(8 + data.length);
        buf.order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(opcode);
        buf.putInt(data.length);
        buf.put(data);
        pipe.write(buf.array());
    }

    private static byte[] readFrame() {
        try {
            byte[] header = new byte[8];
            if (pipe.read(header) < 8) {
                return null;
            }
            ByteBuffer buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
            buf.getInt();
            int len = buf.getInt();
            if (len <= 0 || len > 65536) {
                return null;
            }
            byte[] body = new byte[len];
            pipe.read(body);
            return body;
        }
        catch (Exception e) {
            return null;
        }
    }

    private static void closePipe() {
        try {
            if (pipe != null) {
                pipe.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        pipe = null;
    }

    private static int getPid() {
        try {
            String name = ManagementFactory.getRuntimeMXBean().getName();
            return Integer.parseInt(name.split("@")[0]);
        }
        catch (Exception e) {
            return 0;
        }
    }

    private static String esc(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", "");
    }
}
