package swill.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;
import swill.client.utils.CustomFontRenderer;
import swill.client.utils.FontManager;

public class FontHook {
    private static FontRenderer originalFont = null;
    private static PatchedFontRenderer proxy = null;
    private static boolean hooked = false;

    public static void installHook() {
        if (hooked) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc == null || mc.fontRendererObj == null) {
                return;
            }
            FontManager.initialize();
            if (!FontManager.canUseMikron()) {
                System.out.println("[FontHook] \u0428\u0440\u0438\u0444\u0442 \u043d\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d, \u0445\u0443\u043a \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u0442\u0441\u044f");
                return;
            }
            originalFont = mc.fontRendererObj;
            proxy = new PatchedFontRenderer(originalFont);
            mc.fontRendererObj = proxy;
            hooked = true;
            System.out.println("[FontHook] \u2713 \u0428\u0440\u0438\u0444\u0442 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d \u0433\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u043e");
        }
        catch (Exception e) {
            System.err.println("[FontHook] \u2717 \u041e\u0448\u0438\u0431\u043a\u0430: " + e.getMessage());
        }
    }

    public static void removeHook() {
        if (!hooked || originalFont == null) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc != null) {
                mc.fontRendererObj = originalFont;
                hooked = false;
                System.out.println("[FontHook] \u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 \u0448\u0440\u0438\u0444\u0442 (Panic)");
            }
        }
        catch (Exception e) {
            System.err.println("[FontHook] \u2717 removeHook: " + e.getMessage());
        }
    }

    public static void restoreHook() {
        if (hooked || proxy == null) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc != null) {
                mc.fontRendererObj = proxy;
                hooked = true;
                System.out.println("[FontHook] \u041a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0439 \u0448\u0440\u0438\u0444\u0442 \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d");
            }
        }
        catch (Exception e) {
            System.err.println("[FontHook] \u2717 restoreHook: " + e.getMessage());
        }
    }

    public static boolean isHooked() {
        return hooked;
    }

    public static FontRenderer getOriginalFont() {
        return originalFont;
    }

    public static class PatchedFontRenderer
    extends FontRenderer {
        private final FontRenderer orig;

        public PatchedFontRenderer(FontRenderer orig) {
            super(orig.getClass() == FontRenderer.class ? Minecraft.getMinecraft().gameSettings : Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
            this.orig = orig;
            this.FONT_HEIGHT = FontManager.canUseMikron() ? FontManager.getMikronFont().getFontHeight() : orig.FONT_HEIGHT;
        }

        private boolean use() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc != null && mc.ingameGUI != null) {
                StackTraceElement[] stack;
                for (StackTraceElement element : stack = Thread.currentThread().getStackTrace()) {
                    if (!element.getClassName().contains("GuiIngame")) continue;
                    return false;
                }
            }
            return FontManager.canUseMikron();
        }

        @Override
        public int drawString(String text, int x, int y, int color) {
            if (text == null) {
                return 0;
            }
            if (!this.use()) {
                return this.orig.drawString(text, x, y, color);
            }
            CustomFontRenderer f = FontManager.getMikronFont();
            f.drawStringNoShadow(text, x, y, PatchedFontRenderer.alpha(color));
            return x + f.getStringWidth(text);
        }

        @Override
        public int drawStringWithShadow(String text, float x, float y, int color) {
            if (text == null) {
                return 0;
            }
            if (!this.use()) {
                return this.orig.drawStringWithShadow(text, x, y, color);
            }
            CustomFontRenderer f = FontManager.getMikronFont();
            f.drawStringNoShadow(text, x, y, PatchedFontRenderer.alpha(color));
            return (int)(x + (float)f.getStringWidth(text));
        }

        @Override
        public int getStringWidth(String text) {
            if (text == null) {
                return 0;
            }
            if (!this.use()) {
                return this.orig.getStringWidth(text);
            }
            return FontManager.getMikronFont().getStringWidth(text);
        }

        @Override
        public int getCharWidth(char c) {
            if (!this.use()) {
                return this.orig.getCharWidth(c);
            }
            return FontManager.getMikronFont().getStringWidth(String.valueOf(c));
        }

        @Override
        public String trimStringToWidth(String t, int w) {
            return this.orig.trimStringToWidth(t, w);
        }

        @Override
        public String trimStringToWidth(String t, int w, boolean r) {
            return this.orig.trimStringToWidth(t, w, r);
        }

        @Override
        public void drawSplitString(String s, int x, int y, int ww, int c) {
            this.orig.drawSplitString(s, x, y, ww, c);
        }

        @Override
        public int splitStringWidth(String s, int m) {
            return this.orig.splitStringWidth(s, m);
        }

        @Override
        public boolean getUnicodeFlag() {
            return this.orig.getUnicodeFlag();
        }

        @Override
        public void setUnicodeFlag(boolean f) {
            this.orig.setUnicodeFlag(f);
        }

        @Override
        public boolean getBidiFlag() {
            return this.orig.getBidiFlag();
        }

        @Override
        public void setBidiFlag(boolean f) {
            this.orig.setBidiFlag(f);
        }

        private static int alpha(int c) {
            return (c >> 24 & 0xFF) == 0 ? c | 0xFF000000 : c;
        }
    }
}
