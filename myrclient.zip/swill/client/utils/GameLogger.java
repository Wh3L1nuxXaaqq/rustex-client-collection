package swill.client.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

public class GameLogger {
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");
    private static boolean initialized = false;

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        System.out.println("========================================");
        System.out.println("    MyrClient Console Logger v1.0");
        System.out.println("========================================");
        GameLogger.info("Logger initialized");
    }

    public static void info(String message) {
        GameLogger.log("INFO", message);
    }

    public static void warn(String message) {
        GameLogger.log("WARN", message);
    }

    public static void error(String message) {
        GameLogger.log("ERROR", message);
    }

    public static void debug(String message) {
        GameLogger.log("DEBUG", message);
    }

    private static void log(String level, String message) {
        String time = TIME_FORMAT.format(new Date());
        System.out.println(String.format("[%s] [%s] %s", time, level, message));
    }

    public static void logChat(String sender, String message) {
        GameLogger.info("CHAT | " + sender + ": " + message);
    }

    public static void logChatSent(String message) {
        GameLogger.info("CHAT SENT | " + message);
    }

    public static void logGuiOpen(String guiName) {
        GameLogger.info("GUI OPENED | " + guiName);
    }

    public static void logGuiClose(String guiName) {
        GameLogger.info("GUI CLOSED | " + guiName);
    }

    public static void logServerConnect(String serverIp, int port) {
        GameLogger.info("========================================");
        GameLogger.info("CONNECTING TO SERVER");
        GameLogger.info("Server: " + serverIp + ":" + port);
        GameLogger.info("========================================");
    }

    public static void logServerConnected() {
        GameLogger.info("========================================");
        GameLogger.info("CONNECTED TO SERVER");
        GameLogger.logCurrentServer();
        GameLogger.info("========================================");
    }

    public static void logServerDisconnect(String reason) {
        GameLogger.info("========================================");
        GameLogger.info("DISCONNECTED FROM SERVER");
        if (reason != null && !reason.isEmpty()) {
            GameLogger.info("Reason: " + reason);
        }
        GameLogger.info("========================================");
    }

    public static void logCurrentServer() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.getCurrentServerData() != null) {
                ServerData server = mc.getCurrentServerData();
                GameLogger.info("Server IP: " + server.serverIP);
                GameLogger.info("Server Name: " + server.serverName);
                GameLogger.info("Server MOTD: " + server.serverMOTD);
            } else if (mc.isSingleplayer()) {
                GameLogger.info("Mode: Singleplayer");
            } else {
                GameLogger.info("Mode: Unknown");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void logPlayerJoin(String playerName) {
        GameLogger.info("PLAYER JOIN | " + playerName);
    }

    public static void logPlayerLeave(String playerName) {
        GameLogger.info("PLAYER LEAVE | " + playerName);
    }

    public static void logRealNickDetected(int entityId, String uuid, String realNick) {
        GameLogger.info("REAL NICK DETECTED | EntityID: " + entityId + " | UUID: " + uuid + " | Nick: " + realNick);
    }

    public static void logModuleToggle(String moduleName, boolean enabled) {
        String state = enabled ? "ENABLED" : "DISABLED";
        GameLogger.info("MODULE " + state + " | " + moduleName);
    }

    public static void logConfigLoad(String configName) {
        GameLogger.info("CONFIG LOADED | " + configName);
    }

    public static void logConfigSave(String configName) {
        GameLogger.info("CONFIG SAVED | " + configName);
    }

    public static void logFriendAdd(String friendName) {
        GameLogger.info("FRIEND ADDED | " + friendName);
    }

    public static void logFriendRemove(String friendName) {
        GameLogger.info("FRIEND REMOVED | " + friendName);
    }

    public static void logPanicActivated(String unlockCode) {
        GameLogger.warn("========================================");
        GameLogger.warn("!!! PANIC MODE ACTIVATED !!!");
        GameLogger.warn("Unlock Code: " + unlockCode);
        GameLogger.warn("========================================");
    }

    public static void logPanicDeactivated() {
        GameLogger.info("========================================");
        GameLogger.info("PANIC MODE DEACTIVATED");
        GameLogger.info("All features restored");
        GameLogger.info("========================================");
    }

    public static void logPlayerInfo() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.player != null) {
                GameLogger.info("========================================");
                GameLogger.info("PLAYER INFO");
                GameLogger.info("Username: " + mc.player.getName());
                GameLogger.info("UUID: " + mc.player.getUniqueID().toString());
                GameLogger.info("Health: " + mc.player.getHealth() + "/" + mc.player.getMaxHealth());
                GameLogger.info("Position: X=" + (int)mc.player.posX + " Y=" + (int)mc.player.posY + " Z=" + (int)mc.player.posZ);
                GameLogger.info("========================================");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
