package swill.client.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

public class CustomFontRenderer {
    private static final Map<String, CustomFontRenderer> FONT_CACHE = new HashMap<String, CustomFontRenderer>();
    private static final int SCALE = 4;
    private static final int PAD_X = 8;
    private static final int PAD_Y = 8;
    private static final int[] CHAR_RANGES = new int[]{32, 255, 1025, 1105};
    private final Font awtFont;
    private final int fontSize;
    private final Map<Integer, CharData> charMap = new HashMap<Integer, CharData>();
    private int fontTextureId = -1;
    private int textureWidth = 2048;
    private int textureHeight = 2048;
    private int fontAscent = 0;
    private int fontHeight = 0;
    private boolean generated = false;
    private static final int[] MC_COLORS = new int[]{-16777216, -16777046, -16733696, -16733526, -5636096, -5635926, -22016, -5592406, -11184811, -11184641, -11141291, -11141121, -43691, -43521, -171, -1};

    public static CustomFontRenderer createSystem(String fontName, int screenSize) {
        String key = "sys_" + fontName + "_" + screenSize;
        if (FONT_CACHE.containsKey(key)) {
            return FONT_CACHE.get(key);
        }
        try {
            Font font = new Font(fontName, 0, screenSize * 4);
            if (font.getFamily().equalsIgnoreCase("Dialog") && !fontName.equalsIgnoreCase("Dialog")) {
                System.err.println("[CFR] System font not found: " + fontName);
                return null;
            }
            CustomFontRenderer r = new CustomFontRenderer(font, screenSize);
            FONT_CACHE.put(key, r);
            System.out.println("[CFR] \u2713 " + font.getFamily() + " screen=" + screenSize + "px");
            return r;
        }
        catch (Exception e) {
            System.err.println("[CFR] createSystem failed: " + e.getMessage());
            return null;
        }
    }

    public static CustomFontRenderer create(String fontPath, int screenSize) {
        String key = fontPath + "_" + screenSize;
        if (FONT_CACHE.containsKey(key)) {
            return FONT_CACHE.get(key);
        }
        try {
            InputStream stream = CustomFontRenderer.class.getClassLoader().getResourceAsStream("assets/myrclient/" + fontPath);
            if (stream == null) {
                System.err.println("[CFR] Not found: " + fontPath);
                return null;
            }
            Font base = Font.createFont(0, stream);
            Font derived = base.deriveFont(0, screenSize * 4);
            stream.close();
            CustomFontRenderer r = new CustomFontRenderer(derived, screenSize);
            FONT_CACHE.put(key, r);
            System.out.println("[CFR] \u2713 " + fontPath + " screen=" + screenSize + "px");
            return r;
        }
        catch (Exception e) {
            System.err.println("[CFR] create failed: " + e.getMessage());
            return null;
        }
    }

    private CustomFontRenderer(Font awtFont, int screenSize) {
        this.awtFont = awtFont;
        this.fontSize = screenSize;
    }

    private void ensureGenerated() {
        if (this.generated) {
            return;
        }
        this.generated = true;
        this.generateTexture();
    }

    private void generateTexture() {
        try {
            char c;
            BufferedImage tmp = new BufferedImage(1, 1, 2);
            Graphics2D tg = tmp.createGraphics();
            tg.setFont(this.awtFont);
            CustomFontRenderer.applyHints(tg);
            FontMetrics fm = tg.getFontMetrics();
            this.fontAscent = fm.getAscent();
            this.fontHeight = fm.getAscent() + fm.getDescent();
            tg.dispose();
            int padX = 8;
            int padY = 8;
            int cellH = fm.getAscent() + fm.getDescent() + padY * 2;
            int glyphH = fm.getAscent() + fm.getDescent();
            int posX = padX;
            int posY = padY;
            int rowH = 0;
            for (int ri = 0; ri < CHAR_RANGES.length; ri += 2) {
                int from = CHAR_RANGES[ri];
                int to = CHAR_RANGES[ri + 1];
                for (int cp = from; cp <= to; ++cp) {
                    c = (char)cp;
                    if (!this.awtFont.canDisplay(c)) continue;
                    int cw = fm.charWidth(c) + padX * 2;
                    if (cw <= padX * 2) {
                        cw = padX * 2 + 1;
                    }
                    if (posX + cw > this.textureWidth) {
                        posX = padX;
                        posY += rowH;
                        rowH = 0;
                    }
                    CharData d = new CharData();
                    d.x = posX;
                    d.y = posY;
                    d.width = cw;
                    d.height = cellH;
                    d.drawH = glyphH;
                    d.advance = fm.charWidth(c);
                    this.charMap.put(cp, d);
                    rowH = Math.max(rowH, cellH);
                    posX += cw;
                }
            }
            BufferedImage img = new BufferedImage(this.textureWidth, this.textureHeight, 2);
            Graphics2D g = img.createGraphics();
            g.setFont(this.awtFont);
            g.setColor(Color.WHITE);
            CustomFontRenderer.applyHints(g);
            for (Map.Entry<Integer, CharData> entry : this.charMap.entrySet()) {
                c = (char)entry.getKey().intValue();
                CharData d = entry.getValue();
                g.drawString(String.valueOf(c), d.x + padX, d.y + padY + this.fontAscent);
            }
            g.dispose();
            this.fontTextureId = CustomFontRenderer.uploadTexture(img);
            System.out.println("[CFR] \u2713 Texture " + this.textureWidth + "x" + this.textureHeight + " chars=" + this.charMap.size() + " screen=" + this.fontSize + "px");
        }
        catch (Exception e) {
            System.err.println("[CFR] generateTexture failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void applyHints(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    private static int uploadTexture(BufferedImage img) {
        int w = img.getWidth();
        int h = img.getHeight();
        int[] px = new int[w * h];
        img.getRGB(0, 0, w, h, px, 0, w);
        ByteBuffer buf = ByteBuffer.allocateDirect(px.length * 4);
        for (int p : px) {
            buf.put((byte)(p >> 16 & 0xFF));
            buf.put((byte)(p >> 8 & 0xFF));
            buf.put((byte)(p & 0xFF));
            buf.put((byte)(p >> 24 & 0xFF));
        }
        buf.flip();
        int id = GL11.glGenTextures();
        GL11.glBindTexture((int)3553, (int)id);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
        GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)w, (int)h, (int)0, (int)6408, (int)5121, (ByteBuffer)buf);
        GL11.glBindTexture((int)3553, (int)0);
        return id;
    }

    public void drawString(String text, float x, float y, int color) {
        this.ensureGenerated();
        if (this.fontTextureId == -1) {
            CustomFontRenderer.fallback().drawStringWithShadow(text, x, y, color);
            return;
        }
        this.renderTextFormatted(text, x, y, color, false);
    }

    public void drawStringNoShadow(String text, float x, float y, int color) {
        this.ensureGenerated();
        if (this.fontTextureId == -1) {
            CustomFontRenderer.fallback().drawString(text, (int)x, (int)y, color);
            return;
        }
        this.renderTextFormatted(text, x, y, color, false);
    }

    public int getStringWidth(String text) {
        this.ensureGenerated();
        if (this.fontTextureId == -1) {
            return CustomFontRenderer.fallback().getStringWidth(text);
        }
        float w = 0.0f;
        boolean skip = false;
        for (int i = 0; i < text.length(); ++i) {
            int cp = text.codePointAt(i);
            if (cp == 167) {
                skip = true;
                continue;
            }
            if (skip) {
                skip = false;
                continue;
            }
            CharData d = this.charMap.get(cp);
            if (d == null) continue;
            w += (float)d.advance / 4.0f;
        }
        return (int)Math.ceil(w);
    }

    public int getFontHeight() {
        CharData d = this.charMap.get(65);
        if (d != null) {
            return d.drawH / 4;
        }
        return this.fontHeight > 0 ? this.fontHeight / 4 : this.fontSize;
    }

    private void renderTextFormatted(String text, float x, float y, int baseColor, boolean shadowPass) {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.enableTexture2D();
        GlStateManager.bindTexture(this.fontTextureId);
        int currentColor = baseColor;
        float cx = x;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            int charLen = Character.charCount(cp);
            if (cp == 167 && i + charLen < text.length()) {
                int idx;
                char code = Character.toLowerCase(text.charAt(i + charLen));
                i += charLen + 1;
                if (code == 'r') {
                    currentColor = baseColor;
                    continue;
                }
                if (code >= '0' && code <= '9') {
                    idx = code - 48;
                    currentColor = shadowPass ? CustomFontRenderer.darken(MC_COLORS[idx]) : MC_COLORS[idx];
                    continue;
                }
                if (code < 'a' || code > 'f') continue;
                idx = code - 97 + 10;
                currentColor = shadowPass ? CustomFontRenderer.darken(MC_COLORS[idx]) : MC_COLORS[idx];
                continue;
            }
            CharData d = this.charMap.get(cp);
            if (d != null) {
                this.renderChar(cx, y, d, currentColor);
                cx += (float)d.advance / 4.0f;
            }
            i += charLen;
        }
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private static int darken(int color) {
        int a = color >> 24 & 0xFF;
        return a << 24 | (color >> 16 & 0xFF) / 4 << 16 | (color >> 8 & 0xFF) / 4 << 8 | (color & 0xFF) / 4;
    }

    private void renderChar(float x, float y, CharData d, int color) {
        int a = color >> 24 & 0xFF;
        if (a == 0) {
            a = 255;
        }
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.color(r, g, b, (float)a / 255.0f);
        float u1 = (float)(d.x + 8) / (float)this.textureWidth;
        float v1 = (float)(d.y + 8) / (float)this.textureHeight;
        float u2 = (float)(d.x + d.width - 8) / (float)this.textureWidth;
        float v2 = (float)(d.y + 8 + d.drawH) / (float)this.textureHeight;
        float rw = (float)(d.width - 16) / 4.0f;
        float rh = (float)d.drawH / 4.0f;
        float rx = x;
        float ry = y;
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(7, DefaultVertexFormats.POSITION_TEX);
        buf.pos(rx, ry + rh, 0.0).tex(u1, v2).endVertex();
        buf.pos(rx + rw, ry + rh, 0.0).tex(u2, v2).endVertex();
        buf.pos(rx + rw, ry, 0.0).tex(u2, v1).endVertex();
        buf.pos(rx, ry, 0.0).tex(u1, v1).endVertex();
        tess.draw();
    }

    private static FontRenderer fallback() {
        return Minecraft.getMinecraft().fontRendererObj;
    }

    public static void clearCache() {
        for (CustomFontRenderer f : FONT_CACHE.values()) {
            if (f.fontTextureId == -1) continue;
            GL11.glDeleteTextures((int)f.fontTextureId);
        }
        FONT_CACHE.clear();
    }

    private static class CharData {
        int x;
        int y;
        int width;
        int height;
        int drawH;
        int advance;

        private CharData() {
        }
    }
}
