package swill.client.utils;

import net.minecraft.client.Minecraft;
import swill.client.modules.misc.Panic;
import swill.client.utils.CustomFontRenderer;

public class FontManager {
    private static CustomFontRenderer fontNormal = null;
    private static CustomFontRenderer fontSmall = null;
    private static CustomFontRenderer fontIcons = null;
    private static boolean initialized = false;
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        try {
            fontNormal = CustomFontRenderer.create("fonts/main.otf", 10);
            fontSmall = CustomFontRenderer.create("fonts/main.otf", 8);
            fontIcons = CustomFontRenderer.create("fonts/nursultan.ttf", 16);
            if (fontNormal != null) {
                System.out.println("[FontManager] \u2713 Schiffbauer \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d (10/8px)");
            } else {
                System.err.println("[FontManager] \u2717 Schiffbauer \u043d\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d");
            }
        }
        catch (Exception e) {
            System.err.println("[FontManager] \u2717 \u041e\u0448\u0438\u0431\u043a\u0430: " + e.getMessage());
        }
    }

    private static boolean canUse() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontNormal != null && !FontManager.isPanic();
    }

    private static boolean canUseSmall() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontSmall != null && !FontManager.isPanic();
    }

    public static boolean canUseLarge() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontIcons != null && !FontManager.isPanic();
    }

    private static boolean isPanic() {
        try {
            return Panic.isPanicMode();
        }
        catch (Exception e) {
            return false;
        }
    }

    public static CustomFontRenderer getMikronFont() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontNormal;
    }

    public static CustomFontRenderer getMikronFontSmall() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontSmall;
    }

    public static CustomFontRenderer getLargeFont() {
        if (!initialized) {
            FontManager.initialize();
        }
        return fontIcons;
    }

    public static boolean canUseMikron() {
        return FontManager.canUse();
    }

    public static boolean canUseMikronSmall() {
        return FontManager.canUseSmall();
    }

    public static void drawString(String text, float x, float y, int color) {
        if (FontManager.canUse()) {
            fontNormal.drawStringNoShadow(text, x, y, color);
        } else {
            FontManager.mc.fontRendererObj.drawString(text, (int)x, (int)y, color);
        }
    }

    public static void drawString(String text, int x, int y, int color) {
        FontManager.drawString(text, (float)x, (float)y, color);
    }

    public static void drawStringSmall(String text, float x, float y, int color) {
        if (FontManager.canUseSmall()) {
            fontSmall.drawStringNoShadow(text, x, y, color);
        } else {
            FontManager.mc.fontRendererObj.drawString(text, (int)x, (int)y, color);
        }
    }

    public static void drawStringSmall(String text, int x, int y, int color) {
        FontManager.drawStringSmall(text, (float)x, (float)y, color);
    }

    public static void drawStringLarge(String text, float x, float y, int color) {
        if (FontManager.canUseLarge()) {
            fontIcons.drawStringNoShadow(text, x, y, color);
        } else {
            FontManager.mc.fontRendererObj.drawString(text, (int)x, (int)y, color);
        }
    }

    public static int getStringWidth(String text) {
        if (FontManager.canUse()) {
            return fontNormal.getStringWidth(text);
        }
        return FontManager.mc.fontRendererObj.getStringWidth(text);
    }

    public static int getStringWidthSmall(String text) {
        if (FontManager.canUseSmall()) {
            return fontSmall.getStringWidth(text);
        }
        return FontManager.mc.fontRendererObj.getStringWidth(text);
    }

    public static int getStringWidthLarge(String text) {
        if (FontManager.canUseLarge()) {
            return fontIcons.getStringWidth(text);
        }
        return FontManager.mc.fontRendererObj.getStringWidth(text);
    }

    public static int getFontHeight() {
        if (FontManager.canUse()) {
            return fontNormal.getFontHeight();
        }
        return FontManager.mc.fontRendererObj.FONT_HEIGHT;
    }

    public static void cleanup() {
        CustomFontRenderer.clearCache();
        fontNormal = null;
        fontSmall = null;
        fontIcons = null;
        initialized = false;
    }
}
