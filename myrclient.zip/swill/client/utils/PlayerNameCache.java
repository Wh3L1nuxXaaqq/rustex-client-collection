package swill.client.utils;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import swill.client.network.PacketHandler;

public class PlayerNameCache {
    private static final Map<UUID, String> REAL_NAMES_UUID = new ConcurrentHashMap<UUID, String>();
    private static final Map<Integer, String> REAL_NAMES_ENTITY_ID = new ConcurrentHashMap<Integer, String>();
    private static final Pattern[] CHAT_PATTERNS = new Pattern[]{Pattern.compile("\\[.*?\\]\\s*([a-zA-Z0-9_]{3,16})\\s*[>:]"), Pattern.compile("^([a-zA-Z0-9_]{3,16})\\s*[>:]"), Pattern.compile("^([a-zA-Z0-9_]{3,16})\\s*>"), Pattern.compile("([a-zA-Z0-9_]{3,16})\\s+(?:joined|left|quit|disconnected)"), Pattern.compile("([a-zA-Z0-9_]{3,16})\\s+(?:killed|\u0443\u0431\u0438\u043b|slain)"), Pattern.compile("([a-zA-Z0-9_]{3,16})\\s+(?:died|\u0443\u043c\u0435\u0440|\u043f\u043e\u0433\u0438\u0431)"), Pattern.compile("([a-zA-Z0-9_]{3,16})\\s+has\\s+made")};
    private static final Set<String> NAME_BLOCKLIST = new HashSet<String>(Arrays.asList("Given", "Give", "Set", "Teleported", "Kicked", "Banned", "Unbanned", "Opped", "Deopped", "Cleared", "Filled", "Killed", "Summoned", "Executed", "Added", "Removed", "Saved", "Loaded", "Reloaded", "Stopped", "Started", "Enabled", "Disabled", "Changed", "Updated", "Reset", "Deleted", "You", "Your", "The", "This", "That", "There", "These", "Those", "Player", "Players", "Someone", "Nobody", "Everyone", "Everybody", "Hello", "Welcome", "Goodbye", "Server", "Admin", "Staff", "Mod", "Warning", "Error", "Info", "Notice", "Alert", "Message", "Broadcast", "From", "To", "With", "For", "And", "But", "Not", "Has", "Have", "Now", "Just", "Only", "Also", "More", "Less", "New", "Old", "Igrok", "Igroki", "Server", "S\u0435\u0440\u0432\u0435\u0440", "Arrow", "Sword", "Pickaxe", "Diamond", "Iron", "Gold", "Stone", "Wood"));
    private static final Pattern SERVER_COMMAND_MSG = Pattern.compile("^(?:Given|Set|Teleported|Kicked|Banned|Cleared|Filled|Killed|Summoned|Added|Removed|Saved|Loaded|Reloaded|Opped|Deopped|Executed|Successfully|Unable|Cannot|Error|Warning|\\[).*", 2);

    public static void autoAssignNicknames() {
    }

    public static void processChatMessage(String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.world == null || mc.player == null) {
                return;
            }
            if (SERVER_COMMAND_MSG.matcher(message).matches()) {
                return;
            }
            HashSet<String> extractedNames = new HashSet<String>();
            for (Pattern pattern : CHAT_PATTERNS) {
                Matcher matcher = pattern.matcher(message);
                while (matcher.find()) {
                    String name = matcher.group(1);
                    if (name == null || !PlayerNameCache.isValidMinecraftName(name) || NAME_BLOCKLIST.contains(name)) continue;
                    extractedNames.add(name);
                }
            }
            if (extractedNames.isEmpty()) {
                return;
            }
            extractedNames.remove(mc.player.getName());
            if (extractedNames.isEmpty()) {
                return;
            }
            for (String extractedName : extractedNames) {
                PlayerNameCache.bindNameToPlayer(extractedName, mc);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void bindNameToPlayer(String finalName, Minecraft mc) {
        try {
            Entity exactMatch = null;
            Entity proximityMatch = null;
            float exactDist = Float.MAX_VALUE;
            float proximityDist = Float.MAX_VALUE;
            for (EntityPlayer player : mc.world.playerEntities) {
                float dist;
                if (player == mc.player || player.isDead || (dist = mc.player.getDistanceToEntity(player)) > 128.0f) continue;
                UUID uuid = player.getUniqueID();
                String vanillaName = null;
                if (player.getGameProfile() != null) {
                    vanillaName = player.getGameProfile().getName();
                }
                if (vanillaName != null && vanillaName.equalsIgnoreCase(finalName)) {
                    if (!(dist < exactDist)) continue;
                    exactDist = dist;
                    exactMatch = player;
                    continue;
                }
                boolean hasReliableName = PacketHandler.hasRealName(uuid);
                boolean alreadyBound = PlayerNameCache.hasRealNameByEntityId(player.getEntityId());
                if (hasReliableName || alreadyBound || !(dist < proximityDist)) continue;
                proximityDist = dist;
                proximityMatch = player;
            }
            if (exactMatch != null) {
                PlayerNameCache.addRealName(exactMatch.getEntityId(), exactMatch.getUniqueID(), finalName);
                System.out.println("[NameCache] Chat bind (vanilla match): " + finalName + " -> EntityID " + exactMatch.getEntityId() + " (dist=" + (int)exactDist + ")");
            } else if (proximityMatch != null && proximityDist <= 32.0f) {
                PlayerNameCache.addRealName(proximityMatch.getEntityId(), proximityMatch.getUniqueID(), finalName);
                System.out.println("[NameCache] Chat bind (proximity): " + finalName + " -> EntityID " + proximityMatch.getEntityId() + " (dist=" + (int)proximityDist + ")");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void addRealName(int entityId, UUID uuid, String realName) {
        if (realName != null && !realName.isEmpty()) {
            REAL_NAMES_ENTITY_ID.put(entityId, realName);
            if (uuid != null) {
                REAL_NAMES_UUID.put(uuid, realName);
            }
        }
    }

    public static String getRealNameByEntityId(int entityId) {
        return REAL_NAMES_ENTITY_ID.get(entityId);
    }

    public static String getRealName(UUID uuid) {
        return REAL_NAMES_UUID.get(uuid);
    }

    public static boolean hasRealNameByEntityId(int entityId) {
        return REAL_NAMES_ENTITY_ID.containsKey(entityId);
    }

    public static boolean hasRealName(UUID uuid) {
        return REAL_NAMES_UUID.containsKey(uuid);
    }

    public static void clear() {
        REAL_NAMES_UUID.clear();
        REAL_NAMES_ENTITY_ID.clear();
    }

    public static String getCacheInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== PlayerNameCache Info ===\n");
        sb.append("Total cached by EntityID: ").append(REAL_NAMES_ENTITY_ID.size()).append("\n");
        sb.append("Total cached by UUID: ").append(REAL_NAMES_UUID.size()).append("\n");
        if (!REAL_NAMES_ENTITY_ID.isEmpty()) {
            sb.append("\nBy EntityID:\n");
            for (Map.Entry<Integer, String> entry : REAL_NAMES_ENTITY_ID.entrySet()) {
                sb.append("  EntityID ").append(entry.getKey()).append(" -> ").append(entry.getValue()).append("\n");
            }
        }
        return sb.toString();
    }

    public static void removeByEntityId(int entityId) {
        REAL_NAMES_ENTITY_ID.remove(entityId);
    }

    private static boolean isValidMinecraftName(String name) {
        return name != null && name.length() >= 3 && name.length() <= 16 && name.matches("[a-zA-Z0-9_]+");
    }

    public static void updateFromPlayerList() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.getConnection() == null) {
                return;
            }
            for (NetworkPlayerInfo info : mc.getConnection().getPlayerInfoMap()) {
                EntityPlayer player;
                String skinName;
                UUID uuid;
                if (info.getGameProfile() == null || info.getGameProfile().getId() == null || PacketHandler.hasRealName(uuid = info.getGameProfile().getId()) || PlayerNameCache.hasRealName(uuid) || (skinName = PlayerNameCache.getNameFromSkinTextures(info.getGameProfile())) == null || skinName.isEmpty() || mc.world == null || (player = mc.world.getPlayerEntityByUUID(uuid)) == null) continue;
                PlayerNameCache.addRealName(player.getEntityId(), uuid, skinName);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static String getNameFromSkinTextures(GameProfile profile) {
        if (profile == null) {
            return null;
        }
        try {
            PropertyMap properties = profile.getProperties();
            if (properties != null && properties.containsKey((Object)"textures")) {
                for (Property property : properties.get((Object)"textures")) {
                    String value = property.getValue();
                    if (value == null || value.isEmpty()) continue;
                    byte[] decoded = Base64.getDecoder().decode(value);
                    String json = new String(decoded, StandardCharsets.UTF_8);
                    Pattern pattern = Pattern.compile("\"profileName\"\\s*:\\s*\"([a-zA-Z0-9_]{3,16})\"");
                    Matcher matcher = pattern.matcher(json);
                    if (!matcher.find()) continue;
                    return matcher.group(1);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }
}
