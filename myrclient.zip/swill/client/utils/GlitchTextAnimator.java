package swill.client.utils;

import java.util.Random;

public class GlitchTextAnimator {
    private final String targetText;
    private final Random random = new Random();
    private long lastUpdateTime = 0L;
    private int currentPosition = 0;
    private int glitchCounter = 0;
    private final int glitchesPerChar = 3;
    private final long updateDelay = 300L;
    private static final String GLITCH_CHARS = "!@#$%^&*|;:<>?/";
    private String currentDisplay = "";

    public GlitchTextAnimator(String text) {
        this.targetText = text;
        this.currentDisplay = "";
    }

    public void update() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastUpdateTime < 300L) {
            return;
        }
        this.lastUpdateTime = currentTime;
        if (this.currentPosition >= this.targetText.length()) {
            this.currentPosition = 0;
            this.glitchCounter = 0;
            this.currentDisplay = "";
            return;
        }
        if (this.glitchCounter < 3) {
            String printed = this.targetText.substring(0, this.currentPosition);
            char glitchChar = GLITCH_CHARS.charAt(this.random.nextInt(GLITCH_CHARS.length()));
            this.currentDisplay = printed + glitchChar;
            ++this.glitchCounter;
        } else {
            ++this.currentPosition;
            this.currentDisplay = this.targetText.substring(0, this.currentPosition);
            this.glitchCounter = 0;
        }
    }

    public String getCurrentText() {
        return this.currentDisplay;
    }

    public void reset() {
        this.currentPosition = 0;
        this.glitchCounter = 0;
        this.currentDisplay = "";
        this.lastUpdateTime = 0L;
    }

    public boolean isComplete() {
        return this.currentPosition >= this.targetText.length() && this.glitchCounter == 0;
    }

    public void setSpeed(long delayMs) {
    }
}
