package swill.client.utils;

public class TimerUtils {
    private long lastMS = this.getCurrentMS();

    public boolean hasReached(long milliseconds) {
        return this.getCurrentMS() - this.lastMS >= milliseconds;
    }

    public void reset() {
        this.lastMS = this.getCurrentMS();
    }

    public long getTime() {
        return this.getCurrentMS() - this.lastMS;
    }

    private long getCurrentMS() {
        return System.nanoTime() / 1000000L;
    }
}
