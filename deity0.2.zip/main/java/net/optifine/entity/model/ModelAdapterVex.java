package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelVex;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderVex;
import net.minecraft.entity.monster.EntityVex;
import optifine.Reflector;

public class ModelAdapterVex extends ModelAdapterBiped {
   public ModelAdapterVex() {
      super(EntityVex.class, "vex", 0.3F);
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelVex)) {
         return null;
      } else {
         ModelRenderer var3 = super.getModelRenderer(var1, var2);
         if (var3 != null) {
            return var3;
         } else {
            ModelVex var4 = (ModelVex)var1;
            if (var2.equals("left_wing")) {
               return (ModelRenderer)Reflector.getFieldValue(var4, Reflector.ModelVex_leftWing);
            } else {
               return var2.equals("right_wing") ? (ModelRenderer)Reflector.getFieldValue(var4, Reflector.ModelVex_rightWing) : null;
            }
         }
      }
   }

   public ModelBase makeModel() {
      return new ModelVex();
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderVex var4 = new RenderVex(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
