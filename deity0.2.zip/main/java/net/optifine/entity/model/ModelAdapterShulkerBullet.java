package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelShulkerBullet;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderShulkerBullet;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import optifine.Config;
import optifine.Reflector;

public class ModelAdapterShulkerBullet extends ModelAdapter {
   public ModelAdapterShulkerBullet() {
      super(EntityShulkerBullet.class, "shulker_bullet", 0.0F);
   }

   public ModelBase makeModel() {
      return new ModelShulkerBullet();
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelShulkerBullet)) {
         return null;
      } else {
         ModelShulkerBullet var3 = (ModelShulkerBullet)var1;
         return var2.equals("bullet") ? var3.renderer : null;
      }
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderShulkerBullet var4 = new RenderShulkerBullet(var3);
      if (!Reflector.RenderShulkerBullet_model.exists()) {
         Config.warn("Field not found: RenderShulkerBullet.model");
         return null;
      } else {
         Reflector.setFieldValue(var4, Reflector.RenderShulkerBullet_model, var1);
         var4.shadowSize = var2;
         return var4;
      }
   }
}
