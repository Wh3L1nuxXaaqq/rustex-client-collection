package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelArmorStand;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderArmorStand;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityArmorStand;

public class ModelAdapterArmorStand extends ModelAdapter {
   public ModelAdapterArmorStand() {
      super(EntityArmorStand.class, "armor_stand", 0.7F);
   }

   public ModelBase makeModel() {
      return new ModelArmorStand();
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelArmorStand)) {
         return null;
      } else {
         ModelArmorStand var3 = (ModelArmorStand)var1;
         if (var2.equals("right")) {
            return var3.standRightSide;
         } else if (var2.equals("left")) {
            return var3.standLeftSide;
         } else if (var2.equals("waist")) {
            return var3.standWaist;
         } else {
            return var2.equals("base") ? var3.standBase : null;
         }
      }
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderArmorStand var4 = new RenderArmorStand(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
