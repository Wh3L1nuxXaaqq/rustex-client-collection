package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import optifine.Config;

public class CustomModelRegistry {
   private static Map<String, ModelAdapter> mapModelAdapters = makeMapModelAdapters();

   private static Map<String, ModelAdapter> makeMapModelAdapters() {
      LinkedHashMap var0 = new LinkedHashMap();
      addModelAdapter(var0, new ModelAdapterArmorStand());
      addModelAdapter(var0, new ModelAdapterBat());
      addModelAdapter(var0, new ModelAdapterBlaze());
      addModelAdapter(var0, new ModelAdapterBoat());
      addModelAdapter(var0, new ModelAdapterCaveSpider());
      addModelAdapter(var0, new ModelAdapterChicken());
      addModelAdapter(var0, new ModelAdapterCow());
      addModelAdapter(var0, new ModelAdapterCreeper());
      addModelAdapter(var0, new ModelAdapterDragon());
      addModelAdapter(var0, new ModelAdapterDonkey());
      addModelAdapter(var0, new ModelAdapterEnderCrystal());
      addModelAdapter(var0, new ModelAdapterEnderCrystalNoBase());
      addModelAdapter(var0, new ModelAdapterEnderman());
      addModelAdapter(var0, new ModelAdapterEndermite());
      addModelAdapter(var0, new ModelAdapterEvoker());
      addModelAdapter(var0, new ModelAdapterEvokerFangs());
      addModelAdapter(var0, new ModelAdapterGhast());
      addModelAdapter(var0, new ModelAdapterGuardian());
      addModelAdapter(var0, new ModelAdapterHorse());
      addModelAdapter(var0, new ModelAdapterHusk());
      addModelAdapter(var0, new ModelAdapterIronGolem());
      addModelAdapter(var0, new ModelAdapterLeadKnot());
      addModelAdapter(var0, new ModelAdapterLlama());
      addModelAdapter(var0, new ModelAdapterMagmaCube());
      addModelAdapter(var0, new ModelAdapterMinecart());
      addModelAdapter(var0, new ModelAdapterMinecartTnt());
      addModelAdapter(var0, new ModelAdapterMinecartMobSpawner());
      addModelAdapter(var0, new ModelAdapterMooshroom());
      addModelAdapter(var0, new ModelAdapterMule());
      addModelAdapter(var0, new ModelAdapterOcelot());
      addModelAdapter(var0, new ModelAdapterPig());
      addModelAdapter(var0, new ModelAdapterPigZombie());
      addModelAdapter(var0, new ModelAdapterPolarBear());
      addModelAdapter(var0, new ModelAdapterRabbit());
      addModelAdapter(var0, new ModelAdapterSheep());
      addModelAdapter(var0, new ModelAdapterShulker());
      addModelAdapter(var0, new ModelAdapterShulkerBullet());
      addModelAdapter(var0, new ModelAdapterSilverfish());
      addModelAdapter(var0, new ModelAdapterSkeleton());
      addModelAdapter(var0, new ModelAdapterSkeletonHorse());
      addModelAdapter(var0, new ModelAdapterSlime());
      addModelAdapter(var0, new ModelAdapterSnowman());
      addModelAdapter(var0, new ModelAdapterSpider());
      addModelAdapter(var0, new ModelAdapterSquid());
      addModelAdapter(var0, new ModelAdapterStray());
      addModelAdapter(var0, new ModelAdapterVex());
      addModelAdapter(var0, new ModelAdapterVillager());
      addModelAdapter(var0, new ModelAdapterVindicator());
      addModelAdapter(var0, new ModelAdapterWitch());
      addModelAdapter(var0, new ModelAdapterWither());
      addModelAdapter(var0, new ModelAdapterWitherSkeleton());
      addModelAdapter(var0, new ModelAdapterWitherSkull());
      addModelAdapter(var0, new ModelAdapterWolf());
      addModelAdapter(var0, new ModelAdapterZombie());
      addModelAdapter(var0, new ModelAdapterZombieHorse());
      addModelAdapter(var0, new ModelAdapterZombieVillager());
      addModelAdapter(var0, new ModelAdapterSheepWool());
      addModelAdapter(var0, new ModelAdapterBanner());
      addModelAdapter(var0, new ModelAdapterBook());
      addModelAdapter(var0, new ModelAdapterChest());
      addModelAdapter(var0, new ModelAdapterChestLarge());
      addModelAdapter(var0, new ModelAdapterEnderChest());
      addModelAdapter(var0, new ModelAdapterHeadDragon());
      addModelAdapter(var0, new ModelAdapterHeadHumanoid());
      addModelAdapter(var0, new ModelAdapterHeadSkeleton());
      addModelAdapter(var0, new ModelAdapterShulkerBox());
      addModelAdapter(var0, new ModelAdapterSign());
      return var0;
   }

   private static void addModelAdapter(Map<String, ModelAdapter> var0, ModelAdapter var1) {
      if (var0.containsKey(var1.getName())) {
         Config.warn("Model adapter already registered for id: " + var1.getName() + ", class: " + var1.getEntityClass().getName());
      }

      var0.put(var1.getName(), var1);
   }

   public static ModelAdapter getModelAdapter(String var0) {
      return (ModelAdapter)mapModelAdapters.get(var0);
   }

   public static String[] getModelNames() {
      Set var0 = mapModelAdapters.keySet();
      String[] var1 = (String[])var0.toArray(new String[var0.size()]);
      return var1;
   }
}
