package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapter {
   private Class entityClass;
   private String name;
   private float shadowSize;

   public ModelAdapter(Class var1, String var2, float var3) {
      this.entityClass = var1;
      this.name = var2;
      this.shadowSize = var3;
   }

   public Class getEntityClass() {
      return this.entityClass;
   }

   public String getName() {
      return this.name;
   }

   public float getShadowSize() {
      return this.shadowSize;
   }

   public abstract ModelBase makeModel();

   public abstract ModelRenderer getModelRenderer(ModelBase var1, String var2);

   public abstract IEntityRenderer makeEntityRender(ModelBase var1, float var2);
}
