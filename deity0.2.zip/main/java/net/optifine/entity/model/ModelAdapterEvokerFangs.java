package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEvokerFangs;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderEvokerFangs;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import optifine.Config;
import optifine.Reflector;

public class ModelAdapterEvokerFangs extends ModelAdapter {
   public ModelAdapterEvokerFangs() {
      super(EntityEvokerFangs.class, "evocation_fangs", 0.0F);
   }

   public ModelBase makeModel() {
      return new ModelEvokerFangs();
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelEvokerFangs)) {
         return null;
      } else {
         ModelEvokerFangs var3 = (ModelEvokerFangs)var1;
         if (var2.equals("base")) {
            return (ModelRenderer)Reflector.getFieldValue(var3, Reflector.ModelEvokerFangs_ModelRenderers, 0);
         } else if (var2.equals("upper_jaw")) {
            return (ModelRenderer)Reflector.getFieldValue(var3, Reflector.ModelEvokerFangs_ModelRenderers, 1);
         } else {
            return var2.equals("lower_jaw") ? (ModelRenderer)Reflector.getFieldValue(var3, Reflector.ModelEvokerFangs_ModelRenderers, 2) : null;
         }
      }
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderEvokerFangs var4 = new RenderEvokerFangs(var3);
      if (!Reflector.RenderEvokerFangs_model.exists()) {
         Config.warn("Field not found: RenderEvokerFangs.model");
         return null;
      } else {
         Reflector.setFieldValue(var4, Reflector.RenderEvokerFangs_model, var1);
         var4.shadowSize = var2;
         return var4;
      }
   }
}
