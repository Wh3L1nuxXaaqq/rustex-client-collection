package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEnderCrystal;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import optifine.Config;
import optifine.Reflector;

public class ModelAdapterEnderCrystalNoBase extends ModelAdapterEnderCrystal {
   public ModelAdapterEnderCrystalNoBase() {
      super("end_crystal_no_base");
   }

   public ModelBase makeModel() {
      return new ModelEnderCrystal(0.0F, false);
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      Render var4 = (Render)var3.getEntityRenderMap().get(EntityEnderCrystal.class);
      if (!(var4 instanceof RenderEnderCrystal)) {
         Config.warn("Not an instance of RenderEnderCrystal: " + var4);
         return null;
      } else {
         RenderEnderCrystal var5 = (RenderEnderCrystal)var4;
         if (!Reflector.RenderEnderCrystal_modelEnderCrystalNoBase.exists()) {
            Config.warn("Field not found: RenderEnderCrystal.modelEnderCrystalNoBase");
            return null;
         } else {
            Reflector.setFieldValue(var5, Reflector.RenderEnderCrystal_modelEnderCrystalNoBase, var1);
            var5.shadowSize = var2;
            return var5;
         }
      }
   }
}
