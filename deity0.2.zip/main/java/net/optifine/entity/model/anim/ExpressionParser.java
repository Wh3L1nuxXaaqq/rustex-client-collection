package net.optifine.entity.model.anim;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import optifine.Config;

public class ExpressionParser {
   private IModelResolver modelResolver;

   public ExpressionParser(IModelResolver var1) {
      this.modelResolver = var1;
   }

   public IExpression parse(String var1) throws ParseException {
      try {
         Token[] var2 = TokenParser.parse(var1);
         if (var2 == null) {
            return null;
         } else {
            ArrayDeque var3 = new ArrayDeque(Arrays.asList(var2));
            return this.parseInfix(var3);
         }
      } catch (IOException var4) {
         throw new ParseException(var4.getMessage(), var4);
      }
   }

   private IExpression parseInfix(Deque<Token> var1) throws ParseException {
      if (var1.isEmpty()) {
         return null;
      } else {
         LinkedList var2 = new LinkedList();
         LinkedList var3 = new LinkedList();
         IExpression var4 = this.parseExpression(var1);
         checkNull(var4, "Missing expression");
         var2.add(var4);

         while(true) {
            Token var5 = (Token)var1.poll();
            if (var5 == null) {
               return this.makeInfix(var2, var3);
            }

            if (var5.getType() != EnumTokenType.OPERATOR) {
               throw new ParseException("Invalid operator: " + var5);
            }

            IExpression var6 = this.parseExpression(var1);
            checkNull(var6, "Missing expression");
            var3.add(var5);
            var2.add(var6);
         }
      }
   }

   private IExpression makeInfix(List<IExpression> var1, List<Token> var2) throws ParseException {
      LinkedList var3 = new LinkedList();

      for(Token var5 : var2) {
         EnumFunctionType var6 = EnumFunctionType.parse(var5.getText());
         checkNull(var6, "Invalid operator: " + var5);
         var3.add(var6);
      }

      return this.makeInfixFunc(var1, var3);
   }

   private IExpression makeInfixFunc(List<IExpression> var1, List<EnumFunctionType> var2) throws ParseException {
      if (var1.size() != var2.size() + 1) {
         throw new ParseException("Invalid infix expression, expressions: " + var1.size() + ", operators: " + var2.size());
      } else if (var1.size() == 1) {
         return (IExpression)var1.get(0);
      } else {
         int var3 = Integer.MAX_VALUE;
         int var4 = Integer.MIN_VALUE;

         for(EnumFunctionType var6 : var2) {
            var3 = Math.min(var6.getPrecedence(), var3);
            var4 = Math.max(var6.getPrecedence(), var4);
         }

         if (var4 >= var3 && var4 - var3 <= 10) {
            for(int var7 = var4; var7 >= var3; --var7) {
               this.mergeOperators(var1, var2, var7);
            }

            if (var1.size() == 1 && var2.size() == 0) {
               return (IExpression)var1.get(0);
            } else {
               throw new ParseException("Error merging operators, expressions: " + var1.size() + ", operators: " + var2.size());
            }
         } else {
            throw new ParseException("Invalid infix precedence, min: " + var3 + ", max: " + var4);
         }
      }
   }

   private void mergeOperators(List<IExpression> var1, List<EnumFunctionType> var2, int var3) {
      for(int var4 = 0; var4 < var2.size(); ++var4) {
         EnumFunctionType var5 = (EnumFunctionType)var2.get(var4);
         if (var5.getPrecedence() == var3) {
            var2.remove(var4);
            IExpression var6 = (IExpression)var1.remove(var4);
            IExpression var7 = (IExpression)var1.remove(var4);
            Function var8 = new Function(var5, new IExpression[]{var6, var7});
            var1.add(var4, var8);
            --var4;
         }
      }

   }

   private IExpression parseExpression(Deque<Token> var1) throws ParseException {
      Token var2 = (Token)var1.poll();
      checkNull(var2, "Missing expression");
      switch (var2.getType()) {
         case CONSTANT:
            return makeConstant(var2);
         case IDENTIFIER:
            EnumFunctionType var3 = this.getFunctionType(var2, var1);
            if (var3 != null) {
               return this.makeFunction(var3, var1);
            }

            return this.makeVariable(var2);
         case BRACKET_OPEN:
            return this.makeBracketed(var2, var1);
         case OPERATOR:
            EnumFunctionType var4 = EnumFunctionType.parse(var2.getText());
            checkNull(var4, "Invalid operator: " + var2);
            if (var4 == EnumFunctionType.PLUS) {
               return this.parseExpression(var1);
            } else if (var4 == EnumFunctionType.MINUS) {
               IExpression var5 = this.parseExpression(var1);
               return new Function(EnumFunctionType.NEG, new IExpression[]{var5});
            }
         default:
            throw new ParseException("Invalid expression: " + var2);
      }
   }

   private static IExpression makeConstant(Token var0) throws ParseException {
      float var1 = Config.parseFloat(var0.getText(), Float.NaN);
      if (var1 == Float.NaN) {
         throw new ParseException("Invalid float value: " + var0);
      } else {
         return new Constant(var1);
      }
   }

   private EnumFunctionType getFunctionType(Token var1, Deque<Token> var2) throws ParseException {
      Token var3 = (Token)var2.peek();
      if (var3 != null && var3.getType() == EnumTokenType.BRACKET_OPEN) {
         EnumFunctionType var5 = EnumFunctionType.parse(var3.getText());
         checkNull(var5, "Unknown function: " + var3);
         return var5;
      } else {
         EnumFunctionType var4 = EnumFunctionType.parse(var3.getText());
         if (var4 == null) {
            return null;
         } else if (var4.getCountArguments() > 0) {
            throw new ParseException("Missing arguments: " + var4);
         } else {
            return var4;
         }
      }
   }

   private IExpression makeFunction(EnumFunctionType var1, Deque<Token> var2) throws ParseException {
      if (var1.getCountArguments() == 0) {
         return makeFunction(var1, new IExpression[0]);
      } else {
         Token var3 = (Token)var2.poll();
         Deque var4 = getGroup(var2, EnumTokenType.BRACKET_CLOSE, true);
         IExpression[] var5 = this.parseExpressions(var4);
         return makeFunction(var1, var5);
      }
   }

   private IExpression[] parseExpressions(Deque<Token> var1) throws ParseException {
      ArrayList var2 = new ArrayList();

      while(true) {
         Deque var3 = getGroup(var1, EnumTokenType.COMMA, false);
         IExpression var4 = this.parseInfix(var3);
         if (var4 == null) {
            IExpression[] var5 = (IExpression[])var2.toArray(new IExpression[var2.size()]);
            return var5;
         }

         var2.add(var4);
      }
   }

   private static IExpression makeFunction(EnumFunctionType var0, IExpression[] var1) throws ParseException {
      if (var0.getCountArguments() != var1.length) {
         throw new ParseException("Invalid number of arguments: " + var1.length + ", should be: " + var0.getCountArguments() + ", function: " + var0.getName());
      } else {
         return new Function(var0, var1);
      }
   }

   private IExpression makeVariable(Token var1) throws ParseException {
      if (this.modelResolver == null) {
         throw new ParseException("Model variable not found: " + var1);
      } else {
         IExpression var2 = this.modelResolver.getExpression(var1.getText());
         if (var2 == null) {
            throw new ParseException("Model variable not found: " + var1);
         } else {
            return var2;
         }
      }
   }

   private IExpression makeBracketed(Token var1, Deque<Token> var2) throws ParseException {
      Deque var3 = getGroup(var2, EnumTokenType.BRACKET_CLOSE, true);
      return this.parseInfix(var3);
   }

   private static Deque<Token> getGroup(Deque<Token> var0, EnumTokenType var1, boolean var2) throws ParseException {
      ArrayDeque var3 = new ArrayDeque();
      int var4 = 0;
      Iterator var5 = var3.iterator();

      while(var5.hasNext()) {
         Token var6 = (Token)var5.next();
         var5.remove();
         if (var4 == 0 && var6.getType() == var1) {
            return var3;
         }

         var3.add(var6);
         if (var6.getType() == EnumTokenType.BRACKET_OPEN) {
            ++var4;
         }

         if (var6.getType() == EnumTokenType.BRACKET_CLOSE) {
            --var4;
         }
      }

      if (var2) {
         throw new ParseException("Missing end token: " + var1);
      } else {
         return var3;
      }
   }

   private static void checkNull(Object var0, String var1) throws ParseException {
      if (var0 == null) {
         throw new ParseException(var1);
      }
   }

   public static void main(String[] var0) throws Exception {
      ExpressionParser var1 = new ExpressionParser((IModelResolver)null);

      while(true) {
         try {
            InputStreamReader var2 = new InputStreamReader(System.in);
            BufferedReader var3 = new BufferedReader(var2);
            String var4 = var3.readLine();
            if (var4.length() <= 0) {
               return;
            }

            IExpression var5 = var1.parse(var4);
            float var6 = var5.eval();
            Config.dbg("" + var4 + " = " + var6);
         } catch (Exception var7) {
            var7.printStackTrace();
         }
      }
   }
}
