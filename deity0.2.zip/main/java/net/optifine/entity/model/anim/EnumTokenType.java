package net.optifine.entity.model.anim;

public enum EnumTokenType {
   IDENTIFIER("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", "0123456789_:."),
   CONSTANT("0123456789", "."),
   OPERATOR("+-*/%", 1),
   COMMA(",", 1),
   BRACKET_OPEN("(", 1),
   BRACKET_CLOSE(")", 1);

   private String charsFirst;
   private String charsExt;
   private int maxLen;
   public static final EnumTokenType[] VALUES = values();

   private EnumTokenType(String var3) {
      this.charsFirst = var3;
      this.charsExt = "";
   }

   private EnumTokenType(String var3, int var4) {
      this.charsFirst = var3;
      this.charsExt = "";
      this.maxLen = var4;
   }

   private EnumTokenType(String var3, String var4) {
      this.charsFirst = var3;
      this.charsExt = var4;
   }

   public String getCharsFirst() {
      return this.charsFirst;
   }

   public String getCharsExt() {
      return this.charsExt;
   }

   public static EnumTokenType getTypeByFirstChar(char var0) {
      for(int var1 = 0; var1 < VALUES.length; ++var1) {
         EnumTokenType var2 = VALUES[var1];
         if (var2.getCharsFirst().indexOf(var0) >= 0) {
            return var2;
         }
      }

      return null;
   }

   public boolean hasChar(char var1) {
      if (this.getCharsFirst().indexOf(var1) >= 0) {
         return true;
      } else {
         return this.getCharsExt().indexOf(var1) >= 0;
      }
   }

   public int getMaxLen() {
      return this.maxLen;
   }
}
