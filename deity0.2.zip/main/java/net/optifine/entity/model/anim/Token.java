package net.optifine.entity.model.anim;

public class Token {
   private EnumTokenType type;
   private String text;

   public Token(EnumTokenType var1, String var2) {
      this.type = var1;
      this.text = var2;
   }

   public EnumTokenType getType() {
      return this.type;
   }

   public String getText() {
      return this.text;
   }

   public String toString() {
      return this.text;
   }
}
