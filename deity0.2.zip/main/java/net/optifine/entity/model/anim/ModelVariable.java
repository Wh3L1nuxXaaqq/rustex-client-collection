package net.optifine.entity.model.anim;

import net.minecraft.client.model.ModelRenderer;

public class ModelVariable implements IExpression {
   private String name;
   private ModelRenderer modelRenderer;
   private EnumModelVariable enumModelVariable;

   public ModelVariable(String var1, ModelRenderer var2, EnumModelVariable var3) {
      this.name = var1;
      this.modelRenderer = var2;
      this.enumModelVariable = var3;
   }

   public float eval() {
      return this.getValue();
   }

   public float getValue() {
      return this.enumModelVariable.getFloat(this.modelRenderer);
   }

   public void setValue(float var1) {
      this.enumModelVariable.setFloat(this.modelRenderer, var1);
   }

   public String toString() {
      return this.name;
   }
}
