package net.optifine.entity.model.anim;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import optifine.Config;
import optifine.MathUtils;

public enum EnumFunctionType {
   PLUS("+", 2, 0),
   MINUS("-", 2, 0),
   MUL("*", 2, 1),
   DIV("/", 2, 1),
   MOD("%", 2, 1),
   NEG("neg", 1),
   PI("pi", 0),
   SIN("sin", 1),
   COS("cos", 1),
   TAN("tan", 1),
   ATAN("atan", 1),
   ATAN2("atan2", 2),
   TORAD("torad", 1),
   TODEG("todeg", 1),
   MIN("min", 2),
   MAX("max", 2),
   CLAMP("clamp", 3),
   ABS("abs", 1),
   FLOOR("floor", 1),
   CEIL("ceil", 1),
   FRAC("frac", 1),
   ROUND("round", 1),
   SQRT("sqrt", 1),
   FMOD("fmod", 2),
   TIME("time", 0);

   private String name;
   private int countArguments;
   private int precedence;
   public static EnumFunctionType[] VALUES = values();

   private EnumFunctionType(String var3, int var4) {
      this.name = var3;
      this.countArguments = var4;
   }

   private EnumFunctionType(String var3, int var4, int var5) {
      this.name = var3;
      this.countArguments = var4;
      this.precedence = var5;
   }

   public String getName() {
      return this.name;
   }

   public int getCountArguments() {
      return this.countArguments;
   }

   public int getPrecedence() {
      return this.precedence;
   }

   public float eval(IExpression[] var1) {
      if (var1.length != this.countArguments) {
         Config.warn("Invalid number of arguments, function: " + this + ", arguments: " + var1.length + ", should be: " + this.countArguments);
         return 0.0F;
      } else {
         switch (this) {
            case PLUS:
               return var1[0].eval() + var1[1].eval();
            case MINUS:
               return var1[0].eval() - var1[1].eval();
            case MUL:
               return var1[0].eval() * var1[1].eval();
            case DIV:
               return var1[0].eval() / var1[1].eval();
            case MOD:
               float var2 = var1[0].eval();
               float var3 = var1[1].eval();
               return var2 - var3 * (float)((int)(var2 / var3));
            case NEG:
               return -var1[0].eval();
            case PI:
               return (float)Math.PI;
            case SIN:
               return MathHelper.sin(var1[0].eval());
            case COS:
               return MathHelper.cos(var1[0].eval());
            case TAN:
               return (float)Math.tan((double)var1[0].eval());
            case ATAN:
               return (float)Math.atan((double)var1[0].eval());
            case ATAN2:
               return (float)MathHelper.atan2((double)var1[0].eval(), (double)var1[1].eval());
            case TORAD:
               return MathUtils.toRad(var1[0].eval());
            case TODEG:
               return MathUtils.toDeg(var1[0].eval());
            case MIN:
               return Math.min(var1[0].eval(), var1[1].eval());
            case MAX:
               return Math.max(var1[0].eval(), var1[1].eval());
            case CLAMP:
               return MathHelper.clamp(var1[0].eval(), var1[1].eval(), var1[2].eval());
            case ABS:
               return MathHelper.abs(var1[0].eval());
            case FLOOR:
               return (float)MathHelper.floor(var1[0].eval());
            case CEIL:
               return (float)MathHelper.ceil(var1[0].eval());
            case FRAC:
               return (float)MathHelper.frac((double)var1[0].eval());
            case ROUND:
               return (float)Math.round(var1[0].eval());
            case SQRT:
               return MathHelper.sqrt(var1[0].eval());
            case FMOD:
               float var4 = var1[0].eval();
               float var5 = var1[1].eval();
               return var4 - var5 * (float)MathHelper.floor(var4 / var5);
            case TIME:
               Minecraft var6 = Minecraft.getMinecraft();
               WorldClient var7 = var6.world;
               if (var7 == null) {
                  return 0.0F;
               }

               return (float)(((World)var7).getTotalWorldTime() % 24000L) + var6.getRenderPartialTicks();
            default:
               Config.warn("Unknown function type: " + this);
               return 0.0F;
         }
      }
   }

   public static EnumFunctionType parse(String var0) {
      for(int var1 = 0; var1 < VALUES.length; ++var1) {
         EnumFunctionType var2 = VALUES[var1];
         if (var2.getName().equals(var0)) {
            return var2;
         }
      }

      return null;
   }
}
