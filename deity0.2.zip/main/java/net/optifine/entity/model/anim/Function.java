package net.optifine.entity.model.anim;

public class Function implements IExpression {
   private EnumFunctionType enumFunction;
   private IExpression[] arguments;

   public Function(EnumFunctionType var1, IExpression[] var2) {
      this.enumFunction = var1;
      this.arguments = var2;
   }

   public float eval() {
      return this.enumFunction.eval(this.arguments);
   }

   public String toString() {
      return "" + this.enumFunction + "()";
   }
}
