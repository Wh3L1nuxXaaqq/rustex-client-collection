package net.optifine.entity.model.anim;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderManager;

public enum EnumRenderParameterEntity implements IExpression {
   LIMB_SWING("limb_swing"),
   LIMB_SWING_SPEED("limb_speed"),
   AGE("age"),
   HEAD_YAW("head_yaw"),
   HEAD_PITCH("head_pitch"),
   SCALE("scale");

   private String name;
   private RenderManager renderManager;
   private static final EnumRenderParameterEntity[] VALUES = values();

   private EnumRenderParameterEntity(String var3) {
      this.name = var3;
      this.renderManager = Minecraft.getMinecraft().getRenderManager();
   }

   public String getName() {
      return this.name;
   }

   public float eval() {
      Render var1 = this.renderManager.renderRender;
      if (var1 == null) {
         return 0.0F;
      } else {
         if (var1 instanceof RenderLivingBase) {
            RenderLivingBase var2 = (RenderLivingBase)var1;
            switch (this) {
               case LIMB_SWING:
                  return var2.renderLimbSwing;
               case LIMB_SWING_SPEED:
                  return var2.renderLimbSwingAmount;
               case AGE:
                  return var2.renderAgeInTicks;
               case HEAD_YAW:
                  return var2.renderHeadYaw;
               case HEAD_PITCH:
                  return var2.renderHeadPitch;
               case SCALE:
                  return var2.renderScaleFactor;
            }
         }

         return 0.0F;
      }
   }

   public static EnumRenderParameterEntity parse(String var0) {
      if (var0 == null) {
         return null;
      } else {
         for(int var1 = 0; var1 < VALUES.length; ++var1) {
            EnumRenderParameterEntity var2 = VALUES[var1];
            if (var2.getName().equals(var0)) {
               return var2;
            }
         }

         return null;
      }
   }
}
