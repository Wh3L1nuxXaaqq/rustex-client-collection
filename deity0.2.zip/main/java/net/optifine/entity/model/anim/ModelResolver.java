package net.optifine.entity.model.anim;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.tileentity.TileEntity;
import net.optifine.entity.model.CustomModelRenderer;
import net.optifine.entity.model.ModelAdapter;
import optifine.Config;

public class ModelResolver implements IModelResolver {
   private ModelAdapter modelAdapter;
   private ModelBase model;
   private CustomModelRenderer[] customModelRenderers;
   private ModelRenderer thisModelRenderer;
   private ModelRenderer partModelRenderer;
   private IRenderResolver renderResolver;

   public ModelResolver(ModelAdapter var1, ModelBase var2, CustomModelRenderer[] var3) {
      this.modelAdapter = var1;
      this.model = var2;
      this.customModelRenderers = var3;
      Class var4 = var1.getEntityClass();
      if (TileEntity.class.isAssignableFrom(var4)) {
         this.renderResolver = new RenderResolverTileEntity();
      } else {
         this.renderResolver = new RenderResolverEntity();
      }

   }

   public IExpression getExpression(String var1) {
      ModelVariable var2 = this.getModelVariable(var1);
      if (var2 != null) {
         return var2;
      } else {
         IExpression var3 = this.renderResolver.getParameter(var1);
         return var3 != null ? var3 : null;
      }
   }

   public ModelRenderer getModelRenderer(String var1) {
      if (var1 == null) {
         return null;
      } else if (var1.indexOf(":") >= 0) {
         String[] var7 = Config.tokenize(var1, ":");
         ModelRenderer var8 = this.getModelRenderer(var7[0]);

         for(int var9 = 1; var9 < var7.length; ++var9) {
            String var10 = var7[var9];
            ModelRenderer var11 = var8.getChildDeep(var10);
            if (var11 == null) {
               return null;
            }

            var8 = var11;
         }

         return var8;
      } else if (this.thisModelRenderer != null && var1.equals("this")) {
         return this.thisModelRenderer;
      } else if (this.partModelRenderer != null && var1.equals("part")) {
         return this.partModelRenderer;
      } else {
         ModelRenderer var2 = this.modelAdapter.getModelRenderer(this.model, var1);
         if (var2 != null) {
            return var2;
         } else {
            for(int var3 = 0; var3 < this.customModelRenderers.length; ++var3) {
               CustomModelRenderer var4 = this.customModelRenderers[var3];
               ModelRenderer var5 = var4.getModelRenderer();
               if (var1.equals(var5.getId())) {
                  return var5;
               }

               ModelRenderer var6 = var5.getChildDeep(var1);
               if (var6 != null) {
                  return var6;
               }
            }

            return null;
         }
      }
   }

   public ModelVariable getModelVariable(String var1) {
      String[] var2 = Config.tokenize(var1, ".");
      if (var2.length != 2) {
         return null;
      } else {
         String var3 = var2[0];
         String var4 = var2[1];
         ModelRenderer var5 = this.getModelRenderer(var3);
         if (var5 == null) {
            return null;
         } else {
            EnumModelVariable var6 = EnumModelVariable.parse(var4);
            return var6 == null ? null : new ModelVariable(var1, var5, var6);
         }
      }
   }

   public void setPartModelRenderer(ModelRenderer var1) {
      this.partModelRenderer = var1;
   }

   public void setThisModelRenderer(ModelRenderer var1) {
      this.thisModelRenderer = var1;
   }
}
