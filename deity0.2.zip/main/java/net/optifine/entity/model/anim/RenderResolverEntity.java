package net.optifine.entity.model.anim;

public class RenderResolverEntity implements IRenderResolver {
   public IExpression getParameter(String var1) {
      EnumRenderParameterEntity var2 = EnumRenderParameterEntity.parse(var1);
      return var2;
   }
}
