package net.optifine.entity.model.anim;

public class Constant implements IExpression {
   private float value;

   public Constant(float var1) {
      this.value = var1;
   }

   public float eval() {
      return this.value;
   }

   public String toString() {
      return "" + this.value;
   }
}
