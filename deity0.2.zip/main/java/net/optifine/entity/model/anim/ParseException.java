package net.optifine.entity.model.anim;

public class ParseException extends Exception {
   public ParseException(String var1, Throwable var2) {
      super(var1, var2);
   }

   public ParseException(String var1) {
      super(var1);
   }
}
