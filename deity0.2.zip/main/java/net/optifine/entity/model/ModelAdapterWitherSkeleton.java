package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelSkeleton;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWitherSkeleton;
import net.minecraft.entity.monster.EntityWitherSkeleton;

public class ModelAdapterWitherSkeleton extends ModelAdapterBiped {
   public ModelAdapterWitherSkeleton() {
      super(EntityWitherSkeleton.class, "wither_skeleton", 0.7F);
   }

   public ModelBase makeModel() {
      return new ModelSkeleton();
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderWitherSkeleton var4 = new RenderWitherSkeleton(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
