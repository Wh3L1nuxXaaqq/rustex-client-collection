package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelSkeleton;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderStray;
import net.minecraft.entity.monster.EntityStray;

public class ModelAdapterStray extends ModelAdapterBiped {
   public ModelAdapterStray() {
      super(EntityStray.class, "stray", 0.7F);
   }

   public ModelBase makeModel() {
      return new ModelSkeleton();
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderStray var4 = new RenderStray(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
