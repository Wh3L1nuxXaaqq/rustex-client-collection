package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelDragonHead;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySkullRenderer;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntitySkull;
import optifine.Config;
import optifine.Reflector;

public class ModelAdapterHeadDragon extends ModelAdapter {
   public ModelAdapterHeadDragon() {
      super(TileEntitySkull.class, "head_dragon", 0.0F);
   }

   public ModelBase makeModel() {
      return new ModelDragonHead(0.0F);
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelDragonHead)) {
         return null;
      } else {
         ModelDragonHead var3 = (ModelDragonHead)var1;
         if (var2.equals("head")) {
            return (ModelRenderer)Reflector.getFieldValue(var3, Reflector.ModelDragonHead_head);
         } else {
            return var2.equals("jaw") ? (ModelRenderer)Reflector.getFieldValue(var3, Reflector.ModelDragonHead_jaw) : null;
         }
      }
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      TileEntityRendererDispatcher var3 = TileEntityRendererDispatcher.instance;
      Object var4 = var3.getSpecialRendererByClass(TileEntitySkull.class);
      if (!(var4 instanceof TileEntitySkullRenderer)) {
         return null;
      } else {
         if (((TileEntitySpecialRenderer)var4).getEntityClass() == null) {
            var4 = new TileEntitySkullRenderer();
            ((TileEntitySpecialRenderer)var4).setRendererDispatcher(var3);
         }

         if (!Reflector.TileEntitySkullRenderer_dragonHead.exists()) {
            Config.warn("Field not found: TileEntitySkullRenderer.dragonHead");
            return null;
         } else {
            Reflector.setFieldValue(var4, Reflector.TileEntitySkullRenderer_dragonHead, var1);
            return (IEntityRenderer)var4;
         }
      }
   }
}
