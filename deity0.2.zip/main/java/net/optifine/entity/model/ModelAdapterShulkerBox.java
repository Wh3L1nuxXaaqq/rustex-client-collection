package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelShulker;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntityShulkerBoxRenderer;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityShulkerBox;
import optifine.Config;
import optifine.Reflector;

public class ModelAdapterShulkerBox extends ModelAdapter {
   public ModelAdapterShulkerBox() {
      super(TileEntityShulkerBox.class, "shulker_box", 0.0F);
   }

   public ModelBase makeModel() {
      return new ModelShulker();
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelShulker)) {
         return null;
      } else {
         ModelShulker var3 = (ModelShulker)var1;
         if (var2.equals("head")) {
            return var3.head;
         } else if (var2.equals("base")) {
            return var3.base;
         } else {
            return var2.equals("lid") ? var3.lid : null;
         }
      }
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      TileEntityRendererDispatcher var3 = TileEntityRendererDispatcher.instance;
      Object var4 = var3.getSpecialRendererByClass(TileEntityShulkerBox.class);
      if (!(var4 instanceof TileEntityShulkerBoxRenderer)) {
         return null;
      } else {
         if (((TileEntitySpecialRenderer)var4).getEntityClass() == null) {
            var4 = new TileEntityShulkerBoxRenderer((ModelShulker)var1);
            ((TileEntitySpecialRenderer)var4).setRendererDispatcher(var3);
         }

         if (!Reflector.TileEntityShulkerBoxRenderer_model.exists()) {
            Config.warn("Field not found: TileEntityShulkerBoxRenderer.model");
            return null;
         } else {
            Reflector.setFieldValue(var4, Reflector.TileEntityShulkerBoxRenderer_model, var1);
            return (IEntityRenderer)var4;
         }
      }
   }
}
