package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelZombie;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPigZombie;
import net.minecraft.entity.monster.EntityPigZombie;

public class ModelAdapterPigZombie extends ModelAdapterBiped {
   public ModelAdapterPigZombie() {
      super(EntityPigZombie.class, "zombie_pigman", 0.5F);
   }

   public ModelBase makeModel() {
      return new ModelZombie();
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderPigZombie var4 = new RenderPigZombie(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
