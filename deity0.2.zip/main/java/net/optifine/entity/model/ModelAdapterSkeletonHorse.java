package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderAbstractHorse;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.passive.EntityZombieHorse;

public class ModelAdapterSkeletonHorse extends ModelAdapterHorse {
   public ModelAdapterSkeletonHorse() {
      super(EntityZombieHorse.class, "zombie_horse", 0.75F);
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderAbstractHorse var4 = new RenderAbstractHorse(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
