package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelZombieVillager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderZombieVillager;
import net.minecraft.entity.monster.EntityZombieVillager;

public class ModelAdapterZombieVillager extends ModelAdapterBiped {
   public ModelAdapterZombieVillager() {
      super(EntityZombieVillager.class, "zombie_villager", 0.5F);
   }

   public ModelBase makeModel() {
      return new ModelZombieVillager();
   }

   public IEntityRenderer makeEntityRender(ModelBase var1, float var2) {
      RenderManager var3 = Minecraft.getMinecraft().getRenderManager();
      RenderZombieVillager var4 = new RenderZombieVillager(var3);
      var4.mainModel = var1;
      var4.shadowSize = var2;
      return var4;
   }
}
