package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelIllager;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapterIllager extends ModelAdapter {
   public ModelAdapterIllager(Class var1, String var2, float var3) {
      super(var1, var2, var3);
   }

   public ModelRenderer getModelRenderer(ModelBase var1, String var2) {
      if (!(var1 instanceof ModelIllager)) {
         return null;
      } else {
         ModelIllager var3 = (ModelIllager)var1;
         if (var2.equals("head")) {
            return var3.field_191217_a;
         } else if (var2.equals("body")) {
            return var3.field_191218_b;
         } else if (var2.equals("arms")) {
            return var3.field_191219_c;
         } else if (var2.equals("left_leg")) {
            return var3.field_191221_e;
         } else if (var2.equals("right_leg")) {
            return var3.field_191220_d;
         } else if (var2.equals("nose")) {
            return var3.field_191222_f;
         } else if (var2.equals("left_arm")) {
            return var3.field_191224_h;
         } else {
            return var2.equals("right_arm") ? var3.field_191223_g : null;
         }
      }
   }
}
