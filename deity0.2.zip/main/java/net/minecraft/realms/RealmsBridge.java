package net.minecraft.realms;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenRealmsProxy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsBridge extends RealmsScreen {
   private static final Logger LOGGER = LogManager.getLogger();
   private GuiScreen previousScreen;

   public void switchToRealms(GuiScreen var1) {
   }

   public GuiScreenRealmsProxy getNotificationScreen(GuiScreen var1) {
      return null;
   }

   public void init() {
      Minecraft.getMinecraft().displayGuiScreen(this.previousScreen);
   }
}
