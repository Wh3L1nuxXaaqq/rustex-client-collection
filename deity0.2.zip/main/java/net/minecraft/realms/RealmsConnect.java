package net.minecraft.realms;

import java.net.InetAddress;
import java.net.UnknownHostException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.CPacketLoginStart;
import net.minecraft.util.text.TextComponentTranslation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsConnect {
   private static final Logger LOGGER = LogManager.getLogger();
   private final RealmsScreen onlineScreen;
   private volatile boolean aborted;
   private NetworkManager connection;

   public RealmsConnect(RealmsScreen var1) {
      this.onlineScreen = var1;
   }

   public void connect(final String var1, final int var2) {
      Realms.setConnectedToRealms(true);
      (new Thread("Realms-connect-task") {
         public void run() {
            InetAddress var1x = null;

            try {
               var1x = InetAddress.getByName(var1);
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$102(RealmsConnect.this, NetworkManager.createNetworkManagerAndConnect(var1x, var2, Minecraft.getMinecraft().gameSettings.isUsingNativeTransport()));
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$100(RealmsConnect.this).setNetHandler(new NetHandlerLoginClient(RealmsConnect.access$100(RealmsConnect.this), Minecraft.getMinecraft(), RealmsConnect.access$200(RealmsConnect.this).getProxy()));
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$100(RealmsConnect.this).sendPacket(new C00Handshake(var1, var2, EnumConnectionState.LOGIN));
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$100(RealmsConnect.this).sendPacket(new CPacketLoginStart(Minecraft.getMinecraft().getSession().getProfile()));
            } catch (UnknownHostException var5) {
               Realms.clearResourcePack();
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$300().error("Couldn't connect to world", var5);
               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.access$200(RealmsConnect.this), "connect.failed", new TextComponentTranslation("disconnect.genericReason", new Object[]{"Unknown host '" + var1 + "'"})));
            } catch (Exception var6) {
               Realms.clearResourcePack();
               if (RealmsConnect.access$000(RealmsConnect.this)) {
                  return;
               }

               RealmsConnect.access$300().error("Couldn't connect to world", var6);
               String var3 = var6.toString();
               if (var1x != null) {
                  String var4 = var1x + ":" + var2;
                  var3 = var3.replaceAll(var4, "");
               }

               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.access$200(RealmsConnect.this), "connect.failed", new TextComponentTranslation("disconnect.genericReason", new Object[]{var3})));
            }

         }
      }).start();
   }

   public void abort() {
      this.aborted = true;
      if (this.connection != null && this.connection.isChannelOpen()) {
         this.connection.closeChannel(new TextComponentTranslation("disconnect.genericReason", new Object[0]));
         this.connection.checkDisconnected();
      }

   }

   public void tick() {
      if (this.connection != null) {
         if (this.connection.isChannelOpen()) {
            this.connection.processReceivedPackets();
         } else {
            this.connection.checkDisconnected();
         }
      }

   }

   static boolean access$000(RealmsConnect var0) {
      return var0.aborted;
   }

   static NetworkManager access$102(RealmsConnect var0, NetworkManager var1) {
      return var0.connection = var1;
   }

   static NetworkManager access$100(RealmsConnect var0) {
      return var0.connection;
   }

   static RealmsScreen access$200(RealmsConnect var0) {
      return var0.onlineScreen;
   }

   static Logger access$300() {
      return LOGGER;
   }
}
