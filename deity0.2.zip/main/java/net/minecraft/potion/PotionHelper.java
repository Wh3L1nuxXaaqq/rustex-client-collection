package net.minecraft.potion;

import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFishFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;

public class PotionHelper {
   private static final List<MixPredicate<PotionType>> POTION_TYPE_CONVERSIONS = Lists.newArrayList();
   private static final List<MixPredicate<Item>> POTION_ITEM_CONVERSIONS = Lists.newArrayList();
   private static final List<Ingredient> POTION_ITEMS = Lists.newArrayList();
   private static final Predicate<ItemStack> IS_POTION_ITEM = new Predicate<ItemStack>() {
      public boolean apply(ItemStack var1) {
         for(Object var3_raw : PotionHelper.access$000()) {
            com.google.common.base.Predicate var3 = (com.google.common.base.Predicate)var3_raw;
            if (var3.apply(var1)) {
               return true;
         }
         }

         return false;
      }
   };

   public static boolean isReagent(ItemStack var0) {
      return isItemConversionReagent(var0) || isTypeConversionReagent(var0);
   }

   protected static boolean isItemConversionReagent(ItemStack var0) {
      int var1 = 0;

      for(int var2 = POTION_ITEM_CONVERSIONS.size(); var1 < var2; ++var1) {
         if (((MixPredicate)POTION_ITEM_CONVERSIONS.get(var1)).reagent.apply(var0)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean isTypeConversionReagent(ItemStack var0) {
      int var1 = 0;

      for(int var2 = POTION_TYPE_CONVERSIONS.size(); var1 < var2; ++var1) {
         if (((MixPredicate)POTION_TYPE_CONVERSIONS.get(var1)).reagent.apply(var0)) {
            return true;
         }
      }

      return false;
   }

   public static boolean hasConversions(ItemStack var0, ItemStack var1) {
      if (!IS_POTION_ITEM.apply(var0)) {
         return false;
      } else {
         return hasItemConversions(var0, var1) || hasTypeConversions(var0, var1);
      }
   }

   protected static boolean hasItemConversions(ItemStack var0, ItemStack var1) {
      Item var2 = var0.getItem();
      int var3 = 0;

      for(int var4 = POTION_ITEM_CONVERSIONS.size(); var3 < var4; ++var3) {
         MixPredicate var5 = (MixPredicate)POTION_ITEM_CONVERSIONS.get(var3);
         if (var5.input == var2 && var5.reagent.apply(var1)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean hasTypeConversions(ItemStack var0, ItemStack var1) {
      PotionType var2 = PotionUtils.getPotionFromItem(var0);
      int var3 = 0;

      for(int var4 = POTION_TYPE_CONVERSIONS.size(); var3 < var4; ++var3) {
         MixPredicate var5 = (MixPredicate)POTION_TYPE_CONVERSIONS.get(var3);
         if (var5.input == var2 && var5.reagent.apply(var1)) {
            return true;
         }
      }

      return false;
   }

   public static ItemStack doReaction(ItemStack var0, ItemStack var1) {
      if (!var1.func_190926_b()) {
         PotionType var2 = PotionUtils.getPotionFromItem(var1);
         Item var3 = var1.getItem();
         int var4 = 0;

         for(int var5 = POTION_ITEM_CONVERSIONS.size(); var4 < var5; ++var4) {
            MixPredicate var6 = (MixPredicate)POTION_ITEM_CONVERSIONS.get(var4);
            if (var6.input == var3 && var6.reagent.apply(var0)) {
               return PotionUtils.addPotionToItemStack(new ItemStack((Item)var6.output), var2);
            }
         }

         var4 = 0;

         for(int var8 = POTION_TYPE_CONVERSIONS.size(); var4 < var8; ++var4) {
            MixPredicate var9 = (MixPredicate)POTION_TYPE_CONVERSIONS.get(var4);
            if (var9.input == var2 && var9.reagent.apply(var0)) {
               return PotionUtils.addPotionToItemStack(new ItemStack(var3), (PotionType)var9.output);
            }
         }
      }

      return var1;
   }

   public static void init() {
      func_193354_a(Items.POTIONITEM);
      func_193354_a(Items.SPLASH_POTION);
      func_193354_a(Items.LINGERING_POTION);
      func_193355_a(Items.POTIONITEM, Items.GUNPOWDER, Items.SPLASH_POTION);
      func_193355_a(Items.SPLASH_POTION, Items.DRAGON_BREATH, Items.LINGERING_POTION);
      func_193357_a(PotionTypes.WATER, Items.SPECKLED_MELON, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.GHAST_TEAR, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.RABBIT_FOOT, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.BLAZE_POWDER, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.SPIDER_EYE, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.SUGAR, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.MAGMA_CREAM, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.GLOWSTONE_DUST, PotionTypes.THICK);
      func_193357_a(PotionTypes.WATER, Items.REDSTONE, PotionTypes.MUNDANE);
      func_193357_a(PotionTypes.WATER, Items.NETHER_WART, PotionTypes.AWKWARD);
      func_193357_a(PotionTypes.AWKWARD, Items.GOLDEN_CARROT, PotionTypes.NIGHT_VISION);
      func_193357_a(PotionTypes.NIGHT_VISION, Items.REDSTONE, PotionTypes.LONG_NIGHT_VISION);
      func_193357_a(PotionTypes.NIGHT_VISION, Items.FERMENTED_SPIDER_EYE, PotionTypes.INVISIBILITY);
      func_193357_a(PotionTypes.LONG_NIGHT_VISION, Items.FERMENTED_SPIDER_EYE, PotionTypes.LONG_INVISIBILITY);
      func_193357_a(PotionTypes.INVISIBILITY, Items.REDSTONE, PotionTypes.LONG_INVISIBILITY);
      func_193357_a(PotionTypes.AWKWARD, Items.MAGMA_CREAM, PotionTypes.FIRE_RESISTANCE);
      func_193357_a(PotionTypes.FIRE_RESISTANCE, Items.REDSTONE, PotionTypes.LONG_FIRE_RESISTANCE);
      func_193357_a(PotionTypes.AWKWARD, Items.RABBIT_FOOT, PotionTypes.LEAPING);
      func_193357_a(PotionTypes.LEAPING, Items.REDSTONE, PotionTypes.LONG_LEAPING);
      func_193357_a(PotionTypes.LEAPING, Items.GLOWSTONE_DUST, PotionTypes.STRONG_LEAPING);
      func_193357_a(PotionTypes.LEAPING, Items.FERMENTED_SPIDER_EYE, PotionTypes.SLOWNESS);
      func_193357_a(PotionTypes.LONG_LEAPING, Items.FERMENTED_SPIDER_EYE, PotionTypes.LONG_SLOWNESS);
      func_193357_a(PotionTypes.SLOWNESS, Items.REDSTONE, PotionTypes.LONG_SLOWNESS);
      func_193357_a(PotionTypes.SWIFTNESS, Items.FERMENTED_SPIDER_EYE, PotionTypes.SLOWNESS);
      func_193357_a(PotionTypes.LONG_SWIFTNESS, Items.FERMENTED_SPIDER_EYE, PotionTypes.LONG_SLOWNESS);
      func_193357_a(PotionTypes.AWKWARD, Items.SUGAR, PotionTypes.SWIFTNESS);
      func_193357_a(PotionTypes.SWIFTNESS, Items.REDSTONE, PotionTypes.LONG_SWIFTNESS);
      func_193357_a(PotionTypes.SWIFTNESS, Items.GLOWSTONE_DUST, PotionTypes.STRONG_SWIFTNESS);
      func_193356_a(PotionTypes.AWKWARD, Ingredient.func_193369_a(new ItemStack(Items.FISH, 1, ItemFishFood.FishType.PUFFERFISH.getMetadata())), PotionTypes.WATER_BREATHING);
      func_193357_a(PotionTypes.WATER_BREATHING, Items.REDSTONE, PotionTypes.LONG_WATER_BREATHING);
      func_193357_a(PotionTypes.AWKWARD, Items.SPECKLED_MELON, PotionTypes.HEALING);
      func_193357_a(PotionTypes.HEALING, Items.GLOWSTONE_DUST, PotionTypes.STRONG_HEALING);
      func_193357_a(PotionTypes.HEALING, Items.FERMENTED_SPIDER_EYE, PotionTypes.HARMING);
      func_193357_a(PotionTypes.STRONG_HEALING, Items.FERMENTED_SPIDER_EYE, PotionTypes.STRONG_HARMING);
      func_193357_a(PotionTypes.HARMING, Items.GLOWSTONE_DUST, PotionTypes.STRONG_HARMING);
      func_193357_a(PotionTypes.POISON, Items.FERMENTED_SPIDER_EYE, PotionTypes.HARMING);
      func_193357_a(PotionTypes.LONG_POISON, Items.FERMENTED_SPIDER_EYE, PotionTypes.HARMING);
      func_193357_a(PotionTypes.STRONG_POISON, Items.FERMENTED_SPIDER_EYE, PotionTypes.STRONG_HARMING);
      func_193357_a(PotionTypes.AWKWARD, Items.SPIDER_EYE, PotionTypes.POISON);
      func_193357_a(PotionTypes.POISON, Items.REDSTONE, PotionTypes.LONG_POISON);
      func_193357_a(PotionTypes.POISON, Items.GLOWSTONE_DUST, PotionTypes.STRONG_POISON);
      func_193357_a(PotionTypes.AWKWARD, Items.GHAST_TEAR, PotionTypes.REGENERATION);
      func_193357_a(PotionTypes.REGENERATION, Items.REDSTONE, PotionTypes.LONG_REGENERATION);
      func_193357_a(PotionTypes.REGENERATION, Items.GLOWSTONE_DUST, PotionTypes.STRONG_REGENERATION);
      func_193357_a(PotionTypes.AWKWARD, Items.BLAZE_POWDER, PotionTypes.STRENGTH);
      func_193357_a(PotionTypes.STRENGTH, Items.REDSTONE, PotionTypes.LONG_STRENGTH);
      func_193357_a(PotionTypes.STRENGTH, Items.GLOWSTONE_DUST, PotionTypes.STRONG_STRENGTH);
      func_193357_a(PotionTypes.WATER, Items.FERMENTED_SPIDER_EYE, PotionTypes.WEAKNESS);
      func_193357_a(PotionTypes.WEAKNESS, Items.REDSTONE, PotionTypes.LONG_WEAKNESS);
   }

   private static void func_193355_a(ItemPotion var0, Item var1, ItemPotion var2) {
      POTION_ITEM_CONVERSIONS.add(new MixPredicate(var0, Ingredient.func_193368_a(var1), var2));
   }

   private static void func_193354_a(ItemPotion var0) {
      POTION_ITEMS.add(Ingredient.func_193368_a(var0));
   }

   private static void func_193357_a(PotionType var0, Item var1, PotionType var2) {
      func_193356_a(var0, Ingredient.func_193368_a(var1), var2);
   }

   private static void func_193356_a(PotionType var0, Ingredient var1, PotionType var2) {
      POTION_TYPE_CONVERSIONS.add(new MixPredicate(var0, var1, var2));
   }

   static List access$000() {
      return POTION_ITEMS;
   }

   static class MixPredicate<T> {
      final T input;
      final Ingredient reagent;
      final T output;

      public MixPredicate(T var1, Ingredient var2, T var3) {
         this.input = var1;
         this.reagent = var2;
         this.output = var3;
      }
   }
}
