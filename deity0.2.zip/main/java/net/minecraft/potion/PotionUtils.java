package net.minecraft.potion;

import com.google.common.base.MoreObjects;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Tuple;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import optifine.Config;
import optifine.CustomColors;

public class PotionUtils {
   public static List<PotionEffect> getEffectsFromStack(ItemStack var0) {
      return getEffectsFromTag(var0.getTagCompound());
   }

   public static List<PotionEffect> mergeEffects(PotionType var0, Collection<PotionEffect> var1) {
      ArrayList var2 = Lists.newArrayList();
      var2.addAll(var0.getEffects());
      var2.addAll(var1);
      return var2;
   }

   public static List<PotionEffect> getEffectsFromTag(@Nullable NBTTagCompound var0) {
      ArrayList var1 = Lists.newArrayList();
      var1.addAll(getPotionTypeFromNBT(var0).getEffects());
      addCustomPotionEffectToList(var0, var1);
      return var1;
   }

   public static List<PotionEffect> getFullEffectsFromItem(ItemStack var0) {
      return getFullEffectsFromTag(var0.getTagCompound());
   }

   public static List<PotionEffect> getFullEffectsFromTag(@Nullable NBTTagCompound var0) {
      ArrayList var1 = Lists.newArrayList();
      addCustomPotionEffectToList(var0, var1);
      return var1;
   }

   public static void addCustomPotionEffectToList(@Nullable NBTTagCompound var0, List<PotionEffect> var1) {
      if (var0 != null && var0.hasKey("CustomPotionEffects", 9)) {
         NBTTagList var2 = var0.getTagList("CustomPotionEffects", 10);

         for(int var3 = 0; var3 < var2.tagCount(); ++var3) {
            NBTTagCompound var4 = var2.getCompoundTagAt(var3);
            PotionEffect var5 = PotionEffect.readCustomPotionEffectFromNBT(var4);
            if (var5 != null) {
               var1.add(var5);
            }
         }
      }

   }

   public static int func_190932_c(ItemStack var0) {
      NBTTagCompound var1 = var0.getTagCompound();
      if (var1 != null && var1.hasKey("CustomPotionColor", 99)) {
         return var1.getInteger("CustomPotionColor");
      } else {
         return getPotionFromItem(var0) == PotionTypes.EMPTY ? 16253176 : getPotionColorFromEffectList(getEffectsFromStack(var0));
      }
   }

   public static int getPotionColor(PotionType var0) {
      return var0 == PotionTypes.EMPTY ? 16253176 : getPotionColorFromEffectList(var0.getEffects());
   }

   public static int getPotionColorFromEffectList(Collection<PotionEffect> var0) {
      int var1 = 3694022;
      if (var0.isEmpty()) {
         return Config.isCustomColors() ? CustomColors.getPotionColor((Potion)null, var1) : 3694022;
      } else {
         float var2 = 0.0F;
         float var3 = 0.0F;
         float var4 = 0.0F;
         int var5 = 0;

         for(PotionEffect var7 : var0) {
            if (var7.doesShowParticles()) {
               int var8 = var7.getPotion().getLiquidColor();
               if (Config.isCustomColors()) {
                  var8 = CustomColors.getPotionColor(var7.getPotion(), var8);
               }

               int var9 = var7.getAmplifier() + 1;
               var2 += (float)(var9 * (var8 >> 16 & 255)) / 255.0F;
               var3 += (float)(var9 * (var8 >> 8 & 255)) / 255.0F;
               var4 += (float)(var9 * (var8 >> 0 & 255)) / 255.0F;
               var5 += var9;
            }
         }

         if (var5 == 0) {
            return 0;
         } else {
            var2 = var2 / (float)var5 * 255.0F;
            var3 = var3 / (float)var5 * 255.0F;
            var4 = var4 / (float)var5 * 255.0F;
            return (int)var2 << 16 | (int)var3 << 8 | (int)var4;
         }
      }
   }

   public static PotionType getPotionFromItem(ItemStack var0) {
      return getPotionTypeFromNBT(var0.getTagCompound());
   }

   public static PotionType getPotionTypeFromNBT(@Nullable NBTTagCompound var0) {
      return var0 == null ? PotionTypes.EMPTY : PotionType.getPotionTypeForName(var0.getString("Potion"));
   }

   public static ItemStack addPotionToItemStack(ItemStack var0, PotionType var1) {
      ResourceLocation var2 = PotionType.REGISTRY.getNameForObject(var1);
      if (var1 == PotionTypes.EMPTY) {
         if (var0.hasTagCompound()) {
            NBTTagCompound var3 = var0.getTagCompound();
            var3.removeTag("Potion");
            if (var3.hasNoTags()) {
               var0.setTagCompound((NBTTagCompound)null);
            }
         }
      } else {
         NBTTagCompound var4 = var0.hasTagCompound() ? var0.getTagCompound() : new NBTTagCompound();
         var4.setString("Potion", var2.toString());
         var0.setTagCompound(var4);
      }

      return var0;
   }

   public static ItemStack appendEffects(ItemStack var0, Collection<PotionEffect> var1) {
      if (var1.isEmpty()) {
         return var0;
      } else {
         NBTTagCompound var2 = (NBTTagCompound)MoreObjects.firstNonNull(var0.getTagCompound(), new NBTTagCompound());
         NBTTagList var3 = var2.getTagList("CustomPotionEffects", 9);

         for(PotionEffect var5 : var1) {
            var3.appendTag(var5.writeCustomPotionEffectToNBT(new NBTTagCompound()));
         }

         var2.setTag("CustomPotionEffects", var3);
         var0.setTagCompound(var2);
         return var0;
      }
   }

   public static void addPotionTooltip(ItemStack var0, List<String> var1, float var2) {
      List var3 = getEffectsFromStack(var0);
      ArrayList var4 = Lists.newArrayList();
      if (var3.isEmpty()) {
         String var5 = I18n.translateToLocal("effect.none").trim();
         var1.add(TextFormatting.GRAY + var5);
      } else {
         for(Object var6_raw : var3) {
            PotionEffect var6 = (PotionEffect)var6_raw;
            String var7 = I18n.translateToLocal(var6.getEffectName()).trim();
            Potion var8 = var6.getPotion();
            Map var9 = var8.getAttributeModifierMap();
            if (!var9.isEmpty()) {
               for(Object var11_raw : var9.entrySet()) {
                  java.util.Map.Entry var11 = (java.util.Map.Entry)var11_raw;
                  AttributeModifier var12 = (AttributeModifier)var11.getValue();
                  AttributeModifier var13 = new AttributeModifier(var12.getName(), var8.getAttributeModifierAmount(var6.getAmplifier(), var12), var12.getOperation());
                  var4.add(new Tuple(((IAttribute)var11.getKey()).getAttributeUnlocalizedName(), var13));
               }
            }

            if (var6.getAmplifier() > 0) {
               var7 = var7 + " " + I18n.translateToLocal("potion.potency." + var6.getAmplifier()).trim();
            }

            if (var6.getDuration() > 20) {
               var7 = var7 + " (" + Potion.getPotionDurationString(var6, var2) + ")";
            }

            if (var8.isBadEffect()) {
               var1.add(TextFormatting.RED + var7);
            } else {
               var1.add(TextFormatting.BLUE + var7);
            }
         }
      }

      if (!var4.isEmpty()) {
         var1.add("");
         var1.add(TextFormatting.DARK_PURPLE + I18n.translateToLocal("potion.whenDrank"));

         for(Object var16_raw : var4) {
            Tuple var16 = (Tuple)var16_raw;
            AttributeModifier var17 = (AttributeModifier)var16.getSecond();
            double var18 = var17.getAmount();
            double var19;
            if (var17.getOperation() != 1 && var17.getOperation() != 2) {
               var19 = var17.getAmount();
            } else {
               var19 = var17.getAmount() * (double)100.0F;
            }

            if (var18 > (double)0.0F) {
               var1.add(TextFormatting.BLUE + I18n.translateToLocalFormatted("attribute.modifier.plus." + var17.getOperation(), ItemStack.DECIMALFORMAT.format(var19), I18n.translateToLocal("attribute.name." + (String)var16.getFirst())));
            } else if (var18 < (double)0.0F) {
               var19 *= (double)-1.0F;
               var1.add(TextFormatting.RED + I18n.translateToLocalFormatted("attribute.modifier.take." + var17.getOperation(), ItemStack.DECIMALFORMAT.format(var19), I18n.translateToLocal("attribute.name." + (String)var16.getFirst())));
            }
         }
      }

   }
}
