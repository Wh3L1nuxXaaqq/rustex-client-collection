package net.minecraft.pathfinding;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class PathNavigateFlying extends PathNavigate {
   public PathNavigateFlying(EntityLiving var1, World var2) {
      super(var1, var2);
   }

   protected PathFinder getPathFinder() {
      this.nodeProcessor = new FlyingNodeProcessor();
      this.nodeProcessor.setCanEnterDoors(true);
      return new PathFinder(this.nodeProcessor);
   }

   protected boolean canNavigate() {
      return this.func_192880_g() && this.isInLiquid() || !this.theEntity.isRiding();
   }

   protected Vec3d getEntityPosition() {
      return new Vec3d(this.theEntity.posX, this.theEntity.posY, this.theEntity.posZ);
   }

   public Path getPathToEntityLiving(Entity var1) {
      return this.getPathToPos(new BlockPos(var1));
   }

   public void onUpdateNavigation() {
      ++this.totalTicks;
      if (this.tryUpdatePath) {
         this.updatePath();
      }

      if (!this.noPath()) {
         if (this.canNavigate()) {
            this.pathFollow();
         } else if (this.currentPath != null && this.currentPath.getCurrentPathIndex() < this.currentPath.getCurrentPathLength()) {
            Vec3d var1 = this.currentPath.getVectorFromIndex(this.theEntity, this.currentPath.getCurrentPathIndex());
            if (MathHelper.floor(this.theEntity.posX) == MathHelper.floor(var1.xCoord) && MathHelper.floor(this.theEntity.posY) == MathHelper.floor(var1.yCoord) && MathHelper.floor(this.theEntity.posZ) == MathHelper.floor(var1.zCoord)) {
               this.currentPath.setCurrentPathIndex(this.currentPath.getCurrentPathIndex() + 1);
            }
         }

         this.func_192876_m();
         if (!this.noPath()) {
            Vec3d var2 = this.currentPath.getPosition(this.theEntity);
            this.theEntity.getMoveHelper().setMoveTo(var2.xCoord, var2.yCoord, var2.zCoord, this.speed);
         }
      }

   }

   protected boolean isDirectPathBetweenPoints(Vec3d var1, Vec3d var2, int var3, int var4, int var5) {
      int var6 = MathHelper.floor(var1.xCoord);
      int var7 = MathHelper.floor(var1.yCoord);
      int var8 = MathHelper.floor(var1.zCoord);
      double var9 = var2.xCoord - var1.xCoord;
      double var11 = var2.yCoord - var1.yCoord;
      double var13 = var2.zCoord - var1.zCoord;
      double var15 = var9 * var9 + var11 * var11 + var13 * var13;
      if (var15 < 1.0E-8) {
         return false;
      } else {
         double var17 = (double)1.0F / Math.sqrt(var15);
         var9 *= var17;
         var11 *= var17;
         var13 *= var17;
         double var19 = (double)1.0F / Math.abs(var9);
         double var21 = (double)1.0F / Math.abs(var11);
         double var23 = (double)1.0F / Math.abs(var13);
         double var25 = (double)var6 - var1.xCoord;
         double var27 = (double)var7 - var1.yCoord;
         double var29 = (double)var8 - var1.zCoord;
         if (var9 >= (double)0.0F) {
            ++var25;
         }

         if (var11 >= (double)0.0F) {
            ++var27;
         }

         if (var13 >= (double)0.0F) {
            ++var29;
         }

         var25 /= var9;
         var27 /= var11;
         var29 /= var13;
         int var31 = var9 < (double)0.0F ? -1 : 1;
         int var32 = var11 < (double)0.0F ? -1 : 1;
         int var33 = var13 < (double)0.0F ? -1 : 1;
         int var34 = MathHelper.floor(var2.xCoord);
         int var35 = MathHelper.floor(var2.yCoord);
         int var36 = MathHelper.floor(var2.zCoord);
         int var37 = var34 - var6;
         int var38 = var35 - var7;
         int var39 = var36 - var8;

         while(var37 * var31 > 0 || var38 * var32 > 0 || var39 * var33 > 0) {
            if (var25 < var29 && var25 <= var27) {
               var25 += var19;
               var6 += var31;
               var37 = var34 - var6;
            } else if (var27 < var25 && var27 <= var29) {
               var27 += var21;
               var7 += var32;
               var38 = var35 - var7;
            } else {
               var29 += var23;
               var8 += var33;
               var39 = var36 - var8;
            }
         }

         return true;
      }
   }

   public void func_192879_a(boolean var1) {
      this.nodeProcessor.setCanBreakDoors(var1);
   }

   public void func_192878_b(boolean var1) {
      this.nodeProcessor.setCanEnterDoors(var1);
   }

   public void func_192877_c(boolean var1) {
      this.nodeProcessor.setCanSwim(var1);
   }

   public boolean func_192880_g() {
      return this.nodeProcessor.getCanSwim();
   }

   public boolean canEntityStandOnPos(BlockPos var1) {
      return this.worldObj.getBlockState(var1).isFullyOpaque();
   }
}
