package net.minecraft.pathfinding;

import com.google.common.collect.Sets;
import java.util.EnumSet;
import java.util.HashSet;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLiving;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;

public class FlyingNodeProcessor extends WalkNodeProcessor {
   public void initProcessor(IBlockAccess var1, EntityLiving var2) {
      super.initProcessor(var1, var2);
      this.avoidsWater = var2.getPathPriority(PathNodeType.WATER);
   }

   public void postProcess() {
      this.entity.setPathPriority(PathNodeType.WATER, this.avoidsWater);
      super.postProcess();
   }

   public PathPoint getStart() {
      int var1;
      if (this.getCanSwim() && this.entity.isInWater()) {
         var1 = (int)this.entity.getEntityBoundingBox().minY;
         BlockPos.MutableBlockPos var2 = new BlockPos.MutableBlockPos(MathHelper.floor(this.entity.posX), var1, MathHelper.floor(this.entity.posZ));

         for(Block var3 = this.blockaccess.getBlockState(var2).getBlock(); var3 == Blocks.FLOWING_WATER || var3 == Blocks.WATER; var3 = this.blockaccess.getBlockState(var2).getBlock()) {
            ++var1;
            var2.setPos(MathHelper.floor(this.entity.posX), var1, MathHelper.floor(this.entity.posZ));
         }
      } else {
         var1 = MathHelper.floor(this.entity.getEntityBoundingBox().minY + (double)0.5F);
      }

      BlockPos var8 = new BlockPos(this.entity);
      PathNodeType var9 = this.func_192558_a(this.entity, var8.getX(), var1, var8.getZ());
      if (this.entity.getPathPriority(var9) < 0.0F) {
         HashSet var4 = Sets.newHashSet();
         var4.add(new BlockPos(this.entity.getEntityBoundingBox().minX, (double)var1, this.entity.getEntityBoundingBox().minZ));
         var4.add(new BlockPos(this.entity.getEntityBoundingBox().minX, (double)var1, this.entity.getEntityBoundingBox().maxZ));
         var4.add(new BlockPos(this.entity.getEntityBoundingBox().maxX, (double)var1, this.entity.getEntityBoundingBox().minZ));
         var4.add(new BlockPos(this.entity.getEntityBoundingBox().maxX, (double)var1, this.entity.getEntityBoundingBox().maxZ));

         for(Object var6_raw : var4) {
            BlockPos var6 = (BlockPos)var6_raw;
            PathNodeType var7 = this.func_192559_a(this.entity, var6);
            if (this.entity.getPathPriority(var7) >= 0.0F) {
               return super.openPoint(var6.getX(), var6.getY(), var6.getZ());
            }
         }
      }

      return super.openPoint(var8.getX(), var1, var8.getZ());
   }

   public PathPoint getPathPointToCoords(double var1, double var3, double var5) {
      return super.openPoint(MathHelper.floor(var1), MathHelper.floor(var3), MathHelper.floor(var5));
   }

   public int findPathOptions(PathPoint[] var1, PathPoint var2, PathPoint var3, float var4) {
      int var5 = 0;
      PathPoint var6 = this.openPoint(var2.xCoord, var2.yCoord, var2.zCoord + 1);
      PathPoint var7 = this.openPoint(var2.xCoord - 1, var2.yCoord, var2.zCoord);
      PathPoint var8 = this.openPoint(var2.xCoord + 1, var2.yCoord, var2.zCoord);
      PathPoint var9 = this.openPoint(var2.xCoord, var2.yCoord, var2.zCoord - 1);
      PathPoint var10 = this.openPoint(var2.xCoord, var2.yCoord + 1, var2.zCoord);
      PathPoint var11 = this.openPoint(var2.xCoord, var2.yCoord - 1, var2.zCoord);
      if (var6 != null && !var6.visited && var6.distanceTo(var3) < var4) {
         var1[var5++] = var6;
      }

      if (var7 != null && !var7.visited && var7.distanceTo(var3) < var4) {
         var1[var5++] = var7;
      }

      if (var8 != null && !var8.visited && var8.distanceTo(var3) < var4) {
         var1[var5++] = var8;
      }

      if (var9 != null && !var9.visited && var9.distanceTo(var3) < var4) {
         var1[var5++] = var9;
      }

      if (var10 != null && !var10.visited && var10.distanceTo(var3) < var4) {
         var1[var5++] = var10;
      }

      if (var11 != null && !var11.visited && var11.distanceTo(var3) < var4) {
         var1[var5++] = var11;
      }

      boolean var12 = var9 == null || var9.costMalus != 0.0F;
      boolean var13 = var6 == null || var6.costMalus != 0.0F;
      boolean var14 = var8 == null || var8.costMalus != 0.0F;
      boolean var15 = var7 == null || var7.costMalus != 0.0F;
      boolean var16 = var10 == null || var10.costMalus != 0.0F;
      boolean var17 = var11 == null || var11.costMalus != 0.0F;
      if (var12 && var15) {
         PathPoint var18 = this.openPoint(var2.xCoord - 1, var2.yCoord, var2.zCoord - 1);
         if (var18 != null && !var18.visited && var18.distanceTo(var3) < var4) {
            var1[var5++] = var18;
         }
      }

      if (var12 && var14) {
         PathPoint var19 = this.openPoint(var2.xCoord + 1, var2.yCoord, var2.zCoord - 1);
         if (var19 != null && !var19.visited && var19.distanceTo(var3) < var4) {
            var1[var5++] = var19;
         }
      }

      if (var13 && var15) {
         PathPoint var20 = this.openPoint(var2.xCoord - 1, var2.yCoord, var2.zCoord + 1);
         if (var20 != null && !var20.visited && var20.distanceTo(var3) < var4) {
            var1[var5++] = var20;
         }
      }

      if (var13 && var14) {
         PathPoint var21 = this.openPoint(var2.xCoord + 1, var2.yCoord, var2.zCoord + 1);
         if (var21 != null && !var21.visited && var21.distanceTo(var3) < var4) {
            var1[var5++] = var21;
         }
      }

      if (var12 && var16) {
         PathPoint var22 = this.openPoint(var2.xCoord, var2.yCoord + 1, var2.zCoord - 1);
         if (var22 != null && !var22.visited && var22.distanceTo(var3) < var4) {
            var1[var5++] = var22;
         }
      }

      if (var13 && var16) {
         PathPoint var23 = this.openPoint(var2.xCoord, var2.yCoord + 1, var2.zCoord + 1);
         if (var23 != null && !var23.visited && var23.distanceTo(var3) < var4) {
            var1[var5++] = var23;
         }
      }

      if (var14 && var16) {
         PathPoint var24 = this.openPoint(var2.xCoord + 1, var2.yCoord + 1, var2.zCoord);
         if (var24 != null && !var24.visited && var24.distanceTo(var3) < var4) {
            var1[var5++] = var24;
         }
      }

      if (var15 && var16) {
         PathPoint var25 = this.openPoint(var2.xCoord - 1, var2.yCoord + 1, var2.zCoord);
         if (var25 != null && !var25.visited && var25.distanceTo(var3) < var4) {
            var1[var5++] = var25;
         }
      }

      if (var12 && var17) {
         PathPoint var26 = this.openPoint(var2.xCoord, var2.yCoord - 1, var2.zCoord - 1);
         if (var26 != null && !var26.visited && var26.distanceTo(var3) < var4) {
            var1[var5++] = var26;
         }
      }

      if (var13 && var17) {
         PathPoint var27 = this.openPoint(var2.xCoord, var2.yCoord - 1, var2.zCoord + 1);
         if (var27 != null && !var27.visited && var27.distanceTo(var3) < var4) {
            var1[var5++] = var27;
         }
      }

      if (var14 && var17) {
         PathPoint var28 = this.openPoint(var2.xCoord + 1, var2.yCoord - 1, var2.zCoord);
         if (var28 != null && !var28.visited && var28.distanceTo(var3) < var4) {
            var1[var5++] = var28;
         }
      }

      if (var15 && var17) {
         PathPoint var29 = this.openPoint(var2.xCoord - 1, var2.yCoord - 1, var2.zCoord);
         if (var29 != null && !var29.visited && var29.distanceTo(var3) < var4) {
            var1[var5++] = var29;
         }
      }

      return var5;
   }

   @Nullable
   protected PathPoint openPoint(int var1, int var2, int var3) {
      PathPoint var4 = null;
      PathNodeType var5 = this.func_192558_a(this.entity, var1, var2, var3);
      float var6 = this.entity.getPathPriority(var5);
      if (var6 >= 0.0F) {
         var4 = super.openPoint(var1, var2, var3);
         var4.nodeType = var5;
         var4.costMalus = Math.max(var4.costMalus, var6);
         if (var5 == PathNodeType.WALKABLE) {
            ++var4.costMalus;
         }
      }

      return var5 != PathNodeType.OPEN && var5 != PathNodeType.WALKABLE ? var4 : var4;
   }

   public PathNodeType getPathNodeType(IBlockAccess var1, int var2, int var3, int var4, EntityLiving var5, int var6, int var7, int var8, boolean var9, boolean var10) {
      EnumSet var11 = EnumSet.noneOf(PathNodeType.class);
      PathNodeType var12 = PathNodeType.BLOCKED;
      BlockPos var13 = new BlockPos(var5);
      var12 = this.func_193577_a(var1, var2, var3, var4, var6, var7, var8, var9, var10, var11, var12, var13);
      if (var11.contains(PathNodeType.FENCE)) {
         return PathNodeType.FENCE;
      } else {
         PathNodeType var14 = PathNodeType.BLOCKED;

         for(Object var16_raw : var11) {
            PathNodeType var16 = (PathNodeType)var16_raw;
            if (var5.getPathPriority(var16) < 0.0F) {
               return var16;
            }

            if (var5.getPathPriority(var16) >= var5.getPathPriority(var14)) {
               var14 = var16;
            }
         }

         if (var12 == PathNodeType.OPEN && var5.getPathPriority(var14) == 0.0F) {
            return PathNodeType.OPEN;
         } else {
            return var14;
         }
      }
   }

   public PathNodeType getPathNodeType(IBlockAccess var1, int var2, int var3, int var4) {
      PathNodeType var5 = this.getPathNodeTypeRaw(var1, var2, var3, var4);
      if (var5 == PathNodeType.OPEN && var3 >= 1) {
         Block var6 = var1.getBlockState(new BlockPos(var2, var3 - 1, var4)).getBlock();
         PathNodeType var7 = this.getPathNodeTypeRaw(var1, var2, var3 - 1, var4);
         if (var7 != PathNodeType.DAMAGE_FIRE && var6 != Blocks.MAGMA && var7 != PathNodeType.LAVA) {
            if (var7 == PathNodeType.DAMAGE_CACTUS) {
               var5 = PathNodeType.DAMAGE_CACTUS;
            } else {
               var5 = var7 != PathNodeType.WALKABLE && var7 != PathNodeType.OPEN && var7 != PathNodeType.WATER ? PathNodeType.WALKABLE : PathNodeType.OPEN;
            }
         } else {
            var5 = PathNodeType.DAMAGE_FIRE;
         }
      }

      var5 = this.func_193578_a(var1, var2, var3, var4, var5);
      return var5;
   }

   private PathNodeType func_192559_a(EntityLiving var1, BlockPos var2) {
      return this.func_192558_a(var1, var2.getX(), var2.getY(), var2.getZ());
   }

   private PathNodeType func_192558_a(EntityLiving var1, int var2, int var3, int var4) {
      return this.getPathNodeType(this.blockaccess, var2, var3, var4, var1, this.entitySizeX, this.entitySizeY, this.entitySizeZ, this.getCanBreakDoors(), this.getCanEnterDoors());
   }
}
