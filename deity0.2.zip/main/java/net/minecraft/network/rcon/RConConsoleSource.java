package net.minecraft.network.rcon;

import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;

public class RConConsoleSource implements ICommandSender {
   private final StringBuffer buffer = new StringBuffer();
   private final MinecraftServer server;

   public RConConsoleSource(MinecraftServer var1) {
      this.server = var1;
   }

   public String getName() {
      return "Rcon";
   }

   public void addChatMessage(ITextComponent var1) {
      this.buffer.append(var1.getUnformattedText());
   }

   public boolean canCommandSenderUseCommand(int var1, String var2) {
      return true;
   }

   public World getEntityWorld() {
      return this.server.getEntityWorld();
   }

   public boolean sendCommandFeedback() {
      return true;
   }

   public MinecraftServer getServer() {
      return this.server;
   }
}
