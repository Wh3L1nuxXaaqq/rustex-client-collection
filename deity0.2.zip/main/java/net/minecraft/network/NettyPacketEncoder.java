package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class NettyPacketEncoder extends MessageToByteEncoder<Packet<?>> {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final Marker RECEIVED_PACKET_MARKER;
   private final EnumPacketDirection direction;

   public NettyPacketEncoder(EnumPacketDirection var1) {
      this.direction = var1;
   }

   protected void encode(ChannelHandlerContext var1, Packet<?> var2, ByteBuf var3) throws IOException, Exception {
      EnumConnectionState var4 = (EnumConnectionState)var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get();
      if (var4 == null) {
         throw new RuntimeException("ConnectionProtocol unknown: " + var2.toString());
      } else {
         Integer var5 = var4.getPacketId(this.direction, var2);
         if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(RECEIVED_PACKET_MARKER, "OUT: [{}:{}] {}", var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get(), var5, var2.getClass().getName());
         }

         if (var5 == null) {
            throw new IOException("Can't serialize unregistered packet");
         } else {
            PacketBuffer var6 = new PacketBuffer(var3);
            var6.writeVarIntToBuffer(var5);

            try {
               var2.writePacketData(var6);
            } catch (Throwable var8) {
               LOGGER.error(var8);
            }

         }
      }
   }

   static {
      RECEIVED_PACKET_MARKER = MarkerManager.getMarker("PACKET_SENT", NetworkManager.NETWORK_PACKETS_MARKER);
   }
}
