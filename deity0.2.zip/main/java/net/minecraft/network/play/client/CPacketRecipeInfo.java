package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketRecipeInfo implements Packet<INetHandlerPlayServer> {
   private Purpose field_194157_a;
   private IRecipe field_193649_d;
   private boolean field_192631_e;
   private boolean field_192632_f;

   public CPacketRecipeInfo() {
   }

   public CPacketRecipeInfo(IRecipe var1) {
      this.field_194157_a = CPacketRecipeInfo.Purpose.SHOWN;
      this.field_193649_d = var1;
   }

   public CPacketRecipeInfo(boolean var1, boolean var2) {
      this.field_194157_a = CPacketRecipeInfo.Purpose.SETTINGS;
      this.field_192631_e = var1;
      this.field_192632_f = var2;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_194157_a = (Purpose)var1.readEnumValue(Purpose.class);
      if (this.field_194157_a == CPacketRecipeInfo.Purpose.SHOWN) {
         this.field_193649_d = CraftingManager.func_193374_a(var1.readInt());
      } else if (this.field_194157_a == CPacketRecipeInfo.Purpose.SETTINGS) {
         this.field_192631_e = var1.readBoolean();
         this.field_192632_f = var1.readBoolean();
      }

   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.field_194157_a);
      if (this.field_194157_a == CPacketRecipeInfo.Purpose.SHOWN) {
         var1.writeInt(CraftingManager.func_193375_a(this.field_193649_d));
      } else if (this.field_194157_a == CPacketRecipeInfo.Purpose.SETTINGS) {
         var1.writeBoolean(this.field_192631_e);
         var1.writeBoolean(this.field_192632_f);
      }

   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.func_191984_a(this);
   }

   public Purpose func_194156_a() {
      return this.field_194157_a;
   }

   public IRecipe func_193648_b() {
      return this.field_193649_d;
   }

   public boolean func_192624_c() {
      return this.field_192631_e;
   }

   public boolean func_192625_d() {
      return this.field_192632_f;
   }

   public static enum Purpose {
      SHOWN,
      SETTINGS;
   }
}
