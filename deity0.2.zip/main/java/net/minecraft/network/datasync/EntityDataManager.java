package net.minecraft.network.datasync;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.Nullable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ReportedException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityDataManager {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final Map<Class<? extends Entity>, Integer> NEXT_ID_MAP = Maps.newHashMap();
   private final Entity entity;
   private final Map<Integer, DataEntry<?>> entries = Maps.newHashMap();
   private final ReadWriteLock lock = new ReentrantReadWriteLock();
   private boolean empty = true;
   private boolean dirty;

   public EntityDataManager(Entity var1) {
      this.entity = var1;
   }

   public static <T> DataParameter<T> createKey(Class<? extends Entity> var0, DataSerializer<T> var1) {
      if (LOGGER.isDebugEnabled()) {
         try {
            Class var2 = Class.forName(Thread.currentThread().getStackTrace()[2].getClassName());
            if (!var2.equals(var0)) {
               LOGGER.debug("defineId called for: {} from {}", var0, var2, new RuntimeException());
            }
         } catch (ClassNotFoundException var5) {
         }
      }

      int var6;
      if (NEXT_ID_MAP.containsKey(var0)) {
         var6 = (Integer)NEXT_ID_MAP.get(var0) + 1;
      } else {
         int var3 = 0;
         Class var4 = var0;

         while(var4 != Entity.class) {
            var4 = var4.getSuperclass();
            if (NEXT_ID_MAP.containsKey(var4)) {
               var3 = (Integer)NEXT_ID_MAP.get(var4) + 1;
               break;
            }
         }

         var6 = var3;
      }

      if (var6 > 254) {
         throw new IllegalArgumentException("Data value id is too big with " + var6 + "! (Max is " + 254 + ")");
      } else {
         NEXT_ID_MAP.put(var0, var6);
         return var1.createKey(var6);
      }
   }

   public <T> void register(DataParameter<T> var1, T var2) {
      int var3 = var1.getId();
      if (var3 > 254) {
         throw new IllegalArgumentException("Data value id is too big with " + var3 + "! (Max is " + 254 + ")");
      } else if (this.entries.containsKey(var3)) {
         throw new IllegalArgumentException("Duplicate id value for " + var3 + "!");
      } else if (DataSerializers.getSerializerId(var1.getSerializer()) < 0) {
         throw new IllegalArgumentException("Unregistered serializer " + var1.getSerializer() + " for " + var3 + "!");
      } else {
         this.setEntry(var1, var2);
      }
   }

   private <T> void setEntry(DataParameter<T> var1, T var2) {
      DataEntry var3 = new DataEntry(var1, var2);
      this.lock.writeLock().lock();
      this.entries.put(var1.getId(), var3);
      this.empty = false;
      this.lock.writeLock().unlock();
   }

   private <T> DataEntry<T> getEntry(DataParameter<T> var1) {
      this.lock.readLock().lock();

      DataEntry var2;
      try {
         var2 = (DataEntry)this.entries.get(var1.getId());
      } catch (Throwable var6) {
         CrashReport var4 = CrashReport.makeCrashReport(var6, "Getting synched entity data");
         CrashReportCategory var5 = var4.makeCategory("Synched entity data");
         var5.addCrashSection("Data ID", var1);
         throw new ReportedException(var4);
      }

      this.lock.readLock().unlock();
      return var2;
   }

   public <T> T get(DataParameter<T> var1) {
      return (T)this.getEntry(var1).getValue();
   }

   public <T> void set(DataParameter<T> var1, T var2) {
      DataEntry var3 = this.getEntry(var1);
      if (ObjectUtils.notEqual(var2, var3.getValue())) {
         var3.setValue(var2);
         this.entity.notifyDataManagerChange(var1);
         var3.setDirty(true);
         this.dirty = true;
      }

   }

   public <T> void setDirty(DataParameter<T> var1) {
      EntityDataManager.DataEntry.access$002(this.getEntry(var1), true);
      this.dirty = true;
   }

   public boolean isDirty() {
      return this.dirty;
   }

   public static void writeEntries(List<DataEntry<?>> var0, PacketBuffer var1) throws IOException {
      if (var0 != null) {
         int var2 = 0;

         for(int var3 = var0.size(); var2 < var3; ++var2) {
            DataEntry var4 = (DataEntry)var0.get(var2);
            writeEntry(var1, var4);
         }
      }

      var1.writeByte(255);
   }

   @Nullable
   public List<DataEntry<?>> getDirty() {
      ArrayList var1 = null;
      if (this.dirty) {
         this.lock.readLock().lock();

         for(DataEntry var3 : this.entries.values()) {
            if (var3.isDirty()) {
               var3.setDirty(false);
               if (var1 == null) {
                  var1 = Lists.newArrayList();
               }

               var1.add(var3.func_192735_d());
            }
         }

         this.lock.readLock().unlock();
      }

      this.dirty = false;
      return var1;
   }

   public void writeEntries(PacketBuffer var1) throws IOException {
      this.lock.readLock().lock();

      for(DataEntry var3 : this.entries.values()) {
         writeEntry(var1, var3);
      }

      this.lock.readLock().unlock();
      var1.writeByte(255);
   }

   @Nullable
   public List<DataEntry<?>> getAll() {
      ArrayList var1 = null;
      this.lock.readLock().lock();

      for(DataEntry var3 : this.entries.values()) {
         if (var1 == null) {
            var1 = Lists.newArrayList();
         }

         var1.add(var3.func_192735_d());
      }

      this.lock.readLock().unlock();
      return var1;
   }

   private static <T> void writeEntry(PacketBuffer var0, DataEntry<T> var1) throws IOException {
      DataParameter var2 = var1.getKey();
      int var3 = DataSerializers.getSerializerId(var2.getSerializer());
      if (var3 < 0) {
         throw new EncoderException("Unknown serializer type " + var2.getSerializer());
      } else {
         var0.writeByte(var2.getId());
         var0.writeVarIntToBuffer(var3);
         var2.getSerializer().write(var0, var1.getValue());
      }
   }

   @Nullable
   public static List<DataEntry<?>> readEntries(PacketBuffer var0) throws IOException {
      ArrayList var1 = null;

      short var2;
      while((var2 = var0.readUnsignedByte()) != 255) {
         if (var1 == null) {
            var1 = Lists.newArrayList();
         }

         int var3 = var0.readVarIntFromBuffer();
         DataSerializer var4 = DataSerializers.getSerializer(var3);
         if (var4 == null) {
            throw new DecoderException("Unknown serializer type " + var3);
         }

         var1.add(new DataEntry(var4.createKey(var2), var4.read(var0)));
      }

      return var1;
   }

   public void setEntryValues(List<DataEntry<?>> var1) {
      this.lock.writeLock().lock();

      for(DataEntry var3 : var1) {
         DataEntry var4 = (DataEntry)this.entries.get(var3.getKey().getId());
         if (var4 != null) {
            this.setEntryValue(var4, var3);
            this.entity.notifyDataManagerChange(var3.getKey());
         }
      }

      this.lock.writeLock().unlock();
      this.dirty = true;
   }

   protected <T> void setEntryValue(DataEntry<T> var1, DataEntry<?> var2) {
      var1.setValue((T)var2.getValue());
   }

   public boolean isEmpty() {
      return this.empty;
   }

   public void setClean() {
      this.dirty = false;
      this.lock.readLock().lock();

      for(DataEntry var2 : this.entries.values()) {
         var2.setDirty(false);
      }

      this.lock.readLock().unlock();
   }

   public static class DataEntry<T> {
      private final DataParameter<T> key;
      private T value;
      private boolean dirty;

      public DataEntry(DataParameter<T> var1, T var2) {
         this.key = var1;
         this.value = var2;
         this.dirty = true;
      }

      public DataParameter<T> getKey() {
         return this.key;
      }

      public void setValue(T var1) {
         this.value = var1;
      }

      public T getValue() {
         return this.value;
      }

      public boolean isDirty() {
         return this.dirty;
      }

      public void setDirty(boolean var1) {
         this.dirty = var1;
      }

      public DataEntry<T> func_192735_d() {
         return new DataEntry<T>(this.key, this.key.getSerializer().func_192717_a(this.value));
      }

      static boolean access$002(DataEntry var0, boolean var1) {
         return var0.dirty = var1;
      }
   }
}
