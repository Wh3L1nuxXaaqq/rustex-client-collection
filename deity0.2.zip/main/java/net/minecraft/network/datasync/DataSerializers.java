package net.minecraft.network.datasync;

import com.google.common.base.Optional;
import java.io.IOException;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IntIdentityHashBiMap;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Rotations;
import net.minecraft.util.text.ITextComponent;

public class DataSerializers {
   private static final IntIdentityHashBiMap<DataSerializer<?>> REGISTRY = new IntIdentityHashBiMap<DataSerializer<?>>(16);
   public static final DataSerializer<Byte> BYTE = new DataSerializer<Byte>() {
      public void write(PacketBuffer var1, Byte var2) {
         var1.writeByte(var2);
      }

      public Byte read(PacketBuffer var1) throws IOException {
         return var1.readByte();
      }

      public DataParameter<Byte> createKey(int var1) {
         return new DataParameter<Byte>(var1, this);
      }

      public Byte func_192717_a(Byte var1) {
         return var1;
      }
   };
   public static final DataSerializer<Integer> VARINT = new DataSerializer<Integer>() {
      public void write(PacketBuffer var1, Integer var2) {
         var1.writeVarIntToBuffer(var2);
      }

      public Integer read(PacketBuffer var1) throws IOException {
         return var1.readVarIntFromBuffer();
      }

      public DataParameter<Integer> createKey(int var1) {
         return new DataParameter<Integer>(var1, this);
      }

      public Integer func_192717_a(Integer var1) {
         return var1;
      }
   };
   public static final DataSerializer<Float> FLOAT = new DataSerializer<Float>() {
      public void write(PacketBuffer var1, Float var2) {
         var1.writeFloat(var2);
      }

      public Float read(PacketBuffer var1) throws IOException {
         return var1.readFloat();
      }

      public DataParameter<Float> createKey(int var1) {
         return new DataParameter<Float>(var1, this);
      }

      public Float func_192717_a(Float var1) {
         return var1;
      }
   };
   public static final DataSerializer<String> STRING = new DataSerializer<String>() {
      public void write(PacketBuffer var1, String var2) {
         var1.writeString(var2);
      }

      public String read(PacketBuffer var1) throws IOException {
         return var1.readStringFromBuffer(32767);
      }

      public DataParameter<String> createKey(int var1) {
         return new DataParameter<String>(var1, this);
      }

      public String func_192717_a(String var1) {
         return var1;
      }
   };
   public static final DataSerializer<ITextComponent> TEXT_COMPONENT = new DataSerializer<ITextComponent>() {
      public void write(PacketBuffer var1, ITextComponent var2) {
         var1.writeTextComponent(var2);
      }

      public ITextComponent read(PacketBuffer var1) throws IOException {
         return var1.readTextComponent();
      }

      public DataParameter<ITextComponent> createKey(int var1) {
         return new DataParameter<ITextComponent>(var1, this);
      }

      public ITextComponent func_192717_a(ITextComponent var1) {
         return var1.createCopy();
      }
   };
   public static final DataSerializer<ItemStack> OPTIONAL_ITEM_STACK = new DataSerializer<ItemStack>() {
      public void write(PacketBuffer var1, ItemStack var2) {
         var1.writeItemStackToBuffer(var2);
      }

      public ItemStack read(PacketBuffer var1) throws IOException {
         return var1.readItemStackFromBuffer();
      }

      public DataParameter<ItemStack> createKey(int var1) {
         return new DataParameter<ItemStack>(var1, this);
      }

      public ItemStack func_192717_a(ItemStack var1) {
         return var1.copy();
      }
   };
   public static final DataSerializer<Optional<IBlockState>> OPTIONAL_BLOCK_STATE = new DataSerializer<Optional<IBlockState>>() {
      public void write(PacketBuffer var1, Optional<IBlockState> var2) {
         if (var2.isPresent()) {
            var1.writeVarIntToBuffer(Block.getStateId((IBlockState)var2.get()));
         } else {
            var1.writeVarIntToBuffer(0);
         }

      }

      public Optional<IBlockState> read(PacketBuffer var1) throws IOException {
         int var2 = var1.readVarIntFromBuffer();
         return var2 == 0 ? Optional.absent() : Optional.of(Block.getStateById(var2));
      }

      public DataParameter<Optional<IBlockState>> createKey(int var1) {
         return new DataParameter<Optional<IBlockState>>(var1, this);
      }

      public Optional<IBlockState> func_192717_a(Optional<IBlockState> var1) {
         return var1;
      }
   };
   public static final DataSerializer<Boolean> BOOLEAN = new DataSerializer<Boolean>() {
      public void write(PacketBuffer var1, Boolean var2) {
         var1.writeBoolean(var2);
      }

      public Boolean read(PacketBuffer var1) throws IOException {
         return var1.readBoolean();
      }

      public DataParameter<Boolean> createKey(int var1) {
         return new DataParameter<Boolean>(var1, this);
      }

      public Boolean func_192717_a(Boolean var1) {
         return var1;
      }
   };
   public static final DataSerializer<Rotations> ROTATIONS = new DataSerializer<Rotations>() {
      public void write(PacketBuffer var1, Rotations var2) {
         var1.writeFloat(var2.getX());
         var1.writeFloat(var2.getY());
         var1.writeFloat(var2.getZ());
      }

      public Rotations read(PacketBuffer var1) throws IOException {
         return new Rotations(var1.readFloat(), var1.readFloat(), var1.readFloat());
      }

      public DataParameter<Rotations> createKey(int var1) {
         return new DataParameter<Rotations>(var1, this);
      }

      public Rotations func_192717_a(Rotations var1) {
         return var1;
      }
   };
   public static final DataSerializer<BlockPos> BLOCK_POS = new DataSerializer<BlockPos>() {
      public void write(PacketBuffer var1, BlockPos var2) {
         var1.writeBlockPos(var2);
      }

      public BlockPos read(PacketBuffer var1) throws IOException {
         return var1.readBlockPos();
      }

      public DataParameter<BlockPos> createKey(int var1) {
         return new DataParameter<BlockPos>(var1, this);
      }

      public BlockPos func_192717_a(BlockPos var1) {
         return var1;
      }
   };
   public static final DataSerializer<Optional<BlockPos>> OPTIONAL_BLOCK_POS = new DataSerializer<Optional<BlockPos>>() {
      public void write(PacketBuffer var1, Optional<BlockPos> var2) {
         var1.writeBoolean(var2.isPresent());
         if (var2.isPresent()) {
            var1.writeBlockPos((BlockPos)var2.get());
         }

      }

      public Optional<BlockPos> read(PacketBuffer var1) throws IOException {
         return !var1.readBoolean() ? Optional.absent() : Optional.of(var1.readBlockPos());
      }

      public DataParameter<Optional<BlockPos>> createKey(int var1) {
         return new DataParameter<Optional<BlockPos>>(var1, this);
      }

      public Optional<BlockPos> func_192717_a(Optional<BlockPos> var1) {
         return var1;
      }
   };
   public static final DataSerializer<EnumFacing> FACING = new DataSerializer<EnumFacing>() {
      public void write(PacketBuffer var1, EnumFacing var2) {
         var1.writeEnumValue(var2);
      }

      public EnumFacing read(PacketBuffer var1) throws IOException {
         return (EnumFacing)var1.readEnumValue(EnumFacing.class);
      }

      public DataParameter<EnumFacing> createKey(int var1) {
         return new DataParameter<EnumFacing>(var1, this);
      }

      public EnumFacing func_192717_a(EnumFacing var1) {
         return var1;
      }
   };
   public static final DataSerializer<Optional<UUID>> OPTIONAL_UNIQUE_ID = new DataSerializer<Optional<UUID>>() {
      public void write(PacketBuffer var1, Optional<UUID> var2) {
         var1.writeBoolean(var2.isPresent());
         if (var2.isPresent()) {
            var1.writeUuid((UUID)var2.get());
         }

      }

      public Optional<UUID> read(PacketBuffer var1) throws IOException {
         return !var1.readBoolean() ? Optional.absent() : Optional.of(var1.readUuid());
      }

      public DataParameter<Optional<UUID>> createKey(int var1) {
         return new DataParameter<Optional<UUID>>(var1, this);
      }

      public Optional<UUID> func_192717_a(Optional<UUID> var1) {
         return var1;
      }
   };
   public static final DataSerializer<NBTTagCompound> field_192734_n = new DataSerializer<NBTTagCompound>() {
      public void write(PacketBuffer var1, NBTTagCompound var2) {
         var1.writeNBTTagCompoundToBuffer(var2);
      }

      public NBTTagCompound read(PacketBuffer var1) throws IOException {
         return var1.readNBTTagCompoundFromBuffer();
      }

      public DataParameter<NBTTagCompound> createKey(int var1) {
         return new DataParameter<NBTTagCompound>(var1, this);
      }

      public NBTTagCompound func_192717_a(NBTTagCompound var1) {
         return var1.copy();
      }
   };

   public static void registerSerializer(DataSerializer<?> var0) {
      REGISTRY.add(var0);
   }

   @Nullable
   public static DataSerializer<?> getSerializer(int var0) {
      return REGISTRY.get(var0);
   }

   public static int getSerializerId(DataSerializer<?> var0) {
      return REGISTRY.getId(var0);
   }

   static {
      registerSerializer(BYTE);
      registerSerializer(VARINT);
      registerSerializer(FLOAT);
      registerSerializer(STRING);
      registerSerializer(TEXT_COMPONENT);
      registerSerializer(OPTIONAL_ITEM_STACK);
      registerSerializer(BOOLEAN);
      registerSerializer(ROTATIONS);
      registerSerializer(BLOCK_POS);
      registerSerializer(OPTIONAL_BLOCK_POS);
      registerSerializer(FACING);
      registerSerializer(OPTIONAL_UNIQUE_ID);
      registerSerializer(OPTIONAL_BLOCK_STATE);
      registerSerializer(field_192734_n);
   }
}
