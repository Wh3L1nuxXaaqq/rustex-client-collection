package net.minecraft.inventory;

import java.util.Map;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ContainerRepair extends Container {
   private static final Logger LOGGER = LogManager.getLogger();
   private final IInventory outputSlot;
   private final IInventory inputSlots;
   private final World theWorld;
   private final BlockPos selfPosition;
   public int maximumCost;
   private int materialCost;
   private String repairedItemName;
   private final EntityPlayer thePlayer;

   public ContainerRepair(InventoryPlayer var1, World var2, EntityPlayer var3) {
      this(var1, var2, BlockPos.ORIGIN, var3);
   }

   public ContainerRepair(InventoryPlayer var1, final World var2, final BlockPos var3, EntityPlayer var4) {
      this.outputSlot = new InventoryCraftResult();
      this.inputSlots = new InventoryBasic("Repair", true, 2) {
         public void markDirty() {
            super.markDirty();
            ContainerRepair.this.onCraftMatrixChanged(this);
         }
      };
      this.selfPosition = var3;
      this.theWorld = var2;
      this.thePlayer = var4;
      this.addSlotToContainer(new Slot(this.inputSlots, 0, 27, 47));
      this.addSlotToContainer(new Slot(this.inputSlots, 1, 76, 47));
      this.addSlotToContainer(new Slot(this.outputSlot, 2, 134, 47) {
         public boolean isItemValid(ItemStack var1) {
            return false;
         }

         public boolean canTakeStack(EntityPlayer var1) {
            return (var1.capabilities.isCreativeMode || var1.experienceLevel >= ContainerRepair.this.maximumCost) && ContainerRepair.this.maximumCost > 0 && this.getHasStack();
         }

         public ItemStack func_190901_a(EntityPlayer var1, ItemStack var2x) {
            if (!var1.capabilities.isCreativeMode) {
               var1.addExperienceLevel(-ContainerRepair.this.maximumCost);
            }

            ContainerRepair.access$000(ContainerRepair.this).setInventorySlotContents(0, ItemStack.field_190927_a);
            if (ContainerRepair.access$100(ContainerRepair.this) > 0) {
               ItemStack var3x = ContainerRepair.access$000(ContainerRepair.this).getStackInSlot(1);
               if (!var3x.func_190926_b() && var3x.func_190916_E() > ContainerRepair.access$100(ContainerRepair.this)) {
                  var3x.func_190918_g(ContainerRepair.access$100(ContainerRepair.this));
                  ContainerRepair.access$000(ContainerRepair.this).setInventorySlotContents(1, var3x);
               } else {
                  ContainerRepair.access$000(ContainerRepair.this).setInventorySlotContents(1, ItemStack.field_190927_a);
               }
            } else {
               ContainerRepair.access$000(ContainerRepair.this).setInventorySlotContents(1, ItemStack.field_190927_a);
            }

            ContainerRepair.this.maximumCost = 0;
            IBlockState var5 = var2.getBlockState(var3);
            if (!var1.capabilities.isCreativeMode && !var2.isRemote && var5.getBlock() == Blocks.ANVIL && var1.getRNG().nextFloat() < 0.12F) {
               int var4 = (Integer)var5.getValue(BlockAnvil.DAMAGE);
               ++var4;
               if (var4 > 2) {
                  var2.setBlockToAir(var3);
                  var2.playEvent(1029, var3, 0);
               } else {
                  var2.setBlockState(var3, var5.withProperty(BlockAnvil.DAMAGE, var4), 2);
                  var2.playEvent(1030, var3, 0);
               }
            } else if (!var2.isRemote) {
               var2.playEvent(1030, var3, 0);
            }

            return var2x;
         }
      });

      for(int var5 = 0; var5 < 3; ++var5) {
         for(int var6 = 0; var6 < 9; ++var6) {
            this.addSlotToContainer(new Slot(var1, var6 + var5 * 9 + 9, 8 + var6 * 18, 84 + var5 * 18));
         }
      }

      for(int var7 = 0; var7 < 9; ++var7) {
         this.addSlotToContainer(new Slot(var1, var7, 8 + var7 * 18, 142));
      }

   }

   public void onCraftMatrixChanged(IInventory var1) {
      super.onCraftMatrixChanged(var1);
      if (var1 == this.inputSlots) {
         this.updateRepairOutput();
      }

   }

   public void updateRepairOutput() {
      ItemStack var1 = this.inputSlots.getStackInSlot(0);
      this.maximumCost = 1;
      int var2 = 0;
      int var3 = 0;
      byte var4 = 0;
      if (var1.func_190926_b()) {
         this.outputSlot.setInventorySlotContents(0, ItemStack.field_190927_a);
         this.maximumCost = 0;
      } else {
         ItemStack var5 = var1.copy();
         ItemStack var6 = this.inputSlots.getStackInSlot(1);
         Map var7 = EnchantmentHelper.getEnchantments(var5);
         var3 = var3 + var1.getRepairCost() + (var6.func_190926_b() ? 0 : var6.getRepairCost());
         this.materialCost = 0;
         if (!var6.func_190926_b()) {
            boolean var8 = var6.getItem() == Items.ENCHANTED_BOOK && !ItemEnchantedBook.getEnchantments(var6).hasNoTags();
            if (var5.isItemStackDamageable() && var5.getItem().getIsRepairable(var1, var6)) {
               int var22 = Math.min(var5.getItemDamage(), var5.getMaxDamage() / 4);
               if (var22 <= 0) {
                  this.outputSlot.setInventorySlotContents(0, ItemStack.field_190927_a);
                  this.maximumCost = 0;
                  return;
               }

               int var24;
               for(var24 = 0; var22 > 0 && var24 < var6.func_190916_E(); ++var24) {
                  int var26 = var5.getItemDamage() - var22;
                  var5.setItemDamage(var26);
                  ++var2;
                  var22 = Math.min(var5.getItemDamage(), var5.getMaxDamage() / 4);
               }

               this.materialCost = var24;
            } else {
               if (!var8 && (var5.getItem() != var6.getItem() || !var5.isItemStackDamageable())) {
                  this.outputSlot.setInventorySlotContents(0, ItemStack.field_190927_a);
                  this.maximumCost = 0;
                  return;
               }

               if (var5.isItemStackDamageable() && !var8) {
                  int var9 = var1.getMaxDamage() - var1.getItemDamage();
                  int var10 = var6.getMaxDamage() - var6.getItemDamage();
                  int var11 = var10 + var5.getMaxDamage() * 12 / 100;
                  int var12 = var9 + var11;
                  int var13 = var5.getMaxDamage() - var12;
                  if (var13 < 0) {
                     var13 = 0;
                  }

                  if (var13 < var5.getMetadata()) {
                     var5.setItemDamage(var13);
                     var2 += 2;
                  }
               }

               Map var21 = EnchantmentHelper.getEnchantments(var6);
               boolean var23 = false;
               boolean var25 = false;

               for(Object var28_raw : var21.keySet()) {
                  net.minecraft.enchantment.Enchantment var28 = (net.minecraft.enchantment.Enchantment)var28_raw;
                  if (var28 != null) {
                     int var14 = var7.containsKey(var28) ? (Integer)var7.get(var28) : 0;
                     int var15 = (Integer)var21.get(var28);
                     var15 = var14 == var15 ? var15 + 1 : Math.max(var15, var14);
                     boolean var16 = var28.canApply(var1);
                     if (this.thePlayer.capabilities.isCreativeMode || var1.getItem() == Items.ENCHANTED_BOOK) {
                        var16 = true;
                     }

                     for(Object var18_raw : var7.keySet()) {
                        net.minecraft.enchantment.Enchantment var18 = (net.minecraft.enchantment.Enchantment)var18_raw;
                        if (var18 != var28 && !var28.func_191560_c(var18)) {
                           var16 = false;
                           ++var2;
                        }
                     }

                     if (!var16) {
                        var25 = true;
                     } else {
                        var23 = true;
                        if (var15 > var28.getMaxLevel()) {
                           var15 = var28.getMaxLevel();
                        }

                        var7.put(var28, var15);
                        int var30 = 0;
                        switch (var28.getRarity()) {
                           case COMMON:
                              var30 = 1;
                              break;
                           case UNCOMMON:
                              var30 = 2;
                              break;
                           case RARE:
                              var30 = 4;
                              break;
                           case VERY_RARE:
                              var30 = 8;
                        }

                        if (var8) {
                           var30 = Math.max(1, var30 / 2);
                        }

                        var2 += var30 * var15;
                        if (var1.func_190916_E() > 1) {
                           var2 = 40;
                        }
                     }
                  }
               }

               if (var25 && !var23) {
                  this.outputSlot.setInventorySlotContents(0, ItemStack.field_190927_a);
                  this.maximumCost = 0;
                  return;
               }
            }
         }

         if (StringUtils.isBlank(this.repairedItemName)) {
            if (var1.hasDisplayName()) {
               var4 = 1;
               var2 += var4;
               var5.clearCustomName();
            }
         } else if (!this.repairedItemName.equals(var1.getDisplayName())) {
            var4 = 1;
            var2 += var4;
            var5.setStackDisplayName(this.repairedItemName);
         }

         this.maximumCost = var3 + var2;
         if (var2 <= 0) {
            var5 = ItemStack.field_190927_a;
         }

         if (var4 == var2 && var4 > 0 && this.maximumCost >= 40) {
            this.maximumCost = 39;
         }

         if (this.maximumCost >= 40 && !this.thePlayer.capabilities.isCreativeMode) {
            var5 = ItemStack.field_190927_a;
         }

         if (!var5.func_190926_b()) {
            int var20 = var5.getRepairCost();
            if (!var6.func_190926_b() && var20 < var6.getRepairCost()) {
               var20 = var6.getRepairCost();
            }

            if (var4 != var2 || var4 == 0) {
               var20 = var20 * 2 + 1;
            }

            var5.setRepairCost(var20);
            EnchantmentHelper.setEnchantments(var7, var5);
         }

         this.outputSlot.setInventorySlotContents(0, var5);
         this.detectAndSendChanges();
      }

   }

   public void addListener(IContainerListener var1) {
      super.addListener(var1);
      var1.sendProgressBarUpdate(this, 0, this.maximumCost);
   }

   public void updateProgressBar(int var1, int var2) {
      if (var1 == 0) {
         this.maximumCost = var2;
      }

   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      if (!this.theWorld.isRemote) {
         this.func_193327_a(var1, this.theWorld, this.inputSlots);
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      if (this.theWorld.getBlockState(this.selfPosition).getBlock() != Blocks.ANVIL) {
         return false;
      } else {
         return var1.getDistanceSq((double)this.selfPosition.getX() + (double)0.5F, (double)this.selfPosition.getY() + (double)0.5F, (double)this.selfPosition.getZ() + (double)0.5F) <= (double)64.0F;
      }
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if (var2 == 2) {
            if (!this.mergeItemStack(var5, 3, 39, true)) {
               return ItemStack.field_190927_a;
            }

            var4.onSlotChange(var5, var3);
         } else if (var2 != 0 && var2 != 1) {
            if (var2 >= 3 && var2 < 39 && !this.mergeItemStack(var5, 0, 2, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (!this.mergeItemStack(var5, 3, 39, false)) {
            return ItemStack.field_190927_a;
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }

         if (var5.func_190916_E() == var3.func_190916_E()) {
            return ItemStack.field_190927_a;
         }

         var4.func_190901_a(var1, var5);
      }

      return var3;
   }

   public void updateItemName(String var1) {
      this.repairedItemName = var1;
      if (this.getSlot(2).getHasStack()) {
         ItemStack var2 = this.getSlot(2).getStack();
         if (StringUtils.isBlank(var1)) {
            var2.clearCustomName();
         } else {
            var2.setStackDisplayName(this.repairedItemName);
         }
      }

      this.updateRepairOutput();
   }

   static IInventory access$000(ContainerRepair var0) {
      return var0.inputSlots;
   }

   static int access$100(ContainerRepair var0) {
      return var0.materialCost;
   }
}
