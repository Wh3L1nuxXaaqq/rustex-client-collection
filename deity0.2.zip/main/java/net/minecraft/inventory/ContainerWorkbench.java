package net.minecraft.inventory;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ContainerWorkbench extends Container {
   public InventoryCrafting craftMatrix = new InventoryCrafting(this, 3, 3);
   public InventoryCraftResult craftResult = new InventoryCraftResult();
   private final World worldObj;
   private final BlockPos pos;
   private final EntityPlayer field_192390_i;

   public ContainerWorkbench(InventoryPlayer var1, World var2, BlockPos var3) {
      this.worldObj = var2;
      this.pos = var3;
      this.field_192390_i = var1.player;
      this.addSlotToContainer(new SlotCrafting(var1.player, this.craftMatrix, this.craftResult, 0, 124, 35));

      for(int var4 = 0; var4 < 3; ++var4) {
         for(int var5 = 0; var5 < 3; ++var5) {
            this.addSlotToContainer(new Slot(this.craftMatrix, var5 + var4 * 3, 30 + var5 * 18, 17 + var4 * 18));
         }
      }

      for(int var6 = 0; var6 < 3; ++var6) {
         for(int var8 = 0; var8 < 9; ++var8) {
            this.addSlotToContainer(new Slot(var1, var8 + var6 * 9 + 9, 8 + var8 * 18, 84 + var6 * 18));
         }
      }

      for(int var7 = 0; var7 < 9; ++var7) {
         this.addSlotToContainer(new Slot(var1, var7, 8 + var7 * 18, 142));
      }

   }

   public void onCraftMatrixChanged(IInventory var1) {
      this.func_192389_a(this.worldObj, this.field_192390_i, this.craftMatrix, this.craftResult);
   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      if (!this.worldObj.isRemote) {
         this.func_193327_a(var1, this.worldObj, this.craftMatrix);
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      if (this.worldObj.getBlockState(this.pos).getBlock() != Blocks.CRAFTING_TABLE) {
         return false;
      } else {
         return var1.getDistanceSq((double)this.pos.getX() + (double)0.5F, (double)this.pos.getY() + (double)0.5F, (double)this.pos.getZ() + (double)0.5F) <= (double)64.0F;
      }
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if (var2 == 0) {
            var5.getItem().onCreated(var5, this.worldObj, var1);
            if (!this.mergeItemStack(var5, 10, 46, true)) {
               return ItemStack.field_190927_a;
            }

            var4.onSlotChange(var5, var3);
         } else if (var2 >= 10 && var2 < 37) {
            if (!this.mergeItemStack(var5, 37, 46, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var2 >= 37 && var2 < 46) {
            if (!this.mergeItemStack(var5, 10, 37, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (!this.mergeItemStack(var5, 10, 46, false)) {
            return ItemStack.field_190927_a;
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }

         if (var5.func_190916_E() == var3.func_190916_E()) {
            return ItemStack.field_190927_a;
         }

         ItemStack var6 = var4.func_190901_a(var1, var5);
         if (var2 == 0) {
            var1.dropItem(var6, false);
         }
      }

      return var3;
   }

   public boolean canMergeSlot(ItemStack var1, Slot var2) {
      return var2.inventory != this.craftResult && super.canMergeSlot(var1, var2);
   }
}
