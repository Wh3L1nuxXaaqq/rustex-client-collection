package net.minecraft.inventory;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class InventoryHelper {
   private static final Random RANDOM = new Random();

   public static void dropInventoryItems(World var0, BlockPos var1, IInventory var2) {
      dropInventoryItems(var0, (double)var1.getX(), (double)var1.getY(), (double)var1.getZ(), var2);
   }

   public static void dropInventoryItems(World var0, Entity var1, IInventory var2) {
      dropInventoryItems(var0, var1.posX, var1.posY, var1.posZ, var2);
   }

   private static void dropInventoryItems(World var0, double var1, double var3, double var5, IInventory var7) {
      for(int var8 = 0; var8 < var7.getSizeInventory(); ++var8) {
         ItemStack var9 = var7.getStackInSlot(var8);
         if (!var9.func_190926_b()) {
            spawnItemStack(var0, var1, var3, var5, var9);
         }
      }

   }

   public static void spawnItemStack(World var0, double var1, double var3, double var5, ItemStack var7) {
      float var8 = RANDOM.nextFloat() * 0.8F + 0.1F;
      float var9 = RANDOM.nextFloat() * 0.8F + 0.1F;
      float var10 = RANDOM.nextFloat() * 0.8F + 0.1F;

      while(!var7.func_190926_b()) {
         EntityItem var11 = new EntityItem(var0, var1 + (double)var8, var3 + (double)var9, var5 + (double)var10, var7.splitStack(RANDOM.nextInt(21) + 10));
         float var12 = 0.05F;
         var11.motionX = RANDOM.nextGaussian() * (double)0.05F;
         var11.motionY = RANDOM.nextGaussian() * (double)0.05F + (double)0.2F;
         var11.motionZ = RANDOM.nextGaussian() * (double)0.05F;
         var0.spawnEntityInWorld(var11);
      }

   }
}
