package net.minecraft.inventory;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public abstract class Container {
   public NonNullList<ItemStack> inventoryItemStacks = NonNullList.<ItemStack>func_191196_a();
   public List<Slot> inventorySlots = Lists.newArrayList();
   public int windowId;
   private short transactionID;
   private int dragMode = -1;
   private int dragEvent;
   private final Set<Slot> dragSlots = Sets.newHashSet();
   protected List<IContainerListener> listeners = Lists.newArrayList();
   private final Set<EntityPlayer> playerList = Sets.newHashSet();

   protected Slot addSlotToContainer(Slot var1) {
      var1.slotNumber = this.inventorySlots.size();
      this.inventorySlots.add(var1);
      this.inventoryItemStacks.add(ItemStack.field_190927_a);
      return var1;
   }

   public void addListener(IContainerListener var1) {
      if (this.listeners.contains(var1)) {
         throw new IllegalArgumentException("Listener already listening");
      } else {
         this.listeners.add(var1);
         var1.updateCraftingInventory(this, this.getInventory());
         this.detectAndSendChanges();
      }
   }

   public void removeListener(IContainerListener var1) {
      this.listeners.remove(var1);
   }

   public NonNullList<ItemStack> getInventory() {
      NonNullList var1 = NonNullList.func_191196_a();

      for(int var2 = 0; var2 < this.inventorySlots.size(); ++var2) {
         var1.add(((Slot)this.inventorySlots.get(var2)).getStack());
      }

      return var1;
   }

   public void detectAndSendChanges() {
      for(int var1 = 0; var1 < this.inventorySlots.size(); ++var1) {
         ItemStack var2 = ((Slot)this.inventorySlots.get(var1)).getStack();
         ItemStack var3 = this.inventoryItemStacks.get(var1);
         if (!ItemStack.areItemStacksEqual(var3, var2)) {
            var3 = var2.func_190926_b() ? ItemStack.field_190927_a : var2.copy();
            this.inventoryItemStacks.set(var1, var3);

            for(int var4 = 0; var4 < this.listeners.size(); ++var4) {
               ((IContainerListener)this.listeners.get(var4)).sendSlotContents(this, var1, var3);
            }
         }
      }

   }

   public boolean enchantItem(EntityPlayer var1, int var2) {
      return false;
   }

   @Nullable
   public Slot getSlotFromInventory(IInventory var1, int var2) {
      for(int var3 = 0; var3 < this.inventorySlots.size(); ++var3) {
         Slot var4 = (Slot)this.inventorySlots.get(var3);
         if (var4.isHere(var1, var2)) {
            return var4;
         }
      }

      return null;
   }

   public Slot getSlot(int var1) {
      return (Slot)this.inventorySlots.get(var1);
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      Slot var3 = (Slot)this.inventorySlots.get(var2);
      return var3 != null ? var3.getStack() : ItemStack.field_190927_a;
   }

   public ItemStack slotClick(int var1, int var2, ClickType var3, EntityPlayer var4) {
      ItemStack var5 = ItemStack.field_190927_a;
      InventoryPlayer var6 = var4.inventory;
      if (var3 == ClickType.QUICK_CRAFT) {
         int var22 = this.dragEvent;
         this.dragEvent = getDragEvent(var2);
         if ((var22 != 1 || this.dragEvent != 2) && var22 != this.dragEvent) {
            this.resetDrag();
         } else if (var6.getItemStack().func_190926_b()) {
            this.resetDrag();
         } else if (this.dragEvent == 0) {
            this.dragMode = extractDragMode(var2);
            if (isValidDragMode(this.dragMode, var4)) {
               this.dragEvent = 1;
               this.dragSlots.clear();
            } else {
               this.resetDrag();
            }
         } else if (this.dragEvent == 1) {
            Slot var29 = (Slot)this.inventorySlots.get(var1);
            ItemStack var33 = var6.getItemStack();
            if (var29 != null && canAddItemToSlot(var29, var33, true) && var29.isItemValid(var33) && (this.dragMode == 2 || var33.func_190916_E() > this.dragSlots.size()) && this.canDragIntoSlot(var29)) {
               this.dragSlots.add(var29);
            }
         } else if (this.dragEvent == 2) {
            if (!this.dragSlots.isEmpty()) {
               ItemStack var30 = var6.getItemStack().copy();
               int var34 = var6.getItemStack().func_190916_E();

               for(Slot var42 : this.dragSlots) {
                  ItemStack var43 = var6.getItemStack();
                  if (var42 != null && canAddItemToSlot(var42, var43, true) && var42.isItemValid(var43) && (this.dragMode == 2 || var43.func_190916_E() >= this.dragSlots.size()) && this.canDragIntoSlot(var42)) {
                     ItemStack var44 = var30.copy();
                     int var45 = var42.getHasStack() ? var42.getStack().func_190916_E() : 0;
                     computeStackSize(this.dragSlots, this.dragMode, var44, var45);
                     int var46 = Math.min(var44.getMaxStackSize(), var42.getItemStackLimit(var44));
                     if (var44.func_190916_E() > var46) {
                        var44.func_190920_e(var46);
                     }

                     var34 -= var44.func_190916_E() - var45;
                     var42.putStack(var44);
                  }
               }

               var30.func_190920_e(var34);
               var6.setItemStack(var30);
            }

            this.resetDrag();
         } else {
            this.resetDrag();
         }
      } else if (this.dragEvent != 0) {
         this.resetDrag();
      } else if ((var3 == ClickType.PICKUP || var3 == ClickType.QUICK_MOVE) && (var2 == 0 || var2 == 1)) {
         if (var1 == -999) {
            if (!var6.getItemStack().func_190926_b()) {
               if (var2 == 0) {
                  var4.dropItem(var6.getItemStack(), true);
                  var6.setItemStack(ItemStack.field_190927_a);
               }

               if (var2 == 1) {
                  var4.dropItem(var6.getItemStack().splitStack(1), true);
               }
            }
         } else if (var3 == ClickType.QUICK_MOVE) {
            if (var1 < 0) {
               return ItemStack.field_190927_a;
            }

            Slot var20 = (Slot)this.inventorySlots.get(var1);
            if (var20 == null || !var20.canTakeStack(var4)) {
               return ItemStack.field_190927_a;
            }

            for(ItemStack var26 = this.transferStackInSlot(var4, var1); !var26.func_190926_b() && ItemStack.areItemsEqual(var20.getStack(), var26); var26 = this.transferStackInSlot(var4, var1)) {
               var5 = var26.copy();
            }
         } else {
            if (var1 < 0) {
               return ItemStack.field_190927_a;
            }

            Slot var21 = (Slot)this.inventorySlots.get(var1);
            if (var21 != null) {
               ItemStack var27 = var21.getStack();
               ItemStack var32 = var6.getItemStack();
               if (!var27.func_190926_b()) {
                  var5 = var27.copy();
               }

               if (var27.func_190926_b()) {
                  if (!var32.func_190926_b() && var21.isItemValid(var32)) {
                     int var40 = var2 == 0 ? var32.func_190916_E() : 1;
                     if (var40 > var21.getItemStackLimit(var32)) {
                        var40 = var21.getItemStackLimit(var32);
                     }

                     var21.putStack(var32.splitStack(var40));
                  }
               } else if (var21.canTakeStack(var4)) {
                  if (var32.func_190926_b()) {
                     if (var27.func_190926_b()) {
                        var21.putStack(ItemStack.field_190927_a);
                        var6.setItemStack(ItemStack.field_190927_a);
                     } else {
                        int var39 = var2 == 0 ? var27.func_190916_E() : (var27.func_190916_E() + 1) / 2;
                        var6.setItemStack(var21.decrStackSize(var39));
                        if (var27.func_190926_b()) {
                           var21.putStack(ItemStack.field_190927_a);
                        }

                        var21.func_190901_a(var4, var6.getItemStack());
                     }
                  } else if (var21.isItemValid(var32)) {
                     if (var27.getItem() == var32.getItem() && var27.getMetadata() == var32.getMetadata() && ItemStack.areItemStackTagsEqual(var27, var32)) {
                        int var38 = var2 == 0 ? var32.func_190916_E() : 1;
                        if (var38 > var21.getItemStackLimit(var32) - var27.func_190916_E()) {
                           var38 = var21.getItemStackLimit(var32) - var27.func_190916_E();
                        }

                        if (var38 > var32.getMaxStackSize() - var27.func_190916_E()) {
                           var38 = var32.getMaxStackSize() - var27.func_190916_E();
                        }

                        var32.func_190918_g(var38);
                        var27.func_190917_f(var38);
                     } else if (var32.func_190916_E() <= var21.getItemStackLimit(var32)) {
                        var21.putStack(var32);
                        var6.setItemStack(var27);
                     }
                  } else if (var27.getItem() == var32.getItem() && var32.getMaxStackSize() > 1 && (!var27.getHasSubtypes() || var27.getMetadata() == var32.getMetadata()) && ItemStack.areItemStackTagsEqual(var27, var32) && !var27.func_190926_b()) {
                     int var37 = var27.func_190916_E();
                     if (var37 + var32.func_190916_E() <= var32.getMaxStackSize()) {
                        var32.func_190917_f(var37);
                        var27 = var21.decrStackSize(var37);
                        if (var27.func_190926_b()) {
                           var21.putStack(ItemStack.field_190927_a);
                        }

                        var21.func_190901_a(var4, var6.getItemStack());
                     }
                  }
               }

               var21.onSlotChanged();
            }
         }
      } else if (var3 == ClickType.SWAP && var2 >= 0 && var2 < 9) {
         Slot var19 = (Slot)this.inventorySlots.get(var1);
         ItemStack var25 = var6.getStackInSlot(var2);
         ItemStack var31 = var19.getStack();
         if (!var25.func_190926_b() || !var31.func_190926_b()) {
            if (var25.func_190926_b()) {
               if (var19.canTakeStack(var4)) {
                  var6.setInventorySlotContents(var2, var31);
                  var19.func_190900_b(var31.func_190916_E());
                  var19.putStack(ItemStack.field_190927_a);
                  var19.func_190901_a(var4, var31);
               }
            } else if (var31.func_190926_b()) {
               if (var19.isItemValid(var25)) {
                  int var35 = var19.getItemStackLimit(var25);
                  if (var25.func_190916_E() > var35) {
                     var19.putStack(var25.splitStack(var35));
                  } else {
                     var19.putStack(var25);
                     var6.setInventorySlotContents(var2, ItemStack.field_190927_a);
                  }
               }
            } else if (var19.canTakeStack(var4) && var19.isItemValid(var25)) {
               int var36 = var19.getItemStackLimit(var25);
               if (var25.func_190916_E() > var36) {
                  var19.putStack(var25.splitStack(var36));
                  var19.func_190901_a(var4, var31);
                  if (!var6.addItemStackToInventory(var31)) {
                     var4.dropItem(var31, true);
                  }
               } else {
                  var19.putStack(var25);
                  var6.setInventorySlotContents(var2, var31);
                  var19.func_190901_a(var4, var31);
               }
            }
         }
      } else if (var3 == ClickType.CLONE && var4.capabilities.isCreativeMode && var6.getItemStack().func_190926_b() && var1 >= 0) {
         Slot var18 = (Slot)this.inventorySlots.get(var1);
         if (var18 != null && var18.getHasStack()) {
            ItemStack var24 = var18.getStack().copy();
            var24.func_190920_e(var24.getMaxStackSize());
            var6.setItemStack(var24);
         }
      } else if (var3 == ClickType.THROW && var6.getItemStack().func_190926_b() && var1 >= 0) {
         Slot var17 = (Slot)this.inventorySlots.get(var1);
         if (var17 != null && var17.getHasStack() && var17.canTakeStack(var4)) {
            ItemStack var23 = var17.decrStackSize(var2 == 0 ? 1 : var17.getStack().func_190916_E());
            var17.func_190901_a(var4, var23);
            var4.dropItem(var23, true);
         }
      } else if (var3 == ClickType.PICKUP_ALL && var1 >= 0) {
         Slot var7 = (Slot)this.inventorySlots.get(var1);
         ItemStack var8 = var6.getItemStack();
         if (!var8.func_190926_b() && (var7 == null || !var7.getHasStack() || !var7.canTakeStack(var4))) {
            int var9 = var2 == 0 ? 0 : this.inventorySlots.size() - 1;
            int var10 = var2 == 0 ? 1 : -1;

            for(int var11 = 0; var11 < 2; ++var11) {
               for(int var12 = var9; var12 >= 0 && var12 < this.inventorySlots.size() && var8.func_190916_E() < var8.getMaxStackSize(); var12 += var10) {
                  Slot var13 = (Slot)this.inventorySlots.get(var12);
                  if (var13.getHasStack() && canAddItemToSlot(var13, var8, true) && var13.canTakeStack(var4) && this.canMergeSlot(var8, var13)) {
                     ItemStack var14 = var13.getStack();
                     if (var11 != 0 || var14.func_190916_E() != var14.getMaxStackSize()) {
                        int var15 = Math.min(var8.getMaxStackSize() - var8.func_190916_E(), var14.func_190916_E());
                        ItemStack var16 = var13.decrStackSize(var15);
                        var8.func_190917_f(var15);
                        if (var16.func_190926_b()) {
                           var13.putStack(ItemStack.field_190927_a);
                        }

                        var13.func_190901_a(var4, var16);
                     }
                  }
               }
            }
         }

         this.detectAndSendChanges();
      }

      return var5;
   }

   public boolean canMergeSlot(ItemStack var1, Slot var2) {
      return true;
   }

   public void onContainerClosed(EntityPlayer var1) {
      InventoryPlayer var2 = var1.inventory;
      if (!var2.getItemStack().func_190926_b()) {
         var1.dropItem(var2.getItemStack(), false);
         var2.setItemStack(ItemStack.field_190927_a);
      }

   }

   protected void func_193327_a(EntityPlayer var1, World var2, IInventory var3) {
      if (!var1.isEntityAlive() || var1 instanceof EntityPlayerMP && ((EntityPlayerMP)var1).func_193105_t()) {
         for(int var5 = 0; var5 < var3.getSizeInventory(); ++var5) {
            var1.dropItem(var3.removeStackFromSlot(var5), false);
         }
      } else {
         for(int var4 = 0; var4 < var3.getSizeInventory(); ++var4) {
            var1.inventory.func_191975_a(var2, var3.removeStackFromSlot(var4));
         }
      }

   }

   public void onCraftMatrixChanged(IInventory var1) {
      this.detectAndSendChanges();
   }

   public void putStackInSlot(int var1, ItemStack var2) {
      this.getSlot(var1).putStack(var2);
   }

   public void func_190896_a(List<ItemStack> var1) {
      for(int var2 = 0; var2 < var1.size(); ++var2) {
         this.getSlot(var2).putStack((ItemStack)var1.get(var2));
      }

   }

   public void updateProgressBar(int var1, int var2) {
   }

   public short getNextTransactionID(InventoryPlayer var1) {
      ++this.transactionID;
      return this.transactionID;
   }

   public boolean getCanCraft(EntityPlayer var1) {
      return !this.playerList.contains(var1);
   }

   public void setCanCraft(EntityPlayer var1, boolean var2) {
      if (var2) {
         this.playerList.remove(var1);
      } else {
         this.playerList.add(var1);
      }

   }

   public abstract boolean canInteractWith(EntityPlayer var1);

   protected boolean mergeItemStack(ItemStack var1, int var2, int var3, boolean var4) {
      boolean var5 = false;
      int var6 = var2;
      if (var4) {
         var6 = var3 - 1;
      }

      if (var1.isStackable()) {
         while(!var1.func_190926_b()) {
            if (var4) {
               if (var6 < var2) {
                  break;
               }
            } else if (var6 >= var3) {
               break;
            }

            Slot var7 = (Slot)this.inventorySlots.get(var6);
            ItemStack var8 = var7.getStack();
            if (!var8.func_190926_b() && var8.getItem() == var1.getItem() && (!var1.getHasSubtypes() || var1.getMetadata() == var8.getMetadata()) && ItemStack.areItemStackTagsEqual(var1, var8)) {
               int var9 = var8.func_190916_E() + var1.func_190916_E();
               if (var9 <= var1.getMaxStackSize()) {
                  var1.func_190920_e(0);
                  var8.func_190920_e(var9);
                  var7.onSlotChanged();
                  var5 = true;
               } else if (var8.func_190916_E() < var1.getMaxStackSize()) {
                  var1.func_190918_g(var1.getMaxStackSize() - var8.func_190916_E());
                  var8.func_190920_e(var1.getMaxStackSize());
                  var7.onSlotChanged();
                  var5 = true;
               }
            }

            if (var4) {
               --var6;
            } else {
               ++var6;
            }
         }
      }

      if (!var1.func_190926_b()) {
         if (var4) {
            var6 = var3 - 1;
         } else {
            var6 = var2;
         }

         while(true) {
            if (var4) {
               if (var6 < var2) {
                  break;
               }
            } else if (var6 >= var3) {
               break;
            }

            Slot var11 = (Slot)this.inventorySlots.get(var6);
            ItemStack var12 = var11.getStack();
            if (var12.func_190926_b() && var11.isItemValid(var1)) {
               if (var1.func_190916_E() > var11.getSlotStackLimit()) {
                  var11.putStack(var1.splitStack(var11.getSlotStackLimit()));
               } else {
                  var11.putStack(var1.splitStack(var1.func_190916_E()));
               }

               var11.onSlotChanged();
               var5 = true;
               break;
            }

            if (var4) {
               --var6;
            } else {
               ++var6;
            }
         }
      }

      return var5;
   }

   public static int extractDragMode(int var0) {
      return var0 >> 2 & 3;
   }

   public static int getDragEvent(int var0) {
      return var0 & 3;
   }

   public static int getQuickcraftMask(int var0, int var1) {
      return var0 & 3 | (var1 & 3) << 2;
   }

   public static boolean isValidDragMode(int var0, EntityPlayer var1) {
      if (var0 == 0) {
         return true;
      } else if (var0 == 1) {
         return true;
      } else {
         return var0 == 2 && var1.capabilities.isCreativeMode;
      }
   }

   protected void resetDrag() {
      this.dragEvent = 0;
      this.dragSlots.clear();
   }

   public static boolean canAddItemToSlot(@Nullable Slot var0, ItemStack var1, boolean var2) {
      boolean var3 = var0 == null || !var0.getHasStack();
      if (!var3 && var1.isItemEqual(var0.getStack()) && ItemStack.areItemStackTagsEqual(var0.getStack(), var1)) {
         return var0.getStack().func_190916_E() + (var2 ? 0 : var1.func_190916_E()) <= var1.getMaxStackSize();
      } else {
         return var3;
      }
   }

   public static void computeStackSize(Set<Slot> var0, int var1, ItemStack var2, int var3) {
      switch (var1) {
         case 0:
            var2.func_190920_e(MathHelper.floor((float)var2.func_190916_E() / (float)var0.size()));
            break;
         case 1:
            var2.func_190920_e(1);
            break;
         case 2:
            var2.func_190920_e(var2.getItem().getItemStackLimit());
      }

      var2.func_190917_f(var3);
   }

   public boolean canDragIntoSlot(Slot var1) {
      return true;
   }

   public static int calcRedstone(@Nullable TileEntity var0) {
      return var0 instanceof IInventory ? calcRedstoneFromInventory((IInventory)var0) : 0;
   }

   public static int calcRedstoneFromInventory(@Nullable IInventory var0) {
      if (var0 == null) {
         return 0;
      } else {
         int var1 = 0;
         float var2 = 0.0F;

         for(int var3 = 0; var3 < var0.getSizeInventory(); ++var3) {
            ItemStack var4 = var0.getStackInSlot(var3);
            if (!var4.func_190926_b()) {
               var2 += (float)var4.func_190916_E() / (float)Math.min(var0.getInventoryStackLimit(), var4.getMaxStackSize());
               ++var1;
            }
         }

         var2 /= (float)var0.getSizeInventory();
         return MathHelper.floor(var2 * 14.0F) + (var1 > 0 ? 1 : 0);
      }
   }

   protected void func_192389_a(World var1, EntityPlayer var2, InventoryCrafting var3, InventoryCraftResult var4) {
      if (!var1.isRemote) {
         EntityPlayerMP var5 = (EntityPlayerMP)var2;
         ItemStack var6 = ItemStack.field_190927_a;
         IRecipe var7 = CraftingManager.func_192413_b(var3, var1);
         if (var7 != null && (var7.func_192399_d() || !var1.getGameRules().getBoolean("doLimitedCrafting") || var5.func_192037_E().func_193830_f(var7))) {
            var4.func_193056_a(var7);
            var6 = var7.getCraftingResult(var3);
         }

         var4.setInventorySlotContents(0, var6);
         var5.connection.sendPacket(new SPacketSetSlot(this.windowId, 0, var6));
      }

   }
}
