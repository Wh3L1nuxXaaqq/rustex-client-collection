package net.minecraft.inventory;

import com.google.common.collect.Lists;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;

public class SlotCrafting extends Slot {
   private final InventoryCrafting craftMatrix;
   private final EntityPlayer thePlayer;
   private int amountCrafted;

   public SlotCrafting(EntityPlayer var1, InventoryCrafting var2, IInventory var3, int var4, int var5, int var6) {
      super(var3, var4, var5, var6);
      this.thePlayer = var1;
      this.craftMatrix = var2;
   }

   public boolean isItemValid(ItemStack var1) {
      return false;
   }

   public ItemStack decrStackSize(int var1) {
      if (this.getHasStack()) {
         this.amountCrafted += Math.min(var1, this.getStack().func_190916_E());
      }

      return super.decrStackSize(var1);
   }

   protected void onCrafting(ItemStack var1, int var2) {
      this.amountCrafted += var2;
      this.onCrafting(var1);
   }

   protected void func_190900_b(int var1) {
      this.amountCrafted += var1;
   }

   protected void onCrafting(ItemStack var1) {
      if (this.amountCrafted > 0) {
         var1.onCrafting(this.thePlayer.world, this.thePlayer, this.amountCrafted);
      }

      this.amountCrafted = 0;
      InventoryCraftResult var2 = (InventoryCraftResult)this.inventory;
      IRecipe var3 = var2.func_193055_i();
      if (var3 != null && !var3.func_192399_d()) {
         this.thePlayer.func_192021_a(Lists.newArrayList(new IRecipe[]{var3}));
         var2.func_193056_a((IRecipe)null);
      }

   }

   public ItemStack func_190901_a(EntityPlayer var1, ItemStack var2) {
      this.onCrafting(var2);
      NonNullList var3 = CraftingManager.getRemainingItems(this.craftMatrix, var1.world);

      for(int var4 = 0; var4 < var3.size(); ++var4) {
         ItemStack var5 = this.craftMatrix.getStackInSlot(var4);
         ItemStack var6 = (ItemStack)var3.get(var4);
         if (!var5.func_190926_b()) {
            this.craftMatrix.decrStackSize(var4, 1);
            var5 = this.craftMatrix.getStackInSlot(var4);
         }

         if (!var6.func_190926_b()) {
            if (var5.func_190926_b()) {
               this.craftMatrix.setInventorySlotContents(var4, var6);
            } else if (ItemStack.areItemsEqual(var5, var6) && ItemStack.areItemStackTagsEqual(var5, var6)) {
               var6.func_190917_f(var5.func_190916_E());
               this.craftMatrix.setInventorySlotContents(var4, var6);
            } else if (!this.thePlayer.inventory.addItemStackToInventory(var6)) {
               this.thePlayer.dropItem(var6, false);
            }
         }
      }

      return var2;
   }
}
