package net.minecraft.inventory;

import java.util.List;
import java.util.Random;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentData;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ContainerEnchantment extends Container {
   public IInventory tableInventory;
   private final World worldPointer;
   private final BlockPos position;
   private final Random rand;
   public int xpSeed;
   public int[] enchantLevels;
   public int[] enchantClue;
   public int[] worldClue;

   public ContainerEnchantment(InventoryPlayer var1, World var2) {
      this(var1, var2, BlockPos.ORIGIN);
   }

   public ContainerEnchantment(InventoryPlayer var1, World var2, BlockPos var3) {
      this.tableInventory = new InventoryBasic("Enchant", true, 2) {
         public int getInventoryStackLimit() {
            return 64;
         }

         public void markDirty() {
            super.markDirty();
            ContainerEnchantment.this.onCraftMatrixChanged(this);
         }
      };
      this.rand = new Random();
      this.enchantLevels = new int[3];
      this.enchantClue = new int[]{-1, -1, -1};
      this.worldClue = new int[]{-1, -1, -1};
      this.worldPointer = var2;
      this.position = var3;
      this.xpSeed = var1.player.getXPSeed();
      this.addSlotToContainer(new Slot(this.tableInventory, 0, 15, 47) {
         public boolean isItemValid(ItemStack var1) {
            return true;
         }

         public int getSlotStackLimit() {
            return 1;
         }
      });
      this.addSlotToContainer(new Slot(this.tableInventory, 1, 35, 47) {
         public boolean isItemValid(ItemStack var1) {
            return var1.getItem() == Items.DYE && EnumDyeColor.byDyeDamage(var1.getMetadata()) == EnumDyeColor.BLUE;
         }
      });

      for(int var4 = 0; var4 < 3; ++var4) {
         for(int var5 = 0; var5 < 9; ++var5) {
            this.addSlotToContainer(new Slot(var1, var5 + var4 * 9 + 9, 8 + var5 * 18, 84 + var4 * 18));
         }
      }

      for(int var6 = 0; var6 < 9; ++var6) {
         this.addSlotToContainer(new Slot(var1, var6, 8 + var6 * 18, 142));
      }

   }

   protected void broadcastData(IContainerListener var1) {
      var1.sendProgressBarUpdate(this, 0, this.enchantLevels[0]);
      var1.sendProgressBarUpdate(this, 1, this.enchantLevels[1]);
      var1.sendProgressBarUpdate(this, 2, this.enchantLevels[2]);
      var1.sendProgressBarUpdate(this, 3, this.xpSeed & -16);
      var1.sendProgressBarUpdate(this, 4, this.enchantClue[0]);
      var1.sendProgressBarUpdate(this, 5, this.enchantClue[1]);
      var1.sendProgressBarUpdate(this, 6, this.enchantClue[2]);
      var1.sendProgressBarUpdate(this, 7, this.worldClue[0]);
      var1.sendProgressBarUpdate(this, 8, this.worldClue[1]);
      var1.sendProgressBarUpdate(this, 9, this.worldClue[2]);
   }

   public void addListener(IContainerListener var1) {
      super.addListener(var1);
      this.broadcastData(var1);
   }

   public void detectAndSendChanges() {
      super.detectAndSendChanges();

      for(int var1 = 0; var1 < this.listeners.size(); ++var1) {
         IContainerListener var2 = (IContainerListener)this.listeners.get(var1);
         this.broadcastData(var2);
      }

   }

   public void updateProgressBar(int var1, int var2) {
      if (var1 >= 0 && var1 <= 2) {
         this.enchantLevels[var1] = var2;
      } else if (var1 == 3) {
         this.xpSeed = var2;
      } else if (var1 >= 4 && var1 <= 6) {
         this.enchantClue[var1 - 4] = var2;
      } else if (var1 >= 7 && var1 <= 9) {
         this.worldClue[var1 - 7] = var2;
      } else {
         super.updateProgressBar(var1, var2);
      }

   }

   public void onCraftMatrixChanged(IInventory var1) {
      if (var1 == this.tableInventory) {
         ItemStack var2 = var1.getStackInSlot(0);
         if (!var2.func_190926_b() && var2.isItemEnchantable()) {
            if (!this.worldPointer.isRemote) {
               int var7 = 0;

               for(int var4 = -1; var4 <= 1; ++var4) {
                  for(int var5 = -1; var5 <= 1; ++var5) {
                     if ((var4 != 0 || var5 != 0) && this.worldPointer.isAirBlock(this.position.add(var5, 0, var4)) && this.worldPointer.isAirBlock(this.position.add(var5, 1, var4))) {
                        if (this.worldPointer.getBlockState(this.position.add(var5 * 2, 0, var4 * 2)).getBlock() == Blocks.BOOKSHELF) {
                           ++var7;
                        }

                        if (this.worldPointer.getBlockState(this.position.add(var5 * 2, 1, var4 * 2)).getBlock() == Blocks.BOOKSHELF) {
                           ++var7;
                        }

                        if (var5 != 0 && var4 != 0) {
                           if (this.worldPointer.getBlockState(this.position.add(var5 * 2, 0, var4)).getBlock() == Blocks.BOOKSHELF) {
                              ++var7;
                           }

                           if (this.worldPointer.getBlockState(this.position.add(var5 * 2, 1, var4)).getBlock() == Blocks.BOOKSHELF) {
                              ++var7;
                           }

                           if (this.worldPointer.getBlockState(this.position.add(var5, 0, var4 * 2)).getBlock() == Blocks.BOOKSHELF) {
                              ++var7;
                           }

                           if (this.worldPointer.getBlockState(this.position.add(var5, 1, var4 * 2)).getBlock() == Blocks.BOOKSHELF) {
                              ++var7;
                           }
                        }
                     }
                  }
               }

               this.rand.setSeed((long)this.xpSeed);

               for(int var8 = 0; var8 < 3; ++var8) {
                  this.enchantLevels[var8] = EnchantmentHelper.calcItemStackEnchantability(this.rand, var8, var7, var2);
                  this.enchantClue[var8] = -1;
                  this.worldClue[var8] = -1;
                  if (this.enchantLevels[var8] < var8 + 1) {
                     this.enchantLevels[var8] = 0;
                  }
               }

               for(int var9 = 0; var9 < 3; ++var9) {
                  if (this.enchantLevels[var9] > 0) {
                     List var10 = this.getEnchantmentList(var2, var9, this.enchantLevels[var9]);
                     if (var10 != null && !var10.isEmpty()) {
                        EnchantmentData var6 = (EnchantmentData)var10.get(this.rand.nextInt(var10.size()));
                        this.enchantClue[var9] = Enchantment.getEnchantmentID(var6.enchantmentobj);
                        this.worldClue[var9] = var6.enchantmentLevel;
                     }
                  }
               }

               this.detectAndSendChanges();
            }
         } else {
            for(int var3 = 0; var3 < 3; ++var3) {
               this.enchantLevels[var3] = 0;
               this.enchantClue[var3] = -1;
               this.worldClue[var3] = -1;
            }
         }
      }

   }

   public boolean enchantItem(EntityPlayer var1, int var2) {
      ItemStack var3 = this.tableInventory.getStackInSlot(0);
      ItemStack var4 = this.tableInventory.getStackInSlot(1);
      int var5 = var2 + 1;
      if ((var4.func_190926_b() || var4.func_190916_E() < var5) && !var1.capabilities.isCreativeMode) {
         return false;
      } else if (this.enchantLevels[var2] > 0 && !var3.func_190926_b() && (var1.experienceLevel >= var5 && var1.experienceLevel >= this.enchantLevels[var2] || var1.capabilities.isCreativeMode)) {
         if (!this.worldPointer.isRemote) {
            List var6 = this.getEnchantmentList(var3, var2, this.enchantLevels[var2]);
            if (!var6.isEmpty()) {
               var1.func_192024_a(var3, var5);
               boolean var7 = var3.getItem() == Items.BOOK;
               if (var7) {
                  var3 = new ItemStack(Items.ENCHANTED_BOOK);
                  this.tableInventory.setInventorySlotContents(0, var3);
               }

               for(int var8 = 0; var8 < var6.size(); ++var8) {
                  EnchantmentData var9 = (EnchantmentData)var6.get(var8);
                  if (var7) {
                     ItemEnchantedBook.addEnchantment(var3, var9);
                  } else {
                     var3.addEnchantment(var9.enchantmentobj, var9.enchantmentLevel);
                  }
               }

               if (!var1.capabilities.isCreativeMode) {
                  var4.func_190918_g(var5);
                  if (var4.func_190926_b()) {
                     this.tableInventory.setInventorySlotContents(1, ItemStack.field_190927_a);
                  }
               }

               var1.addStat(StatList.ITEM_ENCHANTED);
               if (var1 instanceof EntityPlayerMP) {
                  CriteriaTriggers.field_192129_i.func_192190_a((EntityPlayerMP)var1, var3, var5);
               }

               this.tableInventory.markDirty();
               this.xpSeed = var1.getXPSeed();
               this.onCraftMatrixChanged(this.tableInventory);
               this.worldPointer.playSound((EntityPlayer)null, this.position, SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.BLOCKS, 1.0F, this.worldPointer.rand.nextFloat() * 0.1F + 0.9F);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private List<EnchantmentData> getEnchantmentList(ItemStack var1, int var2, int var3) {
      this.rand.setSeed((long)(this.xpSeed + var2));
      List var4 = EnchantmentHelper.buildEnchantmentList(this.rand, var1, var3, false);
      if (var1.getItem() == Items.BOOK && var4.size() > 1) {
         var4.remove(this.rand.nextInt(var4.size()));
      }

      return var4;
   }

   public int getLapisAmount() {
      ItemStack var1 = this.tableInventory.getStackInSlot(1);
      return var1.func_190926_b() ? 0 : var1.func_190916_E();
   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      if (!this.worldPointer.isRemote) {
         this.func_193327_a(var1, var1.world, this.tableInventory);
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      if (this.worldPointer.getBlockState(this.position).getBlock() != Blocks.ENCHANTING_TABLE) {
         return false;
      } else {
         return var1.getDistanceSq((double)this.position.getX() + (double)0.5F, (double)this.position.getY() + (double)0.5F, (double)this.position.getZ() + (double)0.5F) <= (double)64.0F;
      }
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if (var2 == 0) {
            if (!this.mergeItemStack(var5, 2, 38, true)) {
               return ItemStack.field_190927_a;
            }
         } else if (var2 == 1) {
            if (!this.mergeItemStack(var5, 2, 38, true)) {
               return ItemStack.field_190927_a;
            }
         } else if (var5.getItem() == Items.DYE && EnumDyeColor.byDyeDamage(var5.getMetadata()) == EnumDyeColor.BLUE) {
            if (!this.mergeItemStack(var5, 1, 2, true)) {
               return ItemStack.field_190927_a;
            }
         } else {
            if (((Slot)this.inventorySlots.get(0)).getHasStack() || !((Slot)this.inventorySlots.get(0)).isItemValid(var5)) {
               return ItemStack.field_190927_a;
            }

            if (var5.hasTagCompound() && var5.func_190916_E() == 1) {
               ((Slot)this.inventorySlots.get(0)).putStack(var5.copy());
               var5.func_190920_e(0);
            } else if (!var5.func_190926_b()) {
               ((Slot)this.inventorySlots.get(0)).putStack(new ItemStack(var5.getItem(), 1, var5.getMetadata()));
               var5.func_190918_g(1);
            }
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }

         if (var5.func_190916_E() == var3.func_190916_E()) {
            return ItemStack.field_190927_a;
         }

         var4.func_190901_a(var1, var5);
      }

      return var3;
   }
}
