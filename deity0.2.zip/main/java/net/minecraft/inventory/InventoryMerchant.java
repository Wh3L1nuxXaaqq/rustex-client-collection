package net.minecraft.inventory;

import net.minecraft.entity.IMerchant;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;

public class InventoryMerchant implements IInventory {
   private final IMerchant theMerchant;
   private final NonNullList<ItemStack> theInventory;
   private final EntityPlayer thePlayer;
   private MerchantRecipe currentRecipe;
   private int currentRecipeIndex;

   public InventoryMerchant(EntityPlayer var1, IMerchant var2) {
      this.theInventory = NonNullList.<ItemStack>func_191197_a(3, ItemStack.field_190927_a);
      this.thePlayer = var1;
      this.theMerchant = var2;
   }

   public int getSizeInventory() {
      return this.theInventory.size();
   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.theInventory) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int var1) {
      return this.theInventory.get(var1);
   }

   public ItemStack decrStackSize(int var1, int var2) {
      ItemStack var3 = this.theInventory.get(var1);
      if (var1 == 2 && !var3.func_190926_b()) {
         return ItemStackHelper.getAndSplit(this.theInventory, var1, var3.func_190916_E());
      } else {
         ItemStack var4 = ItemStackHelper.getAndSplit(this.theInventory, var1, var2);
         if (!var4.func_190926_b() && this.inventoryResetNeededOnSlotChange(var1)) {
            this.resetRecipeAndSlots();
         }

         return var4;
      }
   }

   private boolean inventoryResetNeededOnSlotChange(int var1) {
      return var1 == 0 || var1 == 1;
   }

   public ItemStack removeStackFromSlot(int var1) {
      return ItemStackHelper.getAndRemove(this.theInventory, var1);
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      this.theInventory.set(var1, var2);
      if (!var2.func_190926_b() && var2.func_190916_E() > this.getInventoryStackLimit()) {
         var2.func_190920_e(this.getInventoryStackLimit());
      }

      if (this.inventoryResetNeededOnSlotChange(var1)) {
         this.resetRecipeAndSlots();
      }

   }

   public String getName() {
      return "mob.villager";
   }

   public boolean hasCustomName() {
      return false;
   }

   public ITextComponent getDisplayName() {
      return (ITextComponent)(this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]));
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      return this.theMerchant.getCustomer() == var1;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public void markDirty() {
      this.resetRecipeAndSlots();
   }

   public void resetRecipeAndSlots() {
      this.currentRecipe = null;
      ItemStack var1 = this.theInventory.get(0);
      ItemStack var2 = this.theInventory.get(1);
      if (var1.func_190926_b()) {
         var1 = var2;
         var2 = ItemStack.field_190927_a;
      }

      if (var1.func_190926_b()) {
         this.setInventorySlotContents(2, ItemStack.field_190927_a);
      } else {
         MerchantRecipeList var3 = this.theMerchant.getRecipes(this.thePlayer);
         if (var3 != null) {
            MerchantRecipe var4 = var3.canRecipeBeUsed(var1, var2, this.currentRecipeIndex);
            if (var4 != null && !var4.isRecipeDisabled()) {
               this.currentRecipe = var4;
               this.setInventorySlotContents(2, var4.getItemToSell().copy());
            } else if (!var2.func_190926_b()) {
               var4 = var3.canRecipeBeUsed(var2, var1, this.currentRecipeIndex);
               if (var4 != null && !var4.isRecipeDisabled()) {
                  this.currentRecipe = var4;
                  this.setInventorySlotContents(2, var4.getItemToSell().copy());
               } else {
                  this.setInventorySlotContents(2, ItemStack.field_190927_a);
               }
            } else {
               this.setInventorySlotContents(2, ItemStack.field_190927_a);
            }
         }

         this.theMerchant.verifySellingItem(this.getStackInSlot(2));
      }

   }

   public MerchantRecipe getCurrentRecipe() {
      return this.currentRecipe;
   }

   public void setCurrentRecipeIndex(int var1) {
      this.currentRecipeIndex = var1;
      this.resetRecipeAndSlots();
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void clear() {
      this.theInventory.clear();
   }
}
