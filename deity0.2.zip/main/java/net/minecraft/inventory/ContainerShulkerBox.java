package net.minecraft.inventory;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;

public class ContainerShulkerBox extends Container {
   private final IInventory field_190899_a;

   public ContainerShulkerBox(InventoryPlayer var1, IInventory var2, EntityPlayer var3) {
      this.field_190899_a = var2;
      var2.openInventory(var3);
      boolean var4 = true;
      boolean var5 = true;

      for(int var6 = 0; var6 < 3; ++var6) {
         for(int var7 = 0; var7 < 9; ++var7) {
            this.addSlotToContainer(new SlotShulkerBox(var2, var7 + var6 * 9, 8 + var7 * 18, 18 + var6 * 18));
         }
      }

      for(int var8 = 0; var8 < 3; ++var8) {
         for(int var10 = 0; var10 < 9; ++var10) {
            this.addSlotToContainer(new Slot(var1, var10 + var8 * 9 + 9, 8 + var10 * 18, 84 + var8 * 18));
         }
      }

      for(int var9 = 0; var9 < 9; ++var9) {
         this.addSlotToContainer(new Slot(var1, var9, 8 + var9 * 18, 142));
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      return this.field_190899_a.isUsableByPlayer(var1);
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if (var2 < this.field_190899_a.getSizeInventory()) {
            if (!this.mergeItemStack(var5, this.field_190899_a.getSizeInventory(), this.inventorySlots.size(), true)) {
               return ItemStack.field_190927_a;
            }
         } else if (!this.mergeItemStack(var5, 0, this.field_190899_a.getSizeInventory(), false)) {
            return ItemStack.field_190927_a;
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }
      }

      return var3;
   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      this.field_190899_a.closeInventory(var1);
   }
}
