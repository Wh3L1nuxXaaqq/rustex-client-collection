package net.minecraft.inventory;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;

public class InventoryBasic implements IInventory {
   private String inventoryTitle;
   private final int slotsCount;
   private final NonNullList<ItemStack> inventoryContents;
   private List<IInventoryChangedListener> changeListeners;
   private boolean hasCustomName;

   public InventoryBasic(String var1, boolean var2, int var3) {
      this.inventoryTitle = var1;
      this.hasCustomName = var2;
      this.slotsCount = var3;
      this.inventoryContents = NonNullList.<ItemStack>func_191197_a(var3, ItemStack.field_190927_a);
   }

   public InventoryBasic(ITextComponent var1, int var2) {
      this(var1.getUnformattedText(), true, var2);
   }

   public void addInventoryChangeListener(IInventoryChangedListener var1) {
      if (this.changeListeners == null) {
         this.changeListeners = Lists.newArrayList();
      }

      this.changeListeners.add(var1);
   }

   public void removeInventoryChangeListener(IInventoryChangedListener var1) {
      this.changeListeners.remove(var1);
   }

   public ItemStack getStackInSlot(int var1) {
      return var1 >= 0 && var1 < this.inventoryContents.size() ? (ItemStack)this.inventoryContents.get(var1) : ItemStack.field_190927_a;
   }

   public ItemStack decrStackSize(int var1, int var2) {
      ItemStack var3 = ItemStackHelper.getAndSplit(this.inventoryContents, var1, var2);
      if (!var3.func_190926_b()) {
         this.markDirty();
      }

      return var3;
   }

   public ItemStack addItem(ItemStack var1) {
      ItemStack var2 = var1.copy();

      for(int var3 = 0; var3 < this.slotsCount; ++var3) {
         ItemStack var4 = this.getStackInSlot(var3);
         if (var4.func_190926_b()) {
            this.setInventorySlotContents(var3, var2);
            this.markDirty();
            return ItemStack.field_190927_a;
         }

         if (ItemStack.areItemsEqual(var4, var2)) {
            int var5 = Math.min(this.getInventoryStackLimit(), var4.getMaxStackSize());
            int var6 = Math.min(var2.func_190916_E(), var5 - var4.func_190916_E());
            if (var6 > 0) {
               var4.func_190917_f(var6);
               var2.func_190918_g(var6);
               if (var2.func_190926_b()) {
                  this.markDirty();
                  return ItemStack.field_190927_a;
               }
            }
         }
      }

      if (var2.func_190916_E() != var1.func_190916_E()) {
         this.markDirty();
      }

      return var2;
   }

   public ItemStack removeStackFromSlot(int var1) {
      ItemStack var2 = this.inventoryContents.get(var1);
      if (var2.func_190926_b()) {
         return ItemStack.field_190927_a;
      } else {
         this.inventoryContents.set(var1, ItemStack.field_190927_a);
         return var2;
      }
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      this.inventoryContents.set(var1, var2);
      if (!var2.func_190926_b() && var2.func_190916_E() > this.getInventoryStackLimit()) {
         var2.func_190920_e(this.getInventoryStackLimit());
      }

      this.markDirty();
   }

   public int getSizeInventory() {
      return this.slotsCount;
   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.inventoryContents) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public String getName() {
      return this.inventoryTitle;
   }

   public boolean hasCustomName() {
      return this.hasCustomName;
   }

   public void setCustomName(String var1) {
      this.hasCustomName = true;
      this.inventoryTitle = var1;
   }

   public ITextComponent getDisplayName() {
      return (ITextComponent)(this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]));
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public void markDirty() {
      if (this.changeListeners != null) {
         for(int var1 = 0; var1 < this.changeListeners.size(); ++var1) {
            ((IInventoryChangedListener)this.changeListeners.get(var1)).onInventoryChanged(this);
         }
      }

   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      return true;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void clear() {
      this.inventoryContents.clear();
   }
}
