package net.minecraft.inventory;

import net.minecraft.client.util.RecipeItemHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;

public class InventoryCrafting implements IInventory {
   private final NonNullList<ItemStack> stackList;
   private final int inventoryWidth;
   private final int inventoryHeight;
   private final Container eventHandler;

   public InventoryCrafting(Container var1, int var2, int var3) {
      this.stackList = NonNullList.<ItemStack>func_191197_a(var2 * var3, ItemStack.field_190927_a);
      this.eventHandler = var1;
      this.inventoryWidth = var2;
      this.inventoryHeight = var3;
   }

   public int getSizeInventory() {
      return this.stackList.size();
   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.stackList) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int var1) {
      return var1 >= this.getSizeInventory() ? ItemStack.field_190927_a : (ItemStack)this.stackList.get(var1);
   }

   public ItemStack getStackInRowAndColumn(int var1, int var2) {
      return var1 >= 0 && var1 < this.inventoryWidth && var2 >= 0 && var2 <= this.inventoryHeight ? this.getStackInSlot(var1 + var2 * this.inventoryWidth) : ItemStack.field_190927_a;
   }

   public String getName() {
      return "container.crafting";
   }

   public boolean hasCustomName() {
      return false;
   }

   public ITextComponent getDisplayName() {
      return (ITextComponent)(this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]));
   }

   public ItemStack removeStackFromSlot(int var1) {
      return ItemStackHelper.getAndRemove(this.stackList, var1);
   }

   public ItemStack decrStackSize(int var1, int var2) {
      ItemStack var3 = ItemStackHelper.getAndSplit(this.stackList, var1, var2);
      if (!var3.func_190926_b()) {
         this.eventHandler.onCraftMatrixChanged(this);
      }

      return var3;
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      this.stackList.set(var1, var2);
      this.eventHandler.onCraftMatrixChanged(this);
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public void markDirty() {
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      return true;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void clear() {
      this.stackList.clear();
   }

   public int getHeight() {
      return this.inventoryHeight;
   }

   public int getWidth() {
      return this.inventoryWidth;
   }

   public void func_194018_a(RecipeItemHelper var1) {
      for(ItemStack var3 : this.stackList) {
         var1.func_194112_a(var3);
      }

   }
}
