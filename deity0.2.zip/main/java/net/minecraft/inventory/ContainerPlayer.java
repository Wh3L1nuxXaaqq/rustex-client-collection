package net.minecraft.inventory;

import javax.annotation.Nullable;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class ContainerPlayer extends Container {
   private static final EntityEquipmentSlot[] VALID_EQUIPMENT_SLOTS;
   public InventoryCrafting craftMatrix = new InventoryCrafting(this, 2, 2);
   public InventoryCraftResult craftResult = new InventoryCraftResult();
   public boolean isLocalWorld;
   private final EntityPlayer thePlayer;

   public ContainerPlayer(InventoryPlayer var1, boolean var2, EntityPlayer var3) {
      this.isLocalWorld = var2;
      this.thePlayer = var3;
      this.addSlotToContainer(new SlotCrafting(var1.player, this.craftMatrix, this.craftResult, 0, 154, 28));

      for(int var4 = 0; var4 < 2; ++var4) {
         for(int var5 = 0; var5 < 2; ++var5) {
            this.addSlotToContainer(new Slot(this.craftMatrix, var5 + var4 * 2, 98 + var5 * 18, 18 + var4 * 18));
         }
      }

      for(int var6 = 0; var6 < 4; ++var6) {
         final EntityEquipmentSlot var9 = VALID_EQUIPMENT_SLOTS[var6];
         this.addSlotToContainer(new Slot(var1, 36 + (3 - var6), 8, 8 + var6 * 18) {
            public int getSlotStackLimit() {
               return 1;
            }

            public boolean isItemValid(ItemStack var1) {
               return var9 == EntityLiving.getSlotForItemStack(var1);
            }

            public boolean canTakeStack(EntityPlayer var1) {
               ItemStack var2 = this.getStack();
               return !var2.func_190926_b() && !var1.isCreative() && EnchantmentHelper.func_190938_b(var2) ? false : super.canTakeStack(var1);
            }

            @Nullable
            public String getSlotTexture() {
               return ItemArmor.EMPTY_SLOT_NAMES[var9.getIndex()];
            }
         });
      }

      for(int var7 = 0; var7 < 3; ++var7) {
         for(int var10 = 0; var10 < 9; ++var10) {
            this.addSlotToContainer(new Slot(var1, var10 + (var7 + 1) * 9, 8 + var10 * 18, 84 + var7 * 18));
         }
      }

      for(int var8 = 0; var8 < 9; ++var8) {
         this.addSlotToContainer(new Slot(var1, var8, 8 + var8 * 18, 142));
      }

      this.addSlotToContainer(new Slot(var1, 40, 77, 62) {
         @Nullable
         public String getSlotTexture() {
            return "minecraft:items/empty_armor_slot_shield";
         }
      });
   }

   public void onCraftMatrixChanged(IInventory var1) {
      this.func_192389_a(this.thePlayer.world, this.thePlayer, this.craftMatrix, this.craftResult);
   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      this.craftResult.clear();
      if (!var1.world.isRemote) {
         this.func_193327_a(var1, var1.world, this.craftMatrix);
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      return true;
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         EntityEquipmentSlot var6 = EntityLiving.getSlotForItemStack(var3);
         if (var2 == 0) {
            if (!this.mergeItemStack(var5, 9, 45, true)) {
               return ItemStack.field_190927_a;
            }

            var4.onSlotChange(var5, var3);
         } else if (var2 >= 1 && var2 < 5) {
            if (!this.mergeItemStack(var5, 9, 45, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var2 >= 5 && var2 < 9) {
            if (!this.mergeItemStack(var5, 9, 45, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var6.getSlotType() == EntityEquipmentSlot.Type.ARMOR && !((Slot)this.inventorySlots.get(8 - var6.getIndex())).getHasStack()) {
            int var7 = 8 - var6.getIndex();
            if (!this.mergeItemStack(var5, var7, var7 + 1, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var6 == EntityEquipmentSlot.OFFHAND && !((Slot)this.inventorySlots.get(45)).getHasStack()) {
            if (!this.mergeItemStack(var5, 45, 46, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var2 >= 9 && var2 < 36) {
            if (!this.mergeItemStack(var5, 36, 45, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (var2 >= 36 && var2 < 45) {
            if (!this.mergeItemStack(var5, 9, 36, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (!this.mergeItemStack(var5, 9, 45, false)) {
            return ItemStack.field_190927_a;
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }

         if (var5.func_190916_E() == var3.func_190916_E()) {
            return ItemStack.field_190927_a;
         }

         ItemStack var8 = var4.func_190901_a(var1, var5);
         if (var2 == 0) {
            var1.dropItem(var8, false);
         }
      }

      return var3;
   }

   public boolean canMergeSlot(ItemStack var1, Slot var2) {
      return var2.inventory != this.craftResult && super.canMergeSlot(var1, var2);
   }

   static {
      VALID_EQUIPMENT_SLOTS = new EntityEquipmentSlot[]{EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST, EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET};
   }
}
