package net.minecraft.inventory;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionHelper;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;

public class ContainerBrewingStand extends Container {
   private final IInventory tileBrewingStand;
   private final Slot theSlot;
   private int prevBrewTime;
   private int prevFuel;

   public ContainerBrewingStand(InventoryPlayer var1, IInventory var2) {
      this.tileBrewingStand = var2;
      this.addSlotToContainer(new Potion(var2, 0, 56, 51));
      this.addSlotToContainer(new Potion(var2, 1, 79, 58));
      this.addSlotToContainer(new Potion(var2, 2, 102, 51));
      this.theSlot = this.addSlotToContainer(new Ingredient(var2, 3, 79, 17));
      this.addSlotToContainer(new Fuel(var2, 4, 17, 17));

      for(int var3 = 0; var3 < 3; ++var3) {
         for(int var4 = 0; var4 < 9; ++var4) {
            this.addSlotToContainer(new Slot(var1, var4 + var3 * 9 + 9, 8 + var4 * 18, 84 + var3 * 18));
         }
      }

      for(int var5 = 0; var5 < 9; ++var5) {
         this.addSlotToContainer(new Slot(var1, var5, 8 + var5 * 18, 142));
      }

   }

   public void addListener(IContainerListener var1) {
      super.addListener(var1);
      var1.sendAllWindowProperties(this, this.tileBrewingStand);
   }

   public void detectAndSendChanges() {
      super.detectAndSendChanges();

      for(int var1 = 0; var1 < this.listeners.size(); ++var1) {
         IContainerListener var2 = (IContainerListener)this.listeners.get(var1);
         if (this.prevBrewTime != this.tileBrewingStand.getField(0)) {
            var2.sendProgressBarUpdate(this, 0, this.tileBrewingStand.getField(0));
         }

         if (this.prevFuel != this.tileBrewingStand.getField(1)) {
            var2.sendProgressBarUpdate(this, 1, this.tileBrewingStand.getField(1));
         }
      }

      this.prevBrewTime = this.tileBrewingStand.getField(0);
      this.prevFuel = this.tileBrewingStand.getField(1);
   }

   public void updateProgressBar(int var1, int var2) {
      this.tileBrewingStand.setField(var1, var2);
   }

   public boolean canInteractWith(EntityPlayer var1) {
      return this.tileBrewingStand.isUsableByPlayer(var1);
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if ((var2 < 0 || var2 > 2) && var2 != 3 && var2 != 4) {
            if (this.theSlot.isItemValid(var5)) {
               if (!this.mergeItemStack(var5, 3, 4, false)) {
                  return ItemStack.field_190927_a;
               }
            } else if (ContainerBrewingStand.Potion.canHoldPotion(var3) && var3.func_190916_E() == 1) {
               if (!this.mergeItemStack(var5, 0, 3, false)) {
                  return ItemStack.field_190927_a;
               }
            } else if (ContainerBrewingStand.Fuel.isValidBrewingFuel(var3)) {
               if (!this.mergeItemStack(var5, 4, 5, false)) {
                  return ItemStack.field_190927_a;
               }
            } else if (var2 >= 5 && var2 < 32) {
               if (!this.mergeItemStack(var5, 32, 41, false)) {
                  return ItemStack.field_190927_a;
               }
            } else if (var2 >= 32 && var2 < 41) {
               if (!this.mergeItemStack(var5, 5, 32, false)) {
                  return ItemStack.field_190927_a;
               }
            } else if (!this.mergeItemStack(var5, 5, 41, false)) {
               return ItemStack.field_190927_a;
            }
         } else {
            if (!this.mergeItemStack(var5, 5, 41, true)) {
               return ItemStack.field_190927_a;
            }

            var4.onSlotChange(var5, var3);
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }

         if (var5.func_190916_E() == var3.func_190916_E()) {
            return ItemStack.field_190927_a;
         }

         var4.func_190901_a(var1, var5);
      }

      return var3;
   }

   static class Fuel extends Slot {
      public Fuel(IInventory var1, int var2, int var3, int var4) {
         super(var1, var2, var3, var4);
      }

      public boolean isItemValid(ItemStack var1) {
         return isValidBrewingFuel(var1);
      }

      public static boolean isValidBrewingFuel(ItemStack var0) {
         return var0.getItem() == Items.BLAZE_POWDER;
      }

      public int getSlotStackLimit() {
         return 64;
      }
   }

   static class Ingredient extends Slot {
      public Ingredient(IInventory var1, int var2, int var3, int var4) {
         super(var1, var2, var3, var4);
      }

      public boolean isItemValid(ItemStack var1) {
         return PotionHelper.isReagent(var1);
      }

      public int getSlotStackLimit() {
         return 64;
      }
   }

   static class Potion extends Slot {
      public Potion(IInventory var1, int var2, int var3, int var4) {
         super(var1, var2, var3, var4);
      }

      public boolean isItemValid(ItemStack var1) {
         return canHoldPotion(var1);
      }

      public int getSlotStackLimit() {
         return 1;
      }

      public ItemStack func_190901_a(EntityPlayer var1, ItemStack var2) {
         PotionType var3 = PotionUtils.getPotionFromItem(var2);
         if (var1 instanceof EntityPlayerMP) {
            CriteriaTriggers.field_192130_j.func_192173_a((EntityPlayerMP)var1, var3);
         }

         super.func_190901_a(var1, var2);
         return var2;
      }

      public static boolean canHoldPotion(ItemStack var0) {
         Item var1 = var0.getItem();
         return var1 == Items.POTIONITEM || var1 == Items.SPLASH_POTION || var1 == Items.LINGERING_POTION || var1 == Items.GLASS_BOTTLE;
      }
   }
}
