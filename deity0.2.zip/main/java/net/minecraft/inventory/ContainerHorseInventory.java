package net.minecraft.inventory;

import net.minecraft.entity.passive.AbstractChestHorse;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class ContainerHorseInventory extends Container {
   private final IInventory horseInventory;
   private final AbstractHorse theHorse;

   public ContainerHorseInventory(IInventory var1, IInventory var2, final AbstractHorse var3, EntityPlayer var4) {
      this.horseInventory = var2;
      this.theHorse = var3;
      boolean var5 = true;
      var2.openInventory(var4);
      boolean var6 = true;
      this.addSlotToContainer(new Slot(var2, 0, 8, 18) {
         public boolean isItemValid(ItemStack var1) {
            return var1.getItem() == Items.SADDLE && !this.getHasStack() && var3.func_190685_dA();
         }

         public boolean canBeHovered() {
            return var3.func_190685_dA();
         }
      });
      this.addSlotToContainer(new Slot(var2, 1, 8, 36) {
         public boolean isItemValid(ItemStack var1) {
            return var3.func_190682_f(var1);
         }

         public boolean canBeHovered() {
            return var3.func_190677_dK();
         }

         public int getSlotStackLimit() {
            return 1;
         }
      });
      if (var3 instanceof AbstractChestHorse && ((AbstractChestHorse)var3).func_190695_dh()) {
         for(int var7 = 0; var7 < 3; ++var7) {
            for(int var8 = 0; var8 < ((AbstractChestHorse)var3).func_190696_dl(); ++var8) {
               this.addSlotToContainer(new Slot(var2, 2 + var8 + var7 * ((AbstractChestHorse)var3).func_190696_dl(), 80 + var8 * 18, 18 + var7 * 18));
            }
         }
      }

      for(int var9 = 0; var9 < 3; ++var9) {
         for(int var11 = 0; var11 < 9; ++var11) {
            this.addSlotToContainer(new Slot(var1, var11 + var9 * 9 + 9, 8 + var11 * 18, 102 + var9 * 18 + -18));
         }
      }

      for(int var10 = 0; var10 < 9; ++var10) {
         this.addSlotToContainer(new Slot(var1, var10, 8 + var10 * 18, 142));
      }

   }

   public boolean canInteractWith(EntityPlayer var1) {
      return this.horseInventory.isUsableByPlayer(var1) && this.theHorse.isEntityAlive() && this.theHorse.getDistanceToEntity(var1) < 8.0F;
   }

   public ItemStack transferStackInSlot(EntityPlayer var1, int var2) {
      ItemStack var3 = ItemStack.field_190927_a;
      Slot var4 = (Slot)this.inventorySlots.get(var2);
      if (var4 != null && var4.getHasStack()) {
         ItemStack var5 = var4.getStack();
         var3 = var5.copy();
         if (var2 < this.horseInventory.getSizeInventory()) {
            if (!this.mergeItemStack(var5, this.horseInventory.getSizeInventory(), this.inventorySlots.size(), true)) {
               return ItemStack.field_190927_a;
            }
         } else if (this.getSlot(1).isItemValid(var5) && !this.getSlot(1).getHasStack()) {
            if (!this.mergeItemStack(var5, 1, 2, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (this.getSlot(0).isItemValid(var5)) {
            if (!this.mergeItemStack(var5, 0, 1, false)) {
               return ItemStack.field_190927_a;
            }
         } else if (this.horseInventory.getSizeInventory() <= 2 || !this.mergeItemStack(var5, 2, this.horseInventory.getSizeInventory(), false)) {
            return ItemStack.field_190927_a;
         }

         if (var5.func_190926_b()) {
            var4.putStack(ItemStack.field_190927_a);
         } else {
            var4.onSlotChanged();
         }
      }

      return var3;
   }

   public void onContainerClosed(EntityPlayer var1) {
      super.onContainerClosed(var1);
      this.horseInventory.closeInventory(var1);
   }
}
