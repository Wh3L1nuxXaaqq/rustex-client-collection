package net.minecraft.inventory;

import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;

public class InventoryCraftResult implements IInventory {
   private final NonNullList<ItemStack> stackResult;
   private IRecipe field_193057_b;

   public InventoryCraftResult() {
      this.stackResult = NonNullList.<ItemStack>func_191197_a(1, ItemStack.field_190927_a);
   }

   public int getSizeInventory() {
      return 1;
   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.stackResult) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int var1) {
      return this.stackResult.get(0);
   }

   public String getName() {
      return "Result";
   }

   public boolean hasCustomName() {
      return false;
   }

   public ITextComponent getDisplayName() {
      return (ITextComponent)(this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]));
   }

   public ItemStack decrStackSize(int var1, int var2) {
      return ItemStackHelper.getAndRemove(this.stackResult, 0);
   }

   public ItemStack removeStackFromSlot(int var1) {
      return ItemStackHelper.getAndRemove(this.stackResult, 0);
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      this.stackResult.set(0, var2);
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public void markDirty() {
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      return true;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void clear() {
      this.stackResult.clear();
   }

   public void func_193056_a(@Nullable IRecipe var1) {
      this.field_193057_b = var1;
   }

   @Nullable
   public IRecipe func_193055_i() {
      return this.field_193057_b;
   }
}
