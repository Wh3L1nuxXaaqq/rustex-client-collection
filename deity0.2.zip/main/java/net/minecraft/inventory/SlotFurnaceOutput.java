package net.minecraft.inventory;

import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.util.math.MathHelper;

public class SlotFurnaceOutput extends Slot {
   private final EntityPlayer thePlayer;
   private int removeCount;

   public SlotFurnaceOutput(EntityPlayer var1, IInventory var2, int var3, int var4, int var5) {
      super(var2, var3, var4, var5);
      this.thePlayer = var1;
   }

   public boolean isItemValid(ItemStack var1) {
      return false;
   }

   public ItemStack decrStackSize(int var1) {
      if (this.getHasStack()) {
         this.removeCount += Math.min(var1, this.getStack().func_190916_E());
      }

      return super.decrStackSize(var1);
   }

   public ItemStack func_190901_a(EntityPlayer var1, ItemStack var2) {
      this.onCrafting(var2);
      super.func_190901_a(var1, var2);
      return var2;
   }

   protected void onCrafting(ItemStack var1, int var2) {
      this.removeCount += var2;
      this.onCrafting(var1);
   }

   protected void onCrafting(ItemStack var1) {
      var1.onCrafting(this.thePlayer.world, this.thePlayer, this.removeCount);
      if (!this.thePlayer.world.isRemote) {
         int var2 = this.removeCount;
         float var3 = FurnaceRecipes.instance().getSmeltingExperience(var1);
         if (var3 == 0.0F) {
            var2 = 0;
         } else if (var3 < 1.0F) {
            int var4 = MathHelper.floor((float)var2 * var3);
            if (var4 < MathHelper.ceil((float)var2 * var3) && Math.random() < (double)((float)var2 * var3 - (float)var4)) {
               ++var4;
            }

            var2 = var4;
         }

         while(var2 > 0) {
            int var5 = EntityXPOrb.getXPSplit(var2);
            var2 -= var5;
            this.thePlayer.world.spawnEntityInWorld(new EntityXPOrb(this.thePlayer.world, this.thePlayer.posX, this.thePlayer.posY + (double)0.5F, this.thePlayer.posZ + (double)0.5F, var5));
         }
      }

      this.removeCount = 0;
   }
}
