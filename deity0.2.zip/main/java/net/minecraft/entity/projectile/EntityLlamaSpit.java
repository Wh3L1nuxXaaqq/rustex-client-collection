package net.minecraft.entity.projectile;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityLlamaSpit extends Entity implements IProjectile {
   public EntityLlama field_190539_a;
   private NBTTagCompound field_190540_b;

   public EntityLlamaSpit(World var1) {
      super(var1);
   }

   public EntityLlamaSpit(World var1, EntityLlama var2) {
      super(var1);
      this.field_190539_a = var2;
      this.setPosition(var2.posX - (double)(var2.width + 1.0F) * (double)0.5F * (double)MathHelper.sin(var2.renderYawOffset * ((float)Math.PI / 180F)), var2.posY + (double)var2.getEyeHeight() - (double)0.1F, var2.posZ + (double)(var2.width + 1.0F) * (double)0.5F * (double)MathHelper.cos(var2.renderYawOffset * ((float)Math.PI / 180F)));
      this.setSize(0.25F, 0.25F);
   }

   public EntityLlamaSpit(World var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1);
      this.setPosition(var2, var4, var6);

      for(int var14 = 0; var14 < 7; ++var14) {
         double var15 = 0.4 + 0.1 * (double)var14;
         var1.spawnParticle(EnumParticleTypes.SPIT, var2, var4, var6, var8 * var15, var10, var12 * var15);
      }

      this.motionX = var8;
      this.motionY = var10;
      this.motionZ = var12;
   }

   public void onUpdate() {
      super.onUpdate();
      if (this.field_190540_b != null) {
         this.func_190537_j();
      }

      Vec3d var1 = new Vec3d(this.posX, this.posY, this.posZ);
      Vec3d var2 = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
      RayTraceResult var3 = this.world.rayTraceBlocks(var1, var2);
      var1 = new Vec3d(this.posX, this.posY, this.posZ);
      var2 = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
      if (var3 != null) {
         var2 = new Vec3d(var3.hitVec.xCoord, var3.hitVec.yCoord, var3.hitVec.zCoord);
      }

      Entity var4 = this.func_190538_a(var1, var2);
      if (var4 != null) {
         var3 = new RayTraceResult(var4);
      }

      if (var3 != null) {
         this.func_190536_a(var3);
      }

      this.posX += this.motionX;
      this.posY += this.motionY;
      this.posZ += this.motionZ;
      float var5 = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      this.rotationYaw = (float)(MathHelper.atan2(this.motionX, this.motionZ) * (180D / Math.PI));

      for(this.rotationPitch = (float)(MathHelper.atan2(this.motionY, (double)var5) * (180D / Math.PI)); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F) {
      }

      while(this.rotationPitch - this.prevRotationPitch >= 180.0F) {
         this.prevRotationPitch += 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw < -180.0F) {
         this.prevRotationYaw -= 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw >= 180.0F) {
         this.prevRotationYaw += 360.0F;
      }

      this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
      this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
      float var6 = 0.99F;
      float var7 = 0.06F;
      if (!this.world.isMaterialInBB(this.getEntityBoundingBox(), Material.AIR)) {
         this.setDead();
      } else if (this.isInWater()) {
         this.setDead();
      } else {
         this.motionX *= (double)0.99F;
         this.motionY *= (double)0.99F;
         this.motionZ *= (double)0.99F;
         if (!this.hasNoGravity()) {
            this.motionY -= (double)0.06F;
         }

         this.setPosition(this.posX, this.posY, this.posZ);
      }

   }

   public void setVelocity(double var1, double var3, double var5) {
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
      if (this.prevRotationPitch == 0.0F && this.prevRotationYaw == 0.0F) {
         float var7 = MathHelper.sqrt(var1 * var1 + var5 * var5);
         this.rotationPitch = (float)(MathHelper.atan2(var3, (double)var7) * (180D / Math.PI));
         this.rotationYaw = (float)(MathHelper.atan2(var1, var5) * (180D / Math.PI));
         this.prevRotationPitch = this.rotationPitch;
         this.prevRotationYaw = this.rotationYaw;
         this.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
      }

   }

   @Nullable
   private Entity func_190538_a(Vec3d var1, Vec3d var2) {
      Entity var3 = null;
      List var4 = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().addCoord(this.motionX, this.motionY, this.motionZ).expandXyz((double)1.0F));
      double var5 = (double)0.0F;

      for(Object var8_raw : var4) {
         Entity var8 = (Entity)var8_raw;
         if (var8 != this.field_190539_a) {
            AxisAlignedBB var9 = var8.getEntityBoundingBox().expandXyz((double)0.3F);
            RayTraceResult var10 = var9.calculateIntercept(var1, var2);
            if (var10 != null) {
               double var11 = var1.squareDistanceTo(var10.hitVec);
               if (var11 < var5 || var5 == (double)0.0F) {
                  var3 = var8;
                  var5 = var11;
               }
            }
         }
      }

      return var3;
   }

   public void setThrowableHeading(double var1, double var3, double var5, float var7, float var8) {
      float var9 = MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
      var1 /= (double)var9;
      var3 /= (double)var9;
      var5 /= (double)var9;
      var1 += this.rand.nextGaussian() * (double)0.0075F * (double)var8;
      var3 += this.rand.nextGaussian() * (double)0.0075F * (double)var8;
      var5 += this.rand.nextGaussian() * (double)0.0075F * (double)var8;
      var1 *= (double)var7;
      var3 *= (double)var7;
      var5 *= (double)var7;
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
      float var10 = MathHelper.sqrt(var1 * var1 + var5 * var5);
      this.rotationYaw = (float)(MathHelper.atan2(var1, var5) * (180D / Math.PI));
      this.rotationPitch = (float)(MathHelper.atan2(var3, (double)var10) * (180D / Math.PI));
      this.prevRotationYaw = this.rotationYaw;
      this.prevRotationPitch = this.rotationPitch;
   }

   public void func_190536_a(RayTraceResult var1) {
      if (var1.entityHit != null && this.field_190539_a != null) {
         var1.entityHit.attackEntityFrom(DamageSource.causeIndirectDamage(this, this.field_190539_a).setProjectile(), 1.0F);
      }

      if (!this.world.isRemote) {
         this.setDead();
      }

   }

   protected void entityInit() {
   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      if (var1.hasKey("Owner", 10)) {
         this.field_190540_b = var1.getCompoundTag("Owner");
      }

   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      if (this.field_190539_a != null) {
         NBTTagCompound var2 = new NBTTagCompound();
         UUID var3 = this.field_190539_a.getUniqueID();
         var2.setUniqueId("OwnerUUID", var3);
         var1.setTag("Owner", var2);
      }

   }

   private void func_190537_j() {
      if (this.field_190540_b != null && this.field_190540_b.hasUniqueId("OwnerUUID")) {
         UUID var1 = this.field_190540_b.getUniqueId("OwnerUUID");

         for(EntityLlama var3 : this.world.getEntitiesWithinAABB(EntityLlama.class, this.getEntityBoundingBox().expandXyz((double)15.0F))) {
            if (var3.getUniqueID().equals(var1)) {
               this.field_190539_a = var3;
               break;
            }
         }
      }

      this.field_190540_b = null;
   }
}
