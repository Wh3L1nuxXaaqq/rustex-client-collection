package net.minecraft.entity.projectile;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EntityEvokerFangs extends Entity {
   private int field_190553_a;
   private boolean field_190554_b;
   private int field_190555_c;
   private boolean field_190556_d;
   private EntityLivingBase field_190557_e;
   private UUID field_190558_f;

   public EntityEvokerFangs(World var1) {
      super(var1);
      this.field_190555_c = 22;
      this.setSize(0.5F, 0.8F);
   }

   public EntityEvokerFangs(World var1, double var2, double var4, double var6, float var8, int var9, EntityLivingBase var10) {
      this(var1);
      this.field_190553_a = var9;
      this.func_190549_a(var10);
      this.rotationYaw = var8 * (180F / (float)Math.PI);
      this.setPosition(var2, var4, var6);
   }

   protected void entityInit() {
   }

   public void func_190549_a(@Nullable EntityLivingBase var1) {
      this.field_190557_e = var1;
      this.field_190558_f = var1 == null ? null : var1.getUniqueID();
   }

   @Nullable
   public EntityLivingBase func_190552_j() {
      if (this.field_190557_e == null && this.field_190558_f != null && this.world instanceof WorldServer) {
         Entity var1 = ((WorldServer)this.world).getEntityFromUuid(this.field_190558_f);
         if (var1 instanceof EntityLivingBase) {
            this.field_190557_e = (EntityLivingBase)var1;
         }
      }

      return this.field_190557_e;
   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      this.field_190553_a = var1.getInteger("Warmup");
      this.field_190558_f = var1.getUniqueId("OwnerUUID");
   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      var1.setInteger("Warmup", this.field_190553_a);
      if (this.field_190558_f != null) {
         var1.setUniqueId("OwnerUUID", this.field_190558_f);
      }

   }

   public void onUpdate() {
      super.onUpdate();
      if (this.world.isRemote) {
         if (this.field_190556_d) {
            --this.field_190555_c;
            if (this.field_190555_c == 14) {
               for(int var1 = 0; var1 < 12; ++var1) {
                  double var2 = this.posX + (this.rand.nextDouble() * (double)2.0F - (double)1.0F) * (double)this.width * (double)0.5F;
                  double var4 = this.posY + 0.05 + this.rand.nextDouble() * (double)1.0F;
                  double var6 = this.posZ + (this.rand.nextDouble() * (double)2.0F - (double)1.0F) * (double)this.width * (double)0.5F;
                  double var8 = (this.rand.nextDouble() * (double)2.0F - (double)1.0F) * 0.3;
                  double var10 = 0.3 + this.rand.nextDouble() * 0.3;
                  double var12 = (this.rand.nextDouble() * (double)2.0F - (double)1.0F) * 0.3;
                  this.world.spawnParticle(EnumParticleTypes.CRIT, var2, var4 + (double)1.0F, var6, var8, var10, var12);
               }
            }
         }
      } else if (--this.field_190553_a < 0) {
         if (this.field_190553_a == -8) {
            for(EntityLivingBase var15 : this.world.getEntitiesWithinAABB(EntityLivingBase.class, this.getEntityBoundingBox().expand(0.2, (double)0.0F, 0.2))) {
               this.func_190551_c(var15);
            }
         }

         if (!this.field_190554_b) {
            this.world.setEntityState(this, (byte)4);
            this.field_190554_b = true;
         }

         if (--this.field_190555_c < 0) {
            this.setDead();
         }
      }

   }

   private void func_190551_c(EntityLivingBase var1) {
      EntityLivingBase var2 = this.func_190552_j();
      if (var1.isEntityAlive() && !var1.func_190530_aW() && var1 != var2) {
         if (var2 == null) {
            var1.attackEntityFrom(DamageSource.magic, 6.0F);
         } else {
            if (var2.isOnSameTeam(var1)) {
               return;
            }

            var1.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, var2), 6.0F);
         }
      }

   }

   public void handleStatusUpdate(byte var1) {
      super.handleStatusUpdate(var1);
      if (var1 == 4) {
         this.field_190556_d = true;
         if (!this.isSilent()) {
            this.world.playSound(this.posX, this.posY, this.posZ, SoundEvents.field_191242_bl, this.getSoundCategory(), 1.0F, this.rand.nextFloat() * 0.2F + 0.85F, false);
         }
      }

   }

   public float func_190550_a(float var1) {
      if (!this.field_190556_d) {
         return 0.0F;
      } else {
         int var2 = this.field_190555_c - 2;
         return var2 <= 0 ? 1.0F : 1.0F - ((float)var2 - var1) / 20.0F;
      }
   }
}
