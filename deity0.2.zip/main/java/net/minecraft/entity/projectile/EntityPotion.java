package net.minecraft.entity.projectile;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityPotion extends EntityThrowable {
   private static final DataParameter<ItemStack> ITEM;
   private static final Logger LOGGER;
   public static final Predicate<EntityLivingBase> field_190546_d;

   public EntityPotion(World var1) {
      super(var1);
   }

   public EntityPotion(World var1, EntityLivingBase var2, ItemStack var3) {
      super(var1, var2);
      this.setItem(var3);
   }

   public EntityPotion(World var1, double var2, double var4, double var6, ItemStack var8) {
      super(var1, var2, var4, var6);
      if (!var8.func_190926_b()) {
         this.setItem(var8);
      }

   }

   protected void entityInit() {
      this.getDataManager().register(ITEM, ItemStack.field_190927_a);
   }

   public ItemStack getPotion() {
      ItemStack var1 = (ItemStack)this.getDataManager().get(ITEM);
      if (var1.getItem() != Items.SPLASH_POTION && var1.getItem() != Items.LINGERING_POTION) {
         if (this.world != null) {
            LOGGER.error("ThrownPotion entity {} has no item?!", this.getEntityId());
         }

         return new ItemStack(Items.SPLASH_POTION);
      } else {
         return var1;
      }
   }

   public void setItem(ItemStack var1) {
      this.getDataManager().set(ITEM, var1);
      this.getDataManager().setDirty(ITEM);
   }

   protected float getGravityVelocity() {
      return 0.05F;
   }

   protected void onImpact(RayTraceResult var1) {
      if (!this.world.isRemote) {
         ItemStack var2 = this.getPotion();
         PotionType var3 = PotionUtils.getPotionFromItem(var2);
         List var4 = PotionUtils.getEffectsFromStack(var2);
         boolean var5 = var3 == PotionTypes.WATER && var4.isEmpty();
         if (var1.typeOfHit == RayTraceResult.Type.BLOCK && var5) {
            BlockPos var6 = var1.getBlockPos().offset(var1.sideHit);
            this.extinguishFires(var6, var1.sideHit);

            for(EnumFacing var8 : EnumFacing.Plane.HORIZONTAL) {
               this.extinguishFires(var6.offset(var8), var8);
            }
         }

         if (var5) {
            this.func_190545_n();
         } else if (!var4.isEmpty()) {
            if (this.isLingering()) {
               this.func_190542_a(var2, var3);
            } else {
               this.func_190543_a(var1, var4);
            }
         }

         int var9 = var3.hasInstantEffect() ? 2007 : 2002;
         this.world.playEvent(var9, new BlockPos(this), PotionUtils.func_190932_c(var2));
         this.setDead();
      }

   }

   private void func_190545_n() {
      AxisAlignedBB var1 = this.getEntityBoundingBox().expand((double)4.0F, (double)2.0F, (double)4.0F);
      List var2 = this.world.getEntitiesWithinAABB(EntityLivingBase.class, var1, field_190546_d);
      if (!var2.isEmpty()) {
         for(Object var4_raw : var2) {
            EntityLivingBase var4 = (EntityLivingBase)var4_raw;
            double var5 = this.getDistanceSqToEntity(var4);
            if (var5 < (double)16.0F && func_190544_c(var4)) {
               var4.attackEntityFrom(DamageSource.drown, 1.0F);
            }
         }
      }

   }

   private void func_190543_a(RayTraceResult var1, List<PotionEffect> var2) {
      AxisAlignedBB var3 = this.getEntityBoundingBox().expand((double)4.0F, (double)2.0F, (double)4.0F);
      List var4 = this.world.getEntitiesWithinAABB(EntityLivingBase.class, var3);
      if (!var4.isEmpty()) {
         for(Object var6_raw : var4) {
            EntityLivingBase var6 = (EntityLivingBase)var6_raw;
            if (var6.canBeHitWithPotion()) {
               double var7 = this.getDistanceSqToEntity(var6);
               if (var7 < (double)16.0F) {
                  double var9 = (double)1.0F - Math.sqrt(var7) / (double)4.0F;
                  if (var6 == var1.entityHit) {
                     var9 = (double)1.0F;
                  }

                  for(PotionEffect var12 : var2) {
                     Potion var13 = var12.getPotion();
                     if (var13.isInstant()) {
                        var13.affectEntity(this, this.getThrower(), var6, var12.getAmplifier(), var9);
                     } else {
                        int var14 = (int)(var9 * (double)var12.getDuration() + (double)0.5F);
                        if (var14 > 20) {
                           var6.addPotionEffect(new PotionEffect(var13, var14, var12.getAmplifier(), var12.getIsAmbient(), var12.doesShowParticles()));
                        }
                     }
                  }
               }
            }
         }
      }

   }

   private void func_190542_a(ItemStack var1, PotionType var2) {
      EntityAreaEffectCloud var3 = new EntityAreaEffectCloud(this.world, this.posX, this.posY, this.posZ);
      var3.setOwner(this.getThrower());
      var3.setRadius(3.0F);
      var3.setRadiusOnUse(-0.5F);
      var3.setWaitTime(10);
      var3.setRadiusPerTick(-var3.getRadius() / (float)var3.getDuration());
      var3.setPotion(var2);

      for(PotionEffect var5 : PotionUtils.getFullEffectsFromItem(var1)) {
         var3.addEffect(new PotionEffect(var5));
      }

      NBTTagCompound var6 = var1.getTagCompound();
      if (var6 != null && var6.hasKey("CustomPotionColor", 99)) {
         var3.setColor(var6.getInteger("CustomPotionColor"));
      }

      this.world.spawnEntityInWorld(var3);
   }

   private boolean isLingering() {
      return this.getPotion().getItem() == Items.LINGERING_POTION;
   }

   private void extinguishFires(BlockPos var1, EnumFacing var2) {
      if (this.world.getBlockState(var1).getBlock() == Blocks.FIRE) {
         this.world.extinguishFire((EntityPlayer)null, var1.offset(var2), var2.getOpposite());
      }

   }

   public static void registerFixesPotion(DataFixer var0) {
      EntityThrowable.registerFixesThrowable(var0, "ThrownPotion");
      var0.registerWalker(FixTypes.ENTITY, new ItemStackData(EntityPotion.class, new String[]{"Potion"}));
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      ItemStack var2 = new ItemStack(var1.getCompoundTag("Potion"));
      if (var2.func_190926_b()) {
         this.setDead();
      } else {
         this.setItem(var2);
      }

   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      ItemStack var2 = this.getPotion();
      if (!var2.func_190926_b()) {
         var1.setTag("Potion", var2.writeToNBT(new NBTTagCompound()));
      }

   }

   private static boolean func_190544_c(EntityLivingBase var0) {
      return var0 instanceof EntityEnderman || var0 instanceof EntityBlaze;
   }

   static boolean access$000(EntityLivingBase var0) {
      return func_190544_c(var0);
   }

   static {
      ITEM = EntityDataManager.<ItemStack>createKey(EntityPotion.class, DataSerializers.OPTIONAL_ITEM_STACK);
      LOGGER = LogManager.getLogger();
      field_190546_d = new Predicate<EntityLivingBase>() {
         public boolean apply(@Nullable EntityLivingBase var1) {
            return EntityPotion.access$000(var1);
         }
      };
   }
}
