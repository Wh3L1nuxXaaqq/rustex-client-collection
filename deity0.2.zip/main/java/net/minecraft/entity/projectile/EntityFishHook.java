package net.minecraft.entity.projectile;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.stats.StatList;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityFishHook extends Entity {
   private static final DataParameter<Integer> DATA_HOOKED_ENTITY;
   private boolean inGround;
   private int ticksInGround;
   private EntityPlayer angler;
   private int ticksInAir;
   private int ticksCatchable;
   private int ticksCaughtDelay;
   private int ticksCatchableDelay;
   private float fishApproachAngle;
   public Entity caughtEntity;
   private State field_190627_av;
   private int field_191518_aw;
   private int field_191519_ax;

   public EntityFishHook(World var1, EntityPlayer var2, double var3, double var5, double var7) {
      super(var1);
      this.field_190627_av = EntityFishHook.State.FLYING;
      this.func_190626_a(var2);
      this.setPosition(var3, var5, var7);
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
   }

   public EntityFishHook(World var1, EntityPlayer var2) {
      super(var1);
      this.field_190627_av = EntityFishHook.State.FLYING;
      this.func_190626_a(var2);
      this.func_190620_n();
   }

   private void func_190626_a(EntityPlayer var1) {
      this.setSize(0.25F, 0.25F);
      this.ignoreFrustumCheck = true;
      this.angler = var1;
      this.angler.fishEntity = this;
   }

   public void func_191516_a(int var1) {
      this.field_191519_ax = var1;
   }

   public void func_191517_b(int var1) {
      this.field_191518_aw = var1;
   }

   private void func_190620_n() {
      float var1 = this.angler.prevRotationPitch + (this.angler.rotationPitch - this.angler.prevRotationPitch);
      float var2 = this.angler.prevRotationYaw + (this.angler.rotationYaw - this.angler.prevRotationYaw);
      float var3 = MathHelper.cos(-var2 * ((float)Math.PI / 180F) - (float)Math.PI);
      float var4 = MathHelper.sin(-var2 * ((float)Math.PI / 180F) - (float)Math.PI);
      float var5 = -MathHelper.cos(-var1 * ((float)Math.PI / 180F));
      float var6 = MathHelper.sin(-var1 * ((float)Math.PI / 180F));
      double var7 = this.angler.prevPosX + (this.angler.posX - this.angler.prevPosX) - (double)var4 * 0.3;
      double var9 = this.angler.prevPosY + (this.angler.posY - this.angler.prevPosY) + (double)this.angler.getEyeHeight();
      double var11 = this.angler.prevPosZ + (this.angler.posZ - this.angler.prevPosZ) - (double)var3 * 0.3;
      this.setLocationAndAngles(var7, var9, var11, var2, var1);
      this.motionX = (double)(-var4);
      this.motionY = (double)MathHelper.clamp(-(var6 / var5), -5.0F, 5.0F);
      this.motionZ = (double)(-var3);
      float var13 = MathHelper.sqrt(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
      this.motionX *= 0.6 / (double)var13 + (double)0.5F + this.rand.nextGaussian() * 0.0045;
      this.motionY *= 0.6 / (double)var13 + (double)0.5F + this.rand.nextGaussian() * 0.0045;
      this.motionZ *= 0.6 / (double)var13 + (double)0.5F + this.rand.nextGaussian() * 0.0045;
      float var14 = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      this.rotationYaw = (float)(MathHelper.atan2(this.motionX, this.motionZ) * (180D / Math.PI));
      this.rotationPitch = (float)(MathHelper.atan2(this.motionY, (double)var14) * (180D / Math.PI));
      this.prevRotationYaw = this.rotationYaw;
      this.prevRotationPitch = this.rotationPitch;
   }

   protected void entityInit() {
      this.getDataManager().register(DATA_HOOKED_ENTITY, 0);
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      if (DATA_HOOKED_ENTITY.equals(var1)) {
         int var2 = (Integer)this.getDataManager().get(DATA_HOOKED_ENTITY);
         this.caughtEntity = var2 > 0 ? this.world.getEntityByID(var2 - 1) : null;
      }

      super.notifyDataManagerChange(var1);
   }

   public boolean isInRangeToRenderDist(double var1) {
      double var3 = (double)64.0F;
      return var1 < (double)4096.0F;
   }

   public void setPositionAndRotationDirect(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
   }

   public void onUpdate() {
      super.onUpdate();
      if (this.angler == null) {
         this.setDead();
      } else if (this.world.isRemote || !this.func_190625_o()) {
         if (this.inGround) {
            ++this.ticksInGround;
            if (this.ticksInGround >= 1200) {
               this.setDead();
               return;
            }
         }

         float var1 = 0.0F;
         BlockPos var2 = new BlockPos(this);
         IBlockState var3 = this.world.getBlockState(var2);
         if (var3.getMaterial() == Material.WATER) {
            var1 = BlockLiquid.func_190973_f(var3, this.world, var2);
         }

         if (this.field_190627_av == EntityFishHook.State.FLYING) {
            if (this.caughtEntity != null) {
               this.motionX = (double)0.0F;
               this.motionY = (double)0.0F;
               this.motionZ = (double)0.0F;
               this.field_190627_av = EntityFishHook.State.HOOKED_IN_ENTITY;
               return;
            }

            if (var1 > 0.0F) {
               this.motionX *= 0.3;
               this.motionY *= 0.2;
               this.motionZ *= 0.3;
               this.field_190627_av = EntityFishHook.State.BOBBING;
               return;
            }

            if (!this.world.isRemote) {
               this.func_190624_r();
            }

            if (!this.inGround && !this.onGround && !this.isCollidedHorizontally) {
               ++this.ticksInAir;
            } else {
               this.ticksInAir = 0;
               this.motionX = (double)0.0F;
               this.motionY = (double)0.0F;
               this.motionZ = (double)0.0F;
            }
         } else {
            if (this.field_190627_av == EntityFishHook.State.HOOKED_IN_ENTITY) {
               if (this.caughtEntity != null) {
                  if (this.caughtEntity.isDead) {
                     this.caughtEntity = null;
                     this.field_190627_av = EntityFishHook.State.FLYING;
                  } else {
                     this.posX = this.caughtEntity.posX;
                     double var7 = (double)this.caughtEntity.height;
                     this.posY = this.caughtEntity.getEntityBoundingBox().minY + var7 * 0.8;
                     this.posZ = this.caughtEntity.posZ;
                     this.setPosition(this.posX, this.posY, this.posZ);
                  }
               }

               return;
            }

            if (this.field_190627_av == EntityFishHook.State.BOBBING) {
               this.motionX *= 0.9;
               this.motionZ *= 0.9;
               double var4 = this.posY + this.motionY - (double)var2.getY() - (double)var1;
               if (Math.abs(var4) < 0.01) {
                  var4 += Math.signum(var4) * 0.1;
               }

               this.motionY -= var4 * (double)this.rand.nextFloat() * 0.2;
               if (!this.world.isRemote && var1 > 0.0F) {
                  this.func_190621_a(var2);
               }
            }
         }

         if (var3.getMaterial() != Material.WATER) {
            this.motionY -= 0.03;
         }

         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         this.func_190623_q();
         double var6 = 0.92;
         this.motionX *= 0.92;
         this.motionY *= 0.92;
         this.motionZ *= 0.92;
         this.setPosition(this.posX, this.posY, this.posZ);
      }

   }

   private boolean func_190625_o() {
      ItemStack var1 = this.angler.getHeldItemMainhand();
      ItemStack var2 = this.angler.getHeldItemOffhand();
      boolean var3 = var1.getItem() == Items.FISHING_ROD;
      boolean var4 = var2.getItem() == Items.FISHING_ROD;
      if (!this.angler.isDead && this.angler.isEntityAlive() && (var3 || var4) && this.getDistanceSqToEntity(this.angler) <= (double)1024.0F) {
         return false;
      } else {
         this.setDead();
         return true;
      }
   }

   private void func_190623_q() {
      float var1 = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      this.rotationYaw = (float)(MathHelper.atan2(this.motionX, this.motionZ) * (180D / Math.PI));

      for(this.rotationPitch = (float)(MathHelper.atan2(this.motionY, (double)var1) * (180D / Math.PI)); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F) {
      }

      while(this.rotationPitch - this.prevRotationPitch >= 180.0F) {
         this.prevRotationPitch += 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw < -180.0F) {
         this.prevRotationYaw -= 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw >= 180.0F) {
         this.prevRotationYaw += 360.0F;
      }

      this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
      this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
   }

   private void func_190624_r() {
      Vec3d var1 = new Vec3d(this.posX, this.posY, this.posZ);
      Vec3d var2 = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
      RayTraceResult var3 = this.world.rayTraceBlocks(var1, var2, false, true, false);
      var1 = new Vec3d(this.posX, this.posY, this.posZ);
      var2 = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
      if (var3 != null) {
         var2 = new Vec3d(var3.hitVec.xCoord, var3.hitVec.yCoord, var3.hitVec.zCoord);
      }

      Entity var4 = null;
      List var5 = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().addCoord(this.motionX, this.motionY, this.motionZ).expandXyz((double)1.0F));
      double var6 = (double)0.0F;

      for(Object var9_raw : var5) {
         Entity var9 = (Entity)var9_raw;
         if (this.canBeHooked(var9) && (var9 != this.angler || this.ticksInAir >= 5)) {
            AxisAlignedBB var10 = var9.getEntityBoundingBox().expandXyz((double)0.3F);
            RayTraceResult var11 = var10.calculateIntercept(var1, var2);
            if (var11 != null) {
               double var12 = var1.squareDistanceTo(var11.hitVec);
               if (var12 < var6 || var6 == (double)0.0F) {
                  var4 = var9;
                  var6 = var12;
               }
            }
         }
      }

      if (var4 != null) {
         var3 = new RayTraceResult(var4);
      }

      if (var3 != null && var3.typeOfHit != RayTraceResult.Type.MISS) {
         if (var3.typeOfHit == RayTraceResult.Type.ENTITY) {
            this.caughtEntity = var3.entityHit;
            this.func_190622_s();
         } else {
            this.inGround = true;
         }
      }

   }

   private void func_190622_s() {
      this.getDataManager().set(DATA_HOOKED_ENTITY, this.caughtEntity.getEntityId() + 1);
   }

   private void func_190621_a(BlockPos var1) {
      WorldServer var2 = (WorldServer)this.world;
      int var3 = 1;
      BlockPos var4 = var1.up();
      if (this.rand.nextFloat() < 0.25F && this.world.isRainingAt(var4)) {
         ++var3;
      }

      if (this.rand.nextFloat() < 0.5F && !this.world.canSeeSky(var4)) {
         --var3;
      }

      if (this.ticksCatchable > 0) {
         --this.ticksCatchable;
         if (this.ticksCatchable <= 0) {
            this.ticksCaughtDelay = 0;
            this.ticksCatchableDelay = 0;
         } else {
            this.motionY -= 0.2 * (double)this.rand.nextFloat() * (double)this.rand.nextFloat();
         }
      } else if (this.ticksCatchableDelay > 0) {
         this.ticksCatchableDelay -= var3;
         if (this.ticksCatchableDelay > 0) {
            this.fishApproachAngle = (float)((double)this.fishApproachAngle + this.rand.nextGaussian() * (double)4.0F);
            float var5 = this.fishApproachAngle * ((float)Math.PI / 180F);
            float var6 = MathHelper.sin(var5);
            float var7 = MathHelper.cos(var5);
            double var8 = this.posX + (double)(var6 * (float)this.ticksCatchableDelay * 0.1F);
            double var10 = (double)((float)MathHelper.floor(this.getEntityBoundingBox().minY) + 1.0F);
            double var12 = this.posZ + (double)(var7 * (float)this.ticksCatchableDelay * 0.1F);
            Block var14 = var2.getBlockState(new BlockPos(var8, var10 - (double)1.0F, var12)).getBlock();
            if (var14 == Blocks.WATER || var14 == Blocks.FLOWING_WATER) {
               if (this.rand.nextFloat() < 0.15F) {
                  var2.spawnParticle(EnumParticleTypes.WATER_BUBBLE, var8, var10 - (double)0.1F, var12, 1, (double)var6, 0.1, (double)var7, (double)0.0F);
               }

               float var15 = var6 * 0.04F;
               float var16 = var7 * 0.04F;
               var2.spawnParticle(EnumParticleTypes.WATER_WAKE, var8, var10, var12, 0, (double)var16, 0.01, (double)(-var15), (double)1.0F);
               var2.spawnParticle(EnumParticleTypes.WATER_WAKE, var8, var10, var12, 0, (double)(-var16), 0.01, (double)var15, (double)1.0F);
            }
         } else {
            this.motionY = (double)(-0.4F * MathHelper.nextFloat(this.rand, 0.6F, 1.0F));
            this.playSound(SoundEvents.ENTITY_BOBBER_SPLASH, 0.25F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
            double var17 = this.getEntityBoundingBox().minY + (double)0.5F;
            var2.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX, var17, this.posZ, (int)(1.0F + this.width * 20.0F), (double)this.width, (double)0.0F, (double)this.width, (double)0.2F);
            var2.spawnParticle(EnumParticleTypes.WATER_WAKE, this.posX, var17, this.posZ, (int)(1.0F + this.width * 20.0F), (double)this.width, (double)0.0F, (double)this.width, (double)0.2F);
            this.ticksCatchable = MathHelper.getInt((Random)this.rand, 20, 40);
         }
      } else if (this.ticksCaughtDelay > 0) {
         this.ticksCaughtDelay -= var3;
         float var18 = 0.15F;
         if (this.ticksCaughtDelay < 20) {
            var18 = (float)((double)var18 + (double)(20 - this.ticksCaughtDelay) * 0.05);
         } else if (this.ticksCaughtDelay < 40) {
            var18 = (float)((double)var18 + (double)(40 - this.ticksCaughtDelay) * 0.02);
         } else if (this.ticksCaughtDelay < 60) {
            var18 = (float)((double)var18 + (double)(60 - this.ticksCaughtDelay) * 0.01);
         }

         if (this.rand.nextFloat() < var18) {
            float var19 = MathHelper.nextFloat(this.rand, 0.0F, 360.0F) * ((float)Math.PI / 180F);
            float var20 = MathHelper.nextFloat(this.rand, 25.0F, 60.0F);
            double var21 = this.posX + (double)(MathHelper.sin(var19) * var20 * 0.1F);
            double var22 = (double)((float)MathHelper.floor(this.getEntityBoundingBox().minY) + 1.0F);
            double var23 = this.posZ + (double)(MathHelper.cos(var19) * var20 * 0.1F);
            Block var24 = var2.getBlockState(new BlockPos((int)var21, (int)var22 - 1, (int)var23)).getBlock();
            if (var24 == Blocks.WATER || var24 == Blocks.FLOWING_WATER) {
               var2.spawnParticle(EnumParticleTypes.WATER_SPLASH, var21, var22, var23, 2 + this.rand.nextInt(2), (double)0.1F, (double)0.0F, (double)0.1F, (double)0.0F);
            }
         }

         if (this.ticksCaughtDelay <= 0) {
            this.fishApproachAngle = MathHelper.nextFloat(this.rand, 0.0F, 360.0F);
            this.ticksCatchableDelay = MathHelper.getInt((Random)this.rand, 20, 80);
         }
      } else {
         this.ticksCaughtDelay = MathHelper.getInt((Random)this.rand, 100, 600);
         this.ticksCaughtDelay -= this.field_191519_ax * 20 * 5;
      }

   }

   protected boolean canBeHooked(Entity var1) {
      return var1.canBeCollidedWith() || var1 instanceof EntityItem;
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
   }

   public int handleHookRetraction() {
      if (!this.world.isRemote && this.angler != null) {
         int var1 = 0;
         if (this.caughtEntity != null) {
            this.bringInHookedEntity();
            this.world.setEntityState(this, (byte)31);
            var1 = this.caughtEntity instanceof EntityItem ? 3 : 5;
         } else if (this.ticksCatchable > 0) {
            LootContext.Builder var2 = new LootContext.Builder((WorldServer)this.world);
            var2.withLuck((float)this.field_191518_aw + this.angler.getLuck());

            for(ItemStack var4 : this.world.getLootTableManager().getLootTableFromLocation(LootTableList.GAMEPLAY_FISHING).generateLootForPools(this.rand, var2.build())) {
               EntityItem var5 = new EntityItem(this.world, this.posX, this.posY, this.posZ, var4);
               double var6 = this.angler.posX - this.posX;
               double var8 = this.angler.posY - this.posY;
               double var10 = this.angler.posZ - this.posZ;
               double var12 = (double)MathHelper.sqrt(var6 * var6 + var8 * var8 + var10 * var10);
               double var14 = 0.1;
               var5.motionX = var6 * 0.1;
               var5.motionY = var8 * 0.1 + (double)MathHelper.sqrt(var12) * 0.08;
               var5.motionZ = var10 * 0.1;
               this.world.spawnEntityInWorld(var5);
               this.angler.world.spawnEntityInWorld(new EntityXPOrb(this.angler.world, this.angler.posX, this.angler.posY + (double)0.5F, this.angler.posZ + (double)0.5F, this.rand.nextInt(6) + 1));
               Item var16 = var4.getItem();
               if (var16 == Items.FISH || var16 == Items.COOKED_FISH) {
                  this.angler.addStat(StatList.FISH_CAUGHT, 1);
               }
            }

            var1 = 1;
         }

         if (this.inGround) {
            var1 = 2;
         }

         this.setDead();
         return var1;
      } else {
         return 0;
      }
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 31 && this.world.isRemote && this.caughtEntity instanceof EntityPlayer && ((EntityPlayer)this.caughtEntity).isUser()) {
         this.bringInHookedEntity();
      }

      super.handleStatusUpdate(var1);
   }

   protected void bringInHookedEntity() {
      if (this.angler != null) {
         double var1 = this.angler.posX - this.posX;
         double var3 = this.angler.posY - this.posY;
         double var5 = this.angler.posZ - this.posZ;
         double var7 = 0.1;
         Entity var10000 = this.caughtEntity;
         var10000.motionX += var1 * 0.1;
         var10000 = this.caughtEntity;
         var10000.motionY += var3 * 0.1;
         var10000 = this.caughtEntity;
         var10000.motionZ += var5 * 0.1;
      }

   }

   protected boolean canTriggerWalking() {
      return false;
   }

   public void setDead() {
      super.setDead();
      if (this.angler != null) {
         this.angler.fishEntity = null;
      }

   }

   public EntityPlayer func_190619_l() {
      return this.angler;
   }

   static {
      DATA_HOOKED_ENTITY = EntityDataManager.<Integer>createKey(EntityFishHook.class, DataSerializers.VARINT);
   }

   static enum State {
      FLYING,
      HOOKED_IN_ENTITY,
      BOBBING;
   }
}
