package net.minecraft.entity.passive;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public abstract class EntityAnimal extends EntityAgeable implements IAnimals {
   protected Block spawnableBlock;
   private int inLove;
   private UUID playerInLove;

   public EntityAnimal(World var1) {
      super(var1);
      this.spawnableBlock = Blocks.GRASS;
   }

   protected void updateAITasks() {
      if (this.getGrowingAge() != 0) {
         this.inLove = 0;
      }

      super.updateAITasks();
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if (this.getGrowingAge() != 0) {
         this.inLove = 0;
      }

      if (this.inLove > 0) {
         --this.inLove;
         if (this.inLove % 10 == 0) {
            double var1 = this.rand.nextGaussian() * 0.02;
            double var3 = this.rand.nextGaussian() * 0.02;
            double var5 = this.rand.nextGaussian() * 0.02;
            this.world.spawnParticle(EnumParticleTypes.HEART, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)0.5F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, var1, var3, var5);
         }
      }

   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (this.isEntityInvulnerable(var1)) {
         return false;
      } else {
         this.inLove = 0;
         return super.attackEntityFrom(var1, var2);
      }
   }

   public float getBlockPathWeight(BlockPos var1) {
      return this.world.getBlockState(var1.down()).getBlock() == this.spawnableBlock ? 10.0F : this.world.getLightBrightness(var1) - 0.5F;
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("InLove", this.inLove);
      if (this.playerInLove != null) {
         var1.setUniqueId("LoveCause", this.playerInLove);
      }

   }

   public double getYOffset() {
      return 0.14;
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.inLove = var1.getInteger("InLove");
      this.playerInLove = var1.hasUniqueId("LoveCause") ? var1.getUniqueId("LoveCause") : null;
   }

   public boolean getCanSpawnHere() {
      int var1 = MathHelper.floor(this.posX);
      int var2 = MathHelper.floor(this.getEntityBoundingBox().minY);
      int var3 = MathHelper.floor(this.posZ);
      BlockPos var4 = new BlockPos(var1, var2, var3);
      return this.world.getBlockState(var4.down()).getBlock() == this.spawnableBlock && this.world.getLight(var4) > 8 && super.getCanSpawnHere();
   }

   public int getTalkInterval() {
      return 120;
   }

   protected boolean canDespawn() {
      return false;
   }

   protected int getExperiencePoints(EntityPlayer var1) {
      return 1 + this.world.rand.nextInt(3);
   }

   public boolean isBreedingItem(ItemStack var1) {
      return var1.getItem() == Items.WHEAT;
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (!var3.func_190926_b()) {
         if (this.isBreedingItem(var3) && this.getGrowingAge() == 0 && this.inLove <= 0) {
            this.consumeItemFromStack(var1, var3);
            this.setInLove(var1);
            return true;
         }

         if (this.isChild() && this.isBreedingItem(var3)) {
            this.consumeItemFromStack(var1, var3);
            this.ageUp((int)((float)(-this.getGrowingAge() / 20) * 0.1F), true);
            return true;
         }
      }

      return super.processInteract(var1, var2);
   }

   protected void consumeItemFromStack(EntityPlayer var1, ItemStack var2) {
      if (!var1.capabilities.isCreativeMode) {
         var2.func_190918_g(1);
      }

   }

   public void setInLove(@Nullable EntityPlayer var1) {
      this.inLove = 600;
      if (var1 != null) {
         this.playerInLove = var1.getUniqueID();
      }

      this.world.setEntityState(this, (byte)18);
   }

   @Nullable
   public EntityPlayerMP func_191993_do() {
      if (this.playerInLove == null) {
         return null;
      } else {
         EntityPlayer var1 = this.world.getPlayerEntityByUUID(this.playerInLove);
         return var1 instanceof EntityPlayerMP ? (EntityPlayerMP)var1 : null;
      }
   }

   public boolean isInLove() {
      return this.inLove > 0;
   }

   public void resetInLove() {
      this.inLove = 0;
   }

   public boolean canMateWith(EntityAnimal var1) {
      if (var1 == this) {
         return false;
      } else if (var1.getClass() != this.getClass()) {
         return false;
      } else {
         return this.isInLove() && var1.isInLove();
      }
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 18) {
         for(int var2 = 0; var2 < 7; ++var2) {
            double var3 = this.rand.nextGaussian() * 0.02;
            double var5 = this.rand.nextGaussian() * 0.02;
            double var7 = this.rand.nextGaussian() * 0.02;
            this.world.spawnParticle(EnumParticleTypes.HEART, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)0.5F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, var3, var5, var7);
         }
      } else {
         super.handleStatusUpdate(var1);
      }

   }
}
