package net.minecraft.entity.passive;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIEatGrass;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntitySheep extends EntityAnimal {
   private static final DataParameter<Byte> DYE_COLOR;
   private final InventoryCrafting inventoryCrafting = new InventoryCrafting(new Container() {
      public boolean canInteractWith(EntityPlayer var1) {
         return false;
      }
   }, 2, 1);
   private static final Map<EnumDyeColor, float[]> DYE_TO_RGB;
   private int sheepTimer;
   private EntityAIEatGrass entityAIEatGrass;

   private static float[] func_192020_c(EnumDyeColor var0) {
      float[] var1 = var0.func_193349_f();
      float var2 = 0.75F;
      return new float[]{var1[0] * 0.75F, var1[1] * 0.75F, var1[2] * 0.75F};
   }

   public static float[] getDyeRgb(EnumDyeColor var0) {
      return (float[])DYE_TO_RGB.get(var0);
   }

   public EntitySheep(World var1) {
      super(var1);
      this.setSize(0.9F, 1.3F);
      this.inventoryCrafting.setInventorySlotContents(0, new ItemStack(Items.DYE));
      this.inventoryCrafting.setInventorySlotContents(1, new ItemStack(Items.DYE));
   }

   protected void initEntityAI() {
      this.entityAIEatGrass = new EntityAIEatGrass(this);
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIPanic(this, (double)1.25F));
      this.tasks.addTask(2, new EntityAIMate(this, (double)1.0F));
      this.tasks.addTask(3, new EntityAITempt(this, 1.1, Items.WHEAT, false));
      this.tasks.addTask(4, new EntityAIFollowParent(this, 1.1));
      this.tasks.addTask(5, this.entityAIEatGrass);
      this.tasks.addTask(6, new EntityAIWanderAvoidWater(this, (double)1.0F));
      this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      this.tasks.addTask(8, new EntityAILookIdle(this));
   }

   protected void updateAITasks() {
      this.sheepTimer = this.entityAIEatGrass.getEatingGrassTimer();
      super.updateAITasks();
   }

   public void onLivingUpdate() {
      if (this.world.isRemote) {
         this.sheepTimer = Math.max(0, this.sheepTimer - 1);
      }

      super.onLivingUpdate();
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)8.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.23F);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(DYE_COLOR, (byte)0);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      if (this.getSheared()) {
         return LootTableList.ENTITIES_SHEEP;
      } else {
         switch (this.getFleeceColor()) {
            case WHITE:
            default:
               return LootTableList.ENTITIES_SHEEP_WHITE;
            case ORANGE:
               return LootTableList.ENTITIES_SHEEP_ORANGE;
            case MAGENTA:
               return LootTableList.ENTITIES_SHEEP_MAGENTA;
            case LIGHT_BLUE:
               return LootTableList.ENTITIES_SHEEP_LIGHT_BLUE;
            case YELLOW:
               return LootTableList.ENTITIES_SHEEP_YELLOW;
            case LIME:
               return LootTableList.ENTITIES_SHEEP_LIME;
            case PINK:
               return LootTableList.ENTITIES_SHEEP_PINK;
            case GRAY:
               return LootTableList.ENTITIES_SHEEP_GRAY;
            case SILVER:
               return LootTableList.ENTITIES_SHEEP_SILVER;
            case CYAN:
               return LootTableList.ENTITIES_SHEEP_CYAN;
            case PURPLE:
               return LootTableList.ENTITIES_SHEEP_PURPLE;
            case BLUE:
               return LootTableList.ENTITIES_SHEEP_BLUE;
            case BROWN:
               return LootTableList.ENTITIES_SHEEP_BROWN;
            case GREEN:
               return LootTableList.ENTITIES_SHEEP_GREEN;
            case RED:
               return LootTableList.ENTITIES_SHEEP_RED;
            case BLACK:
               return LootTableList.ENTITIES_SHEEP_BLACK;
         }
      }
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 10) {
         this.sheepTimer = 40;
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   public float getHeadRotationPointY(float var1) {
      if (this.sheepTimer <= 0) {
         return 0.0F;
      } else if (this.sheepTimer >= 4 && this.sheepTimer <= 36) {
         return 1.0F;
      } else {
         return this.sheepTimer < 4 ? ((float)this.sheepTimer - var1) / 4.0F : -((float)(this.sheepTimer - 40) - var1) / 4.0F;
      }
   }

   public float getHeadRotationAngleX(float var1) {
      if (this.sheepTimer > 4 && this.sheepTimer <= 36) {
         float var2 = ((float)(this.sheepTimer - 4) - var1) / 32.0F;
         return ((float)Math.PI / 5F) + 0.2199115F * MathHelper.sin(var2 * 28.7F);
      } else {
         return this.sheepTimer > 0 ? ((float)Math.PI / 5F) : this.rotationPitch * ((float)Math.PI / 180F);
      }
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (var3.getItem() == Items.SHEARS && !this.getSheared() && !this.isChild()) {
         if (!this.world.isRemote) {
            this.setSheared(true);
            int var4 = 1 + this.rand.nextInt(3);

            for(int var5 = 0; var5 < var4; ++var5) {
               EntityItem var6 = this.entityDropItem(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, this.getFleeceColor().getMetadata()), 1.0F);
               var6.motionY += (double)(this.rand.nextFloat() * 0.05F);
               var6.motionX += (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F);
               var6.motionZ += (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F);
            }
         }

         var3.damageItem(1, var1);
         this.playSound(SoundEvents.ENTITY_SHEEP_SHEAR, 1.0F, 1.0F);
      }

      return super.processInteract(var1, var2);
   }

   public static void registerFixesSheep(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntitySheep.class);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("Sheared", this.getSheared());
      var1.setByte("Color", (byte)this.getFleeceColor().getMetadata());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setSheared(var1.getBoolean("Sheared"));
      this.setFleeceColor(EnumDyeColor.byMetadata(var1.getByte("Color")));
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_SHEEP_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_SHEEP_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_SHEEP_DEATH;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(SoundEvents.ENTITY_SHEEP_STEP, 0.15F, 1.0F);
   }

   public EnumDyeColor getFleeceColor() {
      return EnumDyeColor.byMetadata((Byte)this.dataManager.get(DYE_COLOR) & 15);
   }

   public void setFleeceColor(EnumDyeColor var1) {
      byte var2 = (Byte)this.dataManager.get(DYE_COLOR);
      this.dataManager.set(DYE_COLOR, (byte)(var2 & 240 | var1.getMetadata() & 15));
   }

   public boolean getSheared() {
      return ((Byte)this.dataManager.get(DYE_COLOR) & 16) != 0;
   }

   public void setSheared(boolean var1) {
      byte var2 = (Byte)this.dataManager.get(DYE_COLOR);
      if (var1) {
         this.dataManager.set(DYE_COLOR, (byte)(var2 | 16));
      } else {
         this.dataManager.set(DYE_COLOR, (byte)(var2 & -17));
      }

   }

   public static EnumDyeColor getRandomSheepColor(Random var0) {
      int var1 = var0.nextInt(100);
      if (var1 < 5) {
         return EnumDyeColor.BLACK;
      } else if (var1 < 10) {
         return EnumDyeColor.GRAY;
      } else if (var1 < 15) {
         return EnumDyeColor.SILVER;
      } else if (var1 < 18) {
         return EnumDyeColor.BROWN;
      } else {
         return var0.nextInt(500) == 0 ? EnumDyeColor.PINK : EnumDyeColor.WHITE;
      }
   }

   public EntitySheep createChild(EntityAgeable var1) {
      EntitySheep var2 = (EntitySheep)var1;
      EntitySheep var3 = new EntitySheep(this.world);
      var3.setFleeceColor(this.getDyeColorMixFromParents(this, var2));
      return var3;
   }

   public void eatGrassBonus() {
      this.setSheared(false);
      if (this.isChild()) {
         this.addGrowth(60);
      }

   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      this.setFleeceColor(getRandomSheepColor(this.world.rand));
      return var2;
   }

   private EnumDyeColor getDyeColorMixFromParents(EntityAnimal var1, EntityAnimal var2) {
      int var3 = ((EntitySheep)var1).getFleeceColor().getDyeDamage();
      int var4 = ((EntitySheep)var2).getFleeceColor().getDyeDamage();
      this.inventoryCrafting.getStackInSlot(0).setItemDamage(var3);
      this.inventoryCrafting.getStackInSlot(1).setItemDamage(var4);
      ItemStack var5 = CraftingManager.findMatchingRecipe(this.inventoryCrafting, ((EntitySheep)var1).world);
      int var6;
      if (var5.getItem() == Items.DYE) {
         var6 = var5.getMetadata();
      } else {
         var6 = this.world.rand.nextBoolean() ? var3 : var4;
      }

      return EnumDyeColor.byDyeDamage(var6);
   }

   public float getEyeHeight() {
      return 0.95F * this.height;
   }

   static {
      DYE_COLOR = EntityDataManager.<Byte>createKey(EntitySheep.class, DataSerializers.BYTE);
      DYE_TO_RGB = Maps.newEnumMap(EnumDyeColor.class);

      for(EnumDyeColor var3 : EnumDyeColor.values()) {
         DYE_TO_RGB.put(var3, func_192020_c(var3));
      }

      DYE_TO_RGB.put(EnumDyeColor.WHITE, new float[]{0.9019608F, 0.9019608F, 0.9019608F});
   }
}
