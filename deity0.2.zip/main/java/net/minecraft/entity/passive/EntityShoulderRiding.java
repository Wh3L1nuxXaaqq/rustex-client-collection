package net.minecraft.entity.passive;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract class EntityShoulderRiding extends EntityTameable {
   private int field_191996_bB;

   public EntityShoulderRiding(World var1) {
      super(var1);
   }

   public boolean func_191994_f(EntityPlayer var1) {
      NBTTagCompound var2 = new NBTTagCompound();
      var2.setString("id", this.getEntityString());
      this.writeToNBT(var2);
      if (var1.func_192027_g(var2)) {
         this.world.removeEntity(this);
         return true;
      } else {
         return false;
      }
   }

   public void onUpdate() {
      ++this.field_191996_bB;
      super.onUpdate();
   }

   public boolean func_191995_du() {
      return this.field_191996_bB > 100;
   }
}
