package net.minecraft.entity.passive;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityDonkey extends AbstractChestHorse {
   public EntityDonkey(World var1) {
      super(var1);
   }

   public static void func_190699_b(DataFixer var0) {
      AbstractChestHorse.func_190694_b(var0, EntityDonkey.class);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191190_H;
   }

   protected SoundEvent getAmbientSound() {
      super.getAmbientSound();
      return SoundEvents.ENTITY_DONKEY_AMBIENT;
   }

   protected SoundEvent getDeathSound() {
      super.getDeathSound();
      return SoundEvents.ENTITY_DONKEY_DEATH;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      super.getHurtSound(var1);
      return SoundEvents.ENTITY_DONKEY_HURT;
   }

   public boolean canMateWith(EntityAnimal var1) {
      if (var1 == this) {
         return false;
      } else if (!(var1 instanceof EntityDonkey) && !(var1 instanceof EntityHorse)) {
         return false;
      } else {
         return this.canMate() && ((AbstractHorse)var1).canMate();
      }
   }

   public EntityAgeable createChild(EntityAgeable var1) {
      Object var2 = var1 instanceof EntityHorse ? new EntityMule(this.world) : new EntityDonkey(this.world);
      this.func_190681_a(var1, (AbstractHorse)var2);
      return (EntityAgeable)var2;
   }
}
