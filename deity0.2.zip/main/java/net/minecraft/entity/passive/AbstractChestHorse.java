package net.minecraft.entity.passive;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.world.World;

public abstract class AbstractChestHorse extends AbstractHorse {
   private static final DataParameter<Boolean> field_190698_bG;

   public AbstractChestHorse(World var1) {
      super(var1);
      this.field_190688_bE = false;
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_190698_bG, false);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)this.getModifiedMaxHealth());
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.175F);
      this.getEntityAttribute(JUMP_STRENGTH).setBaseValue((double)0.5F);
   }

   public boolean func_190695_dh() {
      return (Boolean)this.dataManager.get(field_190698_bG);
   }

   public void setChested(boolean var1) {
      this.dataManager.set(field_190698_bG, var1);
   }

   protected int func_190686_di() {
      return this.func_190695_dh() ? 17 : super.func_190686_di();
   }

   public double getMountedYOffset() {
      return super.getMountedYOffset() - (double)0.25F;
   }

   protected SoundEvent getAngrySound() {
      super.getAngrySound();
      return SoundEvents.ENTITY_DONKEY_ANGRY;
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (this.func_190695_dh()) {
         if (!this.world.isRemote) {
            this.dropItem(Item.getItemFromBlock(Blocks.CHEST), 1);
         }

         this.setChested(false);
      }

   }

   public static void func_190694_b(DataFixer var0, Class<?> var1) {
      AbstractHorse.func_190683_c(var0, var1);
      var0.registerWalker(FixTypes.ENTITY, new ItemStackDataLists(var1, new String[]{"Items"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("ChestedHorse", this.func_190695_dh());
      if (this.func_190695_dh()) {
         NBTTagList var2 = new NBTTagList();

         for(int var3 = 2; var3 < this.horseChest.getSizeInventory(); ++var3) {
            ItemStack var4 = this.horseChest.getStackInSlot(var3);
            if (!var4.func_190926_b()) {
               NBTTagCompound var5 = new NBTTagCompound();
               var5.setByte("Slot", (byte)var3);
               var4.writeToNBT(var5);
               var2.appendTag(var5);
            }
         }

         var1.setTag("Items", var2);
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setChested(var1.getBoolean("ChestedHorse"));
      if (this.func_190695_dh()) {
         NBTTagList var2 = var1.getTagList("Items", 10);
         this.initHorseChest();

         for(int var3 = 0; var3 < var2.tagCount(); ++var3) {
            NBTTagCompound var4 = var2.getCompoundTagAt(var3);
            int var5 = var4.getByte("Slot") & 255;
            if (var5 >= 2 && var5 < this.horseChest.getSizeInventory()) {
               this.horseChest.setInventorySlotContents(var5, new ItemStack(var4));
            }
         }
      }

      this.updateHorseSlots();
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      if (var1 == 499) {
         if (this.func_190695_dh() && var2.func_190926_b()) {
            this.setChested(false);
            this.initHorseChest();
            return true;
         }

         if (!this.func_190695_dh() && var2.getItem() == Item.getItemFromBlock(Blocks.CHEST)) {
            this.setChested(true);
            this.initHorseChest();
            return true;
         }
      }

      return super.replaceItemInInventory(var1, var2);
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (var3.getItem() == Items.SPAWN_EGG) {
         return super.processInteract(var1, var2);
      } else {
         if (!this.isChild()) {
            if (this.isTame() && var1.isSneaking()) {
               this.openGUI(var1);
               return true;
            }

            if (this.isBeingRidden()) {
               return super.processInteract(var1, var2);
            }
         }

         if (!var3.func_190926_b()) {
            boolean var4 = this.func_190678_b(var1, var3);
            if (!var4 && !this.isTame()) {
               if (var3.interactWithEntity(var1, this, var2)) {
                  return true;
               }

               this.func_190687_dF();
               return true;
            }

            if (!var4 && !this.func_190695_dh() && var3.getItem() == Item.getItemFromBlock(Blocks.CHEST)) {
               this.setChested(true);
               this.func_190697_dk();
               var4 = true;
               this.initHorseChest();
            }

            if (!var4 && !this.isChild() && !this.isHorseSaddled() && var3.getItem() == Items.SADDLE) {
               this.openGUI(var1);
               return true;
            }

            if (var4) {
               if (!var1.capabilities.isCreativeMode) {
                  var3.func_190918_g(1);
               }

               return true;
            }
         }

         if (this.isChild()) {
            return super.processInteract(var1, var2);
         } else if (var3.interactWithEntity(var1, this, var2)) {
            return true;
         } else {
            this.mountTo(var1);
            return true;
         }
      }
   }

   protected void func_190697_dk() {
      this.playSound(SoundEvents.ENTITY_DONKEY_CHEST, 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
   }

   public int func_190696_dl() {
      return 5;
   }

   static {
      field_190698_bG = EntityDataManager.<Boolean>createKey(AbstractChestHorse.class, DataSerializers.BOOLEAN);
   }
}
