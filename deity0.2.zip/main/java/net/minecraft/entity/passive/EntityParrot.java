package net.minecraft.entity.passive;

import com.google.common.base.Predicate;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollow;
import net.minecraft.entity.ai.EntityAIFollowOwnerFlying;
import net.minecraft.entity.ai.EntityAILandOnOwnersShoulder;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWaterFlying;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityFlyHelper;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityElderGuardian;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityEndermite;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityHusk;
import net.minecraft.entity.monster.EntityIllusionIllager;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityPolarBear;
import net.minecraft.entity.monster.EntityShulker;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityStray;
import net.minecraft.entity.monster.EntityVex;
import net.minecraft.entity.monster.EntityVindicator;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.EntityZombieVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateFlying;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityParrot extends EntityShoulderRiding implements EntityFlying {
   private static final DataParameter<Integer> field_192013_bG;
   private static final Predicate<EntityLiving> field_192014_bH;
   private static final Item field_192015_bI;
   private static final Set<Item> field_192016_bJ;
   private static final Int2ObjectMap<SoundEvent> field_192017_bK;
   public float field_192008_bB;
   public float field_192009_bC;
   public float field_192010_bD;
   public float field_192011_bE;
   public float field_192012_bF = 1.0F;
   private boolean field_192018_bL;
   private BlockPos field_192019_bM;

   public EntityParrot(World var1) {
      super(var1);
      this.setSize(0.5F, 0.9F);
      this.moveHelper = new EntityFlyHelper(this);
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      this.func_191997_m(this.rand.nextInt(5));
      return super.onInitialSpawn(var1, var2);
   }

   protected void initEntityAI() {
      this.aiSit = new EntityAISit(this);
      this.tasks.addTask(0, new EntityAIPanic(this, (double)1.25F));
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      this.tasks.addTask(2, this.aiSit);
      this.tasks.addTask(2, new EntityAIFollowOwnerFlying(this, (double)1.0F, 5.0F, 1.0F));
      this.tasks.addTask(2, new EntityAIWanderAvoidWaterFlying(this, (double)1.0F));
      this.tasks.addTask(3, new EntityAILandOnOwnersShoulder(this));
      this.tasks.addTask(3, new EntityAIFollow(this, (double)1.0F, 3.0F, 7.0F));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.field_193334_e);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)6.0F);
      this.getEntityAttribute(SharedMonsterAttributes.field_193334_e).setBaseValue((double)0.4F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.2F);
   }

   protected PathNavigate getNewNavigator(World var1) {
      PathNavigateFlying var2 = new PathNavigateFlying(this, var1);
      var2.func_192879_a(false);
      var2.func_192877_c(true);
      var2.func_192878_b(true);
      return var2;
   }

   public float getEyeHeight() {
      return this.height * 0.6F;
   }

   public void onLivingUpdate() {
      func_192006_b(this.world, this);
      if (this.field_192019_bM == null || this.field_192019_bM.distanceSq(this.posX, this.posY, this.posZ) > (double)12.0F || this.world.getBlockState(this.field_192019_bM).getBlock() != Blocks.JUKEBOX) {
         this.field_192018_bL = false;
         this.field_192019_bM = null;
      }

      super.onLivingUpdate();
      this.func_192001_dv();
   }

   public void func_191987_a(BlockPos var1, boolean var2) {
      this.field_192019_bM = var1;
      this.field_192018_bL = var2;
   }

   public boolean func_192004_dr() {
      return this.field_192018_bL;
   }

   private void func_192001_dv() {
      this.field_192011_bE = this.field_192008_bB;
      this.field_192010_bD = this.field_192009_bC;
      this.field_192009_bC = (float)((double)this.field_192009_bC + (double)(this.onGround ? -1 : 4) * 0.3);
      this.field_192009_bC = MathHelper.clamp(this.field_192009_bC, 0.0F, 1.0F);
      if (!this.onGround && this.field_192012_bF < 1.0F) {
         this.field_192012_bF = 1.0F;
      }

      this.field_192012_bF = (float)((double)this.field_192012_bF * 0.9);
      if (!this.onGround && this.motionY < (double)0.0F) {
         this.motionY *= 0.6;
      }

      this.field_192008_bB += this.field_192012_bF * 2.0F;
   }

   private static boolean func_192006_b(World var0, Entity var1) {
      if (!var1.isSilent() && var0.rand.nextInt(50) == 0) {
         List var2 = var0.getEntitiesWithinAABB(EntityLiving.class, var1.getEntityBoundingBox().expandXyz((double)20.0F), field_192014_bH);
         if (!var2.isEmpty()) {
            EntityLiving var3 = (EntityLiving)var2.get(var0.rand.nextInt(var2.size()));
            if (!var3.isSilent()) {
               SoundEvent var4 = func_191999_g(EntityList.field_191308_b.getIDForObject(var3.getClass()));
               var0.playSound((EntityPlayer)null, var1.posX, var1.posY, var1.posZ, var4, var1.getSoundCategory(), 0.7F, func_192000_b(var0.rand));
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (!this.isTamed() && field_192016_bJ.contains(var3.getItem())) {
         if (!var1.capabilities.isCreativeMode) {
            var3.func_190918_g(1);
         }

         if (!this.isSilent()) {
            this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.field_192797_eu, this.getSoundCategory(), 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
         }

         if (!this.world.isRemote) {
            if (this.rand.nextInt(10) == 0) {
               this.func_193101_c(var1);
               this.playTameEffect(true);
               this.world.setEntityState(this, (byte)7);
            } else {
               this.playTameEffect(false);
               this.world.setEntityState(this, (byte)6);
            }
         }

         return true;
      } else if (var3.getItem() == field_192015_bI) {
         if (!var1.capabilities.isCreativeMode) {
            var3.func_190918_g(1);
         }

         this.addPotionEffect(new PotionEffect(MobEffects.POISON, 900));
         if (var1.isCreative() || !this.func_190530_aW()) {
            this.attackEntityFrom(DamageSource.causePlayerDamage(var1), Float.MAX_VALUE);
         }

         return true;
      } else {
         if (!this.world.isRemote && !this.func_192002_a() && this.isTamed() && this.isOwner(var1)) {
            this.aiSit.setSitting(!this.isSitting());
         }

         return super.processInteract(var1, var2);
      }
   }

   public boolean isBreedingItem(ItemStack var1) {
      return false;
   }

   public boolean getCanSpawnHere() {
      int var1 = MathHelper.floor(this.posX);
      int var2 = MathHelper.floor(this.getEntityBoundingBox().minY);
      int var3 = MathHelper.floor(this.posZ);
      BlockPos var4 = new BlockPos(var1, var2, var3);
      Block var5 = this.world.getBlockState(var4.down()).getBlock();
      return var5 instanceof BlockLeaves || var5 == Blocks.GRASS || var5 instanceof BlockLog || var5 == Blocks.AIR && this.world.getLight(var4) > 8 && super.getCanSpawnHere();
   }

   public void fall(float var1, float var2) {
   }

   protected void updateFallState(double var1, boolean var3, IBlockState var4, BlockPos var5) {
   }

   public boolean canMateWith(EntityAnimal var1) {
      return false;
   }

   @Nullable
   public EntityAgeable createChild(EntityAgeable var1) {
      return null;
   }

   public static void func_192005_a(World var0, Entity var1) {
      if (!var1.isSilent() && !func_192006_b(var0, var1) && var0.rand.nextInt(200) == 0) {
         var0.playSound((EntityPlayer)null, var1.posX, var1.posY, var1.posZ, func_192003_a(var0.rand), var1.getSoundCategory(), 1.0F, func_192000_b(var0.rand));
      }

   }

   public boolean attackEntityAsMob(Entity var1) {
      return var1.attackEntityFrom(DamageSource.causeMobDamage(this), 3.0F);
   }

   @Nullable
   public SoundEvent getAmbientSound() {
      return func_192003_a(this.rand);
   }

   private static SoundEvent func_192003_a(Random var0) {
      if (var0.nextInt(1000) == 0) {
         ArrayList var1 = new ArrayList(field_192017_bK.keySet());
         return func_191999_g((Integer)var1.get(var0.nextInt(var1.size())));
      } else {
         return SoundEvents.field_192792_ep;
      }
   }

   public static SoundEvent func_191999_g(int var0) {
      return field_192017_bK.containsKey(var0) ? (SoundEvent)field_192017_bK.get(var0) : SoundEvents.field_192792_ep;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_192794_er;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_192793_eq;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(SoundEvents.field_192795_es, 0.15F, 1.0F);
   }

   protected float func_191954_d(float var1) {
      this.playSound(SoundEvents.field_192796_et, 0.15F, 1.0F);
      return var1 + this.field_192009_bC / 2.0F;
   }

   protected boolean func_191957_ae() {
      return true;
   }

   protected float getSoundPitch() {
      return func_192000_b(this.rand);
   }

   private static float func_192000_b(Random var0) {
      return (var0.nextFloat() - var0.nextFloat()) * 0.2F + 1.0F;
   }

   public SoundCategory getSoundCategory() {
      return SoundCategory.NEUTRAL;
   }

   public boolean canBePushed() {
      return true;
   }

   protected void collideWithEntity(Entity var1) {
      if (!(var1 instanceof EntityPlayer)) {
         super.collideWithEntity(var1);
      }

   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (this.isEntityInvulnerable(var1)) {
         return false;
      } else {
         if (this.aiSit != null) {
            this.aiSit.setSitting(false);
         }

         return super.attackEntityFrom(var1, var2);
      }
   }

   public int func_191998_ds() {
      return MathHelper.clamp((Integer)this.dataManager.get(field_192013_bG), 0, 4);
   }

   public void func_191997_m(int var1) {
      this.dataManager.set(field_192013_bG, var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_192013_bG, 0);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("Variant", this.func_191998_ds());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.func_191997_m(var1.getInteger("Variant"));
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_192561_ax;
   }

   public boolean func_192002_a() {
      return !this.onGround;
   }

   static Int2ObjectMap access$000() {
      return field_192017_bK;
   }

   static {
      field_192013_bG = EntityDataManager.<Integer>createKey(EntityParrot.class, DataSerializers.VARINT);
      field_192014_bH = new Predicate<EntityLiving>() {
         public boolean apply(@Nullable EntityLiving var1) {
            return var1 != null && EntityParrot.access$000().containsKey(EntityList.field_191308_b.getIDForObject(var1.getClass()));
         }
      };
      field_192015_bI = Items.COOKIE;
      field_192016_bJ = Sets.newHashSet(new Item[]{Items.WHEAT_SEEDS, Items.MELON_SEEDS, Items.PUMPKIN_SEEDS, Items.BEETROOT_SEEDS});
      field_192017_bK = new Int2ObjectOpenHashMap(32);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityBlaze.class), SoundEvents.field_193791_eM);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityCaveSpider.class), SoundEvents.field_193813_fc);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityCreeper.class), SoundEvents.field_193792_eN);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityElderGuardian.class), SoundEvents.field_193793_eO);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityDragon.class), SoundEvents.field_193794_eP);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityEnderman.class), SoundEvents.field_193795_eQ);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityEndermite.class), SoundEvents.field_193796_eR);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityEvoker.class), SoundEvents.field_193797_eS);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityGhast.class), SoundEvents.field_193798_eT);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityHusk.class), SoundEvents.field_193799_eU);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityIllusionIllager.class), SoundEvents.field_193800_eV);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityMagmaCube.class), SoundEvents.field_193801_eW);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityPigZombie.class), SoundEvents.field_193822_fl);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityPolarBear.class), SoundEvents.field_193802_eX);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityShulker.class), SoundEvents.field_193803_eY);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntitySilverfish.class), SoundEvents.field_193804_eZ);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntitySkeleton.class), SoundEvents.field_193811_fa);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntitySlime.class), SoundEvents.field_193812_fb);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntitySpider.class), SoundEvents.field_193813_fc);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityStray.class), SoundEvents.field_193814_fd);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityVex.class), SoundEvents.field_193815_fe);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityVindicator.class), SoundEvents.field_193816_ff);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityWitch.class), SoundEvents.field_193817_fg);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityWither.class), SoundEvents.field_193818_fh);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityWitherSkeleton.class), SoundEvents.field_193819_fi);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityWolf.class), SoundEvents.field_193820_fj);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityZombie.class), SoundEvents.field_193821_fk);
      field_192017_bK.put(EntityList.field_191308_b.getIDForObject(EntityZombieVillager.class), SoundEvents.field_193823_fm);
   }
}
