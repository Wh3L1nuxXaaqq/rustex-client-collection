package net.minecraft.entity.passive;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.SoundType;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityHorse extends AbstractHorse {
   private static final UUID ARMOR_MODIFIER_UUID = UUID.fromString("556E1665-8B10-40C8-8F9D-CF9B1667F295");
   private static final DataParameter<Integer> HORSE_VARIANT;
   private static final DataParameter<Integer> HORSE_ARMOR;
   private static final String[] HORSE_TEXTURES;
   private static final String[] HORSE_TEXTURES_ABBR;
   private static final String[] HORSE_MARKING_TEXTURES;
   private static final String[] HORSE_MARKING_TEXTURES_ABBR;
   private String texturePrefix;
   private final String[] horseTexturesArray = new String[3];

   public EntityHorse(World var1) {
      super(var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(HORSE_VARIANT, 0);
      this.dataManager.register(HORSE_ARMOR, HorseArmorType.NONE.getOrdinal());
   }

   public static void registerFixesHorse(DataFixer var0) {
      AbstractHorse.func_190683_c(var0, EntityHorse.class);
      var0.registerWalker(FixTypes.ENTITY, new ItemStackData(EntityHorse.class, new String[]{"ArmorItem"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("Variant", this.getHorseVariant());
      if (!this.horseChest.getStackInSlot(1).func_190926_b()) {
         var1.setTag("ArmorItem", this.horseChest.getStackInSlot(1).writeToNBT(new NBTTagCompound()));
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setHorseVariant(var1.getInteger("Variant"));
      if (var1.hasKey("ArmorItem", 10)) {
         ItemStack var2 = new ItemStack(var1.getCompoundTag("ArmorItem"));
         if (!var2.func_190926_b() && HorseArmorType.isHorseArmor(var2.getItem())) {
            this.horseChest.setInventorySlotContents(1, var2);
         }
      }

      this.updateHorseSlots();
   }

   public void setHorseVariant(int var1) {
      this.dataManager.set(HORSE_VARIANT, var1);
      this.resetTexturePrefix();
   }

   public int getHorseVariant() {
      return (Integer)this.dataManager.get(HORSE_VARIANT);
   }

   private void resetTexturePrefix() {
      this.texturePrefix = null;
   }

   private void setHorseTexturePaths() {
      int var1 = this.getHorseVariant();
      int var2 = (var1 & 255) % 7;
      int var3 = ((var1 & '\uff00') >> 8) % 5;
      HorseArmorType var4 = this.getHorseArmorType();
      this.horseTexturesArray[0] = HORSE_TEXTURES[var2];
      this.horseTexturesArray[1] = HORSE_MARKING_TEXTURES[var3];
      this.horseTexturesArray[2] = var4.getTextureName();
      this.texturePrefix = "horse/" + HORSE_TEXTURES_ABBR[var2] + HORSE_MARKING_TEXTURES_ABBR[var3] + var4.getHash();
   }

   public String getHorseTexture() {
      if (this.texturePrefix == null) {
         this.setHorseTexturePaths();
      }

      return this.texturePrefix;
   }

   public String[] getVariantTexturePaths() {
      if (this.texturePrefix == null) {
         this.setHorseTexturePaths();
      }

      return this.horseTexturesArray;
   }

   protected void updateHorseSlots() {
      super.updateHorseSlots();
      this.setHorseArmorStack(this.horseChest.getStackInSlot(1));
   }

   public void setHorseArmorStack(ItemStack var1) {
      HorseArmorType var2 = HorseArmorType.getByItemStack(var1);
      this.dataManager.set(HORSE_ARMOR, var2.getOrdinal());
      this.resetTexturePrefix();
      if (!this.world.isRemote) {
         this.getEntityAttribute(SharedMonsterAttributes.ARMOR).removeModifier(ARMOR_MODIFIER_UUID);
         int var3 = var2.getProtection();
         if (var3 != 0) {
            this.getEntityAttribute(SharedMonsterAttributes.ARMOR).applyModifier((new AttributeModifier(ARMOR_MODIFIER_UUID, "Horse armor bonus", (double)var3, 0)).setSaved(false));
         }
      }

   }

   public HorseArmorType getHorseArmorType() {
      return HorseArmorType.getByOrdinal((Integer)this.dataManager.get(HORSE_ARMOR));
   }

   public void onInventoryChanged(IInventory var1) {
      HorseArmorType var2 = this.getHorseArmorType();
      super.onInventoryChanged(var1);
      HorseArmorType var3 = this.getHorseArmorType();
      if (this.ticksExisted > 20 && var2 != var3 && var3 != HorseArmorType.NONE) {
         this.playSound(SoundEvents.ENTITY_HORSE_ARMOR, 0.5F, 1.0F);
      }

   }

   protected void func_190680_a(SoundType var1) {
      super.func_190680_a(var1);
      if (this.rand.nextInt(10) == 0) {
         this.playSound(SoundEvents.ENTITY_HORSE_BREATHE, var1.getVolume() * 0.6F, var1.getPitch());
      }

   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)this.getModifiedMaxHealth());
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(this.getModifiedMovementSpeed());
      this.getEntityAttribute(JUMP_STRENGTH).setBaseValue(this.getModifiedJumpStrength());
   }

   public void onUpdate() {
      super.onUpdate();
      if (this.world.isRemote && this.dataManager.isDirty()) {
         this.dataManager.setClean();
         this.resetTexturePrefix();
      }

   }

   protected SoundEvent getAmbientSound() {
      super.getAmbientSound();
      return SoundEvents.ENTITY_HORSE_AMBIENT;
   }

   protected SoundEvent getDeathSound() {
      super.getDeathSound();
      return SoundEvents.ENTITY_HORSE_DEATH;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      super.getHurtSound(var1);
      return SoundEvents.ENTITY_HORSE_HURT;
   }

   protected SoundEvent getAngrySound() {
      super.getAngrySound();
      return SoundEvents.ENTITY_HORSE_ANGRY;
   }

   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_HORSE;
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      boolean var4 = !var3.func_190926_b();
      if (var4 && var3.getItem() == Items.SPAWN_EGG) {
         return super.processInteract(var1, var2);
      } else {
         if (!this.isChild()) {
            if (this.isTame() && var1.isSneaking()) {
               this.openGUI(var1);
               return true;
            }

            if (this.isBeingRidden()) {
               return super.processInteract(var1, var2);
            }
         }

         if (var4) {
            if (this.func_190678_b(var1, var3)) {
               if (!var1.capabilities.isCreativeMode) {
                  var3.func_190918_g(1);
               }

               return true;
            }

            if (var3.interactWithEntity(var1, this, var2)) {
               return true;
            }

            if (!this.isTame()) {
               this.func_190687_dF();
               return true;
            }

            boolean var5 = HorseArmorType.getByItemStack(var3) != HorseArmorType.NONE;
            boolean var6 = !this.isChild() && !this.isHorseSaddled() && var3.getItem() == Items.SADDLE;
            if (var5 || var6) {
               this.openGUI(var1);
               return true;
            }
         }

         if (this.isChild()) {
            return super.processInteract(var1, var2);
         } else {
            this.mountTo(var1);
            return true;
         }
      }
   }

   public boolean canMateWith(EntityAnimal var1) {
      if (var1 == this) {
         return false;
      } else if (!(var1 instanceof EntityDonkey) && !(var1 instanceof EntityHorse)) {
         return false;
      } else {
         return this.canMate() && ((AbstractHorse)var1).canMate();
      }
   }

   public EntityAgeable createChild(EntityAgeable var1) {
      Object var2;
      if (var1 instanceof EntityDonkey) {
         var2 = new EntityMule(this.world);
      } else {
         EntityHorse var3 = (EntityHorse)var1;
         var2 = new EntityHorse(this.world);
         int var4 = this.rand.nextInt(9);
         int var5;
         if (var4 < 4) {
            var5 = this.getHorseVariant() & 255;
         } else if (var4 < 8) {
            var5 = var3.getHorseVariant() & 255;
         } else {
            var5 = this.rand.nextInt(7);
         }

         int var6 = this.rand.nextInt(5);
         if (var6 < 2) {
            var5 |= this.getHorseVariant() & '\uff00';
         } else if (var6 < 4) {
            var5 |= var3.getHorseVariant() & '\uff00';
         } else {
            var5 |= this.rand.nextInt(5) << 8 & '\uff00';
         }

         ((EntityHorse)var2).setHorseVariant(var5);
      }

      this.func_190681_a(var1, (AbstractHorse)var2);
      return (EntityAgeable)var2;
   }

   public boolean func_190677_dK() {
      return true;
   }

   public boolean func_190682_f(ItemStack var1) {
      return HorseArmorType.isHorseArmor(var1.getItem());
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      int var3;
      if (var2 instanceof GroupData) {
         var3 = ((GroupData)var2).field_190885_a;
      } else {
         var3 = this.rand.nextInt(7);
         var2 = new GroupData(var3);
      }

      this.setHorseVariant(var3 | this.rand.nextInt(5) << 8);
      return var2;
   }

   static {
      HORSE_VARIANT = EntityDataManager.<Integer>createKey(EntityHorse.class, DataSerializers.VARINT);
      HORSE_ARMOR = EntityDataManager.<Integer>createKey(EntityHorse.class, DataSerializers.VARINT);
      HORSE_TEXTURES = new String[]{"textures/entity/horse/horse_white.png", "textures/entity/horse/horse_creamy.png", "textures/entity/horse/horse_chestnut.png", "textures/entity/horse/horse_brown.png", "textures/entity/horse/horse_black.png", "textures/entity/horse/horse_gray.png", "textures/entity/horse/horse_darkbrown.png"};
      HORSE_TEXTURES_ABBR = new String[]{"hwh", "hcr", "hch", "hbr", "hbl", "hgr", "hdb"};
      HORSE_MARKING_TEXTURES = new String[]{null, "textures/entity/horse/horse_markings_white.png", "textures/entity/horse/horse_markings_whitefield.png", "textures/entity/horse/horse_markings_whitedots.png", "textures/entity/horse/horse_markings_blackdots.png"};
      HORSE_MARKING_TEXTURES_ABBR = new String[]{"", "wo_", "wmo", "wdo", "bdo"};
   }

   public static class GroupData implements IEntityLivingData {
      public int field_190885_a;

      public GroupData(int var1) {
         this.field_190885_a = var1;
      }
   }
}
