package net.minecraft.entity.passive;

import com.google.common.collect.Sets;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityPig extends EntityAnimal {
   private static final DataParameter<Boolean> SADDLED;
   private static final DataParameter<Integer> field_191520_bx;
   private static final Set<Item> TEMPTATION_ITEMS;
   private boolean boosting;
   private int boostTime;
   private int totalBoostTime;

   public EntityPig(World var1) {
      super(var1);
      this.setSize(0.9F, 0.9F);
   }

   protected void initEntityAI() {
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIPanic(this, (double)1.25F));
      this.tasks.addTask(3, new EntityAIMate(this, (double)1.0F));
      this.tasks.addTask(4, new EntityAITempt(this, 1.2, Items.CARROT_ON_A_STICK, false));
      this.tasks.addTask(4, new EntityAITempt(this, 1.2, false, TEMPTATION_ITEMS));
      this.tasks.addTask(5, new EntityAIFollowParent(this, 1.1));
      this.tasks.addTask(6, new EntityAIWanderAvoidWater(this, (double)1.0F));
      this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      this.tasks.addTask(8, new EntityAILookIdle(this));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)10.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.25F);
   }

   @Nullable
   public Entity getControllingPassenger() {
      return this.getPassengers().isEmpty() ? null : (Entity)this.getPassengers().get(0);
   }

   public boolean canBeSteered() {
      Entity var1 = this.getControllingPassenger();
      if (!(var1 instanceof EntityPlayer)) {
         return false;
      } else {
         EntityPlayer var2 = (EntityPlayer)var1;
         return var2.getHeldItemMainhand().getItem() == Items.CARROT_ON_A_STICK || var2.getHeldItemOffhand().getItem() == Items.CARROT_ON_A_STICK;
      }
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      if (field_191520_bx.equals(var1) && this.world.isRemote) {
         this.boosting = true;
         this.boostTime = 0;
         this.totalBoostTime = (Integer)this.dataManager.get(field_191520_bx);
      }

      super.notifyDataManagerChange(var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(SADDLED, false);
      this.dataManager.register(field_191520_bx, 0);
   }

   public static void registerFixesPig(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityPig.class);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("Saddle", this.getSaddled());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setSaddled(var1.getBoolean("Saddle"));
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_PIG_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_PIG_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_PIG_DEATH;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(SoundEvents.ENTITY_PIG_STEP, 0.15F, 1.0F);
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      if (!super.processInteract(var1, var2)) {
         ItemStack var3 = var1.getHeldItem(var2);
         if (var3.getItem() == Items.NAME_TAG) {
            var3.interactWithEntity(var1, this, var2);
            return true;
         } else if (this.getSaddled() && !this.isBeingRidden()) {
            if (!this.world.isRemote) {
               var1.startRiding(this);
            }

            return true;
         } else if (var3.getItem() == Items.SADDLE) {
            var3.interactWithEntity(var1, this, var2);
            return true;
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (!this.world.isRemote && this.getSaddled()) {
         this.dropItem(Items.SADDLE, 1);
      }

   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_PIG;
   }

   public boolean getSaddled() {
      return (Boolean)this.dataManager.get(SADDLED);
   }

   public void setSaddled(boolean var1) {
      if (var1) {
         this.dataManager.set(SADDLED, true);
      } else {
         this.dataManager.set(SADDLED, false);
      }

   }

   public void onStruckByLightning(EntityLightningBolt var1) {
      if (!this.world.isRemote && !this.isDead) {
         EntityPigZombie var2 = new EntityPigZombie(this.world);
         var2.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
         var2.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
         var2.setNoAI(this.isAIDisabled());
         if (this.hasCustomName()) {
            var2.setCustomNameTag(this.getCustomNameTag());
            var2.setAlwaysRenderNameTag(this.getAlwaysRenderNameTag());
         }

         this.world.spawnEntityInWorld(var2);
         this.setDead();
      }

   }

   public void func_191986_a(float var1, float var2, float var3) {
      Entity var4 = this.getPassengers().isEmpty() ? null : (Entity)this.getPassengers().get(0);
      if (this.isBeingRidden() && this.canBeSteered()) {
         this.rotationYaw = var4.rotationYaw;
         this.prevRotationYaw = this.rotationYaw;
         this.rotationPitch = var4.rotationPitch * 0.5F;
         this.setRotation(this.rotationYaw, this.rotationPitch);
         this.renderYawOffset = this.rotationYaw;
         this.rotationYawHead = this.rotationYaw;
         this.stepHeight = 1.0F;
         this.jumpMovementFactor = this.getAIMoveSpeed() * 0.1F;
         if (this.boosting && this.boostTime++ > this.totalBoostTime) {
            this.boosting = false;
         }

         if (this.canPassengerSteer()) {
            float var5 = (float)this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue() * 0.225F;
            if (this.boosting) {
               var5 += var5 * 1.15F * MathHelper.sin((float)this.boostTime / (float)this.totalBoostTime * (float)Math.PI);
            }

            this.setAIMoveSpeed(var5);
            super.func_191986_a(0.0F, 0.0F, 1.0F);
         } else {
            this.motionX = (double)0.0F;
            this.motionY = (double)0.0F;
            this.motionZ = (double)0.0F;
         }

         this.prevLimbSwingAmount = this.limbSwingAmount;
         double var10 = this.posX - this.prevPosX;
         double var7 = this.posZ - this.prevPosZ;
         float var9 = MathHelper.sqrt(var10 * var10 + var7 * var7) * 4.0F;
         if (var9 > 1.0F) {
            var9 = 1.0F;
         }

         this.limbSwingAmount += (var9 - this.limbSwingAmount) * 0.4F;
         this.limbSwing += this.limbSwingAmount;
      } else {
         this.stepHeight = 0.5F;
         this.jumpMovementFactor = 0.02F;
         super.func_191986_a(var1, var2, var3);
      }

   }

   public boolean boost() {
      if (this.boosting) {
         return false;
      } else {
         this.boosting = true;
         this.boostTime = 0;
         this.totalBoostTime = this.getRNG().nextInt(841) + 140;
         this.getDataManager().set(field_191520_bx, this.totalBoostTime);
         return true;
      }
   }

   public EntityPig createChild(EntityAgeable var1) {
      return new EntityPig(this.world);
   }

   public boolean isBreedingItem(ItemStack var1) {
      return TEMPTATION_ITEMS.contains(var1.getItem());
   }

   static {
      SADDLED = EntityDataManager.<Boolean>createKey(EntityPig.class, DataSerializers.BOOLEAN);
      field_191520_bx = EntityDataManager.<Integer>createKey(EntityPig.class, DataSerializers.VARINT);
      TEMPTATION_ITEMS = Sets.newHashSet(new Item[]{Items.CARROT, Items.POTATO, Items.BEETROOT});
   }
}
