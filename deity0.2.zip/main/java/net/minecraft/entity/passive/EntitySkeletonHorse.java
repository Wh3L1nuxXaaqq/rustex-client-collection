package net.minecraft.entity.passive;

import javax.annotation.Nullable;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAISkeletonRiders;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntitySkeletonHorse extends AbstractHorse {
   private final EntityAISkeletonRiders skeletonTrapAI = new EntityAISkeletonRiders(this);
   private boolean skeletonTrap;
   private int skeletonTrapTime;

   public EntitySkeletonHorse(World var1) {
      super(var1);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)15.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.2F);
      this.getEntityAttribute(JUMP_STRENGTH).setBaseValue(this.getModifiedJumpStrength());
   }

   protected SoundEvent getAmbientSound() {
      super.getAmbientSound();
      return SoundEvents.ENTITY_SKELETON_HORSE_AMBIENT;
   }

   protected SoundEvent getDeathSound() {
      super.getDeathSound();
      return SoundEvents.ENTITY_SKELETON_HORSE_DEATH;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      super.getHurtSound(var1);
      return SoundEvents.ENTITY_SKELETON_HORSE_HURT;
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.UNDEAD;
   }

   public double getMountedYOffset() {
      return super.getMountedYOffset() - (double)0.1875F;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_SKELETON_HORSE;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if (this.func_190690_dh() && this.skeletonTrapTime++ >= 18000) {
         this.setDead();
      }

   }

   public static void func_190692_b(DataFixer var0) {
      AbstractHorse.func_190683_c(var0, EntitySkeletonHorse.class);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("SkeletonTrap", this.func_190690_dh());
      var1.setInteger("SkeletonTrapTime", this.skeletonTrapTime);
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.func_190691_p(var1.getBoolean("SkeletonTrap"));
      this.skeletonTrapTime = var1.getInteger("SkeletonTrapTime");
   }

   public boolean func_190690_dh() {
      return this.skeletonTrap;
   }

   public void func_190691_p(boolean var1) {
      if (var1 != this.skeletonTrap) {
         this.skeletonTrap = var1;
         if (var1) {
            this.tasks.addTask(1, this.skeletonTrapAI);
         } else {
            this.tasks.removeTask(this.skeletonTrapAI);
         }
      }

   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      boolean var4 = !var3.func_190926_b();
      if (var4 && var3.getItem() == Items.SPAWN_EGG) {
         return super.processInteract(var1, var2);
      } else if (!this.isTame()) {
         return false;
      } else if (this.isChild()) {
         return super.processInteract(var1, var2);
      } else if (var1.isSneaking()) {
         this.openGUI(var1);
         return true;
      } else if (this.isBeingRidden()) {
         return super.processInteract(var1, var2);
      } else {
         if (var4) {
            if (var3.getItem() == Items.SADDLE && !this.isHorseSaddled()) {
               this.openGUI(var1);
               return true;
            }

            if (var3.interactWithEntity(var1, this, var2)) {
               return true;
            }
         }

         this.mountTo(var1);
         return true;
      }
   }
}
