package net.minecraft.entity.passive;

import java.util.Locale;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentData;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.INpc;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIFollowGolem;
import net.minecraft.entity.ai.EntityAIHarvestFarmland;
import net.minecraft.entity.ai.EntityAILookAtTradePlayer;
import net.minecraft.entity.ai.EntityAIMoveIndoors;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAIPlay;
import net.minecraft.entity.ai.EntityAIRestrictOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITradePlayer;
import net.minecraft.entity.ai.EntityAIVillagerInteract;
import net.minecraft.entity.ai.EntityAIVillagerMate;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityAIWatchClosest2;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.monster.EntityVex;
import net.minecraft.entity.monster.EntityVindicator;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.potion.PotionEffect;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.Tuple;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.DataFixesManager;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.village.Village;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapData;
import net.minecraft.world.storage.MapDecoration;
import net.minecraft.world.storage.loot.LootTableList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityVillager extends EntityAgeable implements INpc, IMerchant {
   private static final Logger field_190674_bx = LogManager.getLogger();
   private static final DataParameter<Integer> PROFESSION;
   private int randomTickDivider;
   private boolean isMating;
   private boolean isPlaying;
   Village villageObj;
   @Nullable
   private EntityPlayer buyingPlayer;
   @Nullable
   private MerchantRecipeList buyingList;
   private int timeUntilReset;
   private boolean needsInitilization;
   private boolean isWillingToMate;
   private int wealth;
   private String lastBuyingPlayer;
   private int careerId;
   private int careerLevel;
   private boolean isLookingForHome;
   private boolean areAdditionalTasksSet;
   private final InventoryBasic villagerInventory;
   private static final ITradeList[][][][] DEFAULT_TRADE_LIST_MAP;

   public EntityVillager(World var1) {
      this(var1, 0);
   }

   public EntityVillager(World var1, int var2) {
      super(var1);
      this.villagerInventory = new InventoryBasic("Items", false, 8);
      this.setProfession(var2);
      this.setSize(0.6F, 1.95F);
      ((PathNavigateGround)this.getNavigator()).setBreakDoors(true);
      this.setCanPickUpLoot(true);
   }

   protected void initEntityAI() {
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityZombie.class, 8.0F, 0.6, 0.6));
      this.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityEvoker.class, 12.0F, 0.8, 0.8));
      this.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityVindicator.class, 8.0F, 0.8, 0.8));
      this.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityVex.class, 8.0F, 0.6, 0.6));
      this.tasks.addTask(1, new EntityAITradePlayer(this));
      this.tasks.addTask(1, new EntityAILookAtTradePlayer(this));
      this.tasks.addTask(2, new EntityAIMoveIndoors(this));
      this.tasks.addTask(3, new EntityAIRestrictOpenDoor(this));
      this.tasks.addTask(4, new EntityAIOpenDoor(this, true));
      this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, 0.6));
      this.tasks.addTask(6, new EntityAIVillagerMate(this));
      this.tasks.addTask(7, new EntityAIFollowGolem(this));
      this.tasks.addTask(9, new EntityAIWatchClosest2(this, EntityPlayer.class, 3.0F, 1.0F));
      this.tasks.addTask(9, new EntityAIVillagerInteract(this));
      this.tasks.addTask(9, new EntityAIWanderAvoidWater(this, 0.6));
      this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
   }

   private void setAdditionalAItasks() {
      if (!this.areAdditionalTasksSet) {
         this.areAdditionalTasksSet = true;
         if (this.isChild()) {
            this.tasks.addTask(8, new EntityAIPlay(this, 0.32));
         } else if (this.getProfession() == 0) {
            this.tasks.addTask(6, new EntityAIHarvestFarmland(this, 0.6));
         }
      }

   }

   protected void onGrowingAdult() {
      if (this.getProfession() == 0) {
         this.tasks.addTask(8, new EntityAIHarvestFarmland(this, 0.6));
      }

      super.onGrowingAdult();
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.5F);
   }

   protected void updateAITasks() {
      if (--this.randomTickDivider <= 0) {
         BlockPos var1 = new BlockPos(this);
         this.world.getVillageCollection().addToVillagerPositionList(var1);
         this.randomTickDivider = 70 + this.rand.nextInt(50);
         this.villageObj = this.world.getVillageCollection().getNearestVillage(var1, 32);
         if (this.villageObj == null) {
            this.detachHome();
         } else {
            BlockPos var2 = this.villageObj.getCenter();
            this.setHomePosAndDistance(var2, this.villageObj.getVillageRadius());
            if (this.isLookingForHome) {
               this.isLookingForHome = false;
               this.villageObj.setDefaultPlayerReputation(5);
            }
         }
      }

      if (!this.isTrading() && this.timeUntilReset > 0) {
         --this.timeUntilReset;
         if (this.timeUntilReset <= 0) {
            if (this.needsInitilization) {
               for(MerchantRecipe var4 : this.buyingList) {
                  if (var4.isRecipeDisabled()) {
                     var4.increaseMaxTradeUses(this.rand.nextInt(6) + this.rand.nextInt(6) + 2);
                  }
               }

               this.populateBuyingList();
               this.needsInitilization = false;
               if (this.villageObj != null && this.lastBuyingPlayer != null) {
                  this.world.setEntityState(this, (byte)14);
                  this.villageObj.modifyPlayerReputation(this.lastBuyingPlayer, 1);
               }
            }

            this.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 0));
         }
      }

      super.updateAITasks();
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      boolean var4 = var3.getItem() == Items.NAME_TAG;
      if (var4) {
         var3.interactWithEntity(var1, this, var2);
         return true;
      } else if (!this.func_190669_a(var3, this.getClass()) && this.isEntityAlive() && !this.isTrading() && !this.isChild()) {
         if (this.buyingList == null) {
            this.populateBuyingList();
         }

         if (var2 == EnumHand.MAIN_HAND) {
            var1.addStat(StatList.TALKED_TO_VILLAGER);
         }

         if (!this.world.isRemote && !this.buyingList.isEmpty()) {
            this.setCustomer(var1);
            var1.displayVillagerTradeGui(this);
         } else if (this.buyingList.isEmpty()) {
            return super.processInteract(var1, var2);
         }

         return true;
      } else {
         return super.processInteract(var1, var2);
      }
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(PROFESSION, 0);
   }

   public static void registerFixesVillager(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityVillager.class);
      var0.registerWalker(FixTypes.ENTITY, new ItemStackDataLists(EntityVillager.class, new String[]{"Inventory"}));
      var0.registerWalker(FixTypes.ENTITY, new IDataWalker() {
         public NBTTagCompound process(IDataFixer var1, NBTTagCompound var2, int var3) {
            if (EntityList.func_191306_a(EntityVillager.class).equals(new ResourceLocation(var2.getString("id"))) && var2.hasKey("Offers", 10)) {
               NBTTagCompound var4 = var2.getCompoundTag("Offers");
               if (var4.hasKey("Recipes", 9)) {
                  NBTTagList var5 = var4.getTagList("Recipes", 10);

                  for(int var6 = 0; var6 < var5.tagCount(); ++var6) {
                     NBTTagCompound var7 = var5.getCompoundTagAt(var6);
                     DataFixesManager.processItemStack(var1, var7, var3, "buy");
                     DataFixesManager.processItemStack(var1, var7, var3, "buyB");
                     DataFixesManager.processItemStack(var1, var7, var3, "sell");
                     var5.set(var6, var7);
                  }
               }
            }

            return var2;
         }
      });
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("Profession", this.getProfession());
      var1.setInteger("Riches", this.wealth);
      var1.setInteger("Career", this.careerId);
      var1.setInteger("CareerLevel", this.careerLevel);
      var1.setBoolean("Willing", this.isWillingToMate);
      if (this.buyingList != null) {
         var1.setTag("Offers", this.buyingList.getRecipiesAsTags());
      }

      NBTTagList var2 = new NBTTagList();

      for(int var3 = 0; var3 < this.villagerInventory.getSizeInventory(); ++var3) {
         ItemStack var4 = this.villagerInventory.getStackInSlot(var3);
         if (!var4.func_190926_b()) {
            var2.appendTag(var4.writeToNBT(new NBTTagCompound()));
         }
      }

      var1.setTag("Inventory", var2);
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setProfession(var1.getInteger("Profession"));
      this.wealth = var1.getInteger("Riches");
      this.careerId = var1.getInteger("Career");
      this.careerLevel = var1.getInteger("CareerLevel");
      this.isWillingToMate = var1.getBoolean("Willing");
      if (var1.hasKey("Offers", 10)) {
         NBTTagCompound var2 = var1.getCompoundTag("Offers");
         this.buyingList = new MerchantRecipeList(var2);
      }

      NBTTagList var5 = var1.getTagList("Inventory", 10);

      for(int var3 = 0; var3 < var5.tagCount(); ++var3) {
         ItemStack var4 = new ItemStack(var5.getCompoundTagAt(var3));
         if (!var4.func_190926_b()) {
            this.villagerInventory.addItem(var4);
         }
      }

      this.setCanPickUpLoot(true);
      this.setAdditionalAItasks();
   }

   protected boolean canDespawn() {
      return false;
   }

   protected SoundEvent getAmbientSound() {
      return this.isTrading() ? SoundEvents.ENTITY_VILLAGER_TRADING : SoundEvents.ENTITY_VILLAGER_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_VILLAGER_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_VILLAGER_DEATH;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191184_at;
   }

   public void setProfession(int var1) {
      this.dataManager.set(PROFESSION, var1);
   }

   public int getProfession() {
      return Math.max((Integer)this.dataManager.get(PROFESSION) % 6, 0);
   }

   public boolean isMating() {
      return this.isMating;
   }

   public void setMating(boolean var1) {
      this.isMating = var1;
   }

   public void setPlaying(boolean var1) {
      this.isPlaying = var1;
   }

   public boolean isPlaying() {
      return this.isPlaying;
   }

   public void setRevengeTarget(@Nullable EntityLivingBase var1) {
      super.setRevengeTarget(var1);
      if (this.villageObj != null && var1 != null) {
         this.villageObj.addOrRenewAgressor(var1);
         if (var1 instanceof EntityPlayer) {
            byte var2 = -1;
            if (this.isChild()) {
               var2 = -3;
            }

            this.villageObj.modifyPlayerReputation(var1.getName(), var2);
            if (this.isEntityAlive()) {
               this.world.setEntityState(this, (byte)13);
            }
         }
      }

   }

   public void onDeath(DamageSource var1) {
      if (this.villageObj != null) {
         Entity var2 = var1.getEntity();
         if (var2 != null) {
            if (var2 instanceof EntityPlayer) {
               this.villageObj.modifyPlayerReputation(var2.getName(), -2);
            } else if (var2 instanceof IMob) {
               this.villageObj.endMatingSeason();
            }
         } else {
            EntityPlayer var3 = this.world.getClosestPlayerToEntity(this, (double)16.0F);
            if (var3 != null) {
               this.villageObj.endMatingSeason();
            }
         }
      }

      super.onDeath(var1);
   }

   public void setCustomer(@Nullable EntityPlayer var1) {
      this.buyingPlayer = var1;
   }

   @Nullable
   public EntityPlayer getCustomer() {
      return this.buyingPlayer;
   }

   public boolean isTrading() {
      return this.buyingPlayer != null;
   }

   public boolean getIsWillingToMate(boolean var1) {
      if (!this.isWillingToMate && var1 && this.hasEnoughFoodToBreed()) {
         boolean var2 = false;

         for(int var3 = 0; var3 < this.villagerInventory.getSizeInventory(); ++var3) {
            ItemStack var4 = this.villagerInventory.getStackInSlot(var3);
            if (!var4.func_190926_b()) {
               if (var4.getItem() == Items.BREAD && var4.func_190916_E() >= 3) {
                  var2 = true;
                  this.villagerInventory.decrStackSize(var3, 3);
               } else if ((var4.getItem() == Items.POTATO || var4.getItem() == Items.CARROT) && var4.func_190916_E() >= 12) {
                  var2 = true;
                  this.villagerInventory.decrStackSize(var3, 12);
               }
            }

            if (var2) {
               this.world.setEntityState(this, (byte)18);
               this.isWillingToMate = true;
               break;
            }
         }
      }

      return this.isWillingToMate;
   }

   public void setIsWillingToMate(boolean var1) {
      this.isWillingToMate = var1;
   }

   public void useRecipe(MerchantRecipe var1) {
      var1.incrementToolUses();
      this.livingSoundTime = -this.getTalkInterval();
      this.playSound(SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
      int var2 = 3 + this.rand.nextInt(4);
      if (var1.getToolUses() == 1 || this.rand.nextInt(5) == 0) {
         this.timeUntilReset = 40;
         this.needsInitilization = true;
         this.isWillingToMate = true;
         if (this.buyingPlayer != null) {
            this.lastBuyingPlayer = this.buyingPlayer.getName();
         } else {
            this.lastBuyingPlayer = null;
         }

         var2 += 5;
      }

      if (var1.getItemToBuy().getItem() == Items.EMERALD) {
         this.wealth += var1.getItemToBuy().func_190916_E();
      }

      if (var1.getRewardsExp()) {
         this.world.spawnEntityInWorld(new EntityXPOrb(this.world, this.posX, this.posY + (double)0.5F, this.posZ, var2));
      }

      if (this.buyingPlayer instanceof EntityPlayerMP) {
         CriteriaTriggers.field_192138_r.func_192234_a((EntityPlayerMP)this.buyingPlayer, this, var1.getItemToSell());
      }

   }

   public void verifySellingItem(ItemStack var1) {
      if (!this.world.isRemote && this.livingSoundTime > -this.getTalkInterval() + 20) {
         this.livingSoundTime = -this.getTalkInterval();
         this.playSound(var1.func_190926_b() ? SoundEvents.ENTITY_VILLAGER_NO : SoundEvents.ENTITY_VILLAGER_YES, this.getSoundVolume(), this.getSoundPitch());
      }

   }

   @Nullable
   public MerchantRecipeList getRecipes(EntityPlayer var1) {
      if (this.buyingList == null) {
         this.populateBuyingList();
      }

      return this.buyingList;
   }

   private void populateBuyingList() {
      ITradeList[][][] var1 = DEFAULT_TRADE_LIST_MAP[this.getProfession()];
      if (this.careerId != 0 && this.careerLevel != 0) {
         ++this.careerLevel;
      } else {
         this.careerId = this.rand.nextInt(var1.length) + 1;
         this.careerLevel = 1;
      }

      if (this.buyingList == null) {
         this.buyingList = new MerchantRecipeList();
      }

      int var2 = this.careerId - 1;
      int var3 = this.careerLevel - 1;
      if (var2 >= 0 && var2 < var1.length) {
         ITradeList[][] var4 = var1[var2];
         if (var3 >= 0 && var3 < var4.length) {
            ITradeList[] var5 = var4[var3];

            for(ITradeList var9 : var5) {
               var9.func_190888_a(this, this.buyingList, this.rand);
            }
         }
      }

   }

   public void setRecipes(@Nullable MerchantRecipeList var1) {
   }

   public World func_190670_t_() {
      return this.world;
   }

   public BlockPos func_190671_u_() {
      return new BlockPos(this);
   }

   public ITextComponent getDisplayName() {
      Team var1 = this.getTeam();
      String var2 = this.getCustomNameTag();
      if (var2 != null && !var2.isEmpty()) {
         TextComponentString var5 = new TextComponentString(ScorePlayerTeam.formatPlayerName(var1, var2));
         var5.getStyle().setHoverEvent(this.getHoverEvent());
         var5.getStyle().setInsertion(this.getCachedUniqueIdString());
         return var5;
      } else {
         if (this.buyingList == null) {
            this.populateBuyingList();
         }

         String var3 = null;
         switch (this.getProfession()) {
            case 0:
               if (this.careerId == 1) {
                  var3 = "farmer";
               } else if (this.careerId == 2) {
                  var3 = "fisherman";
               } else if (this.careerId == 3) {
                  var3 = "shepherd";
               } else if (this.careerId == 4) {
                  var3 = "fletcher";
               }
               break;
            case 1:
               if (this.careerId == 1) {
                  var3 = "librarian";
               } else if (this.careerId == 2) {
                  var3 = "cartographer";
               }
               break;
            case 2:
               var3 = "cleric";
               break;
            case 3:
               if (this.careerId == 1) {
                  var3 = "armor";
               } else if (this.careerId == 2) {
                  var3 = "weapon";
               } else if (this.careerId == 3) {
                  var3 = "tool";
               }
               break;
            case 4:
               if (this.careerId == 1) {
                  var3 = "butcher";
               } else if (this.careerId == 2) {
                  var3 = "leather";
               }
               break;
            case 5:
               var3 = "nitwit";
         }

         if (var3 != null) {
            TextComponentTranslation var4 = new TextComponentTranslation("entity.Villager." + var3, new Object[0]);
            var4.getStyle().setHoverEvent(this.getHoverEvent());
            var4.getStyle().setInsertion(this.getCachedUniqueIdString());
            if (var1 != null) {
               var4.getStyle().setColor(var1.getChatFormat());
            }

            return var4;
         } else {
            return super.getDisplayName();
         }
      }
   }

   public float getEyeHeight() {
      return this.isChild() ? 0.81F : 1.62F;
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 12) {
         this.spawnParticles(EnumParticleTypes.HEART);
      } else if (var1 == 13) {
         this.spawnParticles(EnumParticleTypes.VILLAGER_ANGRY);
      } else if (var1 == 14) {
         this.spawnParticles(EnumParticleTypes.VILLAGER_HAPPY);
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   private void spawnParticles(EnumParticleTypes var1) {
      for(int var2 = 0; var2 < 5; ++var2) {
         double var3 = this.rand.nextGaussian() * 0.02;
         double var5 = this.rand.nextGaussian() * 0.02;
         double var7 = this.rand.nextGaussian() * 0.02;
         this.world.spawnParticle(var1, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)1.0F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, var3, var5, var7);
      }

   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      return this.func_190672_a(var1, var2, true);
   }

   public IEntityLivingData func_190672_a(DifficultyInstance var1, @Nullable IEntityLivingData var2, boolean var3) {
      var2 = super.onInitialSpawn(var1, var2);
      if (var3) {
         this.setProfession(this.world.rand.nextInt(6));
      }

      this.setAdditionalAItasks();
      this.populateBuyingList();
      return var2;
   }

   public void setLookingForHome() {
      this.isLookingForHome = true;
   }

   public EntityVillager createChild(EntityAgeable var1) {
      EntityVillager var2 = new EntityVillager(this.world);
      var2.onInitialSpawn(this.world.getDifficultyForLocation(new BlockPos(var2)), (IEntityLivingData)null);
      return var2;
   }

   public boolean canBeLeashedTo(EntityPlayer var1) {
      return false;
   }

   public void onStruckByLightning(EntityLightningBolt var1) {
      if (!this.world.isRemote && !this.isDead) {
         EntityWitch var2 = new EntityWitch(this.world);
         var2.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
         var2.onInitialSpawn(this.world.getDifficultyForLocation(new BlockPos(var2)), (IEntityLivingData)null);
         var2.setNoAI(this.isAIDisabled());
         if (this.hasCustomName()) {
            var2.setCustomNameTag(this.getCustomNameTag());
            var2.setAlwaysRenderNameTag(this.getAlwaysRenderNameTag());
         }

         this.world.spawnEntityInWorld(var2);
         this.setDead();
      }

   }

   public InventoryBasic getVillagerInventory() {
      return this.villagerInventory;
   }

   protected void updateEquipmentIfNeeded(EntityItem var1) {
      ItemStack var2 = var1.getEntityItem();
      Item var3 = var2.getItem();
      if (this.canVillagerPickupItem(var3)) {
         ItemStack var4 = this.villagerInventory.addItem(var2);
         if (var4.func_190926_b()) {
            var1.setDead();
         } else {
            var2.func_190920_e(var4.func_190916_E());
         }
      }

   }

   private boolean canVillagerPickupItem(Item var1) {
      return var1 == Items.BREAD || var1 == Items.POTATO || var1 == Items.CARROT || var1 == Items.WHEAT || var1 == Items.WHEAT_SEEDS || var1 == Items.BEETROOT || var1 == Items.BEETROOT_SEEDS;
   }

   public boolean hasEnoughFoodToBreed() {
      return this.hasEnoughItems(1);
   }

   public boolean canAbondonItems() {
      return this.hasEnoughItems(2);
   }

   public boolean wantsMoreFood() {
      boolean var1 = this.getProfession() == 0;
      if (var1) {
         return !this.hasEnoughItems(5);
      } else {
         return !this.hasEnoughItems(1);
      }
   }

   private boolean hasEnoughItems(int var1) {
      boolean var2 = this.getProfession() == 0;

      for(int var3 = 0; var3 < this.villagerInventory.getSizeInventory(); ++var3) {
         ItemStack var4 = this.villagerInventory.getStackInSlot(var3);
         if (!var4.func_190926_b()) {
            if (var4.getItem() == Items.BREAD && var4.func_190916_E() >= 3 * var1 || var4.getItem() == Items.POTATO && var4.func_190916_E() >= 12 * var1 || var4.getItem() == Items.CARROT && var4.func_190916_E() >= 12 * var1 || var4.getItem() == Items.BEETROOT && var4.func_190916_E() >= 12 * var1) {
               return true;
            }

            if (var2 && var4.getItem() == Items.WHEAT && var4.func_190916_E() >= 9 * var1) {
               return true;
            }
         }
      }

      return false;
   }

   public boolean isFarmItemInInventory() {
      for(int var1 = 0; var1 < this.villagerInventory.getSizeInventory(); ++var1) {
         ItemStack var2 = this.villagerInventory.getStackInSlot(var1);
         if (!var2.func_190926_b() && (var2.getItem() == Items.WHEAT_SEEDS || var2.getItem() == Items.POTATO || var2.getItem() == Items.CARROT || var2.getItem() == Items.BEETROOT_SEEDS)) {
            return true;
         }
      }

      return false;
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      if (super.replaceItemInInventory(var1, var2)) {
         return true;
      } else {
         int var3 = var1 - 300;
         if (var3 >= 0 && var3 < this.villagerInventory.getSizeInventory()) {
            this.villagerInventory.setInventorySlotContents(var3, var2);
            return true;
         } else {
            return false;
         }
      }
   }

   static Logger access$000() {
      return field_190674_bx;
   }

   static {
      PROFESSION = EntityDataManager.<Integer>createKey(EntityVillager.class, DataSerializers.VARINT);
      DEFAULT_TRADE_LIST_MAP = new ITradeList[][][][]{{{{new EmeraldForItems(Items.WHEAT, new PriceInfo(18, 22)), new EmeraldForItems(Items.POTATO, new PriceInfo(15, 19)), new EmeraldForItems(Items.CARROT, new PriceInfo(15, 19)), new ListItemForEmeralds(Items.BREAD, new PriceInfo(-4, -2))}, {new EmeraldForItems(Item.getItemFromBlock(Blocks.PUMPKIN), new PriceInfo(8, 13)), new ListItemForEmeralds(Items.PUMPKIN_PIE, new PriceInfo(-3, -2))}, {new EmeraldForItems(Item.getItemFromBlock(Blocks.MELON_BLOCK), new PriceInfo(7, 12)), new ListItemForEmeralds(Items.APPLE, new PriceInfo(-7, -5))}, {new ListItemForEmeralds(Items.COOKIE, new PriceInfo(-10, -6)), new ListItemForEmeralds(Items.CAKE, new PriceInfo(1, 1))}}, {{new EmeraldForItems(Items.STRING, new PriceInfo(15, 20)), new EmeraldForItems(Items.COAL, new PriceInfo(16, 24)), new ItemAndEmeraldToItem(Items.FISH, new PriceInfo(6, 6), Items.COOKED_FISH, new PriceInfo(6, 6))}, {new ListEnchantedItemForEmeralds(Items.FISHING_ROD, new PriceInfo(7, 8))}}, {{new EmeraldForItems(Item.getItemFromBlock(Blocks.WOOL), new PriceInfo(16, 22)), new ListItemForEmeralds(Items.SHEARS, new PriceInfo(3, 4))}, {new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL)), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 1), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 2), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 3), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 4), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 5), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 6), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 7), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 8), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 9), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 10), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 11), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 12), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 13), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 14), new PriceInfo(1, 2)), new ListItemForEmeralds(new ItemStack(Item.getItemFromBlock(Blocks.WOOL), 1, 15), new PriceInfo(1, 2))}}, {{new EmeraldForItems(Items.STRING, new PriceInfo(15, 20)), new ListItemForEmeralds(Items.ARROW, new PriceInfo(-12, -8))}, {new ListItemForEmeralds(Items.BOW, new PriceInfo(2, 3)), new ItemAndEmeraldToItem(Item.getItemFromBlock(Blocks.GRAVEL), new PriceInfo(10, 10), Items.FLINT, new PriceInfo(6, 10))}}}, {{{new EmeraldForItems(Items.PAPER, new PriceInfo(24, 36)), new ListEnchantedBookForEmeralds()}, {new EmeraldForItems(Items.BOOK, new PriceInfo(8, 10)), new ListItemForEmeralds(Items.COMPASS, new PriceInfo(10, 12)), new ListItemForEmeralds(Item.getItemFromBlock(Blocks.BOOKSHELF), new PriceInfo(3, 4))}, {new EmeraldForItems(Items.WRITTEN_BOOK, new PriceInfo(2, 2)), new ListItemForEmeralds(Items.CLOCK, new PriceInfo(10, 12)), new ListItemForEmeralds(Item.getItemFromBlock(Blocks.GLASS), new PriceInfo(-5, -3))}, {new ListEnchantedBookForEmeralds()}, {new ListEnchantedBookForEmeralds()}, {new ListItemForEmeralds(Items.NAME_TAG, new PriceInfo(20, 22))}}, {{new EmeraldForItems(Items.PAPER, new PriceInfo(24, 36))}, {new EmeraldForItems(Items.COMPASS, new PriceInfo(1, 1))}, {new ListItemForEmeralds(Items.MAP, new PriceInfo(7, 11))}, {new TreasureMapForEmeralds(new PriceInfo(12, 20), "Monument", MapDecoration.Type.MONUMENT), new TreasureMapForEmeralds(new PriceInfo(16, 28), "Mansion", MapDecoration.Type.MANSION)}}}, {{{new EmeraldForItems(Items.ROTTEN_FLESH, new PriceInfo(36, 40)), new EmeraldForItems(Items.GOLD_INGOT, new PriceInfo(8, 10))}, {new ListItemForEmeralds(Items.REDSTONE, new PriceInfo(-4, -1)), new ListItemForEmeralds(new ItemStack(Items.DYE, 1, EnumDyeColor.BLUE.getDyeDamage()), new PriceInfo(-2, -1))}, {new ListItemForEmeralds(Items.ENDER_PEARL, new PriceInfo(4, 7)), new ListItemForEmeralds(Item.getItemFromBlock(Blocks.GLOWSTONE), new PriceInfo(-3, -1))}, {new ListItemForEmeralds(Items.EXPERIENCE_BOTTLE, new PriceInfo(3, 11))}}}, {{{new EmeraldForItems(Items.COAL, new PriceInfo(16, 24)), new ListItemForEmeralds(Items.IRON_HELMET, new PriceInfo(4, 6))}, {new EmeraldForItems(Items.IRON_INGOT, new PriceInfo(7, 9)), new ListItemForEmeralds(Items.IRON_CHESTPLATE, new PriceInfo(10, 14))}, {new EmeraldForItems(Items.DIAMOND, new PriceInfo(3, 4)), new ListEnchantedItemForEmeralds(Items.DIAMOND_CHESTPLATE, new PriceInfo(16, 19))}, {new ListItemForEmeralds(Items.CHAINMAIL_BOOTS, new PriceInfo(5, 7)), new ListItemForEmeralds(Items.CHAINMAIL_LEGGINGS, new PriceInfo(9, 11)), new ListItemForEmeralds(Items.CHAINMAIL_HELMET, new PriceInfo(5, 7)), new ListItemForEmeralds(Items.CHAINMAIL_CHESTPLATE, new PriceInfo(11, 15))}}, {{new EmeraldForItems(Items.COAL, new PriceInfo(16, 24)), new ListItemForEmeralds(Items.IRON_AXE, new PriceInfo(6, 8))}, {new EmeraldForItems(Items.IRON_INGOT, new PriceInfo(7, 9)), new ListEnchantedItemForEmeralds(Items.IRON_SWORD, new PriceInfo(9, 10))}, {new EmeraldForItems(Items.DIAMOND, new PriceInfo(3, 4)), new ListEnchantedItemForEmeralds(Items.DIAMOND_SWORD, new PriceInfo(12, 15)), new ListEnchantedItemForEmeralds(Items.DIAMOND_AXE, new PriceInfo(9, 12))}}, {{new EmeraldForItems(Items.COAL, new PriceInfo(16, 24)), new ListEnchantedItemForEmeralds(Items.IRON_SHOVEL, new PriceInfo(5, 7))}, {new EmeraldForItems(Items.IRON_INGOT, new PriceInfo(7, 9)), new ListEnchantedItemForEmeralds(Items.IRON_PICKAXE, new PriceInfo(9, 11))}, {new EmeraldForItems(Items.DIAMOND, new PriceInfo(3, 4)), new ListEnchantedItemForEmeralds(Items.DIAMOND_PICKAXE, new PriceInfo(12, 15))}}}, {{{new EmeraldForItems(Items.PORKCHOP, new PriceInfo(14, 18)), new EmeraldForItems(Items.CHICKEN, new PriceInfo(14, 18))}, {new EmeraldForItems(Items.COAL, new PriceInfo(16, 24)), new ListItemForEmeralds(Items.COOKED_PORKCHOP, new PriceInfo(-7, -5)), new ListItemForEmeralds(Items.COOKED_CHICKEN, new PriceInfo(-8, -6))}}, {{new EmeraldForItems(Items.LEATHER, new PriceInfo(9, 12)), new ListItemForEmeralds(Items.LEATHER_LEGGINGS, new PriceInfo(2, 4))}, {new ListEnchantedItemForEmeralds(Items.LEATHER_CHESTPLATE, new PriceInfo(7, 12))}, {new ListItemForEmeralds(Items.SADDLE, new PriceInfo(8, 10))}}}, {new ITradeList[0][]}};
   }

   static class EmeraldForItems implements ITradeList {
      public Item buyingItem;
      public PriceInfo price;

      public EmeraldForItems(Item var1, PriceInfo var2) {
         this.buyingItem = var1;
         this.price = var2;
      }

      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         int var4 = 1;
         if (this.price != null) {
            var4 = this.price.getPrice(var3);
         }

         var2.add(new MerchantRecipe(new ItemStack(this.buyingItem, var4, 0), Items.EMERALD));
      }
   }

   interface ITradeList {
      void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3);
   }

   static class ItemAndEmeraldToItem implements ITradeList {
      public ItemStack buyingItemStack;
      public PriceInfo buyingPriceInfo;
      public ItemStack sellingItemstack;
      public PriceInfo sellingPriceInfo;

      public ItemAndEmeraldToItem(Item var1, PriceInfo var2, Item var3, PriceInfo var4) {
         this.buyingItemStack = new ItemStack(var1);
         this.buyingPriceInfo = var2;
         this.sellingItemstack = new ItemStack(var3);
         this.sellingPriceInfo = var4;
      }

      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         int var4 = this.buyingPriceInfo.getPrice(var3);
         int var5 = this.sellingPriceInfo.getPrice(var3);
         var2.add(new MerchantRecipe(new ItemStack(this.buyingItemStack.getItem(), var4, this.buyingItemStack.getMetadata()), new ItemStack(Items.EMERALD), new ItemStack(this.sellingItemstack.getItem(), var5, this.sellingItemstack.getMetadata())));
      }
   }

   static class ListEnchantedBookForEmeralds implements ITradeList {
      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         Enchantment var4 = (Enchantment)Enchantment.REGISTRY.getRandomObject(var3);
         int var5 = MathHelper.getInt(var3, var4.getMinLevel(), var4.getMaxLevel());
         ItemStack var6 = ItemEnchantedBook.getEnchantedItemStack(new EnchantmentData(var4, var5));
         int var7 = 2 + var3.nextInt(5 + var5 * 10) + 3 * var5;
         if (var4.isTreasureEnchantment()) {
            var7 *= 2;
         }

         if (var7 > 64) {
            var7 = 64;
         }

         var2.add(new MerchantRecipe(new ItemStack(Items.BOOK), new ItemStack(Items.EMERALD, var7), var6));
      }
   }

   static class ListEnchantedItemForEmeralds implements ITradeList {
      public ItemStack enchantedItemStack;
      public PriceInfo priceInfo;

      public ListEnchantedItemForEmeralds(Item var1, PriceInfo var2) {
         this.enchantedItemStack = new ItemStack(var1);
         this.priceInfo = var2;
      }

      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         int var4 = 1;
         if (this.priceInfo != null) {
            var4 = this.priceInfo.getPrice(var3);
         }

         ItemStack var5 = new ItemStack(Items.EMERALD, var4, 0);
         ItemStack var6 = EnchantmentHelper.addRandomEnchantment(var3, new ItemStack(this.enchantedItemStack.getItem(), 1, this.enchantedItemStack.getMetadata()), 5 + var3.nextInt(15), false);
         var2.add(new MerchantRecipe(var5, var6));
      }
   }

   static class ListItemForEmeralds implements ITradeList {
      public ItemStack itemToBuy;
      public PriceInfo priceInfo;

      public ListItemForEmeralds(Item var1, PriceInfo var2) {
         this.itemToBuy = new ItemStack(var1);
         this.priceInfo = var2;
      }

      public ListItemForEmeralds(ItemStack var1, PriceInfo var2) {
         this.itemToBuy = var1;
         this.priceInfo = var2;
      }

      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         int var4 = 1;
         if (this.priceInfo != null) {
            var4 = this.priceInfo.getPrice(var3);
         }

         ItemStack var5;
         ItemStack var6;
         if (var4 < 0) {
            var5 = new ItemStack(Items.EMERALD);
            var6 = new ItemStack(this.itemToBuy.getItem(), -var4, this.itemToBuy.getMetadata());
         } else {
            var5 = new ItemStack(Items.EMERALD, var4, 0);
            var6 = new ItemStack(this.itemToBuy.getItem(), 1, this.itemToBuy.getMetadata());
         }

         var2.add(new MerchantRecipe(var5, var6));
      }
   }

   static class PriceInfo extends Tuple<Integer, Integer> {
      public PriceInfo(int var1, int var2) {
         super(var1, var2);
         if (var2 < var1) {
            EntityVillager.access$000().warn("PriceRange({}, {}) invalid, {} smaller than {}", var1, var2, var2, var1);
         }

      }

      public int getPrice(Random var1) {
         return (Integer)this.getFirst() >= (Integer)this.getSecond() ? (Integer)this.getFirst() : (Integer)this.getFirst() + var1.nextInt((Integer)this.getSecond() - (Integer)this.getFirst() + 1);
      }
   }

   static class TreasureMapForEmeralds implements ITradeList {
      public PriceInfo field_190889_a;
      public String field_190890_b;
      public MapDecoration.Type field_190891_c;

      public TreasureMapForEmeralds(PriceInfo var1, String var2, MapDecoration.Type var3) {
         this.field_190889_a = var1;
         this.field_190890_b = var2;
         this.field_190891_c = var3;
      }

      public void func_190888_a(IMerchant var1, MerchantRecipeList var2, Random var3) {
         int var4 = this.field_190889_a.getPrice(var3);
         World var5 = var1.func_190670_t_();
         BlockPos var6 = var5.func_190528_a(this.field_190890_b, var1.func_190671_u_(), true);
         if (var6 != null) {
            ItemStack var7 = ItemMap.func_190906_a(var5, (double)var6.getX(), (double)var6.getZ(), (byte)2, true, true);
            ItemMap.func_190905_a(var5, var7);
            MapData.func_191094_a(var7, var6, "+", this.field_190891_c);
            var7.func_190924_f("filled_map." + this.field_190890_b.toLowerCase(Locale.ROOT));
            var2.add(new MerchantRecipe(new ItemStack(Items.EMERALD, var4), new ItemStack(Items.COMPASS), var7));
         }

      }
   }
}
