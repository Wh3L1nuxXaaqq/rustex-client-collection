package net.minecraft.entity.passive;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackRanged;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILlamaFollowCaravan;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAIRunAroundLikeCrazy;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLlamaSpit;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityLlama extends AbstractChestHorse implements IRangedAttackMob {
   private static final DataParameter<Integer> field_190720_bG;
   private static final DataParameter<Integer> field_190721_bH;
   private static final DataParameter<Integer> field_190722_bI;
   private boolean field_190723_bJ;
   @Nullable
   private EntityLlama field_190724_bK;
   @Nullable
   private EntityLlama field_190725_bL;

   public EntityLlama(World var1) {
      super(var1);
      this.setSize(0.9F, 1.87F);
   }

   private void func_190706_p(int var1) {
      this.dataManager.set(field_190720_bG, Math.max(1, Math.min(5, var1)));
   }

   private void func_190705_dT() {
      int var1 = this.rand.nextFloat() < 0.04F ? 5 : 3;
      this.func_190706_p(1 + this.rand.nextInt(var1));
   }

   public int func_190707_dL() {
      return (Integer)this.dataManager.get(field_190720_bG);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("Variant", this.func_190719_dM());
      var1.setInteger("Strength", this.func_190707_dL());
      if (!this.horseChest.getStackInSlot(1).func_190926_b()) {
         var1.setTag("DecorItem", this.horseChest.getStackInSlot(1).writeToNBT(new NBTTagCompound()));
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      this.func_190706_p(var1.getInteger("Strength"));
      super.readEntityFromNBT(var1);
      this.func_190710_o(var1.getInteger("Variant"));
      if (var1.hasKey("DecorItem", 10)) {
         this.horseChest.setInventorySlotContents(1, new ItemStack(var1.getCompoundTag("DecorItem")));
      }

      this.updateHorseSlots();
   }

   protected void initEntityAI() {
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIRunAroundLikeCrazy(this, 1.2));
      this.tasks.addTask(2, new EntityAILlamaFollowCaravan(this, (double)2.1F));
      this.tasks.addTask(3, new EntityAIAttackRanged(this, (double)1.25F, 40, 20.0F));
      this.tasks.addTask(3, new EntityAIPanic(this, 1.2));
      this.tasks.addTask(4, new EntityAIMate(this, (double)1.0F));
      this.tasks.addTask(5, new EntityAIFollowParent(this, (double)1.0F));
      this.tasks.addTask(6, new EntityAIWanderAvoidWater(this, 0.7));
      this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      this.tasks.addTask(8, new EntityAILookIdle(this));
      this.targetTasks.addTask(1, new AIHurtByTarget(this));
      this.targetTasks.addTask(2, new AIDefendTarget(this));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)40.0F);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_190720_bG, 0);
      this.dataManager.register(field_190721_bH, -1);
      this.dataManager.register(field_190722_bI, 0);
   }

   public int func_190719_dM() {
      return MathHelper.clamp((Integer)this.dataManager.get(field_190722_bI), 0, 3);
   }

   public void func_190710_o(int var1) {
      this.dataManager.set(field_190722_bI, var1);
   }

   protected int func_190686_di() {
      return this.func_190695_dh() ? 2 + 3 * this.func_190696_dl() : super.func_190686_di();
   }

   public void updatePassenger(Entity var1) {
      if (this.isPassenger(var1)) {
         float var2 = MathHelper.cos(this.renderYawOffset * ((float)Math.PI / 180F));
         float var3 = MathHelper.sin(this.renderYawOffset * ((float)Math.PI / 180F));
         float var4 = 0.3F;
         var1.setPosition(this.posX + (double)(0.3F * var3), this.posY + this.getMountedYOffset() + var1.getYOffset(), this.posZ - (double)(0.3F * var2));
      }

   }

   public double getMountedYOffset() {
      return (double)this.height * 0.67;
   }

   public boolean canBeSteered() {
      return false;
   }

   protected boolean func_190678_b(EntityPlayer var1, ItemStack var2) {
      byte var3 = 0;
      byte var4 = 0;
      float var5 = 0.0F;
      boolean var6 = false;
      Item var7 = var2.getItem();
      if (var7 == Items.WHEAT) {
         var3 = 10;
         var4 = 3;
         var5 = 2.0F;
      } else if (var7 == Item.getItemFromBlock(Blocks.HAY_BLOCK)) {
         var3 = 90;
         var4 = 6;
         var5 = 10.0F;
         if (this.isTame() && this.getGrowingAge() == 0) {
            var6 = true;
            this.setInLove(var1);
         }
      }

      if (this.getHealth() < this.getMaxHealth() && var5 > 0.0F) {
         this.heal(var5);
         var6 = true;
      }

      if (this.isChild() && var3 > 0) {
         this.world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)0.5F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, (double)0.0F, (double)0.0F, (double)0.0F);
         if (!this.world.isRemote) {
            this.addGrowth(var3);
         }

         var6 = true;
      }

      if (var4 > 0 && (var6 || !this.isTame()) && this.getTemper() < this.func_190676_dC()) {
         var6 = true;
         if (!this.world.isRemote) {
            this.increaseTemper(var4);
         }
      }

      if (var6 && !this.isSilent()) {
         this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.field_191253_dD, this.getSoundCategory(), 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
      }

      return var6;
   }

   protected boolean isMovementBlocked() {
      return this.getHealth() <= 0.0F || this.isEatingHaystack();
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      this.func_190705_dT();
      int var3;
      if (var2 instanceof GroupData) {
         var3 = ((GroupData)var2).field_190886_a;
      } else {
         var3 = this.rand.nextInt(4);
         var2 = new GroupData(var3);
      }

      this.func_190710_o(var3);
      return var2;
   }

   public boolean func_190717_dN() {
      return this.func_190704_dO() != null;
   }

   protected SoundEvent getAngrySound() {
      return SoundEvents.field_191250_dA;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.field_191260_dz;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_191254_dE;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_191252_dC;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(SoundEvents.field_191256_dG, 0.15F, 1.0F);
   }

   protected void func_190697_dk() {
      this.playSound(SoundEvents.field_191251_dB, 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
   }

   public void func_190687_dF() {
      SoundEvent var1 = this.getAngrySound();
      if (var1 != null) {
         this.playSound(var1, this.getSoundVolume(), this.getSoundPitch());
      }

   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191187_aw;
   }

   public int func_190696_dl() {
      return this.func_190707_dL();
   }

   public boolean func_190677_dK() {
      return true;
   }

   public boolean func_190682_f(ItemStack var1) {
      return var1.getItem() == Item.getItemFromBlock(Blocks.CARPET);
   }

   public boolean func_190685_dA() {
      return false;
   }

   public void onInventoryChanged(IInventory var1) {
      EnumDyeColor var2 = this.func_190704_dO();
      super.onInventoryChanged(var1);
      EnumDyeColor var3 = this.func_190704_dO();
      if (this.ticksExisted > 20 && var3 != null && var3 != var2) {
         this.playSound(SoundEvents.field_191257_dH, 0.5F, 1.0F);
      }

   }

   protected void updateHorseSlots() {
      if (!this.world.isRemote) {
         super.updateHorseSlots();
         this.func_190702_g(this.horseChest.getStackInSlot(1));
      }

   }

   private void func_190711_a(@Nullable EnumDyeColor var1) {
      this.dataManager.set(field_190721_bH, var1 == null ? -1 : var1.getMetadata());
   }

   private void func_190702_g(ItemStack var1) {
      if (this.func_190682_f(var1)) {
         this.func_190711_a(EnumDyeColor.byMetadata(var1.getMetadata()));
      } else {
         this.func_190711_a((EnumDyeColor)null);
      }

   }

   @Nullable
   public EnumDyeColor func_190704_dO() {
      int var1 = (Integer)this.dataManager.get(field_190721_bH);
      return var1 == -1 ? null : EnumDyeColor.byMetadata(var1);
   }

   public int func_190676_dC() {
      return 30;
   }

   public boolean canMateWith(EntityAnimal var1) {
      return var1 != this && var1 instanceof EntityLlama && this.canMate() && ((EntityLlama)var1).canMate();
   }

   public EntityLlama createChild(EntityAgeable var1) {
      EntityLlama var2 = new EntityLlama(this.world);
      this.func_190681_a(var1, var2);
      EntityLlama var3 = (EntityLlama)var1;
      int var4 = this.rand.nextInt(Math.max(this.func_190707_dL(), var3.func_190707_dL())) + 1;
      if (this.rand.nextFloat() < 0.03F) {
         ++var4;
      }

      var2.func_190706_p(var4);
      var2.func_190710_o(this.rand.nextBoolean() ? this.func_190719_dM() : var3.func_190719_dM());
      return var2;
   }

   private void func_190713_e(EntityLivingBase var1) {
      EntityLlamaSpit var2 = new EntityLlamaSpit(this.world, this);
      double var3 = var1.posX - this.posX;
      double var5 = var1.getEntityBoundingBox().minY + (double)(var1.height / 3.0F) - var2.posY;
      double var7 = var1.posZ - this.posZ;
      float var9 = MathHelper.sqrt(var3 * var3 + var7 * var7) * 0.2F;
      var2.setThrowableHeading(var3, var5 + (double)var9, var7, 1.5F, 10.0F);
      this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.field_191255_dF, this.getSoundCategory(), 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
      this.world.spawnEntityInWorld(var2);
      this.field_190723_bJ = true;
   }

   private void func_190714_x(boolean var1) {
      this.field_190723_bJ = var1;
   }

   public void fall(float var1, float var2) {
      int var3 = MathHelper.ceil((var1 * 0.5F - 3.0F) * var2);
      if (var3 > 0) {
         if (var1 >= 6.0F) {
            this.attackEntityFrom(DamageSource.fall, (float)var3);
            if (this.isBeingRidden()) {
               for(Entity var5 : this.getRecursivePassengers()) {
                  var5.attackEntityFrom(DamageSource.fall, (float)var3);
               }
            }
         }

         IBlockState var7 = this.world.getBlockState(new BlockPos(this.posX, this.posY - 0.2 - (double)this.prevRotationYaw, this.posZ));
         Block var8 = var7.getBlock();
         if (var7.getMaterial() != Material.AIR && !this.isSilent()) {
            SoundType var6 = var8.getSoundType();
            this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, var6.getStepSound(), this.getSoundCategory(), var6.getVolume() * 0.5F, var6.getPitch() * 0.75F);
         }
      }

   }

   public void func_190709_dP() {
      if (this.field_190724_bK != null) {
         this.field_190724_bK.field_190725_bL = null;
      }

      this.field_190724_bK = null;
   }

   public void func_190715_a(EntityLlama var1) {
      this.field_190724_bK = var1;
      this.field_190724_bK.field_190725_bL = this;
   }

   public boolean func_190712_dQ() {
      return this.field_190725_bL != null;
   }

   public boolean func_190718_dR() {
      return this.field_190724_bK != null;
   }

   @Nullable
   public EntityLlama func_190716_dS() {
      return this.field_190724_bK;
   }

   protected double func_190634_dg() {
      return (double)2.0F;
   }

   protected void func_190679_dD() {
      if (!this.func_190718_dR() && this.isChild()) {
         super.func_190679_dD();
      }

   }

   public boolean func_190684_dE() {
      return false;
   }

   public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2) {
      this.func_190713_e(var1);
   }

   public void setSwingingArms(boolean var1) {
   }

   static boolean access$100(EntityLlama var0) {
      return var0.field_190723_bJ;
   }

   static void access$200(EntityLlama var0, boolean var1) {
      var0.func_190714_x(var1);
   }

   static {
      field_190720_bG = EntityDataManager.<Integer>createKey(EntityLlama.class, DataSerializers.VARINT);
      field_190721_bH = EntityDataManager.<Integer>createKey(EntityLlama.class, DataSerializers.VARINT);
      field_190722_bI = EntityDataManager.<Integer>createKey(EntityLlama.class, DataSerializers.VARINT);
   }

   static class AIDefendTarget extends EntityAINearestAttackableTarget<EntityWolf> {
      public AIDefendTarget(EntityLlama var1) {
         super(var1, EntityWolf.class, 16, false, true, (Predicate)null);
      }

      public boolean shouldExecute() {
         if (super.shouldExecute() && this.targetEntity != null && !((EntityWolf)this.targetEntity).isTamed()) {
            return true;
         } else {
            this.taskOwner.setAttackTarget((EntityLivingBase)null);
            return false;
         }
      }

      protected double getTargetDistance() {
         return super.getTargetDistance() * (double)0.25F;
      }
   }

   static class AIHurtByTarget extends EntityAIHurtByTarget {
      public AIHurtByTarget(EntityLlama var1) {
         super(var1, false);
      }

      public boolean continueExecuting() {
         if (this.taskOwner instanceof EntityLlama) {
            EntityLlama var1 = (EntityLlama)this.taskOwner;
            if (EntityLlama.access$100(var1)) {
               EntityLlama.access$200(var1, false);
               return false;
            }
         }

         return super.continueExecuting();
      }
   }

   static class GroupData implements IEntityLivingData {
      public int field_190886_a;

      private GroupData(int var1) {
         this.field_190886_a = var1;
      }

      GroupData(int var1, Object var2) {
         this(var1);
      }
   }
}
