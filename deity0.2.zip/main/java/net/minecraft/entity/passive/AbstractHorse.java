package net.minecraft.entity.passive;

import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IJumpingMount;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAIRunAroundLikeCrazy;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.ContainerHorseChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.IInventoryChangedListener;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;

public abstract class AbstractHorse extends EntityAnimal implements IInventoryChangedListener, IJumpingMount {
   private static final Predicate<Entity> IS_HORSE_BREEDING = new Predicate<Entity>() {
      public boolean apply(@Nullable Entity var1) {
         return var1 instanceof AbstractHorse && ((AbstractHorse)var1).isBreeding();
      }
   };
   protected static final IAttribute JUMP_STRENGTH = (new RangedAttribute((IAttribute)null, "horse.jumpStrength", 0.7, (double)0.0F, (double)2.0F)).setDescription("Jump Strength").setShouldWatch(true);
   private static final DataParameter<Byte> STATUS;
   private static final DataParameter<Optional<UUID>> OWNER_UNIQUE_ID;
   private int field_190689_bJ;
   private int openMouthCounter;
   private int jumpRearingCounter;
   public int tailCounter;
   public int sprintCounter;
   protected boolean horseJumping;
   protected ContainerHorseChest horseChest;
   protected int temper;
   protected float jumpPower;
   private boolean allowStandSliding;
   private float headLean;
   private float prevHeadLean;
   private float rearingAmount;
   private float prevRearingAmount;
   private float mouthOpenness;
   private float prevMouthOpenness;
   protected boolean field_190688_bE = true;
   protected int gallopTime;

   public AbstractHorse(World var1) {
      super(var1);
      this.setSize(1.3964844F, 1.6F);
      this.stepHeight = 1.0F;
      this.initHorseChest();
   }

   protected void initEntityAI() {
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntityAIPanic(this, 1.2));
      this.tasks.addTask(1, new EntityAIRunAroundLikeCrazy(this, 1.2));
      this.tasks.addTask(2, new EntityAIMate(this, (double)1.0F, AbstractHorse.class));
      this.tasks.addTask(4, new EntityAIFollowParent(this, (double)1.0F));
      this.tasks.addTask(6, new EntityAIWanderAvoidWater(this, 0.7));
      this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      this.tasks.addTask(8, new EntityAILookIdle(this));
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(STATUS, (byte)0);
      this.dataManager.register(OWNER_UNIQUE_ID, Optional.absent());
   }

   protected boolean getHorseWatchableBoolean(int var1) {
      return ((Byte)this.dataManager.get(STATUS) & var1) != 0;
   }

   protected void setHorseWatchableBoolean(int var1, boolean var2) {
      byte var3 = (Byte)this.dataManager.get(STATUS);
      if (var2) {
         this.dataManager.set(STATUS, (byte)(var3 | var1));
      } else {
         this.dataManager.set(STATUS, (byte)(var3 & ~var1));
      }

   }

   public boolean isTame() {
      return this.getHorseWatchableBoolean(2);
   }

   @Nullable
   public UUID getOwnerUniqueId() {
      return (UUID)((Optional)this.dataManager.get(OWNER_UNIQUE_ID)).orNull();
   }

   public void setOwnerUniqueId(@Nullable UUID var1) {
      this.dataManager.set(OWNER_UNIQUE_ID, Optional.fromNullable(var1));
   }

   public float getHorseSize() {
      return 0.5F;
   }

   public void setScaleForAge(boolean var1) {
      this.setScale(var1 ? this.getHorseSize() : 1.0F);
   }

   public boolean isHorseJumping() {
      return this.horseJumping;
   }

   public void setHorseTamed(boolean var1) {
      this.setHorseWatchableBoolean(2, var1);
   }

   public void setHorseJumping(boolean var1) {
      this.horseJumping = var1;
   }

   public boolean canBeLeashedTo(EntityPlayer var1) {
      return super.canBeLeashedTo(var1) && this.getCreatureAttribute() != EnumCreatureAttribute.UNDEAD;
   }

   protected void onLeashDistance(float var1) {
      if (var1 > 6.0F && this.isEatingHaystack()) {
         this.setEatingHaystack(false);
      }

   }

   public boolean isEatingHaystack() {
      return this.getHorseWatchableBoolean(16);
   }

   public boolean isRearing() {
      return this.getHorseWatchableBoolean(32);
   }

   public boolean isBreeding() {
      return this.getHorseWatchableBoolean(8);
   }

   public void setBreeding(boolean var1) {
      this.setHorseWatchableBoolean(8, var1);
   }

   public void setHorseSaddled(boolean var1) {
      this.setHorseWatchableBoolean(4, var1);
   }

   public int getTemper() {
      return this.temper;
   }

   public void setTemper(int var1) {
      this.temper = var1;
   }

   public int increaseTemper(int var1) {
      int var2 = MathHelper.clamp(this.getTemper() + var1, 0, this.func_190676_dC());
      this.setTemper(var2);
      return var2;
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      Entity var3 = var1.getEntity();
      return this.isBeingRidden() && var3 != null && this.isRidingOrBeingRiddenBy(var3) ? false : super.attackEntityFrom(var1, var2);
   }

   public boolean canBePushed() {
      return !this.isBeingRidden();
   }

   private void eatingHorse() {
      this.openHorseMouth();
      if (!this.isSilent()) {
         this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_HORSE_EAT, this.getSoundCategory(), 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
      }

   }

   public void fall(float var1, float var2) {
      if (var1 > 1.0F) {
         this.playSound(SoundEvents.ENTITY_HORSE_LAND, 0.4F, 1.0F);
      }

      int var3 = MathHelper.ceil((var1 * 0.5F - 3.0F) * var2);
      if (var3 > 0) {
         this.attackEntityFrom(DamageSource.fall, (float)var3);
         if (this.isBeingRidden()) {
            for(Entity var5 : this.getRecursivePassengers()) {
               var5.attackEntityFrom(DamageSource.fall, (float)var3);
            }
         }

         IBlockState var7 = this.world.getBlockState(new BlockPos(this.posX, this.posY - 0.2 - (double)this.prevRotationYaw, this.posZ));
         Block var8 = var7.getBlock();
         if (var7.getMaterial() != Material.AIR && !this.isSilent()) {
            SoundType var6 = var8.getSoundType();
            this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, var6.getStepSound(), this.getSoundCategory(), var6.getVolume() * 0.5F, var6.getPitch() * 0.75F);
         }
      }

   }

   protected int func_190686_di() {
      return 2;
   }

   protected void initHorseChest() {
      ContainerHorseChest var1 = this.horseChest;
      this.horseChest = new ContainerHorseChest("HorseChest", this.func_190686_di());
      this.horseChest.setCustomName(this.getName());
      if (var1 != null) {
         var1.removeInventoryChangeListener(this);
         int var2 = Math.min(var1.getSizeInventory(), this.horseChest.getSizeInventory());

         for(int var3 = 0; var3 < var2; ++var3) {
            ItemStack var4 = var1.getStackInSlot(var3);
            if (!var4.func_190926_b()) {
               this.horseChest.setInventorySlotContents(var3, var4.copy());
            }
         }
      }

      this.horseChest.addInventoryChangeListener(this);
      this.updateHorseSlots();
   }

   protected void updateHorseSlots() {
      if (!this.world.isRemote) {
         this.setHorseSaddled(!this.horseChest.getStackInSlot(0).func_190926_b() && this.func_190685_dA());
      }

   }

   public void onInventoryChanged(IInventory var1) {
      boolean var2 = this.isHorseSaddled();
      this.updateHorseSlots();
      if (this.ticksExisted > 20 && !var2 && this.isHorseSaddled()) {
         this.playSound(SoundEvents.ENTITY_HORSE_SADDLE, 0.5F, 1.0F);
      }

   }

   @Nullable
   protected AbstractHorse getClosestHorse(Entity var1, double var2) {
      double var4 = Double.MAX_VALUE;
      Entity var6 = null;

      for(Entity var8 : this.world.getEntitiesInAABBexcluding(var1, var1.getEntityBoundingBox().addCoord(var2, var2, var2), IS_HORSE_BREEDING)) {
         double var9 = var8.getDistanceSq(var1.posX, var1.posY, var1.posZ);
         if (var9 < var4) {
            var6 = var8;
            var4 = var9;
         }
      }

      return (AbstractHorse)var6;
   }

   public double getHorseJumpStrength() {
      return this.getEntityAttribute(JUMP_STRENGTH).getAttributeValue();
   }

   @Nullable
   protected SoundEvent getDeathSound() {
      this.openHorseMouth();
      return null;
   }

   @Nullable
   protected SoundEvent getHurtSound(DamageSource var1) {
      this.openHorseMouth();
      if (this.rand.nextInt(3) == 0) {
         this.makeHorseRear();
      }

      return null;
   }

   @Nullable
   protected SoundEvent getAmbientSound() {
      this.openHorseMouth();
      if (this.rand.nextInt(10) == 0 && !this.isMovementBlocked()) {
         this.makeHorseRear();
      }

      return null;
   }

   public boolean func_190685_dA() {
      return true;
   }

   public boolean isHorseSaddled() {
      return this.getHorseWatchableBoolean(4);
   }

   @Nullable
   protected SoundEvent getAngrySound() {
      this.openHorseMouth();
      this.makeHorseRear();
      return null;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      if (!var2.getDefaultState().getMaterial().isLiquid()) {
         SoundType var3 = var2.getSoundType();
         if (this.world.getBlockState(var1.up()).getBlock() == Blocks.SNOW_LAYER) {
            var3 = Blocks.SNOW_LAYER.getSoundType();
         }

         if (this.isBeingRidden() && this.field_190688_bE) {
            ++this.gallopTime;
            if (this.gallopTime > 5 && this.gallopTime % 3 == 0) {
               this.func_190680_a(var3);
            } else if (this.gallopTime <= 5) {
               this.playSound(SoundEvents.ENTITY_HORSE_STEP_WOOD, var3.getVolume() * 0.15F, var3.getPitch());
            }
         } else if (var3 == SoundType.WOOD) {
            this.playSound(SoundEvents.ENTITY_HORSE_STEP_WOOD, var3.getVolume() * 0.15F, var3.getPitch());
         } else {
            this.playSound(SoundEvents.ENTITY_HORSE_STEP, var3.getVolume() * 0.15F, var3.getPitch());
         }
      }

   }

   protected void func_190680_a(SoundType var1) {
      this.playSound(SoundEvents.ENTITY_HORSE_GALLOP, var1.getVolume() * 0.15F, var1.getPitch());
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getAttributeMap().registerAttribute(JUMP_STRENGTH);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)53.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.225F);
   }

   public int getMaxSpawnedInChunk() {
      return 6;
   }

   public int func_190676_dC() {
      return 100;
   }

   protected float getSoundVolume() {
      return 0.8F;
   }

   public int getTalkInterval() {
      return 400;
   }

   public void openGUI(EntityPlayer var1) {
      if (!this.world.isRemote && (!this.isBeingRidden() || this.isPassenger(var1)) && this.isTame()) {
         this.horseChest.setCustomName(this.getName());
         var1.openGuiHorseInventory(this, this.horseChest);
      }

   }

   protected boolean func_190678_b(EntityPlayer var1, ItemStack var2) {
      boolean var3 = false;
      float var4 = 0.0F;
      short var5 = 0;
      byte var6 = 0;
      Item var7 = var2.getItem();
      if (var7 == Items.WHEAT) {
         var4 = 2.0F;
         var5 = 20;
         var6 = 3;
      } else if (var7 == Items.SUGAR) {
         var4 = 1.0F;
         var5 = 30;
         var6 = 3;
      } else if (var7 == Item.getItemFromBlock(Blocks.HAY_BLOCK)) {
         var4 = 20.0F;
         var5 = 180;
      } else if (var7 == Items.APPLE) {
         var4 = 3.0F;
         var5 = 60;
         var6 = 3;
      } else if (var7 == Items.GOLDEN_CARROT) {
         var4 = 4.0F;
         var5 = 60;
         var6 = 5;
         if (this.isTame() && this.getGrowingAge() == 0 && !this.isInLove()) {
            var3 = true;
            this.setInLove(var1);
         }
      } else if (var7 == Items.GOLDEN_APPLE) {
         var4 = 10.0F;
         var5 = 240;
         var6 = 10;
         if (this.isTame() && this.getGrowingAge() == 0 && !this.isInLove()) {
            var3 = true;
            this.setInLove(var1);
         }
      }

      if (this.getHealth() < this.getMaxHealth() && var4 > 0.0F) {
         this.heal(var4);
         var3 = true;
      }

      if (this.isChild() && var5 > 0) {
         this.world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)0.5F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, (double)0.0F, (double)0.0F, (double)0.0F);
         if (!this.world.isRemote) {
            this.addGrowth(var5);
         }

         var3 = true;
      }

      if (var6 > 0 && (var3 || !this.isTame()) && this.getTemper() < this.func_190676_dC()) {
         var3 = true;
         if (!this.world.isRemote) {
            this.increaseTemper(var6);
         }
      }

      if (var3) {
         this.eatingHorse();
      }

      return var3;
   }

   protected void mountTo(EntityPlayer var1) {
      var1.rotationYaw = this.rotationYaw;
      var1.rotationPitch = this.rotationPitch;
      this.setEatingHaystack(false);
      this.setRearing(false);
      if (!this.world.isRemote) {
         var1.startRiding(this);
      }

   }

   protected boolean isMovementBlocked() {
      return super.isMovementBlocked() && this.isBeingRidden() && this.isHorseSaddled() || this.isEatingHaystack() || this.isRearing();
   }

   public boolean isBreedingItem(ItemStack var1) {
      return false;
   }

   private void moveTail() {
      this.tailCounter = 1;
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (!this.world.isRemote && this.horseChest != null) {
         for(int var2 = 0; var2 < this.horseChest.getSizeInventory(); ++var2) {
            ItemStack var3 = this.horseChest.getStackInSlot(var2);
            if (!var3.func_190926_b()) {
               this.entityDropItem(var3, 0.0F);
            }
         }
      }

   }

   public void onLivingUpdate() {
      if (this.rand.nextInt(200) == 0) {
         this.moveTail();
      }

      super.onLivingUpdate();
      if (!this.world.isRemote) {
         if (this.rand.nextInt(900) == 0 && this.deathTime == 0) {
            this.heal(1.0F);
         }

         if (this.func_190684_dE()) {
            if (!this.isEatingHaystack() && !this.isBeingRidden() && this.rand.nextInt(300) == 0 && this.world.getBlockState(new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.posY) - 1, MathHelper.floor(this.posZ))).getBlock() == Blocks.GRASS) {
               this.setEatingHaystack(true);
            }

            if (this.isEatingHaystack() && ++this.field_190689_bJ > 50) {
               this.field_190689_bJ = 0;
               this.setEatingHaystack(false);
            }
         }

         this.func_190679_dD();
      }

   }

   protected void func_190679_dD() {
      if (this.isBreeding() && this.isChild() && !this.isEatingHaystack()) {
         AbstractHorse var1 = this.getClosestHorse(this, (double)16.0F);
         if (var1 != null && this.getDistanceSqToEntity(var1) > (double)4.0F) {
            this.navigator.getPathToEntityLiving(var1);
         }
      }

   }

   public boolean func_190684_dE() {
      return true;
   }

   public void onUpdate() {
      super.onUpdate();
      if (this.openMouthCounter > 0 && ++this.openMouthCounter > 30) {
         this.openMouthCounter = 0;
         this.setHorseWatchableBoolean(64, false);
      }

      if (this.canPassengerSteer() && this.jumpRearingCounter > 0 && ++this.jumpRearingCounter > 20) {
         this.jumpRearingCounter = 0;
         this.setRearing(false);
      }

      if (this.tailCounter > 0 && ++this.tailCounter > 8) {
         this.tailCounter = 0;
      }

      if (this.sprintCounter > 0) {
         ++this.sprintCounter;
         if (this.sprintCounter > 300) {
            this.sprintCounter = 0;
         }
      }

      this.prevHeadLean = this.headLean;
      if (this.isEatingHaystack()) {
         this.headLean += (1.0F - this.headLean) * 0.4F + 0.05F;
         if (this.headLean > 1.0F) {
            this.headLean = 1.0F;
         }
      } else {
         this.headLean += (0.0F - this.headLean) * 0.4F - 0.05F;
         if (this.headLean < 0.0F) {
            this.headLean = 0.0F;
         }
      }

      this.prevRearingAmount = this.rearingAmount;
      if (this.isRearing()) {
         this.headLean = 0.0F;
         this.prevHeadLean = this.headLean;
         this.rearingAmount += (1.0F - this.rearingAmount) * 0.4F + 0.05F;
         if (this.rearingAmount > 1.0F) {
            this.rearingAmount = 1.0F;
         }
      } else {
         this.allowStandSliding = false;
         this.rearingAmount += (0.8F * this.rearingAmount * this.rearingAmount * this.rearingAmount - this.rearingAmount) * 0.6F - 0.05F;
         if (this.rearingAmount < 0.0F) {
            this.rearingAmount = 0.0F;
         }
      }

      this.prevMouthOpenness = this.mouthOpenness;
      if (this.getHorseWatchableBoolean(64)) {
         this.mouthOpenness += (1.0F - this.mouthOpenness) * 0.7F + 0.05F;
         if (this.mouthOpenness > 1.0F) {
            this.mouthOpenness = 1.0F;
         }
      } else {
         this.mouthOpenness += (0.0F - this.mouthOpenness) * 0.7F - 0.05F;
         if (this.mouthOpenness < 0.0F) {
            this.mouthOpenness = 0.0F;
         }
      }

   }

   private void openHorseMouth() {
      if (!this.world.isRemote) {
         this.openMouthCounter = 1;
         this.setHorseWatchableBoolean(64, true);
      }

   }

   public void setEatingHaystack(boolean var1) {
      this.setHorseWatchableBoolean(16, var1);
   }

   public void setRearing(boolean var1) {
      if (var1) {
         this.setEatingHaystack(false);
      }

      this.setHorseWatchableBoolean(32, var1);
   }

   private void makeHorseRear() {
      if (this.canPassengerSteer()) {
         this.jumpRearingCounter = 1;
         this.setRearing(true);
      }

   }

   public void func_190687_dF() {
      this.makeHorseRear();
      SoundEvent var1 = this.getAngrySound();
      if (var1 != null) {
         this.playSound(var1, this.getSoundVolume(), this.getSoundPitch());
      }

   }

   public boolean setTamedBy(EntityPlayer var1) {
      this.setOwnerUniqueId(var1.getUniqueID());
      this.setHorseTamed(true);
      if (var1 instanceof EntityPlayerMP) {
         CriteriaTriggers.field_193136_w.func_193178_a((EntityPlayerMP)var1, this);
      }

      this.world.setEntityState(this, (byte)7);
      return true;
   }

   public void func_191986_a(float var1, float var2, float var3) {
      if (this.isBeingRidden() && this.canBeSteered() && this.isHorseSaddled()) {
         EntityLivingBase var4 = (EntityLivingBase)this.getControllingPassenger();
         this.rotationYaw = var4.rotationYaw;
         this.prevRotationYaw = this.rotationYaw;
         this.rotationPitch = var4.rotationPitch * 0.5F;
         this.setRotation(this.rotationYaw, this.rotationPitch);
         this.renderYawOffset = this.rotationYaw;
         this.rotationYawHead = this.renderYawOffset;
         var1 = var4.moveStrafing * 0.5F;
         var3 = var4.field_191988_bg;
         if (var3 <= 0.0F) {
            var3 *= 0.25F;
            this.gallopTime = 0;
         }

         if (this.onGround && this.jumpPower == 0.0F && this.isRearing() && !this.allowStandSliding) {
            var1 = 0.0F;
            var3 = 0.0F;
         }

         if (this.jumpPower > 0.0F && !this.isHorseJumping() && this.onGround) {
            this.motionY = this.getHorseJumpStrength() * (double)this.jumpPower;
            if (this.isPotionActive(MobEffects.JUMP_BOOST)) {
               this.motionY += (double)((float)(this.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier() + 1) * 0.1F);
            }

            this.setHorseJumping(true);
            this.isAirBorne = true;
            if (var3 > 0.0F) {
               float var5 = MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F));
               float var6 = MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F));
               this.motionX += (double)(-0.4F * var5 * this.jumpPower);
               this.motionZ += (double)(0.4F * var6 * this.jumpPower);
               this.playSound(SoundEvents.ENTITY_HORSE_JUMP, 0.4F, 1.0F);
            }

            this.jumpPower = 0.0F;
         }

         this.jumpMovementFactor = this.getAIMoveSpeed() * 0.1F;
         if (this.canPassengerSteer()) {
            this.setAIMoveSpeed((float)this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue());
            super.func_191986_a(var1, var2, var3);
         } else if (var4 instanceof EntityPlayer) {
            this.motionX = (double)0.0F;
            this.motionY = (double)0.0F;
            this.motionZ = (double)0.0F;
         }

         if (this.onGround) {
            this.jumpPower = 0.0F;
            this.setHorseJumping(false);
         }

         this.prevLimbSwingAmount = this.limbSwingAmount;
         double var12 = this.posX - this.prevPosX;
         double var7 = this.posZ - this.prevPosZ;
         float var9 = MathHelper.sqrt(var12 * var12 + var7 * var7) * 4.0F;
         if (var9 > 1.0F) {
            var9 = 1.0F;
         }

         this.limbSwingAmount += (var9 - this.limbSwingAmount) * 0.4F;
         this.limbSwing += this.limbSwingAmount;
      } else {
         this.jumpMovementFactor = 0.02F;
         super.func_191986_a(var1, var2, var3);
      }

   }

   public static void func_190683_c(DataFixer var0, Class<?> var1) {
      EntityLiving.registerFixesMob(var0, var1);
      var0.registerWalker(FixTypes.ENTITY, new ItemStackData(var1, new String[]{"SaddleItem"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("EatingHaystack", this.isEatingHaystack());
      var1.setBoolean("Bred", this.isBreeding());
      var1.setInteger("Temper", this.getTemper());
      var1.setBoolean("Tame", this.isTame());
      if (this.getOwnerUniqueId() != null) {
         var1.setString("OwnerUUID", this.getOwnerUniqueId().toString());
      }

      if (!this.horseChest.getStackInSlot(0).func_190926_b()) {
         var1.setTag("SaddleItem", this.horseChest.getStackInSlot(0).writeToNBT(new NBTTagCompound()));
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setEatingHaystack(var1.getBoolean("EatingHaystack"));
      this.setBreeding(var1.getBoolean("Bred"));
      this.setTemper(var1.getInteger("Temper"));
      this.setHorseTamed(var1.getBoolean("Tame"));
      String var2;
      if (var1.hasKey("OwnerUUID", 8)) {
         var2 = var1.getString("OwnerUUID");
      } else {
         String var3 = var1.getString("Owner");
         var2 = PreYggdrasilConverter.convertMobOwnerIfNeeded(this.getServer(), var3);
      }

      if (!var2.isEmpty()) {
         this.setOwnerUniqueId(UUID.fromString(var2));
      }

      IAttributeInstance var5 = this.getAttributeMap().getAttributeInstanceByName("Speed");
      if (var5 != null) {
         this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(var5.getBaseValue() * (double)0.25F);
      }

      if (var1.hasKey("SaddleItem", 10)) {
         ItemStack var4 = new ItemStack(var1.getCompoundTag("SaddleItem"));
         if (var4.getItem() == Items.SADDLE) {
            this.horseChest.setInventorySlotContents(0, var4);
         }
      }

      this.updateHorseSlots();
   }

   public boolean canMateWith(EntityAnimal var1) {
      return false;
   }

   protected boolean canMate() {
      return !this.isBeingRidden() && !this.isRiding() && this.isTame() && !this.isChild() && this.getHealth() >= this.getMaxHealth() && this.isInLove();
   }

   @Nullable
   public EntityAgeable createChild(EntityAgeable var1) {
      return null;
   }

   protected void func_190681_a(EntityAgeable var1, AbstractHorse var2) {
      double var3 = this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).getBaseValue() + var1.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).getBaseValue() + (double)this.getModifiedMaxHealth();
      var2.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(var3 / (double)3.0F);
      double var5 = this.getEntityAttribute(JUMP_STRENGTH).getBaseValue() + var1.getEntityAttribute(JUMP_STRENGTH).getBaseValue() + this.getModifiedJumpStrength();
      var2.getEntityAttribute(JUMP_STRENGTH).setBaseValue(var5 / (double)3.0F);
      double var7 = this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getBaseValue() + var1.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getBaseValue() + this.getModifiedMovementSpeed();
      var2.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(var7 / (double)3.0F);
   }

   public boolean canBeSteered() {
      return this.getControllingPassenger() instanceof EntityLivingBase;
   }

   public float getGrassEatingAmount(float var1) {
      return this.prevHeadLean + (this.headLean - this.prevHeadLean) * var1;
   }

   public float getRearingAmount(float var1) {
      return this.prevRearingAmount + (this.rearingAmount - this.prevRearingAmount) * var1;
   }

   public float getMouthOpennessAngle(float var1) {
      return this.prevMouthOpenness + (this.mouthOpenness - this.prevMouthOpenness) * var1;
   }

   public void setJumpPower(int var1) {
      if (this.isHorseSaddled()) {
         if (var1 < 0) {
            var1 = 0;
         } else {
            this.allowStandSliding = true;
            this.makeHorseRear();
         }

         if (var1 >= 90) {
            this.jumpPower = 1.0F;
         } else {
            this.jumpPower = 0.4F + 0.4F * (float)var1 / 90.0F;
         }
      }

   }

   public boolean canJump() {
      return this.isHorseSaddled();
   }

   public void handleStartJump(int var1) {
      this.allowStandSliding = true;
      this.makeHorseRear();
   }

   public void handleStopJump() {
   }

   protected void spawnHorseParticles(boolean var1) {
      EnumParticleTypes var2 = var1 ? EnumParticleTypes.HEART : EnumParticleTypes.SMOKE_NORMAL;

      for(int var3 = 0; var3 < 7; ++var3) {
         double var4 = this.rand.nextGaussian() * 0.02;
         double var6 = this.rand.nextGaussian() * 0.02;
         double var8 = this.rand.nextGaussian() * 0.02;
         this.world.spawnParticle(var2, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)0.5F + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, var4, var6, var8);
      }

   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 7) {
         this.spawnHorseParticles(true);
      } else if (var1 == 6) {
         this.spawnHorseParticles(false);
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   public void updatePassenger(Entity var1) {
      super.updatePassenger(var1);
      if (var1 instanceof EntityLiving) {
         EntityLiving var2 = (EntityLiving)var1;
         this.renderYawOffset = var2.renderYawOffset;
      }

      if (this.prevRearingAmount > 0.0F) {
         float var6 = MathHelper.sin(this.renderYawOffset * ((float)Math.PI / 180F));
         float var3 = MathHelper.cos(this.renderYawOffset * ((float)Math.PI / 180F));
         float var4 = 0.7F * this.prevRearingAmount;
         float var5 = 0.15F * this.prevRearingAmount;
         var1.setPosition(this.posX + (double)(var4 * var6), this.posY + this.getMountedYOffset() + var1.getYOffset() + (double)var5, this.posZ - (double)(var4 * var3));
         if (var1 instanceof EntityLivingBase) {
            ((EntityLivingBase)var1).renderYawOffset = this.renderYawOffset;
         }
      }

   }

   protected float getModifiedMaxHealth() {
      return 15.0F + (float)this.rand.nextInt(8) + (float)this.rand.nextInt(9);
   }

   protected double getModifiedJumpStrength() {
      return (double)0.4F + this.rand.nextDouble() * 0.2 + this.rand.nextDouble() * 0.2 + this.rand.nextDouble() * 0.2;
   }

   protected double getModifiedMovementSpeed() {
      return ((double)0.45F + this.rand.nextDouble() * 0.3 + this.rand.nextDouble() * 0.3 + this.rand.nextDouble() * 0.3) * (double)0.25F;
   }

   public boolean isOnLadder() {
      return false;
   }

   public float getEyeHeight() {
      return this.height;
   }

   public boolean func_190677_dK() {
      return false;
   }

   public boolean func_190682_f(ItemStack var1) {
      return false;
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      int var3 = var1 - 400;
      if (var3 >= 0 && var3 < 2 && var3 < this.horseChest.getSizeInventory()) {
         if (var3 == 0 && var2.getItem() != Items.SADDLE) {
            return false;
         } else if (var3 == 1 && (!this.func_190677_dK() || !this.func_190682_f(var2))) {
            return false;
         } else {
            this.horseChest.setInventorySlotContents(var3, var2);
            this.updateHorseSlots();
            return true;
         }
      } else {
         int var4 = var1 - 500 + 2;
         if (var4 >= 2 && var4 < this.horseChest.getSizeInventory()) {
            this.horseChest.setInventorySlotContents(var4, var2);
            return true;
         } else {
            return false;
         }
      }
   }

   @Nullable
   public Entity getControllingPassenger() {
      return this.getPassengers().isEmpty() ? null : (Entity)this.getPassengers().get(0);
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      if (this.rand.nextInt(5) == 0) {
         this.setGrowingAge(-24000);
      }

      return var2;
   }

   static {
      STATUS = EntityDataManager.<Byte>createKey(AbstractHorse.class, DataSerializers.BYTE);
      OWNER_UNIQUE_ID = EntityDataManager.<Optional<UUID>>createKey(AbstractHorse.class, DataSerializers.OPTIONAL_UNIQUE_ID);
   }
}
