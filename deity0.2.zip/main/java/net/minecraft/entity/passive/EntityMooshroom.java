package net.minecraft.entity.passive;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityMooshroom extends EntityCow {
   public EntityMooshroom(World var1) {
      super(var1);
      this.setSize(0.9F, 1.4F);
      this.spawnableBlock = Blocks.MYCELIUM;
   }

   public static void registerFixesMooshroom(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityMooshroom.class);
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (var3.getItem() == Items.BOWL && this.getGrowingAge() >= 0 && !var1.capabilities.isCreativeMode) {
         var3.func_190918_g(1);
         if (var3.func_190926_b()) {
            var1.setHeldItem(var2, new ItemStack(Items.MUSHROOM_STEW));
         } else if (!var1.inventory.addItemStackToInventory(new ItemStack(Items.MUSHROOM_STEW))) {
            var1.dropItem(new ItemStack(Items.MUSHROOM_STEW), false);
         }

         return true;
      } else if (var3.getItem() == Items.SHEARS && this.getGrowingAge() >= 0) {
         this.setDead();
         this.world.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, this.posX, this.posY + (double)(this.height / 2.0F), this.posZ, (double)0.0F, (double)0.0F, (double)0.0F);
         if (!this.world.isRemote) {
            EntityCow var4 = new EntityCow(this.world);
            var4.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
            var4.setHealth(this.getHealth());
            var4.renderYawOffset = this.renderYawOffset;
            if (this.hasCustomName()) {
               var4.setCustomNameTag(this.getCustomNameTag());
            }

            this.world.spawnEntityInWorld(var4);

            for(int var5 = 0; var5 < 5; ++var5) {
               this.world.spawnEntityInWorld(new EntityItem(this.world, this.posX, this.posY + (double)this.height, this.posZ, new ItemStack(Blocks.RED_MUSHROOM)));
            }

            var3.damageItem(1, var1);
            this.playSound(SoundEvents.ENTITY_MOOSHROOM_SHEAR, 1.0F, 1.0F);
         }

         return true;
      } else {
         return super.processInteract(var1, var2);
      }
   }

   public EntityMooshroom createChild(EntityAgeable var1) {
      return new EntityMooshroom(this.world);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_MUSHROOM_COW;
   }
}
