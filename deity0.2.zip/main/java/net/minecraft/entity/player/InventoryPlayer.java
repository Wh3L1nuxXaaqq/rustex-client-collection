package net.minecraft.entity.player;

import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.RecipeItemHelper;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ReportedException;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

public class InventoryPlayer implements IInventory {
   public final NonNullList<ItemStack> mainInventory;
   public final NonNullList<ItemStack> armorInventory;
   public final NonNullList<ItemStack> offHandInventory;
   private final List<NonNullList<ItemStack>> allInventories;
   public int currentItem;
   public EntityPlayer player;
   private ItemStack itemStack;
   private int field_194017_h;

   public InventoryPlayer(EntityPlayer var1) {
      this.mainInventory = NonNullList.<ItemStack>func_191197_a(36, ItemStack.field_190927_a);
      this.armorInventory = NonNullList.<ItemStack>func_191197_a(4, ItemStack.field_190927_a);
      this.offHandInventory = NonNullList.<ItemStack>func_191197_a(1, ItemStack.field_190927_a);
      this.allInventories = Arrays.asList(this.mainInventory, this.armorInventory, this.offHandInventory);
      this.itemStack = ItemStack.field_190927_a;
      this.player = var1;
   }

   public ItemStack getCurrentItem() {
      return isHotbar(this.currentItem) ? (ItemStack)this.mainInventory.get(this.currentItem) : ItemStack.field_190927_a;
   }

   public static int getHotbarSize() {
      return 9;
   }

   private boolean canMergeStacks(ItemStack var1, ItemStack var2) {
      return !var1.func_190926_b() && this.stackEqualExact(var1, var2) && var1.isStackable() && var1.func_190916_E() < var1.getMaxStackSize() && var1.func_190916_E() < this.getInventoryStackLimit();
   }

   private boolean stackEqualExact(ItemStack var1, ItemStack var2) {
      return var1.getItem() == var2.getItem() && (!var1.getHasSubtypes() || var1.getMetadata() == var2.getMetadata()) && ItemStack.areItemStackTagsEqual(var1, var2);
   }

   public int getFirstEmptyStack() {
      for(int var1 = 0; var1 < this.mainInventory.size(); ++var1) {
         if (((ItemStack)this.mainInventory.get(var1)).func_190926_b()) {
            return var1;
         }
      }

      return -1;
   }

   public void setPickedItemStack(ItemStack var1) {
      int var2 = this.getSlotFor(var1);
      if (isHotbar(var2)) {
         this.currentItem = var2;
      } else if (var2 == -1) {
         this.currentItem = this.getBestHotbarSlot();
         if (!((ItemStack)this.mainInventory.get(this.currentItem)).func_190926_b()) {
            int var3 = this.getFirstEmptyStack();
            if (var3 != -1) {
               this.mainInventory.set(var3, this.mainInventory.get(this.currentItem));
            }
         }

         this.mainInventory.set(this.currentItem, var1);
      } else {
         this.pickItem(var2);
      }

   }

   public void pickItem(int var1) {
      this.currentItem = this.getBestHotbarSlot();
      ItemStack var2 = this.mainInventory.get(this.currentItem);
      this.mainInventory.set(this.currentItem, this.mainInventory.get(var1));
      this.mainInventory.set(var1, var2);
   }

   public static boolean isHotbar(int var0) {
      return var0 >= 0 && var0 < 9;
   }

   public int getSlotFor(ItemStack var1) {
      for(int var2 = 0; var2 < this.mainInventory.size(); ++var2) {
         if (!((ItemStack)this.mainInventory.get(var2)).func_190926_b() && this.stackEqualExact(var1, this.mainInventory.get(var2))) {
            return var2;
         }
      }

      return -1;
   }

   public int func_194014_c(ItemStack var1) {
      for(int var2 = 0; var2 < this.mainInventory.size(); ++var2) {
         ItemStack var3 = this.mainInventory.get(var2);
         if (!((ItemStack)this.mainInventory.get(var2)).func_190926_b() && this.stackEqualExact(var1, this.mainInventory.get(var2)) && !((ItemStack)this.mainInventory.get(var2)).isItemDamaged() && !var3.isItemEnchanted() && !var3.hasDisplayName()) {
            return var2;
         }
      }

      return -1;
   }

   public int getBestHotbarSlot() {
      for(int var1 = 0; var1 < 9; ++var1) {
         int var2 = (this.currentItem + var1) % 9;
         if (((ItemStack)this.mainInventory.get(var2)).func_190926_b()) {
            return var2;
         }
      }

      for(int var3 = 0; var3 < 9; ++var3) {
         int var4 = (this.currentItem + var3) % 9;
         if (!((ItemStack)this.mainInventory.get(var4)).isItemEnchanted()) {
            return var4;
         }
      }

      return this.currentItem;
   }

   public void changeCurrentItem(int var1) {
      if (var1 > 0) {
         var1 = 1;
      }

      if (var1 < 0) {
         var1 = -1;
      }

      for(this.currentItem -= var1; this.currentItem < 0; this.currentItem += 9) {
      }

      while(this.currentItem >= 9) {
         this.currentItem -= 9;
      }

   }

   public int clearMatchingItems(@Nullable Item var1, int var2, int var3, @Nullable NBTTagCompound var4) {
      int var5 = 0;

      for(int var6 = 0; var6 < this.getSizeInventory(); ++var6) {
         ItemStack var7 = this.getStackInSlot(var6);
         if (!var7.func_190926_b() && (var1 == null || var7.getItem() == var1) && (var2 <= -1 || var7.getMetadata() == var2) && (var4 == null || NBTUtil.areNBTEquals(var4, var7.getTagCompound(), true))) {
            int var8 = var3 <= 0 ? var7.func_190916_E() : Math.min(var3 - var5, var7.func_190916_E());
            var5 += var8;
            if (var3 != 0) {
               var7.func_190918_g(var8);
               if (var7.func_190926_b()) {
                  this.setInventorySlotContents(var6, ItemStack.field_190927_a);
               }

               if (var3 > 0 && var5 >= var3) {
                  return var5;
               }
            }
         }
      }

      if (!this.itemStack.func_190926_b()) {
         if (var1 != null && this.itemStack.getItem() != var1) {
            return var5;
         }

         if (var2 > -1 && this.itemStack.getMetadata() != var2) {
            return var5;
         }

         if (var4 != null && !NBTUtil.areNBTEquals(var4, this.itemStack.getTagCompound(), true)) {
            return var5;
         }

         int var9 = var3 <= 0 ? this.itemStack.func_190916_E() : Math.min(var3 - var5, this.itemStack.func_190916_E());
         var5 += var9;
         if (var3 != 0) {
            this.itemStack.func_190918_g(var9);
            if (this.itemStack.func_190926_b()) {
               this.itemStack = ItemStack.field_190927_a;
            }

            if (var3 > 0 && var5 >= var3) {
               return var5;
            }
         }
      }

      return var5;
   }

   private int storePartialItemStack(ItemStack var1) {
      int var2 = this.storeItemStack(var1);
      if (var2 == -1) {
         var2 = this.getFirstEmptyStack();
      }

      return var2 == -1 ? var1.func_190916_E() : this.func_191973_d(var2, var1);
   }

   private int func_191973_d(int var1, ItemStack var2) {
      Item var3 = var2.getItem();
      int var4 = var2.func_190916_E();
      ItemStack var5 = this.getStackInSlot(var1);
      if (var5.func_190926_b()) {
         var5 = new ItemStack(var3, 0, var2.getMetadata());
         if (var2.hasTagCompound()) {
            var5.setTagCompound(var2.getTagCompound().copy());
         }

         this.setInventorySlotContents(var1, var5);
      }

      int var6 = var4;
      if (var4 > var5.getMaxStackSize() - var5.func_190916_E()) {
         var6 = var5.getMaxStackSize() - var5.func_190916_E();
      }

      if (var6 > this.getInventoryStackLimit() - var5.func_190916_E()) {
         var6 = this.getInventoryStackLimit() - var5.func_190916_E();
      }

      if (var6 == 0) {
         return var4;
      } else {
         var4 -= var6;
         var5.func_190917_f(var6);
         var5.func_190915_d(5);
         return var4;
      }
   }

   public int storeItemStack(ItemStack var1) {
      if (this.canMergeStacks(this.getStackInSlot(this.currentItem), var1)) {
         return this.currentItem;
      } else if (this.canMergeStacks(this.getStackInSlot(40), var1)) {
         return 40;
      } else {
         for(int var2 = 0; var2 < this.mainInventory.size(); ++var2) {
            if (this.canMergeStacks(this.mainInventory.get(var2), var1)) {
               return var2;
            }
         }

         return -1;
      }
   }

   public void decrementAnimations() {
      for(NonNullList var2 : this.allInventories) {
         for(int var3 = 0; var3 < var2.size(); ++var3) {
            if (!((ItemStack)var2.get(var3)).func_190926_b()) {
               ((ItemStack)var2.get(var3)).updateAnimation(this.player.world, this.player, var3, this.currentItem == var3);
            }
         }
      }

   }

   public boolean addItemStackToInventory(ItemStack var1) {
      return this.func_191971_c(-1, var1);
   }

   public boolean func_191971_c(int var1, final ItemStack var2) {
      if (var2.func_190926_b()) {
         return false;
      } else {
         try {
            if (var2.isItemDamaged()) {
               if (var1 == -1) {
                  var1 = this.getFirstEmptyStack();
               }

               if (var1 >= 0) {
                  this.mainInventory.set(var1, var2.copy());
                  ((ItemStack)this.mainInventory.get(var1)).func_190915_d(5);
                  var2.func_190920_e(0);
                  return true;
               } else if (this.player.capabilities.isCreativeMode) {
                  var2.func_190920_e(0);
                  return true;
               } else {
                  return false;
               }
            } else {
               int var3;
               do {
                  var3 = var2.func_190916_E();
                  if (var1 == -1) {
                     var2.func_190920_e(this.storePartialItemStack(var2));
                  } else {
                     var2.func_190920_e(this.func_191973_d(var1, var2));
                  }
               } while(!var2.func_190926_b() && var2.func_190916_E() < var3);

               if (var2.func_190916_E() == var3 && this.player.capabilities.isCreativeMode) {
                  var2.func_190920_e(0);
                  return true;
               } else {
                  return var2.func_190916_E() < var3;
               }
            }
         } catch (Throwable var6) {
            CrashReport var4 = CrashReport.makeCrashReport(var6, "Adding item to inventory");
            CrashReportCategory var5 = var4.makeCategory("Item being added");
            var5.addCrashSection("Item ID", Item.getIdFromItem(var2.getItem()));
            var5.addCrashSection("Item data", var2.getMetadata());
            var5.setDetail("Item name", new ICrashReportDetail<String>() {
               public String call() throws Exception {
                  return var2.getDisplayName();
               }
            });
            throw new ReportedException(var4);
         }
      }
   }

   public void func_191975_a(World var1, ItemStack var2) {
      if (!var1.isRemote) {
         while(!var2.func_190926_b()) {
            int var3 = this.storeItemStack(var2);
            if (var3 == -1) {
               var3 = this.getFirstEmptyStack();
            }

            if (var3 == -1) {
               this.player.dropItem(var2, false);
               break;
            }

            int var4 = var2.getMaxStackSize() - this.getStackInSlot(var3).func_190916_E();
            if (this.func_191971_c(var3, var2.splitStack(var4))) {
               ((EntityPlayerMP)this.player).connection.sendPacket(new SPacketSetSlot(-2, var3, this.getStackInSlot(var3)));
            }
         }
      }

   }

   public ItemStack decrStackSize(int var1, int var2) {
      NonNullList var3 = null;

      for(NonNullList var5 : this.allInventories) {
         if (var1 < var5.size()) {
            var3 = var5;
            break;
         }

         var1 -= var5.size();
      }

      return var3 != null && !((ItemStack)var3.get(var1)).func_190926_b() ? ItemStackHelper.getAndSplit(var3, var1, var2) : ItemStack.field_190927_a;
   }

   public void deleteStack(ItemStack var1) {
      for(NonNullList var3 : this.allInventories) {
         for(int var4 = 0; var4 < var3.size(); ++var4) {
            if (var3.get(var4) == var1) {
               var3.set(var4, ItemStack.field_190927_a);
               break;
            }
         }
      }

   }

   public ItemStack removeStackFromSlot(int var1) {
      NonNullList var2 = null;

      for(NonNullList var4 : this.allInventories) {
         if (var1 < var4.size()) {
            var2 = var4;
            break;
         }

         var1 -= var4.size();
      }

      if (var2 != null && !((ItemStack)var2.get(var1)).func_190926_b()) {
         ItemStack var5 = (ItemStack)var2.get(var1);
         var2.set(var1, ItemStack.field_190927_a);
         return var5;
      } else {
         return ItemStack.field_190927_a;
      }
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      NonNullList var3 = null;

      for(NonNullList var5 : this.allInventories) {
         if (var1 < var5.size()) {
            var3 = var5;
            break;
         }

         var1 -= var5.size();
      }

      if (var3 != null) {
         var3.set(var1, var2);
      }

   }

   public float getStrVsBlock(IBlockState var1) {
      float var2 = 1.0F;
      if (!((ItemStack)this.mainInventory.get(this.currentItem)).func_190926_b()) {
         var2 *= ((ItemStack)this.mainInventory.get(this.currentItem)).getStrVsBlock(var1);
      }

      return var2;
   }

   public NBTTagList writeToNBT(NBTTagList var1) {
      for(int var2 = 0; var2 < this.mainInventory.size(); ++var2) {
         if (!((ItemStack)this.mainInventory.get(var2)).func_190926_b()) {
            NBTTagCompound var3 = new NBTTagCompound();
            var3.setByte("Slot", (byte)var2);
            ((ItemStack)this.mainInventory.get(var2)).writeToNBT(var3);
            var1.appendTag(var3);
         }
      }

      for(int var4 = 0; var4 < this.armorInventory.size(); ++var4) {
         if (!((ItemStack)this.armorInventory.get(var4)).func_190926_b()) {
            NBTTagCompound var6 = new NBTTagCompound();
            var6.setByte("Slot", (byte)(var4 + 100));
            ((ItemStack)this.armorInventory.get(var4)).writeToNBT(var6);
            var1.appendTag(var6);
         }
      }

      for(int var5 = 0; var5 < this.offHandInventory.size(); ++var5) {
         if (!((ItemStack)this.offHandInventory.get(var5)).func_190926_b()) {
            NBTTagCompound var7 = new NBTTagCompound();
            var7.setByte("Slot", (byte)(var5 + 150));
            ((ItemStack)this.offHandInventory.get(var5)).writeToNBT(var7);
            var1.appendTag(var7);
         }
      }

      return var1;
   }

   public void readFromNBT(NBTTagList var1) {
      this.mainInventory.clear();
      this.armorInventory.clear();
      this.offHandInventory.clear();

      for(int var2 = 0; var2 < var1.tagCount(); ++var2) {
         NBTTagCompound var3 = var1.getCompoundTagAt(var2);
         int var4 = var3.getByte("Slot") & 255;
         ItemStack var5 = new ItemStack(var3);
         if (!var5.func_190926_b()) {
            if (var4 >= 0 && var4 < this.mainInventory.size()) {
               this.mainInventory.set(var4, var5);
            } else if (var4 >= 100 && var4 < this.armorInventory.size() + 100) {
               this.armorInventory.set(var4 - 100, var5);
            } else if (var4 >= 150 && var4 < this.offHandInventory.size() + 150) {
               this.offHandInventory.set(var4 - 150, var5);
            }
         }
      }

   }

   public int getSizeInventory() {
      return this.mainInventory.size() + this.armorInventory.size() + this.offHandInventory.size();
   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.mainInventory) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      for(ItemStack var5 : this.armorInventory) {
         if (!var5.func_190926_b()) {
            return false;
         }
      }

      for(ItemStack var6 : this.offHandInventory) {
         if (!var6.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int var1) {
      NonNullList var2 = null;

      for(NonNullList var4 : this.allInventories) {
         if (var1 < var4.size()) {
            var2 = var4;
            break;
         }

         var1 -= var4.size();
      }

      return var2 == null ? ItemStack.field_190927_a : (ItemStack)var2.get(var1);
   }

   public String getName() {
      return "container.inventory";
   }

   public boolean hasCustomName() {
      return false;
   }

   public ITextComponent getDisplayName() {
      return (ITextComponent)(this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]));
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean canHarvestBlock(IBlockState var1) {
      if (var1.getMaterial().isToolNotRequired()) {
         return true;
      } else {
         ItemStack var2 = this.getStackInSlot(this.currentItem);
         return !var2.func_190926_b() ? var2.canHarvestBlock(var1) : false;
      }
   }

   public ItemStack armorItemInSlot(int var1) {
      return this.armorInventory.get(var1);
   }

   public void damageArmor(float var1) {
      var1 /= 4.0F;
      if (var1 < 1.0F) {
         var1 = 1.0F;
      }

      for(int var2 = 0; var2 < this.armorInventory.size(); ++var2) {
         ItemStack var3 = this.armorInventory.get(var2);
         if (var3.getItem() instanceof ItemArmor) {
            var3.damageItem((int)var1, this.player);
         }
      }

   }

   public void dropAllItems() {
      for(List var2 : this.allInventories) {
         for(int var3 = 0; var3 < var2.size(); ++var3) {
            ItemStack var4 = (ItemStack)var2.get(var3);
            if (!var4.func_190926_b()) {
               this.player.dropItem(var4, true, false);
               var2.set(var3, ItemStack.field_190927_a);
            }
         }
      }

   }

   public void markDirty() {
      ++this.field_194017_h;
   }

   public int func_194015_p() {
      return this.field_194017_h;
   }

   public void setItemStack(ItemStack var1) {
      this.itemStack = var1;
   }

   public ItemStack getItemStack() {
      return this.itemStack;
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      if (this.player.isDead) {
         return false;
      } else {
         return var1.getDistanceSqToEntity(this.player) <= (double)64.0F;
      }
   }

   public boolean hasItemStack(ItemStack var1) {
      for(List var3 : this.allInventories) {
         for(Object var5_raw : var3) {
            ItemStack var5 = (ItemStack)var5_raw;
            if (!var5.func_190926_b() && var5.isItemEqual(var1)) {
               return true;
            }
         }
      }

      return false;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public void copyInventory(InventoryPlayer var1) {
      for(int var2 = 0; var2 < this.getSizeInventory(); ++var2) {
         this.setInventorySlotContents(var2, var1.getStackInSlot(var2));
      }

      this.currentItem = var1.currentItem;
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void clear() {
      for(List var2 : this.allInventories) {
         var2.clear();
      }

   }

   public void func_194016_a(RecipeItemHelper var1, boolean var2) {
      for(ItemStack var4 : this.mainInventory) {
         var1.func_194112_a(var4);
      }

      if (var2) {
         var1.func_194112_a(this.offHandInventory.get(0));
      }

   }
}
