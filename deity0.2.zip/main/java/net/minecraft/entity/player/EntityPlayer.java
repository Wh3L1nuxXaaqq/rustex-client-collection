package net.minecraft.entity.player;

import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.MultiPartEntityPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.CommandBlockBaseLogic;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.tileentity.TileEntityStructure;
import net.minecraft.util.CooldownTracker;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.FoodStats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.DataFixesManager;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameType;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.LockCode;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class EntityPlayer extends EntityLivingBase {
   private static final DataParameter<Float> ABSORPTION;
   private static final DataParameter<Integer> PLAYER_SCORE;
   protected static final DataParameter<Byte> PLAYER_MODEL_FLAG;
   protected static final DataParameter<Byte> MAIN_HAND;
   protected static final DataParameter<NBTTagCompound> field_192032_bt;
   protected static final DataParameter<NBTTagCompound> field_192033_bu;
   public InventoryPlayer inventory = new InventoryPlayer(this);
   protected InventoryEnderChest theInventoryEnderChest = new InventoryEnderChest();
   public Container inventoryContainer;
   public Container openContainer;
   protected FoodStats foodStats = new FoodStats();
   protected int flyToggleTimer;
   public float prevCameraYaw;
   public float cameraYaw;
   public int xpCooldown;
   public double prevChasingPosX;
   public double prevChasingPosY;
   public double prevChasingPosZ;
   public double chasingPosX;
   public double chasingPosY;
   public double chasingPosZ;
   protected boolean sleeping;
   public BlockPos bedLocation;
   private int sleepTimer;
   public float renderOffsetX;
   public float renderOffsetY;
   public float renderOffsetZ;
   private BlockPos spawnChunk;
   private boolean spawnForced;
   public PlayerCapabilities capabilities = new PlayerCapabilities();
   public int experienceLevel;
   public int experienceTotal;
   public float experience;
   protected int xpSeed;
   protected float speedInAir = 0.02F;
   private int lastXPSound;
   private final GameProfile gameProfile;
   private boolean hasReducedDebug;
   private ItemStack itemStackMainHand;
   private final CooldownTracker cooldownTracker;
   @Nullable
   public EntityFishHook fishEntity;

   protected CooldownTracker createCooldownTracker() {
      return new CooldownTracker();
   }

   public EntityPlayer(World var1, GameProfile var2) {
      super(var1);
      this.itemStackMainHand = ItemStack.field_190927_a;
      this.cooldownTracker = this.createCooldownTracker();
      this.setUniqueId(getUUID(var2));
      this.gameProfile = var2;
      this.inventoryContainer = new ContainerPlayer(this.inventory, !var1.isRemote, this);
      this.openContainer = this.inventoryContainer;
      BlockPos var3 = var1.getSpawnPoint();
      this.setLocationAndAngles((double)var3.getX() + (double)0.5F, (double)(var3.getY() + 1), (double)var3.getZ() + (double)0.5F, 0.0F, 0.0F);
      this.unused180 = 180.0F;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)1.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.1F);
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_SPEED);
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.LUCK);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(ABSORPTION, 0.0F);
      this.dataManager.register(PLAYER_SCORE, 0);
      this.dataManager.register(PLAYER_MODEL_FLAG, (byte)0);
      this.dataManager.register(MAIN_HAND, (byte)1);
      this.dataManager.register(field_192032_bt, new NBTTagCompound());
      this.dataManager.register(field_192033_bu, new NBTTagCompound());
   }

   public void onUpdate() {
      this.noClip = this.isSpectator();
      if (this.isSpectator()) {
         this.onGround = false;
      }

      if (this.xpCooldown > 0) {
         --this.xpCooldown;
      }

      if (this.isPlayerSleeping()) {
         ++this.sleepTimer;
         if (this.sleepTimer > 100) {
            this.sleepTimer = 100;
         }

         if (!this.world.isRemote) {
            if (!this.isInBed()) {
               this.wakeUpPlayer(true, true, false);
            } else if (this.world.isDaytime()) {
               this.wakeUpPlayer(false, true, true);
            }
         }
      } else if (this.sleepTimer > 0) {
         ++this.sleepTimer;
         if (this.sleepTimer >= 110) {
            this.sleepTimer = 0;
         }
      }

      super.onUpdate();
      if (!this.world.isRemote && this.openContainer != null && !this.openContainer.canInteractWith(this)) {
         this.closeScreen();
         this.openContainer = this.inventoryContainer;
      }

      if (this.isBurning() && this.capabilities.disableDamage) {
         this.extinguish();
      }

      this.updateCape();
      if (!this.world.isRemote) {
         this.foodStats.onUpdate(this);
         this.addStat(StatList.PLAY_ONE_MINUTE);
         if (this.isEntityAlive()) {
            this.addStat(StatList.TIME_SINCE_DEATH);
         }

         if (this.isSneaking()) {
            this.addStat(StatList.SNEAK_TIME);
         }
      }

      int var1 = 29999999;
      double var2 = MathHelper.clamp(this.posX, -2.9999999E7, 2.9999999E7);
      double var4 = MathHelper.clamp(this.posZ, -2.9999999E7, 2.9999999E7);
      if (var2 != this.posX || var4 != this.posZ) {
         this.setPosition(var2, this.posY, var4);
      }

      ++this.ticksSinceLastSwing;
      ItemStack var6 = this.getHeldItemMainhand();
      if (!ItemStack.areItemStacksEqual(this.itemStackMainHand, var6)) {
         if (!ItemStack.areItemsEqualIgnoreDurability(this.itemStackMainHand, var6)) {
            this.resetCooldown();
         }

         this.itemStackMainHand = var6.func_190926_b() ? ItemStack.field_190927_a : var6.copy();
      }

      this.cooldownTracker.tick();
      this.updateSize();
   }

   private void updateCape() {
      this.prevChasingPosX = this.chasingPosX;
      this.prevChasingPosY = this.chasingPosY;
      this.prevChasingPosZ = this.chasingPosZ;
      double var1 = this.posX - this.chasingPosX;
      double var3 = this.posY - this.chasingPosY;
      double var5 = this.posZ - this.chasingPosZ;
      double var7 = (double)10.0F;
      if (var1 > (double)10.0F) {
         this.chasingPosX = this.posX;
         this.prevChasingPosX = this.chasingPosX;
      }

      if (var5 > (double)10.0F) {
         this.chasingPosZ = this.posZ;
         this.prevChasingPosZ = this.chasingPosZ;
      }

      if (var3 > (double)10.0F) {
         this.chasingPosY = this.posY;
         this.prevChasingPosY = this.chasingPosY;
      }

      if (var1 < (double)-10.0F) {
         this.chasingPosX = this.posX;
         this.prevChasingPosX = this.chasingPosX;
      }

      if (var5 < (double)-10.0F) {
         this.chasingPosZ = this.posZ;
         this.prevChasingPosZ = this.chasingPosZ;
      }

      if (var3 < (double)-10.0F) {
         this.chasingPosY = this.posY;
         this.prevChasingPosY = this.chasingPosY;
      }

      this.chasingPosX += var1 * (double)0.25F;
      this.chasingPosZ += var5 * (double)0.25F;
      this.chasingPosY += var3 * (double)0.25F;
   }

   protected void updateSize() {
      float var1;
      float var2;
      if (this.isElytraFlying()) {
         var1 = 0.6F;
         var2 = 0.6F;
      } else if (this.isPlayerSleeping()) {
         var1 = 0.2F;
         var2 = 0.2F;
      } else if (this.isSneaking()) {
         var1 = 0.6F;
         var2 = 1.65F;
      } else {
         var1 = 0.6F;
         var2 = 1.8F;
      }

      if (var1 != this.width || var2 != this.height) {
         AxisAlignedBB var3 = this.getEntityBoundingBox();
         var3 = new AxisAlignedBB(var3.minX, var3.minY, var3.minZ, var3.minX + (double)var1, var3.minY + (double)var2, var3.minZ + (double)var1);
         if (!this.world.collidesWithAnyBlock(var3)) {
            this.setSize(var1, var2);
         }
      }

   }

   public int getMaxInPortalTime() {
      return this.capabilities.disableDamage ? 1 : 80;
   }

   protected SoundEvent getSwimSound() {
      return SoundEvents.ENTITY_PLAYER_SWIM;
   }

   protected SoundEvent getSplashSound() {
      return SoundEvents.ENTITY_PLAYER_SPLASH;
   }

   public int getPortalCooldown() {
      return 10;
   }

   public void playSound(SoundEvent var1, float var2, float var3) {
      this.world.playSound(this, this.posX, this.posY, this.posZ, var1, this.getSoundCategory(), var2, var3);
   }

   public SoundCategory getSoundCategory() {
      return SoundCategory.PLAYERS;
   }

   protected int func_190531_bD() {
      return 20;
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 9) {
         this.onItemUseFinish();
      } else if (var1 == 23) {
         this.hasReducedDebug = false;
      } else if (var1 == 22) {
         this.hasReducedDebug = true;
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   protected boolean isMovementBlocked() {
      return this.getHealth() <= 0.0F || this.isPlayerSleeping();
   }

   protected void closeScreen() {
      this.openContainer = this.inventoryContainer;
   }

   public void updateRidden() {
      if (!this.world.isRemote && this.isSneaking() && this.isRiding()) {
         this.dismountRidingEntity();
         this.setSneaking(false);
      } else {
         double var1 = this.posX;
         double var3 = this.posY;
         double var5 = this.posZ;
         float var7 = this.rotationYaw;
         float var8 = this.rotationPitch;
         super.updateRidden();
         this.prevCameraYaw = this.cameraYaw;
         this.cameraYaw = 0.0F;
         this.addMountedMovementStat(this.posX - var1, this.posY - var3, this.posZ - var5);
         if (this.getRidingEntity() instanceof EntityPig) {
            this.rotationPitch = var8;
            this.rotationYaw = var7;
            this.renderYawOffset = ((EntityPig)this.getRidingEntity()).renderYawOffset;
         }
      }

   }

   public void preparePlayerToSpawn() {
      this.setSize(0.6F, 1.8F);
      super.preparePlayerToSpawn();
      this.setHealth(this.getMaxHealth());
      this.deathTime = 0;
   }

   protected void updateEntityActionState() {
      super.updateEntityActionState();
      this.updateArmSwingProgress();
      this.rotationPitchHead = this.rotationPitch;
      this.rotationYawHead = this.rotationYaw;
   }

   public void onLivingUpdate() {
      if (this.flyToggleTimer > 0) {
         --this.flyToggleTimer;
      }

      if (this.world.getDifficulty() == EnumDifficulty.PEACEFUL && this.world.getGameRules().getBoolean("naturalRegeneration")) {
         if (this.getHealth() < this.getMaxHealth() && this.ticksExisted % 20 == 0) {
            this.heal(1.0F);
         }

         if (this.foodStats.needFood() && this.ticksExisted % 10 == 0) {
            this.foodStats.setFoodLevel(this.foodStats.getFoodLevel() + 1);
         }
      }

      this.inventory.decrementAnimations();
      this.prevCameraYaw = this.cameraYaw;
      super.onLivingUpdate();
      IAttributeInstance var1 = this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED);
      if (!this.world.isRemote) {
         var1.setBaseValue((double)this.capabilities.getWalkSpeed());
      }

      this.jumpMovementFactor = this.speedInAir;
      if (this.isSprinting()) {
         this.jumpMovementFactor = (float)((double)this.jumpMovementFactor + (double)this.speedInAir * 0.3);
      }

      this.setAIMoveSpeed((float)var1.getAttributeValue());
      float var2 = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      float var3 = (float)(Math.atan(-this.motionY * (double)0.2F) * (double)15.0F);
      if (var2 > 0.1F) {
         var2 = 0.1F;
      }

      if (!this.onGround || this.getHealth() <= 0.0F) {
         var2 = 0.0F;
      }

      if (this.onGround || this.getHealth() <= 0.0F) {
         var3 = 0.0F;
      }

      this.cameraYaw += (var2 - this.cameraYaw) * 0.4F;
      this.cameraPitch += (var3 - this.cameraPitch) * 0.8F;
      if (this.getHealth() > 0.0F && !this.isSpectator()) {
         AxisAlignedBB var4;
         if (this.isRiding() && !this.getRidingEntity().isDead) {
            var4 = this.getEntityBoundingBox().union(this.getRidingEntity().getEntityBoundingBox()).expand((double)1.0F, (double)0.0F, (double)1.0F);
         } else {
            var4 = this.getEntityBoundingBox().expand((double)1.0F, (double)0.5F, (double)1.0F);
         }

         List var5 = this.world.getEntitiesWithinAABBExcludingEntity(this, var4);

         for(int var6 = 0; var6 < var5.size(); ++var6) {
            Entity var7 = (Entity)var5.get(var6);
            if (!var7.isDead) {
               this.collideWithPlayer(var7);
            }
         }
      }

      this.func_192028_j(this.func_192023_dk());
      this.func_192028_j(this.func_192025_dl());
      if (!this.world.isRemote && (this.fallDistance > 0.5F || this.isInWater() || this.isRiding()) || this.capabilities.isFlying) {
         this.func_192030_dh();
      }

   }

   private void func_192028_j(@Nullable NBTTagCompound var1) {
      if (var1 != null && !var1.hasKey("Silent") || !var1.getBoolean("Silent")) {
         String var2 = var1.getString("id");
         if (var2.equals(EntityList.func_191306_a(EntityParrot.class).toString())) {
            EntityParrot.func_192005_a(this.world, this);
         }
      }

   }

   private void collideWithPlayer(Entity var1) {
      var1.onCollideWithPlayer(this);
   }

   public int getScore() {
      return (Integer)this.dataManager.get(PLAYER_SCORE);
   }

   public void setScore(int var1) {
      this.dataManager.set(PLAYER_SCORE, var1);
   }

   public void addScore(int var1) {
      int var2 = this.getScore();
      this.dataManager.set(PLAYER_SCORE, var2 + var1);
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      this.setSize(0.2F, 0.2F);
      this.setPosition(this.posX, this.posY, this.posZ);
      this.motionY = (double)0.1F;
      if ("Notch".equals(this.getName())) {
         this.dropItem(new ItemStack(Items.APPLE, 1), true, false);
      }

      if (!this.world.getGameRules().getBoolean("keepInventory") && !this.isSpectator()) {
         this.func_190776_cN();
         this.inventory.dropAllItems();
      }

      if (var1 != null) {
         this.motionX = (double)(-MathHelper.cos((this.attackedAtYaw + this.rotationYaw) * ((float)Math.PI / 180F)) * 0.1F);
         this.motionZ = (double)(-MathHelper.sin((this.attackedAtYaw + this.rotationYaw) * ((float)Math.PI / 180F)) * 0.1F);
      } else {
         this.motionX = (double)0.0F;
         this.motionZ = (double)0.0F;
      }

      this.addStat(StatList.DEATHS);
      this.takeStat(StatList.TIME_SINCE_DEATH);
      this.extinguish();
      this.setFlag(0, false);
   }

   protected void func_190776_cN() {
      for(int var1 = 0; var1 < this.inventory.getSizeInventory(); ++var1) {
         ItemStack var2 = this.inventory.getStackInSlot(var1);
         if (!var2.func_190926_b() && EnchantmentHelper.func_190939_c(var2)) {
            this.inventory.removeStackFromSlot(var1);
         }
      }

   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      if (var1 == DamageSource.onFire) {
         return SoundEvents.field_193806_fH;
      } else {
         return var1 == DamageSource.drown ? SoundEvents.field_193805_fG : SoundEvents.ENTITY_PLAYER_HURT;
      }
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_PLAYER_DEATH;
   }

   @Nullable
   public EntityItem dropItem(boolean var1) {
      return this.dropItem(this.inventory.decrStackSize(this.inventory.currentItem, var1 && !this.inventory.getCurrentItem().func_190926_b() ? this.inventory.getCurrentItem().func_190916_E() : 1), false, true);
   }

   @Nullable
   public EntityItem dropItem(ItemStack var1, boolean var2) {
      return this.dropItem(var1, false, var2);
   }

   @Nullable
   public EntityItem dropItem(ItemStack var1, boolean var2, boolean var3) {
      if (var1.func_190926_b()) {
         return null;
      } else {
         double var4 = this.posY - (double)0.3F + (double)this.getEyeHeight();
         EntityItem var6 = new EntityItem(this.world, this.posX, var4, this.posZ, var1);
         var6.setPickupDelay(40);
         if (var3) {
            var6.setThrower(this.getName());
         }

         if (var2) {
            float var7 = this.rand.nextFloat() * 0.5F;
            float var8 = this.rand.nextFloat() * ((float)Math.PI * 2F);
            var6.motionX = (double)(-MathHelper.sin(var8) * var7);
            var6.motionZ = (double)(MathHelper.cos(var8) * var7);
            var6.motionY = (double)0.2F;
         } else {
            float var9 = 0.3F;
            var6.motionX = (double)(-MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)) * MathHelper.cos(this.rotationPitch * ((float)Math.PI / 180F)) * var9);
            var6.motionZ = (double)(MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F)) * MathHelper.cos(this.rotationPitch * ((float)Math.PI / 180F)) * var9);
            var6.motionY = (double)(-MathHelper.sin(this.rotationPitch * ((float)Math.PI / 180F)) * var9 + 0.1F);
            float var12 = this.rand.nextFloat() * ((float)Math.PI * 2F);
            var9 = 0.02F * this.rand.nextFloat();
            var6.motionX += Math.cos((double)var12) * (double)var9;
            var6.motionY += (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F);
            var6.motionZ += Math.sin((double)var12) * (double)var9;
         }

         ItemStack var11 = this.dropItemAndGetStack(var6);
         if (var3) {
            if (!var11.func_190926_b()) {
               this.addStat(StatList.getDroppedObjectStats(var11.getItem()), var1.func_190916_E());
            }

            this.addStat(StatList.DROP);
         }

         return var6;
      }
   }

   protected ItemStack dropItemAndGetStack(EntityItem var1) {
      this.world.spawnEntityInWorld(var1);
      return var1.getEntityItem();
   }

   public float getDigSpeed(IBlockState var1) {
      float var2 = this.inventory.getStrVsBlock(var1);
      if (var2 > 1.0F) {
         int var3 = EnchantmentHelper.getEfficiencyModifier(this);
         ItemStack var4 = this.getHeldItemMainhand();
         if (var3 > 0 && !var4.func_190926_b()) {
            var2 += (float)(var3 * var3 + 1);
         }
      }

      if (this.isPotionActive(MobEffects.HASTE)) {
         var2 *= 1.0F + (float)(this.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
      }

      if (this.isPotionActive(MobEffects.MINING_FATIGUE)) {
         float var5;
         switch (this.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
            case 0:
               var5 = 0.3F;
               break;
            case 1:
               var5 = 0.09F;
               break;
            case 2:
               var5 = 0.0027F;
               break;
            case 3:
            default:
               var5 = 8.1E-4F;
         }

         var2 *= var5;
      }

      if (this.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier(this)) {
         var2 /= 5.0F;
      }

      if (!this.onGround) {
         var2 /= 5.0F;
      }

      return var2;
   }

   public boolean canHarvestBlock(IBlockState var1) {
      return this.inventory.canHarvestBlock(var1);
   }

   public static void registerFixesPlayer(DataFixer var0) {
      var0.registerWalker(FixTypes.PLAYER, new IDataWalker() {
         public NBTTagCompound process(IDataFixer var1, NBTTagCompound var2, int var3) {
            DataFixesManager.processInventory(var1, var2, var3, "Inventory");
            DataFixesManager.processInventory(var1, var2, var3, "EnderItems");
            if (var2.hasKey("ShoulderEntityLeft", 10)) {
               var2.setTag("ShoulderEntityLeft", var1.process(FixTypes.ENTITY, var2.getCompoundTag("ShoulderEntityLeft"), var3));
            }

            if (var2.hasKey("ShoulderEntityRight", 10)) {
               var2.setTag("ShoulderEntityRight", var1.process(FixTypes.ENTITY, var2.getCompoundTag("ShoulderEntityRight"), var3));
            }

            return var2;
         }
      });
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setUniqueId(getUUID(this.gameProfile));
      NBTTagList var2 = var1.getTagList("Inventory", 10);
      this.inventory.readFromNBT(var2);
      this.inventory.currentItem = var1.getInteger("SelectedItemSlot");
      this.sleeping = var1.getBoolean("Sleeping");
      this.sleepTimer = var1.getShort("SleepTimer");
      this.experience = var1.getFloat("XpP");
      this.experienceLevel = var1.getInteger("XpLevel");
      this.experienceTotal = var1.getInteger("XpTotal");
      this.xpSeed = var1.getInteger("XpSeed");
      if (this.xpSeed == 0) {
         this.xpSeed = this.rand.nextInt();
      }

      this.setScore(var1.getInteger("Score"));
      if (this.sleeping) {
         this.bedLocation = new BlockPos(this);
         this.wakeUpPlayer(true, true, false);
      }

      if (var1.hasKey("SpawnX", 99) && var1.hasKey("SpawnY", 99) && var1.hasKey("SpawnZ", 99)) {
         this.spawnChunk = new BlockPos(var1.getInteger("SpawnX"), var1.getInteger("SpawnY"), var1.getInteger("SpawnZ"));
         this.spawnForced = var1.getBoolean("SpawnForced");
      }

      this.foodStats.readNBT(var1);
      this.capabilities.readCapabilitiesFromNBT(var1);
      if (var1.hasKey("EnderItems", 9)) {
         NBTTagList var3 = var1.getTagList("EnderItems", 10);
         this.theInventoryEnderChest.loadInventoryFromNBT(var3);
      }

      if (var1.hasKey("ShoulderEntityLeft", 10)) {
         this.func_192029_h(var1.getCompoundTag("ShoulderEntityLeft"));
      }

      if (var1.hasKey("ShoulderEntityRight", 10)) {
         this.func_192031_i(var1.getCompoundTag("ShoulderEntityRight"));
      }

   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("DataVersion", 1343);
      var1.setTag("Inventory", this.inventory.writeToNBT(new NBTTagList()));
      var1.setInteger("SelectedItemSlot", this.inventory.currentItem);
      var1.setBoolean("Sleeping", this.sleeping);
      var1.setShort("SleepTimer", (short)this.sleepTimer);
      var1.setFloat("XpP", this.experience);
      var1.setInteger("XpLevel", this.experienceLevel);
      var1.setInteger("XpTotal", this.experienceTotal);
      var1.setInteger("XpSeed", this.xpSeed);
      var1.setInteger("Score", this.getScore());
      if (this.spawnChunk != null) {
         var1.setInteger("SpawnX", this.spawnChunk.getX());
         var1.setInteger("SpawnY", this.spawnChunk.getY());
         var1.setInteger("SpawnZ", this.spawnChunk.getZ());
         var1.setBoolean("SpawnForced", this.spawnForced);
      }

      this.foodStats.writeNBT(var1);
      this.capabilities.writeCapabilitiesToNBT(var1);
      var1.setTag("EnderItems", this.theInventoryEnderChest.saveInventoryToNBT());
      if (!this.func_192023_dk().hasNoTags()) {
         var1.setTag("ShoulderEntityLeft", this.func_192023_dk());
      }

      if (!this.func_192025_dl().hasNoTags()) {
         var1.setTag("ShoulderEntityRight", this.func_192025_dl());
      }

   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (this.isEntityInvulnerable(var1)) {
         return false;
      } else if (this.capabilities.disableDamage && !var1.canHarmInCreative()) {
         return false;
      } else {
         this.entityAge = 0;
         if (this.getHealth() <= 0.0F) {
            return false;
         } else {
            if (this.isPlayerSleeping() && !this.world.isRemote) {
               this.wakeUpPlayer(true, true, false);
            }

            this.func_192030_dh();
            if (var1.isDifficultyScaled()) {
               if (this.world.getDifficulty() == EnumDifficulty.PEACEFUL) {
                  var2 = 0.0F;
               }

               if (this.world.getDifficulty() == EnumDifficulty.EASY) {
                  var2 = Math.min(var2 / 2.0F + 1.0F, var2);
               }

               if (this.world.getDifficulty() == EnumDifficulty.HARD) {
                  var2 = var2 * 3.0F / 2.0F;
               }
            }

            return var2 == 0.0F ? false : super.attackEntityFrom(var1, var2);
         }
      }
   }

   protected void func_190629_c(EntityLivingBase var1) {
      super.func_190629_c(var1);
      if (var1.getHeldItemMainhand().getItem() instanceof ItemAxe) {
         this.func_190777_m(true);
      }

   }

   public boolean canAttackPlayer(EntityPlayer var1) {
      Team var2 = this.getTeam();
      Team var3 = var1.getTeam();
      if (var2 == null) {
         return true;
      } else {
         return !var2.isSameTeam(var3) ? true : var2.getAllowFriendlyFire();
      }
   }

   protected void damageArmor(float var1) {
      this.inventory.damageArmor(var1);
   }

   protected void damageShield(float var1) {
      if (var1 >= 3.0F && this.activeItemStack.getItem() == Items.SHIELD) {
         int var2 = 1 + MathHelper.floor(var1);
         this.activeItemStack.damageItem(var2, this);
         if (this.activeItemStack.func_190926_b()) {
            EnumHand var3 = this.getActiveHand();
            if (var3 == EnumHand.MAIN_HAND) {
               this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, ItemStack.field_190927_a);
            } else {
               this.setItemStackToSlot(EntityEquipmentSlot.OFFHAND, ItemStack.field_190927_a);
            }

            this.activeItemStack = ItemStack.field_190927_a;
            this.playSound(SoundEvents.ITEM_SHIELD_BREAK, 0.8F, 0.8F + this.world.rand.nextFloat() * 0.4F);
         }
      }

   }

   public float getArmorVisibility() {
      int var1 = 0;

      for(ItemStack var3 : this.inventory.armorInventory) {
         if (!var3.func_190926_b()) {
            ++var1;
         }
      }

      return (float)var1 / (float)this.inventory.armorInventory.size();
   }

   protected void damageEntity(DamageSource var1, float var2) {
      if (!this.isEntityInvulnerable(var1)) {
         var2 = this.applyArmorCalculations(var1, var2);
         var2 = this.applyPotionDamageCalculations(var1, var2);
         float var3 = var2;
         var2 = Math.max(var2 - this.getAbsorptionAmount(), 0.0F);
         this.setAbsorptionAmount(this.getAbsorptionAmount() - (var3 - var2));
         if (var2 != 0.0F) {
            this.addExhaustion(var1.getHungerDamage());
            float var4 = this.getHealth();
            this.setHealth(this.getHealth() - var2);
            this.getCombatTracker().trackDamage(var1, var4, var2);
            if (var2 < 3.4028235E37F) {
               this.addStat(StatList.DAMAGE_TAKEN, Math.round(var2 * 10.0F));
            }
         }
      }

   }

   public void openEditSign(TileEntitySign var1) {
   }

   public void displayGuiEditCommandCart(CommandBlockBaseLogic var1) {
   }

   public void displayGuiCommandBlock(TileEntityCommandBlock var1) {
   }

   public void openEditStructure(TileEntityStructure var1) {
   }

   public void displayVillagerTradeGui(IMerchant var1) {
   }

   public void displayGUIChest(IInventory var1) {
   }

   public void openGuiHorseInventory(AbstractHorse var1, IInventory var2) {
   }

   public void displayGui(IInteractionObject var1) {
   }

   public void openBook(ItemStack var1, EnumHand var2) {
   }

   public EnumActionResult func_190775_a(Entity var1, EnumHand var2) {
      if (this.isSpectator()) {
         if (var1 instanceof IInventory) {
            this.displayGUIChest((IInventory)var1);
         }

         return EnumActionResult.PASS;
      } else {
         ItemStack var3 = this.getHeldItem(var2);
         ItemStack var4 = var3.func_190926_b() ? ItemStack.field_190927_a : var3.copy();
         if (var1.processInitialInteract(this, var2)) {
            if (this.capabilities.isCreativeMode && var3 == this.getHeldItem(var2) && var3.func_190916_E() < var4.func_190916_E()) {
               var3.func_190920_e(var4.func_190916_E());
            }

            return EnumActionResult.SUCCESS;
         } else {
            if (!var3.func_190926_b() && var1 instanceof EntityLivingBase) {
               if (this.capabilities.isCreativeMode) {
                  var3 = var4;
               }

               if (var3.interactWithEntity(this, (EntityLivingBase)var1, var2)) {
                  if (var3.func_190926_b() && !this.capabilities.isCreativeMode) {
                     this.setHeldItem(var2, ItemStack.field_190927_a);
                  }

                  return EnumActionResult.SUCCESS;
               }
            }

            return EnumActionResult.PASS;
         }
      }
   }

   public double getYOffset() {
      return -0.35;
   }

   public void dismountRidingEntity() {
      super.dismountRidingEntity();
      this.rideCooldown = 0;
   }

   public void attackTargetEntityWithCurrentItem(Entity var1) {
      if (var1.canBeAttackedWithItem() && !var1.hitByEntity(this)) {
         float var2 = (float)this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
         float var3;
         if (var1 instanceof EntityLivingBase) {
            var3 = EnchantmentHelper.getModifierForCreature(this.getHeldItemMainhand(), ((EntityLivingBase)var1).getCreatureAttribute());
         } else {
            var3 = EnchantmentHelper.getModifierForCreature(this.getHeldItemMainhand(), EnumCreatureAttribute.UNDEFINED);
         }

         float var4 = this.getCooledAttackStrength(0.5F);
         var2 *= 0.2F + var4 * var4 * 0.8F;
         var3 *= var4;
         this.resetCooldown();
         if (var2 > 0.0F || var3 > 0.0F) {
            boolean var5 = var4 > 0.9F;
            boolean var6 = false;
            int var7 = 0;
            var7 += EnchantmentHelper.getKnockbackModifier(this);
            if (this.isSprinting() && var5) {
               this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, this.getSoundCategory(), 1.0F, 1.0F);
               ++var7;
               var6 = true;
            }

            boolean var8 = var5 && this.fallDistance > 0.0F && !this.onGround && !this.isOnLadder() && !this.isInWater() && !this.isPotionActive(MobEffects.BLINDNESS) && !this.isRiding() && var1 instanceof EntityLivingBase;
            var8 = var8 && !this.isSprinting();
            if (var8) {
               var2 *= 1.5F;
            }

            var2 += var3;
            boolean var9 = false;
            double var10 = (double)(this.distanceWalkedModified - this.prevDistanceWalkedModified);
            if (var5 && !var8 && !var6 && this.onGround && var10 < (double)this.getAIMoveSpeed()) {
               ItemStack var12 = this.getHeldItem(EnumHand.MAIN_HAND);
               if (var12.getItem() instanceof ItemSword) {
                  var9 = true;
               }
            }

            float var31 = 0.0F;
            boolean var13 = false;
            int var14 = EnchantmentHelper.getFireAspectModifier(this);
            if (var1 instanceof EntityLivingBase) {
               var31 = ((EntityLivingBase)var1).getHealth();
               if (var14 > 0 && !var1.isBurning()) {
                  var13 = true;
                  var1.setFire(1);
               }
            }

            double var15 = var1.motionX;
            double var17 = var1.motionY;
            double var19 = var1.motionZ;
            boolean var21 = var1.attackEntityFrom(DamageSource.causePlayerDamage(this), var2);
            if (var21) {
               if (var7 > 0) {
                  if (var1 instanceof EntityLivingBase) {
                     ((EntityLivingBase)var1).knockBack(this, (float)var7 * 0.5F, (double)MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)), (double)(-MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F))));
                  } else {
                     var1.addVelocity((double)(-MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)) * (float)var7 * 0.5F), 0.1, (double)(MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F)) * (float)var7 * 0.5F));
                  }

                  this.motionX *= 0.6;
                  this.motionZ *= 0.6;
                  this.setSprinting(false);
               }

               if (var9) {
                  float var22 = 1.0F + EnchantmentHelper.func_191527_a(this) * var2;

                  for(EntityLivingBase var24 : this.world.getEntitiesWithinAABB(EntityLivingBase.class, var1.getEntityBoundingBox().expand((double)1.0F, (double)0.25F, (double)1.0F))) {
                     if (var24 != this && var24 != var1 && !this.isOnSameTeam(var24) && this.getDistanceSqToEntity(var24) < (double)9.0F) {
                        var24.knockBack(this, 0.4F, (double)MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)), (double)(-MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F))));
                        var24.attackEntityFrom(DamageSource.causePlayerDamage(this), var22);
                     }
                  }

                  this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, this.getSoundCategory(), 1.0F, 1.0F);
                  this.spawnSweepParticles();
               }

               if (var1 instanceof EntityPlayerMP && var1.velocityChanged) {
                  ((EntityPlayerMP)var1).connection.sendPacket(new SPacketEntityVelocity(var1));
                  var1.velocityChanged = false;
                  var1.motionX = var15;
                  var1.motionY = var17;
                  var1.motionZ = var19;
               }

               if (var8) {
                  this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, this.getSoundCategory(), 1.0F, 1.0F);
                  this.onCriticalHit(var1);
               }

               if (!var8 && !var9) {
                  if (var5) {
                     this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, this.getSoundCategory(), 1.0F, 1.0F);
                  } else {
                     this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_WEAK, this.getSoundCategory(), 1.0F, 1.0F);
                  }
               }

               if (var3 > 0.0F) {
                  this.onEnchantmentCritical(var1);
               }

               this.setLastAttacker(var1);
               if (var1 instanceof EntityLivingBase) {
                  EnchantmentHelper.applyThornEnchantments((EntityLivingBase)var1, this);
               }

               EnchantmentHelper.applyArthropodEnchantments(this, var1);
               ItemStack var32 = this.getHeldItemMainhand();
               Object var33 = var1;
               if (var1 instanceof MultiPartEntityPart) {
                  IEntityMultiPart var34 = ((MultiPartEntityPart)var1).entityDragonObj;
                  if (var34 instanceof EntityLivingBase) {
                     var33 = (EntityLivingBase)var34;
                  }
               }

               if (!var32.func_190926_b() && var33 instanceof EntityLivingBase) {
                  var32.hitEntity((EntityLivingBase)var33, this);
                  if (var32.func_190926_b()) {
                     this.setHeldItem(EnumHand.MAIN_HAND, ItemStack.field_190927_a);
                  }
               }

               if (var1 instanceof EntityLivingBase) {
                  float var35 = var31 - ((EntityLivingBase)var1).getHealth();
                  this.addStat(StatList.DAMAGE_DEALT, Math.round(var35 * 10.0F));
                  if (var14 > 0) {
                     var1.setFire(var14 * 4);
                  }

                  if (this.world instanceof WorldServer && var35 > 2.0F) {
                     int var25 = (int)((double)var35 * (double)0.5F);
                     ((WorldServer)this.world).spawnParticle(EnumParticleTypes.DAMAGE_INDICATOR, var1.posX, var1.posY + (double)(var1.height * 0.5F), var1.posZ, var25, 0.1, (double)0.0F, 0.1, 0.2);
                  }
               }

               this.addExhaustion(0.1F);
            } else {
               this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_NODAMAGE, this.getSoundCategory(), 1.0F, 1.0F);
               if (var13) {
                  var1.extinguish();
               }
            }
         }
      }

   }

   public void func_190777_m(boolean var1) {
      float var2 = 0.25F + (float)EnchantmentHelper.getEfficiencyModifier(this) * 0.05F;
      if (var1) {
         var2 += 0.75F;
      }

      if (this.rand.nextFloat() < var2) {
         this.getCooldownTracker().setCooldown(Items.SHIELD, 100);
         this.resetActiveHand();
         this.world.setEntityState(this, (byte)30);
      }

   }

   public void onCriticalHit(Entity var1) {
   }

   public void onEnchantmentCritical(Entity var1) {
   }

   public void spawnSweepParticles() {
      double var1 = (double)(-MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)));
      double var3 = (double)MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F));
      if (this.world instanceof WorldServer) {
         ((WorldServer)this.world).spawnParticle(EnumParticleTypes.SWEEP_ATTACK, this.posX + var1, this.posY + (double)this.height * (double)0.5F, this.posZ + var3, 0, var1, (double)0.0F, var3, (double)0.0F);
      }

   }

   public void respawnPlayer() {
   }

   public void setDead() {
      super.setDead();
      this.inventoryContainer.onContainerClosed(this);
      if (this.openContainer != null) {
         this.openContainer.onContainerClosed(this);
      }

   }

   public boolean isEntityInsideOpaqueBlock() {
      return !this.sleeping && super.isEntityInsideOpaqueBlock();
   }

   public boolean isUser() {
      return false;
   }

   public GameProfile getGameProfile() {
      return this.gameProfile;
   }

   public SleepResult trySleep(BlockPos var1) {
      EnumFacing var2 = (EnumFacing)this.world.getBlockState(var1).getValue(BlockHorizontal.FACING);
      if (!this.world.isRemote) {
         if (this.isPlayerSleeping() || !this.isEntityAlive()) {
            return EntityPlayer.SleepResult.OTHER_PROBLEM;
         }

         if (!this.world.provider.isSurfaceWorld()) {
            return EntityPlayer.SleepResult.NOT_POSSIBLE_HERE;
         }

         if (this.world.isDaytime()) {
            return EntityPlayer.SleepResult.NOT_POSSIBLE_NOW;
         }

         if (!this.func_190774_a(var1, var2)) {
            return EntityPlayer.SleepResult.TOO_FAR_AWAY;
         }

         double var3 = (double)8.0F;
         double var5 = (double)5.0F;
         List var7 = this.world.getEntitiesWithinAABB(EntityMob.class, new AxisAlignedBB((double)var1.getX() - (double)8.0F, (double)var1.getY() - (double)5.0F, (double)var1.getZ() - (double)8.0F, (double)var1.getX() + (double)8.0F, (double)var1.getY() + (double)5.0F, (double)var1.getZ() + (double)8.0F), new SleepEnemyPredicate(this));
         if (!var7.isEmpty()) {
            return EntityPlayer.SleepResult.NOT_SAFE;
         }
      }

      if (this.isRiding()) {
         this.dismountRidingEntity();
      }

      this.func_192030_dh();
      this.setSize(0.2F, 0.2F);
      if (this.world.isBlockLoaded(var1)) {
         float var8 = 0.5F + (float)var2.getFrontOffsetX() * 0.4F;
         float var4 = 0.5F + (float)var2.getFrontOffsetZ() * 0.4F;
         this.setRenderOffsetForSleep(var2);
         this.setPosition((double)((float)var1.getX() + var8), (double)((float)var1.getY() + 0.6875F), (double)((float)var1.getZ() + var4));
      } else {
         this.setPosition((double)((float)var1.getX() + 0.5F), (double)((float)var1.getY() + 0.6875F), (double)((float)var1.getZ() + 0.5F));
      }

      this.sleeping = true;
      this.sleepTimer = 0;
      this.bedLocation = var1;
      this.motionX = (double)0.0F;
      this.motionY = (double)0.0F;
      this.motionZ = (double)0.0F;
      if (!this.world.isRemote) {
         this.world.updateAllPlayersSleepingFlag();
      }

      return EntityPlayer.SleepResult.OK;
   }

   private boolean func_190774_a(BlockPos var1, EnumFacing var2) {
      if (Math.abs(this.posX - (double)var1.getX()) <= (double)3.0F && Math.abs(this.posY - (double)var1.getY()) <= (double)2.0F && Math.abs(this.posZ - (double)var1.getZ()) <= (double)3.0F) {
         return true;
      } else {
         BlockPos var3 = var1.offset(var2.getOpposite());
         return Math.abs(this.posX - (double)var3.getX()) <= (double)3.0F && Math.abs(this.posY - (double)var3.getY()) <= (double)2.0F && Math.abs(this.posZ - (double)var3.getZ()) <= (double)3.0F;
      }
   }

   private void setRenderOffsetForSleep(EnumFacing var1) {
      this.renderOffsetX = -1.8F * (float)var1.getFrontOffsetX();
      this.renderOffsetZ = -1.8F * (float)var1.getFrontOffsetZ();
   }

   public void wakeUpPlayer(boolean var1, boolean var2, boolean var3) {
      this.setSize(0.6F, 1.8F);
      IBlockState var4 = this.world.getBlockState(this.bedLocation);
      if (this.bedLocation != null && var4.getBlock() == Blocks.BED) {
         this.world.setBlockState(this.bedLocation, var4.withProperty(BlockBed.OCCUPIED, false), 4);
         BlockPos var5 = BlockBed.getSafeExitLocation(this.world, this.bedLocation, 0);
         if (var5 == null) {
            var5 = this.bedLocation.up();
         }

         this.setPosition((double)((float)var5.getX() + 0.5F), (double)((float)var5.getY() + 0.1F), (double)((float)var5.getZ() + 0.5F));
      }

      this.sleeping = false;
      if (!this.world.isRemote && var2) {
         this.world.updateAllPlayersSleepingFlag();
      }

      this.sleepTimer = var1 ? 0 : 100;
      if (var3) {
         this.setSpawnPoint(this.bedLocation, false);
      }

   }

   private boolean isInBed() {
      return this.world.getBlockState(this.bedLocation).getBlock() == Blocks.BED;
   }

   @Nullable
   public static BlockPos getBedSpawnLocation(World var0, BlockPos var1, boolean var2) {
      Block var3 = var0.getBlockState(var1).getBlock();
      if (var3 != Blocks.BED) {
         if (!var2) {
            return null;
         } else {
            boolean var4 = var3.canSpawnInBlock();
            boolean var5 = var0.getBlockState(var1.up()).getBlock().canSpawnInBlock();
            return var4 && var5 ? var1 : null;
         }
      } else {
         return BlockBed.getSafeExitLocation(var0, var1, 0);
      }
   }

   public float getBedOrientationInDegrees() {
      if (this.bedLocation != null) {
         EnumFacing var1 = (EnumFacing)this.world.getBlockState(this.bedLocation).getValue(BlockHorizontal.FACING);
         switch (var1) {
            case SOUTH:
               return 90.0F;
            case WEST:
               return 0.0F;
            case NORTH:
               return 270.0F;
            case EAST:
               return 180.0F;
         }
      }

      return 0.0F;
   }

   public boolean isPlayerSleeping() {
      return this.sleeping;
   }

   public boolean isPlayerFullyAsleep() {
      return this.sleeping && this.sleepTimer >= 100;
   }

   public int getSleepTimer() {
      return this.sleepTimer;
   }

   public void addChatComponentMessage(ITextComponent var1, boolean var2) {
   }

   public BlockPos getBedLocation() {
      return this.spawnChunk;
   }

   public boolean isSpawnForced() {
      return this.spawnForced;
   }

   public void setSpawnPoint(BlockPos var1, boolean var2) {
      if (var1 != null) {
         this.spawnChunk = var1;
         this.spawnForced = var2;
      } else {
         this.spawnChunk = null;
         this.spawnForced = false;
      }

   }

   public void addStat(StatBase var1) {
      this.addStat(var1, 1);
   }

   public void addStat(StatBase var1, int var2) {
   }

   public void takeStat(StatBase var1) {
   }

   public void func_192021_a(List<IRecipe> var1) {
   }

   public void func_193102_a(ResourceLocation[] var1) {
   }

   public void func_192022_b(List<IRecipe> var1) {
   }

   public void jump() {
      super.jump();
      this.addStat(StatList.JUMP);
      if (this.isSprinting()) {
         this.addExhaustion(0.2F);
      } else {
         this.addExhaustion(0.05F);
      }

   }

   public void func_191986_a(float var1, float var2, float var3) {
      double var4 = this.posX;
      double var6 = this.posY;
      double var8 = this.posZ;
      if (this.capabilities.isFlying && !this.isRiding()) {
         double var10 = this.motionY;
         float var12 = this.jumpMovementFactor;
         this.jumpMovementFactor = this.capabilities.getFlySpeed() * (float)(this.isSprinting() ? 2 : 1);
         super.func_191986_a(var1, var2, var3);
         this.motionY = var10 * 0.6;
         this.jumpMovementFactor = var12;
         this.fallDistance = 0.0F;
         this.setFlag(7, false);
      } else {
         super.func_191986_a(var1, var2, var3);
      }

      this.addMovementStat(this.posX - var4, this.posY - var6, this.posZ - var8);
   }

   public float getAIMoveSpeed() {
      return (float)this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue();
   }

   public void addMovementStat(double var1, double var3, double var5) {
      if (!this.isRiding()) {
         if (this.isInsideOfMaterial(Material.WATER)) {
            int var7 = Math.round(MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            if (var7 > 0) {
               this.addStat(StatList.DIVE_ONE_CM, var7);
               this.addExhaustion(0.01F * (float)var7 * 0.01F);
            }
         } else if (this.isInWater()) {
            int var8 = Math.round(MathHelper.sqrt(var1 * var1 + var5 * var5) * 100.0F);
            if (var8 > 0) {
               this.addStat(StatList.SWIM_ONE_CM, var8);
               this.addExhaustion(0.01F * (float)var8 * 0.01F);
            }
         } else if (this.isOnLadder()) {
            if (var3 > (double)0.0F) {
               this.addStat(StatList.CLIMB_ONE_CM, (int)Math.round(var3 * (double)100.0F));
            }
         } else if (this.onGround) {
            int var9 = Math.round(MathHelper.sqrt(var1 * var1 + var5 * var5) * 100.0F);
            if (var9 > 0) {
               if (this.isSprinting()) {
                  this.addStat(StatList.SPRINT_ONE_CM, var9);
                  this.addExhaustion(0.1F * (float)var9 * 0.01F);
               } else if (this.isSneaking()) {
                  this.addStat(StatList.CROUCH_ONE_CM, var9);
                  this.addExhaustion(0.0F * (float)var9 * 0.01F);
               } else {
                  this.addStat(StatList.WALK_ONE_CM, var9);
                  this.addExhaustion(0.0F * (float)var9 * 0.01F);
               }
            }
         } else if (this.isElytraFlying()) {
            int var10 = Math.round(MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            this.addStat(StatList.AVIATE_ONE_CM, var10);
         } else {
            int var11 = Math.round(MathHelper.sqrt(var1 * var1 + var5 * var5) * 100.0F);
            if (var11 > 25) {
               this.addStat(StatList.FLY_ONE_CM, var11);
            }
         }
      }

   }

   private void addMountedMovementStat(double var1, double var3, double var5) {
      if (this.isRiding()) {
         int var7 = Math.round(MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
         if (var7 > 0) {
            if (this.getRidingEntity() instanceof EntityMinecart) {
               this.addStat(StatList.MINECART_ONE_CM, var7);
            } else if (this.getRidingEntity() instanceof EntityBoat) {
               this.addStat(StatList.BOAT_ONE_CM, var7);
            } else if (this.getRidingEntity() instanceof EntityPig) {
               this.addStat(StatList.PIG_ONE_CM, var7);
            } else if (this.getRidingEntity() instanceof AbstractHorse) {
               this.addStat(StatList.HORSE_ONE_CM, var7);
            }
         }
      }

   }

   public void fall(float var1, float var2) {
      if (!this.capabilities.allowFlying) {
         if (var1 >= 2.0F) {
            this.addStat(StatList.FALL_ONE_CM, (int)Math.round((double)var1 * (double)100.0F));
         }

         super.fall(var1, var2);
      }

   }

   protected void resetHeight() {
      if (!this.isSpectator()) {
         super.resetHeight();
      }

   }

   protected SoundEvent getFallSound(int var1) {
      return var1 > 4 ? SoundEvents.ENTITY_PLAYER_BIG_FALL : SoundEvents.ENTITY_PLAYER_SMALL_FALL;
   }

   public void onKillEntity(EntityLivingBase var1) {
      EntityList.EntityEggInfo var2 = (EntityList.EntityEggInfo)EntityList.ENTITY_EGGS.get(EntityList.func_191301_a(var1));
      if (var2 != null) {
         this.addStat(var2.killEntityStat);
      }

   }

   public void setInWeb() {
      if (!this.capabilities.isFlying) {
         super.setInWeb();
      }

   }

   public void addExperience(int var1) {
      this.addScore(var1);
      int var2 = Integer.MAX_VALUE - this.experienceTotal;
      if (var1 > var2) {
         var1 = var2;
      }

      this.experience += (float)var1 / (float)this.xpBarCap();

      for(this.experienceTotal += var1; this.experience >= 1.0F; this.experience /= (float)this.xpBarCap()) {
         this.experience = (this.experience - 1.0F) * (float)this.xpBarCap();
         this.addExperienceLevel(1);
      }

   }

   public int getXPSeed() {
      return this.xpSeed;
   }

   public void func_192024_a(ItemStack var1, int var2) {
      this.experienceLevel -= var2;
      if (this.experienceLevel < 0) {
         this.experienceLevel = 0;
         this.experience = 0.0F;
         this.experienceTotal = 0;
      }

      this.xpSeed = this.rand.nextInt();
   }

   public void addExperienceLevel(int var1) {
      this.experienceLevel += var1;
      if (this.experienceLevel < 0) {
         this.experienceLevel = 0;
         this.experience = 0.0F;
         this.experienceTotal = 0;
      }

      if (var1 > 0 && this.experienceLevel % 5 == 0 && (float)this.lastXPSound < (float)this.ticksExisted - 100.0F) {
         float var2 = this.experienceLevel > 30 ? 1.0F : (float)this.experienceLevel / 30.0F;
         this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_PLAYER_LEVELUP, this.getSoundCategory(), var2 * 0.75F, 1.0F);
         this.lastXPSound = this.ticksExisted;
      }

   }

   public int xpBarCap() {
      if (this.experienceLevel >= 30) {
         return 112 + (this.experienceLevel - 30) * 9;
      } else {
         return this.experienceLevel >= 15 ? 37 + (this.experienceLevel - 15) * 5 : 7 + this.experienceLevel * 2;
      }
   }

   public void addExhaustion(float var1) {
      if (!this.capabilities.disableDamage && !this.world.isRemote) {
         this.foodStats.addExhaustion(var1);
      }

   }

   public FoodStats getFoodStats() {
      return this.foodStats;
   }

   public boolean canEat(boolean var1) {
      return (var1 || this.foodStats.needFood()) && !this.capabilities.disableDamage;
   }

   public boolean shouldHeal() {
      return this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth();
   }

   public boolean isAllowEdit() {
      return this.capabilities.allowEdit;
   }

   public boolean canPlayerEdit(BlockPos var1, EnumFacing var2, ItemStack var3) {
      if (this.capabilities.allowEdit) {
         return true;
      } else if (var3.func_190926_b()) {
         return false;
      } else {
         BlockPos var4 = var1.offset(var2.getOpposite());
         Block var5 = this.world.getBlockState(var4).getBlock();
         return var3.canPlaceOn(var5) || var3.canEditBlocks();
      }
   }

   protected int getExperiencePoints(EntityPlayer var1) {
      if (!this.world.getGameRules().getBoolean("keepInventory") && !this.isSpectator()) {
         int var2 = this.experienceLevel * 7;
         return var2 > 100 ? 100 : var2;
      } else {
         return 0;
      }
   }

   protected boolean isPlayer() {
      return true;
   }

   public boolean getAlwaysRenderNameTagForRender() {
      return true;
   }

   protected boolean canTriggerWalking() {
      return !this.capabilities.isFlying;
   }

   public void sendPlayerAbilities() {
   }

   public void setGameType(GameType var1) {
   }

   public String getName() {
      return this.gameProfile.getName();
   }

   public InventoryEnderChest getInventoryEnderChest() {
      return this.theInventoryEnderChest;
   }

   public ItemStack getItemStackFromSlot(EntityEquipmentSlot var1) {
      if (var1 == EntityEquipmentSlot.MAINHAND) {
         return this.inventory.getCurrentItem();
      } else if (var1 == EntityEquipmentSlot.OFFHAND) {
         return this.inventory.offHandInventory.get(0);
      } else {
         return var1.getSlotType() == EntityEquipmentSlot.Type.ARMOR ? (ItemStack)this.inventory.armorInventory.get(var1.getIndex()) : ItemStack.field_190927_a;
      }
   }

   public void setItemStackToSlot(EntityEquipmentSlot var1, ItemStack var2) {
      if (var1 == EntityEquipmentSlot.MAINHAND) {
         this.playEquipSound(var2);
         this.inventory.mainInventory.set(this.inventory.currentItem, var2);
      } else if (var1 == EntityEquipmentSlot.OFFHAND) {
         this.playEquipSound(var2);
         this.inventory.offHandInventory.set(0, var2);
      } else if (var1.getSlotType() == EntityEquipmentSlot.Type.ARMOR) {
         this.playEquipSound(var2);
         this.inventory.armorInventory.set(var1.getIndex(), var2);
      }

   }

   public boolean func_191521_c(ItemStack var1) {
      this.playEquipSound(var1);
      return this.inventory.addItemStackToInventory(var1);
   }

   public Iterable<ItemStack> getHeldEquipment() {
      return Lists.newArrayList(new ItemStack[]{this.getHeldItemMainhand(), this.getHeldItemOffhand()});
   }

   public Iterable<ItemStack> getArmorInventoryList() {
      return this.inventory.armorInventory;
   }

   public boolean func_192027_g(NBTTagCompound var1) {
      if (!this.isRiding() && this.onGround && !this.isInWater()) {
         if (this.func_192023_dk().hasNoTags()) {
            this.func_192029_h(var1);
            return true;
         } else if (this.func_192025_dl().hasNoTags()) {
            this.func_192031_i(var1);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   protected void func_192030_dh() {
      this.func_192026_k(this.func_192023_dk());
      this.func_192029_h(new NBTTagCompound());
      this.func_192026_k(this.func_192025_dl());
      this.func_192031_i(new NBTTagCompound());
   }

   private void func_192026_k(@Nullable NBTTagCompound var1) {
      if (!this.world.isRemote && !var1.hasNoTags()) {
         Entity var2 = EntityList.createEntityFromNBT(var1, this.world);
         if (var2 instanceof EntityTameable) {
            ((EntityTameable)var2).setOwnerId(this.entityUniqueID);
         }

         var2.setPosition(this.posX, this.posY + (double)0.7F, this.posZ);
         this.world.spawnEntityInWorld(var2);
      }

   }

   public boolean isInvisibleToPlayer(EntityPlayer var1) {
      if (!this.isInvisible()) {
         return false;
      } else if (var1.isSpectator()) {
         return false;
      } else {
         Team var2 = this.getTeam();
         return var2 == null || var1 == null || var1.getTeam() != var2 || !var2.getSeeFriendlyInvisiblesEnabled();
      }
   }

   public abstract boolean isSpectator();

   public abstract boolean isCreative();

   public boolean isPushedByWater() {
      return !this.capabilities.isFlying;
   }

   public Scoreboard getWorldScoreboard() {
      return this.world.getScoreboard();
   }

   public Team getTeam() {
      return this.getWorldScoreboard().getPlayersTeam(this.getName());
   }

   public ITextComponent getDisplayName() {
      TextComponentString var1 = new TextComponentString(ScorePlayerTeam.formatPlayerName(this.getTeam(), this.getName()));
      var1.getStyle().setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/msg " + this.getName() + " "));
      var1.getStyle().setHoverEvent(this.getHoverEvent());
      var1.getStyle().setInsertion(this.getName());
      return var1;
   }

   public float getEyeHeight() {
      float var1 = 1.62F;
      if (this.isPlayerSleeping()) {
         var1 = 0.2F;
      } else if (!this.isSneaking() && this.height != 1.65F) {
         if (this.isElytraFlying() || this.height == 0.6F) {
            var1 = 0.4F;
         }
      } else {
         var1 -= 0.08F;
      }

      return var1;
   }

   public void setAbsorptionAmount(float var1) {
      if (var1 < 0.0F) {
         var1 = 0.0F;
      }

      this.getDataManager().set(ABSORPTION, var1);
   }

   public float getAbsorptionAmount() {
      return (Float)this.getDataManager().get(ABSORPTION);
   }

   public static UUID getUUID(GameProfile var0) {
      UUID var1 = var0.getId();
      if (var1 == null) {
         var1 = getOfflineUUID(var0.getName());
      }

      return var1;
   }

   public static UUID getOfflineUUID(String var0) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0).getBytes(StandardCharsets.UTF_8));
   }

   public boolean canOpen(LockCode var1) {
      if (var1.isEmpty()) {
         return true;
      } else {
         ItemStack var2 = this.getHeldItemMainhand();
         return !var2.func_190926_b() && var2.hasDisplayName() ? var2.getDisplayName().equals(var1.getLock()) : false;
      }
   }

   public boolean isWearing(EnumPlayerModelParts var1) {
      return ((Byte)this.getDataManager().get(PLAYER_MODEL_FLAG) & var1.getPartMask()) == var1.getPartMask();
   }

   public boolean sendCommandFeedback() {
      return this.getServer().worldServers[0].getGameRules().getBoolean("sendCommandFeedback");
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      if (var1 >= 0 && var1 < this.inventory.mainInventory.size()) {
         this.inventory.setInventorySlotContents(var1, var2);
         return true;
      } else {
         EntityEquipmentSlot var3;
         if (var1 == 100 + EntityEquipmentSlot.HEAD.getIndex()) {
            var3 = EntityEquipmentSlot.HEAD;
         } else if (var1 == 100 + EntityEquipmentSlot.CHEST.getIndex()) {
            var3 = EntityEquipmentSlot.CHEST;
         } else if (var1 == 100 + EntityEquipmentSlot.LEGS.getIndex()) {
            var3 = EntityEquipmentSlot.LEGS;
         } else if (var1 == 100 + EntityEquipmentSlot.FEET.getIndex()) {
            var3 = EntityEquipmentSlot.FEET;
         } else {
            var3 = null;
         }

         if (var1 == 98) {
            this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, var2);
            return true;
         } else if (var1 == 99) {
            this.setItemStackToSlot(EntityEquipmentSlot.OFFHAND, var2);
            return true;
         } else if (var3 == null) {
            int var4 = var1 - 200;
            if (var4 >= 0 && var4 < this.theInventoryEnderChest.getSizeInventory()) {
               this.theInventoryEnderChest.setInventorySlotContents(var4, var2);
               return true;
            } else {
               return false;
            }
         } else {
            if (!var2.func_190926_b()) {
               if (!(var2.getItem() instanceof ItemArmor) && !(var2.getItem() instanceof ItemElytra)) {
                  if (var3 != EntityEquipmentSlot.HEAD) {
                     return false;
                  }
               } else if (EntityLiving.getSlotForItemStack(var2) != var3) {
                  return false;
               }
            }

            this.inventory.setInventorySlotContents(var3.getIndex() + this.inventory.mainInventory.size(), var2);
            return true;
         }
      }
   }

   public boolean hasReducedDebug() {
      return this.hasReducedDebug;
   }

   public void setReducedDebug(boolean var1) {
      this.hasReducedDebug = var1;
   }

   public EnumHandSide getPrimaryHand() {
      return (Byte)this.dataManager.get(MAIN_HAND) == 0 ? EnumHandSide.LEFT : EnumHandSide.RIGHT;
   }

   public void setPrimaryHand(EnumHandSide var1) {
      this.dataManager.set(MAIN_HAND, (byte)(var1 == EnumHandSide.LEFT ? 0 : 1));
   }

   public NBTTagCompound func_192023_dk() {
      return (NBTTagCompound)this.dataManager.get(field_192032_bt);
   }

   protected void func_192029_h(NBTTagCompound var1) {
      this.dataManager.set(field_192032_bt, var1);
   }

   public NBTTagCompound func_192025_dl() {
      return (NBTTagCompound)this.dataManager.get(field_192033_bu);
   }

   protected void func_192031_i(NBTTagCompound var1) {
      this.dataManager.set(field_192033_bu, var1);
   }

   public float getCooldownPeriod() {
      return (float)((double)1.0F / this.getEntityAttribute(SharedMonsterAttributes.ATTACK_SPEED).getAttributeValue() * (double)20.0F);
   }

   public float getCooledAttackStrength(float var1) {
      return MathHelper.clamp(((float)this.ticksSinceLastSwing + var1) / this.getCooldownPeriod(), 0.0F, 1.0F);
   }

   public void resetCooldown() {
      this.ticksSinceLastSwing = 0;
   }

   public CooldownTracker getCooldownTracker() {
      return this.cooldownTracker;
   }

   public void applyEntityCollision(Entity var1) {
      if (!this.isPlayerSleeping()) {
         super.applyEntityCollision(var1);
      }

   }

   public float getLuck() {
      return (float)this.getEntityAttribute(SharedMonsterAttributes.LUCK).getAttributeValue();
   }

   public boolean canUseCommandBlock() {
      return this.capabilities.isCreativeMode && this.canCommandSenderUseCommand(2, "");
   }

   static {
      ABSORPTION = EntityDataManager.<Float>createKey(EntityPlayer.class, DataSerializers.FLOAT);
      PLAYER_SCORE = EntityDataManager.<Integer>createKey(EntityPlayer.class, DataSerializers.VARINT);
      PLAYER_MODEL_FLAG = EntityDataManager.<Byte>createKey(EntityPlayer.class, DataSerializers.BYTE);
      MAIN_HAND = EntityDataManager.<Byte>createKey(EntityPlayer.class, DataSerializers.BYTE);
      field_192032_bt = EntityDataManager.<NBTTagCompound>createKey(EntityPlayer.class, DataSerializers.field_192734_n);
      field_192033_bu = EntityDataManager.<NBTTagCompound>createKey(EntityPlayer.class, DataSerializers.field_192734_n);
   }

   public static enum EnumChatVisibility {
      FULL(0, "options.chat.visibility.full"),
      SYSTEM(1, "options.chat.visibility.system"),
      HIDDEN(2, "options.chat.visibility.hidden");

      private static final EnumChatVisibility[] ID_LOOKUP = new EnumChatVisibility[values().length];
      private final int chatVisibility;
      private final String resourceKey;

      private EnumChatVisibility(int var3, String var4) {
         this.chatVisibility = var3;
         this.resourceKey = var4;
      }

      public int getChatVisibility() {
         return this.chatVisibility;
      }

      public static EnumChatVisibility getEnumChatVisibility(int var0) {
         return ID_LOOKUP[var0 % ID_LOOKUP.length];
      }

      public String getResourceKey() {
         return this.resourceKey;
      }

      static {
         for(EnumChatVisibility var3 : values()) {
            ID_LOOKUP[var3.chatVisibility] = var3;
         }

      }
   }

   static class SleepEnemyPredicate implements Predicate<EntityMob> {
      private final EntityPlayer field_192387_a;

      private SleepEnemyPredicate(EntityPlayer var1) {
         this.field_192387_a = var1;
      }

      public boolean apply(@Nullable EntityMob var1) {
         return var1.func_191990_c(this.field_192387_a);
      }

      SleepEnemyPredicate(EntityPlayer var1, Object var2) {
         this(var1);
      }
   }

   public static enum SleepResult {
      OK,
      NOT_POSSIBLE_HERE,
      NOT_POSSIBLE_NOW,
      TOO_FAR_AWAY,
      OTHER_PROBLEM,
      NOT_SAFE;
   }
}
