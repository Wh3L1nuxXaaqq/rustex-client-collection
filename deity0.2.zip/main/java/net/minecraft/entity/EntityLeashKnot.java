package net.minecraft.entity;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.BlockFence;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class EntityLeashKnot extends EntityHanging {
   public EntityLeashKnot(World var1) {
      super(var1);
   }

   public EntityLeashKnot(World var1, BlockPos var2) {
      super(var1, var2);
      this.setPosition((double)var2.getX() + (double)0.5F, (double)var2.getY() + (double)0.5F, (double)var2.getZ() + (double)0.5F);
      float var3 = 0.125F;
      float var4 = 0.1875F;
      float var5 = 0.25F;
      this.setEntityBoundingBox(new AxisAlignedBB(this.posX - (double)0.1875F, this.posY - (double)0.25F + (double)0.125F, this.posZ - (double)0.1875F, this.posX + (double)0.1875F, this.posY + (double)0.25F + (double)0.125F, this.posZ + (double)0.1875F));
      this.forceSpawn = true;
   }

   public void setPosition(double var1, double var3, double var5) {
      super.setPosition((double)MathHelper.floor(var1) + (double)0.5F, (double)MathHelper.floor(var3) + (double)0.5F, (double)MathHelper.floor(var5) + (double)0.5F);
   }

   protected void updateBoundingBox() {
      this.posX = (double)this.hangingPosition.getX() + (double)0.5F;
      this.posY = (double)this.hangingPosition.getY() + (double)0.5F;
      this.posZ = (double)this.hangingPosition.getZ() + (double)0.5F;
   }

   public void updateFacingWithBoundingBox(EnumFacing var1) {
   }

   public int getWidthPixels() {
      return 9;
   }

   public int getHeightPixels() {
      return 9;
   }

   public float getEyeHeight() {
      return -0.0625F;
   }

   public boolean isInRangeToRenderDist(double var1) {
      return var1 < (double)1024.0F;
   }

   public void onBroken(@Nullable Entity var1) {
      this.playSound(SoundEvents.ENTITY_LEASHKNOT_BREAK, 1.0F, 1.0F);
   }

   public boolean writeToNBTOptional(NBTTagCompound var1) {
      return false;
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
   }

   public boolean processInitialInteract(EntityPlayer var1, EnumHand var2) {
      if (this.world.isRemote) {
         return true;
      } else {
         boolean var3 = false;
         double var4 = (double)7.0F;
         List var6 = this.world.getEntitiesWithinAABB(EntityLiving.class, new AxisAlignedBB(this.posX - (double)7.0F, this.posY - (double)7.0F, this.posZ - (double)7.0F, this.posX + (double)7.0F, this.posY + (double)7.0F, this.posZ + (double)7.0F));

         for(Object var8_raw : var6) {
            EntityLiving var8 = (EntityLiving)var8_raw;
            if (var8.getLeashed() && var8.getLeashedToEntity() == var1) {
               var8.setLeashedToEntity(this, true);
               var3 = true;
            }
         }

         if (!var3) {
            this.setDead();
            if (var1.capabilities.isCreativeMode) {
               for(Object var10_raw : var6) {
                  EntityLiving var10 = (EntityLiving)var10_raw;
                  if (var10.getLeashed() && var10.getLeashedToEntity() == this) {
                     var10.clearLeashed(true, false);
                  }
               }
            }
         }

         return true;
      }
   }

   public boolean onValidSurface() {
      return this.world.getBlockState(this.hangingPosition).getBlock() instanceof BlockFence;
   }

   public static EntityLeashKnot createKnot(World var0, BlockPos var1) {
      EntityLeashKnot var2 = new EntityLeashKnot(var0, var1);
      var0.spawnEntityInWorld(var2);
      var2.playPlaceSound();
      return var2;
   }

   @Nullable
   public static EntityLeashKnot getKnotForPosition(World var0, BlockPos var1) {
      int var2 = var1.getX();
      int var3 = var1.getY();
      int var4 = var1.getZ();

      for(EntityLeashKnot var6 : var0.getEntitiesWithinAABB(EntityLeashKnot.class, new AxisAlignedBB((double)var2 - (double)1.0F, (double)var3 - (double)1.0F, (double)var4 - (double)1.0F, (double)var2 + (double)1.0F, (double)var3 + (double)1.0F, (double)var4 + (double)1.0F))) {
         if (var6.getHangingPosition().equals(var1)) {
            return var6;
         }
      }

      return null;
   }

   public void playPlaceSound() {
      this.playSound(SoundEvents.ENTITY_LEASHKNOT_PLACE, 1.0F, 1.0F);
   }
}
