package net.minecraft.entity.boss.dragon.phase;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityDragonFireball;
import net.minecraft.pathfinding.Path;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PhaseStrafePlayer extends PhaseBase {
   private static final Logger LOGGER = LogManager.getLogger();
   private int fireballCharge;
   private Path currentPath;
   private Vec3d targetLocation;
   private EntityLivingBase attackTarget;
   private boolean holdingPatternClockwise;

   public PhaseStrafePlayer(EntityDragon var1) {
      super(var1);
   }

   public void doLocalUpdate() {
      if (this.attackTarget == null) {
         LOGGER.warn("Skipping player strafe phase because no player was found");
         this.dragon.getPhaseManager().setPhase(PhaseList.HOLDING_PATTERN);
      } else {
         if (this.currentPath != null && this.currentPath.isFinished()) {
            double var1 = this.attackTarget.posX;
            double var3 = this.attackTarget.posZ;
            double var5 = var1 - this.dragon.posX;
            double var7 = var3 - this.dragon.posZ;
            double var9 = (double)MathHelper.sqrt(var5 * var5 + var7 * var7);
            double var11 = Math.min((double)0.4F + var9 / (double)80.0F - (double)1.0F, (double)10.0F);
            this.targetLocation = new Vec3d(var1, this.attackTarget.posY + var11, var3);
         }

         double var25 = this.targetLocation == null ? (double)0.0F : this.targetLocation.squareDistanceTo(this.dragon.posX, this.dragon.posY, this.dragon.posZ);
         if (var25 < (double)100.0F || var25 > (double)22500.0F) {
            this.findNewTarget();
         }

         double var26 = (double)64.0F;
         if (this.attackTarget.getDistanceSqToEntity(this.dragon) < (double)4096.0F) {
            if (this.dragon.canEntityBeSeen(this.attackTarget)) {
               ++this.fireballCharge;
               Vec3d var27 = (new Vec3d(this.attackTarget.posX - this.dragon.posX, (double)0.0F, this.attackTarget.posZ - this.dragon.posZ)).normalize();
               Vec3d var6 = (new Vec3d((double)MathHelper.sin(this.dragon.rotationYaw * ((float)Math.PI / 180F)), (double)0.0F, (double)(-MathHelper.cos(this.dragon.rotationYaw * ((float)Math.PI / 180F))))).normalize();
               float var28 = (float)var6.dotProduct(var27);
               float var8 = (float)(Math.acos((double)var28) * (180D / Math.PI));
               var8 += 0.5F;
               if (this.fireballCharge >= 5 && var8 >= 0.0F && var8 < 10.0F) {
                  double var30 = (double)1.0F;
                  Vec3d var31 = this.dragon.getLook(1.0F);
                  double var12 = this.dragon.dragonPartHead.posX - var31.xCoord * (double)1.0F;
                  double var14 = this.dragon.dragonPartHead.posY + (double)(this.dragon.dragonPartHead.height / 2.0F) + (double)0.5F;
                  double var16 = this.dragon.dragonPartHead.posZ - var31.zCoord * (double)1.0F;
                  double var18 = this.attackTarget.posX - var12;
                  double var20 = this.attackTarget.posY + (double)(this.attackTarget.height / 2.0F) - (var14 + (double)(this.dragon.dragonPartHead.height / 2.0F));
                  double var22 = this.attackTarget.posZ - var16;
                  this.dragon.world.playEvent((EntityPlayer)null, 1017, new BlockPos(this.dragon), 0);
                  EntityDragonFireball var24 = new EntityDragonFireball(this.dragon.world, this.dragon, var18, var20, var22);
                  var24.setLocationAndAngles(var12, var14, var16, 0.0F, 0.0F);
                  this.dragon.world.spawnEntityInWorld(var24);
                  this.fireballCharge = 0;
                  if (this.currentPath != null) {
                     while(!this.currentPath.isFinished()) {
                        this.currentPath.incrementPathIndex();
                     }
                  }

                  this.dragon.getPhaseManager().setPhase(PhaseList.HOLDING_PATTERN);
               }
            } else if (this.fireballCharge > 0) {
               --this.fireballCharge;
            }
         } else if (this.fireballCharge > 0) {
            --this.fireballCharge;
         }
      }

   }

   private void findNewTarget() {
      if (this.currentPath == null || this.currentPath.isFinished()) {
         int var1 = this.dragon.initPathPoints();
         int var2 = var1;
         if (this.dragon.getRNG().nextInt(8) == 0) {
            this.holdingPatternClockwise = !this.holdingPatternClockwise;
            var2 = var1 + 6;
         }

         if (this.holdingPatternClockwise) {
            ++var2;
         } else {
            --var2;
         }

         if (this.dragon.getFightManager() != null && this.dragon.getFightManager().getNumAliveCrystals() > 0) {
            var2 %= 12;
            if (var2 < 0) {
               var2 += 12;
            }
         } else {
            var2 -= 12;
            var2 &= 7;
            var2 += 12;
         }

         this.currentPath = this.dragon.findPath(var1, var2, (PathPoint)null);
         if (this.currentPath != null) {
            this.currentPath.incrementPathIndex();
         }
      }

      this.navigateToNextPathNode();
   }

   private void navigateToNextPathNode() {
      if (this.currentPath != null && !this.currentPath.isFinished()) {
         Vec3d var1 = this.currentPath.getCurrentPos();
         this.currentPath.incrementPathIndex();
         double var2 = var1.xCoord;
         double var4 = var1.zCoord;

         double var6;
         do {
            var6 = var1.yCoord + (double)(this.dragon.getRNG().nextFloat() * 20.0F);
         } while(!(var6 >= var1.yCoord));

         this.targetLocation = new Vec3d(var2, var6, var4);
      }

   }

   public void initPhase() {
      this.fireballCharge = 0;
      this.targetLocation = null;
      this.currentPath = null;
      this.attackTarget = null;
   }

   public void setTarget(EntityLivingBase var1) {
      this.attackTarget = var1;
      int var2 = this.dragon.initPathPoints();
      int var3 = this.dragon.getNearestPpIdx(this.attackTarget.posX, this.attackTarget.posY, this.attackTarget.posZ);
      int var4 = MathHelper.floor(this.attackTarget.posX);
      int var5 = MathHelper.floor(this.attackTarget.posZ);
      double var6 = (double)var4 - this.dragon.posX;
      double var8 = (double)var5 - this.dragon.posZ;
      double var10 = (double)MathHelper.sqrt(var6 * var6 + var8 * var8);
      double var12 = Math.min((double)0.4F + var10 / (double)80.0F - (double)1.0F, (double)10.0F);
      int var14 = MathHelper.floor(this.attackTarget.posY + var12);
      PathPoint var15 = new PathPoint(var4, var14, var5);
      this.currentPath = this.dragon.findPath(var2, var3, var15);
      if (this.currentPath != null) {
         this.currentPath.incrementPathIndex();
         this.navigateToNextPathNode();
      }

   }

   @Nullable
   public Vec3d getTargetLocation() {
      return this.targetLocation;
   }

   public PhaseList<PhaseStrafePlayer> getPhaseList() {
      return PhaseList.STRAFE_PLAYER;
   }
}
