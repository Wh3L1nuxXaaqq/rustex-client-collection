package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityHusk extends EntityZombie {
   public EntityHusk(World var1) {
      super(var1);
   }

   public static void func_190740_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityHusk.class);
   }

   public boolean getCanSpawnHere() {
      return super.getCanSpawnHere() && this.world.canSeeSky(new BlockPos(this));
   }

   protected boolean func_190730_o() {
      return false;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_HUSK_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_HUSK_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_HUSK_DEATH;
   }

   protected SoundEvent func_190731_di() {
      return SoundEvents.ENTITY_HUSK_STEP;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191182_ar;
   }

   public boolean attackEntityAsMob(Entity var1) {
      boolean var2 = super.attackEntityAsMob(var1);
      if (var2 && this.getHeldItemMainhand().func_190926_b() && var1 instanceof EntityLivingBase) {
         float var3 = this.world.getDifficultyForLocation(new BlockPos(this)).getAdditionalDifficulty();
         ((EntityLivingBase)var1).addPotionEffect(new PotionEffect(MobEffects.HUNGER, 140 * (int)var3));
      }

      return var2;
   }

   protected ItemStack func_190732_dj() {
      return ItemStack.field_190927_a;
   }
}
