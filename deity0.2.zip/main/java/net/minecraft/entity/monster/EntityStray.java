package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityStray extends AbstractSkeleton {
   public EntityStray(World var1) {
      super(var1);
   }

   public static void func_190728_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityStray.class);
   }

   public boolean getCanSpawnHere() {
      return super.getCanSpawnHere() && this.world.canSeeSky(new BlockPos(this));
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_STRAY;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_STRAY_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_STRAY_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_STRAY_DEATH;
   }

   SoundEvent func_190727_o() {
      return SoundEvents.ENTITY_STRAY_STEP;
   }

   protected EntityArrow func_190726_a(float var1) {
      EntityArrow var2 = super.func_190726_a(var1);
      if (var2 instanceof EntityTippedArrow) {
         ((EntityTippedArrow)var2).addEffect(new PotionEffect(MobEffects.SLOWNESS, 600));
      }

      return var2;
   }
}
