package net.minecraft.entity.monster;

import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBreakDoor;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveThroughVillage;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityAIZombieAttack;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityZombie extends EntityMob {
   protected static final IAttribute SPAWN_REINFORCEMENTS_CHANCE = (new RangedAttribute((IAttribute)null, "zombie.spawnReinforcements", (double)0.0F, (double)0.0F, (double)1.0F)).setDescription("Spawn Reinforcements Chance");
   private static final UUID BABY_SPEED_BOOST_ID = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
   private static final AttributeModifier BABY_SPEED_BOOST;
   private static final DataParameter<Boolean> IS_CHILD;
   private static final DataParameter<Integer> VILLAGER_TYPE;
   private static final DataParameter<Boolean> ARMS_RAISED;
   private final EntityAIBreakDoor breakDoor = new EntityAIBreakDoor(this);
   private boolean isBreakDoorsTaskSet;
   private float zombieWidth = -1.0F;
   private float zombieHeight;

   public EntityZombie(World var1) {
      super(var1);
      this.setSize(0.6F, 1.95F);
   }

   protected void initEntityAI() {
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(2, new EntityAIZombieAttack(this, (double)1.0F, false));
      this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, (double)1.0F));
      this.tasks.addTask(7, new EntityAIWanderAvoidWater(this, (double)1.0F));
      this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      this.tasks.addTask(8, new EntityAILookIdle(this));
      this.applyEntityAI();
   }

   protected void applyEntityAI() {
      this.tasks.addTask(6, new EntityAIMoveThroughVillage(this, (double)1.0F, false));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[]{EntityPigZombie.class}));
      this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityVillager.class, false));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityIronGolem.class, true));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)35.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.23F);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)3.0F);
      this.getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue((double)2.0F);
      this.getAttributeMap().registerAttribute(SPAWN_REINFORCEMENTS_CHANCE).setBaseValue(this.rand.nextDouble() * (double)0.1F);
   }

   protected void entityInit() {
      super.entityInit();
      this.getDataManager().register(IS_CHILD, false);
      this.getDataManager().register(VILLAGER_TYPE, 0);
      this.getDataManager().register(ARMS_RAISED, false);
   }

   public void setArmsRaised(boolean var1) {
      this.getDataManager().set(ARMS_RAISED, var1);
   }

   public boolean isArmsRaised() {
      return (Boolean)this.getDataManager().get(ARMS_RAISED);
   }

   public boolean isBreakDoorsTaskSet() {
      return this.isBreakDoorsTaskSet;
   }

   public void setBreakDoorsAItask(boolean var1) {
      if (this.isBreakDoorsTaskSet != var1) {
         this.isBreakDoorsTaskSet = var1;
         ((PathNavigateGround)this.getNavigator()).setBreakDoors(var1);
         if (var1) {
            this.tasks.addTask(1, this.breakDoor);
         } else {
            this.tasks.removeTask(this.breakDoor);
         }
      }

   }

   public boolean isChild() {
      return (Boolean)this.getDataManager().get(IS_CHILD);
   }

   protected int getExperiencePoints(EntityPlayer var1) {
      if (this.isChild()) {
         this.experienceValue = (int)((float)this.experienceValue * 2.5F);
      }

      return super.getExperiencePoints(var1);
   }

   public void setChild(boolean var1) {
      this.getDataManager().set(IS_CHILD, var1);
      if (this.world != null && !this.world.isRemote) {
         IAttributeInstance var2 = this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED);
         var2.removeModifier(BABY_SPEED_BOOST);
         if (var1) {
            var2.applyModifier(BABY_SPEED_BOOST);
         }
      }

      this.setChildSize(var1);
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      if (IS_CHILD.equals(var1)) {
         this.setChildSize(this.isChild());
      }

      super.notifyDataManagerChange(var1);
   }

   public void onLivingUpdate() {
      if (this.world.isDaytime() && !this.world.isRemote && !this.isChild() && this.func_190730_o()) {
         float var1 = this.getBrightness();
         if (var1 > 0.5F && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F && this.world.canSeeSky(new BlockPos(this.posX, this.posY + (double)this.getEyeHeight(), this.posZ))) {
            boolean var2 = true;
            ItemStack var3 = this.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
            if (!var3.func_190926_b()) {
               if (var3.isItemStackDamageable()) {
                  var3.setItemDamage(var3.getItemDamage() + this.rand.nextInt(2));
                  if (var3.getItemDamage() >= var3.getMaxDamage()) {
                     this.renderBrokenItemStack(var3);
                     this.setItemStackToSlot(EntityEquipmentSlot.HEAD, ItemStack.field_190927_a);
                  }
               }

               var2 = false;
            }

            if (var2) {
               this.setFire(8);
            }
         }
      }

      super.onLivingUpdate();
   }

   protected boolean func_190730_o() {
      return true;
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (super.attackEntityFrom(var1, var2)) {
         EntityLivingBase var3 = this.getAttackTarget();
         if (var3 == null && var1.getEntity() instanceof EntityLivingBase) {
            var3 = (EntityLivingBase)var1.getEntity();
         }

         if (var3 != null && this.world.getDifficulty() == EnumDifficulty.HARD && (double)this.rand.nextFloat() < this.getEntityAttribute(SPAWN_REINFORCEMENTS_CHANCE).getAttributeValue() && this.world.getGameRules().getBoolean("doMobSpawning")) {
            int var4 = MathHelper.floor(this.posX);
            int var5 = MathHelper.floor(this.posY);
            int var6 = MathHelper.floor(this.posZ);
            EntityZombie var7 = new EntityZombie(this.world);

            for(int var8 = 0; var8 < 50; ++var8) {
               int var9 = var4 + MathHelper.getInt((Random)this.rand, 7, 40) * MathHelper.getInt((Random)this.rand, -1, 1);
               int var10 = var5 + MathHelper.getInt((Random)this.rand, 7, 40) * MathHelper.getInt((Random)this.rand, -1, 1);
               int var11 = var6 + MathHelper.getInt((Random)this.rand, 7, 40) * MathHelper.getInt((Random)this.rand, -1, 1);
               if (this.world.getBlockState(new BlockPos(var9, var10 - 1, var11)).isFullyOpaque() && this.world.getLightFromNeighbors(new BlockPos(var9, var10, var11)) < 10) {
                  var7.setPosition((double)var9, (double)var10, (double)var11);
                  if (!this.world.isAnyPlayerWithinRangeAt((double)var9, (double)var10, (double)var11, (double)7.0F) && this.world.checkNoEntityCollision(var7.getEntityBoundingBox(), var7) && this.world.getCollisionBoxes(var7, var7.getEntityBoundingBox()).isEmpty() && !this.world.containsAnyLiquid(var7.getEntityBoundingBox())) {
                     this.world.spawnEntityInWorld(var7);
                     var7.setAttackTarget(var3);
                     var7.onInitialSpawn(this.world.getDifficultyForLocation(new BlockPos(var7)), (IEntityLivingData)null);
                     this.getEntityAttribute(SPAWN_REINFORCEMENTS_CHANCE).applyModifier(new AttributeModifier("Zombie reinforcement caller charge", (double)-0.05F, 0));
                     var7.getEntityAttribute(SPAWN_REINFORCEMENTS_CHANCE).applyModifier(new AttributeModifier("Zombie reinforcement callee charge", (double)-0.05F, 0));
                     break;
                  }
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean attackEntityAsMob(Entity var1) {
      boolean var2 = super.attackEntityAsMob(var1);
      if (var2) {
         float var3 = this.world.getDifficultyForLocation(new BlockPos(this)).getAdditionalDifficulty();
         if (this.getHeldItemMainhand().func_190926_b() && this.isBurning() && this.rand.nextFloat() < var3 * 0.3F) {
            var1.setFire(2 * (int)var3);
         }
      }

      return var2;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_ZOMBIE_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_ZOMBIE_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_ZOMBIE_DEATH;
   }

   protected SoundEvent func_190731_di() {
      return SoundEvents.ENTITY_ZOMBIE_STEP;
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(this.func_190731_di(), 0.15F, 1.0F);
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.UNDEAD;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_ZOMBIE;
   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      super.setEquipmentBasedOnDifficulty(var1);
      if (this.rand.nextFloat() < (this.world.getDifficulty() == EnumDifficulty.HARD ? 0.05F : 0.01F)) {
         int var2 = this.rand.nextInt(3);
         if (var2 == 0) {
            this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
         } else {
            this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SHOVEL));
         }
      }

   }

   public static void registerFixesZombie(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityZombie.class);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      if (this.isChild()) {
         var1.setBoolean("IsBaby", true);
      }

      var1.setBoolean("CanBreakDoors", this.isBreakDoorsTaskSet());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.getBoolean("IsBaby")) {
         this.setChild(true);
      }

      this.setBreakDoorsAItask(var1.getBoolean("CanBreakDoors"));
   }

   public void onKillEntity(EntityLivingBase var1) {
      super.onKillEntity(var1);
      if ((this.world.getDifficulty() == EnumDifficulty.NORMAL || this.world.getDifficulty() == EnumDifficulty.HARD) && var1 instanceof EntityVillager) {
         if (this.world.getDifficulty() != EnumDifficulty.HARD && this.rand.nextBoolean()) {
            return;
         }

         EntityVillager var2 = (EntityVillager)var1;
         EntityZombieVillager var3 = new EntityZombieVillager(this.world);
         var3.copyLocationAndAnglesFrom(var2);
         this.world.removeEntity(var2);
         var3.onInitialSpawn(this.world.getDifficultyForLocation(new BlockPos(var3)), new GroupData(false));
         var3.func_190733_a(var2.getProfession());
         var3.setChild(var2.isChild());
         var3.setNoAI(var2.isAIDisabled());
         if (var2.hasCustomName()) {
            var3.setCustomNameTag(var2.getCustomNameTag());
            var3.setAlwaysRenderNameTag(var2.getAlwaysRenderNameTag());
         }

         this.world.spawnEntityInWorld(var3);
         this.world.playEvent((EntityPlayer)null, 1026, new BlockPos(this), 0);
      }

   }

   public float getEyeHeight() {
      float var1 = 1.74F;
      if (this.isChild()) {
         var1 = (float)((double)var1 - 0.81);
      }

      return var1;
   }

   protected boolean canEquipItem(ItemStack var1) {
      return var1.getItem() == Items.EGG && this.isChild() && this.isRiding() ? false : super.canEquipItem(var1);
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      float var3 = var1.getClampedAdditionalDifficulty();
      this.setCanPickUpLoot(this.rand.nextFloat() < 0.55F * var3);
      if (var2 == null) {
         var2 = new GroupData(this.world.rand.nextFloat() < 0.05F);
      }

      if (var2 instanceof GroupData) {
         GroupData var4 = (GroupData)var2;
         if (var4.isChild) {
            this.setChild(true);
            if ((double)this.world.rand.nextFloat() < 0.05) {
               List var5 = this.world.getEntitiesWithinAABB(EntityChicken.class, this.getEntityBoundingBox().expand((double)5.0F, (double)3.0F, (double)5.0F), EntitySelectors.IS_STANDALONE);
               if (!var5.isEmpty()) {
                  EntityChicken var6 = (EntityChicken)var5.get(0);
                  var6.setChickenJockey(true);
                  this.startRiding(var6);
               }
            } else if ((double)this.world.rand.nextFloat() < 0.05) {
               EntityChicken var10 = new EntityChicken(this.world);
               var10.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
               var10.onInitialSpawn(var1, (IEntityLivingData)null);
               var10.setChickenJockey(true);
               this.world.spawnEntityInWorld(var10);
               this.startRiding(var10);
            }
         }
      }

      this.setBreakDoorsAItask(this.rand.nextFloat() < var3 * 0.1F);
      this.setEquipmentBasedOnDifficulty(var1);
      this.setEnchantmentBasedOnDifficulty(var1);
      if (this.getItemStackFromSlot(EntityEquipmentSlot.HEAD).func_190926_b()) {
         Calendar var8 = this.world.getCurrentDate();
         if (var8.get(2) + 1 == 10 && var8.get(5) == 31 && this.rand.nextFloat() < 0.25F) {
            this.setItemStackToSlot(EntityEquipmentSlot.HEAD, new ItemStack(this.rand.nextFloat() < 0.1F ? Blocks.LIT_PUMPKIN : Blocks.PUMPKIN));
            this.inventoryArmorDropChances[EntityEquipmentSlot.HEAD.getIndex()] = 0.0F;
         }
      }

      this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).applyModifier(new AttributeModifier("Random spawn bonus", this.rand.nextDouble() * (double)0.05F, 0));
      double var9 = this.rand.nextDouble() * (double)1.5F * (double)var3;
      if (var9 > (double)1.0F) {
         this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).applyModifier(new AttributeModifier("Random zombie-spawn bonus", var9, 2));
      }

      if (this.rand.nextFloat() < var3 * 0.05F) {
         this.getEntityAttribute(SPAWN_REINFORCEMENTS_CHANCE).applyModifier(new AttributeModifier("Leader zombie bonus", this.rand.nextDouble() * (double)0.25F + (double)0.5F, 0));
         this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).applyModifier(new AttributeModifier("Leader zombie bonus", this.rand.nextDouble() * (double)3.0F + (double)1.0F, 2));
         this.setBreakDoorsAItask(true);
      }

      return var2;
   }

   public void setChildSize(boolean var1) {
      this.multiplySize(var1 ? 0.5F : 1.0F);
   }

   protected final void setSize(float var1, float var2) {
      boolean var3 = this.zombieWidth > 0.0F && this.zombieHeight > 0.0F;
      this.zombieWidth = var1;
      this.zombieHeight = var2;
      if (!var3) {
         this.multiplySize(1.0F);
      }

   }

   protected final void multiplySize(float var1) {
      super.setSize(this.zombieWidth * var1, this.zombieHeight * var1);
   }

   public double getYOffset() {
      return this.isChild() ? (double)0.0F : -0.45;
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (var1.getEntity() instanceof EntityCreeper) {
         EntityCreeper var2 = (EntityCreeper)var1.getEntity();
         if (var2.getPowered() && var2.isAIEnabled()) {
            var2.incrementDroppedSkulls();
            ItemStack var3 = this.func_190732_dj();
            if (!var3.func_190926_b()) {
               this.entityDropItem(var3, 0.0F);
            }
         }
      }

   }

   protected ItemStack func_190732_dj() {
      return new ItemStack(Items.SKULL, 1, 2);
   }

   static {
      BABY_SPEED_BOOST = new AttributeModifier(BABY_SPEED_BOOST_ID, "Baby speed boost", (double)0.5F, 1);
      IS_CHILD = EntityDataManager.<Boolean>createKey(EntityZombie.class, DataSerializers.BOOLEAN);
      VILLAGER_TYPE = EntityDataManager.<Integer>createKey(EntityZombie.class, DataSerializers.VARINT);
      ARMS_RAISED = EntityDataManager.<Boolean>createKey(EntityZombie.class, DataSerializers.BOOLEAN);
   }

   class GroupData implements IEntityLivingData {
      public boolean isChild;

      private GroupData(boolean var2) {
         this.isChild = var2;
      }

      GroupData(boolean var2, Object var3) {
         this(var2);
      }
   }
}
