package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackRangedBow;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityIllusionIllager extends EntitySpellcasterIllager implements IRangedAttackMob {
   private int field_193099_c;
   private final Vec3d[][] field_193100_bx;

   public EntityIllusionIllager(World var1) {
      super(var1);
      this.setSize(0.6F, 1.95F);
      this.experienceValue = 5;
      this.field_193100_bx = new Vec3d[2][4];

      for(int var2 = 0; var2 < 4; ++var2) {
         this.field_193100_bx[0][var2] = new Vec3d((double)0.0F, (double)0.0F, (double)0.0F);
         this.field_193100_bx[1][var2] = new Vec3d((double)0.0F, (double)0.0F, (double)0.0F);
      }

   }

   protected void initEntityAI() {
      super.initEntityAI();
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new EntitySpellcasterIllager.AICastingApell());
      this.tasks.addTask(4, new AIMirriorSpell());
      this.tasks.addTask(5, new AIBlindnessSpell());
      this.tasks.addTask(6, new EntityAIAttackRangedBow(this, (double)0.5F, 20, 15.0F));
      this.tasks.addTask(8, new EntityAIWander(this, 0.6));
      this.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 3.0F, 1.0F));
      this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[]{EntityIllusionIllager.class}));
      this.targetTasks.addTask(2, (new EntityAINearestAttackableTarget(this, EntityPlayer.class, true)).func_190882_b(300));
      this.targetTasks.addTask(3, (new EntityAINearestAttackableTarget(this, EntityVillager.class, false)).func_190882_b(300));
      this.targetTasks.addTask(3, (new EntityAINearestAttackableTarget(this, EntityIronGolem.class, false)).func_190882_b(300));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.5F);
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)18.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)32.0F);
   }

   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, IEntityLivingData var2) {
      this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
      return super.onInitialSpawn(var1, var2);
   }

   protected void entityInit() {
      super.entityInit();
   }

   protected ResourceLocation getLootTable() {
      return LootTableList.EMPTY;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return this.getEntityBoundingBox().expand((double)3.0F, (double)0.0F, (double)3.0F);
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if (this.world.isRemote && this.isInvisible()) {
         --this.field_193099_c;
         if (this.field_193099_c < 0) {
            this.field_193099_c = 0;
         }

         if (this.hurtTime != 1 && this.ticksExisted % 1200 != 0) {
            if (this.hurtTime == this.maxHurtTime - 1) {
               this.field_193099_c = 3;

               for(int var4 = 0; var4 < 4; ++var4) {
                  this.field_193100_bx[0][var4] = this.field_193100_bx[1][var4];
                  this.field_193100_bx[1][var4] = new Vec3d((double)0.0F, (double)0.0F, (double)0.0F);
               }
            }
         } else {
            this.field_193099_c = 3;
            float var1 = -6.0F;
            boolean var2 = true;

            for(int var3 = 0; var3 < 4; ++var3) {
               this.field_193100_bx[0][var3] = this.field_193100_bx[1][var3];
               this.field_193100_bx[1][var3] = new Vec3d((double)(-6.0F + (float)this.rand.nextInt(13)) * (double)0.5F, (double)Math.max(0, this.rand.nextInt(6) - 4), (double)(-6.0F + (float)this.rand.nextInt(13)) * (double)0.5F);
            }

            for(int var5 = 0; var5 < 16; ++var5) {
               this.world.spawnParticle(EnumParticleTypes.CLOUD, this.posX + (this.rand.nextDouble() - (double)0.5F) * (double)this.width, this.posY + this.rand.nextDouble() * (double)this.height, this.posZ + (this.rand.nextDouble() - (double)0.5F) * (double)this.width, (double)0.0F, (double)0.0F, (double)0.0F);
            }

            this.world.playSound(this.posX, this.posY, this.posZ, SoundEvents.field_193788_dg, this.getSoundCategory(), 1.0F, 1.0F, false);
         }
      }

   }

   public Vec3d[] func_193098_a(float var1) {
      if (this.field_193099_c <= 0) {
         return this.field_193100_bx[1];
      } else {
         double var2 = (double)(((float)this.field_193099_c - var1) / 3.0F);
         var2 = Math.pow(var2, (double)0.25F);
         Vec3d[] var4 = new Vec3d[4];

         for(int var5 = 0; var5 < 4; ++var5) {
            var4[var5] = this.field_193100_bx[1][var5].scale((double)1.0F - var2).add(this.field_193100_bx[0][var5].scale(var2));
         }

         return var4;
      }
   }

   public boolean isOnSameTeam(Entity var1) {
      if (super.isOnSameTeam(var1)) {
         return true;
      } else if (var1 instanceof EntityLivingBase && ((EntityLivingBase)var1).getCreatureAttribute() == EnumCreatureAttribute.ILLAGER) {
         return this.getTeam() == null && var1.getTeam() == null;
      } else {
         return false;
      }
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.field_193783_dc;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_193786_de;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_193787_df;
   }

   protected SoundEvent func_193086_dk() {
      return SoundEvents.field_193784_dd;
   }

   public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2) {
      EntityArrow var3 = this.func_193097_t(var2);
      double var4 = var1.posX - this.posX;
      double var6 = var1.getEntityBoundingBox().minY + (double)(var1.height / 3.0F) - var3.posY;
      double var8 = var1.posZ - this.posZ;
      double var10 = (double)MathHelper.sqrt(var4 * var4 + var8 * var8);
      var3.setThrowableHeading(var4, var6 + var10 * (double)0.2F, var8, 1.6F, (float)(14 - this.world.getDifficulty().getDifficultyId() * 4));
      this.playSound(SoundEvents.ENTITY_SKELETON_SHOOT, 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
      this.world.spawnEntityInWorld(var3);
   }

   protected EntityArrow func_193097_t(float var1) {
      EntityTippedArrow var2 = new EntityTippedArrow(this.world, this);
      var2.func_190547_a(this, var1);
      return var2;
   }

   public boolean func_193096_dj() {
      return this.func_193078_a(1);
   }

   public void setSwingingArms(boolean var1) {
      this.func_193079_a(1, var1);
   }

   public AbstractIllager.IllagerArmPose func_193077_p() {
      if (this.func_193082_dl()) {
         return AbstractIllager.IllagerArmPose.SPELLCASTING;
      } else {
         return this.func_193096_dj() ? AbstractIllager.IllagerArmPose.BOW_AND_ARROW : AbstractIllager.IllagerArmPose.CROSSED;
      }
   }

   class AIBlindnessSpell extends EntitySpellcasterIllager.AIUseSpell {
      private int field_193325_b;

      private AIBlindnessSpell() {
      }

      public boolean shouldExecute() {
         if (!super.shouldExecute()) {
            return false;
         } else if (EntityIllusionIllager.this.getAttackTarget() == null) {
            return false;
         } else {
            return EntityIllusionIllager.this.getAttackTarget().getEntityId() == this.field_193325_b ? false : EntityIllusionIllager.this.world.getDifficultyForLocation(new BlockPos(EntityIllusionIllager.this)).func_193845_a((float)EnumDifficulty.NORMAL.ordinal());
         }
      }

      public void startExecuting() {
         super.startExecuting();
         this.field_193325_b = EntityIllusionIllager.this.getAttackTarget().getEntityId();
      }

      protected int func_190869_f() {
         return 20;
      }

      protected int func_190872_i() {
         return 180;
      }

      protected void func_190868_j() {
         EntityIllusionIllager.this.getAttackTarget().addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 400));
      }

      protected SoundEvent func_190871_k() {
         return SoundEvents.field_193789_dh;
      }

      protected EntitySpellcasterIllager.SpellType func_193320_l() {
         return EntitySpellcasterIllager.SpellType.BLINDNESS;
      }

      AIBlindnessSpell(Object var2) {
         this();
      }
   }

   class AIMirriorSpell extends EntitySpellcasterIllager.AIUseSpell {
      private AIMirriorSpell() {
      }

      public boolean shouldExecute() {
         if (!super.shouldExecute()) {
            return false;
         } else {
            return !EntityIllusionIllager.this.isPotionActive(MobEffects.INVISIBILITY);
         }
      }

      protected int func_190869_f() {
         return 20;
      }

      protected int func_190872_i() {
         return 340;
      }

      protected void func_190868_j() {
         EntityIllusionIllager.this.addPotionEffect(new PotionEffect(MobEffects.INVISIBILITY, 1200));
      }

      @Nullable
      protected SoundEvent func_190871_k() {
         return SoundEvents.field_193790_di;
      }

      protected EntitySpellcasterIllager.SpellType func_193320_l() {
         return EntitySpellcasterIllager.SpellType.DISAPPEAR;
      }

      AIMirriorSpell(Object var2) {
         this();
      }
   }
}
