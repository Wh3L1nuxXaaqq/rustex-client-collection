package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityElderGuardian extends EntityGuardian {
   public EntityElderGuardian(World var1) {
      super(var1);
      this.setSize(this.width * 2.35F, this.height * 2.35F);
      this.enablePersistence();
      if (this.wander != null) {
         this.wander.setExecutionChance(400);
      }

   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.3F);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)8.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)80.0F);
   }

   public static void func_190768_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityElderGuardian.class);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_ELDER_GUARDIAN;
   }

   public int getAttackDuration() {
      return 60;
   }

   public void func_190767_di() {
      this.clientSideSpikesAnimation = 1.0F;
      this.clientSideSpikesAnimationO = this.clientSideSpikesAnimation;
   }

   protected SoundEvent getAmbientSound() {
      return this.isInWater() ? SoundEvents.ENTITY_ELDER_GUARDIAN_AMBIENT : SoundEvents.ENTITY_ELDERGUARDIAN_AMBIENTLAND;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return this.isInWater() ? SoundEvents.ENTITY_ELDER_GUARDIAN_HURT : SoundEvents.ENTITY_ELDER_GUARDIAN_HURT_LAND;
   }

   protected SoundEvent getDeathSound() {
      return this.isInWater() ? SoundEvents.ENTITY_ELDER_GUARDIAN_DEATH : SoundEvents.ENTITY_ELDER_GUARDIAN_DEATH_LAND;
   }

   protected SoundEvent func_190765_dj() {
      return SoundEvents.field_191240_aK;
   }

   protected void updateAITasks() {
      super.updateAITasks();
      boolean var1 = true;
      if ((this.ticksExisted + this.getEntityId()) % 1200 == 0) {
         Potion var2 = MobEffects.MINING_FATIGUE;
         List var3 = this.world.getPlayers(EntityPlayerMP.class, new Predicate<EntityPlayerMP>() {
            public boolean apply(@Nullable EntityPlayerMP var1) {
               return EntityElderGuardian.this.getDistanceSqToEntity(var1) < (double)2500.0F && var1.interactionManager.survivalOrAdventure();
            }
         });
         boolean var4 = true;
         boolean var5 = true;
         boolean var6 = true;

         for(Object var8_raw : var3) {
            EntityPlayerMP var8 = (EntityPlayerMP)var8_raw;
            if (!var8.isPotionActive(var2) || var8.getActivePotionEffect(var2).getAmplifier() < 2 || var8.getActivePotionEffect(var2).getDuration() < 1200) {
               var8.connection.sendPacket(new SPacketChangeGameState(10, 0.0F));
               var8.addPotionEffect(new PotionEffect(var2, 6000, 2));
            }
         }
      }

      if (!this.hasHome()) {
         this.setHomePosAndDistance(new BlockPos(this), 16);
      }

   }
}
