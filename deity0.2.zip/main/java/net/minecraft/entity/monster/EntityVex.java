package net.minecraft.entity.monster;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITarget;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityVex extends EntityMob {
   protected static final DataParameter<Byte> field_190664_a;
   private EntityLiving field_190665_b;
   @Nullable
   private BlockPos field_190666_c;
   private boolean field_190667_bw;
   private int field_190668_bx;

   public EntityVex(World var1) {
      super(var1);
      this.isImmuneToFire = true;
      this.moveHelper = new AIMoveControl(this);
      this.setSize(0.4F, 0.8F);
      this.experienceValue = 3;
   }

   public void moveEntity(MoverType var1, double var2, double var4, double var6) {
      super.moveEntity(var1, var2, var4, var6);
      this.doBlockCollisions();
   }

   public void onUpdate() {
      this.noClip = true;
      super.onUpdate();
      this.noClip = false;
      this.setNoGravity(true);
      if (this.field_190667_bw && --this.field_190668_bx <= 0) {
         this.field_190668_bx = 20;
         this.attackEntityFrom(DamageSource.starve, 1.0F);
      }

   }

   protected void initEntityAI() {
      super.initEntityAI();
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(4, new AIChargeAttack());
      this.tasks.addTask(8, new AIMoveRandom());
      this.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 3.0F, 1.0F));
      this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[]{EntityVex.class}));
      this.targetTasks.addTask(2, new AICopyOwnerTarget(this));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)14.0F);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)4.0F);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_190664_a, (byte)0);
   }

   public static void func_190663_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityVex.class);
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.hasKey("BoundX")) {
         this.field_190666_c = new BlockPos(var1.getInteger("BoundX"), var1.getInteger("BoundY"), var1.getInteger("BoundZ"));
      }

      if (var1.hasKey("LifeTicks")) {
         this.func_190653_a(var1.getInteger("LifeTicks"));
      }

   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      if (this.field_190666_c != null) {
         var1.setInteger("BoundX", this.field_190666_c.getX());
         var1.setInteger("BoundY", this.field_190666_c.getY());
         var1.setInteger("BoundZ", this.field_190666_c.getZ());
      }

      if (this.field_190667_bw) {
         var1.setInteger("LifeTicks", this.field_190668_bx);
      }

   }

   public EntityLiving func_190645_o() {
      return this.field_190665_b;
   }

   @Nullable
   public BlockPos func_190646_di() {
      return this.field_190666_c;
   }

   public void func_190651_g(@Nullable BlockPos var1) {
      this.field_190666_c = var1;
   }

   private boolean func_190656_b(int var1) {
      byte var2 = (Byte)this.dataManager.get(field_190664_a);
      return (var2 & var1) != 0;
   }

   private void func_190660_a(int var1, boolean var2) {
      int var3 = (Byte)this.dataManager.get(field_190664_a);
      if (var2) {
         var3 |= var1;
      } else {
         var3 &= ~var1;
      }

      this.dataManager.set(field_190664_a, (byte)(var3 & 255));
   }

   public boolean func_190647_dj() {
      return this.func_190656_b(1);
   }

   public void func_190648_a(boolean var1) {
      this.func_190660_a(1, var1);
   }

   public void func_190658_a(EntityLiving var1) {
      this.field_190665_b = var1;
   }

   public void func_190653_a(int var1) {
      this.field_190667_bw = true;
      this.field_190668_bx = var1;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.field_191264_hc;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_191266_he;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_191267_hf;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191188_ax;
   }

   public int getBrightnessForRender() {
      return 15728880;
   }

   public float getBrightness() {
      return 1.0F;
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      this.setEquipmentBasedOnDifficulty(var1);
      this.setEnchantmentBasedOnDifficulty(var1);
      return super.onInitialSpawn(var1, var2);
   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
      this.setDropChance(EntityEquipmentSlot.MAINHAND, 0.0F);
   }

   static Random access$000(EntityVex var0) {
      return var0.rand;
   }

   static EntityMoveHelper access$100(EntityVex var0) {
      return var0.moveHelper;
   }

   static EntityMoveHelper access$200(EntityVex var0) {
      return var0.moveHelper;
   }

   static EntityLiving access$300(EntityVex var0) {
      return var0.field_190665_b;
   }

   static Random access$400(EntityVex var0) {
      return var0.rand;
   }

   static Random access$500(EntityVex var0) {
      return var0.rand;
   }

   static Random access$600(EntityVex var0) {
      return var0.rand;
   }

   static Random access$700(EntityVex var0) {
      return var0.rand;
   }

   static EntityMoveHelper access$800(EntityVex var0) {
      return var0.moveHelper;
   }

   static {
      field_190664_a = EntityDataManager.<Byte>createKey(EntityVex.class, DataSerializers.BYTE);
   }

   class AIChargeAttack extends EntityAIBase {
      public AIChargeAttack() {
         this.setMutexBits(1);
      }

      public boolean shouldExecute() {
         if (EntityVex.this.getAttackTarget() != null && !EntityVex.this.getMoveHelper().isUpdating() && EntityVex.access$000(EntityVex.this).nextInt(7) == 0) {
            return EntityVex.this.getDistanceSqToEntity(EntityVex.this.getAttackTarget()) > (double)4.0F;
         } else {
            return false;
         }
      }

      public boolean continueExecuting() {
         return EntityVex.this.getMoveHelper().isUpdating() && EntityVex.this.func_190647_dj() && EntityVex.this.getAttackTarget() != null && EntityVex.this.getAttackTarget().isEntityAlive();
      }

      public void startExecuting() {
         EntityLivingBase var1 = EntityVex.this.getAttackTarget();
         Vec3d var2 = var1.getPositionEyes(1.0F);
         EntityVex.access$100(EntityVex.this).setMoveTo(var2.xCoord, var2.yCoord, var2.zCoord, (double)1.0F);
         EntityVex.this.func_190648_a(true);
         EntityVex.this.playSound(SoundEvents.field_191265_hd, 1.0F, 1.0F);
      }

      public void resetTask() {
         EntityVex.this.func_190648_a(false);
      }

      public void updateTask() {
         EntityLivingBase var1 = EntityVex.this.getAttackTarget();
         if (EntityVex.this.getEntityBoundingBox().intersectsWith(var1.getEntityBoundingBox())) {
            EntityVex.this.attackEntityAsMob(var1);
            EntityVex.this.func_190648_a(false);
         } else {
            double var2 = EntityVex.this.getDistanceSqToEntity(var1);
            if (var2 < (double)9.0F) {
               Vec3d var4 = var1.getPositionEyes(1.0F);
               EntityVex.access$200(EntityVex.this).setMoveTo(var4.xCoord, var4.yCoord, var4.zCoord, (double)1.0F);
            }
         }

      }
   }

   class AICopyOwnerTarget extends EntityAITarget {
      public AICopyOwnerTarget(EntityCreature var2) {
         super(var2, false);
      }

      public boolean shouldExecute() {
         return EntityVex.access$300(EntityVex.this) != null && EntityVex.access$300(EntityVex.this).getAttackTarget() != null && this.isSuitableTarget(EntityVex.access$300(EntityVex.this).getAttackTarget(), false);
      }

      public void startExecuting() {
         EntityVex.this.setAttackTarget(EntityVex.access$300(EntityVex.this).getAttackTarget());
         super.startExecuting();
      }
   }

   class AIMoveControl extends EntityMoveHelper {
      public AIMoveControl(EntityVex var2) {
         super(var2);
      }

      public void onUpdateMoveHelper() {
         if (this.action == EntityMoveHelper.Action.MOVE_TO) {
            double var1 = this.posX - EntityVex.this.posX;
            double var3 = this.posY - EntityVex.this.posY;
            double var5 = this.posZ - EntityVex.this.posZ;
            double var7 = var1 * var1 + var3 * var3 + var5 * var5;
            var7 = (double)MathHelper.sqrt(var7);
            if (var7 < EntityVex.this.getEntityBoundingBox().getAverageEdgeLength()) {
               this.action = EntityMoveHelper.Action.WAIT;
               EntityVex var10000 = EntityVex.this;
               var10000.motionX *= (double)0.5F;
               var10000 = EntityVex.this;
               var10000.motionY *= (double)0.5F;
               var10000 = EntityVex.this;
               var10000.motionZ *= (double)0.5F;
            } else {
               EntityVex var16 = EntityVex.this;
               var16.motionX += var1 / var7 * 0.05 * this.speed;
               var16 = EntityVex.this;
               var16.motionY += var3 / var7 * 0.05 * this.speed;
               var16 = EntityVex.this;
               var16.motionZ += var5 / var7 * 0.05 * this.speed;
               if (EntityVex.this.getAttackTarget() == null) {
                  EntityVex.this.rotationYaw = -((float)MathHelper.atan2(EntityVex.this.motionX, EntityVex.this.motionZ)) * (180F / (float)Math.PI);
                  EntityVex.this.renderYawOffset = EntityVex.this.rotationYaw;
               } else {
                  double var9 = EntityVex.this.getAttackTarget().posX - EntityVex.this.posX;
                  double var11 = EntityVex.this.getAttackTarget().posZ - EntityVex.this.posZ;
                  EntityVex.this.rotationYaw = -((float)MathHelper.atan2(var9, var11)) * (180F / (float)Math.PI);
                  EntityVex.this.renderYawOffset = EntityVex.this.rotationYaw;
               }
            }
         }

      }
   }

   class AIMoveRandom extends EntityAIBase {
      public AIMoveRandom() {
         this.setMutexBits(1);
      }

      public boolean shouldExecute() {
         return !EntityVex.this.getMoveHelper().isUpdating() && EntityVex.access$400(EntityVex.this).nextInt(7) == 0;
      }

      public boolean continueExecuting() {
         return false;
      }

      public void updateTask() {
         BlockPos var1 = EntityVex.this.func_190646_di();
         if (var1 == null) {
            var1 = new BlockPos(EntityVex.this);
         }

         for(int var2 = 0; var2 < 3; ++var2) {
            BlockPos var3 = var1.add(EntityVex.access$500(EntityVex.this).nextInt(15) - 7, EntityVex.access$600(EntityVex.this).nextInt(11) - 5, EntityVex.access$700(EntityVex.this).nextInt(15) - 7);
            if (EntityVex.this.world.isAirBlock(var3)) {
               EntityVex.access$800(EntityVex.this).setMoveTo((double)var3.getX() + (double)0.5F, (double)var3.getY() + (double)0.5F, (double)var3.getZ() + (double)0.5F, (double)0.25F);
               if (EntityVex.this.getAttackTarget() == null) {
                  EntityVex.this.getLookHelper().setLookPosition((double)var3.getX() + (double)0.5F, (double)var3.getY() + (double)0.5F, (double)var3.getZ() + (double)0.5F, 180.0F, 20.0F);
               }
               break;
            }
         }

      }
   }
}
