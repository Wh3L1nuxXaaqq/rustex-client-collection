package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntitySpectralArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntitySkeleton extends AbstractSkeleton {
   public EntitySkeleton(World var1) {
      super(var1);
   }

   public static void registerFixesSkeleton(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntitySkeleton.class);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_SKELETON;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_SKELETON_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_SKELETON_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_SKELETON_DEATH;
   }

   SoundEvent func_190727_o() {
      return SoundEvents.ENTITY_SKELETON_STEP;
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (var1.getEntity() instanceof EntityCreeper) {
         EntityCreeper var2 = (EntityCreeper)var1.getEntity();
         if (var2.getPowered() && var2.isAIEnabled()) {
            var2.incrementDroppedSkulls();
            this.entityDropItem(new ItemStack(Items.SKULL, 1, 0), 0.0F);
         }
      }

   }

   protected EntityArrow func_190726_a(float var1) {
      ItemStack var2 = this.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND);
      if (var2.getItem() == Items.SPECTRAL_ARROW) {
         EntitySpectralArrow var4 = new EntitySpectralArrow(this.world, this);
         var4.func_190547_a(this, var1);
         return var4;
      } else {
         EntityArrow var3 = super.func_190726_a(var1);
         if (var2.getItem() == Items.TIPPED_ARROW && var3 instanceof EntityTippedArrow) {
            ((EntityTippedArrow)var3).setPotionEffect(var2);
         }

         return var3;
      }
   }
}
