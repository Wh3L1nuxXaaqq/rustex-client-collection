package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackRanged;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntitySnowman extends EntityGolem implements IRangedAttackMob {
   private static final DataParameter<Byte> PUMPKIN_EQUIPPED;

   public EntitySnowman(World var1) {
      super(var1);
      this.setSize(0.7F, 1.9F);
   }

   public static void registerFixesSnowman(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntitySnowman.class);
   }

   protected void initEntityAI() {
      this.tasks.addTask(1, new EntityAIAttackRanged(this, (double)1.25F, 20, 10.0F));
      this.tasks.addTask(2, new EntityAIWanderAvoidWater(this, (double)1.0F, 1.0000001E-5F));
      this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      this.tasks.addTask(4, new EntityAILookIdle(this));
      this.targetTasks.addTask(1, new EntityAINearestAttackableTarget(this, EntityLiving.class, 10, true, false, IMob.MOB_SELECTOR));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)4.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.2F);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(PUMPKIN_EQUIPPED, (byte)16);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("Pumpkin", this.isPumpkinEquipped());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.hasKey("Pumpkin")) {
         this.setPumpkinEquipped(var1.getBoolean("Pumpkin"));
      }

   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if (!this.world.isRemote) {
         int var1 = MathHelper.floor(this.posX);
         int var2 = MathHelper.floor(this.posY);
         int var3 = MathHelper.floor(this.posZ);
         if (this.isWet()) {
            this.attackEntityFrom(DamageSource.drown, 1.0F);
         }

         if (this.world.getBiome(new BlockPos(var1, 0, var3)).getFloatTemperature(new BlockPos(var1, var2, var3)) > 1.0F) {
            this.attackEntityFrom(DamageSource.onFire, 1.0F);
         }

         if (!this.world.getGameRules().getBoolean("mobGriefing")) {
            return;
         }

         for(int var4 = 0; var4 < 4; ++var4) {
            var1 = MathHelper.floor(this.posX + (double)((float)(var4 % 2 * 2 - 1) * 0.25F));
            var2 = MathHelper.floor(this.posY);
            var3 = MathHelper.floor(this.posZ + (double)((float)(var4 / 2 % 2 * 2 - 1) * 0.25F));
            BlockPos var5 = new BlockPos(var1, var2, var3);
            if (this.world.getBlockState(var5).getMaterial() == Material.AIR && this.world.getBiome(var5).getFloatTemperature(var5) < 0.8F && Blocks.SNOW_LAYER.canPlaceBlockAt(this.world, var5)) {
               this.world.setBlockState(var5, Blocks.SNOW_LAYER.getDefaultState());
            }
         }
      }

   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_SNOWMAN;
   }

   public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2) {
      EntitySnowball var3 = new EntitySnowball(this.world, this);
      double var4 = var1.posY + (double)var1.getEyeHeight() - (double)1.1F;
      double var6 = var1.posX - this.posX;
      double var8 = var4 - var3.posY;
      double var10 = var1.posZ - this.posZ;
      float var12 = MathHelper.sqrt(var6 * var6 + var10 * var10) * 0.2F;
      var3.setThrowableHeading(var6, var8 + (double)var12, var10, 1.6F, 12.0F);
      this.playSound(SoundEvents.ENTITY_SNOWMAN_SHOOT, 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
      this.world.spawnEntityInWorld(var3);
   }

   public float getEyeHeight() {
      return 1.7F;
   }

   protected boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (var3.getItem() == Items.SHEARS && this.isPumpkinEquipped() && !this.world.isRemote) {
         this.setPumpkinEquipped(false);
         var3.damageItem(1, var1);
      }

      return super.processInteract(var1, var2);
   }

   public boolean isPumpkinEquipped() {
      return ((Byte)this.dataManager.get(PUMPKIN_EQUIPPED) & 16) != 0;
   }

   public void setPumpkinEquipped(boolean var1) {
      byte var2 = (Byte)this.dataManager.get(PUMPKIN_EQUIPPED);
      if (var1) {
         this.dataManager.set(PUMPKIN_EQUIPPED, (byte)(var2 | 16));
      } else {
         this.dataManager.set(PUMPKIN_EQUIPPED, (byte)(var2 & -17));
      }

   }

   @Nullable
   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_SNOWMAN_AMBIENT;
   }

   @Nullable
   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_SNOWMAN_HURT;
   }

   @Nullable
   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_SNOWMAN_DEATH;
   }

   public void setSwingingArms(boolean var1) {
   }

   static {
      PUMPKIN_EQUIPPED = EntityDataManager.<Byte>createKey(EntitySnowman.class, DataSerializers.BYTE);
   }
}
