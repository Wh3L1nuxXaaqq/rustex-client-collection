package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityEvoker extends EntitySpellcasterIllager {
   private EntitySheep field_190763_bw;

   public EntityEvoker(World var1) {
      super(var1);
      this.setSize(0.6F, 1.95F);
      this.experienceValue = 10;
   }

   protected void initEntityAI() {
      super.initEntityAI();
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(1, new AICastingSpell());
      this.tasks.addTask(2, new EntityAIAvoidEntity(this, EntityPlayer.class, 8.0F, 0.6, (double)1.0F));
      this.tasks.addTask(4, new AISummonSpell());
      this.tasks.addTask(5, new AIAttackSpell());
      this.tasks.addTask(6, new AIWololoSpell());
      this.tasks.addTask(8, new EntityAIWander(this, 0.6));
      this.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 3.0F, 1.0F));
      this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[]{EntityEvoker.class}));
      this.targetTasks.addTask(2, (new EntityAINearestAttackableTarget(this, EntityPlayer.class, true)).func_190882_b(300));
      this.targetTasks.addTask(3, (new EntityAINearestAttackableTarget(this, EntityVillager.class, false)).func_190882_b(300));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityIronGolem.class, false));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.5F);
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)12.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)24.0F);
   }

   protected void entityInit() {
      super.entityInit();
   }

   public static void func_190759_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityEvoker.class);
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
   }

   protected ResourceLocation getLootTable() {
      return LootTableList.field_191185_au;
   }

   protected void updateAITasks() {
      super.updateAITasks();
   }

   public void onUpdate() {
      super.onUpdate();
   }

   public boolean isOnSameTeam(Entity var1) {
      if (var1 == null) {
         return false;
      } else if (var1 == this) {
         return true;
      } else if (super.isOnSameTeam(var1)) {
         return true;
      } else if (var1 instanceof EntityVex) {
         return this.isOnSameTeam(((EntityVex)var1).func_190645_o());
      } else if (var1 instanceof EntityLivingBase && ((EntityLivingBase)var1).getCreatureAttribute() == EnumCreatureAttribute.ILLAGER) {
         return this.getTeam() == null && var1.getTeam() == null;
      } else {
         return false;
      }
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.field_191243_bm;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_191245_bo;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_191246_bp;
   }

   private void func_190748_a(@Nullable EntitySheep var1) {
      this.field_190763_bw = var1;
   }

   @Nullable
   private EntitySheep func_190751_dj() {
      return this.field_190763_bw;
   }

   protected SoundEvent func_193086_dk() {
      return SoundEvents.field_191244_bn;
   }

   static EntitySheep access$300(EntityEvoker var0) {
      return var0.func_190751_dj();
   }

   static Random access$400(EntityEvoker var0) {
      return var0.rand;
   }

   static Random access$500(EntityEvoker var0) {
      return var0.rand;
   }

   static Random access$600(EntityEvoker var0) {
      return var0.rand;
   }

   static Random access$700(EntityEvoker var0) {
      return var0.rand;
   }

   static Random access$800(EntityEvoker var0) {
      return var0.rand;
   }

   static void access$900(EntityEvoker var0, EntitySheep var1) {
      var0.func_190748_a(var1);
   }

   class AIAttackSpell extends EntitySpellcasterIllager.AIUseSpell {
      private AIAttackSpell() {
      }

      protected int func_190869_f() {
         return 40;
      }

      protected int func_190872_i() {
         return 100;
      }

      protected void func_190868_j() {
         EntityLivingBase var1 = EntityEvoker.this.getAttackTarget();
         double var2 = Math.min(var1.posY, EntityEvoker.this.posY);
         double var4 = Math.max(var1.posY, EntityEvoker.this.posY) + (double)1.0F;
         float var6 = (float)MathHelper.atan2(var1.posZ - EntityEvoker.this.posZ, var1.posX - EntityEvoker.this.posX);
         if (EntityEvoker.this.getDistanceSqToEntity(var1) < (double)9.0F) {
            for(int var7 = 0; var7 < 5; ++var7) {
               float var8 = var6 + (float)var7 * (float)Math.PI * 0.4F;
               this.func_190876_a(EntityEvoker.this.posX + (double)MathHelper.cos(var8) * (double)1.5F, EntityEvoker.this.posZ + (double)MathHelper.sin(var8) * (double)1.5F, var2, var4, var8, 0);
            }

            for(int var11 = 0; var11 < 8; ++var11) {
               float var13 = var6 + (float)var11 * (float)Math.PI * 2.0F / 8.0F + 1.2566371F;
               this.func_190876_a(EntityEvoker.this.posX + (double)MathHelper.cos(var13) * (double)2.5F, EntityEvoker.this.posZ + (double)MathHelper.sin(var13) * (double)2.5F, var2, var4, var13, 3);
            }
         } else {
            for(int var12 = 0; var12 < 16; ++var12) {
               double var14 = (double)1.25F * (double)(var12 + 1);
               int var10 = 1 * var12;
               this.func_190876_a(EntityEvoker.this.posX + (double)MathHelper.cos(var6) * var14, EntityEvoker.this.posZ + (double)MathHelper.sin(var6) * var14, var2, var4, var6, var10);
            }
         }

      }

      private void func_190876_a(double var1, double var3, double var5, double var7, float var9, int var10) {
         BlockPos var11 = new BlockPos(var1, var7, var3);
         boolean var12 = false;
         double var13 = (double)0.0F;

         do {
            if (!EntityEvoker.this.world.isBlockNormalCube(var11, true) && EntityEvoker.this.world.isBlockNormalCube(var11.down(), true)) {
               if (!EntityEvoker.this.world.isAirBlock(var11)) {
                  IBlockState var15 = EntityEvoker.this.world.getBlockState(var11);
                  AxisAlignedBB var16 = var15.getCollisionBoundingBox(EntityEvoker.this.world, var11);
                  if (var16 != null) {
                     var13 = var16.maxY;
                  }
               }

               var12 = true;
               break;
            }

            var11 = var11.down();
         } while(var11.getY() >= MathHelper.floor(var5) - 1);

         if (var12) {
            EntityEvokerFangs var17 = new EntityEvokerFangs(EntityEvoker.this.world, var1, (double)var11.getY() + var13, var3, var9, var10, EntityEvoker.this);
            EntityEvoker.this.world.spawnEntityInWorld(var17);
         }

      }

      protected SoundEvent func_190871_k() {
         return SoundEvents.field_191247_bq;
      }

      protected EntitySpellcasterIllager.SpellType func_193320_l() {
         return EntitySpellcasterIllager.SpellType.FANGS;
      }

      AIAttackSpell(Object var2) {
         this();
      }
   }

   class AICastingSpell extends EntitySpellcasterIllager.AICastingApell {
      private AICastingSpell() {
      }

      public void updateTask() {
         if (EntityEvoker.this.getAttackTarget() != null) {
            EntityEvoker.this.getLookHelper().setLookPositionWithEntity(EntityEvoker.this.getAttackTarget(), (float)EntityEvoker.this.getHorizontalFaceSpeed(), (float)EntityEvoker.this.getVerticalFaceSpeed());
         } else if (EntityEvoker.access$300(EntityEvoker.this) != null) {
            EntityEvoker.this.getLookHelper().setLookPositionWithEntity(EntityEvoker.access$300(EntityEvoker.this), (float)EntityEvoker.this.getHorizontalFaceSpeed(), (float)EntityEvoker.this.getVerticalFaceSpeed());
         }

      }

      AICastingSpell(Object var2) {
         this();
      }
   }

   class AISummonSpell extends EntitySpellcasterIllager.AIUseSpell {
      private AISummonSpell() {
      }

      public boolean shouldExecute() {
         if (!super.shouldExecute()) {
            return false;
         } else {
            int var1 = EntityEvoker.this.world.getEntitiesWithinAABB(EntityVex.class, EntityEvoker.this.getEntityBoundingBox().expandXyz((double)16.0F)).size();
            return EntityEvoker.access$400(EntityEvoker.this).nextInt(8) + 1 > var1;
         }
      }

      protected int func_190869_f() {
         return 100;
      }

      protected int func_190872_i() {
         return 340;
      }

      protected void func_190868_j() {
         for(int var1 = 0; var1 < 3; ++var1) {
            BlockPos var2 = (new BlockPos(EntityEvoker.this)).add(-2 + EntityEvoker.access$500(EntityEvoker.this).nextInt(5), 1, -2 + EntityEvoker.access$600(EntityEvoker.this).nextInt(5));
            EntityVex var3 = new EntityVex(EntityEvoker.this.world);
            var3.moveToBlockPosAndAngles(var2, 0.0F, 0.0F);
            var3.onInitialSpawn(EntityEvoker.this.world.getDifficultyForLocation(var2), (IEntityLivingData)null);
            var3.func_190658_a(EntityEvoker.this);
            var3.func_190651_g(var2);
            var3.func_190653_a(20 * (30 + EntityEvoker.access$700(EntityEvoker.this).nextInt(90)));
            EntityEvoker.this.world.spawnEntityInWorld(var3);
         }

      }

      protected SoundEvent func_190871_k() {
         return SoundEvents.field_191248_br;
      }

      protected EntitySpellcasterIllager.SpellType func_193320_l() {
         return EntitySpellcasterIllager.SpellType.SUMMON_VEX;
      }

      AISummonSpell(Object var2) {
         this();
      }
   }

   public class AIWololoSpell extends EntitySpellcasterIllager.AIUseSpell {
      final Predicate<EntitySheep> field_190879_a = new Predicate<EntitySheep>() {
         public boolean apply(EntitySheep var1) {
            return var1.getFleeceColor() == EnumDyeColor.BLUE;
         }
      };

      public boolean shouldExecute() {
         if (EntityEvoker.this.getAttackTarget() != null) {
            return false;
         } else if (EntityEvoker.this.func_193082_dl()) {
            return false;
         } else if (EntityEvoker.this.ticksExisted < this.field_193322_d) {
            return false;
         } else if (!EntityEvoker.this.world.getGameRules().getBoolean("mobGriefing")) {
            return false;
         } else {
            List var1 = EntityEvoker.this.world.getEntitiesWithinAABB(EntitySheep.class, EntityEvoker.this.getEntityBoundingBox().expand((double)16.0F, (double)4.0F, (double)16.0F), this.field_190879_a);
            if (var1.isEmpty()) {
               return false;
            } else {
               EntityEvoker.access$900(EntityEvoker.this, (EntitySheep)var1.get(EntityEvoker.access$800(EntityEvoker.this).nextInt(var1.size())));
               return true;
            }
         }
      }

      public boolean continueExecuting() {
         return EntityEvoker.access$300(EntityEvoker.this) != null && this.field_193321_c > 0;
      }

      public void resetTask() {
         super.resetTask();
         EntityEvoker.access$900(EntityEvoker.this, (EntitySheep)null);
      }

      protected void func_190868_j() {
         EntitySheep var1 = EntityEvoker.access$300(EntityEvoker.this);
         if (var1 != null && var1.isEntityAlive()) {
            var1.setFleeceColor(EnumDyeColor.RED);
         }

      }

      protected int func_190867_m() {
         return 40;
      }

      protected int func_190869_f() {
         return 60;
      }

      protected int func_190872_i() {
         return 140;
      }

      protected SoundEvent func_190871_k() {
         return SoundEvents.field_191249_bs;
      }

      protected EntitySpellcasterIllager.SpellType func_193320_l() {
         return EntitySpellcasterIllager.SpellType.WOLOLO;
      }
   }
}
