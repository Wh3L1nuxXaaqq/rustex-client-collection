package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityVindicator extends AbstractIllager {
   private boolean field_190643_b;
   private static final Predicate<Entity> field_190644_c = new Predicate<Entity>() {
      public boolean apply(@Nullable Entity var1) {
         return var1 instanceof EntityLivingBase && ((EntityLivingBase)var1).func_190631_cK();
      }
   };

   public EntityVindicator(World var1) {
      super(var1);
      this.setSize(0.6F, 1.95F);
   }

   public static void func_190641_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityVindicator.class);
   }

   protected void initEntityAI() {
      super.initEntityAI();
      this.tasks.addTask(0, new EntityAISwimming(this));
      this.tasks.addTask(4, new EntityAIAttackMelee(this, (double)1.0F, false));
      this.tasks.addTask(8, new EntityAIWander(this, 0.6));
      this.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 3.0F, 1.0F));
      this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[]{EntityVindicator.class}));
      this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityVillager.class, true));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityIronGolem.class, true));
      this.targetTasks.addTask(4, new AIJohnnyAttack(this));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.35F);
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)12.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)24.0F);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)5.0F);
   }

   protected void entityInit() {
      super.entityInit();
   }

   protected ResourceLocation getLootTable() {
      return LootTableList.field_191186_av;
   }

   public boolean func_190639_o() {
      return this.func_193078_a(1);
   }

   public void func_190636_a(boolean var1) {
      this.func_193079_a(1, var1);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      if (this.field_190643_b) {
         var1.setBoolean("Johnny", true);
      }

   }

   public AbstractIllager.IllagerArmPose func_193077_p() {
      return this.func_190639_o() ? AbstractIllager.IllagerArmPose.ATTACKING : AbstractIllager.IllagerArmPose.CROSSED;
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.hasKey("Johnny", 99)) {
         this.field_190643_b = var1.getBoolean("Johnny");
      }

   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      IEntityLivingData var3 = super.onInitialSpawn(var1, var2);
      this.setEquipmentBasedOnDifficulty(var1);
      this.setEnchantmentBasedOnDifficulty(var1);
      return var3;
   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
   }

   protected void updateAITasks() {
      super.updateAITasks();
      this.func_190636_a(this.getAttackTarget() != null);
   }

   public boolean isOnSameTeam(Entity var1) {
      if (super.isOnSameTeam(var1)) {
         return true;
      } else if (var1 instanceof EntityLivingBase && ((EntityLivingBase)var1).getCreatureAttribute() == EnumCreatureAttribute.ILLAGER) {
         return this.getTeam() == null && var1.getTeam() == null;
      } else {
         return false;
      }
   }

   public void setCustomNameTag(String var1) {
      super.setCustomNameTag(var1);
      if (!this.field_190643_b && "Johnny".equals(var1)) {
         this.field_190643_b = true;
      }

   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.field_191268_hm;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.field_191269_hn;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.field_191270_ho;
   }

   static Predicate access$000() {
      return field_190644_c;
   }

   static boolean access$100(EntityVindicator var0) {
      return var0.field_190643_b;
   }

   static class AIJohnnyAttack extends EntityAINearestAttackableTarget<EntityLivingBase> {
      public AIJohnnyAttack(EntityVindicator var1) {
         super(var1, EntityLivingBase.class, 0, true, true, EntityVindicator.access$000());
      }

      public boolean shouldExecute() {
         return EntityVindicator.access$100((EntityVindicator)this.taskOwner) && super.shouldExecute();
      }
   }
}
