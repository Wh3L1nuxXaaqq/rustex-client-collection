package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityWitherSkeleton extends AbstractSkeleton {
   public EntityWitherSkeleton(World var1) {
      super(var1);
      this.setSize(0.7F, 2.4F);
      this.isImmuneToFire = true;
   }

   public static void func_190729_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityWitherSkeleton.class);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_WITHER_SKELETON;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_WITHER_SKELETON_AMBIENT;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_WITHER_SKELETON_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_WITHER_SKELETON_DEATH;
   }

   SoundEvent func_190727_o() {
      return SoundEvents.ENTITY_WITHER_SKELETON_STEP;
   }

   public void onDeath(DamageSource var1) {
      super.onDeath(var1);
      if (var1.getEntity() instanceof EntityCreeper) {
         EntityCreeper var2 = (EntityCreeper)var1.getEntity();
         if (var2.getPowered() && var2.isAIEnabled()) {
            var2.incrementDroppedSkulls();
            this.entityDropItem(new ItemStack(Items.SKULL, 1, 1), 0.0F);
         }
      }

   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
   }

   protected void setEnchantmentBasedOnDifficulty(DifficultyInstance var1) {
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      IEntityLivingData var3 = super.onInitialSpawn(var1, var2);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)4.0F);
      this.setCombatTask();
      return var3;
   }

   public float getEyeHeight() {
      return 2.1F;
   }

   public boolean attackEntityAsMob(Entity var1) {
      if (!super.attackEntityAsMob(var1)) {
         return false;
      } else {
         if (var1 instanceof EntityLivingBase) {
            ((EntityLivingBase)var1).addPotionEffect(new PotionEffect(MobEffects.WITHER, 200));
         }

         return true;
      }
   }

   protected EntityArrow func_190726_a(float var1) {
      EntityArrow var2 = super.func_190726_a(var1);
      var2.setFire(100);
      return var2;
   }
}
