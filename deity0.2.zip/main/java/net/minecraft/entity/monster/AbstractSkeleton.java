package net.minecraft.entity.monster;

import java.util.Calendar;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIAttackRangedBow;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIFleeSun;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIRestrictSun;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public abstract class AbstractSkeleton extends EntityMob implements IRangedAttackMob {
   private static final DataParameter<Boolean> SWINGING_ARMS;
   private final EntityAIAttackRangedBow<AbstractSkeleton> aiArrowAttack = new EntityAIAttackRangedBow<AbstractSkeleton>(this, (double)1.0F, 20, 15.0F);
   private final EntityAIAttackMelee aiAttackOnCollide = new EntityAIAttackMelee(this, 1.2, false) {
      public void resetTask() {
         super.resetTask();
         AbstractSkeleton.this.setSwingingArms(false);
      }

      public void startExecuting() {
         super.startExecuting();
         AbstractSkeleton.this.setSwingingArms(true);
      }
   };

   public AbstractSkeleton(World var1) {
      super(var1);
      this.setSize(0.6F, 1.99F);
      this.setCombatTask();
   }

   protected void initEntityAI() {
      this.tasks.addTask(1, new EntityAISwimming(this));
      this.tasks.addTask(2, new EntityAIRestrictSun(this));
      this.tasks.addTask(3, new EntityAIFleeSun(this, (double)1.0F));
      this.tasks.addTask(3, new EntityAIAvoidEntity(this, EntityWolf.class, 6.0F, (double)1.0F, 1.2));
      this.tasks.addTask(5, new EntityAIWanderAvoidWater(this, (double)1.0F));
      this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      this.tasks.addTask(6, new EntityAILookIdle(this));
      this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false, new Class[0]));
      this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));
      this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityIronGolem.class, true));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.25F);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(SWINGING_ARMS, false);
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      this.playSound(this.func_190727_o(), 0.15F, 1.0F);
   }

   abstract SoundEvent func_190727_o();

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.UNDEAD;
   }

   public void onLivingUpdate() {
      if (this.world.isDaytime() && !this.world.isRemote) {
         float var1 = this.getBrightness();
         BlockPos var2 = this.getRidingEntity() instanceof EntityBoat ? (new BlockPos(this.posX, (double)Math.round(this.posY), this.posZ)).up() : new BlockPos(this.posX, (double)Math.round(this.posY), this.posZ);
         if (var1 > 0.5F && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F && this.world.canSeeSky(var2)) {
            boolean var3 = true;
            ItemStack var4 = this.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
            if (!var4.func_190926_b()) {
               if (var4.isItemStackDamageable()) {
                  var4.setItemDamage(var4.getItemDamage() + this.rand.nextInt(2));
                  if (var4.getItemDamage() >= var4.getMaxDamage()) {
                     this.renderBrokenItemStack(var4);
                     this.setItemStackToSlot(EntityEquipmentSlot.HEAD, ItemStack.field_190927_a);
                  }
               }

               var3 = false;
            }

            if (var3) {
               this.setFire(8);
            }
         }
      }

      super.onLivingUpdate();
   }

   public void updateRidden() {
      super.updateRidden();
      if (this.getRidingEntity() instanceof EntityCreature) {
         EntityCreature var1 = (EntityCreature)this.getRidingEntity();
         this.renderYawOffset = var1.renderYawOffset;
      }

   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      super.setEquipmentBasedOnDifficulty(var1);
      this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      var2 = super.onInitialSpawn(var1, var2);
      this.setEquipmentBasedOnDifficulty(var1);
      this.setEnchantmentBasedOnDifficulty(var1);
      this.setCombatTask();
      this.setCanPickUpLoot(this.rand.nextFloat() < 0.55F * var1.getClampedAdditionalDifficulty());
      if (this.getItemStackFromSlot(EntityEquipmentSlot.HEAD).func_190926_b()) {
         Calendar var3 = this.world.getCurrentDate();
         if (var3.get(2) + 1 == 10 && var3.get(5) == 31 && this.rand.nextFloat() < 0.25F) {
            this.setItemStackToSlot(EntityEquipmentSlot.HEAD, new ItemStack(this.rand.nextFloat() < 0.1F ? Blocks.LIT_PUMPKIN : Blocks.PUMPKIN));
            this.inventoryArmorDropChances[EntityEquipmentSlot.HEAD.getIndex()] = 0.0F;
         }
      }

      return var2;
   }

   public void setCombatTask() {
      if (this.world != null && !this.world.isRemote) {
         this.tasks.removeTask(this.aiAttackOnCollide);
         this.tasks.removeTask(this.aiArrowAttack);
         ItemStack var1 = this.getHeldItemMainhand();
         if (var1.getItem() == Items.BOW) {
            byte var2 = 20;
            if (this.world.getDifficulty() != EnumDifficulty.HARD) {
               var2 = 40;
            }

            this.aiArrowAttack.setAttackCooldown(var2);
            this.tasks.addTask(4, this.aiArrowAttack);
         } else {
            this.tasks.addTask(4, this.aiAttackOnCollide);
         }
      }

   }

   public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2) {
      EntityArrow var3 = this.func_190726_a(var2);
      double var4 = var1.posX - this.posX;
      double var6 = var1.getEntityBoundingBox().minY + (double)(var1.height / 3.0F) - var3.posY;
      double var8 = var1.posZ - this.posZ;
      double var10 = (double)MathHelper.sqrt(var4 * var4 + var8 * var8);
      var3.setThrowableHeading(var4, var6 + var10 * (double)0.2F, var8, 1.6F, (float)(14 - this.world.getDifficulty().getDifficultyId() * 4));
      this.playSound(SoundEvents.ENTITY_SKELETON_SHOOT, 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
      this.world.spawnEntityInWorld(var3);
   }

   protected EntityArrow func_190726_a(float var1) {
      EntityTippedArrow var2 = new EntityTippedArrow(this.world, this);
      var2.func_190547_a(this, var1);
      return var2;
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.setCombatTask();
   }

   public void setItemStackToSlot(EntityEquipmentSlot var1, ItemStack var2) {
      super.setItemStackToSlot(var1, var2);
      if (!this.world.isRemote && var1 == EntityEquipmentSlot.MAINHAND) {
         this.setCombatTask();
      }

   }

   public float getEyeHeight() {
      return 1.74F;
   }

   public double getYOffset() {
      return -0.6;
   }

   public boolean isSwingingArms() {
      return (Boolean)this.dataManager.get(SWINGING_ARMS);
   }

   public void setSwingingArms(boolean var1) {
      this.dataManager.set(SWINGING_ARMS, var1);
   }

   static {
      SWINGING_ARMS = EntityDataManager.<Boolean>createKey(AbstractSkeleton.class, DataSerializers.BOOLEAN);
   }
}
