package net.minecraft.entity.monster;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityZombieVillager extends EntityZombie {
   private static final DataParameter<Boolean> CONVERTING;
   private static final DataParameter<Integer> field_190739_c;
   private int conversionTime;
   private UUID field_191992_by;

   public EntityZombieVillager(World var1) {
      super(var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(CONVERTING, false);
      this.dataManager.register(field_190739_c, 0);
   }

   public void func_190733_a(int var1) {
      this.dataManager.set(field_190739_c, var1);
   }

   public int func_190736_dl() {
      return Math.max((Integer)this.dataManager.get(field_190739_c) % 6, 0);
   }

   public static void func_190737_b(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityZombieVillager.class);
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("Profession", this.func_190736_dl());
      var1.setInteger("ConversionTime", this.isConverting() ? this.conversionTime : -1);
      if (this.field_191992_by != null) {
         var1.setUniqueId("ConversionPlayer", this.field_191992_by);
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.func_190733_a(var1.getInteger("Profession"));
      if (var1.hasKey("ConversionTime", 99) && var1.getInteger("ConversionTime") > -1) {
         this.func_191991_a(var1.hasUniqueId("ConversionPlayer") ? var1.getUniqueId("ConversionPlayer") : null, var1.getInteger("ConversionTime"));
      }

   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      this.func_190733_a(this.world.rand.nextInt(6));
      return super.onInitialSpawn(var1, var2);
   }

   public void onUpdate() {
      if (!this.world.isRemote && this.isConverting()) {
         int var1 = this.func_190735_dq();
         this.conversionTime -= var1;
         if (this.conversionTime <= 0) {
            this.func_190738_dp();
         }
      }

      super.onUpdate();
   }

   public boolean processInteract(EntityPlayer var1, EnumHand var2) {
      ItemStack var3 = var1.getHeldItem(var2);
      if (var3.getItem() == Items.GOLDEN_APPLE && var3.getMetadata() == 0 && this.isPotionActive(MobEffects.WEAKNESS)) {
         if (!var1.capabilities.isCreativeMode) {
            var3.func_190918_g(1);
         }

         if (!this.world.isRemote) {
            this.func_191991_a(var1.getUniqueID(), this.rand.nextInt(2401) + 3600);
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean canDespawn() {
      return !this.isConverting();
   }

   public boolean isConverting() {
      return (Boolean)this.getDataManager().get(CONVERTING);
   }

   protected void func_191991_a(@Nullable UUID var1, int var2) {
      this.field_191992_by = var1;
      this.conversionTime = var2;
      this.getDataManager().set(CONVERTING, true);
      this.removePotionEffect(MobEffects.WEAKNESS);
      this.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, var2, Math.min(this.world.getDifficulty().getDifficultyId() - 1, 0)));
      this.world.setEntityState(this, (byte)16);
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 16) {
         if (!this.isSilent()) {
            this.world.playSound(this.posX + (double)0.5F, this.posY + (double)0.5F, this.posZ + (double)0.5F, SoundEvents.ENTITY_ZOMBIE_VILLAGER_CURE, this.getSoundCategory(), 1.0F + this.rand.nextFloat(), this.rand.nextFloat() * 0.7F + 0.3F, false);
         }
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   protected void func_190738_dp() {
      EntityVillager var1 = new EntityVillager(this.world);
      var1.copyLocationAndAnglesFrom(this);
      var1.setProfession(this.func_190736_dl());
      var1.func_190672_a(this.world.getDifficultyForLocation(new BlockPos(var1)), (IEntityLivingData)null, false);
      var1.setLookingForHome();
      if (this.isChild()) {
         var1.setGrowingAge(-24000);
      }

      this.world.removeEntity(this);
      var1.setNoAI(this.isAIDisabled());
      if (this.hasCustomName()) {
         var1.setCustomNameTag(this.getCustomNameTag());
         var1.setAlwaysRenderNameTag(this.getAlwaysRenderNameTag());
      }

      this.world.spawnEntityInWorld(var1);
      if (this.field_191992_by != null) {
         EntityPlayer var2 = this.world.getPlayerEntityByUUID(this.field_191992_by);
         if (var2 instanceof EntityPlayerMP) {
            CriteriaTriggers.field_192137_q.func_192183_a((EntityPlayerMP)var2, this, var1);
         }
      }

      var1.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 200, 0));
      this.world.playEvent((EntityPlayer)null, 1027, new BlockPos((int)this.posX, (int)this.posY, (int)this.posZ), 0);
   }

   protected int func_190735_dq() {
      int var1 = 1;
      if (this.rand.nextFloat() < 0.01F) {
         int var2 = 0;
         BlockPos.MutableBlockPos var3 = new BlockPos.MutableBlockPos();

         for(int var4 = (int)this.posX - 4; var4 < (int)this.posX + 4 && var2 < 14; ++var4) {
            for(int var5 = (int)this.posY - 4; var5 < (int)this.posY + 4 && var2 < 14; ++var5) {
               for(int var6 = (int)this.posZ - 4; var6 < (int)this.posZ + 4 && var2 < 14; ++var6) {
                  Block var7 = this.world.getBlockState(var3.setPos(var4, var5, var6)).getBlock();
                  if (var7 == Blocks.IRON_BARS || var7 == Blocks.BED) {
                     if (this.rand.nextFloat() < 0.3F) {
                        ++var1;
                     }

                     ++var2;
                  }
               }
            }
         }
      }

      return var1;
   }

   protected float getSoundPitch() {
      return this.isChild() ? (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 2.0F : (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F;
   }

   public SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_ZOMBIE_VILLAGER_AMBIENT;
   }

   public SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_ZOMBIE_VILLAGER_HURT;
   }

   public SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_ZOMBIE_VILLAGER_DEATH;
   }

   public SoundEvent func_190731_di() {
      return SoundEvents.ENTITY_ZOMBIE_VILLAGER_STEP;
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.field_191183_as;
   }

   protected ItemStack func_190732_dj() {
      return ItemStack.field_190927_a;
   }

   static {
      CONVERTING = EntityDataManager.<Boolean>createKey(EntityZombieVillager.class, DataSerializers.BOOLEAN);
      field_190739_c = EntityDataManager.<Integer>createKey(EntityZombieVillager.class, DataSerializers.VARINT);
   }
}
