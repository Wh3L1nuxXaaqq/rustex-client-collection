package net.minecraft.entity.monster;

import javax.annotation.Nullable;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public abstract class EntitySpellcasterIllager extends AbstractIllager {
   private static final DataParameter<Byte> field_193088_c;
   protected int field_193087_b;
   private SpellType field_193089_bx;

   public EntitySpellcasterIllager(World var1) {
      super(var1);
      this.field_193089_bx = EntitySpellcasterIllager.SpellType.NONE;
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_193088_c, (byte)0);
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.field_193087_b = var1.getInteger("SpellTicks");
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setInteger("SpellTicks", this.field_193087_b);
   }

   public AbstractIllager.IllagerArmPose func_193077_p() {
      return this.func_193082_dl() ? AbstractIllager.IllagerArmPose.SPELLCASTING : AbstractIllager.IllagerArmPose.CROSSED;
   }

   public boolean func_193082_dl() {
      if (this.world.isRemote) {
         return (Byte)this.dataManager.get(field_193088_c) > 0;
      } else {
         return this.field_193087_b > 0;
      }
   }

   public void func_193081_a(SpellType var1) {
      this.field_193089_bx = var1;
      this.dataManager.set(field_193088_c, (byte)EntitySpellcasterIllager.SpellType.access$000(var1));
   }

   protected SpellType func_193083_dm() {
      return !this.world.isRemote ? this.field_193089_bx : EntitySpellcasterIllager.SpellType.func_193337_a((Byte)this.dataManager.get(field_193088_c));
   }

   protected void updateAITasks() {
      super.updateAITasks();
      if (this.field_193087_b > 0) {
         --this.field_193087_b;
      }

   }

   public void onUpdate() {
      super.onUpdate();
      if (this.world.isRemote && this.func_193082_dl()) {
         SpellType var1 = this.func_193083_dm();
         double var2 = EntitySpellcasterIllager.SpellType.access$100(var1)[0];
         double var4 = EntitySpellcasterIllager.SpellType.access$100(var1)[1];
         double var6 = EntitySpellcasterIllager.SpellType.access$100(var1)[2];
         float var8 = this.renderYawOffset * ((float)Math.PI / 180F) + MathHelper.cos((float)this.ticksExisted * 0.6662F) * 0.25F;
         float var9 = MathHelper.cos(var8);
         float var10 = MathHelper.sin(var8);
         this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + (double)var9 * 0.6, this.posY + 1.8, this.posZ + (double)var10 * 0.6, var2, var4, var6);
         this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX - (double)var9 * 0.6, this.posY + 1.8, this.posZ - (double)var10 * 0.6, var2, var4, var6);
      }

   }

   protected int func_193085_dn() {
      return this.field_193087_b;
   }

   protected abstract SoundEvent func_193086_dk();

   static PathNavigate access$200(EntitySpellcasterIllager var0) {
      return var0.navigator;
   }

   static {
      field_193088_c = EntityDataManager.<Byte>createKey(EntitySpellcasterIllager.class, DataSerializers.BYTE);
   }

   public class AICastingApell extends EntityAIBase {
      public AICastingApell() {
         this.setMutexBits(3);
      }

      public boolean shouldExecute() {
         return EntitySpellcasterIllager.this.func_193085_dn() > 0;
      }

      public void startExecuting() {
         super.startExecuting();
         EntitySpellcasterIllager.access$200(EntitySpellcasterIllager.this).clearPathEntity();
      }

      public void resetTask() {
         super.resetTask();
         EntitySpellcasterIllager.this.func_193081_a(EntitySpellcasterIllager.SpellType.NONE);
      }

      public void updateTask() {
         if (EntitySpellcasterIllager.this.getAttackTarget() != null) {
            EntitySpellcasterIllager.this.getLookHelper().setLookPositionWithEntity(EntitySpellcasterIllager.this.getAttackTarget(), (float)EntitySpellcasterIllager.this.getHorizontalFaceSpeed(), (float)EntitySpellcasterIllager.this.getVerticalFaceSpeed());
         }

      }
   }

   public abstract class AIUseSpell extends EntityAIBase {
      protected int field_193321_c;
      protected int field_193322_d;

      public boolean shouldExecute() {
         if (EntitySpellcasterIllager.this.getAttackTarget() == null) {
            return false;
         } else if (EntitySpellcasterIllager.this.func_193082_dl()) {
            return false;
         } else {
            return EntitySpellcasterIllager.this.ticksExisted >= this.field_193322_d;
         }
      }

      public boolean continueExecuting() {
         return EntitySpellcasterIllager.this.getAttackTarget() != null && this.field_193321_c > 0;
      }

      public void startExecuting() {
         this.field_193321_c = this.func_190867_m();
         EntitySpellcasterIllager.this.field_193087_b = this.func_190869_f();
         this.field_193322_d = EntitySpellcasterIllager.this.ticksExisted + this.func_190872_i();
         SoundEvent var1 = this.func_190871_k();
         if (var1 != null) {
            EntitySpellcasterIllager.this.playSound(var1, 1.0F, 1.0F);
         }

         EntitySpellcasterIllager.this.func_193081_a(this.func_193320_l());
      }

      public void updateTask() {
         --this.field_193321_c;
         if (this.field_193321_c == 0) {
            this.func_190868_j();
            EntitySpellcasterIllager.this.playSound(EntitySpellcasterIllager.this.func_193086_dk(), 1.0F, 1.0F);
         }

      }

      protected abstract void func_190868_j();

      protected int func_190867_m() {
         return 20;
      }

      protected abstract int func_190869_f();

      protected abstract int func_190872_i();

      @Nullable
      protected abstract SoundEvent func_190871_k();

      protected abstract SpellType func_193320_l();
   }

   public static enum SpellType {
      NONE(0, (double)0.0F, (double)0.0F, (double)0.0F),
      SUMMON_VEX(1, 0.7, 0.7, 0.8),
      FANGS(2, 0.4, 0.3, 0.35),
      WOLOLO(3, 0.7, (double)0.5F, 0.2),
      DISAPPEAR(4, 0.3, 0.3, 0.8),
      BLINDNESS(5, 0.1, 0.1, 0.2);

      private final int field_193345_g;
      private final double[] field_193346_h;

      private SpellType(int var3, double var4, double var6, double var8) {
         this.field_193345_g = var3;
         this.field_193346_h = new double[]{var4, var6, var8};
      }

      public static SpellType func_193337_a(int var0) {
         for(SpellType var4 : values()) {
            if (var0 == var4.field_193345_g) {
               return var4;
            }
         }

         return NONE;
      }

      static int access$000(SpellType var0) {
         return var0.field_193345_g;
      }

      static double[] access$100(SpellType var0) {
         return var0.field_193346_h;
      }
   }
}
