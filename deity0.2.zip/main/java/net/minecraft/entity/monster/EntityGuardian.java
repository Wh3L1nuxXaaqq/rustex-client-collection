package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateSwimmer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityGuardian extends EntityMob {
   private static final DataParameter<Boolean> field_190766_bz;
   private static final DataParameter<Integer> TARGET_ENTITY;
   protected float clientSideTailAnimation;
   protected float clientSideTailAnimationO;
   protected float clientSideTailAnimationSpeed;
   protected float clientSideSpikesAnimation;
   protected float clientSideSpikesAnimationO;
   private EntityLivingBase targetedEntity;
   private int clientSideAttackTime;
   private boolean clientSideTouchedGround;
   protected EntityAIWander wander;

   public EntityGuardian(World var1) {
      super(var1);
      this.experienceValue = 10;
      this.setSize(0.85F, 0.85F);
      this.moveHelper = new GuardianMoveHelper(this);
      this.clientSideTailAnimation = this.rand.nextFloat();
      this.clientSideTailAnimationO = this.clientSideTailAnimation;
   }

   protected void initEntityAI() {
      EntityAIMoveTowardsRestriction var1 = new EntityAIMoveTowardsRestriction(this, (double)1.0F);
      this.wander = new EntityAIWander(this, (double)1.0F, 80);
      this.tasks.addTask(4, new AIGuardianAttack(this));
      this.tasks.addTask(5, var1);
      this.tasks.addTask(7, this.wander);
      this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityGuardian.class, 12.0F, 0.01F));
      this.tasks.addTask(9, new EntityAILookIdle(this));
      this.wander.setMutexBits(3);
      var1.setMutexBits(3);
      this.targetTasks.addTask(1, new EntityAINearestAttackableTarget(this, EntityLivingBase.class, 10, true, false, new GuardianTargetSelector(this)));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue((double)6.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue((double)0.5F);
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)16.0F);
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue((double)30.0F);
   }

   public static void registerFixesGuardian(DataFixer var0) {
      EntityLiving.registerFixesMob(var0, EntityGuardian.class);
   }

   protected PathNavigate getNewNavigator(World var1) {
      return new PathNavigateSwimmer(this, var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_190766_bz, false);
      this.dataManager.register(TARGET_ENTITY, 0);
   }

   public boolean isMoving() {
      return (Boolean)this.dataManager.get(field_190766_bz);
   }

   private void setMoving(boolean var1) {
      this.dataManager.set(field_190766_bz, var1);
   }

   public int getAttackDuration() {
      return 80;
   }

   private void setTargetedEntity(int var1) {
      this.dataManager.set(TARGET_ENTITY, var1);
   }

   public boolean hasTargetedEntity() {
      return (Integer)this.dataManager.get(TARGET_ENTITY) != 0;
   }

   @Nullable
   public EntityLivingBase getTargetedEntity() {
      if (!this.hasTargetedEntity()) {
         return null;
      } else if (this.world.isRemote) {
         if (this.targetedEntity != null) {
            return this.targetedEntity;
         } else {
            Entity var1 = this.world.getEntityByID((Integer)this.dataManager.get(TARGET_ENTITY));
            if (var1 instanceof EntityLivingBase) {
               this.targetedEntity = (EntityLivingBase)var1;
               return this.targetedEntity;
            } else {
               return null;
            }
         }
      } else {
         return this.getAttackTarget();
      }
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      super.notifyDataManagerChange(var1);
      if (TARGET_ENTITY.equals(var1)) {
         this.clientSideAttackTime = 0;
         this.targetedEntity = null;
      }

   }

   public int getTalkInterval() {
      return 160;
   }

   protected SoundEvent getAmbientSound() {
      return this.isInWater() ? SoundEvents.ENTITY_GUARDIAN_AMBIENT : SoundEvents.ENTITY_GUARDIAN_AMBIENT_LAND;
   }

   protected SoundEvent getHurtSound(DamageSource var1) {
      return this.isInWater() ? SoundEvents.ENTITY_GUARDIAN_HURT : SoundEvents.ENTITY_GUARDIAN_HURT_LAND;
   }

   protected SoundEvent getDeathSound() {
      return this.isInWater() ? SoundEvents.ENTITY_GUARDIAN_DEATH : SoundEvents.ENTITY_GUARDIAN_DEATH_LAND;
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   public float getEyeHeight() {
      return this.height * 0.5F;
   }

   public float getBlockPathWeight(BlockPos var1) {
      return this.world.getBlockState(var1).getMaterial() == Material.WATER ? 10.0F + this.world.getLightBrightness(var1) - 0.5F : super.getBlockPathWeight(var1);
   }

   public void onLivingUpdate() {
      if (this.world.isRemote) {
         this.clientSideTailAnimationO = this.clientSideTailAnimation;
         if (!this.isInWater()) {
            this.clientSideTailAnimationSpeed = 2.0F;
            if (this.motionY > (double)0.0F && this.clientSideTouchedGround && !this.isSilent()) {
               this.world.playSound(this.posX, this.posY, this.posZ, this.func_190765_dj(), this.getSoundCategory(), 1.0F, 1.0F, false);
            }

            this.clientSideTouchedGround = this.motionY < (double)0.0F && this.world.isBlockNormalCube((new BlockPos(this)).down(), false);
         } else if (this.isMoving()) {
            if (this.clientSideTailAnimationSpeed < 0.5F) {
               this.clientSideTailAnimationSpeed = 4.0F;
            } else {
               this.clientSideTailAnimationSpeed += (0.5F - this.clientSideTailAnimationSpeed) * 0.1F;
            }
         } else {
            this.clientSideTailAnimationSpeed += (0.125F - this.clientSideTailAnimationSpeed) * 0.2F;
         }

         this.clientSideTailAnimation += this.clientSideTailAnimationSpeed;
         this.clientSideSpikesAnimationO = this.clientSideSpikesAnimation;
         if (!this.isInWater()) {
            this.clientSideSpikesAnimation = this.rand.nextFloat();
         } else if (this.isMoving()) {
            this.clientSideSpikesAnimation += (0.0F - this.clientSideSpikesAnimation) * 0.25F;
         } else {
            this.clientSideSpikesAnimation += (1.0F - this.clientSideSpikesAnimation) * 0.06F;
         }

         if (this.isMoving() && this.isInWater()) {
            Vec3d var1 = this.getLook(0.0F);

            for(int var2 = 0; var2 < 2; ++var2) {
               this.world.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX + (this.rand.nextDouble() - (double)0.5F) * (double)this.width - var1.xCoord * (double)1.5F, this.posY + this.rand.nextDouble() * (double)this.height - var1.yCoord * (double)1.5F, this.posZ + (this.rand.nextDouble() - (double)0.5F) * (double)this.width - var1.zCoord * (double)1.5F, (double)0.0F, (double)0.0F, (double)0.0F);
            }
         }

         if (this.hasTargetedEntity()) {
            if (this.clientSideAttackTime < this.getAttackDuration()) {
               ++this.clientSideAttackTime;
            }

            EntityLivingBase var14 = this.getTargetedEntity();
            if (var14 != null) {
               this.getLookHelper().setLookPositionWithEntity(var14, 90.0F, 90.0F);
               this.getLookHelper().onUpdateLook();
               double var15 = (double)this.getAttackAnimationScale(0.0F);
               double var4 = var14.posX - this.posX;
               double var6 = var14.posY + (double)(var14.height * 0.5F) - (this.posY + (double)this.getEyeHeight());
               double var8 = var14.posZ - this.posZ;
               double var10 = Math.sqrt(var4 * var4 + var6 * var6 + var8 * var8);
               var4 /= var10;
               var6 /= var10;
               var8 /= var10;
               double var12 = this.rand.nextDouble();

               while(var12 < var10) {
                  var12 += 1.8 - var15 + this.rand.nextDouble() * (1.7 - var15);
                  this.world.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX + var4 * var12, this.posY + var6 * var12 + (double)this.getEyeHeight(), this.posZ + var8 * var12, (double)0.0F, (double)0.0F, (double)0.0F);
               }
            }
         }
      }

      if (this.inWater) {
         this.setAir(300);
      } else if (this.onGround) {
         this.motionY += (double)0.5F;
         this.motionX += (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 0.4F);
         this.motionZ += (double)((this.rand.nextFloat() * 2.0F - 1.0F) * 0.4F);
         this.rotationYaw = this.rand.nextFloat() * 360.0F;
         this.onGround = false;
         this.isAirBorne = true;
      }

      if (this.hasTargetedEntity()) {
         this.rotationYaw = this.rotationYawHead;
      }

      super.onLivingUpdate();
   }

   protected SoundEvent func_190765_dj() {
      return SoundEvents.ENTITY_GUARDIAN_FLOP;
   }

   public float getTailAnimation(float var1) {
      return this.clientSideTailAnimationO + (this.clientSideTailAnimation - this.clientSideTailAnimationO) * var1;
   }

   public float getSpikesAnimation(float var1) {
      return this.clientSideSpikesAnimationO + (this.clientSideSpikesAnimation - this.clientSideSpikesAnimationO) * var1;
   }

   public float getAttackAnimationScale(float var1) {
      return ((float)this.clientSideAttackTime + var1) / (float)this.getAttackDuration();
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_GUARDIAN;
   }

   protected boolean isValidLightLevel() {
      return true;
   }

   public boolean isNotColliding() {
      return this.world.checkNoEntityCollision(this.getEntityBoundingBox(), this) && this.world.getCollisionBoxes(this, this.getEntityBoundingBox()).isEmpty();
   }

   public boolean getCanSpawnHere() {
      return (this.rand.nextInt(20) == 0 || !this.world.canBlockSeeSky(new BlockPos(this))) && super.getCanSpawnHere();
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (!this.isMoving() && !var1.isMagicDamage() && var1.getSourceOfDamage() instanceof EntityLivingBase) {
         EntityLivingBase var3 = (EntityLivingBase)var1.getSourceOfDamage();
         if (!var1.isExplosion()) {
            var3.attackEntityFrom(DamageSource.causeThornsDamage(this), 2.0F);
         }
      }

      if (this.wander != null) {
         this.wander.makeUpdate();
      }

      return super.attackEntityFrom(var1, var2);
   }

   public int getVerticalFaceSpeed() {
      return 180;
   }

   public void func_191986_a(float var1, float var2, float var3) {
      if (this.isServerWorld() && this.isInWater()) {
         this.func_191958_b(var1, var2, var3, 0.1F);
         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         this.motionX *= (double)0.9F;
         this.motionY *= (double)0.9F;
         this.motionZ *= (double)0.9F;
         if (!this.isMoving() && this.getAttackTarget() == null) {
            this.motionY -= 0.005;
         }
      } else {
         super.func_191986_a(var1, var2, var3);
      }

   }

   static void access$000(EntityGuardian var0, int var1) {
      var0.setTargetedEntity(var1);
   }

   static void access$100(EntityGuardian var0, boolean var1) {
      var0.setMoving(var1);
   }

   static {
      field_190766_bz = EntityDataManager.<Boolean>createKey(EntityGuardian.class, DataSerializers.BOOLEAN);
      TARGET_ENTITY = EntityDataManager.<Integer>createKey(EntityGuardian.class, DataSerializers.VARINT);
   }

   static class AIGuardianAttack extends EntityAIBase {
      private final EntityGuardian theEntity;
      private int tickCounter;
      private final boolean field_190881_c;

      public AIGuardianAttack(EntityGuardian var1) {
         this.theEntity = var1;
         this.field_190881_c = var1 instanceof EntityElderGuardian;
         this.setMutexBits(3);
      }

      public boolean shouldExecute() {
         EntityLivingBase var1 = this.theEntity.getAttackTarget();
         return var1 != null && var1.isEntityAlive();
      }

      public boolean continueExecuting() {
         return super.continueExecuting() && (this.field_190881_c || this.theEntity.getDistanceSqToEntity(this.theEntity.getAttackTarget()) > (double)9.0F);
      }

      public void startExecuting() {
         this.tickCounter = -10;
         this.theEntity.getNavigator().clearPathEntity();
         this.theEntity.getLookHelper().setLookPositionWithEntity(this.theEntity.getAttackTarget(), 90.0F, 90.0F);
         this.theEntity.isAirBorne = true;
      }

      public void resetTask() {
         EntityGuardian.access$000(this.theEntity, 0);
         this.theEntity.setAttackTarget((EntityLivingBase)null);
         this.theEntity.wander.makeUpdate();
      }

      public void updateTask() {
         EntityLivingBase var1 = this.theEntity.getAttackTarget();
         this.theEntity.getNavigator().clearPathEntity();
         this.theEntity.getLookHelper().setLookPositionWithEntity(var1, 90.0F, 90.0F);
         if (!this.theEntity.canEntityBeSeen(var1)) {
            this.theEntity.setAttackTarget((EntityLivingBase)null);
         } else {
            ++this.tickCounter;
            if (this.tickCounter == 0) {
               EntityGuardian.access$000(this.theEntity, this.theEntity.getAttackTarget().getEntityId());
               this.theEntity.world.setEntityState(this.theEntity, (byte)21);
            } else if (this.tickCounter >= this.theEntity.getAttackDuration()) {
               float var2 = 1.0F;
               if (this.theEntity.world.getDifficulty() == EnumDifficulty.HARD) {
                  var2 += 2.0F;
               }

               if (this.field_190881_c) {
                  var2 += 2.0F;
               }

               var1.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this.theEntity, this.theEntity), var2);
               var1.attackEntityFrom(DamageSource.causeMobDamage(this.theEntity), (float)this.theEntity.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue());
               this.theEntity.setAttackTarget((EntityLivingBase)null);
            }

            super.updateTask();
         }

      }
   }

   static class GuardianMoveHelper extends EntityMoveHelper {
      private final EntityGuardian entityGuardian;

      public GuardianMoveHelper(EntityGuardian var1) {
         super(var1);
         this.entityGuardian = var1;
      }

      public void onUpdateMoveHelper() {
         if (this.action == EntityMoveHelper.Action.MOVE_TO && !this.entityGuardian.getNavigator().noPath()) {
            double var1 = this.posX - this.entityGuardian.posX;
            double var3 = this.posY - this.entityGuardian.posY;
            double var5 = this.posZ - this.entityGuardian.posZ;
            double var7 = (double)MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
            var3 /= var7;
            float var9 = (float)(MathHelper.atan2(var5, var1) * (180D / Math.PI)) - 90.0F;
            this.entityGuardian.rotationYaw = this.limitAngle(this.entityGuardian.rotationYaw, var9, 90.0F);
            this.entityGuardian.renderYawOffset = this.entityGuardian.rotationYaw;
            float var10 = (float)(this.speed * this.entityGuardian.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue());
            this.entityGuardian.setAIMoveSpeed(this.entityGuardian.getAIMoveSpeed() + (var10 - this.entityGuardian.getAIMoveSpeed()) * 0.125F);
            double var11 = Math.sin((double)(this.entityGuardian.ticksExisted + this.entityGuardian.getEntityId()) * (double)0.5F) * 0.05;
            double var13 = Math.cos((double)(this.entityGuardian.rotationYaw * ((float)Math.PI / 180F)));
            double var15 = Math.sin((double)(this.entityGuardian.rotationYaw * ((float)Math.PI / 180F)));
            EntityGuardian var10000 = this.entityGuardian;
            var10000.motionX += var11 * var13;
            var10000 = this.entityGuardian;
            var10000.motionZ += var11 * var15;
            var11 = Math.sin((double)(this.entityGuardian.ticksExisted + this.entityGuardian.getEntityId()) * (double)0.75F) * 0.05;
            var10000 = this.entityGuardian;
            var10000.motionY += var11 * (var15 + var13) * (double)0.25F;
            var10000 = this.entityGuardian;
            var10000.motionY += (double)this.entityGuardian.getAIMoveSpeed() * var3 * 0.1;
            EntityLookHelper var17 = this.entityGuardian.getLookHelper();
            double var18 = this.entityGuardian.posX + var1 / var7 * (double)2.0F;
            double var20 = (double)this.entityGuardian.getEyeHeight() + this.entityGuardian.posY + var3 / var7;
            double var22 = this.entityGuardian.posZ + var5 / var7 * (double)2.0F;
            double var24 = var17.getLookPosX();
            double var26 = var17.getLookPosY();
            double var28 = var17.getLookPosZ();
            if (!var17.getIsLooking()) {
               var24 = var18;
               var26 = var20;
               var28 = var22;
            }

            this.entityGuardian.getLookHelper().setLookPosition(var24 + (var18 - var24) * (double)0.125F, var26 + (var20 - var26) * (double)0.125F, var28 + (var22 - var28) * (double)0.125F, 10.0F, 40.0F);
            EntityGuardian.access$100(this.entityGuardian, true);
         } else {
            this.entityGuardian.setAIMoveSpeed(0.0F);
            EntityGuardian.access$100(this.entityGuardian, false);
         }

      }
   }

   static class GuardianTargetSelector implements Predicate<EntityLivingBase> {
      private final EntityGuardian parentEntity;

      public GuardianTargetSelector(EntityGuardian var1) {
         this.parentEntity = var1;
      }

      public boolean apply(@Nullable EntityLivingBase var1) {
         return (var1 instanceof EntityPlayer || var1 instanceof EntitySquid) && var1.getDistanceSqToEntity(this.parentEntity) > (double)9.0F;
      }
   }
}
