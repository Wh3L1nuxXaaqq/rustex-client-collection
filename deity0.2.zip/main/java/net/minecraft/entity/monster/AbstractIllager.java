package net.minecraft.entity.monster;

import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.world.World;

public abstract class AbstractIllager extends EntityMob {
   protected static final DataParameter<Byte> field_193080_a;

   public AbstractIllager(World var1) {
      super(var1);
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(field_193080_a, (byte)0);
   }

   protected boolean func_193078_a(int var1) {
      byte var2 = (Byte)this.dataManager.get(field_193080_a);
      return (var2 & var1) != 0;
   }

   protected void func_193079_a(int var1, boolean var2) {
      int var3 = (Byte)this.dataManager.get(field_193080_a);
      if (var2) {
         var3 |= var1;
      } else {
         var3 &= ~var1;
      }

      this.dataManager.set(field_193080_a, (byte)(var3 & 255));
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.ILLAGER;
   }

   public IllagerArmPose func_193077_p() {
      return AbstractIllager.IllagerArmPose.CROSSED;
   }

   static {
      field_193080_a = EntityDataManager.<Byte>createKey(AbstractIllager.class, DataSerializers.BYTE);
   }

   public static enum IllagerArmPose {
      CROSSED,
      ATTACKING,
      SPELLCASTING,
      BOW_AND_ARROW;
   }
}
