package net.minecraft.entity.ai;

import java.util.List;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.util.math.Vec3d;

public class EntityAILlamaFollowCaravan extends EntityAIBase {
   public EntityLlama field_190859_a;
   private double field_190860_b;
   private int field_190861_c;

   public EntityAILlamaFollowCaravan(EntityLlama var1, double var2) {
      this.field_190859_a = var1;
      this.field_190860_b = var2;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      if (!this.field_190859_a.getLeashed() && !this.field_190859_a.func_190718_dR()) {
         List var1 = this.field_190859_a.world.getEntitiesWithinAABB(this.field_190859_a.getClass(), this.field_190859_a.getEntityBoundingBox().expand((double)9.0F, (double)4.0F, (double)9.0F));
         EntityLlama var2 = null;
         double var3 = Double.MAX_VALUE;

         for(Object var6_raw : var1) {
            EntityLlama var6 = (EntityLlama)var6_raw;
            if (var6.func_190718_dR() && !var6.func_190712_dQ()) {
               double var7 = this.field_190859_a.getDistanceSqToEntity(var6);
               if (var7 <= var3) {
                  var3 = var7;
                  var2 = var6;
               }
            }
         }

         if (var2 == null) {
            for(Object var10_raw : var1) {
               EntityLlama var10 = (EntityLlama)var10_raw;
               if (var10.getLeashed() && !var10.func_190712_dQ()) {
                  double var11 = this.field_190859_a.getDistanceSqToEntity(var10);
                  if (var11 <= var3) {
                     var3 = var11;
                     var2 = var10;
                  }
               }
            }
         }

         if (var2 == null) {
            return false;
         } else if (var3 < (double)4.0F) {
            return false;
         } else if (!var2.getLeashed() && !this.func_190858_a(var2, 1)) {
            return false;
         } else {
            this.field_190859_a.func_190715_a(var2);
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      if (this.field_190859_a.func_190718_dR() && this.field_190859_a.func_190716_dS().isEntityAlive() && this.func_190858_a(this.field_190859_a, 0)) {
         double var1 = this.field_190859_a.getDistanceSqToEntity(this.field_190859_a.func_190716_dS());
         if (var1 > (double)676.0F) {
            if (this.field_190860_b <= (double)3.0F) {
               this.field_190860_b *= 1.2;
               this.field_190861_c = 40;
               return true;
            }

            if (this.field_190861_c == 0) {
               return false;
            }
         }

         if (this.field_190861_c > 0) {
            --this.field_190861_c;
         }

         return true;
      } else {
         return false;
      }
   }

   public void resetTask() {
      this.field_190859_a.func_190709_dP();
      this.field_190860_b = 2.1;
   }

   public void updateTask() {
      if (this.field_190859_a.func_190718_dR()) {
         EntityLlama var1 = this.field_190859_a.func_190716_dS();
         double var2 = (double)this.field_190859_a.getDistanceToEntity(var1);
         float var4 = 2.0F;
         Vec3d var5 = (new Vec3d(var1.posX - this.field_190859_a.posX, var1.posY - this.field_190859_a.posY, var1.posZ - this.field_190859_a.posZ)).normalize().scale(Math.max(var2 - (double)2.0F, (double)0.0F));
         this.field_190859_a.getNavigator().tryMoveToXYZ(this.field_190859_a.posX + var5.xCoord, this.field_190859_a.posY + var5.yCoord, this.field_190859_a.posZ + var5.zCoord, this.field_190860_b);
      }

   }

   private boolean func_190858_a(EntityLlama var1, int var2) {
      if (var2 > 8) {
         return false;
      } else if (var1.func_190718_dR()) {
         if (var1.func_190716_dS().getLeashed()) {
            return true;
         } else {
            EntityLlama var3 = var1.func_190716_dS();
            ++var2;
            return this.func_190858_a(var3, var2);
         }
      } else {
         return false;
      }
   }
}
