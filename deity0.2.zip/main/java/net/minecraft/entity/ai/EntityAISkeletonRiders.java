package net.minecraft.entity.ai;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntitySkeletonHorse;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DifficultyInstance;

public class EntityAISkeletonRiders extends EntityAIBase {
   private final EntitySkeletonHorse horse;

   public EntityAISkeletonRiders(EntitySkeletonHorse var1) {
      this.horse = var1;
   }

   public boolean shouldExecute() {
      return this.horse.world.isAnyPlayerWithinRangeAt(this.horse.posX, this.horse.posY, this.horse.posZ, (double)10.0F);
   }

   public void updateTask() {
      DifficultyInstance var1 = this.horse.world.getDifficultyForLocation(new BlockPos(this.horse));
      this.horse.func_190691_p(false);
      this.horse.setHorseTamed(true);
      this.horse.setGrowingAge(0);
      this.horse.world.addWeatherEffect(new EntityLightningBolt(this.horse.world, this.horse.posX, this.horse.posY, this.horse.posZ, true));
      EntitySkeleton var2 = this.createSkeleton(var1, this.horse);
      var2.startRiding(this.horse);

      for(int var3 = 0; var3 < 3; ++var3) {
         AbstractHorse var4 = this.createHorse(var1);
         EntitySkeleton var5 = this.createSkeleton(var1, var4);
         var5.startRiding(var4);
         var4.addVelocity(this.horse.getRNG().nextGaussian() * (double)0.5F, (double)0.0F, this.horse.getRNG().nextGaussian() * (double)0.5F);
      }

   }

   private AbstractHorse createHorse(DifficultyInstance var1) {
      EntitySkeletonHorse var2 = new EntitySkeletonHorse(this.horse.world);
      var2.onInitialSpawn(var1, (IEntityLivingData)null);
      var2.setPosition(this.horse.posX, this.horse.posY, this.horse.posZ);
      var2.hurtResistantTime = 60;
      var2.enablePersistence();
      var2.setHorseTamed(true);
      var2.setGrowingAge(0);
      var2.world.spawnEntityInWorld(var2);
      return var2;
   }

   private EntitySkeleton createSkeleton(DifficultyInstance var1, AbstractHorse var2) {
      EntitySkeleton var3 = new EntitySkeleton(var2.world);
      var3.onInitialSpawn(var1, (IEntityLivingData)null);
      var3.setPosition(var2.posX, var2.posY, var2.posZ);
      var3.hurtResistantTime = 60;
      var3.enablePersistence();
      if (var3.getItemStackFromSlot(EntityEquipmentSlot.HEAD).func_190926_b()) {
         var3.setItemStackToSlot(EntityEquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
      }

      var3.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, EnchantmentHelper.addRandomEnchantment(var3.getRNG(), var3.getHeldItemMainhand(), (int)(5.0F + var1.getClampedAdditionalDifficulty() * (float)var3.getRNG().nextInt(18)), false));
      var3.setItemStackToSlot(EntityEquipmentSlot.HEAD, EnchantmentHelper.addRandomEnchantment(var3.getRNG(), var3.getItemStackFromSlot(EntityEquipmentSlot.HEAD), (int)(5.0F + var1.getClampedAdditionalDifficulty() * (float)var3.getRNG().nextInt(18)), false));
      var3.world.spawnEntityInWorld(var3);
      return var3;
   }
}
