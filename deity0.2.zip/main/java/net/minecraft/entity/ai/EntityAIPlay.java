package net.minecraft.entity.ai;

import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.util.math.Vec3d;

public class EntityAIPlay extends EntityAIBase {
   private final EntityVillager villagerObj;
   private EntityLivingBase targetVillager;
   private final double speed;
   private int playTime;

   public EntityAIPlay(EntityVillager var1, double var2) {
      this.villagerObj = var1;
      this.speed = var2;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      if (this.villagerObj.getGrowingAge() >= 0) {
         return false;
      } else if (this.villagerObj.getRNG().nextInt(400) != 0) {
         return false;
      } else {
         List var1 = this.villagerObj.world.getEntitiesWithinAABB(EntityVillager.class, this.villagerObj.getEntityBoundingBox().expand((double)6.0F, (double)3.0F, (double)6.0F));
         double var2 = Double.MAX_VALUE;

         for(Object var5_raw : var1) {
            EntityVillager var5 = (EntityVillager)var5_raw;
            if (var5 != this.villagerObj && !var5.isPlaying() && var5.getGrowingAge() < 0) {
               double var6 = var5.getDistanceSqToEntity(this.villagerObj);
               if (var6 <= var2) {
                  var2 = var6;
                  this.targetVillager = var5;
               }
            }
         }

         if (this.targetVillager == null) {
            Vec3d var8 = RandomPositionGenerator.findRandomTarget(this.villagerObj, 16, 3);
            if (var8 == null) {
               return false;
            }
         }

         return true;
      }
   }

   public boolean continueExecuting() {
      return this.playTime > 0;
   }

   public void startExecuting() {
      if (this.targetVillager != null) {
         this.villagerObj.setPlaying(true);
      }

      this.playTime = 1000;
   }

   public void resetTask() {
      this.villagerObj.setPlaying(false);
      this.targetVillager = null;
   }

   public void updateTask() {
      --this.playTime;
      if (this.targetVillager != null) {
         if (this.villagerObj.getDistanceSqToEntity(this.targetVillager) > (double)4.0F) {
            this.villagerObj.getNavigator().tryMoveToEntityLiving(this.targetVillager, this.speed);
         }
      } else if (this.villagerObj.getNavigator().noPath()) {
         Vec3d var1 = RandomPositionGenerator.findRandomTarget(this.villagerObj, 16, 3);
         if (var1 == null) {
            return;
         }

         this.villagerObj.getNavigator().tryMoveToXYZ(var1.xCoord, var1.yCoord, var1.zCoord, this.speed);
      }

   }
}
