package net.minecraft.entity.ai;

import java.util.List;
import java.util.Random;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.stats.StatList;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityAIMate extends EntityAIBase {
   private final EntityAnimal theAnimal;
   private final Class<? extends EntityAnimal> field_190857_e;
   World theWorld;
   private EntityAnimal targetMate;
   int spawnBabyDelay;
   double moveSpeed;

   public EntityAIMate(EntityAnimal var1, double var2) {
      this(var1, var2, var1.getClass());
   }

   public EntityAIMate(EntityAnimal var1, double var2, Class<? extends EntityAnimal> var4) {
      this.theAnimal = var1;
      this.theWorld = var1.world;
      this.field_190857_e = var4;
      this.moveSpeed = var2;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if (!this.theAnimal.isInLove()) {
         return false;
      } else {
         this.targetMate = this.getNearbyMate();
         return this.targetMate != null;
      }
   }

   public boolean continueExecuting() {
      return this.targetMate.isEntityAlive() && this.targetMate.isInLove() && this.spawnBabyDelay < 60;
   }

   public void resetTask() {
      this.targetMate = null;
      this.spawnBabyDelay = 0;
   }

   public void updateTask() {
      this.theAnimal.getLookHelper().setLookPositionWithEntity(this.targetMate, 10.0F, (float)this.theAnimal.getVerticalFaceSpeed());
      this.theAnimal.getNavigator().tryMoveToEntityLiving(this.targetMate, this.moveSpeed);
      ++this.spawnBabyDelay;
      if (this.spawnBabyDelay >= 60 && this.theAnimal.getDistanceSqToEntity(this.targetMate) < (double)9.0F) {
         this.spawnBaby();
      }

   }

   private EntityAnimal getNearbyMate() {
      List var1 = this.theWorld.getEntitiesWithinAABB(this.field_190857_e, this.theAnimal.getEntityBoundingBox().expandXyz((double)8.0F));
      double var2 = Double.MAX_VALUE;
      EntityAnimal var4 = null;

      for(Object var6_raw : var1) {
         EntityAnimal var6 = (EntityAnimal)var6_raw;
         if (this.theAnimal.canMateWith(var6) && this.theAnimal.getDistanceSqToEntity(var6) < var2) {
            var4 = var6;
            var2 = this.theAnimal.getDistanceSqToEntity(var6);
         }
      }

      return var4;
   }

   private void spawnBaby() {
      EntityAgeable var1 = this.theAnimal.createChild(this.targetMate);
      if (var1 != null) {
         EntityPlayerMP var2 = this.theAnimal.func_191993_do();
         if (var2 == null && this.targetMate.func_191993_do() != null) {
            var2 = this.targetMate.func_191993_do();
         }

         if (var2 != null) {
            var2.addStat(StatList.ANIMALS_BRED);
            CriteriaTriggers.field_192134_n.func_192168_a(var2, this.theAnimal, this.targetMate, var1);
         }

         this.theAnimal.setGrowingAge(6000);
         this.targetMate.setGrowingAge(6000);
         this.theAnimal.resetInLove();
         this.targetMate.resetInLove();
         var1.setGrowingAge(-24000);
         var1.setLocationAndAngles(this.theAnimal.posX, this.theAnimal.posY, this.theAnimal.posZ, 0.0F, 0.0F);
         this.theWorld.spawnEntityInWorld(var1);
         Random var3 = this.theAnimal.getRNG();

         for(int var4 = 0; var4 < 7; ++var4) {
            double var5 = var3.nextGaussian() * 0.02;
            double var7 = var3.nextGaussian() * 0.02;
            double var9 = var3.nextGaussian() * 0.02;
            double var11 = var3.nextDouble() * (double)this.theAnimal.width * (double)2.0F - (double)this.theAnimal.width;
            double var13 = (double)0.5F + var3.nextDouble() * (double)this.theAnimal.height;
            double var15 = var3.nextDouble() * (double)this.theAnimal.width * (double)2.0F - (double)this.theAnimal.width;
            this.theWorld.spawnParticle(EnumParticleTypes.HEART, this.theAnimal.posX + var11, this.theAnimal.posY + var13, this.theAnimal.posZ + var15, var5, var7, var9);
         }

         if (this.theWorld.getGameRules().getBoolean("doMobLoot")) {
            this.theWorld.spawnEntityInWorld(new EntityXPOrb(this.theWorld, this.theAnimal.posX, this.theAnimal.posY, this.theAnimal.posZ, var3.nextInt(7) + 1));
         }
      }

   }
}
