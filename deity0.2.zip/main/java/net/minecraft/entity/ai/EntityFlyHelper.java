package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.math.MathHelper;

public class EntityFlyHelper extends EntityMoveHelper {
   public EntityFlyHelper(EntityLiving var1) {
      super(var1);
   }

   public void onUpdateMoveHelper() {
      if (this.action == EntityMoveHelper.Action.MOVE_TO) {
         this.action = EntityMoveHelper.Action.WAIT;
         this.entity.setNoGravity(true);
         double var1 = this.posX - this.entity.posX;
         double var3 = this.posY - this.entity.posY;
         double var5 = this.posZ - this.entity.posZ;
         double var7 = var1 * var1 + var3 * var3 + var5 * var5;
         if (var7 < (double)2.5000003E-7F) {
            this.entity.setMoveForward(0.0F);
            this.entity.func_191989_p(0.0F);
            return;
         }

         float var9 = (float)(MathHelper.atan2(var5, var1) * (180D / Math.PI)) - 90.0F;
         this.entity.rotationYaw = this.limitAngle(this.entity.rotationYaw, var9, 10.0F);
         float var10;
         if (this.entity.onGround) {
            var10 = (float)(this.speed * this.entity.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue());
         } else {
            var10 = (float)(this.speed * this.entity.getEntityAttribute(SharedMonsterAttributes.field_193334_e).getAttributeValue());
         }

         this.entity.setAIMoveSpeed(var10);
         double var11 = (double)MathHelper.sqrt(var1 * var1 + var5 * var5);
         float var13 = (float)(-(MathHelper.atan2(var3, var11) * (180D / Math.PI)));
         this.entity.rotationPitch = this.limitAngle(this.entity.rotationPitch, var13, 10.0F);
         this.entity.setMoveForward(var3 > (double)0.0F ? var10 : -var10);
      } else {
         this.entity.setNoGravity(false);
         this.entity.setMoveForward(0.0F);
         this.entity.func_191989_p(0.0F);
      }

   }
}
