package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

public class EntityAILeapAtTarget extends EntityAIBase {
   EntityLiving leaper;
   EntityLivingBase leapTarget;
   float leapMotionY;

   public EntityAILeapAtTarget(EntityLiving var1, float var2) {
      this.leaper = var1;
      this.leapMotionY = var2;
      this.setMutexBits(5);
   }

   public boolean shouldExecute() {
      this.leapTarget = this.leaper.getAttackTarget();
      if (this.leapTarget == null) {
         return false;
      } else {
         double var1 = this.leaper.getDistanceSqToEntity(this.leapTarget);
         if (var1 >= (double)4.0F && var1 <= (double)16.0F) {
            if (!this.leaper.onGround) {
               return false;
            } else {
               return this.leaper.getRNG().nextInt(5) == 0;
            }
         } else {
            return false;
         }
      }
   }

   public boolean continueExecuting() {
      return !this.leaper.onGround;
   }

   public void startExecuting() {
      double var1 = this.leapTarget.posX - this.leaper.posX;
      double var3 = this.leapTarget.posZ - this.leaper.posZ;
      float var5 = MathHelper.sqrt(var1 * var1 + var3 * var3);
      if ((double)var5 >= 1.0E-4) {
         EntityLiving var10000 = this.leaper;
         var10000.motionX += var1 / (double)var5 * (double)0.5F * (double)0.8F + this.leaper.motionX * (double)0.2F;
         var10000 = this.leaper;
         var10000.motionZ += var3 / (double)var5 * (double)0.5F * (double)0.8F + this.leaper.motionZ * (double)0.2F;
      }

      this.leaper.motionY = (double)this.leapMotionY;
   }
}
