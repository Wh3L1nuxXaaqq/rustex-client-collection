package net.minecraft.entity.ai;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateFlying;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.pathfinding.PathNodeType;

public class EntityAIFollow extends EntityAIBase {
   private final EntityLiving field_192372_a;
   private final Predicate<EntityLiving> field_192373_b;
   private EntityLiving field_192374_c;
   private final double field_192375_d;
   private final PathNavigate field_192376_e;
   private int field_192377_f;
   private final float field_192378_g;
   private float field_192379_h;
   private final float field_192380_i;

   public EntityAIFollow(final EntityLiving var1, double var2, float var4, float var5) {
      this.field_192372_a = var1;
      this.field_192373_b = new Predicate<EntityLiving>() {
         public boolean apply(@Nullable EntityLiving var1x) {
            return var1x != null && var1.getClass() != var1x.getClass();
         }
      };
      this.field_192375_d = var2;
      this.field_192376_e = var1.getNavigator();
      this.field_192378_g = var4;
      this.field_192380_i = var5;
      this.setMutexBits(3);
      if (!(var1.getNavigator() instanceof PathNavigateGround) && !(var1.getNavigator() instanceof PathNavigateFlying)) {
         throw new IllegalArgumentException("Unsupported mob type for FollowMobGoal");
      }
   }

   public boolean shouldExecute() {
      List var1 = this.field_192372_a.world.getEntitiesWithinAABB(EntityLiving.class, this.field_192372_a.getEntityBoundingBox().expandXyz((double)this.field_192380_i), this.field_192373_b);
      if (!var1.isEmpty()) {
         for(Object var3_raw : var1) {
            EntityLiving var3 = (EntityLiving)var3_raw;
            if (!var3.isInvisible()) {
               this.field_192374_c = var3;
               return true;
            }
         }
      }

      return false;
   }

   public boolean continueExecuting() {
      return this.field_192374_c != null && !this.field_192376_e.noPath() && this.field_192372_a.getDistanceSqToEntity(this.field_192374_c) > (double)(this.field_192378_g * this.field_192378_g);
   }

   public void startExecuting() {
      this.field_192377_f = 0;
      this.field_192379_h = this.field_192372_a.getPathPriority(PathNodeType.WATER);
      this.field_192372_a.setPathPriority(PathNodeType.WATER, 0.0F);
   }

   public void resetTask() {
      this.field_192374_c = null;
      this.field_192376_e.clearPathEntity();
      this.field_192372_a.setPathPriority(PathNodeType.WATER, this.field_192379_h);
   }

   public void updateTask() {
      if (this.field_192374_c != null && !this.field_192372_a.getLeashed()) {
         this.field_192372_a.getLookHelper().setLookPositionWithEntity(this.field_192374_c, 10.0F, (float)this.field_192372_a.getVerticalFaceSpeed());
         if (--this.field_192377_f <= 0) {
            this.field_192377_f = 10;
            double var1 = this.field_192372_a.posX - this.field_192374_c.posX;
            double var3 = this.field_192372_a.posY - this.field_192374_c.posY;
            double var5 = this.field_192372_a.posZ - this.field_192374_c.posZ;
            double var7 = var1 * var1 + var3 * var3 + var5 * var5;
            if (var7 > (double)(this.field_192378_g * this.field_192378_g)) {
               this.field_192376_e.tryMoveToEntityLiving(this.field_192374_c, this.field_192375_d);
            } else {
               this.field_192376_e.clearPathEntity();
               EntityLookHelper var9 = this.field_192374_c.getLookHelper();
               if (var7 <= (double)this.field_192378_g || var9.getLookPosX() == this.field_192372_a.posX && var9.getLookPosY() == this.field_192372_a.posY && var9.getLookPosZ() == this.field_192372_a.posZ) {
                  double var10 = this.field_192374_c.posX - this.field_192372_a.posX;
                  double var12 = this.field_192374_c.posZ - this.field_192372_a.posZ;
                  this.field_192376_e.tryMoveToXYZ(this.field_192372_a.posX - var10, this.field_192372_a.posY, this.field_192372_a.posZ - var12, this.field_192375_d);
               }
            }
         }
      }

   }
}
