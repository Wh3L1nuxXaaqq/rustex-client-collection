package net.minecraft.entity.ai;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityAIPanic extends EntityAIBase {
   protected final EntityCreature theEntityCreature;
   protected double speed;
   protected double randPosX;
   protected double randPosY;
   protected double randPosZ;

   public EntityAIPanic(EntityCreature var1, double var2) {
      this.theEntityCreature = var1;
      this.speed = var2;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      if (this.theEntityCreature.getAITarget() == null && !this.theEntityCreature.isBurning()) {
         return false;
      } else {
         if (this.theEntityCreature.isBurning()) {
            BlockPos var1 = this.getRandPos(this.theEntityCreature.world, this.theEntityCreature, 5, 4);
            if (var1 != null) {
               this.randPosX = (double)var1.getX();
               this.randPosY = (double)var1.getY();
               this.randPosZ = (double)var1.getZ();
               return true;
            }
         }

         return this.func_190863_f();
      }
   }

   protected boolean func_190863_f() {
      Vec3d var1 = RandomPositionGenerator.findRandomTarget(this.theEntityCreature, 5, 4);
      if (var1 == null) {
         return false;
      } else {
         this.randPosX = var1.xCoord;
         this.randPosY = var1.yCoord;
         this.randPosZ = var1.zCoord;
         return true;
      }
   }

   public void startExecuting() {
      this.theEntityCreature.getNavigator().tryMoveToXYZ(this.randPosX, this.randPosY, this.randPosZ, this.speed);
   }

   public boolean continueExecuting() {
      return !this.theEntityCreature.getNavigator().noPath();
   }

   @Nullable
   private BlockPos getRandPos(World var1, Entity var2, int var3, int var4) {
      BlockPos var5 = new BlockPos(var2);
      int var6 = var5.getX();
      int var7 = var5.getY();
      int var8 = var5.getZ();
      float var9 = (float)(var3 * var3 * var4 * 2);
      BlockPos var10 = null;
      BlockPos.MutableBlockPos var11 = new BlockPos.MutableBlockPos();

      for(int var12 = var6 - var3; var12 <= var6 + var3; ++var12) {
         for(int var13 = var7 - var4; var13 <= var7 + var4; ++var13) {
            for(int var14 = var8 - var3; var14 <= var8 + var3; ++var14) {
               var11.setPos(var12, var13, var14);
               IBlockState var15 = var1.getBlockState(var11);
               if (var15.getMaterial() == Material.WATER) {
                  float var16 = (float)((var12 - var6) * (var12 - var6) + (var13 - var7) * (var13 - var7) + (var14 - var8) * (var14 - var8));
                  if (var16 < var9) {
                     var9 = var16;
                     var10 = new BlockPos(var11);
                  }
               }
            }
         }
      }

      return var10;
   }
}
