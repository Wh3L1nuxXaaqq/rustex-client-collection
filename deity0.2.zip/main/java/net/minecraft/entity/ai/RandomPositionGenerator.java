package net.minecraft.entity.ai;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityCreature;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RandomPositionGenerator {
   private static Vec3d staticVector;

   @Nullable
   public static Vec3d findRandomTarget(EntityCreature var0, int var1, int var2) {
      return findRandomTargetBlock(var0, var1, var2, (Vec3d)null);
   }

   @Nullable
   public static Vec3d func_191377_b(EntityCreature var0, int var1, int var2) {
      return func_191379_a(var0, var1, var2, (Vec3d)null, false);
   }

   @Nullable
   public static Vec3d findRandomTargetBlockTowards(EntityCreature var0, int var1, int var2, Vec3d var3) {
      staticVector = var3.subtract(var0.posX, var0.posY, var0.posZ);
      return findRandomTargetBlock(var0, var1, var2, staticVector);
   }

   @Nullable
   public static Vec3d findRandomTargetBlockAwayFrom(EntityCreature var0, int var1, int var2, Vec3d var3) {
      staticVector = (new Vec3d(var0.posX, var0.posY, var0.posZ)).subtract(var3);
      return findRandomTargetBlock(var0, var1, var2, staticVector);
   }

   @Nullable
   private static Vec3d findRandomTargetBlock(EntityCreature var0, int var1, int var2, @Nullable Vec3d var3) {
      return func_191379_a(var0, var1, var2, var3, true);
   }

   @Nullable
   private static Vec3d func_191379_a(EntityCreature var0, int var1, int var2, @Nullable Vec3d var3, boolean var4) {
      PathNavigate var5 = var0.getNavigator();
      Random var6 = var0.getRNG();
      boolean var7;
      if (var0.hasHome()) {
         double var8 = var0.getHomePosition().distanceSq((double)MathHelper.floor(var0.posX), (double)MathHelper.floor(var0.posY), (double)MathHelper.floor(var0.posZ)) + (double)4.0F;
         double var10 = (double)(var0.getMaximumHomeDistance() + (float)var1);
         var7 = var8 < var10 * var10;
      } else {
         var7 = false;
      }

      boolean var19 = false;
      float var9 = -99999.0F;
      int var20 = 0;
      int var11 = 0;
      int var12 = 0;

      for(int var13 = 0; var13 < 10; ++var13) {
         int var14 = var6.nextInt(2 * var1 + 1) - var1;
         int var15 = var6.nextInt(2 * var2 + 1) - var2;
         int var16 = var6.nextInt(2 * var1 + 1) - var1;
         if (var3 == null || (double)var14 * var3.xCoord + (double)var16 * var3.zCoord >= (double)0.0F) {
            if (var0.hasHome() && var1 > 1) {
               BlockPos var17 = var0.getHomePosition();
               if (var0.posX > (double)var17.getX()) {
                  var14 -= var6.nextInt(var1 / 2);
               } else {
                  var14 += var6.nextInt(var1 / 2);
               }

               if (var0.posZ > (double)var17.getZ()) {
                  var16 -= var6.nextInt(var1 / 2);
               } else {
                  var16 += var6.nextInt(var1 / 2);
               }
            }

            BlockPos var21 = new BlockPos((double)var14 + var0.posX, (double)var15 + var0.posY, (double)var16 + var0.posZ);
            if ((!var7 || var0.isWithinHomeDistanceFromPosition(var21)) && var5.canEntityStandOnPos(var21)) {
               if (!var4) {
                  var21 = func_191378_a(var21, var0);
                  if (func_191380_b(var21, var0)) {
                     continue;
                  }
               }

               float var18 = var0.getBlockPathWeight(var21);
               if (var18 > var9) {
                  var9 = var18;
                  var20 = var14;
                  var11 = var15;
                  var12 = var16;
                  var19 = true;
               }
            }
         }
      }

      if (var19) {
         return new Vec3d((double)var20 + var0.posX, (double)var11 + var0.posY, (double)var12 + var0.posZ);
      } else {
         return null;
      }
   }

   private static BlockPos func_191378_a(BlockPos var0, EntityCreature var1) {
      if (!var1.world.getBlockState(var0).getMaterial().isSolid()) {
         return var0;
      } else {
         BlockPos var2;
         for(var2 = var0.up(); var2.getY() < var1.world.getHeight() && var1.world.getBlockState(var2).getMaterial().isSolid(); var2 = var2.up()) {
         }

         return var2;
      }
   }

   private static boolean func_191380_b(BlockPos var0, EntityCreature var1) {
      return var1.world.getBlockState(var0).getMaterial() == Material.WATER;
   }

   static {
      staticVector = Vec3d.ZERO;
   }
}
