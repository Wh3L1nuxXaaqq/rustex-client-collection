package net.minecraft.entity.ai;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.entity.EntityCreature;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class EntityAIWanderAvoidWaterFlying extends EntityAIWanderAvoidWater {
   public EntityAIWanderAvoidWaterFlying(EntityCreature var1, double var2) {
      super(var1, var2);
   }

   @Nullable
   protected Vec3d func_190864_f() {
      Vec3d var1 = null;
      if (this.entity.isInWater() || this.entity.func_191953_am()) {
         var1 = RandomPositionGenerator.func_191377_b(this.entity, 15, 15);
      }

      if (this.entity.getRNG().nextFloat() >= this.field_190865_h) {
         var1 = this.func_192385_j();
      }

      return var1 == null ? super.func_190864_f() : var1;
   }

   @Nullable
   private Vec3d func_192385_j() {
      BlockPos var1 = new BlockPos(this.entity);
      BlockPos.MutableBlockPos var2 = new BlockPos.MutableBlockPos();
      BlockPos.MutableBlockPos var3 = new BlockPos.MutableBlockPos();

      for(BlockPos var6 : BlockPos.MutableBlockPos.func_191531_b(MathHelper.floor(this.entity.posX - (double)3.0F), MathHelper.floor(this.entity.posY - (double)6.0F), MathHelper.floor(this.entity.posZ - (double)3.0F), MathHelper.floor(this.entity.posX + (double)3.0F), MathHelper.floor(this.entity.posY + (double)6.0F), MathHelper.floor(this.entity.posZ + (double)3.0F))) {
         if (!var1.equals(var6)) {
            Block var7 = this.entity.world.getBlockState(var3.setPos((Vec3i)var6).move(EnumFacing.DOWN)).getBlock();
            boolean var8 = var7 instanceof BlockLeaves || var7 == Blocks.LOG || var7 == Blocks.LOG2;
            if (var8 && this.entity.world.isAirBlock(var6) && this.entity.world.isAirBlock(var2.setPos((Vec3i)var6).move(EnumFacing.UP))) {
               return new Vec3d((double)var6.getX(), (double)var6.getY(), (double)var6.getZ());
            }
         }
      }

      return null;
   }
}
