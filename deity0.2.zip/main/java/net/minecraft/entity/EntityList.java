package net.minecraft.entity;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderEye;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.entity.item.EntityMinecartCommandBlock;
import net.minecraft.entity.item.EntityMinecartEmpty;
import net.minecraft.entity.item.EntityMinecartFurnace;
import net.minecraft.entity.item.EntityMinecartHopper;
import net.minecraft.entity.item.EntityMinecartMobSpawner;
import net.minecraft.entity.item.EntityMinecartTNT;
import net.minecraft.entity.item.EntityPainting;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityElderGuardian;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityEndermite;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGiantZombie;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.monster.EntityHusk;
import net.minecraft.entity.monster.EntityIllusionIllager;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityPolarBear;
import net.minecraft.entity.monster.EntityShulker;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityStray;
import net.minecraft.entity.monster.EntityVex;
import net.minecraft.entity.monster.EntityVindicator;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.EntityZombieVillager;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityDonkey;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.entity.passive.EntityMooshroom;
import net.minecraft.entity.passive.EntityMule;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntitySkeletonHorse;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.passive.EntityZombieHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityDragonFireball;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.entity.projectile.EntityLlamaSpit;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.entity.projectile.EntitySpectralArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.RegistryNamespaced;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityList {
   public static final ResourceLocation field_191307_a = new ResourceLocation("lightning_bolt");
   private static final ResourceLocation field_191310_e = new ResourceLocation("player");
   private static final Logger LOGGER = LogManager.getLogger();
   public static final RegistryNamespaced<ResourceLocation, Class<? extends Entity>> field_191308_b = new RegistryNamespaced<ResourceLocation, Class<? extends Entity>>();
   public static final Map<ResourceLocation, EntityEggInfo> ENTITY_EGGS = Maps.newLinkedHashMap();
   public static final Set<ResourceLocation> field_191309_d = Sets.newHashSet();
   private static final List<String> field_191311_g = Lists.newArrayList();

   @Nullable
   public static ResourceLocation func_191301_a(Entity var0) {
      return func_191306_a(var0.getClass());
   }

   @Nullable
   public static ResourceLocation func_191306_a(Class<? extends Entity> var0) {
      return field_191308_b.getNameForObject(var0);
   }

   @Nullable
   public static String getEntityString(Entity var0) {
      int var1 = field_191308_b.getIDForObject(var0.getClass());
      return var1 == -1 ? null : (String)field_191311_g.get(var1);
   }

   @Nullable
   public static String func_191302_a(@Nullable ResourceLocation var0) {
      int var1 = field_191308_b.getIDForObject(field_191308_b.getObject(var0));
      return var1 == -1 ? null : (String)field_191311_g.get(var1);
   }

   @Nullable
   public static Class<? extends Entity> getClassFromID(int var0) {
      return field_191308_b.getObjectById(var0);
   }

   @Nullable
   public static Class<? extends Entity> func_192839_a(String var0) {
      return field_191308_b.getObject(new ResourceLocation(var0));
   }

   @Nullable
   public static Entity func_191304_a(@Nullable Class<? extends Entity> var0, World var1) {
      if (var0 == null) {
         return null;
      } else {
         try {
            return (Entity)var0.getConstructor(World.class).newInstance(var1);
         } catch (Exception var3) {
            var3.printStackTrace();
            return null;
         }
      }
   }

   @Nullable
   public static Entity createEntityByID(int var0, World var1) {
      return func_191304_a(getClassFromID(var0), var1);
   }

   @Nullable
   public static Entity createEntityByIDFromName(ResourceLocation var0, World var1) {
      return func_191304_a(field_191308_b.getObject(var0), var1);
   }

   @Nullable
   public static Entity createEntityFromNBT(NBTTagCompound var0, World var1) {
      ResourceLocation var2 = new ResourceLocation(var0.getString("id"));
      Entity var3 = createEntityByIDFromName(var2, var1);
      if (var3 == null) {
         LOGGER.warn("Skipping Entity with id {}", var2);
      } else {
         var3.readFromNBT(var0);
      }

      return var3;
   }

   public static Set<ResourceLocation> getEntityNameList() {
      return field_191309_d;
   }

   public static boolean isStringEntityName(Entity var0, ResourceLocation var1) {
      ResourceLocation var2 = func_191306_a(var0.getClass());
      if (var2 != null) {
         return var2.equals(var1);
      } else if (var0 instanceof EntityPlayer) {
         return field_191310_e.equals(var1);
      } else {
         return var0 instanceof EntityLightningBolt ? field_191307_a.equals(var1) : false;
      }
   }

   public static boolean isStringValidEntityName(ResourceLocation var0) {
      return field_191310_e.equals(var0) || getEntityNameList().contains(var0);
   }

   public static String func_192840_b() {
      StringBuilder var0 = new StringBuilder();

      for(ResourceLocation var2 : getEntityNameList()) {
         var0.append(var2).append(", ");
      }

      var0.append(field_191310_e);
      return var0.toString();
   }

   public static void init() {
      func_191303_a(1, "item", EntityItem.class, "Item");
      func_191303_a(2, "xp_orb", EntityXPOrb.class, "XPOrb");
      func_191303_a(3, "area_effect_cloud", EntityAreaEffectCloud.class, "AreaEffectCloud");
      func_191303_a(4, "elder_guardian", EntityElderGuardian.class, "ElderGuardian");
      func_191303_a(5, "wither_skeleton", EntityWitherSkeleton.class, "WitherSkeleton");
      func_191303_a(6, "stray", EntityStray.class, "Stray");
      func_191303_a(7, "egg", EntityEgg.class, "ThrownEgg");
      func_191303_a(8, "leash_knot", EntityLeashKnot.class, "LeashKnot");
      func_191303_a(9, "painting", EntityPainting.class, "Painting");
      func_191303_a(10, "arrow", EntityTippedArrow.class, "Arrow");
      func_191303_a(11, "snowball", EntitySnowball.class, "Snowball");
      func_191303_a(12, "fireball", EntityLargeFireball.class, "Fireball");
      func_191303_a(13, "small_fireball", EntitySmallFireball.class, "SmallFireball");
      func_191303_a(14, "ender_pearl", EntityEnderPearl.class, "ThrownEnderpearl");
      func_191303_a(15, "eye_of_ender_signal", EntityEnderEye.class, "EyeOfEnderSignal");
      func_191303_a(16, "potion", EntityPotion.class, "ThrownPotion");
      func_191303_a(17, "xp_bottle", EntityExpBottle.class, "ThrownExpBottle");
      func_191303_a(18, "item_frame", EntityItemFrame.class, "ItemFrame");
      func_191303_a(19, "wither_skull", EntityWitherSkull.class, "WitherSkull");
      func_191303_a(20, "tnt", EntityTNTPrimed.class, "PrimedTnt");
      func_191303_a(21, "falling_block", EntityFallingBlock.class, "FallingSand");
      func_191303_a(22, "fireworks_rocket", EntityFireworkRocket.class, "FireworksRocketEntity");
      func_191303_a(23, "husk", EntityHusk.class, "Husk");
      func_191303_a(24, "spectral_arrow", EntitySpectralArrow.class, "SpectralArrow");
      func_191303_a(25, "shulker_bullet", EntityShulkerBullet.class, "ShulkerBullet");
      func_191303_a(26, "dragon_fireball", EntityDragonFireball.class, "DragonFireball");
      func_191303_a(27, "zombie_villager", EntityZombieVillager.class, "ZombieVillager");
      func_191303_a(28, "skeleton_horse", EntitySkeletonHorse.class, "SkeletonHorse");
      func_191303_a(29, "zombie_horse", EntityZombieHorse.class, "ZombieHorse");
      func_191303_a(30, "armor_stand", EntityArmorStand.class, "ArmorStand");
      func_191303_a(31, "donkey", EntityDonkey.class, "Donkey");
      func_191303_a(32, "mule", EntityMule.class, "Mule");
      func_191303_a(33, "evocation_fangs", EntityEvokerFangs.class, "EvocationFangs");
      func_191303_a(34, "evocation_illager", EntityEvoker.class, "EvocationIllager");
      func_191303_a(35, "vex", EntityVex.class, "Vex");
      func_191303_a(36, "vindication_illager", EntityVindicator.class, "VindicationIllager");
      func_191303_a(37, "illusion_illager", EntityIllusionIllager.class, "IllusionIllager");
      func_191303_a(40, "commandblock_minecart", EntityMinecartCommandBlock.class, EntityMinecart.Type.COMMAND_BLOCK.getName());
      func_191303_a(41, "boat", EntityBoat.class, "Boat");
      func_191303_a(42, "minecart", EntityMinecartEmpty.class, EntityMinecart.Type.RIDEABLE.getName());
      func_191303_a(43, "chest_minecart", EntityMinecartChest.class, EntityMinecart.Type.CHEST.getName());
      func_191303_a(44, "furnace_minecart", EntityMinecartFurnace.class, EntityMinecart.Type.FURNACE.getName());
      func_191303_a(45, "tnt_minecart", EntityMinecartTNT.class, EntityMinecart.Type.TNT.getName());
      func_191303_a(46, "hopper_minecart", EntityMinecartHopper.class, EntityMinecart.Type.HOPPER.getName());
      func_191303_a(47, "spawner_minecart", EntityMinecartMobSpawner.class, EntityMinecart.Type.SPAWNER.getName());
      func_191303_a(50, "creeper", EntityCreeper.class, "Creeper");
      func_191303_a(51, "skeleton", EntitySkeleton.class, "Skeleton");
      func_191303_a(52, "spider", EntitySpider.class, "Spider");
      func_191303_a(53, "giant", EntityGiantZombie.class, "Giant");
      func_191303_a(54, "zombie", EntityZombie.class, "Zombie");
      func_191303_a(55, "slime", EntitySlime.class, "Slime");
      func_191303_a(56, "ghast", EntityGhast.class, "Ghast");
      func_191303_a(57, "zombie_pigman", EntityPigZombie.class, "PigZombie");
      func_191303_a(58, "enderman", EntityEnderman.class, "Enderman");
      func_191303_a(59, "cave_spider", EntityCaveSpider.class, "CaveSpider");
      func_191303_a(60, "silverfish", EntitySilverfish.class, "Silverfish");
      func_191303_a(61, "blaze", EntityBlaze.class, "Blaze");
      func_191303_a(62, "magma_cube", EntityMagmaCube.class, "LavaSlime");
      func_191303_a(63, "ender_dragon", EntityDragon.class, "EnderDragon");
      func_191303_a(64, "wither", EntityWither.class, "WitherBoss");
      func_191303_a(65, "bat", EntityBat.class, "Bat");
      func_191303_a(66, "witch", EntityWitch.class, "Witch");
      func_191303_a(67, "endermite", EntityEndermite.class, "Endermite");
      func_191303_a(68, "guardian", EntityGuardian.class, "Guardian");
      func_191303_a(69, "shulker", EntityShulker.class, "Shulker");
      func_191303_a(90, "pig", EntityPig.class, "Pig");
      func_191303_a(91, "sheep", EntitySheep.class, "Sheep");
      func_191303_a(92, "cow", EntityCow.class, "Cow");
      func_191303_a(93, "chicken", EntityChicken.class, "Chicken");
      func_191303_a(94, "squid", EntitySquid.class, "Squid");
      func_191303_a(95, "wolf", EntityWolf.class, "Wolf");
      func_191303_a(96, "mooshroom", EntityMooshroom.class, "MushroomCow");
      func_191303_a(97, "snowman", EntitySnowman.class, "SnowMan");
      func_191303_a(98, "ocelot", EntityOcelot.class, "Ozelot");
      func_191303_a(99, "villager_golem", EntityIronGolem.class, "VillagerGolem");
      func_191303_a(100, "horse", EntityHorse.class, "Horse");
      func_191303_a(101, "rabbit", EntityRabbit.class, "Rabbit");
      func_191303_a(102, "polar_bear", EntityPolarBear.class, "PolarBear");
      func_191303_a(103, "llama", EntityLlama.class, "Llama");
      func_191303_a(104, "llama_spit", EntityLlamaSpit.class, "LlamaSpit");
      func_191303_a(105, "parrot", EntityParrot.class, "Parrot");
      func_191303_a(120, "villager", EntityVillager.class, "Villager");
      func_191303_a(200, "ender_crystal", EntityEnderCrystal.class, "EnderCrystal");
      func_191305_a("bat", 4996656, 986895);
      func_191305_a("blaze", 16167425, 16775294);
      func_191305_a("cave_spider", 803406, 11013646);
      func_191305_a("chicken", 10592673, 16711680);
      func_191305_a("cow", 4470310, 10592673);
      func_191305_a("creeper", 894731, 0);
      func_191305_a("donkey", 5457209, 8811878);
      func_191305_a("elder_guardian", 13552826, 7632531);
      func_191305_a("enderman", 1447446, 0);
      func_191305_a("endermite", 1447446, 7237230);
      func_191305_a("evocation_illager", 9804699, 1973274);
      func_191305_a("ghast", 16382457, 12369084);
      func_191305_a("guardian", 5931634, 15826224);
      func_191305_a("horse", 12623485, 15656192);
      func_191305_a("husk", 7958625, 15125652);
      func_191305_a("llama", 12623485, 10051392);
      func_191305_a("magma_cube", 3407872, 16579584);
      func_191305_a("mooshroom", 10489616, 12040119);
      func_191305_a("mule", 1769984, 5321501);
      func_191305_a("ocelot", 15720061, 5653556);
      func_191305_a("parrot", 894731, 16711680);
      func_191305_a("pig", 15771042, 14377823);
      func_191305_a("polar_bear", 15921906, 9803152);
      func_191305_a("rabbit", 10051392, 7555121);
      func_191305_a("sheep", 15198183, 16758197);
      func_191305_a("shulker", 9725844, 5060690);
      func_191305_a("silverfish", 7237230, 3158064);
      func_191305_a("skeleton", 12698049, 4802889);
      func_191305_a("skeleton_horse", 6842447, 15066584);
      func_191305_a("slime", 5349438, 8306542);
      func_191305_a("spider", 3419431, 11013646);
      func_191305_a("squid", 2243405, 7375001);
      func_191305_a("stray", 6387319, 14543594);
      func_191305_a("vex", 8032420, 15265265);
      func_191305_a("villager", 5651507, 12422002);
      func_191305_a("vindication_illager", 9804699, 2580065);
      func_191305_a("witch", 3407872, 5349438);
      func_191305_a("wither_skeleton", 1315860, 4672845);
      func_191305_a("wolf", 14144467, 13545366);
      func_191305_a("zombie", 44975, 7969893);
      func_191305_a("zombie_horse", 3232308, 9945732);
      func_191305_a("zombie_pigman", 15373203, 5009705);
      func_191305_a("zombie_villager", 5651507, 7969893);
      field_191309_d.add(field_191307_a);
   }

   private static void func_191303_a(int var0, String var1, Class<? extends Entity> var2, String var3) {
      try {
         var2.getConstructor(World.class);
      } catch (NoSuchMethodException var5) {
         throw new RuntimeException("Invalid class " + var2 + " no constructor taking " + World.class.getName());
      }

      if ((var2.getModifiers() & 1024) == 1024) {
         throw new RuntimeException("Invalid abstract class " + var2);
      } else {
         ResourceLocation var4 = new ResourceLocation(var1);
         field_191308_b.register(var0, var4, var2);
         field_191309_d.add(var4);

         while(field_191311_g.size() <= var0) {
            field_191311_g.add((String)null);
         }

         field_191311_g.set(var0, var3);
      }
   }

   protected static EntityEggInfo func_191305_a(String var0, int var1, int var2) {
      ResourceLocation var3 = new ResourceLocation(var0);
      return (EntityEggInfo)ENTITY_EGGS.put(var3, new EntityEggInfo(var3, var1, var2));
   }

   public static class EntityEggInfo {
      public final ResourceLocation spawnedID;
      public final int primaryColor;
      public final int secondaryColor;
      public final StatBase killEntityStat;
      public final StatBase entityKilledByStat;

      public EntityEggInfo(ResourceLocation var1, int var2, int var3) {
         this.spawnedID = var1;
         this.primaryColor = var2;
         this.secondaryColor = var3;
         this.killEntityStat = StatList.getStatKillEntity(this);
         this.entityKilledByStat = StatList.getStatEntityKilledBy(this);
      }
   }
}
