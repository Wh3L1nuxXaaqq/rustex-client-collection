package net.minecraft.entity;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public abstract class EntityFlying extends EntityLiving {
   public EntityFlying(World var1) {
      super(var1);
   }

   public void fall(float var1, float var2) {
   }

   protected void updateFallState(double var1, boolean var3, IBlockState var4, BlockPos var5) {
   }

   public void func_191986_a(float var1, float var2, float var3) {
      if (this.isInWater()) {
         this.func_191958_b(var1, var2, var3, 0.02F);
         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         this.motionX *= (double)0.8F;
         this.motionY *= (double)0.8F;
         this.motionZ *= (double)0.8F;
      } else if (this.isInLava()) {
         this.func_191958_b(var1, var2, var3, 0.02F);
         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         this.motionX *= (double)0.5F;
         this.motionY *= (double)0.5F;
         this.motionZ *= (double)0.5F;
      } else {
         float var4 = 0.91F;
         if (this.onGround) {
            var4 = this.world.getBlockState(new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.getEntityBoundingBox().minY) - 1, MathHelper.floor(this.posZ))).getBlock().slipperiness * 0.91F;
         }

         float var5 = 0.16277136F / (var4 * var4 * var4);
         this.func_191958_b(var1, var2, var3, this.onGround ? 0.1F * var5 : 0.02F);
         var4 = 0.91F;
         if (this.onGround) {
            var4 = this.world.getBlockState(new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.getEntityBoundingBox().minY) - 1, MathHelper.floor(this.posZ))).getBlock().slipperiness * 0.91F;
         }

         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         this.motionX *= (double)var4;
         this.motionY *= (double)var4;
         this.motionZ *= (double)var4;
      }

      this.prevLimbSwingAmount = this.limbSwingAmount;
      double var10 = this.posX - this.prevPosX;
      double var6 = this.posZ - this.prevPosZ;
      float var8 = MathHelper.sqrt(var10 * var10 + var6 * var6) * 4.0F;
      if (var8 > 1.0F) {
         var8 = 1.0F;
      }

      this.limbSwingAmount += (var8 - this.limbSwingAmount) * 0.4F;
      this.limbSwing += this.limbSwingAmount;
   }

   public boolean isOnLadder() {
      return false;
   }
}
