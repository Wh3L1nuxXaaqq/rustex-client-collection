package net.minecraft.entity;

import com.google.common.collect.Maps;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.EntityJumpHelper;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.ai.EntitySenses;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.server.SPacketEntityAttach;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;
import optifine.Config;
import optifine.Reflector;

public abstract class EntityLiving extends EntityLivingBase {
   private static final DataParameter<Byte> AI_FLAGS;
   public int livingSoundTime;
   protected int experienceValue;
   private final EntityLookHelper lookHelper;
   protected EntityMoveHelper moveHelper;
   protected EntityJumpHelper jumpHelper;
   private final EntityBodyHelper bodyHelper;
   protected PathNavigate navigator;
   protected final EntityAITasks tasks;
   protected final EntityAITasks targetTasks;
   private EntityLivingBase attackTarget;
   private final EntitySenses senses;
   private final NonNullList<ItemStack> inventoryHands;
   protected float[] inventoryHandsDropChances;
   private final NonNullList<ItemStack> inventoryArmor;
   protected float[] inventoryArmorDropChances;
   private boolean canPickUpLoot;
   private boolean persistenceRequired;
   private final Map<PathNodeType, Float> mapPathPriority;
   private ResourceLocation deathLootTable;
   private long deathLootTableSeed;
   private boolean isLeashed;
   private Entity leashedToEntity;
   private NBTTagCompound leashNBTTag;
   public int randomMobsId;
   public Biome spawnBiome;
   public BlockPos spawnPosition;
   private UUID teamUuid;
   private String teamUuidString;

   public EntityLiving(World var1) {
      super(var1);
      this.inventoryHands = NonNullList.<ItemStack>func_191197_a(2, ItemStack.field_190927_a);
      this.inventoryHandsDropChances = new float[2];
      this.inventoryArmor = NonNullList.<ItemStack>func_191197_a(4, ItemStack.field_190927_a);
      this.inventoryArmorDropChances = new float[4];
      this.mapPathPriority = Maps.newEnumMap(PathNodeType.class);
      this.randomMobsId = 0;
      this.spawnBiome = null;
      this.spawnPosition = null;
      this.teamUuid = null;
      this.teamUuidString = null;
      this.tasks = new EntityAITasks(var1 != null && var1.theProfiler != null ? var1.theProfiler : null);
      this.targetTasks = new EntityAITasks(var1 != null && var1.theProfiler != null ? var1.theProfiler : null);
      this.lookHelper = new EntityLookHelper(this);
      this.moveHelper = new EntityMoveHelper(this);
      this.jumpHelper = new EntityJumpHelper(this);
      this.bodyHelper = this.createBodyHelper();
      this.navigator = this.getNewNavigator(var1);
      this.senses = new EntitySenses(this);
      Arrays.fill(this.inventoryArmorDropChances, 0.085F);
      Arrays.fill(this.inventoryHandsDropChances, 0.085F);
      if (var1 != null && !var1.isRemote) {
         this.initEntityAI();
      }

      UUID var2 = this.getUniqueID();
      long var3 = var2.getLeastSignificantBits();
      this.randomMobsId = (int)(var3 & 2147483647L);
   }

   protected void initEntityAI() {
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue((double)16.0F);
   }

   protected PathNavigate getNewNavigator(World var1) {
      return new PathNavigateGround(this, var1);
   }

   public float getPathPriority(PathNodeType var1) {
      Float var2 = (Float)this.mapPathPriority.get(var1);
      return var2 == null ? var1.getPriority() : var2;
   }

   public void setPathPriority(PathNodeType var1, float var2) {
      this.mapPathPriority.put(var1, var2);
   }

   protected EntityBodyHelper createBodyHelper() {
      return new EntityBodyHelper(this);
   }

   public EntityLookHelper getLookHelper() {
      return this.lookHelper;
   }

   public EntityMoveHelper getMoveHelper() {
      return this.moveHelper;
   }

   public EntityJumpHelper getJumpHelper() {
      return this.jumpHelper;
   }

   public PathNavigate getNavigator() {
      return this.navigator;
   }

   public EntitySenses getEntitySenses() {
      return this.senses;
   }

   @Nullable
   public EntityLivingBase getAttackTarget() {
      return this.attackTarget;
   }

   public void setAttackTarget(@Nullable EntityLivingBase var1) {
      this.attackTarget = var1;
      Reflector.callVoid(Reflector.ForgeHooks_onLivingSetAttackTarget, this, var1);
   }

   public boolean canAttackClass(Class<? extends EntityLivingBase> var1) {
      return var1 != EntityGhast.class;
   }

   public void eatGrassBonus() {
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(AI_FLAGS, (byte)0);
   }

   public int getTalkInterval() {
      return 80;
   }

   public void playLivingSound() {
      SoundEvent var1 = this.getAmbientSound();
      if (var1 != null) {
         this.playSound(var1, this.getSoundVolume(), this.getSoundPitch());
      }

   }

   public void onEntityUpdate() {
      super.onEntityUpdate();
      this.world.theProfiler.startSection("mobBaseTick");
      if (this.isEntityAlive() && this.rand.nextInt(1000) < this.livingSoundTime++) {
         this.applyEntityAI();
         this.playLivingSound();
      }

      this.world.theProfiler.endSection();
   }

   protected void playHurtSound(DamageSource var1) {
      this.applyEntityAI();
      super.playHurtSound(var1);
   }

   private void applyEntityAI() {
      this.livingSoundTime = -this.getTalkInterval();
   }

   protected int getExperiencePoints(EntityPlayer var1) {
      if (this.experienceValue > 0) {
         int var2 = this.experienceValue;

         for(int var3 = 0; var3 < this.inventoryArmor.size(); ++var3) {
            if (!((ItemStack)this.inventoryArmor.get(var3)).func_190926_b() && this.inventoryArmorDropChances[var3] <= 1.0F) {
               var2 += 1 + this.rand.nextInt(3);
            }
         }

         for(int var4 = 0; var4 < this.inventoryHands.size(); ++var4) {
            if (!((ItemStack)this.inventoryHands.get(var4)).func_190926_b() && this.inventoryHandsDropChances[var4] <= 1.0F) {
               var2 += 1 + this.rand.nextInt(3);
            }
         }

         return var2;
      } else {
         return this.experienceValue;
      }
   }

   public void spawnExplosionParticle() {
      if (this.world.isRemote) {
         for(int var1 = 0; var1 < 20; ++var1) {
            double var2 = this.rand.nextGaussian() * 0.02;
            double var4 = this.rand.nextGaussian() * 0.02;
            double var6 = this.rand.nextGaussian() * 0.02;
            double var8 = (double)10.0F;
            this.world.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width - var2 * (double)10.0F, this.posY + (double)(this.rand.nextFloat() * this.height) - var4 * (double)10.0F, this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width - var6 * (double)10.0F, var2, var4, var6);
         }
      } else {
         this.world.setEntityState(this, (byte)20);
      }

   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 20) {
         this.spawnExplosionParticle();
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   public void onUpdate() {
      if (Config.isSmoothWorld() && this.canSkipUpdate()) {
         this.onUpdateMinimal();
      } else {
         super.onUpdate();
         if (!this.world.isRemote) {
            this.updateLeashedState();
            if (this.ticksExisted % 5 == 0) {
               boolean var1 = !(this.getControllingPassenger() instanceof EntityLiving);
               boolean var2 = !(this.getRidingEntity() instanceof EntityBoat);
               this.tasks.setControlFlag(1, var1);
               this.tasks.setControlFlag(4, var1 && var2);
               this.tasks.setControlFlag(2, var1);
            }
         }
      }

   }

   protected float updateDistance(float var1, float var2) {
      this.bodyHelper.updateRenderAngles();
      return var2;
   }

   @Nullable
   protected SoundEvent getAmbientSound() {
      return null;
   }

   @Nullable
   protected Item getDropItem() {
      return null;
   }

   protected void dropFewItems(boolean var1, int var2) {
      Item var3 = this.getDropItem();
      if (var3 != null) {
         int var4 = this.rand.nextInt(3);
         if (var2 > 0) {
            var4 += this.rand.nextInt(var2 + 1);
         }

         for(int var5 = 0; var5 < var4; ++var5) {
            this.dropItem(var3, 1);
         }
      }

   }

   public static void registerFixesMob(DataFixer var0, Class<?> var1) {
      var0.registerWalker(FixTypes.ENTITY, new ItemStackDataLists(var1, new String[]{"ArmorItems", "HandItems"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      var1.setBoolean("CanPickUpLoot", this.canPickUpLoot());
      var1.setBoolean("PersistenceRequired", this.persistenceRequired);
      NBTTagList var2 = new NBTTagList();

      for(ItemStack var4 : this.inventoryArmor) {
         NBTTagCompound var5 = new NBTTagCompound();
         if (!var4.func_190926_b()) {
            var4.writeToNBT(var5);
         }

         var2.appendTag(var5);
      }

      var1.setTag("ArmorItems", var2);
      NBTTagList var10 = new NBTTagList();

      for(ItemStack var13 : this.inventoryHands) {
         NBTTagCompound var6 = new NBTTagCompound();
         if (!var13.func_190926_b()) {
            var13.writeToNBT(var6);
         }

         var10.appendTag(var6);
      }

      var1.setTag("HandItems", var10);
      NBTTagList var12 = new NBTTagList();

      for(float var8 : this.inventoryArmorDropChances) {
         var12.appendTag(new NBTTagFloat(var8));
      }

      var1.setTag("ArmorDropChances", var12);
      NBTTagList var15 = new NBTTagList();

      for(float var9 : this.inventoryHandsDropChances) {
         var15.appendTag(new NBTTagFloat(var9));
      }

      var1.setTag("HandDropChances", var15);
      var1.setBoolean("Leashed", this.isLeashed);
      if (this.leashedToEntity != null) {
         NBTTagCompound var18 = new NBTTagCompound();
         if (this.leashedToEntity instanceof EntityLivingBase) {
            UUID var20 = this.leashedToEntity.getUniqueID();
            var18.setUniqueId("UUID", var20);
         } else if (this.leashedToEntity instanceof EntityHanging) {
            BlockPos var21 = ((EntityHanging)this.leashedToEntity).getHangingPosition();
            var18.setInteger("X", var21.getX());
            var18.setInteger("Y", var21.getY());
            var18.setInteger("Z", var21.getZ());
         }

         var1.setTag("Leash", var18);
      }

      var1.setBoolean("LeftHanded", this.isLeftHanded());
      if (this.deathLootTable != null) {
         var1.setString("DeathLootTable", this.deathLootTable.toString());
         if (this.deathLootTableSeed != 0L) {
            var1.setLong("DeathLootTableSeed", this.deathLootTableSeed);
         }
      }

      if (this.isAIDisabled()) {
         var1.setBoolean("NoAI", this.isAIDisabled());
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.hasKey("CanPickUpLoot", 1)) {
         this.setCanPickUpLoot(var1.getBoolean("CanPickUpLoot"));
      }

      this.persistenceRequired = var1.getBoolean("PersistenceRequired");
      if (var1.hasKey("ArmorItems", 9)) {
         NBTTagList var2 = var1.getTagList("ArmorItems", 10);

         for(int var3 = 0; var3 < this.inventoryArmor.size(); ++var3) {
            this.inventoryArmor.set(var3, new ItemStack(var2.getCompoundTagAt(var3)));
         }
      }

      if (var1.hasKey("HandItems", 9)) {
         NBTTagList var4 = var1.getTagList("HandItems", 10);

         for(int var7 = 0; var7 < this.inventoryHands.size(); ++var7) {
            this.inventoryHands.set(var7, new ItemStack(var4.getCompoundTagAt(var7)));
         }
      }

      if (var1.hasKey("ArmorDropChances", 9)) {
         NBTTagList var5 = var1.getTagList("ArmorDropChances", 5);

         for(int var8 = 0; var8 < var5.tagCount(); ++var8) {
            this.inventoryArmorDropChances[var8] = var5.getFloatAt(var8);
         }
      }

      if (var1.hasKey("HandDropChances", 9)) {
         NBTTagList var6 = var1.getTagList("HandDropChances", 5);

         for(int var9 = 0; var9 < var6.tagCount(); ++var9) {
            this.inventoryHandsDropChances[var9] = var6.getFloatAt(var9);
         }
      }

      this.isLeashed = var1.getBoolean("Leashed");
      if (this.isLeashed && var1.hasKey("Leash", 10)) {
         this.leashNBTTag = var1.getCompoundTag("Leash");
      }

      this.setLeftHanded(var1.getBoolean("LeftHanded"));
      if (var1.hasKey("DeathLootTable", 8)) {
         this.deathLootTable = new ResourceLocation(var1.getString("DeathLootTable"));
         this.deathLootTableSeed = var1.getLong("DeathLootTableSeed");
      }

      this.setNoAI(var1.getBoolean("NoAI"));
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return null;
   }

   protected void dropLoot(boolean var1, int var2, DamageSource var3) {
      ResourceLocation var4 = this.deathLootTable;
      if (var4 == null) {
         var4 = this.getLootTable();
      }

      if (var4 != null) {
         LootTable var5 = this.world.getLootTableManager().getLootTableFromLocation(var4);
         this.deathLootTable = null;
         LootContext.Builder var6 = (new LootContext.Builder((WorldServer)this.world)).withLootedEntity(this).withDamageSource(var3);
         if (var1 && this.attackingPlayer != null) {
            var6 = var6.withPlayer(this.attackingPlayer).withLuck(this.attackingPlayer.getLuck());
         }

         for(ItemStack var8 : var5.generateLootForPools(this.deathLootTableSeed == 0L ? this.rand : new Random(this.deathLootTableSeed), var6.build())) {
            this.entityDropItem(var8, 0.0F);
         }

         this.dropEquipment(var1, var2);
      } else {
         super.dropLoot(var1, var2, var3);
      }

   }

   public void func_191989_p(float var1) {
      this.field_191988_bg = var1;
   }

   public void setMoveForward(float var1) {
      this.moveForward = var1;
   }

   public void setMoveStrafing(float var1) {
      this.moveStrafing = var1;
   }

   public void setAIMoveSpeed(float var1) {
      super.setAIMoveSpeed(var1);
      this.func_191989_p(var1);
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      this.world.theProfiler.startSection("looting");
      if (!this.world.isRemote && this.canPickUpLoot() && !this.dead && this.world.getGameRules().getBoolean("mobGriefing")) {
         for(EntityItem var2 : this.world.getEntitiesWithinAABB(EntityItem.class, this.getEntityBoundingBox().expand((double)1.0F, (double)0.0F, (double)1.0F))) {
            if (!var2.isDead && !var2.getEntityItem().func_190926_b() && !var2.cannotPickup()) {
               this.updateEquipmentIfNeeded(var2);
            }
         }
      }

      this.world.theProfiler.endSection();
   }

   protected void updateEquipmentIfNeeded(EntityItem var1) {
      ItemStack var2 = var1.getEntityItem();
      EntityEquipmentSlot var3 = getSlotForItemStack(var2);
      boolean var4 = true;
      ItemStack var5 = this.getItemStackFromSlot(var3);
      if (!var5.func_190926_b()) {
         if (var3.getSlotType() == EntityEquipmentSlot.Type.HAND) {
            if (var2.getItem() instanceof ItemSword && !(var5.getItem() instanceof ItemSword)) {
               var4 = true;
            } else if (var2.getItem() instanceof ItemSword && var5.getItem() instanceof ItemSword) {
               ItemSword var6 = (ItemSword)var2.getItem();
               ItemSword var7 = (ItemSword)var5.getItem();
               if (var6.getDamageVsEntity() == var7.getDamageVsEntity()) {
                  var4 = var2.getMetadata() > var5.getMetadata() || var2.hasTagCompound() && !var5.hasTagCompound();
               } else {
                  var4 = var6.getDamageVsEntity() > var7.getDamageVsEntity();
               }
            } else if (var2.getItem() instanceof ItemBow && var5.getItem() instanceof ItemBow) {
               var4 = var2.hasTagCompound() && !var5.hasTagCompound();
            } else {
               var4 = false;
            }
         } else if (var2.getItem() instanceof ItemArmor && !(var5.getItem() instanceof ItemArmor)) {
            var4 = true;
         } else if (var2.getItem() instanceof ItemArmor && var5.getItem() instanceof ItemArmor && !EnchantmentHelper.func_190938_b(var5)) {
            ItemArmor var8 = (ItemArmor)var2.getItem();
            ItemArmor var10 = (ItemArmor)var5.getItem();
            if (var8.damageReduceAmount == var10.damageReduceAmount) {
               var4 = var2.getMetadata() > var5.getMetadata() || var2.hasTagCompound() && !var5.hasTagCompound();
            } else {
               var4 = var8.damageReduceAmount > var10.damageReduceAmount;
            }
         } else {
            var4 = false;
         }
      }

      if (var4 && this.canEquipItem(var2)) {
         double var9;
         switch (var3.getSlotType()) {
            case HAND:
               var9 = (double)this.inventoryHandsDropChances[var3.getIndex()];
               break;
            case ARMOR:
               var9 = (double)this.inventoryArmorDropChances[var3.getIndex()];
               break;
            default:
               var9 = (double)0.0F;
         }

         if (!var5.func_190926_b() && (double)(this.rand.nextFloat() - 0.1F) < var9) {
            this.entityDropItem(var5, 0.0F);
         }

         this.setItemStackToSlot(var3, var2);
         switch (var3.getSlotType()) {
            case HAND:
               this.inventoryHandsDropChances[var3.getIndex()] = 2.0F;
               break;
            case ARMOR:
               this.inventoryArmorDropChances[var3.getIndex()] = 2.0F;
         }

         this.persistenceRequired = true;
         this.onItemPickup(var1, var2.func_190916_E());
         var1.setDead();
      }

   }

   protected boolean canEquipItem(ItemStack var1) {
      return true;
   }

   protected boolean canDespawn() {
      return true;
   }

   protected void despawnEntity() {
      Object var1 = null;
      Object var2 = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
      Object var3 = Reflector.getFieldValue(Reflector.Event_Result_DENY);
      if (this.persistenceRequired) {
         this.entityAge = 0;
      } else if ((this.entityAge & 31) == 31 && (var1 = Reflector.call(Reflector.ForgeEventFactory_canEntityDespawn, this)) != var2) {
         if (var1 == var3) {
            this.entityAge = 0;
         } else {
            this.setDead();
         }
      } else {
         EntityPlayer var4 = this.world.getClosestPlayerToEntity(this, (double)-1.0F);
         if (var4 != null) {
            double var5 = var4.posX - this.posX;
            double var7 = var4.posY - this.posY;
            double var9 = var4.posZ - this.posZ;
            double var11 = var5 * var5 + var7 * var7 + var9 * var9;
            if (this.canDespawn() && var11 > (double)16384.0F) {
               this.setDead();
            }

            if (this.entityAge > 600 && this.rand.nextInt(800) == 0 && var11 > (double)1024.0F && this.canDespawn()) {
               this.setDead();
            } else if (var11 < (double)1024.0F) {
               this.entityAge = 0;
            }
         }
      }

   }

   protected final void updateEntityActionState() {
      ++this.entityAge;
      this.world.theProfiler.startSection("checkDespawn");
      this.despawnEntity();
      this.world.theProfiler.endSection();
      this.world.theProfiler.startSection("sensing");
      this.senses.clearSensingCache();
      this.world.theProfiler.endSection();
      this.world.theProfiler.startSection("targetSelector");
      this.targetTasks.onUpdateTasks();
      this.world.theProfiler.endSection();
      this.world.theProfiler.startSection("goalSelector");
      this.tasks.onUpdateTasks();
      this.world.theProfiler.endSection();
      this.world.theProfiler.startSection("navigation");
      this.navigator.onUpdateNavigation();
      this.world.theProfiler.endSection();
      this.world.theProfiler.startSection("mob tick");
      this.updateAITasks();
      this.world.theProfiler.endSection();
      if (this.isRiding() && this.getRidingEntity() instanceof EntityLiving) {
         EntityLiving var1 = (EntityLiving)this.getRidingEntity();
         var1.getNavigator().setPath(this.getNavigator().getPath(), (double)1.5F);
         var1.getMoveHelper().read(this.getMoveHelper());
      }

      this.world.theProfiler.startSection("controls");
      this.world.theProfiler.startSection("move");
      this.moveHelper.onUpdateMoveHelper();
      this.world.theProfiler.endStartSection("look");
      this.lookHelper.onUpdateLook();
      this.world.theProfiler.endStartSection("jump");
      this.jumpHelper.doJump();
      this.world.theProfiler.endSection();
      this.world.theProfiler.endSection();
   }

   protected void updateAITasks() {
   }

   public int getVerticalFaceSpeed() {
      return 40;
   }

   public int getHorizontalFaceSpeed() {
      return 10;
   }

   public void faceEntity(Entity var1, float var2, float var3) {
      double var4 = var1.posX - this.posX;
      double var6 = var1.posZ - this.posZ;
      double var8;
      if (var1 instanceof EntityLivingBase) {
         EntityLivingBase var10 = (EntityLivingBase)var1;
         var8 = var10.posY + (double)var10.getEyeHeight() - (this.posY + (double)this.getEyeHeight());
      } else {
         var8 = (var1.getEntityBoundingBox().minY + var1.getEntityBoundingBox().maxY) / (double)2.0F - (this.posY + (double)this.getEyeHeight());
      }

      double var14 = (double)MathHelper.sqrt(var4 * var4 + var6 * var6);
      float var12 = (float)(MathHelper.atan2(var6, var4) * (180D / Math.PI)) - 90.0F;
      float var13 = (float)(-(MathHelper.atan2(var8, var14) * (180D / Math.PI)));
      this.rotationPitch = this.updateRotation(this.rotationPitch, var13, var3);
      this.rotationYaw = this.updateRotation(this.rotationYaw, var12, var2);
   }

   private float updateRotation(float var1, float var2, float var3) {
      float var4 = MathHelper.wrapDegrees(var2 - var1);
      if (var4 > var3) {
         var4 = var3;
      }

      if (var4 < -var3) {
         var4 = -var3;
      }

      return var1 + var4;
   }

   public boolean getCanSpawnHere() {
      IBlockState var1 = this.world.getBlockState((new BlockPos(this)).down());
      return var1.canEntitySpawn(this);
   }

   public boolean isNotColliding() {
      return !this.world.containsAnyLiquid(this.getEntityBoundingBox()) && this.world.getCollisionBoxes(this, this.getEntityBoundingBox()).isEmpty() && this.world.checkNoEntityCollision(this.getEntityBoundingBox(), this);
   }

   public float getRenderSizeModifier() {
      return 1.0F;
   }

   public int getMaxSpawnedInChunk() {
      return 4;
   }

   public int getMaxFallHeight() {
      if (this.getAttackTarget() == null) {
         return 3;
      } else {
         int var1 = (int)(this.getHealth() - this.getMaxHealth() * 0.33F);
         var1 -= (3 - this.world.getDifficulty().getDifficultyId()) * 4;
         if (var1 < 0) {
            var1 = 0;
         }

         return var1 + 3;
      }
   }

   public Iterable<ItemStack> getHeldEquipment() {
      return this.inventoryHands;
   }

   public Iterable<ItemStack> getArmorInventoryList() {
      return this.inventoryArmor;
   }

   public ItemStack getItemStackFromSlot(EntityEquipmentSlot var1) {
      switch (var1.getSlotType()) {
         case HAND:
            return this.inventoryHands.get(var1.getIndex());
         case ARMOR:
            return this.inventoryArmor.get(var1.getIndex());
         default:
            return ItemStack.field_190927_a;
      }
   }

   public void setItemStackToSlot(EntityEquipmentSlot var1, ItemStack var2) {
      switch (var1.getSlotType()) {
         case HAND:
            this.inventoryHands.set(var1.getIndex(), var2);
            break;
         case ARMOR:
            this.inventoryArmor.set(var1.getIndex(), var2);
      }

   }

   protected void dropEquipment(boolean var1, int var2) {
      for(EntityEquipmentSlot var6 : EntityEquipmentSlot.values()) {
         ItemStack var7 = this.getItemStackFromSlot(var6);
         double var8;
         switch (var6.getSlotType()) {
            case HAND:
               var8 = (double)this.inventoryHandsDropChances[var6.getIndex()];
               break;
            case ARMOR:
               var8 = (double)this.inventoryArmorDropChances[var6.getIndex()];
               break;
            default:
               var8 = (double)0.0F;
         }

         boolean var10 = var8 > (double)1.0F;
         if (!var7.func_190926_b() && !EnchantmentHelper.func_190939_c(var7) && (var1 || var10) && (double)(this.rand.nextFloat() - (float)var2 * 0.01F) < var8) {
            if (!var10 && var7.isItemStackDamageable()) {
               var7.setItemDamage(var7.getMaxDamage() - this.rand.nextInt(1 + this.rand.nextInt(Math.max(var7.getMaxDamage() - 3, 1))));
            }

            this.entityDropItem(var7, 0.0F);
         }
      }

   }

   protected void setEquipmentBasedOnDifficulty(DifficultyInstance var1) {
      if (this.rand.nextFloat() < 0.15F * var1.getClampedAdditionalDifficulty()) {
         int var2 = this.rand.nextInt(2);
         float var3 = this.world.getDifficulty() == EnumDifficulty.HARD ? 0.1F : 0.25F;
         if (this.rand.nextFloat() < 0.095F) {
            ++var2;
         }

         if (this.rand.nextFloat() < 0.095F) {
            ++var2;
         }

         if (this.rand.nextFloat() < 0.095F) {
            ++var2;
         }

         boolean var4 = true;

         for(EntityEquipmentSlot var8 : EntityEquipmentSlot.values()) {
            if (var8.getSlotType() == EntityEquipmentSlot.Type.ARMOR) {
               ItemStack var9 = this.getItemStackFromSlot(var8);
               if (!var4 && this.rand.nextFloat() < var3) {
                  break;
               }

               var4 = false;
               if (var9.func_190926_b()) {
                  Item var10 = getArmorByChance(var8, var2);
                  if (var10 != null) {
                     this.setItemStackToSlot(var8, new ItemStack(var10));
                  }
               }
            }
         }
      }

   }

   public static EntityEquipmentSlot getSlotForItemStack(ItemStack var0) {
      if (var0.getItem() != Item.getItemFromBlock(Blocks.PUMPKIN) && var0.getItem() != Items.SKULL) {
         if (var0.getItem() instanceof ItemArmor) {
            return ((ItemArmor)var0.getItem()).armorType;
         } else if (var0.getItem() == Items.ELYTRA) {
            return EntityEquipmentSlot.CHEST;
         } else {
            boolean var1 = var0.getItem() == Items.SHIELD;
            if (Reflector.ForgeItem_isShield.exists()) {
               var1 = Reflector.callBoolean(var0.getItem(), Reflector.ForgeItem_isShield, var0, null);
            }

            return var1 ? EntityEquipmentSlot.OFFHAND : EntityEquipmentSlot.MAINHAND;
         }
      } else {
         return EntityEquipmentSlot.HEAD;
      }
   }

   @Nullable
   public static Item getArmorByChance(EntityEquipmentSlot var0, int var1) {
      switch (var0) {
         case HEAD:
            if (var1 == 0) {
               return Items.LEATHER_HELMET;
            } else if (var1 == 1) {
               return Items.GOLDEN_HELMET;
            } else if (var1 == 2) {
               return Items.CHAINMAIL_HELMET;
            } else if (var1 == 3) {
               return Items.IRON_HELMET;
            } else if (var1 == 4) {
               return Items.DIAMOND_HELMET;
            }
         case CHEST:
            if (var1 == 0) {
               return Items.LEATHER_CHESTPLATE;
            } else if (var1 == 1) {
               return Items.GOLDEN_CHESTPLATE;
            } else if (var1 == 2) {
               return Items.CHAINMAIL_CHESTPLATE;
            } else if (var1 == 3) {
               return Items.IRON_CHESTPLATE;
            } else if (var1 == 4) {
               return Items.DIAMOND_CHESTPLATE;
            }
         case LEGS:
            if (var1 == 0) {
               return Items.LEATHER_LEGGINGS;
            } else if (var1 == 1) {
               return Items.GOLDEN_LEGGINGS;
            } else if (var1 == 2) {
               return Items.CHAINMAIL_LEGGINGS;
            } else if (var1 == 3) {
               return Items.IRON_LEGGINGS;
            } else if (var1 == 4) {
               return Items.DIAMOND_LEGGINGS;
            }
         case FEET:
            if (var1 == 0) {
               return Items.LEATHER_BOOTS;
            } else if (var1 == 1) {
               return Items.GOLDEN_BOOTS;
            } else if (var1 == 2) {
               return Items.CHAINMAIL_BOOTS;
            } else if (var1 == 3) {
               return Items.IRON_BOOTS;
            } else if (var1 == 4) {
               return Items.DIAMOND_BOOTS;
            }
         default:
            return null;
      }
   }

   protected void setEnchantmentBasedOnDifficulty(DifficultyInstance var1) {
      float var2 = var1.getClampedAdditionalDifficulty();
      if (!this.getHeldItemMainhand().func_190926_b() && this.rand.nextFloat() < 0.25F * var2) {
         this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, EnchantmentHelper.addRandomEnchantment(this.rand, this.getHeldItemMainhand(), (int)(5.0F + var2 * (float)this.rand.nextInt(18)), false));
      }

      for(EntityEquipmentSlot var6 : EntityEquipmentSlot.values()) {
         if (var6.getSlotType() == EntityEquipmentSlot.Type.ARMOR) {
            ItemStack var7 = this.getItemStackFromSlot(var6);
            if (!var7.func_190926_b() && this.rand.nextFloat() < 0.5F * var2) {
               this.setItemStackToSlot(var6, EnchantmentHelper.addRandomEnchantment(this.rand, var7, (int)(5.0F + var2 * (float)this.rand.nextInt(18)), false));
            }
         }
      }

   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).applyModifier(new AttributeModifier("Random spawn bonus", this.rand.nextGaussian() * 0.05, 1));
      if (this.rand.nextFloat() < 0.05F) {
         this.setLeftHanded(true);
      } else {
         this.setLeftHanded(false);
      }

      return var2;
   }

   public boolean canBeSteered() {
      return false;
   }

   public void enablePersistence() {
      this.persistenceRequired = true;
   }

   public void setDropChance(EntityEquipmentSlot var1, float var2) {
      switch (var1.getSlotType()) {
         case HAND:
            this.inventoryHandsDropChances[var1.getIndex()] = var2;
            break;
         case ARMOR:
            this.inventoryArmorDropChances[var1.getIndex()] = var2;
      }

   }

   public boolean canPickUpLoot() {
      return this.canPickUpLoot;
   }

   public void setCanPickUpLoot(boolean var1) {
      this.canPickUpLoot = var1;
   }

   public boolean isNoDespawnRequired() {
      return this.persistenceRequired;
   }

   public final boolean processInitialInteract(EntityPlayer var1, EnumHand var2) {
      if (this.getLeashed() && this.getLeashedToEntity() == var1) {
         this.clearLeashed(true, !var1.capabilities.isCreativeMode);
         return true;
      } else {
         ItemStack var3 = var1.getHeldItem(var2);
         if (var3.getItem() == Items.LEAD && this.canBeLeashedTo(var1)) {
            this.setLeashedToEntity(var1, true);
            var3.func_190918_g(1);
            return true;
         } else {
            return this.processInteract(var1, var2) ? true : super.processInitialInteract(var1, var2);
         }
      }
   }

   protected boolean processInteract(EntityPlayer var1, EnumHand var2) {
      return false;
   }

   protected void updateLeashedState() {
      if (this.leashNBTTag != null) {
         this.recreateLeash();
      }

      if (this.isLeashed) {
         if (!this.isEntityAlive()) {
            this.clearLeashed(true, true);
         }

         if (this.leashedToEntity == null || this.leashedToEntity.isDead) {
            this.clearLeashed(true, true);
         }
      }

   }

   public void clearLeashed(boolean var1, boolean var2) {
      if (this.isLeashed) {
         this.isLeashed = false;
         this.leashedToEntity = null;
         if (!this.world.isRemote && var2) {
            this.dropItem(Items.LEAD, 1);
         }

         if (!this.world.isRemote && var1 && this.world instanceof WorldServer) {
            ((WorldServer)this.world).getEntityTracker().sendToAllTrackingEntity(this, new SPacketEntityAttach(this, (Entity)null));
         }
      }

   }

   public boolean canBeLeashedTo(EntityPlayer var1) {
      return !this.getLeashed() && !(this instanceof IMob);
   }

   public boolean getLeashed() {
      return this.isLeashed;
   }

   public Entity getLeashedToEntity() {
      return this.leashedToEntity;
   }

   public void setLeashedToEntity(Entity var1, boolean var2) {
      this.isLeashed = true;
      this.leashedToEntity = var1;
      if (!this.world.isRemote && var2 && this.world instanceof WorldServer) {
         ((WorldServer)this.world).getEntityTracker().sendToAllTrackingEntity(this, new SPacketEntityAttach(this, this.leashedToEntity));
      }

      if (this.isRiding()) {
         this.dismountRidingEntity();
      }

   }

   public boolean startRiding(Entity var1, boolean var2) {
      boolean var3 = super.startRiding(var1, var2);
      if (var3 && this.getLeashed()) {
         this.clearLeashed(true, true);
      }

      return var3;
   }

   private void recreateLeash() {
      if (this.isLeashed && this.leashNBTTag != null) {
         if (this.leashNBTTag.hasUniqueId("UUID")) {
            UUID var1 = this.leashNBTTag.getUniqueId("UUID");

            for(EntityLivingBase var3 : this.world.getEntitiesWithinAABB(EntityLivingBase.class, this.getEntityBoundingBox().expandXyz((double)10.0F))) {
               if (var3.getUniqueID().equals(var1)) {
                  this.setLeashedToEntity(var3, true);
                  break;
               }
            }
         } else if (this.leashNBTTag.hasKey("X", 99) && this.leashNBTTag.hasKey("Y", 99) && this.leashNBTTag.hasKey("Z", 99)) {
            BlockPos var4 = new BlockPos(this.leashNBTTag.getInteger("X"), this.leashNBTTag.getInteger("Y"), this.leashNBTTag.getInteger("Z"));
            EntityLeashKnot var5 = EntityLeashKnot.getKnotForPosition(this.world, var4);
            if (var5 == null) {
               var5 = EntityLeashKnot.createKnot(this.world, var4);
            }

            this.setLeashedToEntity(var5, true);
         } else {
            this.clearLeashed(false, true);
         }
      }

      this.leashNBTTag = null;
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      EntityEquipmentSlot var3;
      if (var1 == 98) {
         var3 = EntityEquipmentSlot.MAINHAND;
      } else if (var1 == 99) {
         var3 = EntityEquipmentSlot.OFFHAND;
      } else if (var1 == 100 + EntityEquipmentSlot.HEAD.getIndex()) {
         var3 = EntityEquipmentSlot.HEAD;
      } else if (var1 == 100 + EntityEquipmentSlot.CHEST.getIndex()) {
         var3 = EntityEquipmentSlot.CHEST;
      } else if (var1 == 100 + EntityEquipmentSlot.LEGS.getIndex()) {
         var3 = EntityEquipmentSlot.LEGS;
      } else {
         if (var1 != 100 + EntityEquipmentSlot.FEET.getIndex()) {
            return false;
         }

         var3 = EntityEquipmentSlot.FEET;
      }

      if (!var2.func_190926_b() && !isItemStackInSlot(var3, var2) && var3 != EntityEquipmentSlot.HEAD) {
         return false;
      } else {
         this.setItemStackToSlot(var3, var2);
         return true;
      }
   }

   public boolean canPassengerSteer() {
      return this.canBeSteered() && super.canPassengerSteer();
   }

   public static boolean isItemStackInSlot(EntityEquipmentSlot var0, ItemStack var1) {
      EntityEquipmentSlot var2 = getSlotForItemStack(var1);
      return var2 == var0 || var2 == EntityEquipmentSlot.MAINHAND && var0 == EntityEquipmentSlot.OFFHAND || var2 == EntityEquipmentSlot.OFFHAND && var0 == EntityEquipmentSlot.MAINHAND;
   }

   public boolean isServerWorld() {
      return super.isServerWorld() && !this.isAIDisabled();
   }

   public void setNoAI(boolean var1) {
      byte var2 = (Byte)this.dataManager.get(AI_FLAGS);
      this.dataManager.set(AI_FLAGS, var1 ? (byte)(var2 | 1) : (byte)(var2 & -2));
   }

   public void setLeftHanded(boolean var1) {
      byte var2 = (Byte)this.dataManager.get(AI_FLAGS);
      this.dataManager.set(AI_FLAGS, var1 ? (byte)(var2 | 2) : (byte)(var2 & -3));
   }

   public boolean isAIDisabled() {
      return ((Byte)this.dataManager.get(AI_FLAGS) & 1) != 0;
   }

   public boolean isLeftHanded() {
      return ((Byte)this.dataManager.get(AI_FLAGS) & 2) != 0;
   }

   public EnumHandSide getPrimaryHand() {
      return this.isLeftHanded() ? EnumHandSide.LEFT : EnumHandSide.RIGHT;
   }

   private boolean canSkipUpdate() {
      if (this.isChild()) {
         return false;
      } else if (this.hurtTime > 0) {
         return false;
      } else if (this.ticksExisted < 20) {
         return false;
      } else {
         World var1 = this.getEntityWorld();
         if (var1 == null) {
            return false;
         } else if (var1.playerEntities.size() != 1) {
            return false;
         } else {
            Entity var2 = (Entity)var1.playerEntities.get(0);
            double var3 = Math.max(Math.abs(this.posX - var2.posX) - (double)16.0F, (double)0.0F);
            double var5 = Math.max(Math.abs(this.posZ - var2.posZ) - (double)16.0F, (double)0.0F);
            double var7 = var3 * var3 + var5 * var5;
            return !this.isInRangeToRenderDist(var7);
         }
      }
   }

   private void onUpdateMinimal() {
      ++this.entityAge;
      if (this instanceof EntityMob) {
         float var1 = this.getBrightness();
         if (var1 > 0.5F) {
            this.entityAge += 2;
         }
      }

      this.despawnEntity();
   }

   public Team getTeam() {
      UUID var1 = this.getUniqueID();
      if (this.teamUuid != var1) {
         this.teamUuid = var1;
         this.teamUuidString = var1.toString();
      }

      return this.world.getScoreboard().getPlayersTeam(this.teamUuidString);
   }

   static {
      AI_FLAGS = EntityDataManager.<Byte>createKey(EntityLiving.class, DataSerializers.BYTE);
   }

   public static enum SpawnPlacementType {
      ON_GROUND,
      IN_AIR,
      IN_WATER;
   }
}
