package net.minecraft.entity;

import java.util.Collection;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.ai.attributes.AbstractAttributeMap;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SharedMonsterAttributes {
   private static final Logger LOGGER = LogManager.getLogger();
   public static final IAttribute MAX_HEALTH = (new RangedAttribute((IAttribute)null, "generic.maxHealth", (double)20.0F, (double)0.0F, (double)1024.0F)).setDescription("Max Health").setShouldWatch(true);
   public static final IAttribute FOLLOW_RANGE = (new RangedAttribute((IAttribute)null, "generic.followRange", (double)32.0F, (double)0.0F, (double)2048.0F)).setDescription("Follow Range");
   public static final IAttribute KNOCKBACK_RESISTANCE = (new RangedAttribute((IAttribute)null, "generic.knockbackResistance", (double)0.0F, (double)0.0F, (double)1.0F)).setDescription("Knockback Resistance");
   public static final IAttribute MOVEMENT_SPEED = (new RangedAttribute((IAttribute)null, "generic.movementSpeed", (double)0.7F, (double)0.0F, (double)1024.0F)).setDescription("Movement Speed").setShouldWatch(true);
   public static final IAttribute field_193334_e = (new RangedAttribute((IAttribute)null, "generic.flyingSpeed", (double)0.4F, (double)0.0F, (double)1024.0F)).setDescription("Flying Speed").setShouldWatch(true);
   public static final IAttribute ATTACK_DAMAGE = new RangedAttribute((IAttribute)null, "generic.attackDamage", (double)2.0F, (double)0.0F, (double)2048.0F);
   public static final IAttribute ATTACK_SPEED = (new RangedAttribute((IAttribute)null, "generic.attackSpeed", (double)4.0F, (double)0.0F, (double)1024.0F)).setShouldWatch(true);
   public static final IAttribute ARMOR = (new RangedAttribute((IAttribute)null, "generic.armor", (double)0.0F, (double)0.0F, (double)30.0F)).setShouldWatch(true);
   public static final IAttribute ARMOR_TOUGHNESS = (new RangedAttribute((IAttribute)null, "generic.armorToughness", (double)0.0F, (double)0.0F, (double)20.0F)).setShouldWatch(true);
   public static final IAttribute LUCK = (new RangedAttribute((IAttribute)null, "generic.luck", (double)0.0F, (double)-1024.0F, (double)1024.0F)).setShouldWatch(true);

   public static NBTTagList writeBaseAttributeMapToNBT(AbstractAttributeMap var0) {
      NBTTagList var1 = new NBTTagList();

      for(IAttributeInstance var3 : var0.getAllAttributes()) {
         var1.appendTag(writeAttributeInstanceToNBT(var3));
      }

      return var1;
   }

   private static NBTTagCompound writeAttributeInstanceToNBT(IAttributeInstance var0) {
      NBTTagCompound var1 = new NBTTagCompound();
      IAttribute var2 = var0.getAttribute();
      var1.setString("Name", var2.getAttributeUnlocalizedName());
      var1.setDouble("Base", var0.getBaseValue());
      Collection var3 = var0.getModifiers();
      if (var3 != null && !var3.isEmpty()) {
         NBTTagList var4 = new NBTTagList();

         for(Object var6_raw : var3) {
            AttributeModifier var6 = (AttributeModifier)var6_raw;
            if (var6.isSaved()) {
               var4.appendTag(writeAttributeModifierToNBT(var6));
            }
         }

         var1.setTag("Modifiers", var4);
      }

      return var1;
   }

   public static NBTTagCompound writeAttributeModifierToNBT(AttributeModifier var0) {
      NBTTagCompound var1 = new NBTTagCompound();
      var1.setString("Name", var0.getName());
      var1.setDouble("Amount", var0.getAmount());
      var1.setInteger("Operation", var0.getOperation());
      var1.setUniqueId("UUID", var0.getID());
      return var1;
   }

   public static void setAttributeModifiers(AbstractAttributeMap var0, NBTTagList var1) {
      for(int var2 = 0; var2 < var1.tagCount(); ++var2) {
         NBTTagCompound var3 = var1.getCompoundTagAt(var2);
         IAttributeInstance var4 = var0.getAttributeInstanceByName(var3.getString("Name"));
         if (var4 == null) {
            LOGGER.warn("Ignoring unknown attribute '{}'", var3.getString("Name"));
         } else {
            applyModifiersToAttributeInstance(var4, var3);
         }
      }

   }

   private static void applyModifiersToAttributeInstance(IAttributeInstance var0, NBTTagCompound var1) {
      var0.setBaseValue(var1.getDouble("Base"));
      if (var1.hasKey("Modifiers", 9)) {
         NBTTagList var2 = var1.getTagList("Modifiers", 10);

         for(int var3 = 0; var3 < var2.tagCount(); ++var3) {
            AttributeModifier var4 = readAttributeModifierFromNBT(var2.getCompoundTagAt(var3));
            if (var4 != null) {
               AttributeModifier var5 = var0.getModifier(var4.getID());
               if (var5 != null) {
                  var0.removeModifier(var5);
               }

               var0.applyModifier(var4);
            }
         }
      }

   }

   @Nullable
   public static AttributeModifier readAttributeModifierFromNBT(NBTTagCompound var0) {
      UUID var1 = var0.getUniqueId("UUID");

      try {
         return new AttributeModifier(var1, var0.getString("Name"), var0.getDouble("Amount"), var0.getInteger("Operation"));
      } catch (Exception var3) {
         LOGGER.warn("Unable to create attribute: {}", var3.getMessage());
         return null;
      }
   }
}
