package net.minecraft.entity.item;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityItem extends Entity {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final DataParameter<ItemStack> ITEM;
   private int age;
   private int delayBeforeCanPickup;
   private int health;
   private String thrower;
   private String owner;
   public float hoverStart;

   public EntityItem(World var1, double var2, double var4, double var6) {
      super(var1);
      this.health = 5;
      this.hoverStart = (float)(Math.random() * Math.PI * (double)2.0F);
      this.setSize(0.25F, 0.25F);
      this.setPosition(var2, var4, var6);
      this.rotationYaw = (float)(Math.random() * (double)360.0F);
      this.motionX = (double)((float)(Math.random() * (double)0.2F - (double)0.1F));
      this.motionY = (double)0.2F;
      this.motionZ = (double)((float)(Math.random() * (double)0.2F - (double)0.1F));
   }

   public EntityItem(World var1, double var2, double var4, double var6, ItemStack var8) {
      this(var1, var2, var4, var6);
      this.setEntityItemStack(var8);
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   public EntityItem(World var1) {
      super(var1);
      this.health = 5;
      this.hoverStart = (float)(Math.random() * Math.PI * (double)2.0F);
      this.setSize(0.25F, 0.25F);
      this.setEntityItemStack(ItemStack.field_190927_a);
   }

   protected void entityInit() {
      this.getDataManager().register(ITEM, ItemStack.field_190927_a);
   }

   public void onUpdate() {
      if (this.getEntityItem().func_190926_b()) {
         this.setDead();
      } else {
         super.onUpdate();
         if (this.delayBeforeCanPickup > 0 && this.delayBeforeCanPickup != 32767) {
            --this.delayBeforeCanPickup;
         }

         this.prevPosX = this.posX;
         this.prevPosY = this.posY;
         this.prevPosZ = this.posZ;
         double var1 = this.motionX;
         double var3 = this.motionY;
         double var5 = this.motionZ;
         if (!this.hasNoGravity()) {
            this.motionY -= (double)0.04F;
         }

         if (this.world.isRemote) {
            this.noClip = false;
         } else {
            this.noClip = this.pushOutOfBlocks(this.posX, (this.getEntityBoundingBox().minY + this.getEntityBoundingBox().maxY) / (double)2.0F, this.posZ);
         }

         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         boolean var7 = (int)this.prevPosX != (int)this.posX || (int)this.prevPosY != (int)this.posY || (int)this.prevPosZ != (int)this.posZ;
         if (var7 || this.ticksExisted % 25 == 0) {
            if (this.world.getBlockState(new BlockPos(this)).getMaterial() == Material.LAVA) {
               this.motionY = (double)0.2F;
               this.motionX = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
               this.motionZ = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
               this.playSound(SoundEvents.ENTITY_GENERIC_BURN, 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
            }

            if (!this.world.isRemote) {
               this.searchForOtherItemsNearby();
            }
         }

         float var8 = 0.98F;
         if (this.onGround) {
            var8 = this.world.getBlockState(new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.getEntityBoundingBox().minY) - 1, MathHelper.floor(this.posZ))).getBlock().slipperiness * 0.98F;
         }

         this.motionX *= (double)var8;
         this.motionY *= (double)0.98F;
         this.motionZ *= (double)var8;
         if (this.onGround) {
            this.motionY *= (double)-0.5F;
         }

         if (this.age != -32768) {
            ++this.age;
         }

         this.handleWaterMovement();
         if (!this.world.isRemote) {
            double var9 = this.motionX - var1;
            double var11 = this.motionY - var3;
            double var13 = this.motionZ - var5;
            double var15 = var9 * var9 + var11 * var11 + var13 * var13;
            if (var15 > 0.01) {
               this.isAirBorne = true;
            }
         }

         if (!this.world.isRemote && this.age >= 6000) {
            this.setDead();
         }
      }

   }

   private void searchForOtherItemsNearby() {
      for(EntityItem var2 : this.world.getEntitiesWithinAABB(EntityItem.class, this.getEntityBoundingBox().expand((double)0.5F, (double)0.0F, (double)0.5F))) {
         this.combineItems(var2);
      }

   }

   private boolean combineItems(EntityItem var1) {
      if (var1 == this) {
         return false;
      } else if (var1.isEntityAlive() && this.isEntityAlive()) {
         ItemStack var2 = this.getEntityItem();
         ItemStack var3 = var1.getEntityItem();
         if (this.delayBeforeCanPickup != 32767 && var1.delayBeforeCanPickup != 32767) {
            if (this.age != -32768 && var1.age != -32768) {
               if (var3.getItem() != var2.getItem()) {
                  return false;
               } else if (var3.hasTagCompound() ^ var2.hasTagCompound()) {
                  return false;
               } else if (var3.hasTagCompound() && !var3.getTagCompound().equals(var2.getTagCompound())) {
                  return false;
               } else if (var3.getItem() == null) {
                  return false;
               } else if (var3.getItem().getHasSubtypes() && var3.getMetadata() != var2.getMetadata()) {
                  return false;
               } else if (var3.func_190916_E() < var2.func_190916_E()) {
                  return var1.combineItems(this);
               } else if (var3.func_190916_E() + var2.func_190916_E() > var3.getMaxStackSize()) {
                  return false;
               } else {
                  var3.func_190917_f(var2.func_190916_E());
                  var1.delayBeforeCanPickup = Math.max(var1.delayBeforeCanPickup, this.delayBeforeCanPickup);
                  var1.age = Math.min(var1.age, this.age);
                  var1.setEntityItemStack(var3);
                  this.setDead();
                  return true;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void setAgeToCreativeDespawnTime() {
      this.age = 4800;
   }

   public boolean handleWaterMovement() {
      if (this.world.handleMaterialAcceleration(this.getEntityBoundingBox(), Material.WATER, this)) {
         if (!this.inWater && !this.firstUpdate) {
            this.resetHeight();
         }

         this.inWater = true;
      } else {
         this.inWater = false;
      }

      return this.inWater;
   }

   protected void dealFireDamage(int var1) {
      this.attackEntityFrom(DamageSource.inFire, (float)var1);
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (this.isEntityInvulnerable(var1)) {
         return false;
      } else if (!this.getEntityItem().func_190926_b() && this.getEntityItem().getItem() == Items.NETHER_STAR && var1.isExplosion()) {
         return false;
      } else {
         this.setBeenAttacked();
         this.health = (int)((float)this.health - var2);
         if (this.health <= 0) {
            this.setDead();
         }

         return false;
      }
   }

   public static void registerFixesItem(DataFixer var0) {
      var0.registerWalker(FixTypes.ENTITY, new ItemStackData(EntityItem.class, new String[]{"Item"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      var1.setShort("Health", (short)this.health);
      var1.setShort("Age", (short)this.age);
      var1.setShort("PickupDelay", (short)this.delayBeforeCanPickup);
      if (this.getThrower() != null) {
         var1.setString("Thrower", this.thrower);
      }

      if (this.getOwner() != null) {
         var1.setString("Owner", this.owner);
      }

      if (!this.getEntityItem().func_190926_b()) {
         var1.setTag("Item", this.getEntityItem().writeToNBT(new NBTTagCompound()));
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      this.health = var1.getShort("Health");
      this.age = var1.getShort("Age");
      if (var1.hasKey("PickupDelay")) {
         this.delayBeforeCanPickup = var1.getShort("PickupDelay");
      }

      if (var1.hasKey("Owner")) {
         this.owner = var1.getString("Owner");
      }

      if (var1.hasKey("Thrower")) {
         this.thrower = var1.getString("Thrower");
      }

      NBTTagCompound var2 = var1.getCompoundTag("Item");
      this.setEntityItemStack(new ItemStack(var2));
      if (this.getEntityItem().func_190926_b()) {
         this.setDead();
      }

   }

   public void onCollideWithPlayer(EntityPlayer var1) {
      if (!this.world.isRemote) {
         ItemStack var2 = this.getEntityItem();
         Item var3 = var2.getItem();
         int var4 = var2.func_190916_E();
         if (this.delayBeforeCanPickup == 0 && (this.owner == null || 6000 - this.age <= 200 || this.owner.equals(var1.getName())) && var1.inventory.addItemStackToInventory(var2)) {
            var1.onItemPickup(this, var4);
            if (var2.func_190926_b()) {
               this.setDead();
               var2.func_190920_e(var4);
            }

            var1.addStat(StatList.getObjectsPickedUpStats(var3), var4);
         }
      }

   }

   public String getName() {
      return this.hasCustomName() ? this.getCustomNameTag() : I18n.translateToLocal("item." + this.getEntityItem().getUnlocalizedName());
   }

   public boolean canBeAttackedWithItem() {
      return false;
   }

   @Nullable
   public Entity changeDimension(int var1) {
      Entity var2 = super.changeDimension(var1);
      if (!this.world.isRemote && var2 instanceof EntityItem) {
         ((EntityItem)var2).searchForOtherItemsNearby();
      }

      return var2;
   }

   public ItemStack getEntityItem() {
      return (ItemStack)this.getDataManager().get(ITEM);
   }

   public void setEntityItemStack(ItemStack var1) {
      this.getDataManager().set(ITEM, var1);
      this.getDataManager().setDirty(ITEM);
   }

   public String getOwner() {
      return this.owner;
   }

   public void setOwner(String var1) {
      this.owner = var1;
   }

   public String getThrower() {
      return this.thrower;
   }

   public void setThrower(String var1) {
      this.thrower = var1;
   }

   public int getAge() {
      return this.age;
   }

   public void setDefaultPickupDelay() {
      this.delayBeforeCanPickup = 10;
   }

   public void setNoPickupDelay() {
      this.delayBeforeCanPickup = 0;
   }

   public void setInfinitePickupDelay() {
      this.delayBeforeCanPickup = 32767;
   }

   public void setPickupDelay(int var1) {
      this.delayBeforeCanPickup = var1;
   }

   public boolean cannotPickup() {
      return this.delayBeforeCanPickup > 0;
   }

   public void setNoDespawn() {
      this.age = -6000;
   }

   public void makeFakeItem() {
      this.setInfinitePickupDelay();
      this.age = 5999;
   }

   static {
      ITEM = EntityDataManager.<ItemStack>createKey(EntityItem.class, DataSerializers.OPTIONAL_ITEM_STACK);
   }
}
