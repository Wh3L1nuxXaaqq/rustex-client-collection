package net.minecraft.entity.item;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityTNTPrimed extends Entity {
   private static final DataParameter<Integer> FUSE;
   @Nullable
   private EntityLivingBase tntPlacedBy;
   private int fuse;

   public EntityTNTPrimed(World var1) {
      super(var1);
      this.fuse = 80;
      this.preventEntitySpawning = true;
      this.isImmuneToFire = true;
      this.setSize(0.98F, 0.98F);
   }

   public EntityTNTPrimed(World var1, double var2, double var4, double var6, EntityLivingBase var8) {
      this(var1);
      this.setPosition(var2, var4, var6);
      float var9 = (float)(Math.random() * (Math.PI * 2D));
      this.motionX = (double)(-((float)Math.sin((double)var9)) * 0.02F);
      this.motionY = (double)0.2F;
      this.motionZ = (double)(-((float)Math.cos((double)var9)) * 0.02F);
      this.setFuse(80);
      this.prevPosX = var2;
      this.prevPosY = var4;
      this.prevPosZ = var6;
      this.tntPlacedBy = var8;
   }

   protected void entityInit() {
      this.dataManager.register(FUSE, 80);
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return !this.isDead;
   }

   public void onUpdate() {
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      if (!this.hasNoGravity()) {
         this.motionY -= (double)0.04F;
      }

      this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
      this.motionX *= (double)0.98F;
      this.motionY *= (double)0.98F;
      this.motionZ *= (double)0.98F;
      if (this.onGround) {
         this.motionX *= (double)0.7F;
         this.motionZ *= (double)0.7F;
         this.motionY *= (double)-0.5F;
      }

      --this.fuse;
      if (this.fuse <= 0) {
         this.setDead();
         if (!this.world.isRemote) {
            this.explode();
         }
      } else {
         this.handleWaterMovement();
         this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, this.posX, this.posY + (double)0.5F, this.posZ, (double)0.0F, (double)0.0F, (double)0.0F);
      }

   }

   private void explode() {
      float var1 = 4.0F;
      this.world.createExplosion(this, this.posX, this.posY + (double)(this.height / 16.0F), this.posZ, 4.0F, true);
   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      var1.setShort("Fuse", (short)this.getFuse());
   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      this.setFuse(var1.getShort("Fuse"));
   }

   @Nullable
   public EntityLivingBase getTntPlacedBy() {
      return this.tntPlacedBy;
   }

   public float getEyeHeight() {
      return 0.0F;
   }

   public void setFuse(int var1) {
      this.dataManager.set(FUSE, var1);
      this.fuse = var1;
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      if (FUSE.equals(var1)) {
         this.fuse = this.getFuseDataManager();
      }

   }

   public int getFuseDataManager() {
      return (Integer)this.dataManager.get(FUSE);
   }

   public int getFuse() {
      return this.fuse;
   }

   static {
      FUSE = EntityDataManager.<Integer>createKey(EntityTNTPrimed.class, DataSerializers.VARINT);
   }
}
