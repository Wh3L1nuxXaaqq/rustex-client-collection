package net.minecraft.entity.item;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Rotations;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EntityArmorStand extends EntityLivingBase {
   private static final Rotations DEFAULT_HEAD_ROTATION = new Rotations(0.0F, 0.0F, 0.0F);
   private static final Rotations DEFAULT_BODY_ROTATION = new Rotations(0.0F, 0.0F, 0.0F);
   private static final Rotations DEFAULT_LEFTARM_ROTATION = new Rotations(-10.0F, 0.0F, -10.0F);
   private static final Rotations DEFAULT_RIGHTARM_ROTATION = new Rotations(-15.0F, 0.0F, 10.0F);
   private static final Rotations DEFAULT_LEFTLEG_ROTATION = new Rotations(-1.0F, 0.0F, -1.0F);
   private static final Rotations DEFAULT_RIGHTLEG_ROTATION = new Rotations(1.0F, 0.0F, 1.0F);
   public static final DataParameter<Byte> STATUS;
   public static final DataParameter<Rotations> HEAD_ROTATION;
   public static final DataParameter<Rotations> BODY_ROTATION;
   public static final DataParameter<Rotations> LEFT_ARM_ROTATION;
   public static final DataParameter<Rotations> RIGHT_ARM_ROTATION;
   public static final DataParameter<Rotations> LEFT_LEG_ROTATION;
   public static final DataParameter<Rotations> RIGHT_LEG_ROTATION;
   private static final Predicate<Entity> IS_RIDEABLE_MINECART;
   private final NonNullList<ItemStack> handItems;
   private final NonNullList<ItemStack> armorItems;
   private boolean canInteract;
   public long punchCooldown;
   private int disabledSlots;
   private boolean wasMarker;
   private Rotations headRotation;
   private Rotations bodyRotation;
   private Rotations leftArmRotation;
   private Rotations rightArmRotation;
   private Rotations leftLegRotation;
   private Rotations rightLegRotation;

   public EntityArmorStand(World var1) {
      super(var1);
      this.handItems = NonNullList.<ItemStack>func_191197_a(2, ItemStack.field_190927_a);
      this.armorItems = NonNullList.<ItemStack>func_191197_a(4, ItemStack.field_190927_a);
      this.headRotation = DEFAULT_HEAD_ROTATION;
      this.bodyRotation = DEFAULT_BODY_ROTATION;
      this.leftArmRotation = DEFAULT_LEFTARM_ROTATION;
      this.rightArmRotation = DEFAULT_RIGHTARM_ROTATION;
      this.leftLegRotation = DEFAULT_LEFTLEG_ROTATION;
      this.rightLegRotation = DEFAULT_RIGHTLEG_ROTATION;
      this.noClip = this.hasNoGravity();
      this.setSize(0.5F, 1.975F);
   }

   public EntityArmorStand(World var1, double var2, double var4, double var6) {
      this(var1);
      this.setPosition(var2, var4, var6);
   }

   protected final void setSize(float var1, float var2) {
      double var3 = this.posX;
      double var5 = this.posY;
      double var7 = this.posZ;
      float var9 = this.hasMarker() ? 0.0F : (this.isChild() ? 0.5F : 1.0F);
      super.setSize(var1 * var9, var2 * var9);
      this.setPosition(var3, var5, var7);
   }

   public boolean isServerWorld() {
      return super.isServerWorld() && !this.hasNoGravity();
   }

   protected void entityInit() {
      super.entityInit();
      this.dataManager.register(STATUS, (byte)0);
      this.dataManager.register(HEAD_ROTATION, DEFAULT_HEAD_ROTATION);
      this.dataManager.register(BODY_ROTATION, DEFAULT_BODY_ROTATION);
      this.dataManager.register(LEFT_ARM_ROTATION, DEFAULT_LEFTARM_ROTATION);
      this.dataManager.register(RIGHT_ARM_ROTATION, DEFAULT_RIGHTARM_ROTATION);
      this.dataManager.register(LEFT_LEG_ROTATION, DEFAULT_LEFTLEG_ROTATION);
      this.dataManager.register(RIGHT_LEG_ROTATION, DEFAULT_RIGHTLEG_ROTATION);
   }

   public Iterable<ItemStack> getHeldEquipment() {
      return this.handItems;
   }

   public Iterable<ItemStack> getArmorInventoryList() {
      return this.armorItems;
   }

   public ItemStack getItemStackFromSlot(EntityEquipmentSlot var1) {
      switch (var1.getSlotType()) {
         case HAND:
            return this.handItems.get(var1.getIndex());
         case ARMOR:
            return this.armorItems.get(var1.getIndex());
         default:
            return ItemStack.field_190927_a;
      }
   }

   public void setItemStackToSlot(EntityEquipmentSlot var1, ItemStack var2) {
      switch (var1.getSlotType()) {
         case HAND:
            this.playEquipSound(var2);
            this.handItems.set(var1.getIndex(), var2);
            break;
         case ARMOR:
            this.playEquipSound(var2);
            this.armorItems.set(var1.getIndex(), var2);
      }

   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      EntityEquipmentSlot var3;
      if (var1 == 98) {
         var3 = EntityEquipmentSlot.MAINHAND;
      } else if (var1 == 99) {
         var3 = EntityEquipmentSlot.OFFHAND;
      } else if (var1 == 100 + EntityEquipmentSlot.HEAD.getIndex()) {
         var3 = EntityEquipmentSlot.HEAD;
      } else if (var1 == 100 + EntityEquipmentSlot.CHEST.getIndex()) {
         var3 = EntityEquipmentSlot.CHEST;
      } else if (var1 == 100 + EntityEquipmentSlot.LEGS.getIndex()) {
         var3 = EntityEquipmentSlot.LEGS;
      } else {
         if (var1 != 100 + EntityEquipmentSlot.FEET.getIndex()) {
            return false;
         }

         var3 = EntityEquipmentSlot.FEET;
      }

      if (!var2.func_190926_b() && !EntityLiving.isItemStackInSlot(var3, var2) && var3 != EntityEquipmentSlot.HEAD) {
         return false;
      } else {
         this.setItemStackToSlot(var3, var2);
         return true;
      }
   }

   public static void registerFixesArmorStand(DataFixer var0) {
      var0.registerWalker(FixTypes.ENTITY, new ItemStackDataLists(EntityArmorStand.class, new String[]{"ArmorItems", "HandItems"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      NBTTagList var2 = new NBTTagList();

      for(ItemStack var4 : this.armorItems) {
         NBTTagCompound var5 = new NBTTagCompound();
         if (!var4.func_190926_b()) {
            var4.writeToNBT(var5);
         }

         var2.appendTag(var5);
      }

      var1.setTag("ArmorItems", var2);
      NBTTagList var7 = new NBTTagList();

      for(ItemStack var9 : this.handItems) {
         NBTTagCompound var6 = new NBTTagCompound();
         if (!var9.func_190926_b()) {
            var9.writeToNBT(var6);
         }

         var7.appendTag(var6);
      }

      var1.setTag("HandItems", var7);
      var1.setBoolean("Invisible", this.isInvisible());
      var1.setBoolean("Small", this.isSmall());
      var1.setBoolean("ShowArms", this.getShowArms());
      var1.setInteger("DisabledSlots", this.disabledSlots);
      var1.setBoolean("NoBasePlate", this.hasNoBasePlate());
      if (this.hasMarker()) {
         var1.setBoolean("Marker", this.hasMarker());
      }

      var1.setTag("Pose", this.readPoseFromNBT());
   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      if (var1.hasKey("ArmorItems", 9)) {
         NBTTagList var2 = var1.getTagList("ArmorItems", 10);

         for(int var3 = 0; var3 < this.armorItems.size(); ++var3) {
            this.armorItems.set(var3, new ItemStack(var2.getCompoundTagAt(var3)));
         }
      }

      if (var1.hasKey("HandItems", 9)) {
         NBTTagList var4 = var1.getTagList("HandItems", 10);

         for(int var6 = 0; var6 < this.handItems.size(); ++var6) {
            this.handItems.set(var6, new ItemStack(var4.getCompoundTagAt(var6)));
         }
      }

      this.setInvisible(var1.getBoolean("Invisible"));
      this.setSmall(var1.getBoolean("Small"));
      this.setShowArms(var1.getBoolean("ShowArms"));
      this.disabledSlots = var1.getInteger("DisabledSlots");
      this.setNoBasePlate(var1.getBoolean("NoBasePlate"));
      this.setMarker(var1.getBoolean("Marker"));
      this.wasMarker = !this.hasMarker();
      this.noClip = this.hasNoGravity();
      NBTTagCompound var5 = var1.getCompoundTag("Pose");
      this.writePoseToNBT(var5);
   }

   private void writePoseToNBT(NBTTagCompound var1) {
      NBTTagList var2 = var1.getTagList("Head", 5);
      this.setHeadRotation(var2.hasNoTags() ? DEFAULT_HEAD_ROTATION : new Rotations(var2));
      NBTTagList var3 = var1.getTagList("Body", 5);
      this.setBodyRotation(var3.hasNoTags() ? DEFAULT_BODY_ROTATION : new Rotations(var3));
      NBTTagList var4 = var1.getTagList("LeftArm", 5);
      this.setLeftArmRotation(var4.hasNoTags() ? DEFAULT_LEFTARM_ROTATION : new Rotations(var4));
      NBTTagList var5 = var1.getTagList("RightArm", 5);
      this.setRightArmRotation(var5.hasNoTags() ? DEFAULT_RIGHTARM_ROTATION : new Rotations(var5));
      NBTTagList var6 = var1.getTagList("LeftLeg", 5);
      this.setLeftLegRotation(var6.hasNoTags() ? DEFAULT_LEFTLEG_ROTATION : new Rotations(var6));
      NBTTagList var7 = var1.getTagList("RightLeg", 5);
      this.setRightLegRotation(var7.hasNoTags() ? DEFAULT_RIGHTLEG_ROTATION : new Rotations(var7));
   }

   private NBTTagCompound readPoseFromNBT() {
      NBTTagCompound var1 = new NBTTagCompound();
      if (!DEFAULT_HEAD_ROTATION.equals(this.headRotation)) {
         var1.setTag("Head", this.headRotation.writeToNBT());
      }

      if (!DEFAULT_BODY_ROTATION.equals(this.bodyRotation)) {
         var1.setTag("Body", this.bodyRotation.writeToNBT());
      }

      if (!DEFAULT_LEFTARM_ROTATION.equals(this.leftArmRotation)) {
         var1.setTag("LeftArm", this.leftArmRotation.writeToNBT());
      }

      if (!DEFAULT_RIGHTARM_ROTATION.equals(this.rightArmRotation)) {
         var1.setTag("RightArm", this.rightArmRotation.writeToNBT());
      }

      if (!DEFAULT_LEFTLEG_ROTATION.equals(this.leftLegRotation)) {
         var1.setTag("LeftLeg", this.leftLegRotation.writeToNBT());
      }

      if (!DEFAULT_RIGHTLEG_ROTATION.equals(this.rightLegRotation)) {
         var1.setTag("RightLeg", this.rightLegRotation.writeToNBT());
      }

      return var1;
   }

   public boolean canBePushed() {
      return false;
   }

   protected void collideWithEntity(Entity var1) {
   }

   protected void collideWithNearbyEntities() {
      List var1 = this.world.getEntitiesInAABBexcluding(this, this.getEntityBoundingBox(), IS_RIDEABLE_MINECART);

      for(int var2 = 0; var2 < var1.size(); ++var2) {
         Entity var3 = (Entity)var1.get(var2);
         if (this.getDistanceSqToEntity(var3) <= 0.2) {
            var3.applyEntityCollision(this);
         }
      }

   }

   public EnumActionResult applyPlayerInteraction(EntityPlayer var1, Vec3d var2, EnumHand var3) {
      ItemStack var4 = var1.getHeldItem(var3);
      if (!this.hasMarker() && var4.getItem() != Items.NAME_TAG) {
         if (!this.world.isRemote && !var1.isSpectator()) {
            EntityEquipmentSlot var5 = EntityLiving.getSlotForItemStack(var4);
            if (var4.func_190926_b()) {
               EntityEquipmentSlot var6 = this.func_190772_a(var2);
               EntityEquipmentSlot var7 = this.isDisabled(var6) ? var5 : var6;
               if (this.func_190630_a(var7)) {
                  this.swapItem(var1, var7, var4, var3);
               }
            } else {
               if (this.isDisabled(var5)) {
                  return EnumActionResult.FAIL;
               }

               if (var5.getSlotType() == EntityEquipmentSlot.Type.HAND && !this.getShowArms()) {
                  return EnumActionResult.FAIL;
               }

               this.swapItem(var1, var5, var4, var3);
            }

            return EnumActionResult.SUCCESS;
         } else {
            return EnumActionResult.SUCCESS;
         }
      } else {
         return EnumActionResult.PASS;
      }
   }

   protected EntityEquipmentSlot func_190772_a(Vec3d var1) {
      EntityEquipmentSlot var2 = EntityEquipmentSlot.MAINHAND;
      boolean var3 = this.isSmall();
      double var4 = var3 ? var1.yCoord * (double)2.0F : var1.yCoord;
      EntityEquipmentSlot var6 = EntityEquipmentSlot.FEET;
      if (var4 >= 0.1 && var4 < 0.1 + (var3 ? 0.8 : 0.45) && this.func_190630_a(var6)) {
         var2 = EntityEquipmentSlot.FEET;
      } else if (var4 >= 0.9 + (var3 ? 0.3 : (double)0.0F) && var4 < 0.9 + (var3 ? (double)1.0F : 0.7) && this.func_190630_a(EntityEquipmentSlot.CHEST)) {
         var2 = EntityEquipmentSlot.CHEST;
      } else if (var4 >= 0.4 && var4 < 0.4 + (var3 ? (double)1.0F : 0.8) && this.func_190630_a(EntityEquipmentSlot.LEGS)) {
         var2 = EntityEquipmentSlot.LEGS;
      } else if (var4 >= 1.6 && this.func_190630_a(EntityEquipmentSlot.HEAD)) {
         var2 = EntityEquipmentSlot.HEAD;
      }

      return var2;
   }

   private boolean isDisabled(EntityEquipmentSlot var1) {
      return (this.disabledSlots & 1 << var1.getSlotIndex()) != 0;
   }

   private void swapItem(EntityPlayer var1, EntityEquipmentSlot var2, ItemStack var3, EnumHand var4) {
      ItemStack var5 = this.getItemStackFromSlot(var2);
      if ((var5.func_190926_b() || (this.disabledSlots & 1 << var2.getSlotIndex() + 8) == 0) && (!var5.func_190926_b() || (this.disabledSlots & 1 << var2.getSlotIndex() + 16) == 0)) {
         if (var1.capabilities.isCreativeMode && var5.func_190926_b() && !var3.func_190926_b()) {
            ItemStack var7 = var3.copy();
            var7.func_190920_e(1);
            this.setItemStackToSlot(var2, var7);
         } else if (!var3.func_190926_b() && var3.func_190916_E() > 1) {
            if (var5.func_190926_b()) {
               ItemStack var6 = var3.copy();
               var6.func_190920_e(1);
               this.setItemStackToSlot(var2, var6);
               var3.func_190918_g(1);
            }
         } else {
            this.setItemStackToSlot(var2, var3);
            var1.setHeldItem(var4, var5);
         }
      }

   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (!this.world.isRemote && !this.isDead) {
         if (DamageSource.outOfWorld.equals(var1)) {
            this.setDead();
            return false;
         } else if (!this.isEntityInvulnerable(var1) && !this.canInteract && !this.hasMarker()) {
            if (var1.isExplosion()) {
               this.dropContents();
               this.setDead();
               return false;
            } else if (DamageSource.inFire.equals(var1)) {
               if (this.isBurning()) {
                  this.damageArmorStand(0.15F);
               } else {
                  this.setFire(5);
               }

               return false;
            } else if (DamageSource.onFire.equals(var1) && this.getHealth() > 0.5F) {
               this.damageArmorStand(4.0F);
               return false;
            } else {
               boolean var3 = "arrow".equals(var1.getDamageType());
               boolean var4 = "player".equals(var1.getDamageType());
               if (!var4 && !var3) {
                  return false;
               } else {
                  if (var1.getSourceOfDamage() instanceof EntityArrow) {
                     var1.getSourceOfDamage().setDead();
                  }

                  if (var1.getEntity() instanceof EntityPlayer && !((EntityPlayer)var1.getEntity()).capabilities.allowEdit) {
                     return false;
                  } else if (var1.isCreativePlayer()) {
                     this.func_190773_I();
                     this.playParticles();
                     this.setDead();
                     return false;
                  } else {
                     long var5 = this.world.getTotalWorldTime();
                     if (var5 - this.punchCooldown > 5L && !var3) {
                        this.world.setEntityState(this, (byte)32);
                        this.punchCooldown = var5;
                     } else {
                        this.dropBlock();
                        this.playParticles();
                        this.setDead();
                     }

                     return false;
                  }
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 32) {
         if (this.world.isRemote) {
            this.world.playSound(this.posX, this.posY, this.posZ, SoundEvents.ENTITY_ARMORSTAND_HIT, this.getSoundCategory(), 0.3F, 1.0F, false);
            this.punchCooldown = this.world.getTotalWorldTime();
         }
      } else {
         super.handleStatusUpdate(var1);
      }

   }

   public boolean isInRangeToRenderDist(double var1) {
      double var3 = this.getEntityBoundingBox().getAverageEdgeLength() * (double)4.0F;
      if (Double.isNaN(var3) || var3 == (double)0.0F) {
         var3 = (double)4.0F;
      }

      var3 *= (double)64.0F;
      return var1 < var3 * var3;
   }

   private void playParticles() {
      if (this.world instanceof WorldServer) {
         ((WorldServer)this.world).spawnParticle(EnumParticleTypes.BLOCK_DUST, this.posX, this.posY + (double)this.height / (double)1.5F, this.posZ, 10, (double)(this.width / 4.0F), (double)(this.height / 4.0F), (double)(this.width / 4.0F), 0.05, Block.getStateId(Blocks.PLANKS.getDefaultState()));
      }

   }

   private void damageArmorStand(float var1) {
      float var2 = this.getHealth();
      var2 -= var1;
      if (var2 <= 0.5F) {
         this.dropContents();
         this.setDead();
      } else {
         this.setHealth(var2);
      }

   }

   private void dropBlock() {
      Block.spawnAsEntity(this.world, new BlockPos(this), new ItemStack(Items.ARMOR_STAND));
      this.dropContents();
   }

   private void dropContents() {
      this.func_190773_I();

      for(int var1 = 0; var1 < this.handItems.size(); ++var1) {
         ItemStack var2 = this.handItems.get(var1);
         if (!var2.func_190926_b()) {
            Block.spawnAsEntity(this.world, (new BlockPos(this)).up(), var2);
            this.handItems.set(var1, ItemStack.field_190927_a);
         }
      }

      for(int var3 = 0; var3 < this.armorItems.size(); ++var3) {
         ItemStack var4 = this.armorItems.get(var3);
         if (!var4.func_190926_b()) {
            Block.spawnAsEntity(this.world, (new BlockPos(this)).up(), var4);
            this.armorItems.set(var3, ItemStack.field_190927_a);
         }
      }

   }

   private void func_190773_I() {
      this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_ARMORSTAND_BREAK, this.getSoundCategory(), 1.0F, 1.0F);
   }

   protected float updateDistance(float var1, float var2) {
      this.prevRenderYawOffset = this.prevRotationYaw;
      this.renderYawOffset = this.rotationYaw;
      return 0.0F;
   }

   public float getEyeHeight() {
      return this.isChild() ? this.height * 0.5F : this.height * 0.9F;
   }

   public double getYOffset() {
      return this.hasMarker() ? (double)0.0F : (double)0.1F;
   }

   public void func_191986_a(float var1, float var2, float var3) {
      if (!this.hasNoGravity()) {
         super.func_191986_a(var1, var2, var3);
      }

   }

   public void setRenderYawOffset(float var1) {
      this.prevRenderYawOffset = this.prevRotationYaw = var1;
      this.prevRotationYawHead = this.rotationYawHead = var1;
   }

   public void setRotationYawHead(float var1) {
      this.prevRenderYawOffset = this.prevRotationYaw = var1;
      this.prevRotationYawHead = this.rotationYawHead = var1;
   }

   public void onUpdate() {
      super.onUpdate();
      Rotations var1 = (Rotations)this.dataManager.get(HEAD_ROTATION);
      if (!this.headRotation.equals(var1)) {
         this.setHeadRotation(var1);
      }

      Rotations var2 = (Rotations)this.dataManager.get(BODY_ROTATION);
      if (!this.bodyRotation.equals(var2)) {
         this.setBodyRotation(var2);
      }

      Rotations var3 = (Rotations)this.dataManager.get(LEFT_ARM_ROTATION);
      if (!this.leftArmRotation.equals(var3)) {
         this.setLeftArmRotation(var3);
      }

      Rotations var4 = (Rotations)this.dataManager.get(RIGHT_ARM_ROTATION);
      if (!this.rightArmRotation.equals(var4)) {
         this.setRightArmRotation(var4);
      }

      Rotations var5 = (Rotations)this.dataManager.get(LEFT_LEG_ROTATION);
      if (!this.leftLegRotation.equals(var5)) {
         this.setLeftLegRotation(var5);
      }

      Rotations var6 = (Rotations)this.dataManager.get(RIGHT_LEG_ROTATION);
      if (!this.rightLegRotation.equals(var6)) {
         this.setRightLegRotation(var6);
      }

      boolean var7 = this.hasMarker();
      if (this.wasMarker != var7) {
         this.updateBoundingBox(var7);
         this.preventEntitySpawning = !var7;
         this.wasMarker = var7;
      }

   }

   private void updateBoundingBox(boolean var1) {
      if (var1) {
         this.setSize(0.0F, 0.0F);
      } else {
         this.setSize(0.5F, 1.975F);
      }

   }

   protected void updatePotionMetadata() {
      this.setInvisible(this.canInteract);
   }

   public void setInvisible(boolean var1) {
      this.canInteract = var1;
      super.setInvisible(var1);
   }

   public boolean isChild() {
      return this.isSmall();
   }

   public void onKillCommand() {
      this.setDead();
   }

   public boolean isImmuneToExplosions() {
      return this.isInvisible();
   }

   public EnumPushReaction getPushReaction() {
      return this.hasMarker() ? EnumPushReaction.IGNORE : super.getPushReaction();
   }

   private void setSmall(boolean var1) {
      this.dataManager.set(STATUS, this.setBit((Byte)this.dataManager.get(STATUS), 1, var1));
      this.setSize(0.5F, 1.975F);
   }

   public boolean isSmall() {
      return ((Byte)this.dataManager.get(STATUS) & 1) != 0;
   }

   private void setShowArms(boolean var1) {
      this.dataManager.set(STATUS, this.setBit((Byte)this.dataManager.get(STATUS), 4, var1));
   }

   public boolean getShowArms() {
      return ((Byte)this.dataManager.get(STATUS) & 4) != 0;
   }

   private void setNoBasePlate(boolean var1) {
      this.dataManager.set(STATUS, this.setBit((Byte)this.dataManager.get(STATUS), 8, var1));
   }

   public boolean hasNoBasePlate() {
      return ((Byte)this.dataManager.get(STATUS) & 8) != 0;
   }

   private void setMarker(boolean var1) {
      this.dataManager.set(STATUS, this.setBit((Byte)this.dataManager.get(STATUS), 16, var1));
      this.setSize(0.5F, 1.975F);
   }

   public boolean hasMarker() {
      return ((Byte)this.dataManager.get(STATUS) & 16) != 0;
   }

   private byte setBit(byte var1, int var2, boolean var3) {
      if (var3) {
         var1 = (byte)(var1 | var2);
      } else {
         var1 = (byte)(var1 & ~var2);
      }

      return var1;
   }

   public void setHeadRotation(Rotations var1) {
      this.headRotation = var1;
      this.dataManager.set(HEAD_ROTATION, var1);
   }

   public void setBodyRotation(Rotations var1) {
      this.bodyRotation = var1;
      this.dataManager.set(BODY_ROTATION, var1);
   }

   public void setLeftArmRotation(Rotations var1) {
      this.leftArmRotation = var1;
      this.dataManager.set(LEFT_ARM_ROTATION, var1);
   }

   public void setRightArmRotation(Rotations var1) {
      this.rightArmRotation = var1;
      this.dataManager.set(RIGHT_ARM_ROTATION, var1);
   }

   public void setLeftLegRotation(Rotations var1) {
      this.leftLegRotation = var1;
      this.dataManager.set(LEFT_LEG_ROTATION, var1);
   }

   public void setRightLegRotation(Rotations var1) {
      this.rightLegRotation = var1;
      this.dataManager.set(RIGHT_LEG_ROTATION, var1);
   }

   public Rotations getHeadRotation() {
      return this.headRotation;
   }

   public Rotations getBodyRotation() {
      return this.bodyRotation;
   }

   public Rotations getLeftArmRotation() {
      return this.leftArmRotation;
   }

   public Rotations getRightArmRotation() {
      return this.rightArmRotation;
   }

   public Rotations getLeftLegRotation() {
      return this.leftLegRotation;
   }

   public Rotations getRightLegRotation() {
      return this.rightLegRotation;
   }

   public boolean canBeCollidedWith() {
      return super.canBeCollidedWith() && !this.hasMarker();
   }

   public EnumHandSide getPrimaryHand() {
      return EnumHandSide.RIGHT;
   }

   protected SoundEvent getFallSound(int var1) {
      return SoundEvents.ENTITY_ARMORSTAND_FALL;
   }

   @Nullable
   protected SoundEvent getHurtSound(DamageSource var1) {
      return SoundEvents.ENTITY_ARMORSTAND_HIT;
   }

   @Nullable
   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_ARMORSTAND_BREAK;
   }

   public void onStruckByLightning(EntityLightningBolt var1) {
   }

   public boolean canBeHitWithPotion() {
      return false;
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
      if (STATUS.equals(var1)) {
         this.setSize(0.5F, 1.975F);
      }

      super.notifyDataManagerChange(var1);
   }

   public boolean func_190631_cK() {
      return false;
   }

   static {
      STATUS = EntityDataManager.<Byte>createKey(EntityArmorStand.class, DataSerializers.BYTE);
      HEAD_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      BODY_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      LEFT_ARM_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      RIGHT_ARM_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      LEFT_LEG_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      RIGHT_LEG_ROTATION = EntityDataManager.<Rotations>createKey(EntityArmorStand.class, DataSerializers.ROTATIONS);
      IS_RIDEABLE_MINECART = new Predicate<Entity>() {
         public boolean apply(@Nullable Entity var1) {
            return var1 instanceof EntityMinecart && ((EntityMinecart)var1).getType() == EntityMinecart.Type.RIDEABLE;
         }
      };
   }
}
