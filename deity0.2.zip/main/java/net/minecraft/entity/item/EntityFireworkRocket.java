package net.minecraft.entity.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityFireworkRocket extends Entity {
   private static final DataParameter<ItemStack> FIREWORK_ITEM;
   private static final DataParameter<Integer> field_191512_b;
   private int fireworkAge;
   private int lifetime;
   private EntityLivingBase field_191513_e;

   public EntityFireworkRocket(World var1) {
      super(var1);
      this.setSize(0.25F, 0.25F);
   }

   protected void entityInit() {
      this.dataManager.register(FIREWORK_ITEM, ItemStack.field_190927_a);
      this.dataManager.register(field_191512_b, 0);
   }

   public boolean isInRangeToRenderDist(double var1) {
      return var1 < (double)4096.0F && !this.func_191511_j();
   }

   public boolean isInRangeToRender3d(double var1, double var3, double var5) {
      return super.isInRangeToRender3d(var1, var3, var5) && !this.func_191511_j();
   }

   public EntityFireworkRocket(World var1, double var2, double var4, double var6, ItemStack var8) {
      super(var1);
      this.fireworkAge = 0;
      this.setSize(0.25F, 0.25F);
      this.setPosition(var2, var4, var6);
      int var9 = 1;
      if (!var8.func_190926_b() && var8.hasTagCompound()) {
         this.dataManager.set(FIREWORK_ITEM, var8.copy());
         NBTTagCompound var10 = var8.getTagCompound();
         NBTTagCompound var11 = var10.getCompoundTag("Fireworks");
         var9 += var11.getByte("Flight");
      }

      this.motionX = this.rand.nextGaussian() * 0.001;
      this.motionZ = this.rand.nextGaussian() * 0.001;
      this.motionY = 0.05;
      this.lifetime = 10 * var9 + this.rand.nextInt(6) + this.rand.nextInt(7);
   }

   public EntityFireworkRocket(World var1, ItemStack var2, EntityLivingBase var3) {
      this(var1, var3.posX, var3.posY, var3.posZ, var2);
      this.dataManager.set(field_191512_b, var3.getEntityId());
      this.field_191513_e = var3;
   }

   public void setVelocity(double var1, double var3, double var5) {
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
      if (this.prevRotationPitch == 0.0F && this.prevRotationYaw == 0.0F) {
         float var7 = MathHelper.sqrt(var1 * var1 + var5 * var5);
         this.rotationYaw = (float)(MathHelper.atan2(var1, var5) * (180D / Math.PI));
         this.rotationPitch = (float)(MathHelper.atan2(var3, (double)var7) * (180D / Math.PI));
         this.prevRotationYaw = this.rotationYaw;
         this.prevRotationPitch = this.rotationPitch;
      }

   }

   public void onUpdate() {
      this.lastTickPosX = this.posX;
      this.lastTickPosY = this.posY;
      this.lastTickPosZ = this.posZ;
      super.onUpdate();
      if (this.func_191511_j()) {
         if (this.field_191513_e == null) {
            Entity var1 = this.world.getEntityByID((Integer)this.dataManager.get(field_191512_b));
            if (var1 instanceof EntityLivingBase) {
               this.field_191513_e = (EntityLivingBase)var1;
            }
         }

         if (this.field_191513_e != null) {
            if (this.field_191513_e.isElytraFlying()) {
               Vec3d var6 = this.field_191513_e.getLookVec();
               double var2 = (double)1.5F;
               double var4 = 0.1;
               EntityLivingBase var10000 = this.field_191513_e;
               var10000.motionX += var6.xCoord * 0.1 + (var6.xCoord * (double)1.5F - this.field_191513_e.motionX) * (double)0.5F;
               var10000 = this.field_191513_e;
               var10000.motionY += var6.yCoord * 0.1 + (var6.yCoord * (double)1.5F - this.field_191513_e.motionY) * (double)0.5F;
               var10000 = this.field_191513_e;
               var10000.motionZ += var6.zCoord * 0.1 + (var6.zCoord * (double)1.5F - this.field_191513_e.motionZ) * (double)0.5F;
            }

            this.setPosition(this.field_191513_e.posX, this.field_191513_e.posY, this.field_191513_e.posZ);
            this.motionX = this.field_191513_e.motionX;
            this.motionY = this.field_191513_e.motionY;
            this.motionZ = this.field_191513_e.motionZ;
         }
      } else {
         this.motionX *= 1.15;
         this.motionZ *= 1.15;
         this.motionY += 0.04;
         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
      }

      float var7 = MathHelper.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      this.rotationYaw = (float)(MathHelper.atan2(this.motionX, this.motionZ) * (180D / Math.PI));

      for(this.rotationPitch = (float)(MathHelper.atan2(this.motionY, (double)var7) * (180D / Math.PI)); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F) {
      }

      while(this.rotationPitch - this.prevRotationPitch >= 180.0F) {
         this.prevRotationPitch += 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw < -180.0F) {
         this.prevRotationYaw -= 360.0F;
      }

      while(this.rotationYaw - this.prevRotationYaw >= 180.0F) {
         this.prevRotationYaw += 360.0F;
      }

      this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
      this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
      if (this.fireworkAge == 0 && !this.isSilent()) {
         this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_FIREWORK_LAUNCH, SoundCategory.AMBIENT, 3.0F, 1.0F);
      }

      ++this.fireworkAge;
      if (this.world.isRemote && this.fireworkAge % 2 < 2) {
         this.world.spawnParticle(EnumParticleTypes.FIREWORKS_SPARK, this.posX, this.posY - 0.3, this.posZ, this.rand.nextGaussian() * 0.05, -this.motionY * (double)0.5F, this.rand.nextGaussian() * 0.05);
      }

      if (!this.world.isRemote && this.fireworkAge > this.lifetime) {
         this.world.setEntityState(this, (byte)17);
         this.func_191510_k();
         this.setDead();
      }

   }

   private void func_191510_k() {
      float var1 = 0.0F;
      ItemStack var2 = (ItemStack)this.dataManager.get(FIREWORK_ITEM);
      NBTTagCompound var3 = var2.func_190926_b() ? null : var2.getSubCompound("Fireworks");
      NBTTagList var4 = var3 != null ? var3.getTagList("Explosions", 10) : null;
      if (var4 != null && !var4.hasNoTags()) {
         var1 = (float)(5 + var4.tagCount() * 2);
      }

      if (var1 > 0.0F) {
         if (this.field_191513_e != null) {
            this.field_191513_e.attackEntityFrom(DamageSource.field_191552_t, (float)(5 + var4.tagCount() * 2));
         }

         double var5 = (double)5.0F;
         Vec3d var7 = new Vec3d(this.posX, this.posY, this.posZ);

         for(EntityLivingBase var9 : this.world.getEntitiesWithinAABB(EntityLivingBase.class, this.getEntityBoundingBox().expandXyz((double)5.0F))) {
            if (var9 != this.field_191513_e && this.getDistanceSqToEntity(var9) <= (double)25.0F) {
               boolean var10 = false;

               for(int var11 = 0; var11 < 2; ++var11) {
                  RayTraceResult var12 = this.world.rayTraceBlocks(var7, new Vec3d(var9.posX, var9.posY + (double)var9.height * (double)0.5F * (double)var11, var9.posZ), false, true, false);
                  if (var12 == null || var12.typeOfHit == RayTraceResult.Type.MISS) {
                     var10 = true;
                     break;
                  }
               }

               if (var10) {
                  float var13 = var1 * (float)Math.sqrt(((double)5.0F - (double)this.getDistanceToEntity(var9)) / (double)5.0F);
                  var9.attackEntityFrom(DamageSource.field_191552_t, var13);
               }
            }
         }
      }

   }

   public boolean func_191511_j() {
      return (Integer)this.dataManager.get(field_191512_b) > 0;
   }

   public void handleStatusUpdate(byte var1) {
      if (var1 == 17 && this.world.isRemote) {
         ItemStack var2 = (ItemStack)this.dataManager.get(FIREWORK_ITEM);
         NBTTagCompound var3 = var2.func_190926_b() ? null : var2.getSubCompound("Fireworks");
         this.world.makeFireworks(this.posX, this.posY, this.posZ, this.motionX, this.motionY, this.motionZ, var3);
      }

      super.handleStatusUpdate(var1);
   }

   public static void registerFixesFireworkRocket(DataFixer var0) {
      var0.registerWalker(FixTypes.ENTITY, new ItemStackData(EntityFireworkRocket.class, new String[]{"FireworksItem"}));
   }

   public void writeEntityToNBT(NBTTagCompound var1) {
      var1.setInteger("Life", this.fireworkAge);
      var1.setInteger("LifeTime", this.lifetime);
      ItemStack var2 = (ItemStack)this.dataManager.get(FIREWORK_ITEM);
      if (!var2.func_190926_b()) {
         var1.setTag("FireworksItem", var2.writeToNBT(new NBTTagCompound()));
      }

   }

   public void readEntityFromNBT(NBTTagCompound var1) {
      this.fireworkAge = var1.getInteger("Life");
      this.lifetime = var1.getInteger("LifeTime");
      NBTTagCompound var2 = var1.getCompoundTag("FireworksItem");
      if (var2 != null) {
         ItemStack var3 = new ItemStack(var2);
         if (!var3.func_190926_b()) {
            this.dataManager.set(FIREWORK_ITEM, var3);
         }
      }

   }

   public boolean canBeAttackedWithItem() {
      return false;
   }

   static {
      FIREWORK_ITEM = EntityDataManager.<ItemStack>createKey(EntityFireworkRocket.class, DataSerializers.OPTIONAL_ITEM_STACK);
      field_191512_b = EntityDataManager.<Integer>createKey(EntityFireworkRocket.class, DataSerializers.VARINT);
   }
}
