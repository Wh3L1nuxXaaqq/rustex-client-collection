package net.minecraft.entity.item;

import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.BlockRailPowered;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class EntityMinecart extends Entity implements IWorldNameable {
   private static final DataParameter<Integer> ROLLING_AMPLITUDE;
   private static final DataParameter<Integer> ROLLING_DIRECTION;
   private static final DataParameter<Float> DAMAGE;
   private static final DataParameter<Integer> DISPLAY_TILE;
   private static final DataParameter<Integer> DISPLAY_TILE_OFFSET;
   private static final DataParameter<Boolean> SHOW_BLOCK;
   private boolean isInReverse;
   private static final int[][][] MATRIX;
   private int turnProgress;
   private double minecartX;
   private double minecartY;
   private double minecartZ;
   private double minecartYaw;
   private double minecartPitch;
   private double velocityX;
   private double velocityY;
   private double velocityZ;

   public EntityMinecart(World var1) {
      super(var1);
      this.preventEntitySpawning = true;
      this.setSize(0.98F, 0.7F);
   }

   public static EntityMinecart create(World var0, double var1, double var3, double var5, Type var7) {
      switch (var7) {
         case CHEST:
            return new EntityMinecartChest(var0, var1, var3, var5);
         case FURNACE:
            return new EntityMinecartFurnace(var0, var1, var3, var5);
         case TNT:
            return new EntityMinecartTNT(var0, var1, var3, var5);
         case SPAWNER:
            return new EntityMinecartMobSpawner(var0, var1, var3, var5);
         case HOPPER:
            return new EntityMinecartHopper(var0, var1, var3, var5);
         case COMMAND_BLOCK:
            return new EntityMinecartCommandBlock(var0, var1, var3, var5);
         default:
            return new EntityMinecartEmpty(var0, var1, var3, var5);
      }
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   protected void entityInit() {
      this.dataManager.register(ROLLING_AMPLITUDE, 0);
      this.dataManager.register(ROLLING_DIRECTION, 1);
      this.dataManager.register(DAMAGE, 0.0F);
      this.dataManager.register(DISPLAY_TILE, 0);
      this.dataManager.register(DISPLAY_TILE_OFFSET, 6);
      this.dataManager.register(SHOW_BLOCK, false);
   }

   @Nullable
   public AxisAlignedBB getCollisionBox(Entity var1) {
      return var1.canBePushed() ? var1.getEntityBoundingBox() : null;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox() {
      return null;
   }

   public boolean canBePushed() {
      return true;
   }

   public EntityMinecart(World var1, double var2, double var4, double var6) {
      this(var1);
      this.setPosition(var2, var4, var6);
      this.motionX = (double)0.0F;
      this.motionY = (double)0.0F;
      this.motionZ = (double)0.0F;
      this.prevPosX = var2;
      this.prevPosY = var4;
      this.prevPosZ = var6;
   }

   public double getMountedYOffset() {
      return (double)0.0F;
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (!this.world.isRemote && !this.isDead) {
         if (this.isEntityInvulnerable(var1)) {
            return false;
         } else {
            this.setRollingDirection(-this.getRollingDirection());
            this.setRollingAmplitude(10);
            this.setBeenAttacked();
            this.setDamage(this.getDamage() + var2 * 10.0F);
            boolean var3 = var1.getEntity() instanceof EntityPlayer && ((EntityPlayer)var1.getEntity()).capabilities.isCreativeMode;
            if (var3 || this.getDamage() > 40.0F) {
               this.removePassengers();
               if (var3 && !this.hasCustomName()) {
                  this.setDead();
               } else {
                  this.killMinecart(var1);
               }
            }

            return true;
         }
      } else {
         return true;
      }
   }

   public void killMinecart(DamageSource var1) {
      this.setDead();
      if (this.world.getGameRules().getBoolean("doEntityDrops")) {
         ItemStack var2 = new ItemStack(Items.MINECART, 1);
         if (this.hasCustomName()) {
            var2.setStackDisplayName(this.getCustomNameTag());
         }

         this.entityDropItem(var2, 0.0F);
      }

   }

   public void performHurtAnimation() {
      this.setRollingDirection(-this.getRollingDirection());
      this.setRollingAmplitude(10);
      this.setDamage(this.getDamage() + this.getDamage() * 10.0F);
   }

   public boolean canBeCollidedWith() {
      return !this.isDead;
   }

   public EnumFacing getAdjustedHorizontalFacing() {
      return this.isInReverse ? this.getHorizontalFacing().getOpposite().rotateY() : this.getHorizontalFacing().rotateY();
   }

   public void onUpdate() {
      if (this.getRollingAmplitude() > 0) {
         this.setRollingAmplitude(this.getRollingAmplitude() - 1);
      }

      if (this.getDamage() > 0.0F) {
         this.setDamage(this.getDamage() - 1.0F);
      }

      if (this.posY < (double)-64.0F) {
         this.kill();
      }

      if (!this.world.isRemote && this.world instanceof WorldServer) {
         this.world.theProfiler.startSection("portal");
         MinecraftServer var1 = this.world.getMinecraftServer();
         int var2 = this.getMaxInPortalTime();
         if (this.inPortal) {
            if (var1.getAllowNether()) {
               if (!this.isRiding() && this.portalCounter++ >= var2) {
                  this.portalCounter = var2;
                  this.timeUntilPortal = this.getPortalCooldown();
                  byte var3;
                  if (this.world.provider.getDimensionType().getId() == -1) {
                     var3 = 0;
                  } else {
                     var3 = -1;
                  }

                  this.changeDimension(var3);
               }

               this.inPortal = false;
            }
         } else {
            if (this.portalCounter > 0) {
               this.portalCounter -= 4;
            }

            if (this.portalCounter < 0) {
               this.portalCounter = 0;
            }
         }

         if (this.timeUntilPortal > 0) {
            --this.timeUntilPortal;
         }

         this.world.theProfiler.endSection();
      }

      if (this.world.isRemote) {
         if (this.turnProgress > 0) {
            double var15 = this.posX + (this.minecartX - this.posX) / (double)this.turnProgress;
            double var18 = this.posY + (this.minecartY - this.posY) / (double)this.turnProgress;
            double var5 = this.posZ + (this.minecartZ - this.posZ) / (double)this.turnProgress;
            double var7 = MathHelper.wrapDegrees(this.minecartYaw - (double)this.rotationYaw);
            this.rotationYaw = (float)((double)this.rotationYaw + var7 / (double)this.turnProgress);
            this.rotationPitch = (float)((double)this.rotationPitch + (this.minecartPitch - (double)this.rotationPitch) / (double)this.turnProgress);
            --this.turnProgress;
            this.setPosition(var15, var18, var5);
            this.setRotation(this.rotationYaw, this.rotationPitch);
         } else {
            this.setPosition(this.posX, this.posY, this.posZ);
            this.setRotation(this.rotationYaw, this.rotationPitch);
         }
      } else {
         this.prevPosX = this.posX;
         this.prevPosY = this.posY;
         this.prevPosZ = this.posZ;
         if (!this.hasNoGravity()) {
            this.motionY -= (double)0.04F;
         }

         int var16 = MathHelper.floor(this.posX);
         int var17 = MathHelper.floor(this.posY);
         int var19 = MathHelper.floor(this.posZ);
         if (BlockRailBase.isRailBlock(this.world, new BlockPos(var16, var17 - 1, var19))) {
            --var17;
         }

         BlockPos var4 = new BlockPos(var16, var17, var19);
         IBlockState var20 = this.world.getBlockState(var4);
         if (BlockRailBase.isRailBlock(var20)) {
            this.moveAlongTrack(var4, var20);
            if (var20.getBlock() == Blocks.ACTIVATOR_RAIL) {
               this.onActivatorRailPass(var16, var17, var19, (Boolean)var20.getValue(BlockRailPowered.POWERED));
            }
         } else {
            this.moveDerailedMinecart();
         }

         this.doBlockCollisions();
         this.rotationPitch = 0.0F;
         double var6 = this.prevPosX - this.posX;
         double var8 = this.prevPosZ - this.posZ;
         if (var6 * var6 + var8 * var8 > 0.001) {
            this.rotationYaw = (float)(MathHelper.atan2(var8, var6) * (double)180.0F / Math.PI);
            if (this.isInReverse) {
               this.rotationYaw += 180.0F;
            }
         }

         double var10 = (double)MathHelper.wrapDegrees(this.rotationYaw - this.prevRotationYaw);
         if (var10 < (double)-170.0F || var10 >= (double)170.0F) {
            this.rotationYaw += 180.0F;
            this.isInReverse = !this.isInReverse;
         }

         this.setRotation(this.rotationYaw, this.rotationPitch);
         if (this.getType() == EntityMinecart.Type.RIDEABLE && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.01) {
            List var21 = this.world.getEntitiesInAABBexcluding(this, this.getEntityBoundingBox().expand((double)0.2F, (double)0.0F, (double)0.2F), EntitySelectors.getTeamCollisionPredicate(this));
            if (!var21.isEmpty()) {
               for(int var22 = 0; var22 < var21.size(); ++var22) {
                  Entity var14 = (Entity)var21.get(var22);
                  if (!(var14 instanceof EntityPlayer) && !(var14 instanceof EntityIronGolem) && !(var14 instanceof EntityMinecart) && !this.isBeingRidden() && !var14.isRiding()) {
                     var14.startRiding(this);
                  } else {
                     var14.applyEntityCollision(this);
                  }
               }
            }
         } else {
            for(Entity var13 : this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().expand((double)0.2F, (double)0.0F, (double)0.2F))) {
               if (!this.isPassenger(var13) && var13.canBePushed() && var13 instanceof EntityMinecart) {
                  var13.applyEntityCollision(this);
               }
            }
         }

         this.handleWaterMovement();
      }

   }

   protected double getMaximumSpeed() {
      return 0.4;
   }

   public void onActivatorRailPass(int var1, int var2, int var3, boolean var4) {
   }

   protected void moveDerailedMinecart() {
      double var1 = this.getMaximumSpeed();
      this.motionX = MathHelper.clamp(this.motionX, -var1, var1);
      this.motionZ = MathHelper.clamp(this.motionZ, -var1, var1);
      if (this.onGround) {
         this.motionX *= (double)0.5F;
         this.motionY *= (double)0.5F;
         this.motionZ *= (double)0.5F;
      }

      this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
      if (!this.onGround) {
         this.motionX *= (double)0.95F;
         this.motionY *= (double)0.95F;
         this.motionZ *= (double)0.95F;
      }

   }

   protected void moveAlongTrack(BlockPos var1, IBlockState var2) {
      this.fallDistance = 0.0F;
      Vec3d var3 = this.getPos(this.posX, this.posY, this.posZ);
      this.posY = (double)var1.getY();
      boolean var4 = false;
      boolean var5 = false;
      BlockRailBase var6 = (BlockRailBase)var2.getBlock();
      if (var6 == Blocks.GOLDEN_RAIL) {
         var4 = (Boolean)var2.getValue(BlockRailPowered.POWERED);
         var5 = !var4;
      }

      double var7 = (double)0.0078125F;
      BlockRailBase.EnumRailDirection var9 = (BlockRailBase.EnumRailDirection)var2.getValue(var6.getShapeProperty());
      switch (var9) {
         case ASCENDING_EAST:
            this.motionX -= (double)0.0078125F;
            ++this.posY;
            break;
         case ASCENDING_WEST:
            this.motionX += (double)0.0078125F;
            ++this.posY;
            break;
         case ASCENDING_NORTH:
            this.motionZ += (double)0.0078125F;
            ++this.posY;
            break;
         case ASCENDING_SOUTH:
            this.motionZ -= (double)0.0078125F;
            ++this.posY;
      }

      int[][] var10 = MATRIX[var9.getMetadata()];
      double var11 = (double)(var10[1][0] - var10[0][0]);
      double var13 = (double)(var10[1][2] - var10[0][2]);
      double var15 = Math.sqrt(var11 * var11 + var13 * var13);
      double var17 = this.motionX * var11 + this.motionZ * var13;
      if (var17 < (double)0.0F) {
         var11 = -var11;
         var13 = -var13;
      }

      double var19 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
      if (var19 > (double)2.0F) {
         var19 = (double)2.0F;
      }

      this.motionX = var19 * var11 / var15;
      this.motionZ = var19 * var13 / var15;
      Entity var21 = this.getPassengers().isEmpty() ? null : (Entity)this.getPassengers().get(0);
      if (var21 instanceof EntityLivingBase) {
         double var22 = (double)((EntityLivingBase)var21).field_191988_bg;
         if (var22 > (double)0.0F) {
            double var24 = -Math.sin((double)(var21.rotationYaw * ((float)Math.PI / 180F)));
            double var26 = Math.cos((double)(var21.rotationYaw * ((float)Math.PI / 180F)));
            double var28 = this.motionX * this.motionX + this.motionZ * this.motionZ;
            if (var28 < 0.01) {
               this.motionX += var24 * 0.1;
               this.motionZ += var26 * 0.1;
               var5 = false;
            }
         }
      }

      if (var5) {
         double var49 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
         if (var49 < 0.03) {
            this.motionX *= (double)0.0F;
            this.motionY *= (double)0.0F;
            this.motionZ *= (double)0.0F;
         } else {
            this.motionX *= (double)0.5F;
            this.motionY *= (double)0.0F;
            this.motionZ *= (double)0.5F;
         }
      }

      double var50 = (double)var1.getX() + (double)0.5F + (double)var10[0][0] * (double)0.5F;
      double var51 = (double)var1.getZ() + (double)0.5F + (double)var10[0][2] * (double)0.5F;
      double var52 = (double)var1.getX() + (double)0.5F + (double)var10[1][0] * (double)0.5F;
      double var53 = (double)var1.getZ() + (double)0.5F + (double)var10[1][2] * (double)0.5F;
      var11 = var52 - var50;
      var13 = var53 - var51;
      double var30;
      if (var11 == (double)0.0F) {
         this.posX = (double)var1.getX() + (double)0.5F;
         var30 = this.posZ - (double)var1.getZ();
      } else if (var13 == (double)0.0F) {
         this.posZ = (double)var1.getZ() + (double)0.5F;
         var30 = this.posX - (double)var1.getX();
      } else {
         double var32 = this.posX - var50;
         double var34 = this.posZ - var51;
         var30 = (var32 * var11 + var34 * var13) * (double)2.0F;
      }

      this.posX = var50 + var11 * var30;
      this.posZ = var51 + var13 * var30;
      this.setPosition(this.posX, this.posY, this.posZ);
      double var54 = this.motionX;
      double var56 = this.motionZ;
      if (this.isBeingRidden()) {
         var54 *= (double)0.75F;
         var56 *= (double)0.75F;
      }

      double var36 = this.getMaximumSpeed();
      var54 = MathHelper.clamp(var54, -var36, var36);
      var56 = MathHelper.clamp(var56, -var36, var36);
      this.moveEntity(MoverType.SELF, var54, (double)0.0F, var56);
      if (var10[0][1] != 0 && MathHelper.floor(this.posX) - var1.getX() == var10[0][0] && MathHelper.floor(this.posZ) - var1.getZ() == var10[0][2]) {
         this.setPosition(this.posX, this.posY + (double)var10[0][1], this.posZ);
      } else if (var10[1][1] != 0 && MathHelper.floor(this.posX) - var1.getX() == var10[1][0] && MathHelper.floor(this.posZ) - var1.getZ() == var10[1][2]) {
         this.setPosition(this.posX, this.posY + (double)var10[1][1], this.posZ);
      }

      this.applyDrag();
      Vec3d var38 = this.getPos(this.posX, this.posY, this.posZ);
      if (var38 != null && var3 != null) {
         double var39 = (var3.yCoord - var38.yCoord) * 0.05;
         var19 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
         if (var19 > (double)0.0F) {
            this.motionX = this.motionX / var19 * (var19 + var39);
            this.motionZ = this.motionZ / var19 * (var19 + var39);
         }

         this.setPosition(this.posX, var38.yCoord, this.posZ);
      }

      int var58 = MathHelper.floor(this.posX);
      int var40 = MathHelper.floor(this.posZ);
      if (var58 != var1.getX() || var40 != var1.getZ()) {
         var19 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
         this.motionX = var19 * (double)(var58 - var1.getX());
         this.motionZ = var19 * (double)(var40 - var1.getZ());
      }

      if (var4) {
         double var41 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
         if (var41 > 0.01) {
            double var43 = 0.06;
            this.motionX += this.motionX / var41 * 0.06;
            this.motionZ += this.motionZ / var41 * 0.06;
         } else if (var9 == BlockRailBase.EnumRailDirection.EAST_WEST) {
            if (this.world.getBlockState(var1.west()).isNormalCube()) {
               this.motionX = 0.02;
            } else if (this.world.getBlockState(var1.east()).isNormalCube()) {
               this.motionX = -0.02;
            }
         } else if (var9 == BlockRailBase.EnumRailDirection.NORTH_SOUTH) {
            if (this.world.getBlockState(var1.north()).isNormalCube()) {
               this.motionZ = 0.02;
            } else if (this.world.getBlockState(var1.south()).isNormalCube()) {
               this.motionZ = -0.02;
            }
         }
      }

   }

   protected void applyDrag() {
      if (this.isBeingRidden()) {
         this.motionX *= (double)0.997F;
         this.motionY *= (double)0.0F;
         this.motionZ *= (double)0.997F;
      } else {
         this.motionX *= (double)0.96F;
         this.motionY *= (double)0.0F;
         this.motionZ *= (double)0.96F;
      }

   }

   public void setPosition(double var1, double var3, double var5) {
      this.posX = var1;
      this.posY = var3;
      this.posZ = var5;
      float var7 = this.width / 2.0F;
      float var8 = this.height;
      this.setEntityBoundingBox(new AxisAlignedBB(var1 - (double)var7, var3, var5 - (double)var7, var1 + (double)var7, var3 + (double)var8, var5 + (double)var7));
   }

   @Nullable
   public Vec3d getPosOffset(double var1, double var3, double var5, double var7) {
      int var9 = MathHelper.floor(var1);
      int var10 = MathHelper.floor(var3);
      int var11 = MathHelper.floor(var5);
      if (BlockRailBase.isRailBlock(this.world, new BlockPos(var9, var10 - 1, var11))) {
         --var10;
      }

      IBlockState var12 = this.world.getBlockState(new BlockPos(var9, var10, var11));
      if (BlockRailBase.isRailBlock(var12)) {
         BlockRailBase.EnumRailDirection var13 = (BlockRailBase.EnumRailDirection)var12.getValue(((BlockRailBase)var12.getBlock()).getShapeProperty());
         var3 = (double)var10;
         if (var13.isAscending()) {
            var3 = (double)(var10 + 1);
         }

         int[][] var14 = MATRIX[var13.getMetadata()];
         double var15 = (double)(var14[1][0] - var14[0][0]);
         double var17 = (double)(var14[1][2] - var14[0][2]);
         double var19 = Math.sqrt(var15 * var15 + var17 * var17);
         var15 /= var19;
         var17 /= var19;
         var1 += var15 * var7;
         var5 += var17 * var7;
         if (var14[0][1] != 0 && MathHelper.floor(var1) - var9 == var14[0][0] && MathHelper.floor(var5) - var11 == var14[0][2]) {
            var3 += (double)var14[0][1];
         } else if (var14[1][1] != 0 && MathHelper.floor(var1) - var9 == var14[1][0] && MathHelper.floor(var5) - var11 == var14[1][2]) {
            var3 += (double)var14[1][1];
         }

         return this.getPos(var1, var3, var5);
      } else {
         return null;
      }
   }

   @Nullable
   public Vec3d getPos(double var1, double var3, double var5) {
      int var7 = MathHelper.floor(var1);
      int var8 = MathHelper.floor(var3);
      int var9 = MathHelper.floor(var5);
      if (BlockRailBase.isRailBlock(this.world, new BlockPos(var7, var8 - 1, var9))) {
         --var8;
      }

      IBlockState var10 = this.world.getBlockState(new BlockPos(var7, var8, var9));
      if (BlockRailBase.isRailBlock(var10)) {
         BlockRailBase.EnumRailDirection var11 = (BlockRailBase.EnumRailDirection)var10.getValue(((BlockRailBase)var10.getBlock()).getShapeProperty());
         int[][] var12 = MATRIX[var11.getMetadata()];
         double var13 = (double)var7 + (double)0.5F + (double)var12[0][0] * (double)0.5F;
         double var15 = (double)var8 + (double)0.0625F + (double)var12[0][1] * (double)0.5F;
         double var17 = (double)var9 + (double)0.5F + (double)var12[0][2] * (double)0.5F;
         double var19 = (double)var7 + (double)0.5F + (double)var12[1][0] * (double)0.5F;
         double var21 = (double)var8 + (double)0.0625F + (double)var12[1][1] * (double)0.5F;
         double var23 = (double)var9 + (double)0.5F + (double)var12[1][2] * (double)0.5F;
         double var25 = var19 - var13;
         double var27 = (var21 - var15) * (double)2.0F;
         double var29 = var23 - var17;
         double var31;
         if (var25 == (double)0.0F) {
            var31 = var5 - (double)var9;
         } else if (var29 == (double)0.0F) {
            var31 = var1 - (double)var7;
         } else {
            double var33 = var1 - var13;
            double var35 = var5 - var17;
            var31 = (var33 * var25 + var35 * var29) * (double)2.0F;
         }

         var1 = var13 + var25 * var31;
         var3 = var15 + var27 * var31;
         var5 = var17 + var29 * var31;
         if (var27 < (double)0.0F) {
            ++var3;
         }

         if (var27 > (double)0.0F) {
            var3 += (double)0.5F;
         }

         return new Vec3d(var1, var3, var5);
      } else {
         return null;
      }
   }

   public AxisAlignedBB getRenderBoundingBox() {
      AxisAlignedBB var1 = this.getEntityBoundingBox();
      return this.hasDisplayTile() ? var1.expandXyz((double)Math.abs(this.getDisplayTileOffset()) / (double)16.0F) : var1;
   }

   public static void registerFixesMinecart(DataFixer var0, Class<?> var1) {
   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      if (var1.getBoolean("CustomDisplayTile")) {
         Block var2;
         if (var1.hasKey("DisplayTile", 8)) {
            var2 = Block.getBlockFromName(var1.getString("DisplayTile"));
         } else {
            var2 = Block.getBlockById(var1.getInteger("DisplayTile"));
         }

         int var3 = var1.getInteger("DisplayData");
         this.setDisplayTile(var2 == null ? Blocks.AIR.getDefaultState() : var2.getStateFromMeta(var3));
         this.setDisplayTileOffset(var1.getInteger("DisplayOffset"));
      }

   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      if (this.hasDisplayTile()) {
         var1.setBoolean("CustomDisplayTile", true);
         IBlockState var2 = this.getDisplayTile();
         ResourceLocation var3 = Block.REGISTRY.getNameForObject(var2.getBlock());
         var1.setString("DisplayTile", var3 == null ? "" : var3.toString());
         var1.setInteger("DisplayData", var2.getBlock().getMetaFromState(var2));
         var1.setInteger("DisplayOffset", this.getDisplayTileOffset());
      }

   }

   public void applyEntityCollision(Entity var1) {
      if (!this.world.isRemote && !var1.noClip && !this.noClip && !this.isPassenger(var1)) {
         double var2 = var1.posX - this.posX;
         double var4 = var1.posZ - this.posZ;
         double var6 = var2 * var2 + var4 * var4;
         if (var6 >= (double)1.0E-4F) {
            var6 = (double)MathHelper.sqrt(var6);
            var2 /= var6;
            var4 /= var6;
            double var8 = (double)1.0F / var6;
            if (var8 > (double)1.0F) {
               var8 = (double)1.0F;
            }

            var2 *= var8;
            var4 *= var8;
            var2 *= (double)0.1F;
            var4 *= (double)0.1F;
            var2 *= (double)(1.0F - this.entityCollisionReduction);
            var4 *= (double)(1.0F - this.entityCollisionReduction);
            var2 *= (double)0.5F;
            var4 *= (double)0.5F;
            if (var1 instanceof EntityMinecart) {
               double var10 = var1.posX - this.posX;
               double var12 = var1.posZ - this.posZ;
               Vec3d var14 = (new Vec3d(var10, (double)0.0F, var12)).normalize();
               Vec3d var15 = (new Vec3d((double)MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F)), (double)0.0F, (double)MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F)))).normalize();
               double var16 = Math.abs(var14.dotProduct(var15));
               if (var16 < (double)0.8F) {
                  return;
               }

               double var18 = var1.motionX + this.motionX;
               double var20 = var1.motionZ + this.motionZ;
               if (((EntityMinecart)var1).getType() == EntityMinecart.Type.FURNACE && this.getType() != EntityMinecart.Type.FURNACE) {
                  this.motionX *= (double)0.2F;
                  this.motionZ *= (double)0.2F;
                  this.addVelocity(var1.motionX - var2, (double)0.0F, var1.motionZ - var4);
                  var1.motionX *= (double)0.95F;
                  var1.motionZ *= (double)0.95F;
               } else if (((EntityMinecart)var1).getType() != EntityMinecart.Type.FURNACE && this.getType() == EntityMinecart.Type.FURNACE) {
                  var1.motionX *= (double)0.2F;
                  var1.motionZ *= (double)0.2F;
                  var1.addVelocity(this.motionX + var2, (double)0.0F, this.motionZ + var4);
                  this.motionX *= (double)0.95F;
                  this.motionZ *= (double)0.95F;
               } else {
                  var18 /= (double)2.0F;
                  var20 /= (double)2.0F;
                  this.motionX *= (double)0.2F;
                  this.motionZ *= (double)0.2F;
                  this.addVelocity(var18 - var2, (double)0.0F, var20 - var4);
                  var1.motionX *= (double)0.2F;
                  var1.motionZ *= (double)0.2F;
                  var1.addVelocity(var18 + var2, (double)0.0F, var20 + var4);
               }
            } else {
               this.addVelocity(-var2, (double)0.0F, -var4);
               var1.addVelocity(var2 / (double)4.0F, (double)0.0F, var4 / (double)4.0F);
            }
         }
      }

   }

   public void setPositionAndRotationDirect(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
      this.minecartX = var1;
      this.minecartY = var3;
      this.minecartZ = var5;
      this.minecartYaw = (double)var7;
      this.minecartPitch = (double)var8;
      this.turnProgress = var9 + 2;
      this.motionX = this.velocityX;
      this.motionY = this.velocityY;
      this.motionZ = this.velocityZ;
   }

   public void setVelocity(double var1, double var3, double var5) {
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
      this.velocityX = this.motionX;
      this.velocityY = this.motionY;
      this.velocityZ = this.motionZ;
   }

   public void setDamage(float var1) {
      this.dataManager.set(DAMAGE, var1);
   }

   public float getDamage() {
      return (Float)this.dataManager.get(DAMAGE);
   }

   public void setRollingAmplitude(int var1) {
      this.dataManager.set(ROLLING_AMPLITUDE, var1);
   }

   public int getRollingAmplitude() {
      return (Integer)this.dataManager.get(ROLLING_AMPLITUDE);
   }

   public void setRollingDirection(int var1) {
      this.dataManager.set(ROLLING_DIRECTION, var1);
   }

   public int getRollingDirection() {
      return (Integer)this.dataManager.get(ROLLING_DIRECTION);
   }

   public abstract Type getType();

   public IBlockState getDisplayTile() {
      return !this.hasDisplayTile() ? this.getDefaultDisplayTile() : Block.getStateById((Integer)this.getDataManager().get(DISPLAY_TILE));
   }

   public IBlockState getDefaultDisplayTile() {
      return Blocks.AIR.getDefaultState();
   }

   public int getDisplayTileOffset() {
      return !this.hasDisplayTile() ? this.getDefaultDisplayTileOffset() : (Integer)this.getDataManager().get(DISPLAY_TILE_OFFSET);
   }

   public int getDefaultDisplayTileOffset() {
      return 6;
   }

   public void setDisplayTile(IBlockState var1) {
      this.getDataManager().set(DISPLAY_TILE, Block.getStateId(var1));
      this.setHasDisplayTile(true);
   }

   public void setDisplayTileOffset(int var1) {
      this.getDataManager().set(DISPLAY_TILE_OFFSET, var1);
      this.setHasDisplayTile(true);
   }

   public boolean hasDisplayTile() {
      return (Boolean)this.getDataManager().get(SHOW_BLOCK);
   }

   public void setHasDisplayTile(boolean var1) {
      this.getDataManager().set(SHOW_BLOCK, var1);
   }

   static {
      ROLLING_AMPLITUDE = EntityDataManager.<Integer>createKey(EntityMinecart.class, DataSerializers.VARINT);
      ROLLING_DIRECTION = EntityDataManager.<Integer>createKey(EntityMinecart.class, DataSerializers.VARINT);
      DAMAGE = EntityDataManager.<Float>createKey(EntityMinecart.class, DataSerializers.FLOAT);
      DISPLAY_TILE = EntityDataManager.<Integer>createKey(EntityMinecart.class, DataSerializers.VARINT);
      DISPLAY_TILE_OFFSET = EntityDataManager.<Integer>createKey(EntityMinecart.class, DataSerializers.VARINT);
      SHOW_BLOCK = EntityDataManager.<Boolean>createKey(EntityMinecart.class, DataSerializers.BOOLEAN);
      MATRIX = new int[][][]{{{0, 0, -1}, {0, 0, 1}}, {{-1, 0, 0}, {1, 0, 0}}, {{-1, -1, 0}, {1, 0, 0}}, {{-1, 0, 0}, {1, -1, 0}}, {{0, 0, -1}, {0, -1, 1}}, {{0, -1, -1}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 0}}, {{0, 0, 1}, {-1, 0, 0}}, {{0, 0, -1}, {-1, 0, 0}}, {{0, 0, -1}, {1, 0, 0}}};
   }

   public static enum Type {
      RIDEABLE(0, "MinecartRideable"),
      CHEST(1, "MinecartChest"),
      FURNACE(2, "MinecartFurnace"),
      TNT(3, "MinecartTNT"),
      SPAWNER(4, "MinecartSpawner"),
      HOPPER(5, "MinecartHopper"),
      COMMAND_BLOCK(6, "MinecartCommandBlock");

      private static final Map<Integer, Type> BY_ID = Maps.newHashMap();
      private final int id;
      private final String name;

      private Type(int var3, String var4) {
         this.id = var3;
         this.name = var4;
      }

      public int getId() {
         return this.id;
      }

      public String getName() {
         return this.name;
      }

      public static Type getById(int var0) {
         Type var1 = (Type)BY_ID.get(var0);
         return var1 == null ? RIDEABLE : var1;
      }

      static {
         for(Type var3 : values()) {
            BY_ID.put(var3.getId(), var3);
         }

      }
   }
}
