package net.minecraft.entity.item;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityFallingBlock extends Entity {
   private IBlockState fallTile;
   public int fallTime;
   public boolean shouldDropItem = true;
   private boolean canSetAsBlock;
   private boolean hurtEntities;
   private int fallHurtMax = 40;
   private float fallHurtAmount = 2.0F;
   public NBTTagCompound tileEntityData;
   protected static final DataParameter<BlockPos> ORIGIN;

   public EntityFallingBlock(World var1) {
      super(var1);
   }

   public EntityFallingBlock(World var1, double var2, double var4, double var6, IBlockState var8) {
      super(var1);
      this.fallTile = var8;
      this.preventEntitySpawning = true;
      this.setSize(0.98F, 0.98F);
      this.setPosition(var2, var4 + (double)((1.0F - this.height) / 2.0F), var6);
      this.motionX = (double)0.0F;
      this.motionY = (double)0.0F;
      this.motionZ = (double)0.0F;
      this.prevPosX = var2;
      this.prevPosY = var4;
      this.prevPosZ = var6;
      this.setOrigin(new BlockPos(this));
   }

   public boolean canBeAttackedWithItem() {
      return false;
   }

   public void setOrigin(BlockPos var1) {
      this.dataManager.set(ORIGIN, var1);
   }

   public BlockPos getOrigin() {
      return (BlockPos)this.dataManager.get(ORIGIN);
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   protected void entityInit() {
      this.dataManager.register(ORIGIN, BlockPos.ORIGIN);
   }

   public boolean canBeCollidedWith() {
      return !this.isDead;
   }

   public void onUpdate() {
      Block var1 = this.fallTile.getBlock();
      if (this.fallTile.getMaterial() == Material.AIR) {
         this.setDead();
      } else {
         this.prevPosX = this.posX;
         this.prevPosY = this.posY;
         this.prevPosZ = this.posZ;
         if (this.fallTime++ == 0) {
            BlockPos var2 = new BlockPos(this);
            if (this.world.getBlockState(var2).getBlock() == var1) {
               this.world.setBlockToAir(var2);
            } else if (!this.world.isRemote) {
               this.setDead();
               return;
            }
         }

         if (!this.hasNoGravity()) {
            this.motionY -= (double)0.04F;
         }

         this.moveEntity(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
         if (!this.world.isRemote) {
            BlockPos var13 = new BlockPos(this);
            boolean var3 = this.fallTile.getBlock() == Blocks.field_192444_dS;
            boolean var4 = var3 && this.world.getBlockState(var13).getMaterial() == Material.WATER;
            double var5 = this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ;
            if (var3 && var5 > (double)1.0F) {
               RayTraceResult var7 = this.world.rayTraceBlocks(new Vec3d(this.prevPosX, this.prevPosY, this.prevPosZ), new Vec3d(this.posX, this.posY, this.posZ), true);
               if (var7 != null && this.world.getBlockState(var7.getBlockPos()).getMaterial() == Material.WATER) {
                  var13 = var7.getBlockPos();
                  var4 = true;
               }
            }

            if (!this.onGround && !var4) {
               if (this.fallTime > 100 && !this.world.isRemote && (var13.getY() < 1 || var13.getY() > 256) || this.fallTime > 600) {
                  if (this.shouldDropItem && this.world.getGameRules().getBoolean("doEntityDrops")) {
                     this.entityDropItem(new ItemStack(var1, 1, var1.damageDropped(this.fallTile)), 0.0F);
                  }

                  this.setDead();
               }
            } else {
               IBlockState var14 = this.world.getBlockState(var13);
               if (!var4 && BlockFalling.canFallThrough(this.world.getBlockState(new BlockPos(this.posX, this.posY - (double)0.01F, this.posZ)))) {
                  this.onGround = false;
                  return;
               }

               this.motionX *= (double)0.7F;
               this.motionZ *= (double)0.7F;
               this.motionY *= (double)-0.5F;
               if (var14.getBlock() != Blocks.PISTON_EXTENSION) {
                  this.setDead();
                  if (this.canSetAsBlock) {
                     if (var1 instanceof BlockFalling) {
                        ((BlockFalling)var1).func_190974_b(this.world, var13);
                     }
                  } else if (this.world.func_190527_a(var1, var13, true, EnumFacing.UP, (Entity)null) && (var4 || !BlockFalling.canFallThrough(this.world.getBlockState(var13.down()))) && this.world.setBlockState(var13, this.fallTile, 3)) {
                     if (var1 instanceof BlockFalling) {
                        ((BlockFalling)var1).onEndFalling(this.world, var13, this.fallTile, var14);
                     }

                     if (this.tileEntityData != null && var1 instanceof ITileEntityProvider) {
                        TileEntity var8 = this.world.getTileEntity(var13);
                        if (var8 != null) {
                           NBTTagCompound var9 = var8.writeToNBT(new NBTTagCompound());

                           for(String var11 : this.tileEntityData.getKeySet()) {
                              NBTBase var12 = this.tileEntityData.getTag(var11);
                              if (!"x".equals(var11) && !"y".equals(var11) && !"z".equals(var11)) {
                                 var9.setTag(var11, var12.copy());
                              }
                           }

                           var8.readFromNBT(var9);
                           var8.markDirty();
                        }
                     }
                  } else if (this.shouldDropItem && this.world.getGameRules().getBoolean("doEntityDrops")) {
                     this.entityDropItem(new ItemStack(var1, 1, var1.damageDropped(this.fallTile)), 0.0F);
                  }
               }
            }
         }

         this.motionX *= (double)0.98F;
         this.motionY *= (double)0.98F;
         this.motionZ *= (double)0.98F;
      }

   }

   public void fall(float var1, float var2) {
      Block var3 = this.fallTile.getBlock();
      if (this.hurtEntities) {
         int var4 = MathHelper.ceil(var1 - 1.0F);
         if (var4 > 0) {
            ArrayList var5 = Lists.newArrayList(this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox()));
            boolean var6 = var3 == Blocks.ANVIL;
            DamageSource var7 = var6 ? DamageSource.anvil : DamageSource.fallingBlock;

            for(Object var9_raw : var5) {
               Entity var9 = (Entity)var9_raw;
               var9.attackEntityFrom(var7, (float)Math.min(MathHelper.floor((float)var4 * this.fallHurtAmount), this.fallHurtMax));
            }

            if (var6 && (double)this.rand.nextFloat() < (double)0.05F + (double)var4 * 0.05) {
               int var10 = (Integer)this.fallTile.getValue(BlockAnvil.DAMAGE);
               ++var10;
               if (var10 > 2) {
                  this.canSetAsBlock = true;
               } else {
                  this.fallTile = this.fallTile.withProperty(BlockAnvil.DAMAGE, var10);
               }
            }
         }
      }

   }

   public static void registerFixesFallingBlock(DataFixer var0) {
   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      Block var2 = this.fallTile != null ? this.fallTile.getBlock() : Blocks.AIR;
      ResourceLocation var3 = Block.REGISTRY.getNameForObject(var2);
      var1.setString("Block", var3 == null ? "" : var3.toString());
      var1.setByte("Data", (byte)var2.getMetaFromState(this.fallTile));
      var1.setInteger("Time", this.fallTime);
      var1.setBoolean("DropItem", this.shouldDropItem);
      var1.setBoolean("HurtEntities", this.hurtEntities);
      var1.setFloat("FallHurtAmount", this.fallHurtAmount);
      var1.setInteger("FallHurtMax", this.fallHurtMax);
      if (this.tileEntityData != null) {
         var1.setTag("TileEntityData", this.tileEntityData);
      }

   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      int var2 = var1.getByte("Data") & 255;
      if (var1.hasKey("Block", 8)) {
         this.fallTile = Block.getBlockFromName(var1.getString("Block")).getStateFromMeta(var2);
      } else if (var1.hasKey("TileID", 99)) {
         this.fallTile = Block.getBlockById(var1.getInteger("TileID")).getStateFromMeta(var2);
      } else {
         this.fallTile = Block.getBlockById(var1.getByte("Tile") & 255).getStateFromMeta(var2);
      }

      this.fallTime = var1.getInteger("Time");
      Block var3 = this.fallTile.getBlock();
      if (var1.hasKey("HurtEntities", 99)) {
         this.hurtEntities = var1.getBoolean("HurtEntities");
         this.fallHurtAmount = var1.getFloat("FallHurtAmount");
         this.fallHurtMax = var1.getInteger("FallHurtMax");
      } else if (var3 == Blocks.ANVIL) {
         this.hurtEntities = true;
      }

      if (var1.hasKey("DropItem", 99)) {
         this.shouldDropItem = var1.getBoolean("DropItem");
      }

      if (var1.hasKey("TileEntityData", 10)) {
         this.tileEntityData = var1.getCompoundTag("TileEntityData");
      }

      if (var3 == null || var3.getDefaultState().getMaterial() == Material.AIR) {
         this.fallTile = Blocks.SAND.getDefaultState();
      }

   }

   public World getWorldObj() {
      return this.world;
   }

   public void setHurtEntities(boolean var1) {
      this.hurtEntities = var1;
   }

   public boolean canRenderOnFire() {
      return false;
   }

   public void addEntityCrashInfo(CrashReportCategory var1) {
      super.addEntityCrashInfo(var1);
      if (this.fallTile != null) {
         Block var2 = this.fallTile.getBlock();
         var1.addCrashSection("Immitating block ID", Block.getIdFromBlock(var2));
         var1.addCrashSection("Immitating block data", var2.getMetaFromState(this.fallTile));
      }

   }

   @Nullable
   public IBlockState getBlock() {
      return this.fallTile;
   }

   public boolean ignoreItemEntityData() {
      return true;
   }

   static {
      ORIGIN = EntityDataManager.<BlockPos>createKey(EntityFallingBlock.class, DataSerializers.BLOCK_POS);
   }
}
