package net.minecraft.entity.item;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.LockCode;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.loot.ILootContainer;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;

public abstract class EntityMinecartContainer extends EntityMinecart implements ILockableContainer, ILootContainer {
   private NonNullList<ItemStack> minecartContainerItems;
   private boolean dropContentsWhenDead;
   private ResourceLocation lootTable;
   private long lootTableSeed;

   public EntityMinecartContainer(World var1) {
      super(var1);
      this.minecartContainerItems = NonNullList.<ItemStack>func_191197_a(36, ItemStack.field_190927_a);
      this.dropContentsWhenDead = true;
   }

   public EntityMinecartContainer(World var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6);
      this.minecartContainerItems = NonNullList.<ItemStack>func_191197_a(36, ItemStack.field_190927_a);
      this.dropContentsWhenDead = true;
   }

   public void killMinecart(DamageSource var1) {
      super.killMinecart(var1);
      if (this.world.getGameRules().getBoolean("doEntityDrops")) {
         InventoryHelper.dropInventoryItems(this.world, (Entity)this, this);
      }

   }

   public boolean func_191420_l() {
      for(ItemStack var2 : this.minecartContainerItems) {
         if (!var2.func_190926_b()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int var1) {
      this.addLoot((EntityPlayer)null);
      return this.minecartContainerItems.get(var1);
   }

   public ItemStack decrStackSize(int var1, int var2) {
      this.addLoot((EntityPlayer)null);
      return ItemStackHelper.getAndSplit(this.minecartContainerItems, var1, var2);
   }

   public ItemStack removeStackFromSlot(int var1) {
      this.addLoot((EntityPlayer)null);
      ItemStack var2 = this.minecartContainerItems.get(var1);
      if (var2.func_190926_b()) {
         return ItemStack.field_190927_a;
      } else {
         this.minecartContainerItems.set(var1, ItemStack.field_190927_a);
         return var2;
      }
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      this.addLoot((EntityPlayer)null);
      this.minecartContainerItems.set(var1, var2);
      if (!var2.func_190926_b() && var2.func_190916_E() > this.getInventoryStackLimit()) {
         var2.func_190920_e(this.getInventoryStackLimit());
      }

   }

   public void markDirty() {
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      if (this.isDead) {
         return false;
      } else {
         return var1.getDistanceSqToEntity(this) <= (double)64.0F;
      }
   }

   public void openInventory(EntityPlayer var1) {
   }

   public void closeInventory(EntityPlayer var1) {
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      return true;
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   @Nullable
   public Entity changeDimension(int var1) {
      this.dropContentsWhenDead = false;
      return super.changeDimension(var1);
   }

   public void setDead() {
      if (this.dropContentsWhenDead) {
         InventoryHelper.dropInventoryItems(this.world, (Entity)this, this);
      }

      super.setDead();
   }

   public void setDropItemsWhenDead(boolean var1) {
      this.dropContentsWhenDead = var1;
   }

   public static void func_190574_b(DataFixer var0, Class<?> var1) {
      EntityMinecart.registerFixesMinecart(var0, var1);
      var0.registerWalker(FixTypes.ENTITY, new ItemStackDataLists(var1, new String[]{"Items"}));
   }

   protected void writeEntityToNBT(NBTTagCompound var1) {
      super.writeEntityToNBT(var1);
      if (this.lootTable != null) {
         var1.setString("LootTable", this.lootTable.toString());
         if (this.lootTableSeed != 0L) {
            var1.setLong("LootTableSeed", this.lootTableSeed);
         }
      } else {
         ItemStackHelper.func_191282_a(var1, this.minecartContainerItems);
      }

   }

   protected void readEntityFromNBT(NBTTagCompound var1) {
      super.readEntityFromNBT(var1);
      this.minecartContainerItems = NonNullList.<ItemStack>func_191197_a(this.getSizeInventory(), ItemStack.field_190927_a);
      if (var1.hasKey("LootTable", 8)) {
         this.lootTable = new ResourceLocation(var1.getString("LootTable"));
         this.lootTableSeed = var1.getLong("LootTableSeed");
      } else {
         ItemStackHelper.func_191283_b(var1, this.minecartContainerItems);
      }

   }

   public boolean processInitialInteract(EntityPlayer var1, EnumHand var2) {
      if (!this.world.isRemote) {
         var1.displayGUIChest(this);
      }

      return true;
   }

   protected void applyDrag() {
      float var1 = 0.98F;
      if (this.lootTable == null) {
         int var2 = 15 - Container.calcRedstoneFromInventory(this);
         var1 += (float)var2 * 0.001F;
      }

      this.motionX *= (double)var1;
      this.motionY *= (double)0.0F;
      this.motionZ *= (double)var1;
   }

   public int getField(int var1) {
      return 0;
   }

   public void setField(int var1, int var2) {
   }

   public int getFieldCount() {
      return 0;
   }

   public boolean isLocked() {
      return false;
   }

   public void setLockCode(LockCode var1) {
   }

   public LockCode getLockCode() {
      return LockCode.EMPTY_CODE;
   }

   public void addLoot(@Nullable EntityPlayer var1) {
      if (this.lootTable != null) {
         LootTable var2 = this.world.getLootTableManager().getLootTableFromLocation(this.lootTable);
         this.lootTable = null;
         Random var3;
         if (this.lootTableSeed == 0L) {
            var3 = new Random();
         } else {
            var3 = new Random(this.lootTableSeed);
         }

         LootContext.Builder var4 = new LootContext.Builder((WorldServer)this.world);
         if (var1 != null) {
            var4.withLuck(var1.getLuck());
         }

         var2.fillInventory(this, var3, var4.build());
      }

   }

   public void clear() {
      this.addLoot((EntityPlayer)null);
      this.minecartContainerItems.clear();
   }

   public void setLootTable(ResourceLocation var1, long var2) {
      this.lootTable = var1;
      this.lootTableSeed = var2;
   }

   public ResourceLocation getLootTable() {
      return this.lootTable;
   }
}
