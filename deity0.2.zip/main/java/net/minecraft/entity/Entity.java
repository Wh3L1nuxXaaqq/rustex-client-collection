package net.minecraft.entity;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockWall;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.command.CommandResultStats;
import net.minecraft.command.ICommandSender;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.IDataFixer;
import net.minecraft.util.datafix.IDataWalker;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.Explosion;
import net.minecraft.world.Teleporter;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class Entity implements ICommandSender {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final List<ItemStack> field_190535_b = Collections.emptyList();
   private static final AxisAlignedBB ZERO_AABB = new AxisAlignedBB((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
   private static double renderDistanceWeight = (double)1.0F;
   private static int nextEntityID;
   private int entityId;
   public boolean preventEntitySpawning;
   private final List<Entity> riddenByEntities;
   protected int rideCooldown;
   private Entity ridingEntity;
   public boolean forceSpawn;
   public World world;
   public double prevPosX;
   public double prevPosY;
   public double prevPosZ;
   public double posX;
   public double posY;
   public double posZ;
   public double motionX;
   public double motionY;
   public double motionZ;
   public float rotationYaw;
   public float rotationPitch;
   public float prevRotationYaw;
   public float prevRotationPitch;
   private AxisAlignedBB boundingBox;
   public boolean onGround;
   public boolean isCollidedHorizontally;
   public boolean isCollidedVertically;
   public boolean isCollided;
   public boolean velocityChanged;
   protected boolean isInWeb;
   private boolean isOutsideBorder;
   public boolean isDead;
   public float width;
   public float height;
   public float prevDistanceWalkedModified;
   public float distanceWalkedModified;
   public float distanceWalkedOnStepModified;
   public float fallDistance;
   private int nextStepDistance;
   private float field_191959_ay;
   public double lastTickPosX;
   public double lastTickPosY;
   public double lastTickPosZ;
   public float stepHeight;
   public boolean noClip;
   public float entityCollisionReduction;
   protected Random rand;
   public int ticksExisted;
   private int field_190534_ay;
   protected boolean inWater;
   public int hurtResistantTime;
   protected boolean firstUpdate;
   protected boolean isImmuneToFire;
   protected EntityDataManager dataManager;
   protected static final DataParameter<Byte> FLAGS;
   private static final DataParameter<Integer> AIR;
   private static final DataParameter<String> CUSTOM_NAME;
   private static final DataParameter<Boolean> CUSTOM_NAME_VISIBLE;
   private static final DataParameter<Boolean> SILENT;
   private static final DataParameter<Boolean> NO_GRAVITY;
   public boolean addedToChunk;
   public int chunkCoordX;
   public int chunkCoordY;
   public int chunkCoordZ;
   public long serverPosX;
   public long serverPosY;
   public long serverPosZ;
   public boolean ignoreFrustumCheck;
   public boolean isAirBorne;
   public int timeUntilPortal;
   protected boolean inPortal;
   protected int portalCounter;
   public int dimension;
   protected BlockPos lastPortalPos;
   protected Vec3d lastPortalVec;
   protected EnumFacing teleportDirection;
   private boolean invulnerable;
   protected UUID entityUniqueID;
   protected String cachedUniqueIdString;
   private final CommandResultStats cmdResultStats;
   protected boolean glowing;
   private final Set<String> tags;
   private boolean isPositionDirty;
   private final double[] field_191505_aI;
   private long field_191506_aJ;

   public Entity(World var1) {
      this.entityId = nextEntityID++;
      this.riddenByEntities = Lists.newArrayList();
      this.boundingBox = ZERO_AABB;
      this.width = 0.6F;
      this.height = 1.8F;
      this.nextStepDistance = 1;
      this.field_191959_ay = 1.0F;
      this.rand = new Random();
      this.field_190534_ay = -this.func_190531_bD();
      this.firstUpdate = true;
      this.entityUniqueID = MathHelper.getRandomUUID(this.rand);
      this.cachedUniqueIdString = this.entityUniqueID.toString();
      this.cmdResultStats = new CommandResultStats();
      this.tags = Sets.newHashSet();
      this.field_191505_aI = new double[]{(double)0.0F, (double)0.0F, (double)0.0F};
      this.world = var1;
      this.setPosition((double)0.0F, (double)0.0F, (double)0.0F);
      if (var1 != null) {
         this.dimension = var1.provider.getDimensionType().getId();
      }

      this.dataManager = new EntityDataManager(this);
      this.dataManager.register(FLAGS, (byte)0);
      this.dataManager.register(AIR, 300);
      this.dataManager.register(CUSTOM_NAME_VISIBLE, false);
      this.dataManager.register(CUSTOM_NAME, "");
      this.dataManager.register(SILENT, false);
      this.dataManager.register(NO_GRAVITY, false);
      this.entityInit();
   }

   public int getEntityId() {
      return this.entityId;
   }

   public void setEntityId(int var1) {
      this.entityId = var1;
   }

   public Set<String> getTags() {
      return this.tags;
   }

   public boolean addTag(String var1) {
      if (this.tags.size() >= 1024) {
         return false;
      } else {
         this.tags.add(var1);
         return true;
      }
   }

   public boolean removeTag(String var1) {
      return this.tags.remove(var1);
   }

   public void onKillCommand() {
      this.setDead();
   }

   protected abstract void entityInit();

   public EntityDataManager getDataManager() {
      return this.dataManager;
   }

   public boolean equals(Object var1) {
      if (var1 instanceof Entity) {
         return ((Entity)var1).entityId == this.entityId;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.entityId;
   }

   protected void preparePlayerToSpawn() {
      if (this.world != null) {
         while(true) {
            if (this.posY > (double)0.0F && this.posY < (double)256.0F) {
               this.setPosition(this.posX, this.posY, this.posZ);
               if (!this.world.getCollisionBoxes(this, this.getEntityBoundingBox()).isEmpty()) {
                  ++this.posY;
                  continue;
               }
            }

            this.motionX = (double)0.0F;
            this.motionY = (double)0.0F;
            this.motionZ = (double)0.0F;
            this.rotationPitch = 0.0F;
            break;
         }
      }

   }

   public void setDead() {
      this.isDead = true;
   }

   public void setDropItemsWhenDead(boolean var1) {
   }

   protected void setSize(float var1, float var2) {
      if (var1 != this.width || var2 != this.height) {
         float var3 = this.width;
         this.width = var1;
         this.height = var2;
         if (this.width < var3) {
            double var6 = (double)var1 / (double)2.0F;
            this.setEntityBoundingBox(new AxisAlignedBB(this.posX - var6, this.posY, this.posZ - var6, this.posX + var6, this.posY + (double)this.height, this.posZ + var6));
            return;
         }

         AxisAlignedBB var4 = this.getEntityBoundingBox();
         this.setEntityBoundingBox(new AxisAlignedBB(var4.minX, var4.minY, var4.minZ, var4.minX + (double)this.width, var4.minY + (double)this.height, var4.minZ + (double)this.width));
         if (this.width > var3 && !this.firstUpdate && !this.world.isRemote) {
            this.moveEntity(MoverType.SELF, (double)(var3 - this.width), (double)0.0F, (double)(var3 - this.width));
         }
      }

   }

   protected void setRotation(float var1, float var2) {
      this.rotationYaw = var1 % 360.0F;
      this.rotationPitch = var2 % 360.0F;
   }

   public void setPosition(double var1, double var3, double var5) {
      this.posX = var1;
      this.posY = var3;
      this.posZ = var5;
      float var7 = this.width / 2.0F;
      float var8 = this.height;
      this.setEntityBoundingBox(new AxisAlignedBB(var1 - (double)var7, var3, var5 - (double)var7, var1 + (double)var7, var3 + (double)var8, var5 + (double)var7));
   }

   public void setAngles(float var1, float var2) {
      float var3 = this.rotationPitch;
      float var4 = this.rotationYaw;
      this.rotationYaw = (float)((double)this.rotationYaw + (double)var1 * 0.15);
      this.rotationPitch = (float)((double)this.rotationPitch - (double)var2 * 0.15);
      this.rotationPitch = MathHelper.clamp(this.rotationPitch, -90.0F, 90.0F);
      this.prevRotationPitch += this.rotationPitch - var3;
      this.prevRotationYaw += this.rotationYaw - var4;
      if (this.ridingEntity != null) {
         this.ridingEntity.applyOrientationToEntity(this);
      }

   }

   public void onUpdate() {
      if (!this.world.isRemote) {
         this.setFlag(6, this.isGlowing());
      }

      this.onEntityUpdate();
   }

   public void onEntityUpdate() {
      this.world.theProfiler.startSection("entityBaseTick");
      if (this.isRiding() && this.getRidingEntity().isDead) {
         this.dismountRidingEntity();
      }

      if (this.rideCooldown > 0) {
         --this.rideCooldown;
      }

      this.prevDistanceWalkedModified = this.distanceWalkedModified;
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      this.prevRotationPitch = this.rotationPitch;
      this.prevRotationYaw = this.rotationYaw;
      if (!this.world.isRemote && this.world instanceof WorldServer) {
         this.world.theProfiler.startSection("portal");
         if (this.inPortal) {
            MinecraftServer var1 = this.world.getMinecraftServer();
            if (var1.getAllowNether()) {
               if (!this.isRiding()) {
                  int var2 = this.getMaxInPortalTime();
                  if (this.portalCounter++ >= var2) {
                     this.portalCounter = var2;
                     this.timeUntilPortal = this.getPortalCooldown();
                     byte var3;
                     if (this.world.provider.getDimensionType().getId() == -1) {
                        var3 = 0;
                     } else {
                        var3 = -1;
                     }

                     this.changeDimension(var3);
                  }
               }

               this.inPortal = false;
            }
         } else {
            if (this.portalCounter > 0) {
               this.portalCounter -= 4;
            }

            if (this.portalCounter < 0) {
               this.portalCounter = 0;
            }
         }

         this.decrementTimeUntilPortal();
         this.world.theProfiler.endSection();
      }

      this.spawnRunningParticles();
      this.handleWaterMovement();
      if (this.world.isRemote) {
         this.extinguish();
      } else if (this.field_190534_ay > 0) {
         if (this.isImmuneToFire) {
            this.field_190534_ay -= 4;
            if (this.field_190534_ay < 0) {
               this.extinguish();
            }
         } else {
            if (this.field_190534_ay % 20 == 0) {
               this.attackEntityFrom(DamageSource.onFire, 1.0F);
            }

            --this.field_190534_ay;
         }
      }

      if (this.isInLava()) {
         this.setOnFireFromLava();
         this.fallDistance *= 0.5F;
      }

      if (this.posY < (double)-64.0F) {
         this.kill();
      }

      if (!this.world.isRemote) {
         this.setFlag(0, this.field_190534_ay > 0);
      }

      this.firstUpdate = false;
      this.world.theProfiler.endSection();
   }

   protected void decrementTimeUntilPortal() {
      if (this.timeUntilPortal > 0) {
         --this.timeUntilPortal;
      }

   }

   public int getMaxInPortalTime() {
      return 1;
   }

   protected void setOnFireFromLava() {
      if (!this.isImmuneToFire) {
         this.attackEntityFrom(DamageSource.lava, 4.0F);
         this.setFire(15);
      }

   }

   public void setFire(int var1) {
      int var2 = var1 * 20;
      if (this instanceof EntityLivingBase) {
         var2 = EnchantmentProtection.getFireTimeForEntity((EntityLivingBase)this, var2);
      }

      if (this.field_190534_ay < var2) {
         this.field_190534_ay = var2;
      }

   }

   public void extinguish() {
      this.field_190534_ay = 0;
   }

   protected void kill() {
      this.setDead();
   }

   public boolean isOffsetPositionInLiquid(double var1, double var3, double var5) {
      AxisAlignedBB var7 = this.getEntityBoundingBox().offset(var1, var3, var5);
      return this.isLiquidPresentInAABB(var7);
   }

   private boolean isLiquidPresentInAABB(AxisAlignedBB var1) {
      return this.world.getCollisionBoxes(this, var1).isEmpty() && !this.world.containsAnyLiquid(var1);
   }

   public void moveEntity(MoverType var1, double var2, double var4, double var6) {
      if (this.noClip) {
         this.setEntityBoundingBox(this.getEntityBoundingBox().offset(var2, var4, var6));
         this.resetPositionToBB();
      } else {
         if (var1 == MoverType.PISTON) {
            long var8 = this.world.getTotalWorldTime();
            if (var8 != this.field_191506_aJ) {
               Arrays.fill(this.field_191505_aI, (double)0.0F);
               this.field_191506_aJ = var8;
            }

            if (var2 != (double)0.0F) {
               int var10 = EnumFacing.Axis.X.ordinal();
               double var11 = MathHelper.clamp(var2 + this.field_191505_aI[var10], -0.51, 0.51);
               var2 = var11 - this.field_191505_aI[var10];
               this.field_191505_aI[var10] = var11;
               if (Math.abs(var2) <= (double)1.0E-5F) {
                  return;
               }
            } else if (var4 != (double)0.0F) {
               int var61 = EnumFacing.Axis.Y.ordinal();
               double var64 = MathHelper.clamp(var4 + this.field_191505_aI[var61], -0.51, 0.51);
               var4 = var64 - this.field_191505_aI[var61];
               this.field_191505_aI[var61] = var64;
               if (Math.abs(var4) <= (double)1.0E-5F) {
                  return;
               }
            } else {
               if (var6 == (double)0.0F) {
                  return;
               }

               int var62 = EnumFacing.Axis.Z.ordinal();
               double var65 = MathHelper.clamp(var6 + this.field_191505_aI[var62], -0.51, 0.51);
               var6 = var65 - this.field_191505_aI[var62];
               this.field_191505_aI[var62] = var65;
               if (Math.abs(var6) <= (double)1.0E-5F) {
                  return;
               }
            }
         }

         this.world.theProfiler.startSection("move");
         double var60 = this.posX;
         double var63 = this.posY;
         double var12 = this.posZ;
         if (this.isInWeb) {
            this.isInWeb = false;
            var2 *= (double)0.25F;
            var4 *= (double)0.05F;
            var6 *= (double)0.25F;
            this.motionX = (double)0.0F;
            this.motionY = (double)0.0F;
            this.motionZ = (double)0.0F;
         }

         double var14 = var2;
         double var16 = var4;
         double var18 = var6;
         if ((var1 == MoverType.SELF || var1 == MoverType.PLAYER) && this.onGround && this.isSneaking() && this instanceof EntityPlayer) {
            for(double var20 = 0.05; var2 != (double)0.0F && this.world.getCollisionBoxes(this, this.getEntityBoundingBox().offset(var2, (double)(-this.stepHeight), (double)0.0F)).isEmpty(); var14 = var2) {
               if (var2 < 0.05 && var2 >= -0.05) {
                  var2 = (double)0.0F;
               } else if (var2 > (double)0.0F) {
                  var2 -= 0.05;
               } else {
                  var2 += 0.05;
               }
            }

            for(; var6 != (double)0.0F && this.world.getCollisionBoxes(this, this.getEntityBoundingBox().offset((double)0.0F, (double)(-this.stepHeight), var6)).isEmpty(); var18 = var6) {
               if (var6 < 0.05 && var6 >= -0.05) {
                  var6 = (double)0.0F;
               } else if (var6 > (double)0.0F) {
                  var6 -= 0.05;
               } else {
                  var6 += 0.05;
               }
            }

            for(; var2 != (double)0.0F && var6 != (double)0.0F && this.world.getCollisionBoxes(this, this.getEntityBoundingBox().offset(var2, (double)(-this.stepHeight), var6)).isEmpty(); var18 = var6) {
               if (var2 < 0.05 && var2 >= -0.05) {
                  var2 = (double)0.0F;
               } else if (var2 > (double)0.0F) {
                  var2 -= 0.05;
               } else {
                  var2 += 0.05;
               }

               var14 = var2;
               if (var6 < 0.05 && var6 >= -0.05) {
                  var6 = (double)0.0F;
               } else if (var6 > (double)0.0F) {
                  var6 -= 0.05;
               } else {
                  var6 += 0.05;
               }
            }
         }

         List var66 = this.world.getCollisionBoxes(this, this.getEntityBoundingBox().addCoord(var2, var4, var6));
         AxisAlignedBB var21 = this.getEntityBoundingBox();
         if (var4 != (double)0.0F) {
            int var22 = 0;

            for(int var23 = var66.size(); var22 < var23; ++var22) {
               var4 = ((AxisAlignedBB)var66.get(var22)).calculateYOffset(this.getEntityBoundingBox(), var4);
            }

            this.setEntityBoundingBox(this.getEntityBoundingBox().offset((double)0.0F, var4, (double)0.0F));
         }

         if (var2 != (double)0.0F) {
            int var67 = 0;

            for(int var70 = var66.size(); var67 < var70; ++var67) {
               var2 = ((AxisAlignedBB)var66.get(var67)).calculateXOffset(this.getEntityBoundingBox(), var2);
            }

            if (var2 != (double)0.0F) {
               this.setEntityBoundingBox(this.getEntityBoundingBox().offset(var2, (double)0.0F, (double)0.0F));
            }
         }

         if (var6 != (double)0.0F) {
            int var68 = 0;

            for(int var71 = var66.size(); var68 < var71; ++var68) {
               var6 = ((AxisAlignedBB)var66.get(var68)).calculateZOffset(this.getEntityBoundingBox(), var6);
            }

            if (var6 != (double)0.0F) {
               this.setEntityBoundingBox(this.getEntityBoundingBox().offset((double)0.0F, (double)0.0F, var6));
            }
         }

         boolean var69 = this.onGround || var16 != var4 && var16 < (double)0.0F;
         if (this.stepHeight > 0.0F && var69 && (var14 != var2 || var18 != var6)) {
            double var72 = var2;
            double var25 = var4;
            double var27 = var6;
            AxisAlignedBB var29 = this.getEntityBoundingBox();
            this.setEntityBoundingBox(var21);
            var4 = (double)this.stepHeight;
            List var30 = this.world.getCollisionBoxes(this, this.getEntityBoundingBox().addCoord(var14, var4, var18));
            AxisAlignedBB var31 = this.getEntityBoundingBox();
            AxisAlignedBB var32 = var31.addCoord(var14, (double)0.0F, var18);
            double var33 = var4;
            int var35 = 0;

            for(int var36 = var30.size(); var35 < var36; ++var35) {
               var33 = ((AxisAlignedBB)var30.get(var35)).calculateYOffset(var32, var33);
            }

            var31 = var31.offset((double)0.0F, var33, (double)0.0F);
            double var89 = var14;
            int var38 = 0;

            for(int var39 = var30.size(); var38 < var39; ++var38) {
               var89 = ((AxisAlignedBB)var30.get(var38)).calculateXOffset(var31, var89);
            }

            var31 = var31.offset(var89, (double)0.0F, (double)0.0F);
            double var91 = var18;
            int var41 = 0;

            for(int var42 = var30.size(); var41 < var42; ++var41) {
               var91 = ((AxisAlignedBB)var30.get(var41)).calculateZOffset(var31, var91);
            }

            var31 = var31.offset((double)0.0F, (double)0.0F, var91);
            AxisAlignedBB var92 = this.getEntityBoundingBox();
            double var43 = var4;
            int var45 = 0;

            for(int var46 = var30.size(); var45 < var46; ++var45) {
               var43 = ((AxisAlignedBB)var30.get(var45)).calculateYOffset(var92, var43);
            }

            var92 = var92.offset((double)0.0F, var43, (double)0.0F);
            double var96 = var14;
            int var48 = 0;

            for(int var49 = var30.size(); var48 < var49; ++var48) {
               var96 = ((AxisAlignedBB)var30.get(var48)).calculateXOffset(var92, var96);
            }

            var92 = var92.offset(var96, (double)0.0F, (double)0.0F);
            double var97 = var18;
            int var51 = 0;

            for(int var52 = var30.size(); var51 < var52; ++var51) {
               var97 = ((AxisAlignedBB)var30.get(var51)).calculateZOffset(var92, var97);
            }

            var92 = var92.offset((double)0.0F, (double)0.0F, var97);
            double var98 = var89 * var89 + var91 * var91;
            double var54 = var96 * var96 + var97 * var97;
            if (var98 > var54) {
               var2 = var89;
               var6 = var91;
               var4 = -var33;
               this.setEntityBoundingBox(var31);
            } else {
               var2 = var96;
               var6 = var97;
               var4 = -var43;
               this.setEntityBoundingBox(var92);
            }

            int var56 = 0;

            for(int var57 = var30.size(); var56 < var57; ++var56) {
               var4 = ((AxisAlignedBB)var30.get(var56)).calculateYOffset(this.getEntityBoundingBox(), var4);
            }

            this.setEntityBoundingBox(this.getEntityBoundingBox().offset((double)0.0F, var4, (double)0.0F));
            if (var72 * var72 + var27 * var27 >= var2 * var2 + var6 * var6) {
               var2 = var72;
               var4 = var25;
               var6 = var27;
               this.setEntityBoundingBox(var29);
            }
         }

         this.world.theProfiler.endSection();
         this.world.theProfiler.startSection("rest");
         this.resetPositionToBB();
         this.isCollidedHorizontally = var14 != var2 || var18 != var6;
         this.isCollidedVertically = var16 != var4;
         this.onGround = this.isCollidedVertically && var16 < (double)0.0F;
         this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
         int var73 = MathHelper.floor(this.posX);
         int var24 = MathHelper.floor(this.posY - (double)0.2F);
         int var74 = MathHelper.floor(this.posZ);
         BlockPos var26 = new BlockPos(var73, var24, var74);
         IBlockState var75 = this.world.getBlockState(var26);
         if (var75.getMaterial() == Material.AIR) {
            BlockPos var28 = var26.down();
            IBlockState var77 = this.world.getBlockState(var28);
            Block var80 = var77.getBlock();
            if (var80 instanceof BlockFence || var80 instanceof BlockWall || var80 instanceof BlockFenceGate) {
               var75 = var77;
               var26 = var28;
            }
         }

         this.updateFallState(var4, this.onGround, var75, var26);
         if (var14 != var2) {
            this.motionX = (double)0.0F;
         }

         if (var18 != var6) {
            this.motionZ = (double)0.0F;
         }

         Block var76 = var75.getBlock();
         if (var16 != var4) {
            var76.onLanded(this.world, this);
         }

         if (this.canTriggerWalking() && (!this.onGround || !this.isSneaking() || !(this instanceof EntityPlayer)) && !this.isRiding()) {
            double var78 = this.posX - var60;
            double var85 = this.posY - var63;
            double var87 = this.posZ - var12;
            if (var76 != Blocks.LADDER) {
               var85 = (double)0.0F;
            }

            if (var76 != null && this.onGround) {
               var76.onEntityWalk(this.world, var26, this);
            }

            this.distanceWalkedModified = (float)((double)this.distanceWalkedModified + (double)MathHelper.sqrt(var78 * var78 + var87 * var87) * 0.6);
            this.distanceWalkedOnStepModified = (float)((double)this.distanceWalkedOnStepModified + (double)MathHelper.sqrt(var78 * var78 + var85 * var85 + var87 * var87) * 0.6);
            if (this.distanceWalkedOnStepModified > (float)this.nextStepDistance && var75.getMaterial() != Material.AIR) {
               this.nextStepDistance = (int)this.distanceWalkedOnStepModified + 1;
               if (!this.isInWater()) {
                  this.playStepSound(var26, var76);
               } else {
                  Entity var88 = this.isBeingRidden() && this.getControllingPassenger() != null ? this.getControllingPassenger() : this;
                  float var90 = var88 == this ? 0.35F : 0.4F;
                  float var37 = MathHelper.sqrt(var88.motionX * var88.motionX * (double)0.2F + var88.motionY * var88.motionY + var88.motionZ * var88.motionZ * (double)0.2F) * var90;
                  if (var37 > 1.0F) {
                     var37 = 1.0F;
                  }

                  this.playSound(this.getSwimSound(), var37, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
               }
            } else if (this.distanceWalkedOnStepModified > this.field_191959_ay && this.func_191957_ae() && var75.getMaterial() == Material.AIR) {
               this.field_191959_ay = this.func_191954_d(this.distanceWalkedOnStepModified);
            }
         }

         try {
            this.doBlockCollisions();
         } catch (Throwable var58) {
            CrashReport var81 = CrashReport.makeCrashReport(var58, "Checking entity block collision");
            CrashReportCategory var86 = var81.makeCategory("Entity being checked for collision");
            this.addEntityCrashInfo(var86);
            throw new ReportedException(var81);
         }

         boolean var79 = this.isWet();
         if (this.world.isFlammableWithin(this.getEntityBoundingBox().contract(0.001))) {
            this.dealFireDamage(1);
            if (!var79) {
               ++this.field_190534_ay;
               if (this.field_190534_ay == 0) {
                  this.setFire(8);
               }
            }
         } else if (this.field_190534_ay <= 0) {
            this.field_190534_ay = -this.func_190531_bD();
         }

         if (var79 && this.isBurning()) {
            this.playSound(SoundEvents.ENTITY_GENERIC_EXTINGUISH_FIRE, 0.7F, 1.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
            this.field_190534_ay = -this.func_190531_bD();
         }

         this.world.theProfiler.endSection();
      }

   }

   public void resetPositionToBB() {
      AxisAlignedBB var1 = this.getEntityBoundingBox();
      this.posX = (var1.minX + var1.maxX) / (double)2.0F;
      this.posY = var1.minY;
      this.posZ = (var1.minZ + var1.maxZ) / (double)2.0F;
   }

   protected SoundEvent getSwimSound() {
      return SoundEvents.ENTITY_GENERIC_SWIM;
   }

   protected SoundEvent getSplashSound() {
      return SoundEvents.ENTITY_GENERIC_SPLASH;
   }

   protected void doBlockCollisions() {
      AxisAlignedBB var1 = this.getEntityBoundingBox();
      BlockPos.PooledMutableBlockPos var2 = BlockPos.PooledMutableBlockPos.retain(var1.minX + 0.001, var1.minY + 0.001, var1.minZ + 0.001);
      BlockPos.PooledMutableBlockPos var3 = BlockPos.PooledMutableBlockPos.retain(var1.maxX - 0.001, var1.maxY - 0.001, var1.maxZ - 0.001);
      BlockPos.PooledMutableBlockPos var4 = BlockPos.PooledMutableBlockPos.retain();
      if (this.world.isAreaLoaded(var2, var3)) {
         for(int var5 = var2.getX(); var5 <= var3.getX(); ++var5) {
            for(int var6 = var2.getY(); var6 <= var3.getY(); ++var6) {
               for(int var7 = var2.getZ(); var7 <= var3.getZ(); ++var7) {
                  var4.setPos(var5, var6, var7);
                  IBlockState var8 = this.world.getBlockState(var4);

                  try {
                     var8.getBlock().onEntityCollidedWithBlock(this.world, var4, var8, this);
                     this.func_191955_a(var8);
                  } catch (Throwable var12) {
                     CrashReport var10 = CrashReport.makeCrashReport(var12, "Colliding entity with block");
                     CrashReportCategory var11 = var10.makeCategory("Block being collided with");
                     CrashReportCategory.addBlockInfo(var11, var4, var8);
                     throw new ReportedException(var10);
                  }
               }
            }
         }
      }

      var2.release();
      var3.release();
      var4.release();
   }

   protected void func_191955_a(IBlockState var1) {
   }

   protected void playStepSound(BlockPos var1, Block var2) {
      SoundType var3 = var2.getSoundType();
      if (this.world.getBlockState(var1.up()).getBlock() == Blocks.SNOW_LAYER) {
         var3 = Blocks.SNOW_LAYER.getSoundType();
         this.playSound(var3.getStepSound(), var3.getVolume() * 0.15F, var3.getPitch());
      } else if (!var2.getDefaultState().getMaterial().isLiquid()) {
         this.playSound(var3.getStepSound(), var3.getVolume() * 0.15F, var3.getPitch());
      }

   }

   protected float func_191954_d(float var1) {
      return 0.0F;
   }

   protected boolean func_191957_ae() {
      return false;
   }

   public void playSound(SoundEvent var1, float var2, float var3) {
      if (!this.isSilent()) {
         this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, var1, this.getSoundCategory(), var2, var3);
      }

   }

   public boolean isSilent() {
      return (Boolean)this.dataManager.get(SILENT);
   }

   public void setSilent(boolean var1) {
      this.dataManager.set(SILENT, var1);
   }

   public boolean hasNoGravity() {
      return (Boolean)this.dataManager.get(NO_GRAVITY);
   }

   public void setNoGravity(boolean var1) {
      this.dataManager.set(NO_GRAVITY, var1);
   }

   protected boolean canTriggerWalking() {
      return true;
   }

   protected void updateFallState(double var1, boolean var3, IBlockState var4, BlockPos var5) {
      if (var3) {
         if (this.fallDistance > 0.0F) {
            var4.getBlock().onFallenUpon(this.world, var5, this, this.fallDistance);
         }

         this.fallDistance = 0.0F;
      } else if (var1 < (double)0.0F) {
         this.fallDistance = (float)((double)this.fallDistance - var1);
      }

   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox() {
      return null;
   }

   protected void dealFireDamage(int var1) {
      if (!this.isImmuneToFire) {
         this.attackEntityFrom(DamageSource.inFire, (float)var1);
      }

   }

   public final boolean isImmuneToFire() {
      return this.isImmuneToFire;
   }

   public void fall(float var1, float var2) {
      if (this.isBeingRidden()) {
         for(Entity var4 : this.getPassengers()) {
            var4.fall(var1, var2);
         }
      }

   }

   public boolean isWet() {
      if (this.inWater) {
         return true;
      } else {
         BlockPos.PooledMutableBlockPos var1 = BlockPos.PooledMutableBlockPos.retain(this.posX, this.posY, this.posZ);
         if (!this.world.isRainingAt(var1) && !this.world.isRainingAt(var1.setPos(this.posX, this.posY + (double)this.height, this.posZ))) {
            var1.release();
            return false;
         } else {
            var1.release();
            return true;
         }
      }
   }

   public boolean isInWater() {
      return this.inWater;
   }

   public boolean func_191953_am() {
      return this.world.handleMaterialAcceleration(this.getEntityBoundingBox().expand((double)0.0F, (double)-20.0F, (double)0.0F).contract(0.001), Material.WATER, this);
   }

   public boolean handleWaterMovement() {
      if (this.getRidingEntity() instanceof EntityBoat) {
         this.inWater = false;
      } else if (this.world.handleMaterialAcceleration(this.getEntityBoundingBox().expand((double)0.0F, (double)-0.4F, (double)0.0F).contract(0.001), Material.WATER, this)) {
         if (!this.inWater && !this.firstUpdate) {
            this.resetHeight();
         }

         this.fallDistance = 0.0F;
         this.inWater = true;
         this.extinguish();
      } else {
         this.inWater = false;
      }

      return this.inWater;
   }

   protected void resetHeight() {
      Entity var1 = this.isBeingRidden() && this.getControllingPassenger() != null ? this.getControllingPassenger() : this;
      float var2 = var1 == this ? 0.2F : 0.9F;
      float var3 = MathHelper.sqrt(var1.motionX * var1.motionX * (double)0.2F + var1.motionY * var1.motionY + var1.motionZ * var1.motionZ * (double)0.2F) * var2;
      if (var3 > 1.0F) {
         var3 = 1.0F;
      }

      this.playSound(this.getSplashSound(), var3, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
      float var4 = (float)MathHelper.floor(this.getEntityBoundingBox().minY);

      for(int var5 = 0; (float)var5 < 1.0F + this.width * 20.0F; ++var5) {
         float var6 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
         float var7 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
         this.world.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX + (double)var6, (double)(var4 + 1.0F), this.posZ + (double)var7, this.motionX, this.motionY - (double)(this.rand.nextFloat() * 0.2F), this.motionZ);
      }

      for(int var8 = 0; (float)var8 < 1.0F + this.width * 20.0F; ++var8) {
         float var9 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
         float var10 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
         this.world.spawnParticle(EnumParticleTypes.WATER_SPLASH, this.posX + (double)var9, (double)(var4 + 1.0F), this.posZ + (double)var10, this.motionX, this.motionY, this.motionZ);
      }

   }

   public void spawnRunningParticles() {
      if (this.isSprinting() && !this.isInWater()) {
         this.createRunningParticles();
      }

   }

   protected void createRunningParticles() {
      int var1 = MathHelper.floor(this.posX);
      int var2 = MathHelper.floor(this.posY - (double)0.2F);
      int var3 = MathHelper.floor(this.posZ);
      BlockPos var4 = new BlockPos(var1, var2, var3);
      IBlockState var5 = this.world.getBlockState(var4);
      if (var5.getRenderType() != EnumBlockRenderType.INVISIBLE) {
         this.world.spawnParticle(EnumParticleTypes.BLOCK_CRACK, this.posX + ((double)this.rand.nextFloat() - (double)0.5F) * (double)this.width, this.getEntityBoundingBox().minY + 0.1, this.posZ + ((double)this.rand.nextFloat() - (double)0.5F) * (double)this.width, -this.motionX * (double)4.0F, (double)1.5F, -this.motionZ * (double)4.0F, Block.getStateId(var5));
      }

   }

   public boolean isInsideOfMaterial(Material var1) {
      if (this.getRidingEntity() instanceof EntityBoat) {
         return false;
      } else {
         double var2 = this.posY + (double)this.getEyeHeight();
         BlockPos var4 = new BlockPos(this.posX, var2, this.posZ);
         IBlockState var5 = this.world.getBlockState(var4);
         if (var5.getMaterial() == var1) {
            float var6 = BlockLiquid.getLiquidHeightPercent(var5.getBlock().getMetaFromState(var5)) - 0.11111111F;
            float var7 = (float)(var4.getY() + 1) - var6;
            boolean var8 = var2 < (double)var7;
            return !var8 && this instanceof EntityPlayer ? false : var8;
         } else {
            return false;
         }
      }
   }

   public boolean isInLava() {
      return this.world.isMaterialInBB(this.getEntityBoundingBox().expand((double)-0.1F, (double)-0.4F, (double)-0.1F), Material.LAVA);
   }

   public void func_191958_b(float var1, float var2, float var3, float var4) {
      float var5 = var1 * var1 + var2 * var2 + var3 * var3;
      if (var5 >= 1.0E-4F) {
         var5 = MathHelper.sqrt(var5);
         if (var5 < 1.0F) {
            var5 = 1.0F;
         }

         var5 = var4 / var5;
         var1 *= var5;
         var2 *= var5;
         var3 *= var5;
         float var6 = MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180F));
         float var7 = MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180F));
         this.motionX += (double)(var1 * var7 - var3 * var6);
         this.motionY += (double)var2;
         this.motionZ += (double)(var3 * var7 + var1 * var6);
      }

   }

   public int getBrightnessForRender() {
      BlockPos.MutableBlockPos var1 = new BlockPos.MutableBlockPos(MathHelper.floor(this.posX), 0, MathHelper.floor(this.posZ));
      if (this.world.isBlockLoaded(var1)) {
         var1.setY(MathHelper.floor(this.posY + (double)this.getEyeHeight()));
         return this.world.getCombinedLight(var1, 0);
      } else {
         return 0;
      }
   }

   public float getBrightness() {
      BlockPos.MutableBlockPos var1 = new BlockPos.MutableBlockPos(MathHelper.floor(this.posX), 0, MathHelper.floor(this.posZ));
      if (this.world.isBlockLoaded(var1)) {
         var1.setY(MathHelper.floor(this.posY + (double)this.getEyeHeight()));
         return this.world.getLightBrightness(var1);
      } else {
         return 0.0F;
      }
   }

   public void setWorld(World var1) {
      this.world = var1;
   }

   public void setPositionAndRotation(double var1, double var3, double var5, float var7, float var8) {
      this.posX = MathHelper.clamp(var1, (double)-3.0E7F, (double)3.0E7F);
      this.posY = var3;
      this.posZ = MathHelper.clamp(var5, (double)-3.0E7F, (double)3.0E7F);
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      var8 = MathHelper.clamp(var8, -90.0F, 90.0F);
      this.rotationYaw = var7;
      this.rotationPitch = var8;
      this.prevRotationYaw = this.rotationYaw;
      this.prevRotationPitch = this.rotationPitch;
      double var9 = (double)(this.prevRotationYaw - var7);
      if (var9 < (double)-180.0F) {
         this.prevRotationYaw += 360.0F;
      }

      if (var9 >= (double)180.0F) {
         this.prevRotationYaw -= 360.0F;
      }

      this.setPosition(this.posX, this.posY, this.posZ);
      this.setRotation(var7, var8);
   }

   public void moveToBlockPosAndAngles(BlockPos var1, float var2, float var3) {
      this.setLocationAndAngles((double)var1.getX() + (double)0.5F, (double)var1.getY(), (double)var1.getZ() + (double)0.5F, var2, var3);
   }

   public void setLocationAndAngles(double var1, double var3, double var5, float var7, float var8) {
      this.posX = var1;
      this.posY = var3;
      this.posZ = var5;
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      this.lastTickPosX = this.posX;
      this.lastTickPosY = this.posY;
      this.lastTickPosZ = this.posZ;
      this.rotationYaw = var7;
      this.rotationPitch = var8;
      this.setPosition(this.posX, this.posY, this.posZ);
   }

   public float getDistanceToEntity(Entity var1) {
      float var2 = (float)(this.posX - var1.posX);
      float var3 = (float)(this.posY - var1.posY);
      float var4 = (float)(this.posZ - var1.posZ);
      return MathHelper.sqrt(var2 * var2 + var3 * var3 + var4 * var4);
   }

   public double getDistanceSq(double var1, double var3, double var5) {
      double var7 = this.posX - var1;
      double var9 = this.posY - var3;
      double var11 = this.posZ - var5;
      return var7 * var7 + var9 * var9 + var11 * var11;
   }

   public double getDistanceSq(BlockPos var1) {
      return var1.distanceSq(this.posX, this.posY, this.posZ);
   }

   public double getDistanceSqToCenter(BlockPos var1) {
      return var1.distanceSqToCenter(this.posX, this.posY, this.posZ);
   }

   public double getDistance(double var1, double var3, double var5) {
      double var7 = this.posX - var1;
      double var9 = this.posY - var3;
      double var11 = this.posZ - var5;
      return (double)MathHelper.sqrt(var7 * var7 + var9 * var9 + var11 * var11);
   }

   public double getDistanceSqToEntity(Entity var1) {
      double var2 = this.posX - var1.posX;
      double var4 = this.posY - var1.posY;
      double var6 = this.posZ - var1.posZ;
      return var2 * var2 + var4 * var4 + var6 * var6;
   }

   public void onCollideWithPlayer(EntityPlayer var1) {
   }

   public void applyEntityCollision(Entity var1) {
      if (!this.isRidingSameEntity(var1) && !var1.noClip && !this.noClip) {
         double var2 = var1.posX - this.posX;
         double var4 = var1.posZ - this.posZ;
         double var6 = MathHelper.absMax(var2, var4);
         if (var6 >= (double)0.01F) {
            var6 = (double)MathHelper.sqrt(var6);
            var2 /= var6;
            var4 /= var6;
            double var8 = (double)1.0F / var6;
            if (var8 > (double)1.0F) {
               var8 = (double)1.0F;
            }

            var2 *= var8;
            var4 *= var8;
            var2 *= (double)0.05F;
            var4 *= (double)0.05F;
            var2 *= (double)(1.0F - this.entityCollisionReduction);
            var4 *= (double)(1.0F - this.entityCollisionReduction);
            if (!this.isBeingRidden()) {
               this.addVelocity(-var2, (double)0.0F, -var4);
            }

            if (!var1.isBeingRidden()) {
               var1.addVelocity(var2, (double)0.0F, var4);
            }
         }
      }

   }

   public void addVelocity(double var1, double var3, double var5) {
      this.motionX += var1;
      this.motionY += var3;
      this.motionZ += var5;
      this.isAirBorne = true;
   }

   protected void setBeenAttacked() {
      this.velocityChanged = true;
   }

   public boolean attackEntityFrom(DamageSource var1, float var2) {
      if (this.isEntityInvulnerable(var1)) {
         return false;
      } else {
         this.setBeenAttacked();
         return false;
      }
   }

   public Vec3d getLook(float var1) {
      if (var1 == 1.0F) {
         return this.getVectorForRotation(this.rotationPitch, this.rotationYaw);
      } else {
         float var2 = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * var1;
         float var3 = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * var1;
         return this.getVectorForRotation(var2, var3);
      }
   }

   protected final Vec3d getVectorForRotation(float var1, float var2) {
      float var3 = MathHelper.cos(-var2 * ((float)Math.PI / 180F) - (float)Math.PI);
      float var4 = MathHelper.sin(-var2 * ((float)Math.PI / 180F) - (float)Math.PI);
      float var5 = -MathHelper.cos(-var1 * ((float)Math.PI / 180F));
      float var6 = MathHelper.sin(-var1 * ((float)Math.PI / 180F));
      return new Vec3d((double)(var4 * var5), (double)var6, (double)(var3 * var5));
   }

   public Vec3d getPositionEyes(float var1) {
      if (var1 == 1.0F) {
         return new Vec3d(this.posX, this.posY + (double)this.getEyeHeight(), this.posZ);
      } else {
         double var2 = this.prevPosX + (this.posX - this.prevPosX) * (double)var1;
         double var4 = this.prevPosY + (this.posY - this.prevPosY) * (double)var1 + (double)this.getEyeHeight();
         double var6 = this.prevPosZ + (this.posZ - this.prevPosZ) * (double)var1;
         return new Vec3d(var2, var4, var6);
      }
   }

   @Nullable
   public RayTraceResult rayTrace(double var1, float var3) {
      Vec3d var4 = this.getPositionEyes(var3);
      Vec3d var5 = this.getLook(var3);
      Vec3d var6 = var4.addVector(var5.xCoord * var1, var5.yCoord * var1, var5.zCoord * var1);
      return this.world.rayTraceBlocks(var4, var6, false, false, true);
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   public boolean canBePushed() {
      return false;
   }

   public void func_191956_a(Entity var1, int var2, DamageSource var3) {
      if (var1 instanceof EntityPlayerMP) {
         CriteriaTriggers.field_192123_c.func_192211_a((EntityPlayerMP)var1, this, var3);
      }

   }

   public boolean isInRangeToRender3d(double var1, double var3, double var5) {
      double var7 = this.posX - var1;
      double var9 = this.posY - var3;
      double var11 = this.posZ - var5;
      double var13 = var7 * var7 + var9 * var9 + var11 * var11;
      return this.isInRangeToRenderDist(var13);
   }

   public boolean isInRangeToRenderDist(double var1) {
      double var3 = this.getEntityBoundingBox().getAverageEdgeLength();
      if (Double.isNaN(var3)) {
         var3 = (double)1.0F;
      }

      var3 = var3 * (double)64.0F * renderDistanceWeight;
      return var1 < var3 * var3;
   }

   public boolean writeToNBTAtomically(NBTTagCompound var1) {
      String var2 = this.getEntityString();
      if (!this.isDead && var2 != null) {
         var1.setString("id", var2);
         this.writeToNBT(var1);
         return true;
      } else {
         return false;
      }
   }

   public boolean writeToNBTOptional(NBTTagCompound var1) {
      String var2 = this.getEntityString();
      if (!this.isDead && var2 != null && !this.isRiding()) {
         var1.setString("id", var2);
         this.writeToNBT(var1);
         return true;
      } else {
         return false;
      }
   }

   public static void func_190533_a(DataFixer var0) {
      var0.registerWalker(FixTypes.ENTITY, new IDataWalker() {
         public NBTTagCompound process(IDataFixer var1, NBTTagCompound var2, int var3) {
            if (var2.hasKey("Passengers", 9)) {
               NBTTagList var4 = var2.getTagList("Passengers", 10);

               for(int var5 = 0; var5 < var4.tagCount(); ++var5) {
                  var4.set(var5, var1.process(FixTypes.ENTITY, var4.getCompoundTagAt(var5), var3));
               }
            }

            return var2;
         }
      });
   }

   public NBTTagCompound writeToNBT(NBTTagCompound var1) {
      try {
         var1.setTag("Pos", this.newDoubleNBTList(this.posX, this.posY, this.posZ));
         var1.setTag("Motion", this.newDoubleNBTList(this.motionX, this.motionY, this.motionZ));
         var1.setTag("Rotation", this.newFloatNBTList(this.rotationYaw, this.rotationPitch));
         var1.setFloat("FallDistance", this.fallDistance);
         var1.setShort("Fire", (short)this.field_190534_ay);
         var1.setShort("Air", (short)this.getAir());
         var1.setBoolean("OnGround", this.onGround);
         var1.setInteger("Dimension", this.dimension);
         var1.setBoolean("Invulnerable", this.invulnerable);
         var1.setInteger("PortalCooldown", this.timeUntilPortal);
         var1.setUniqueId("UUID", this.getUniqueID());
         if (this.hasCustomName()) {
            var1.setString("CustomName", this.getCustomNameTag());
         }

         if (this.getAlwaysRenderNameTag()) {
            var1.setBoolean("CustomNameVisible", this.getAlwaysRenderNameTag());
         }

         this.cmdResultStats.writeStatsToNBT(var1);
         if (this.isSilent()) {
            var1.setBoolean("Silent", this.isSilent());
         }

         if (this.hasNoGravity()) {
            var1.setBoolean("NoGravity", this.hasNoGravity());
         }

         if (this.glowing) {
            var1.setBoolean("Glowing", this.glowing);
         }

         if (!this.tags.isEmpty()) {
            NBTTagList var2 = new NBTTagList();

            for(String var10 : this.tags) {
               var2.appendTag(new NBTTagString(var10));
            }

            var1.setTag("Tags", var2);
         }

         this.writeEntityToNBT(var1);
         if (this.isBeingRidden()) {
            NBTTagList var7 = new NBTTagList();

            for(Entity var11 : this.getPassengers()) {
               NBTTagCompound var5 = new NBTTagCompound();
               if (var11.writeToNBTAtomically(var5)) {
                  var7.appendTag(var5);
               }
            }

            if (!var7.hasNoTags()) {
               var1.setTag("Passengers", var7);
            }
         }

         return var1;
      } catch (Throwable var6) {
         CrashReport var3 = CrashReport.makeCrashReport(var6, "Saving entity NBT");
         CrashReportCategory var4 = var3.makeCategory("Entity being saved");
         this.addEntityCrashInfo(var4);
         throw new ReportedException(var3);
      }
   }

   public void readFromNBT(NBTTagCompound var1) {
      try {
         NBTTagList var2 = var1.getTagList("Pos", 6);
         NBTTagList var9 = var1.getTagList("Motion", 6);
         NBTTagList var10 = var1.getTagList("Rotation", 5);
         this.motionX = var9.getDoubleAt(0);
         this.motionY = var9.getDoubleAt(1);
         this.motionZ = var9.getDoubleAt(2);
         if (Math.abs(this.motionX) > (double)10.0F) {
            this.motionX = (double)0.0F;
         }

         if (Math.abs(this.motionY) > (double)10.0F) {
            this.motionY = (double)0.0F;
         }

         if (Math.abs(this.motionZ) > (double)10.0F) {
            this.motionZ = (double)0.0F;
         }

         this.posX = var2.getDoubleAt(0);
         this.posY = var2.getDoubleAt(1);
         this.posZ = var2.getDoubleAt(2);
         this.lastTickPosX = this.posX;
         this.lastTickPosY = this.posY;
         this.lastTickPosZ = this.posZ;
         this.prevPosX = this.posX;
         this.prevPosY = this.posY;
         this.prevPosZ = this.posZ;
         this.rotationYaw = var10.getFloatAt(0);
         this.rotationPitch = var10.getFloatAt(1);
         this.prevRotationYaw = this.rotationYaw;
         this.prevRotationPitch = this.rotationPitch;
         this.setRotationYawHead(this.rotationYaw);
         this.setRenderYawOffset(this.rotationYaw);
         this.fallDistance = var1.getFloat("FallDistance");
         this.field_190534_ay = var1.getShort("Fire");
         this.setAir(var1.getShort("Air"));
         this.onGround = var1.getBoolean("OnGround");
         if (var1.hasKey("Dimension")) {
            this.dimension = var1.getInteger("Dimension");
         }

         this.invulnerable = var1.getBoolean("Invulnerable");
         this.timeUntilPortal = var1.getInteger("PortalCooldown");
         if (var1.hasUniqueId("UUID")) {
            this.entityUniqueID = var1.getUniqueId("UUID");
            this.cachedUniqueIdString = this.entityUniqueID.toString();
         }

         this.setPosition(this.posX, this.posY, this.posZ);
         this.setRotation(this.rotationYaw, this.rotationPitch);
         if (var1.hasKey("CustomName", 8)) {
            this.setCustomNameTag(var1.getString("CustomName"));
         }

         this.setAlwaysRenderNameTag(var1.getBoolean("CustomNameVisible"));
         this.cmdResultStats.readStatsFromNBT(var1);
         this.setSilent(var1.getBoolean("Silent"));
         this.setNoGravity(var1.getBoolean("NoGravity"));
         this.setGlowing(var1.getBoolean("Glowing"));
         if (var1.hasKey("Tags", 9)) {
            this.tags.clear();
            NBTTagList var5 = var1.getTagList("Tags", 8);
            int var6 = Math.min(var5.tagCount(), 1024);

            for(int var7 = 0; var7 < var6; ++var7) {
               this.tags.add(var5.getStringTagAt(var7));
            }
         }

         this.readEntityFromNBT(var1);
         if (this.shouldSetPosAfterLoading()) {
            this.setPosition(this.posX, this.posY, this.posZ);
         }

      } catch (Throwable var8) {
         CrashReport var3 = CrashReport.makeCrashReport(var8, "Loading entity NBT");
         CrashReportCategory var4 = var3.makeCategory("Entity being loaded");
         this.addEntityCrashInfo(var4);
         throw new ReportedException(var3);
      }
   }

   protected boolean shouldSetPosAfterLoading() {
      return true;
   }

   @Nullable
   protected final String getEntityString() {
      ResourceLocation var1 = EntityList.func_191301_a(this);
      return var1 == null ? null : var1.toString();
   }

   protected abstract void readEntityFromNBT(NBTTagCompound var1);

   protected abstract void writeEntityToNBT(NBTTagCompound var1);

   protected NBTTagList newDoubleNBTList(double... var1) {
      NBTTagList var2 = new NBTTagList();

      for(double var6 : var1) {
         var2.appendTag(new NBTTagDouble(var6));
      }

      return var2;
   }

   protected NBTTagList newFloatNBTList(float... var1) {
      NBTTagList var2 = new NBTTagList();

      for(float var6 : var1) {
         var2.appendTag(new NBTTagFloat(var6));
      }

      return var2;
   }

   @Nullable
   public EntityItem dropItem(Item var1, int var2) {
      return this.dropItemWithOffset(var1, var2, 0.0F);
   }

   @Nullable
   public EntityItem dropItemWithOffset(Item var1, int var2, float var3) {
      return this.entityDropItem(new ItemStack(var1, var2, 0), var3);
   }

   @Nullable
   public EntityItem entityDropItem(ItemStack var1, float var2) {
      if (var1.func_190926_b()) {
         return null;
      } else {
         EntityItem var3 = new EntityItem(this.world, this.posX, this.posY + (double)var2, this.posZ, var1);
         var3.setDefaultPickupDelay();
         this.world.spawnEntityInWorld(var3);
         return var3;
      }
   }

   public boolean isEntityAlive() {
      return !this.isDead;
   }

   public boolean isEntityInsideOpaqueBlock() {
      if (this.noClip) {
         return false;
      } else {
         BlockPos.PooledMutableBlockPos var1 = BlockPos.PooledMutableBlockPos.retain();

         for(int var2 = 0; var2 < 8; ++var2) {
            int var3 = MathHelper.floor(this.posY + (double)(((float)((var2 >> 0) % 2) - 0.5F) * 0.1F) + (double)this.getEyeHeight());
            int var4 = MathHelper.floor(this.posX + (double)(((float)((var2 >> 1) % 2) - 0.5F) * this.width * 0.8F));
            int var5 = MathHelper.floor(this.posZ + (double)(((float)((var2 >> 2) % 2) - 0.5F) * this.width * 0.8F));
            if (var1.getX() != var4 || var1.getY() != var3 || var1.getZ() != var5) {
               var1.setPos(var4, var3, var5);
               if (this.world.getBlockState(var1).func_191058_s()) {
                  var1.release();
                  return true;
               }
            }
         }

         var1.release();
         return false;
      }
   }

   public boolean processInitialInteract(EntityPlayer var1, EnumHand var2) {
      return false;
   }

   @Nullable
   public AxisAlignedBB getCollisionBox(Entity var1) {
      return null;
   }

   public void updateRidden() {
      Entity var1 = this.getRidingEntity();
      if (this.isRiding() && var1.isDead) {
         this.dismountRidingEntity();
      } else {
         this.motionX = (double)0.0F;
         this.motionY = (double)0.0F;
         this.motionZ = (double)0.0F;
         this.onUpdate();
         if (this.isRiding()) {
            var1.updatePassenger(this);
         }
      }

   }

   public void updatePassenger(Entity var1) {
      if (this.isPassenger(var1)) {
         var1.setPosition(this.posX, this.posY + this.getMountedYOffset() + var1.getYOffset(), this.posZ);
      }

   }

   public void applyOrientationToEntity(Entity var1) {
   }

   public double getYOffset() {
      return (double)0.0F;
   }

   public double getMountedYOffset() {
      return (double)this.height * (double)0.75F;
   }

   public boolean startRiding(Entity var1) {
      return this.startRiding(var1, false);
   }

   public boolean startRiding(Entity var1, boolean var2) {
      for(Entity var3 = var1; var3.ridingEntity != null; var3 = var3.ridingEntity) {
         if (var3.ridingEntity == this) {
            return false;
         }
      }

      if (var2 || this.canBeRidden(var1) && var1.canFitPassenger(this)) {
         if (this.isRiding()) {
            this.dismountRidingEntity();
         }

         this.ridingEntity = var1;
         this.ridingEntity.addPassenger(this);
         return true;
      } else {
         return false;
      }
   }

   protected boolean canBeRidden(Entity var1) {
      return this.rideCooldown <= 0;
   }

   public void removePassengers() {
      for(int var1 = this.riddenByEntities.size() - 1; var1 >= 0; --var1) {
         ((Entity)this.riddenByEntities.get(var1)).dismountRidingEntity();
      }

   }

   public void dismountRidingEntity() {
      if (this.ridingEntity != null) {
         Entity var1 = this.ridingEntity;
         this.ridingEntity = null;
         var1.removePassenger(this);
      }

   }

   protected void addPassenger(Entity var1) {
      if (var1.getRidingEntity() != this) {
         throw new IllegalStateException("Use x.startRiding(y), not y.addPassenger(x)");
      } else {
         if (!this.world.isRemote && var1 instanceof EntityPlayer && !(this.getControllingPassenger() instanceof EntityPlayer)) {
            this.riddenByEntities.add(0, var1);
         } else {
            this.riddenByEntities.add(var1);
         }

      }
   }

   protected void removePassenger(Entity var1) {
      if (var1.getRidingEntity() == this) {
         throw new IllegalStateException("Use x.stopRiding(y), not y.removePassenger(x)");
      } else {
         this.riddenByEntities.remove(var1);
         var1.rideCooldown = 60;
      }
   }

   protected boolean canFitPassenger(Entity var1) {
      return this.getPassengers().size() < 1;
   }

   public void setPositionAndRotationDirect(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
      this.setPosition(var1, var3, var5);
      this.setRotation(var7, var8);
   }

   public float getCollisionBorderSize() {
      return 0.0F;
   }

   public Vec3d getLookVec() {
      return this.getVectorForRotation(this.rotationPitch, this.rotationYaw);
   }

   public Vec2f getPitchYaw() {
      return new Vec2f(this.rotationPitch, this.rotationYaw);
   }

   public Vec3d getForward() {
      return Vec3d.fromPitchYawVector(this.getPitchYaw());
   }

   public void setPortal(BlockPos var1) {
      if (this.timeUntilPortal > 0) {
         this.timeUntilPortal = this.getPortalCooldown();
      } else {
         if (!this.world.isRemote && !var1.equals(this.lastPortalPos)) {
            this.lastPortalPos = new BlockPos(var1);
            BlockPattern.PatternHelper var2 = Blocks.PORTAL.createPatternHelper(this.world, this.lastPortalPos);
            double var3 = var2.getForwards().getAxis() == EnumFacing.Axis.X ? (double)var2.getFrontTopLeft().getZ() : (double)var2.getFrontTopLeft().getX();
            double var5 = var2.getForwards().getAxis() == EnumFacing.Axis.X ? this.posZ : this.posX;
            var5 = Math.abs(MathHelper.pct(var5 - (double)(var2.getForwards().rotateY().getAxisDirection() == EnumFacing.AxisDirection.NEGATIVE ? 1 : 0), var3, var3 - (double)var2.getWidth()));
            double var7 = MathHelper.pct(this.posY - (double)1.0F, (double)var2.getFrontTopLeft().getY(), (double)(var2.getFrontTopLeft().getY() - var2.getHeight()));
            this.lastPortalVec = new Vec3d(var5, var7, (double)0.0F);
            this.teleportDirection = var2.getForwards();
         }

         this.inPortal = true;
      }

   }

   public int getPortalCooldown() {
      return 300;
   }

   public void setVelocity(double var1, double var3, double var5) {
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
   }

   public void handleStatusUpdate(byte var1) {
   }

   public void performHurtAnimation() {
   }

   public Iterable<ItemStack> getHeldEquipment() {
      return field_190535_b;
   }

   public Iterable<ItemStack> getArmorInventoryList() {
      return field_190535_b;
   }

   public Iterable<ItemStack> getEquipmentAndArmor() {
      return Iterables.concat(this.getHeldEquipment(), this.getArmorInventoryList());
   }

   public void setItemStackToSlot(EntityEquipmentSlot var1, ItemStack var2) {
   }

   public boolean isBurning() {
      boolean var1 = this.world != null && this.world.isRemote;
      return !this.isImmuneToFire && (this.field_190534_ay > 0 || var1 && this.getFlag(0));
   }

   public boolean isRiding() {
      return this.getRidingEntity() != null;
   }

   public boolean isBeingRidden() {
      return !this.getPassengers().isEmpty();
   }

   public boolean isSneaking() {
      return this.getFlag(1);
   }

   public void setSneaking(boolean var1) {
      this.setFlag(1, var1);
   }

   public boolean isSprinting() {
      return this.getFlag(3);
   }

   public void setSprinting(boolean var1) {
      this.setFlag(3, var1);
   }

   public boolean isGlowing() {
      return this.glowing || this.world.isRemote && this.getFlag(6);
   }

   public void setGlowing(boolean var1) {
      this.glowing = var1;
      if (!this.world.isRemote) {
         this.setFlag(6, this.glowing);
      }

   }

   public boolean isInvisible() {
      return this.getFlag(5);
   }

   public boolean isInvisibleToPlayer(EntityPlayer var1) {
      if (var1.isSpectator()) {
         return false;
      } else {
         Team var2 = this.getTeam();
         return var2 != null && var1 != null && var1.getTeam() == var2 && var2.getSeeFriendlyInvisiblesEnabled() ? false : this.isInvisible();
      }
   }

   @Nullable
   public Team getTeam() {
      return this.world.getScoreboard().getPlayersTeam(this.getCachedUniqueIdString());
   }

   public boolean isOnSameTeam(Entity var1) {
      return this.isOnScoreboardTeam(var1.getTeam());
   }

   public boolean isOnScoreboardTeam(Team var1) {
      return this.getTeam() != null ? this.getTeam().isSameTeam(var1) : false;
   }

   public void setInvisible(boolean var1) {
      this.setFlag(5, var1);
   }

   protected boolean getFlag(int var1) {
      return ((Byte)this.dataManager.get(FLAGS) & 1 << var1) != 0;
   }

   protected void setFlag(int var1, boolean var2) {
      byte var3 = (Byte)this.dataManager.get(FLAGS);
      if (var2) {
         this.dataManager.set(FLAGS, (byte)(var3 | 1 << var1));
      } else {
         this.dataManager.set(FLAGS, (byte)(var3 & ~(1 << var1)));
      }

   }

   public int getAir() {
      return (Integer)this.dataManager.get(AIR);
   }

   public void setAir(int var1) {
      this.dataManager.set(AIR, var1);
   }

   public void onStruckByLightning(EntityLightningBolt var1) {
      this.attackEntityFrom(DamageSource.lightningBolt, 5.0F);
      ++this.field_190534_ay;
      if (this.field_190534_ay == 0) {
         this.setFire(8);
      }

   }

   public void onKillEntity(EntityLivingBase var1) {
   }

   protected boolean pushOutOfBlocks(double var1, double var3, double var5) {
      BlockPos var7 = new BlockPos(var1, var3, var5);
      double var8 = var1 - (double)var7.getX();
      double var10 = var3 - (double)var7.getY();
      double var12 = var5 - (double)var7.getZ();
      if (!this.world.collidesWithAnyBlock(this.getEntityBoundingBox())) {
         return false;
      } else {
         EnumFacing var14 = EnumFacing.UP;
         double var15 = Double.MAX_VALUE;
         if (!this.world.isBlockFullCube(var7.west()) && var8 < var15) {
            var15 = var8;
            var14 = EnumFacing.WEST;
         }

         if (!this.world.isBlockFullCube(var7.east()) && (double)1.0F - var8 < var15) {
            var15 = (double)1.0F - var8;
            var14 = EnumFacing.EAST;
         }

         if (!this.world.isBlockFullCube(var7.north()) && var12 < var15) {
            var15 = var12;
            var14 = EnumFacing.NORTH;
         }

         if (!this.world.isBlockFullCube(var7.south()) && (double)1.0F - var12 < var15) {
            var15 = (double)1.0F - var12;
            var14 = EnumFacing.SOUTH;
         }

         if (!this.world.isBlockFullCube(var7.up()) && (double)1.0F - var10 < var15) {
            var15 = (double)1.0F - var10;
            var14 = EnumFacing.UP;
         }

         float var17 = this.rand.nextFloat() * 0.2F + 0.1F;
         float var18 = (float)var14.getAxisDirection().getOffset();
         if (var14.getAxis() == EnumFacing.Axis.X) {
            this.motionX = (double)(var18 * var17);
            this.motionY *= (double)0.75F;
            this.motionZ *= (double)0.75F;
         } else if (var14.getAxis() == EnumFacing.Axis.Y) {
            this.motionX *= (double)0.75F;
            this.motionY = (double)(var18 * var17);
            this.motionZ *= (double)0.75F;
         } else if (var14.getAxis() == EnumFacing.Axis.Z) {
            this.motionX *= (double)0.75F;
            this.motionY *= (double)0.75F;
            this.motionZ = (double)(var18 * var17);
         }

         return true;
      }
   }

   public void setInWeb() {
      this.isInWeb = true;
      this.fallDistance = 0.0F;
   }

   public String getName() {
      if (this.hasCustomName()) {
         return this.getCustomNameTag();
      } else {
         String var1 = EntityList.getEntityString(this);
         if (var1 == null) {
            var1 = "generic";
         }

         return I18n.translateToLocal("entity." + var1 + ".name");
      }
   }

   @Nullable
   public Entity[] getParts() {
      return null;
   }

   public boolean isEntityEqual(Entity var1) {
      return this == var1;
   }

   public float getRotationYawHead() {
      return 0.0F;
   }

   public void setRotationYawHead(float var1) {
   }

   public void setRenderYawOffset(float var1) {
   }

   public boolean canBeAttackedWithItem() {
      return true;
   }

   public boolean hitByEntity(Entity var1) {
      return false;
   }

   public String toString() {
      return String.format("%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f]", this.getClass().getSimpleName(), this.getName(), this.entityId, this.world == null ? "~NULL~" : this.world.getWorldInfo().getWorldName(), this.posX, this.posY, this.posZ);
   }

   public boolean isEntityInvulnerable(DamageSource var1) {
      return this.invulnerable && var1 != DamageSource.outOfWorld && !var1.isCreativePlayer();
   }

   public boolean func_190530_aW() {
      return this.invulnerable;
   }

   public void setEntityInvulnerable(boolean var1) {
      this.invulnerable = var1;
   }

   public void copyLocationAndAnglesFrom(Entity var1) {
      this.setLocationAndAngles(var1.posX, var1.posY, var1.posZ, var1.rotationYaw, var1.rotationPitch);
   }

   private void copyDataFromOld(Entity var1) {
      NBTTagCompound var2 = var1.writeToNBT(new NBTTagCompound());
      var2.removeTag("Dimension");
      this.readFromNBT(var2);
      this.timeUntilPortal = var1.timeUntilPortal;
      this.lastPortalPos = var1.lastPortalPos;
      this.lastPortalVec = var1.lastPortalVec;
      this.teleportDirection = var1.teleportDirection;
   }

   @Nullable
   public Entity changeDimension(int var1) {
      if (!this.world.isRemote && !this.isDead) {
         this.world.theProfiler.startSection("changeDimension");
         MinecraftServer var2 = this.getServer();
         int var3 = this.dimension;
         WorldServer var4 = var2.worldServerForDimension(var3);
         WorldServer var5 = var2.worldServerForDimension(var1);
         this.dimension = var1;
         if (var3 == 1 && var1 == 1) {
            var5 = var2.worldServerForDimension(0);
            this.dimension = 0;
         }

         this.world.removeEntity(this);
         this.isDead = false;
         this.world.theProfiler.startSection("reposition");
         BlockPos var6;
         if (var1 == 1) {
            var6 = var5.getSpawnCoordinate();
         } else {
            double var7 = this.posX;
            double var9 = this.posZ;
            double var11 = (double)8.0F;
            if (var1 == -1) {
               var7 = MathHelper.clamp(var7 / (double)8.0F, var5.getWorldBorder().minX() + (double)16.0F, var5.getWorldBorder().maxX() - (double)16.0F);
               var9 = MathHelper.clamp(var9 / (double)8.0F, var5.getWorldBorder().minZ() + (double)16.0F, var5.getWorldBorder().maxZ() - (double)16.0F);
            } else if (var1 == 0) {
               var7 = MathHelper.clamp(var7 * (double)8.0F, var5.getWorldBorder().minX() + (double)16.0F, var5.getWorldBorder().maxX() - (double)16.0F);
               var9 = MathHelper.clamp(var9 * (double)8.0F, var5.getWorldBorder().minZ() + (double)16.0F, var5.getWorldBorder().maxZ() - (double)16.0F);
            }

            var7 = (double)MathHelper.clamp((int)var7, -29999872, 29999872);
            var9 = (double)MathHelper.clamp((int)var9, -29999872, 29999872);
            float var13 = this.rotationYaw;
            this.setLocationAndAngles(var7, this.posY, var9, 90.0F, 0.0F);
            Teleporter var14 = var5.getDefaultTeleporter();
            var14.placeInExistingPortal(this, var13);
            var6 = new BlockPos(this);
         }

         var4.updateEntityWithOptionalForce(this, false);
         this.world.theProfiler.endStartSection("reloading");
         Entity var16 = EntityList.func_191304_a(this.getClass(), var5);
         if (var16 != null) {
            var16.copyDataFromOld(this);
            if (var3 == 1 && var1 == 1) {
               BlockPos var8 = var5.getTopSolidOrLiquidBlock(var5.getSpawnPoint());
               var16.moveToBlockPosAndAngles(var8, var16.rotationYaw, var16.rotationPitch);
            } else {
               var16.moveToBlockPosAndAngles(var6, var16.rotationYaw, var16.rotationPitch);
            }

            boolean var17 = var16.forceSpawn;
            var16.forceSpawn = true;
            var5.spawnEntityInWorld(var16);
            var16.forceSpawn = var17;
            var5.updateEntityWithOptionalForce(var16, false);
         }

         this.isDead = true;
         this.world.theProfiler.endSection();
         var4.resetUpdateEntityTick();
         var5.resetUpdateEntityTick();
         this.world.theProfiler.endSection();
         return var16;
      } else {
         return null;
      }
   }

   public boolean isNonBoss() {
      return true;
   }

   public float getExplosionResistance(Explosion var1, World var2, BlockPos var3, IBlockState var4) {
      return var4.getBlock().getExplosionResistance(this);
   }

   public boolean verifyExplosion(Explosion var1, World var2, BlockPos var3, IBlockState var4, float var5) {
      return true;
   }

   public int getMaxFallHeight() {
      return 3;
   }

   public Vec3d getLastPortalVec() {
      return this.lastPortalVec;
   }

   public EnumFacing getTeleportDirection() {
      return this.teleportDirection;
   }

   public boolean doesEntityNotTriggerPressurePlate() {
      return false;
   }

   public void addEntityCrashInfo(CrashReportCategory var1) {
      var1.setDetail("Entity Type", new ICrashReportDetail<String>() {
         public String call() throws Exception {
            return EntityList.func_191301_a(Entity.this) + " (" + Entity.this.getClass().getCanonicalName() + ")";
         }
      });
      var1.addCrashSection("Entity ID", this.entityId);
      var1.setDetail("Entity Name", new ICrashReportDetail<String>() {
         public String call() throws Exception {
            return Entity.this.getName();
         }
      });
      var1.addCrashSection("Entity's Exact location", String.format("%.2f, %.2f, %.2f", this.posX, this.posY, this.posZ));
      var1.addCrashSection("Entity's Block location", CrashReportCategory.getCoordinateInfo(MathHelper.floor(this.posX), MathHelper.floor(this.posY), MathHelper.floor(this.posZ)));
      var1.addCrashSection("Entity's Momentum", String.format("%.2f, %.2f, %.2f", this.motionX, this.motionY, this.motionZ));
      var1.setDetail("Entity's Passengers", new ICrashReportDetail<String>() {
         public String call() throws Exception {
            return Entity.this.getPassengers().toString();
         }
      });
      var1.setDetail("Entity's Vehicle", new ICrashReportDetail<String>() {
         public String call() throws Exception {
            return Entity.this.getRidingEntity().toString();
         }
      });
   }

   public boolean canRenderOnFire() {
      return this.isBurning();
   }

   public void setUniqueId(UUID var1) {
      this.entityUniqueID = var1;
      this.cachedUniqueIdString = this.entityUniqueID.toString();
   }

   public UUID getUniqueID() {
      return this.entityUniqueID;
   }

   public String getCachedUniqueIdString() {
      return this.cachedUniqueIdString;
   }

   public boolean isPushedByWater() {
      return true;
   }

   public static double getRenderDistanceWeight() {
      return renderDistanceWeight;
   }

   public static void setRenderDistanceWeight(double var0) {
      renderDistanceWeight = var0;
   }

   public ITextComponent getDisplayName() {
      TextComponentString var1 = new TextComponentString(ScorePlayerTeam.formatPlayerName(this.getTeam(), this.getName()));
      var1.getStyle().setHoverEvent(this.getHoverEvent());
      var1.getStyle().setInsertion(this.getCachedUniqueIdString());
      return var1;
   }

   public void setCustomNameTag(String var1) {
      this.dataManager.set(CUSTOM_NAME, var1);
   }

   public String getCustomNameTag() {
      return (String)this.dataManager.get(CUSTOM_NAME);
   }

   public boolean hasCustomName() {
      return !((String)this.dataManager.get(CUSTOM_NAME)).isEmpty();
   }

   public void setAlwaysRenderNameTag(boolean var1) {
      this.dataManager.set(CUSTOM_NAME_VISIBLE, var1);
   }

   public boolean getAlwaysRenderNameTag() {
      return (Boolean)this.dataManager.get(CUSTOM_NAME_VISIBLE);
   }

   public void setPositionAndUpdate(double var1, double var3, double var5) {
      this.isPositionDirty = true;
      this.setLocationAndAngles(var1, var3, var5, this.rotationYaw, this.rotationPitch);
      this.world.updateEntityWithOptionalForce(this, false);
   }

   public boolean getAlwaysRenderNameTagForRender() {
      return this.getAlwaysRenderNameTag();
   }

   public void notifyDataManagerChange(DataParameter<?> var1) {
   }

   public EnumFacing getHorizontalFacing() {
      return EnumFacing.getHorizontal(MathHelper.floor((double)(this.rotationYaw * 4.0F / 360.0F) + (double)0.5F) & 3);
   }

   public EnumFacing getAdjustedHorizontalFacing() {
      return this.getHorizontalFacing();
   }

   protected HoverEvent getHoverEvent() {
      NBTTagCompound var1 = new NBTTagCompound();
      ResourceLocation var2 = EntityList.func_191301_a(this);
      var1.setString("id", this.getCachedUniqueIdString());
      if (var2 != null) {
         var1.setString("type", var2.toString());
      }

      var1.setString("name", this.getName());
      return new HoverEvent(HoverEvent.Action.SHOW_ENTITY, new TextComponentString(var1.toString()));
   }

   public boolean isSpectatedByPlayer(EntityPlayerMP var1) {
      return true;
   }

   public AxisAlignedBB getEntityBoundingBox() {
      return this.boundingBox;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return this.getEntityBoundingBox();
   }

   public void setEntityBoundingBox(AxisAlignedBB var1) {
      this.boundingBox = var1;
   }

   public float getEyeHeight() {
      return this.height * 0.85F;
   }

   public boolean isOutsideBorder() {
      return this.isOutsideBorder;
   }

   public void setOutsideBorder(boolean var1) {
      this.isOutsideBorder = var1;
   }

   public boolean replaceItemInInventory(int var1, ItemStack var2) {
      return false;
   }

   public void addChatMessage(ITextComponent var1) {
   }

   public boolean canCommandSenderUseCommand(int var1, String var2) {
      return true;
   }

   public BlockPos getPosition() {
      return new BlockPos(this.posX, this.posY + (double)0.5F, this.posZ);
   }

   public Vec3d getPositionVector() {
      return new Vec3d(this.posX, this.posY, this.posZ);
   }

   public World getEntityWorld() {
      return this.world;
   }

   public Entity getCommandSenderEntity() {
      return this;
   }

   public boolean sendCommandFeedback() {
      return false;
   }

   public void setCommandStat(CommandResultStats.Type var1, int var2) {
      if (this.world != null && !this.world.isRemote) {
         this.cmdResultStats.setCommandStatForSender(this.world.getMinecraftServer(), this, var1, var2);
      }

   }

   @Nullable
   public MinecraftServer getServer() {
      return this.world.getMinecraftServer();
   }

   public CommandResultStats getCommandStats() {
      return this.cmdResultStats;
   }

   public void setCommandStats(Entity var1) {
      this.cmdResultStats.addAllStats(var1.getCommandStats());
   }

   public EnumActionResult applyPlayerInteraction(EntityPlayer var1, Vec3d var2, EnumHand var3) {
      return EnumActionResult.PASS;
   }

   public boolean isImmuneToExplosions() {
      return false;
   }

   protected void applyEnchantments(EntityLivingBase var1, Entity var2) {
      if (var2 instanceof EntityLivingBase) {
         EnchantmentHelper.applyThornEnchantments((EntityLivingBase)var2, var1);
      }

      EnchantmentHelper.applyArthropodEnchantments(var1, var2);
   }

   public void addTrackingPlayer(EntityPlayerMP var1) {
   }

   public void removeTrackingPlayer(EntityPlayerMP var1) {
   }

   public float getRotatedYaw(Rotation var1) {
      float var2 = MathHelper.wrapDegrees(this.rotationYaw);
      switch (var1) {
         case CLOCKWISE_180:
            return var2 + 180.0F;
         case COUNTERCLOCKWISE_90:
            return var2 + 270.0F;
         case CLOCKWISE_90:
            return var2 + 90.0F;
         default:
            return var2;
      }
   }

   public float getMirroredYaw(Mirror var1) {
      float var2 = MathHelper.wrapDegrees(this.rotationYaw);
      switch (var1) {
         case LEFT_RIGHT:
            return -var2;
         case FRONT_BACK:
            return 180.0F - var2;
         default:
            return var2;
      }
   }

   public boolean ignoreItemEntityData() {
      return false;
   }

   public boolean setPositionNonDirty() {
      boolean var1 = this.isPositionDirty;
      this.isPositionDirty = false;
      return var1;
   }

   @Nullable
   public Entity getControllingPassenger() {
      return null;
   }

   public List<Entity> getPassengers() {
      return (List<Entity>)(this.riddenByEntities.isEmpty() ? Collections.emptyList() : Lists.newArrayList(this.riddenByEntities));
   }

   public boolean isPassenger(Entity var1) {
      for(Entity var3 : this.getPassengers()) {
         if (var3.equals(var1)) {
            return true;
         }
      }

      return false;
   }

   public Collection<Entity> getRecursivePassengers() {
      HashSet var1 = Sets.newHashSet();
      this.getRecursivePassengersByType(Entity.class, var1);
      return var1;
   }

   public <T extends Entity> Collection<T> getRecursivePassengersByType(Class<T> var1) {
      HashSet var2 = Sets.newHashSet();
      this.getRecursivePassengersByType(var1, var2);
      return var2;
   }

   private <T extends Entity> void getRecursivePassengersByType(Class<T> var1, Set<T> var2) {
      for(Entity var4 : this.getPassengers()) {
         if (var1.isAssignableFrom(var4.getClass())) {
            var2.add((T)var4);
         }

         var4.getRecursivePassengersByType(var1, var2);
      }

   }

   public Entity getLowestRidingEntity() {
      Entity var1;
      for(var1 = this; var1.isRiding(); var1 = var1.getRidingEntity()) {
      }

      return var1;
   }

   public boolean isRidingSameEntity(Entity var1) {
      return this.getLowestRidingEntity() == var1.getLowestRidingEntity();
   }

   public boolean isRidingOrBeingRiddenBy(Entity var1) {
      for(Entity var3 : this.getPassengers()) {
         if (var3.equals(var1)) {
            return true;
         }

         if (var3.isRidingOrBeingRiddenBy(var1)) {
            return true;
         }
      }

      return false;
   }

   public boolean canPassengerSteer() {
      Entity var1 = this.getControllingPassenger();
      if (var1 instanceof EntityPlayer) {
         return ((EntityPlayer)var1).isUser();
      } else {
         return !this.world.isRemote;
      }
   }

   @Nullable
   public Entity getRidingEntity() {
      return this.ridingEntity;
   }

   public EnumPushReaction getPushReaction() {
      return EnumPushReaction.NORMAL;
   }

   public SoundCategory getSoundCategory() {
      return SoundCategory.NEUTRAL;
   }

   protected int func_190531_bD() {
      return 1;
   }

   static {
      FLAGS = EntityDataManager.<Byte>createKey(Entity.class, DataSerializers.BYTE);
      AIR = EntityDataManager.<Integer>createKey(Entity.class, DataSerializers.VARINT);
      CUSTOM_NAME = EntityDataManager.<String>createKey(Entity.class, DataSerializers.STRING);
      CUSTOM_NAME_VISIBLE = EntityDataManager.<Boolean>createKey(Entity.class, DataSerializers.BOOLEAN);
      SILENT = EntityDataManager.<Boolean>createKey(Entity.class, DataSerializers.BOOLEAN);
      NO_GRAVITY = EntityDataManager.<Boolean>createKey(Entity.class, DataSerializers.BOOLEAN);
   }
}
