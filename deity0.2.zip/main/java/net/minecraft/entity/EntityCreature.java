package net.minecraft.entity;

import java.util.UUID;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public abstract class EntityCreature extends EntityLiving {
   public static final UUID FLEEING_SPEED_MODIFIER_UUID = UUID.fromString("E199AD21-BA8A-4C53-8D13-6182D5C69D3A");
   public static final AttributeModifier FLEEING_SPEED_MODIFIER;
   private BlockPos homePosition;
   private float maximumHomeDistance;
   private final float restoreWaterCost;

   public EntityCreature(World var1) {
      super(var1);
      this.homePosition = BlockPos.ORIGIN;
      this.maximumHomeDistance = -1.0F;
      this.restoreWaterCost = PathNodeType.WATER.getPriority();
   }

   public float getBlockPathWeight(BlockPos var1) {
      return 0.0F;
   }

   public boolean getCanSpawnHere() {
      return super.getCanSpawnHere() && this.getBlockPathWeight(new BlockPos(this.posX, this.getEntityBoundingBox().minY, this.posZ)) >= 0.0F;
   }

   public boolean hasPath() {
      return !this.navigator.noPath();
   }

   public boolean isWithinHomeDistanceCurrentPosition() {
      return this.isWithinHomeDistanceFromPosition(new BlockPos(this));
   }

   public boolean isWithinHomeDistanceFromPosition(BlockPos var1) {
      if (this.maximumHomeDistance == -1.0F) {
         return true;
      } else {
         return this.homePosition.distanceSq(var1) < (double)(this.maximumHomeDistance * this.maximumHomeDistance);
      }
   }

   public void setHomePosAndDistance(BlockPos var1, int var2) {
      this.homePosition = var1;
      this.maximumHomeDistance = (float)var2;
   }

   public BlockPos getHomePosition() {
      return this.homePosition;
   }

   public float getMaximumHomeDistance() {
      return this.maximumHomeDistance;
   }

   public void detachHome() {
      this.maximumHomeDistance = -1.0F;
   }

   public boolean hasHome() {
      return this.maximumHomeDistance != -1.0F;
   }

   protected void updateLeashedState() {
      super.updateLeashedState();
      if (this.getLeashed() && this.getLeashedToEntity() != null && this.getLeashedToEntity().world == this.world) {
         Entity var1 = this.getLeashedToEntity();
         this.setHomePosAndDistance(new BlockPos((int)var1.posX, (int)var1.posY, (int)var1.posZ), 5);
         float var2 = this.getDistanceToEntity(var1);
         if (this instanceof EntityTameable && ((EntityTameable)this).isSitting()) {
            if (var2 > 10.0F) {
               this.clearLeashed(true, true);
            }

            return;
         }

         this.onLeashDistance(var2);
         if (var2 > 10.0F) {
            this.clearLeashed(true, true);
            this.tasks.disableControlFlag(1);
         } else if (var2 > 6.0F) {
            double var3 = (var1.posX - this.posX) / (double)var2;
            double var5 = (var1.posY - this.posY) / (double)var2;
            double var7 = (var1.posZ - this.posZ) / (double)var2;
            this.motionX += var3 * Math.abs(var3) * 0.4;
            this.motionY += var5 * Math.abs(var5) * 0.4;
            this.motionZ += var7 * Math.abs(var7) * 0.4;
         } else {
            this.tasks.enableControlFlag(1);
            float var9 = 2.0F;
            Vec3d var4 = (new Vec3d(var1.posX - this.posX, var1.posY - this.posY, var1.posZ - this.posZ)).normalize().scale((double)Math.max(var2 - 2.0F, 0.0F));
            this.getNavigator().tryMoveToXYZ(this.posX + var4.xCoord, this.posY + var4.yCoord, this.posZ + var4.zCoord, this.func_190634_dg());
         }
      }

   }

   protected double func_190634_dg() {
      return (double)1.0F;
   }

   protected void onLeashDistance(float var1) {
   }

   static {
      FLEEING_SPEED_MODIFIER = (new AttributeModifier(FLEEING_SPEED_MODIFIER_UUID, "Fleeing speed bonus", (double)2.0F, 2)).setSaved(false);
   }
}
