package net.minecraft.village;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldEntitySpawner;

public class VillageSiege {
   private final World worldObj;
   private boolean hasSetupSiege;
   private int siegeState = -1;
   private int siegeCount;
   private int nextSpawnTime;
   private Village theVillage;
   private int spawnX;
   private int spawnY;
   private int spawnZ;

   public VillageSiege(World var1) {
      this.worldObj = var1;
   }

   public void tick() {
      if (this.worldObj.isDaytime()) {
         this.siegeState = 0;
      } else if (this.siegeState != 2) {
         if (this.siegeState == 0) {
            float var1 = this.worldObj.getCelestialAngle(0.0F);
            if ((double)var1 < (double)0.5F || (double)var1 > 0.501) {
               return;
            }

            this.siegeState = this.worldObj.rand.nextInt(10) == 0 ? 1 : 2;
            this.hasSetupSiege = false;
            if (this.siegeState == 2) {
               return;
            }
         }

         if (this.siegeState != -1) {
            if (!this.hasSetupSiege) {
               if (!this.trySetupSiege()) {
                  return;
               }

               this.hasSetupSiege = true;
            }

            if (this.nextSpawnTime > 0) {
               --this.nextSpawnTime;
            } else {
               this.nextSpawnTime = 2;
               if (this.siegeCount > 0) {
                  this.spawnZombie();
                  --this.siegeCount;
               } else {
                  this.siegeState = 2;
               }
            }
         }
      }

   }

   private boolean trySetupSiege() {
      for(EntityPlayer var3 : this.worldObj.playerEntities) {
         if (!var3.isSpectator()) {
            this.theVillage = this.worldObj.getVillageCollection().getNearestVillage(new BlockPos(var3), 1);
            if (this.theVillage != null && this.theVillage.getNumVillageDoors() >= 10 && this.theVillage.getTicksSinceLastDoorAdding() >= 20 && this.theVillage.getNumVillagers() >= 20) {
               BlockPos var4 = this.theVillage.getCenter();
               float var5 = (float)this.theVillage.getVillageRadius();
               boolean var6 = false;

               for(int var7 = 0; var7 < 10; ++var7) {
                  float var8 = this.worldObj.rand.nextFloat() * ((float)Math.PI * 2F);
                  this.spawnX = var4.getX() + (int)((double)(MathHelper.cos(var8) * var5) * 0.9);
                  this.spawnY = var4.getY();
                  this.spawnZ = var4.getZ() + (int)((double)(MathHelper.sin(var8) * var5) * 0.9);
                  var6 = false;

                  for(Village var10 : this.worldObj.getVillageCollection().getVillageList()) {
                     if (var10 != this.theVillage && var10.isBlockPosWithinSqVillageRadius(new BlockPos(this.spawnX, this.spawnY, this.spawnZ))) {
                        var6 = true;
                        break;
                     }
                  }

                  if (!var6) {
                     break;
                  }
               }

               if (var6) {
                  return false;
               }

               Vec3d var11 = this.findRandomSpawnPos(new BlockPos(this.spawnX, this.spawnY, this.spawnZ));
               if (var11 != null) {
                  this.nextSpawnTime = 0;
                  this.siegeCount = 20;
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean spawnZombie() {
      Vec3d var1 = this.findRandomSpawnPos(new BlockPos(this.spawnX, this.spawnY, this.spawnZ));
      if (var1 == null) {
         return false;
      } else {
         EntityZombie var2;
         try {
            var2 = new EntityZombie(this.worldObj);
            var2.onInitialSpawn(this.worldObj.getDifficultyForLocation(new BlockPos(var2)), (IEntityLivingData)null);
         } catch (Exception var4) {
            var4.printStackTrace();
            return false;
         }

         var2.setLocationAndAngles(var1.xCoord, var1.yCoord, var1.zCoord, this.worldObj.rand.nextFloat() * 360.0F, 0.0F);
         this.worldObj.spawnEntityInWorld(var2);
         BlockPos var3 = this.theVillage.getCenter();
         var2.setHomePosAndDistance(var3, this.theVillage.getVillageRadius());
         return true;
      }
   }

   @Nullable
   private Vec3d findRandomSpawnPos(BlockPos var1) {
      for(int var2 = 0; var2 < 10; ++var2) {
         BlockPos var3 = var1.add(this.worldObj.rand.nextInt(16) - 8, this.worldObj.rand.nextInt(6) - 3, this.worldObj.rand.nextInt(16) - 8);
         if (this.theVillage.isBlockPosWithinSqVillageRadius(var3) && WorldEntitySpawner.canCreatureTypeSpawnAtLocation(EntityLiving.SpawnPlacementType.ON_GROUND, this.worldObj, var3)) {
            return new Vec3d((double)var3.getX(), (double)var3.getY(), (double)var3.getZ());
         }
      }

      return null;
   }
}
