package net.minecraft.init;

import com.mojang.authlib.GameProfile;
import java.io.File;
import java.io.PrintStream;
import java.util.Random;
import java.util.UUID;
import net.minecraft.advancements.AdvancementManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDispenser;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockPumpkin;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockTNT;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.BehaviorProjectileDispense;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.IPosition;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.entity.projectile.EntitySpectralArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionHelper;
import net.minecraft.potion.PotionType;
import net.minecraft.server.DebugLoggingPrintStream;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.LoggingPrintStream;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.StringUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.storage.loot.LootTableList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Bootstrap {
   public static final PrintStream SYSOUT;
   private static boolean alreadyRegistered;
   public static boolean field_194219_b;
   private static final Logger LOGGER;

   public static boolean isRegistered() {
      return alreadyRegistered;
   }

   static void registerDispenserBehaviors() {
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.ARROW, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            EntityTippedArrow var4 = new EntityTippedArrow(var1, var2.getX(), var2.getY(), var2.getZ());
            var4.pickupStatus = EntityArrow.PickupStatus.ALLOWED;
            return var4;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.TIPPED_ARROW, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            EntityTippedArrow var4 = new EntityTippedArrow(var1, var2.getX(), var2.getY(), var2.getZ());
            var4.setPotionEffect(var3);
            var4.pickupStatus = EntityArrow.PickupStatus.ALLOWED;
            return var4;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SPECTRAL_ARROW, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            EntitySpectralArrow var4 = new EntitySpectralArrow(var1, var2.getX(), var2.getY(), var2.getZ());
            var4.pickupStatus = EntityArrow.PickupStatus.ALLOWED;
            return var4;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.EGG, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            return new EntityEgg(var1, var2.getX(), var2.getY(), var2.getZ());
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SNOWBALL, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            return new EntitySnowball(var1, var2.getX(), var2.getY(), var2.getZ());
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.EXPERIENCE_BOTTLE, new BehaviorProjectileDispense() {
         protected IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3) {
            return new EntityExpBottle(var1, var2.getX(), var2.getY(), var2.getZ());
         }

         protected float getProjectileInaccuracy() {
            return super.getProjectileInaccuracy() * 0.5F;
         }

         protected float getProjectileVelocity() {
            return super.getProjectileVelocity() * 1.25F;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SPLASH_POTION, new IBehaviorDispenseItem() {
         public ItemStack dispense(IBlockSource var1, final ItemStack var2) {
            return (new BehaviorProjectileDispense() {
               protected IProjectile getProjectileEntity(World var1, IPosition var2x, ItemStack var3) {
                  return new EntityPotion(var1, var2x.getX(), var2x.getY(), var2x.getZ(), var2.copy());
               }

               protected float getProjectileInaccuracy() {
                  return super.getProjectileInaccuracy() * 0.5F;
               }

               protected float getProjectileVelocity() {
                  return super.getProjectileVelocity() * 1.25F;
               }
            }).dispense(var1, var2);
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.LINGERING_POTION, new IBehaviorDispenseItem() {
         public ItemStack dispense(IBlockSource var1, final ItemStack var2) {
            return (new BehaviorProjectileDispense() {
               protected IProjectile getProjectileEntity(World var1, IPosition var2x, ItemStack var3) {
                  return new EntityPotion(var1, var2x.getX(), var2x.getY(), var2x.getZ(), var2.copy());
               }

               protected float getProjectileInaccuracy() {
                  return super.getProjectileInaccuracy() * 0.5F;
               }

               protected float getProjectileVelocity() {
                  return super.getProjectileVelocity() * 1.25F;
               }
            }).dispense(var1, var2);
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SPAWN_EGG, new BehaviorDefaultDispenseItem() {
         public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            EnumFacing var3 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
            double var4 = var1.getX() + (double)var3.getFrontOffsetX();
            double var6 = (double)((float)(var1.getBlockPos().getY() + var3.getFrontOffsetY()) + 0.2F);
            double var8 = var1.getZ() + (double)var3.getFrontOffsetZ();
            Entity var10 = ItemMonsterPlacer.spawnCreature(var1.getWorld(), ItemMonsterPlacer.func_190908_h(var2), var4, var6, var8);
            if (var10 instanceof EntityLivingBase && var2.hasDisplayName()) {
               var10.setCustomNameTag(var2.getDisplayName());
            }

            ItemMonsterPlacer.applyItemEntityDataToEntity(var1.getWorld(), (EntityPlayer)null, var2, var10);
            var2.func_190918_g(1);
            return var2;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.FIREWORKS, new BehaviorDefaultDispenseItem() {
         public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            EnumFacing var3 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
            double var4 = var1.getX() + (double)var3.getFrontOffsetX();
            double var6 = (double)((float)var1.getBlockPos().getY() + 0.2F);
            double var8 = var1.getZ() + (double)var3.getFrontOffsetZ();
            EntityFireworkRocket var10 = new EntityFireworkRocket(var1.getWorld(), var4, var6, var8, var2);
            var1.getWorld().spawnEntityInWorld(var10);
            var2.func_190918_g(1);
            return var2;
         }

         protected void playDispenseSound(IBlockSource var1) {
            var1.getWorld().playEvent(1004, var1.getBlockPos(), 0);
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.FIRE_CHARGE, new BehaviorDefaultDispenseItem() {
         public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            EnumFacing var3 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
            IPosition var4 = BlockDispenser.getDispensePosition(var1);
            double var5 = var4.getX() + (double)((float)var3.getFrontOffsetX() * 0.3F);
            double var7 = var4.getY() + (double)((float)var3.getFrontOffsetY() * 0.3F);
            double var9 = var4.getZ() + (double)((float)var3.getFrontOffsetZ() * 0.3F);
            World var11 = var1.getWorld();
            Random var12 = var11.rand;
            double var13 = var12.nextGaussian() * 0.05 + (double)var3.getFrontOffsetX();
            double var15 = var12.nextGaussian() * 0.05 + (double)var3.getFrontOffsetY();
            double var17 = var12.nextGaussian() * 0.05 + (double)var3.getFrontOffsetZ();
            var11.spawnEntityInWorld(new EntitySmallFireball(var11, var5, var7, var9, var13, var15, var17));
            var2.func_190918_g(1);
            return var2;
         }

         protected void playDispenseSound(IBlockSource var1) {
            var1.getWorld().playEvent(1018, var1.getBlockPos(), 0);
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.BOAT, new BehaviorDispenseBoat(EntityBoat.Type.OAK));
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SPRUCE_BOAT, new BehaviorDispenseBoat(EntityBoat.Type.SPRUCE));
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.BIRCH_BOAT, new BehaviorDispenseBoat(EntityBoat.Type.BIRCH));
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.JUNGLE_BOAT, new BehaviorDispenseBoat(EntityBoat.Type.JUNGLE));
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.DARK_OAK_BOAT, new BehaviorDispenseBoat(EntityBoat.Type.DARK_OAK));
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.ACACIA_BOAT, new BehaviorDispenseBoat(EntityBoat.Type.ACACIA));
      BehaviorDefaultDispenseItem var0 = new BehaviorDefaultDispenseItem() {
         private final BehaviorDefaultDispenseItem dispenseBehavior = new BehaviorDefaultDispenseItem();

         public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            ItemBucket var3 = (ItemBucket)var2.getItem();
            BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
            return var3.tryPlaceContainedLiquid((EntityPlayer)null, var1.getWorld(), var4) ? new ItemStack(Items.BUCKET) : this.dispenseBehavior.dispense(var1, var2);
         }
      };
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.LAVA_BUCKET, var0);
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.WATER_BUCKET, var0);
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.BUCKET, new BehaviorDefaultDispenseItem() {
         private final BehaviorDefaultDispenseItem dispenseBehavior = new BehaviorDefaultDispenseItem();

         public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            World var3 = var1.getWorld();
            BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
            IBlockState var5 = var3.getBlockState(var4);
            Block var6 = var5.getBlock();
            Material var7 = var5.getMaterial();
            Item var8;
            if (Material.WATER.equals(var7) && var6 instanceof BlockLiquid && (Integer)var5.getValue(BlockLiquid.LEVEL) == 0) {
               var8 = Items.WATER_BUCKET;
            } else {
               if (!Material.LAVA.equals(var7) || !(var6 instanceof BlockLiquid) || (Integer)var5.getValue(BlockLiquid.LEVEL) != 0) {
                  return super.dispenseStack(var1, var2);
               }

               var8 = Items.LAVA_BUCKET;
            }

            var3.setBlockToAir(var4);
            var2.func_190918_g(1);
            if (var2.func_190926_b()) {
               return new ItemStack(var8);
            } else {
               if (((TileEntityDispenser)var1.getBlockTileEntity()).addItemStack(new ItemStack(var8)) < 0) {
                  this.dispenseBehavior.dispense(var1, new ItemStack(var8));
               }

               return var2;
            }
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.FLINT_AND_STEEL, new BehaviorDispenseOptional() {
         protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            World var3 = var1.getWorld();
            this.field_190911_b = true;
            BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
            if (var3.isAirBlock(var4)) {
               var3.setBlockState(var4, Blocks.FIRE.getDefaultState());
               if (var2.attemptDamageItem(1, var3.rand, (EntityPlayerMP)null)) {
                  var2.func_190920_e(0);
               }
            } else if (var3.getBlockState(var4).getBlock() == Blocks.TNT) {
               Blocks.TNT.onBlockDestroyedByPlayer(var3, var4, Blocks.TNT.getDefaultState().withProperty(BlockTNT.EXPLODE, true));
               var3.setBlockToAir(var4);
            } else {
               this.field_190911_b = false;
            }

            return var2;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.DYE, new BehaviorDispenseOptional() {
         protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            this.field_190911_b = true;
            if (EnumDyeColor.WHITE == EnumDyeColor.byDyeDamage(var2.getMetadata())) {
               World var3 = var1.getWorld();
               BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
               if (ItemDye.applyBonemeal(var2, var3, var4)) {
                  if (!var3.isRemote) {
                     var3.playEvent(2005, var4, 0);
                  }
               } else {
                  this.field_190911_b = false;
               }

               return var2;
            } else {
               return super.dispenseStack(var1, var2);
            }
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Item.getItemFromBlock(Blocks.TNT), new BehaviorDefaultDispenseItem() {
         protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            World var3 = var1.getWorld();
            BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
            EntityTNTPrimed var5 = new EntityTNTPrimed(var3, (double)var4.getX() + (double)0.5F, (double)var4.getY(), (double)var4.getZ() + (double)0.5F, (EntityLivingBase)null);
            var3.spawnEntityInWorld(var5);
            var3.playSound((EntityPlayer)null, var5.posX, var5.posY, var5.posZ, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
            var2.func_190918_g(1);
            return var2;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Items.SKULL, new BehaviorDispenseOptional() {
         protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            World var3 = var1.getWorld();
            EnumFacing var4 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
            BlockPos var5 = var1.getBlockPos().offset(var4);
            BlockSkull var6 = Blocks.SKULL;
            this.field_190911_b = true;
            if (var3.isAirBlock(var5) && var6.canDispenserPlace(var3, var5, var2)) {
               if (!var3.isRemote) {
                  var3.setBlockState(var5, var6.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.UP), 3);
                  TileEntity var7 = var3.getTileEntity(var5);
                  if (var7 instanceof TileEntitySkull) {
                     if (var2.getMetadata() == 3) {
                        GameProfile var8 = null;
                        if (var2.hasTagCompound()) {
                           NBTTagCompound var9 = var2.getTagCompound();
                           if (var9.hasKey("SkullOwner", 10)) {
                              var8 = NBTUtil.readGameProfileFromNBT(var9.getCompoundTag("SkullOwner"));
                           } else if (var9.hasKey("SkullOwner", 8)) {
                              String var10 = var9.getString("SkullOwner");
                              if (!StringUtils.isNullOrEmpty(var10)) {
                                 var8 = new GameProfile((UUID)null, var10);
                              }
                           }
                        }

                        ((TileEntitySkull)var7).setPlayerProfile(var8);
                     } else {
                        ((TileEntitySkull)var7).setType(var2.getMetadata());
                     }

                     ((TileEntitySkull)var7).setSkullRotation(var4.getOpposite().getHorizontalIndex() * 4);
                     Blocks.SKULL.checkWitherSpawn(var3, var5, (TileEntitySkull)var7);
                  }

                  var2.func_190918_g(1);
               }
            } else if (ItemArmor.dispenseArmor(var1, var2).func_190926_b()) {
               this.field_190911_b = false;
            }

            return var2;
         }
      });
      BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Item.getItemFromBlock(Blocks.PUMPKIN), new BehaviorDispenseOptional() {
         protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
            World var3 = var1.getWorld();
            BlockPos var4 = var1.getBlockPos().offset((EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
            BlockPumpkin var5 = (BlockPumpkin)Blocks.PUMPKIN;
            this.field_190911_b = true;
            if (var3.isAirBlock(var4) && var5.canDispenserPlace(var3, var4)) {
               if (!var3.isRemote) {
                  var3.setBlockState(var4, var5.getDefaultState(), 3);
               }

               var2.func_190918_g(1);
            } else {
               ItemStack var6 = ItemArmor.dispenseArmor(var1, var2);
               if (var6.func_190926_b()) {
                  this.field_190911_b = false;
               }
            }

            return var2;
         }
      });

      for(EnumDyeColor var4 : EnumDyeColor.values()) {
         BlockDispenser.DISPENSE_BEHAVIOR_REGISTRY.putObject(Item.getItemFromBlock(BlockShulkerBox.func_190952_a(var4)), new BehaviorDispenseShulkerBox());
      }

   }

   public static void register() {
      if (!alreadyRegistered) {
         alreadyRegistered = true;
         redirectOutputToLog();
         SoundEvent.registerSounds();
         Block.registerBlocks();
         BlockFire.init();
         Potion.registerPotions();
         Enchantment.registerEnchantments();
         Item.registerItems();
         PotionType.registerPotionTypes();
         PotionHelper.init();
         EntityList.init();
         Biome.registerBiomes();
         registerDispenserBehaviors();
         if (!CraftingManager.func_193377_a()) {
            field_194219_b = true;
            LOGGER.error("Errors with built-in recipes!");
         }

         StatList.init();
         if (LOGGER.isDebugEnabled()) {
            if ((new AdvancementManager((File)null)).func_193767_b()) {
               field_194219_b = true;
               LOGGER.error("Errors with built-in advancements!");
            }

            if (!LootTableList.func_193579_b()) {
               field_194219_b = true;
               LOGGER.error("Errors with built-in loot tables");
            }
         }
      }

   }

   private static void redirectOutputToLog() {
      if (LOGGER.isDebugEnabled()) {
         System.setErr(new DebugLoggingPrintStream("STDERR", System.err));
         System.setOut(new DebugLoggingPrintStream("STDOUT", SYSOUT));
      } else {
         System.setErr(new LoggingPrintStream("STDERR", System.err));
         System.setOut(new LoggingPrintStream("STDOUT", SYSOUT));
      }

   }

   public static void printToSYSOUT(String var0) {
      SYSOUT.println(var0);
   }

   static {
      SYSOUT = System.out;
      LOGGER = LogManager.getLogger();
   }

   public static class BehaviorDispenseBoat extends BehaviorDefaultDispenseItem {
      private final BehaviorDefaultDispenseItem dispenseBehavior = new BehaviorDefaultDispenseItem();
      private final EntityBoat.Type boatType;

      public BehaviorDispenseBoat(EntityBoat.Type var1) {
         this.boatType = var1;
      }

      public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
         EnumFacing var3 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
         World var4 = var1.getWorld();
         double var5 = var1.getX() + (double)((float)var3.getFrontOffsetX() * 1.125F);
         double var7 = var1.getY() + (double)((float)var3.getFrontOffsetY() * 1.125F);
         double var9 = var1.getZ() + (double)((float)var3.getFrontOffsetZ() * 1.125F);
         BlockPos var11 = var1.getBlockPos().offset(var3);
         Material var12 = var4.getBlockState(var11).getMaterial();
         double var13;
         if (Material.WATER.equals(var12)) {
            var13 = (double)1.0F;
         } else {
            if (!Material.AIR.equals(var12) || !Material.WATER.equals(var4.getBlockState(var11.down()).getMaterial())) {
               return this.dispenseBehavior.dispense(var1, var2);
            }

            var13 = (double)0.0F;
         }

         EntityBoat var15 = new EntityBoat(var4, var5, var7 + var13, var9);
         var15.setBoatType(this.boatType);
         var15.rotationYaw = var3.getHorizontalAngle();
         var4.spawnEntityInWorld(var15);
         var2.func_190918_g(1);
         return var2;
      }

      protected void playDispenseSound(IBlockSource var1) {
         var1.getWorld().playEvent(1000, var1.getBlockPos(), 0);
      }
   }

   public abstract static class BehaviorDispenseOptional extends BehaviorDefaultDispenseItem {
      protected boolean field_190911_b = true;

      protected void playDispenseSound(IBlockSource var1) {
         var1.getWorld().playEvent(this.field_190911_b ? 1000 : 1001, var1.getBlockPos(), 0);
      }
   }

   static class BehaviorDispenseShulkerBox extends BehaviorDispenseOptional {
      private BehaviorDispenseShulkerBox() {
      }

      protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
         Block var3 = Block.getBlockFromItem(var2.getItem());
         World var4 = var1.getWorld();
         EnumFacing var5 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
         BlockPos var6 = var1.getBlockPos().offset(var5);
         this.field_190911_b = var4.func_190527_a(var3, var6, false, EnumFacing.DOWN, (Entity)null);
         if (this.field_190911_b) {
            EnumFacing var7 = var4.isAirBlock(var6.down()) ? var5 : EnumFacing.UP;
            IBlockState var8 = var3.getDefaultState().withProperty(BlockShulkerBox.field_190957_a, var7);
            var4.setBlockState(var6, var8);
            TileEntity var9 = var4.getTileEntity(var6);
            ItemStack var10 = var2.splitStack(1);
            if (var10.hasTagCompound()) {
               ((TileEntityShulkerBox)var9).func_190586_e(var10.getTagCompound().getCompoundTag("BlockEntityTag"));
            }

            if (var10.hasDisplayName()) {
               ((TileEntityShulkerBox)var9).func_190575_a(var10.getDisplayName());
            }

            var4.updateComparatorOutputLevel(var6, var8.getBlock());
         }

         return var2;
      }

      BehaviorDispenseShulkerBox(Object var1) {
         this();
      }
   }
}
