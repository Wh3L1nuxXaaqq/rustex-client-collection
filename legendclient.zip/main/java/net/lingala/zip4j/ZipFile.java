package net.lingala.zip4j;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderReader;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.inputstream.NumberedSplitRandomAccessFile;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.tasks.AddFilesToZipTask;
import net.lingala.zip4j.tasks.AddFolderToZipTask;
import net.lingala.zip4j.tasks.AddStreamToZipTask;
import net.lingala.zip4j.tasks.AsyncZipTask;
import net.lingala.zip4j.tasks.ExtractAllFilesTask;
import net.lingala.zip4j.tasks.ExtractFileTask;
import net.lingala.zip4j.tasks.MergeSplitZipFileTask;
import net.lingala.zip4j.tasks.RemoveFilesFromZipTask;
import net.lingala.zip4j.tasks.RenameFilesTask;
import net.lingala.zip4j.tasks.SetCommentTask;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.UnzipUtil;
import net.lingala.zip4j.util.Zip4jUtil;

public class ZipFile implements Closeable {
   private File zipFile;
   private ZipModel zipModel;
   private boolean isEncrypted;
   private ProgressMonitor progressMonitor;
   private boolean runInThread;
   private char[] password;
   private HeaderWriter headerWriter;
   private Charset charset;
   private ThreadFactory threadFactory;
   private ExecutorService executorService;
   private int bufferSize;
   private List<InputStream> openInputStreams;
   private boolean useUtf8CharsetForPasswords;

   public ZipFile(String var1) {
      this((File)(new File(var1)), (char[])null);
   }

   public ZipFile(String var1, char[] var2) {
      this(new File(var1), var2);
   }

   public ZipFile(File var1) {
      this((File)var1, (char[])null);
   }

   public ZipFile(File var1, char[] var2) {
      this.headerWriter = new HeaderWriter();
      this.charset = null;
      this.bufferSize = 4096;
      this.openInputStreams = new ArrayList();
      this.useUtf8CharsetForPasswords = true;
      if (var1 == null) {
         throw new IllegalArgumentException("input zip file parameter is null");
      } else {
         this.zipFile = var1;
         this.password = var2;
         this.runInThread = false;
         this.progressMonitor = new ProgressMonitor();
      }
   }

   public void createSplitZipFile(List<File> var1, ZipParameters var2, boolean var3, long var4) throws ZipException {
      if (this.zipFile.exists()) {
         throw new ZipException("zip file: " + this.zipFile + " already exists. To add files to existing zip file use addFile method");
      } else if (var1 != null && var1.size() != 0) {
         this.createNewZipModel();
         this.zipModel.setSplitArchive(var3);
         this.zipModel.setSplitLength(var3 ? var4 : -1L);
         new AddFilesToZipTask(this.zipModel, this.password, this.headerWriter, this.buildAsyncParameters())).execute(new AddFilesToZipTask.AddFilesToZipTaskParameters(var1, var2, this.buildConfig());
      } else {
         throw new ZipException("input file List is null, cannot create zip file");
      }
   }

   public void createSplitZipFile(InputStream var1, ZipParameters var2, boolean var3, long var4) throws ZipException {
      if (this.zipFile.exists()) {
         throw new ZipException("zip file: " + this.zipFile + " already exists. To add files to existing zip file use addFile method");
      } else if (var1 == null) {
         throw new ZipException("input stream is null, cannot create zip file");
      } else {
         this.createNewZipModel();
         this.zipModel.setSplitArchive(var3);
         this.zipModel.setSplitLength(var3 ? var4 : -1L);
         new AddStreamToZipTask(this.zipModel, this.password, this.headerWriter, this.buildAsyncParameters())).execute(new AddStreamToZipTask.AddStreamToZipTaskParameters(var1, var2, this.buildConfig());
      }
   }

   public void createSplitZipFileFromFolder(File var1, ZipParameters var2, boolean var3, long var4) throws ZipException {
      if (var1 == null) {
         throw new ZipException("folderToAdd is null, cannot create zip file from folder");
      } else if (var2 == null) {
         throw new ZipException("input parameters are null, cannot create zip file from folder");
      } else if (this.zipFile.exists()) {
         throw new ZipException("zip file: " + this.zipFile + " already exists. To add files to existing zip file use addFolder method");
      } else {
         this.createNewZipModel();
         this.zipModel.setSplitArchive(var3);
         if (var3) {
            this.zipModel.setSplitLength(var4);
         }

         this.addFolder(var1, var2, false);
      }
   }

   public void addFile(String var1) throws ZipException {
      this.addFile(var1, new ZipParameters());
   }

   public void addFile(String var1, ZipParameters var2) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("file to add is null or empty");
      } else {
         this.addFiles(Collections.singletonList(new File(var1)), var2);
      }
   }

   public void addFile(File var1) throws ZipException {
      this.addFiles(Collections.singletonList(var1), new ZipParameters());
   }

   public void addFile(File var1, ZipParameters var2) throws ZipException {
      this.addFiles(Collections.singletonList(var1), var2);
   }

   public void addFiles(List<File> var1) throws ZipException {
      this.addFiles(var1, new ZipParameters());
   }

   public void addFiles(List<File> var1, ZipParameters var2) throws ZipException {
      if (var1 != null && var1.size() != 0) {
         if (var2 == null) {
            throw new ZipException("input parameters are null");
         } else {
            this.readZipInfo();
            if (this.zipModel == null) {
               throw new ZipException("internal error: zip model is null");
            } else if (this.zipFile.exists() && this.zipModel.isSplitArchive()) {
               throw new ZipException("Zip file already exists. Zip file format does not allow updating split/spanned files");
            } else {
               new AddFilesToZipTask(this.zipModel, this.password, this.headerWriter, this.buildAsyncParameters())).execute(new AddFilesToZipTask.AddFilesToZipTaskParameters(var1, var2, this.buildConfig());
            }
         }
      } else {
         throw new ZipException("input file List is null or empty");
      }
   }

   public void addFolder(File var1) throws ZipException {
      this.addFolder(var1, new ZipParameters());
   }

   public void addFolder(File var1, ZipParameters var2) throws ZipException {
      if (var1 == null) {
         throw new ZipException("input path is null, cannot add folder to zip file");
      } else if (!var1.exists()) {
         throw new ZipException("folder does not exist");
      } else if (!var1.isDirectory()) {
         throw new ZipException("input folder is not a directory");
      } else if (!var1.canRead()) {
         throw new ZipException("cannot read input folder");
      } else if (var2 == null) {
         throw new ZipException("input parameters are null, cannot add folder to zip file");
      } else {
         this.addFolder(var1, var2, true);
      }
   }

   private void addFolder(File var1, ZipParameters var2, boolean var3) throws ZipException {
      this.readZipInfo();
      if (this.zipModel == null) {
         throw new ZipException("internal error: zip model is null");
      } else if (var3 && this.zipModel.isSplitArchive()) {
         throw new ZipException("This is a split archive. Zip file format does not allow updating split/spanned files");
      } else {
         new AddFolderToZipTask(this.zipModel, this.password, this.headerWriter, this.buildAsyncParameters())).execute(new AddFolderToZipTask.AddFolderToZipTaskParameters(var1, var2, this.buildConfig());
      }
   }

   public void addStream(InputStream var1, ZipParameters var2) throws ZipException {
      if (var1 == null) {
         throw new ZipException("inputstream is null, cannot add file to zip");
      } else if (var2 == null) {
         throw new ZipException("zip parameters are null");
      } else {
         this.setRunInThread(false);
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("internal error: zip model is null");
         } else if (this.zipFile.exists() && this.zipModel.isSplitArchive()) {
            throw new ZipException("Zip file already exists. Zip file format does not allow updating split/spanned files");
         } else {
            new AddStreamToZipTask(this.zipModel, this.password, this.headerWriter, this.buildAsyncParameters())).execute(new AddStreamToZipTask.AddStreamToZipTaskParameters(var1, var2, this.buildConfig());
         }
      }
   }

   public void extractAll(String var1) throws ZipException {
      this.extractAll(var1, new UnzipParameters());
   }

   public void extractAll(String var1, UnzipParameters var2) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("output path is null or invalid");
      } else if (!Zip4jUtil.createDirectoryIfNotExists(new File(var1))) {
         throw new ZipException("invalid output path");
      } else {
         if (this.zipModel == null) {
            this.readZipInfo();
         }

         if (this.zipModel == null) {
            throw new ZipException("Internal error occurred when extracting zip file");
         } else {
            new ExtractAllFilesTask(this.zipModel, this.password, var2, this.buildAsyncParameters())).execute(new ExtractAllFilesTask.ExtractAllFilesTaskParameters(var1, this.buildConfig());
         }
      }
   }

   public void extractFile(FileHeader var1, String var2) throws ZipException {
      this.extractFile((FileHeader)var1, var2, (String)null, new UnzipParameters());
   }

   public void extractFile(FileHeader var1, String var2, UnzipParameters var3) throws ZipException {
      this.extractFile((FileHeader)var1, var2, (String)null, var3);
   }

   public void extractFile(FileHeader var1, String var2, String var3, UnzipParameters var4) throws ZipException {
      if (var1 == null) {
         throw new ZipException("input file header is null, cannot extract file");
      } else {
         this.extractFile(var1.getFileName(), var2, var3, var4);
      }
   }

   public void extractFile(String var1, String var2) throws ZipException {
      this.extractFile((String)var1, var2, (String)null, new UnzipParameters());
   }

   public void extractFile(String var1, String var2, UnzipParameters var3) throws ZipException {
      this.extractFile((String)var1, var2, (String)null, var3);
   }

   public void extractFile(String var1, String var2, String var3) throws ZipException {
      this.extractFile(var1, var2, var3, new UnzipParameters());
   }

   public void extractFile(FileHeader var1, String var2, String var3) throws ZipException {
      this.extractFile(var1, var2, var3, new UnzipParameters());
   }

   public void extractFile(String var1, String var2, String var3, UnzipParameters var4) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("file to extract is null or empty, cannot extract file");
      } else if (!Zip4jUtil.isStringNotNullAndNotEmpty(var2)) {
         throw new ZipException("destination path is empty or null, cannot extract file");
      } else {
         if (var4 == null) {
            var4 = new UnzipParameters();
         }

         this.readZipInfo();
         new ExtractFileTask(this.zipModel, this.password, var4, this.buildAsyncParameters())).execute(new ExtractFileTask.ExtractFileTaskParameters(var2, var1, var3, this.buildConfig());
      }
   }

   public List<FileHeader> getFileHeaders() throws ZipException {
      this.readZipInfo();
      return this.zipModel != null && this.zipModel.getCentralDirectory() != null ? this.zipModel.getCentralDirectory().getFileHeaders() : Collections.emptyList();
   }

   public FileHeader getFileHeader(String var1) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("input file name is emtpy or null, cannot get FileHeader");
      } else {
         this.readZipInfo();
         return this.zipModel != null && this.zipModel.getCentralDirectory() != null ? HeaderUtil.getFileHeader(this.zipModel, var1) : null;
      }
   }

   public boolean isEncrypted() throws ZipException {
      if (this.zipModel == null) {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("Zip Model is null");
         }
      }

      if (this.zipModel.getCentralDirectory() != null && this.zipModel.getCentralDirectory().getFileHeaders() != null) {
         for(FileHeader var2 : this.zipModel.getCentralDirectory().getFileHeaders()) {
            if (var2 != null && var2.isEncrypted()) {
               this.isEncrypted = true;
               break;
            }
         }

         return this.isEncrypted;
      } else {
         throw new ZipException("invalid zip file");
      }
   }

   public boolean isSplitArchive() throws ZipException {
      if (this.zipModel == null) {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("Zip Model is null");
         }
      }

      return this.zipModel.isSplitArchive();
   }

   public void removeFile(FileHeader var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("input file header is null, cannot remove file");
      } else {
         this.removeFile(var1.getFileName());
      }
   }

   public void removeFile(String var1) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("file name is empty or null, cannot remove file");
      } else {
         this.removeFiles(Collections.singletonList(var1));
      }
   }

   public void removeFiles(List<String> var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("fileNames list is null");
      } else if (!var1.isEmpty()) {
         if (this.zipModel == null) {
            this.readZipInfo();
         }

         if (this.zipModel.isSplitArchive()) {
            throw new ZipException("Zip file format does not allow updating split/spanned files");
         } else {
            new RemoveFilesFromZipTask(this.zipModel, this.headerWriter, this.buildAsyncParameters())).execute(new RemoveFilesFromZipTask.RemoveFilesFromZipTaskParameters(var1, this.buildConfig());
         }
      }
   }

   public void renameFile(FileHeader var1, String var2) throws ZipException {
      if (var1 == null) {
         throw new ZipException("File header is null");
      } else {
         this.renameFile(var1.getFileName(), var2);
      }
   }

   public void renameFile(String var1, String var2) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("file name to be changed is null or empty");
      } else if (!Zip4jUtil.isStringNotNullAndNotEmpty(var2)) {
         throw new ZipException("newFileName is null or empty");
      } else {
         this.renameFiles(Collections.singletonMap(var1, var2));
      }
   }

   public void renameFiles(Map<String, String> var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("fileNamesMap is null");
      } else if (var1.size() != 0) {
         this.readZipInfo();
         if (this.zipModel.isSplitArchive()) {
            throw new ZipException("Zip file format does not allow updating split/spanned files");
         } else {
            AsyncZipTask.AsyncTaskParameters var2 = this.buildAsyncParameters();
            new RenameFilesTask(this.zipModel, this.headerWriter, new RawIO(), var2)).execute(new RenameFilesTask.RenameFilesTaskParameters(var1, this.buildConfig());
         }
      }
   }

   public void mergeSplitFiles(File var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("outputZipFile is null, cannot merge split files");
      } else if (var1.exists()) {
         throw new ZipException("output Zip File already exists");
      } else {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("zip model is null, corrupt zip file?");
         } else {
            new MergeSplitZipFileTask(this.zipModel, this.buildAsyncParameters())).execute(new MergeSplitZipFileTask.MergeSplitZipFileTaskParameters(var1, this.buildConfig());
         }
      }
   }

   public void setComment(String var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("input comment is null, cannot update zip file");
      } else if (!this.zipFile.exists()) {
         throw new ZipException("zip file does not exist, cannot set comment for zip file");
      } else {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("zipModel is null, cannot update zip file");
         } else if (this.zipModel.getEndOfCentralDirectoryRecord() == null) {
            throw new ZipException("end of central directory is null, cannot set comment");
         } else {
            new SetCommentTask(this.zipModel, this.buildAsyncParameters())).execute(new SetCommentTask.SetCommentTaskTaskParameters(var1, this.buildConfig());
         }
      }
   }

   public String getComment() throws ZipException {
      if (!this.zipFile.exists()) {
         throw new ZipException("zip file does not exist, cannot read comment");
      } else {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("zip model is null, cannot read comment");
         } else if (this.zipModel.getEndOfCentralDirectoryRecord() == null) {
            throw new ZipException("end of central directory record is null, cannot read comment");
         } else {
            return this.zipModel.getEndOfCentralDirectoryRecord().getComment();
         }
      }
   }

   public ZipInputStream getInputStream(FileHeader var1) throws IOException {
      if (var1 == null) {
         throw new ZipException("FileHeader is null, cannot get InputStream");
      } else {
         this.readZipInfo();
         if (this.zipModel == null) {
            throw new ZipException("zip model is null, cannot get inputstream");
         } else {
            ZipInputStream var2 = UnzipUtil.createZipInputStream(this.zipModel, var1, this.password);
            this.openInputStreams.add(var2);
            return var2;
         }
      }
   }

   public boolean isValidZipFile() {
      if (!this.zipFile.exists()) {
         return false;
      } else {
         try {
            this.readZipInfo();
            return !this.zipModel.isSplitArchive() || this.verifyAllSplitFilesOfZipExists(this.getSplitZipFiles());
         } catch (Exception var2) {
            return false;
         }
      }
   }

   public List<File> getSplitZipFiles() throws ZipException {
      this.readZipInfo();
      return FileUtils.getSplitZipFiles(this.zipModel);
   }

   public void close() throws IOException {
      for(InputStream var2 : this.openInputStreams) {
         var2.close();
      }

      this.openInputStreams.clear();
   }

   public void setPassword(char[] var1) {
      this.password = var1;
   }

   public int getBufferSize() {
      return this.bufferSize;
   }

   public void setBufferSize(int var1) {
      if (var1 < 512) {
         throw new IllegalArgumentException("Buffer size cannot be less than 512 bytes");
      } else {
         this.bufferSize = var1;
      }
   }

   private void readZipInfo() throws ZipException {
      if (this.zipModel == null) {
         if (!this.zipFile.exists()) {
            this.createNewZipModel();
         } else if (!this.zipFile.canRead()) {
            throw new ZipException("no read access for the input zip file");
         } else {
            try {
               RandomAccessFile var1 = this.initializeRandomAccessFileForHeaderReading();
               Throwable var2 = null;

               try {
                  HeaderReader var3 = new HeaderReader();
                  this.zipModel = var3.readAllHeaders(var1, this.buildConfig());
                  this.zipModel.setZipFile(this.zipFile);
               } catch (Throwable var13) {
                  var2 = var13;
                  throw var13;
               } finally {
                  if (var1 != null) {
                     if (var2 != null) {
                        try {
                           var1.close();
                        } catch (Throwable var12) {
                           var2.addSuppressed(var12);
                        }
                     } else {
                        var1.close();
                     }
                  }

               }

            } catch (ZipException var15) {
               throw var15;
            } catch (IOException var16) {
               throw new ZipException(var16);
            }
         }
      }
   }

   private void createNewZipModel() {
      this.zipModel = new ZipModel();
      this.zipModel.setZipFile(this.zipFile);
   }

   private RandomAccessFile initializeRandomAccessFileForHeaderReading() throws IOException {
      if (FileUtils.isNumberedSplitFile(this.zipFile)) {
         File[] var1 = FileUtils.getAllSortedNumberedSplitFiles(this.zipFile);
         NumberedSplitRandomAccessFile var2 = new NumberedSplitRandomAccessFile(this.zipFile, RandomAccessFileMode.READ.getValue(), var1);
         var2.openLastSplitFileForReading();
         return var2;
      } else {
         return new RandomAccessFile(this.zipFile, RandomAccessFileMode.READ.getValue());
      }
   }

   private AsyncZipTask.AsyncTaskParameters buildAsyncParameters() {
      if (this.runInThread) {
         if (this.threadFactory == null) {
            this.threadFactory = Executors.defaultThreadFactory();
         }

         this.executorService = Executors.newSingleThreadExecutor(this.threadFactory);
      }

      return new AsyncZipTask.AsyncTaskParameters(this.executorService, this.runInThread, this.progressMonitor);
   }

   private boolean verifyAllSplitFilesOfZipExists(List<File> var1) {
      for(File var3 : var1) {
         if (!var3.exists()) {
            return false;
         }
      }

      return true;
   }

   public ProgressMonitor getProgressMonitor() {
      return this.progressMonitor;
   }

   public boolean isRunInThread() {
      return this.runInThread;
   }

   public void setRunInThread(boolean var1) {
      this.runInThread = var1;
   }

   public File getFile() {
      return this.zipFile;
   }

   public Charset getCharset() {
      return this.charset == null ? InternalZipConstants.CHARSET_UTF_8 : this.charset;
   }

   public void setCharset(Charset var1) throws IllegalArgumentException {
      if (var1 == null) {
         throw new IllegalArgumentException("charset cannot be null");
      } else {
         this.charset = var1;
      }
   }

   public void setThreadFactory(ThreadFactory var1) {
      this.threadFactory = var1;
   }

   public ExecutorService getExecutorService() {
      return this.executorService;
   }

   public String toString() {
      return this.zipFile.toString();
   }

   private Zip4jConfig buildConfig() {
      return new Zip4jConfig(this.charset, this.bufferSize, this.useUtf8CharsetForPasswords);
   }

   public boolean isUseUtf8CharsetForPasswords() {
      return this.useUtf8CharsetForPasswords;
   }

   public void setUseUtf8CharsetForPasswords(boolean var1) {
      this.useUtf8CharsetForPasswords = var1;
   }
}
