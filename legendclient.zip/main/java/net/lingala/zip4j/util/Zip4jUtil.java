package net.lingala.zip4j.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.Calendar;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AbstractFileHeader;
import net.lingala.zip4j.model.enums.CompressionMethod;

public class Zip4jUtil {
   private static final long DOSTIME_BEFORE_1980 = 2162688L;
   private static final int MAX_RAW_READ_FULLY_RETRY_ATTEMPTS = 15;

   public static boolean isStringNullOrEmpty(String var0) {
      return var0 == null || var0.trim().length() == 0;
   }

   public static boolean isStringNotNullAndNotEmpty(String var0) {
      return var0 != null && var0.trim().length() > 0;
   }

   public static boolean createDirectoryIfNotExists(File var0) throws ZipException {
      if (var0 == null) {
         throw new ZipException("output path is null");
      } else {
         if (var0.exists()) {
            if (!var0.isDirectory()) {
               throw new ZipException("output directory is not valid");
            }
         } else if (!var0.mkdirs()) {
            throw new ZipException("Cannot create output directories");
         }

         return true;
      }
   }

   public static long epochToExtendedDosTime(long var0) {
      if (var0 < 0L) {
         return 2162688L;
      } else {
         long var2 = epochToDosTime(var0);
         return var2 != 2162688L ? var2 + (var0 % 2000L << 32) : 2162688L;
      }
   }

   private static long epochToDosTime(long var0) {
      Calendar var2 = Calendar.getInstance();
      var2.setTimeInMillis(var0);
      int var3 = var2.get(1);
      return var3 < 1980 ? 2162688L : (long)(var3 - 1980 << 25 | var2.get(2) + 1 << 21 | var2.get(5) << 16 | var2.get(11) << 11 | var2.get(12) << 5 | var2.get(13) >> 1);
   }

   public static long dosToExtendedEpochTme(long var0) {
      long var2 = dosToEpochTime(var0);
      return var2 + (var0 >> 32);
   }

   private static long dosToEpochTime(long var0) {
      int var2 = (int)(var0 << 1 & 62L);
      int var3 = (int)(var0 >> 5 & 63L);
      int var4 = (int)(var0 >> 11 & 31L);
      int var5 = (int)(var0 >> 16 & 31L);
      int var6 = (int)((var0 >> 21 & 15L) - 1L);
      int var7 = (int)((var0 >> 25 & 127L) + 1980L);
      Calendar var8 = Calendar.getInstance();
      var8.set(var7, var6, var5, var4, var3, var2);
      var8.set(14, 0);
      return var8.getTime().getTime();
   }

   public static byte[] convertCharArrayToByteArray(char[] var0, boolean var1) {
      return var1 ? convertCharArrayToByteArrayUsingUtf8(var0) : convertCharArrayToByteArrayUsingDefaultCharset(var0);
   }

   public static CompressionMethod getCompressionMethod(AbstractFileHeader var0) throws ZipException {
      if (var0.getCompressionMethod() != CompressionMethod.AES_INTERNAL_ONLY) {
         return var0.getCompressionMethod();
      } else if (var0.getAesExtraDataRecord() == null) {
         throw new ZipException("AesExtraDataRecord not present in local header for aes encrypted data");
      } else {
         return var0.getAesExtraDataRecord().getCompressionMethod();
      }
   }

   public static int readFully(InputStream var0, byte[] var1) throws IOException {
      int var2 = var0.read(var1);
      if (var2 == -1) {
         throw new IOException("Unexpected EOF reached when trying to read stream");
      } else {
         if (var2 != var1.length) {
            var2 = readUntilBufferIsFull(var0, var1, var2);
            if (var2 != var1.length) {
               throw new IOException("Cannot read fully into byte buffer");
            }
         }

         return var2;
      }
   }

   public static int readFully(InputStream var0, byte[] var1, int var2, int var3) throws IOException {
      int var4 = 0;
      if (var2 < 0) {
         throw new IllegalArgumentException("Negative offset");
      } else if (var3 < 0) {
         throw new IllegalArgumentException("Negative length");
      } else if (var3 == 0) {
         return 0;
      } else if (var2 + var3 > var1.length) {
         throw new IllegalArgumentException("Length greater than buffer size");
      } else {
         while(var4 != var3) {
            int var5 = var0.read(var1, var2 + var4, var3 - var4);
            if (var5 == -1) {
               if (var4 == 0) {
                  return -1;
               }

               return var4;
            }

            var4 += var5;
         }

         return var4;
      }
   }

   private static int readUntilBufferIsFull(InputStream var0, byte[] var1, int var2) throws IOException {
      if (var2 < 0) {
         throw new IOException("Invalid readLength");
      } else if (var2 == 0) {
         return 0;
      } else {
         int var3 = var1.length - var2;
         int var4 = 0;

         for(int var5 = 1; var2 < var1.length && var4 != -1 && var5 < 15; ++var5) {
            var4 = var0.read(var1, var2, var3);
            if (var4 > 0) {
               var2 += var4;
               var3 -= var4;
            }
         }

         return var2;
      }
   }

   private static byte[] convertCharArrayToByteArrayUsingUtf8(char[] var0) {
      try {
         ByteBuffer var1 = InternalZipConstants.CHARSET_UTF_8.encode(CharBuffer.wrap(var0));
         byte[] var2 = new byte[var1.limit()];
         var1.get(var2);
         return var2;
      } catch (Exception var3) {
         return convertCharArrayToByteArrayUsingDefaultCharset(var0);
      }
   }

   private static byte[] convertCharArrayToByteArrayUsingDefaultCharset(char[] var0) {
      byte[] var1 = new byte[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = (byte)var0[var2];
      }

      return var1;
   }
}
