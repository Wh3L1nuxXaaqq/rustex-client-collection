package net.lingala.zip4j.util;

public class BitUtils {
   public static boolean isBitSet(byte var0, int var1) {
      return ((long)var0 & 1L << var1) != 0L;
   }

   public static byte setBit(byte var0, int var1) {
      return (byte)(var0 | 1 << var1);
   }

   public static byte unsetBit(byte var0, int var1) {
      return (byte)(var0 & ~(1 << var1));
   }
}
