package net.lingala.zip4j.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.CRC32;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.progress.ProgressMonitor;

public class CrcUtil {
   private static final int BUF_SIZE = 16384;

   public static long computeFileCrc(File var0, ProgressMonitor var1) throws IOException {
      if (var0 != null && var0.exists() && var0.canRead()) {
         byte[] var2 = new byte[16384];
         CRC32 var3 = new CRC32();
         FileInputStream var4 = new FileInputStream(var0);
         Throwable var5 = null;

         try {
            while(true) {
               int var6;
               if ((var6 = ((InputStream)var4).read(var2)) != -1) {
                  var3.update(var2, 0, var6);
                  if (var1 == null) {
                     continue;
                  }

                  var1.updateWorkCompleted((long)var6);
                  if (!var1.isCancelAllTasks()) {
                     continue;
                  }

                  var1.setResult(ProgressMonitor.Result.CANCELLED);
                  var1.setState(ProgressMonitor.State.READY);
                  long var20 = 0L;
                  return var20;
               }

               long var7 = var3.getValue();
               return var7;
            }
         } catch (Throwable var18) {
            var5 = var18;
            throw var18;
         } finally {
            if (var4 != null) {
               if (var5 != null) {
                  try {
                     (InputStream)var4).close(;
                  } catch (Throwable var17) {
                     var5.addSuppressed(var17);
                  }
               } else {
                  (InputStream)var4).close(;
               }
            }

         }
      } else {
         throw new ZipException("input file is null or does not exist or cannot read. Cannot calculate CRC for the file");
      }
   }
}
