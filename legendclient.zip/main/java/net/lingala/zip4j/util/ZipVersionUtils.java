package net.lingala.zip4j.util;

import net.lingala.zip4j.headers.VersionMadeBy;
import net.lingala.zip4j.headers.VersionNeededToExtract;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

public class ZipVersionUtils {
   public static int determineVersionMadeBy(ZipParameters var0, RawIO var1) {
      byte[] var2 = new byte[]{VersionMadeBy.SPECIFICATION_VERSION.getCode(), VersionMadeBy.UNIX.getCode()};
      if (FileUtils.isWindows() && !var0.isUnixMode()) {
         var2[1] = VersionMadeBy.WINDOWS.getCode();
      }

      return var1.readShortLittleEndian(var2, 0);
   }

   public static VersionNeededToExtract determineVersionNeededToExtract(ZipParameters var0) {
      VersionNeededToExtract var1 = VersionNeededToExtract.DEFAULT;
      if (var0.getCompressionMethod() == CompressionMethod.DEFLATE) {
         var1 = VersionNeededToExtract.DEFLATE_COMPRESSED;
      }

      if (var0.getEntrySize() > 4294967295L) {
         var1 = VersionNeededToExtract.ZIP_64_FORMAT;
      }

      if (var0.isEncryptFiles() && var0.getEncryptionMethod().equals(EncryptionMethod.AES)) {
         var1 = VersionNeededToExtract.AES_ENCRYPTED;
      }

      return var1;
   }
}
