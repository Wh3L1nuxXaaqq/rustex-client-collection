package net.lingala.zip4j.util;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.DosFileAttributes;
import java.nio.file.attribute.FileTime;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.progress.ProgressMonitor;

public class FileUtils {
   public static final byte[] DEFAULT_POSIX_FILE_ATTRIBUTES = new byte[]{0, 0, -92, -127};
   public static final byte[] DEFAULT_POSIX_FOLDER_ATTRIBUTES = new byte[]{0, 0, -19, 65};

   public static void setFileAttributes(Path var0, byte[] var1) {
      if (var1 != null && var1.length != 0) {
         if (isWindows()) {
            applyWindowsFileAttributes(var0, var1);
         } else if (isMac() || isUnix()) {
            applyPosixFileAttributes(var0, var1);
         }

      }
   }

   public static void setFileLastModifiedTime(Path var0, long var1) {
      if (var1 > 0L && Files.exists(var0, new LinkOption[0])) {
         try {
            Files.setLastModifiedTime(var0, FileTime.fromMillis(Zip4jUtil.dosToExtendedEpochTme(var1)));
         } catch (Exception var4) {
         }

      }
   }

   public static void setFileLastModifiedTimeWithoutNio(File var0, long var1) {
      var0.setLastModified(Zip4jUtil.dosToExtendedEpochTme(var1));
   }

   public static byte[] getFileAttributes(File var0) {
      try {
         if (var0 != null && (Files.isSymbolicLink(var0.toPath()) || var0.exists())) {
            Path var1 = var0.toPath();
            if (isWindows()) {
               return getWindowsFileAttributes(var1);
            } else {
               return !isMac() && !isUnix() ? new byte[4] : getPosixFileAttributes(var1);
            }
         } else {
            return new byte[4];
         }
      } catch (NoSuchMethodError var2) {
         return new byte[4];
      }
   }

   public static List<File> getFilesInDirectoryRecursive(File var0, ZipParameters var1) throws ZipException {
      if (var0 == null) {
         throw new ZipException("input path is null, cannot read files in the directory");
      } else {
         ArrayList var2 = new ArrayList();
         File[] var3 = var0.listFiles();
         if (var0.isDirectory() && var0.canRead() && var3 != null) {
            for(File var7 : var3) {
               if ((var1.getExcludeFileFilter() == null || !var1.getExcludeFileFilter().isExcluded(var7)) && (!var7.isHidden() || var1.isReadHiddenFiles())) {
                  var2.add(var7);
                  ZipParameters.SymbolicLinkAction var8 = var1.getSymbolicLinkAction();
                  boolean var9 = isSymbolicLink(var7);
                  if (var9 && !ZipParameters.SymbolicLinkAction.INCLUDE_LINK_ONLY.equals(var8) || !var9 && var7.isDirectory()) {
                     var2.addAll(getFilesInDirectoryRecursive(var7, var1));
                  }
               }
            }

            return var2;
         } else {
            return var2;
         }
      }
   }

   public static String getFileNameWithoutExtension(String var0) {
      int var1 = var0.lastIndexOf(".");
      return var1 == -1 ? var0 : var0.substring(0, var1);
   }

   public static String getZipFileNameWithoutExtension(String var0) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var0)) {
         throw new ZipException("zip file name is empty or null, cannot determine zip file name");
      } else {
         String var1 = var0;
         if (var0.contains(System.getProperty("file.separator"))) {
            var1 = var0.substring(var0.lastIndexOf(System.getProperty("file.separator")) + 1);
         }

         if (var1.endsWith(".zip")) {
            var1 = var1.substring(0, var1.lastIndexOf("."));
         }

         return var1;
      }
   }

   public static List<File> getSplitZipFiles(ZipModel var0) throws ZipException {
      if (var0 == null) {
         throw new ZipException("cannot get split zip files: zipmodel is null");
      } else if (var0.getEndOfCentralDirectoryRecord() == null) {
         return null;
      } else if (!var0.getZipFile().exists()) {
         throw new ZipException("zip file does not exist");
      } else {
         ArrayList var1 = new ArrayList();
         File var2 = var0.getZipFile();
         if (!var0.isSplitArchive()) {
            var1.add(var2);
            return var1;
         } else {
            int var4 = var0.getEndOfCentralDirectoryRecord().getNumberOfThisDisk();
            if (var4 == 0) {
               var1.add(var2);
               return var1;
            } else {
               for(int var5 = 0; var5 <= var4; ++var5) {
                  if (var5 == var4) {
                     var1.add(var0.getZipFile());
                  } else {
                     if (var5 >= 9) {
                     }

                     String var3 = var2.getName().contains(".") ? var2.getPath().substring(0, var2.getPath().lastIndexOf(".")) : var2.getPath();
                     var3 = var3 + var6 + (var5 + 1);
                     var1.add(new File(var3));
                  }
               }

               return var1;
            }
         }
      }
   }

   public static String getRelativeFileName(File var0, ZipParameters var1) throws ZipException {
      String var2;
      try {
         String var3 = var0.getCanonicalPath();
         if (Zip4jUtil.isStringNotNullAndNotEmpty(var1.getDefaultFolderPath())) {
            File var4 = new File(var1.getDefaultFolderPath());
            String var5 = var4.getCanonicalPath();
            if (!var5.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
               var5 = var5 + InternalZipConstants.FILE_SEPARATOR;
            }

            String var6;
            if (isSymbolicLink(var0)) {
               String var7 = (new File(var0.getParentFile().getCanonicalFile().getPath() + File.separator + var0.getCanonicalFile().getName())).getPath();
               var6 = var7.substring(var5.length());
            } else if (!var0.getCanonicalFile().getPath().startsWith(var5)) {
               var6 = var0.getCanonicalFile().getParentFile().getName() + InternalZipConstants.FILE_SEPARATOR + var0.getCanonicalFile().getName();
            } else {
               var6 = var3.substring(var5.length());
            }

            if (var6.startsWith(System.getProperty("file.separator"))) {
               var6 = var6.substring(1);
            }

            File var15 = new File(var3);
            if (var15.isDirectory()) {
               var6 = var6.replaceAll("\\\\", "/");
               var6 = var6 + "/";
            } else {
               String var8 = var6.substring(0, var6.lastIndexOf(var15.getName()));
               var8 = var8.replaceAll("\\\\", "/");
               var6 = var8 + getNameOfFileInZip(var15, var1.getFileNameInZip());
            }

            var2 = var6;
         } else {
            File var11 = new File(var3);
            var2 = getNameOfFileInZip(var11, var1.getFileNameInZip());
            if (var11.isDirectory()) {
               var2 = var2 + "/";
            }
         }
      } catch (IOException var9) {
         throw new ZipException(var9);
      }

      String var10 = var1.getRootFolderNameInZip();
      if (Zip4jUtil.isStringNotNullAndNotEmpty(var10)) {
         if (!var10.endsWith("\\") && !var10.endsWith("/")) {
            var10 = var10 + InternalZipConstants.FILE_SEPARATOR;
         }

         var10 = var10.replaceAll("\\\\", "/");
         var2 = var10 + var2;
      }

      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var2)) {
         String var12 = "fileName to add to zip is empty or null. fileName: '" + var2 + "' DefaultFolderPath: '" + var1.getDefaultFolderPath() + "' FileNameInZip: " + var1.getFileNameInZip();
         if (isSymbolicLink(var0)) {
            var12 = var12 + "isSymlink: true ";
         }

         if (Zip4jUtil.isStringNotNullAndNotEmpty(var10)) {
            var12 = "rootFolderNameInZip: '" + var10 + "' ";
         }

         throw new ZipException(var12);
      } else {
         return var2;
      }
   }

   private static String getNameOfFileInZip(File var0, String var1) throws IOException {
      if (Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         return var1;
      } else {
         return isSymbolicLink(var0) ? var0.toPath().toRealPath(LinkOption.NOFOLLOW_LINKS).getFileName().toString() : var0.getName();
      }
   }

   public static boolean isZipEntryDirectory(String var0) {
      return var0.endsWith("/") || var0.endsWith("\\");
   }

   public static void copyFile(RandomAccessFile var0, OutputStream var1, long var2, long var4, ProgressMonitor var6, int var7) throws ZipException {
      if (var2 >= 0L && var4 >= 0L && var2 <= var4) {
         if (var2 != var4) {
            try {
               var0.seek(var2);
               long var10 = 0L;
               long var12 = var4 - var2;
               byte[] var9;
               if (var4 - var2 < (long)var7) {
                  var9 = new byte[(int)var12];
               } else {
                  var9 = new byte[var7];
               }

               int var8;
               while((var8 = var0.read(var9)) != -1) {
                  var1.write(var9, 0, var8);
                  var6.updateWorkCompleted((long)var8);
                  if (var6.isCancelAllTasks()) {
                     var6.setResult(ProgressMonitor.Result.CANCELLED);
                     return;
                  }

                  var10 += (long)var8;
                  if (var10 == var12) {
                     break;
                  }

                  if (var10 + (long)var9.length > var12) {
                     var9 = new byte[(int)(var12 - var10)];
                  }
               }

            } catch (IOException var14) {
               throw new ZipException(var14);
            }
         }
      } else {
         throw new ZipException("invalid offsets");
      }
   }

   public static void assertFilesExist(List<File> var0, ZipParameters.SymbolicLinkAction var1) throws ZipException {
      for(File var3 : var0) {
         if (isSymbolicLink(var3)) {
            if (var1.equals(ZipParameters.SymbolicLinkAction.INCLUDE_LINK_AND_LINKED_FILE) || var1.equals(ZipParameters.SymbolicLinkAction.INCLUDE_LINKED_FILE_ONLY)) {
               assertSymbolicLinkTargetExists(var3);
            }
         } else {
            assertFileExists(var3);
         }
      }

   }

   public static boolean isNumberedSplitFile(File var0) {
      return var0.getName().endsWith(".zip.001");
   }

   public static String getFileExtension(File var0) {
      String var1 = var0.getName();
      return !var1.contains(".") ? "" : var1.substring(var1.lastIndexOf(".") + 1);
   }

   public static File[] getAllSortedNumberedSplitFiles(File var0) {
      final String var1 = getFileNameWithoutExtension(var0.getName());
      File[] var2 = var0.getParentFile().listFiles(new FilenameFilter() {
         public boolean accept(File var1x, String var2) {
            return var2.startsWith(var1 + ".");
         }
      });
      if (var2 == null) {
         return new File[0];
      } else {
         Arrays.sort(var2);
         return var2;
      }
   }

   public static String getNextNumberedSplitFileCounterAsExtension(int var0) {
      return "." + getExtensionZerosPrefix(var0) + (var0 + 1);
   }

   public static boolean isSymbolicLink(File var0) {
      try {
         return Files.isSymbolicLink(var0.toPath());
      } catch (Error | Exception var2) {
         return false;
      }
   }

   public static String readSymbolicLink(File var0) {
      try {
         return Files.readSymbolicLink(var0.toPath()).toString();
      } catch (Error | Exception var2) {
         return "";
      }
   }

   public static byte[] getDefaultFileAttributes(boolean var0) {
      byte[] var1 = new byte[4];
      if (!isUnix() && !isMac()) {
         if (isWindows() && var0) {
            var1[0] = BitUtils.setBit(var1[0], 4);
         }
      } else if (var0) {
         System.arraycopy(DEFAULT_POSIX_FOLDER_ATTRIBUTES, 0, var1, 0, var1.length);
      } else {
         System.arraycopy(DEFAULT_POSIX_FILE_ATTRIBUTES, 0, var1, 0, var1.length);
      }

      return var1;
   }

   public static boolean isWindows() {
      String var0 = System.getProperty("os.name").toLowerCase();
      return var0.contains("win");
   }

   public static boolean isMac() {
      String var0 = System.getProperty("os.name").toLowerCase();
      return var0.contains("mac");
   }

   public static boolean isUnix() {
      String var0 = System.getProperty("os.name").toLowerCase();
      return var0.contains("nux");
   }

   private static String getExtensionZerosPrefix(int var0) {
      if (var0 < 9) {
         return "00";
      } else {
         return var0 < 99 ? "0" : "";
      }
   }

   private static void applyWindowsFileAttributes(Path var0, byte[] var1) {
      if (var1[0] != 0) {
         DosFileAttributeView var2 = (DosFileAttributeView)Files.getFileAttributeView(var0, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
         if (var2 != null) {
            try {
               var2.setReadOnly(BitUtils.isBitSet(var1[0], 0));
               var2.setHidden(BitUtils.isBitSet(var1[0], 1));
               var2.setSystem(BitUtils.isBitSet(var1[0], 2));
               var2.setArchive(BitUtils.isBitSet(var1[0], 5));
            } catch (IOException var4) {
            }

         }
      }
   }

   private static void applyPosixFileAttributes(Path var0, byte[] var1) {
      if (var1[2] != 0 || var1[3] != 0) {
         try {
            HashSet var2 = new HashSet();
            addIfBitSet(var1[3], 0, var2, PosixFilePermission.OWNER_READ);
            addIfBitSet(var1[2], 7, var2, PosixFilePermission.OWNER_WRITE);
            addIfBitSet(var1[2], 6, var2, PosixFilePermission.OWNER_EXECUTE);
            addIfBitSet(var1[2], 5, var2, PosixFilePermission.GROUP_READ);
            addIfBitSet(var1[2], 4, var2, PosixFilePermission.GROUP_WRITE);
            addIfBitSet(var1[2], 3, var2, PosixFilePermission.GROUP_EXECUTE);
            addIfBitSet(var1[2], 2, var2, PosixFilePermission.OTHERS_READ);
            addIfBitSet(var1[2], 1, var2, PosixFilePermission.OTHERS_WRITE);
            addIfBitSet(var1[2], 0, var2, PosixFilePermission.OTHERS_EXECUTE);
            Files.setPosixFilePermissions(var0, var2);
         } catch (IOException var3) {
         }

      }
   }

   private static byte[] getWindowsFileAttributes(Path var0) {
      byte[] var1 = new byte[4];

      try {
         DosFileAttributeView var2 = (DosFileAttributeView)Files.getFileAttributeView(var0, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
         if (var2 == null) {
            return var1;
         }

         DosFileAttributes var3 = var2.readAttributes();
         byte var4 = 0;
         var4 = setBitIfApplicable(var3.isReadOnly(), var4, 0);
         var4 = setBitIfApplicable(var3.isHidden(), var4, 1);
         var4 = setBitIfApplicable(var3.isSystem(), var4, 2);
         var4 = setBitIfApplicable(var3.isDirectory(), var4, 4);
         var4 = setBitIfApplicable(var3.isArchive(), var4, 5);
         var1[0] = var4;
      } catch (IOException var5) {
      }

      return var1;
   }

   private static void assertFileExists(File var0) throws ZipException {
      if (!var0.exists()) {
         throw new ZipException("File does not exist: " + var0);
      }
   }

   private static void assertSymbolicLinkTargetExists(File var0) throws ZipException {
      if (!var0.exists()) {
         throw new ZipException("Symlink target '" + readSymbolicLink(var0) + "' does not exist for link '" + var0 + "'");
      }
   }

   private static byte[] getPosixFileAttributes(Path var0) {
      byte[] var1 = new byte[4];

      try {
         PosixFileAttributeView var2 = (PosixFileAttributeView)Files.getFileAttributeView(var0, PosixFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
         Set var3 = var2.readAttributes().permissions();
         boolean var4 = Files.isSymbolicLink(var0);
         if (var4) {
            var1[3] = BitUtils.setBit(var1[3], 7);
            var1[3] = BitUtils.unsetBit(var1[3], 6);
         } else {
            var1[3] = setBitIfApplicable(Files.isRegularFile(var0, new LinkOption[0]), var1[3], 7);
            var1[3] = setBitIfApplicable(Files.isDirectory(var0, new LinkOption[0]), var1[3], 6);
         }

         var1[3] = setBitIfApplicable(var4, var1[3], 5);
         var1[3] = setBitIfApplicable(var3.contains(PosixFilePermission.OWNER_READ), var1[3], 0);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.OWNER_WRITE), var1[2], 7);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.OWNER_EXECUTE), var1[2], 6);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.GROUP_READ), var1[2], 5);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.GROUP_WRITE), var1[2], 4);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.GROUP_EXECUTE), var1[2], 3);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.OTHERS_READ), var1[2], 2);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.OTHERS_WRITE), var1[2], 1);
         var1[2] = setBitIfApplicable(var3.contains(PosixFilePermission.OTHERS_EXECUTE), var1[2], 0);
      } catch (IOException var5) {
      }

      return var1;
   }

   private static byte setBitIfApplicable(boolean var0, byte var1, int var2) {
      if (var0) {
         var1 = BitUtils.setBit(var1, var2);
      }

      return var1;
   }

   private static void addIfBitSet(byte var0, int var1, Set<PosixFilePermission> var2, PosixFilePermission var3) {
      if (BitUtils.isBitSet(var0, var1)) {
         var2.add(var3);
      }

   }
}
