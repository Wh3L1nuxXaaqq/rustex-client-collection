package net.lingala.zip4j.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.inputstream.NumberedSplitFileInputStream;
import net.lingala.zip4j.io.inputstream.SplitFileInputStream;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.io.inputstream.ZipStandardSplitFileInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;

public class UnzipUtil {
   public static ZipInputStream createZipInputStream(ZipModel var0, FileHeader var1, char[] var2) throws IOException {
      SplitFileInputStream var3 = null;

      try {
         var3 = createSplitInputStream(var0);
         var3.prepareExtractionForFileHeader(var1);
         ZipInputStream var4 = new ZipInputStream(var3, var2);
         if (var4.getNextEntry(var1, false) == null) {
            throw new ZipException("Could not locate local file header for corresponding file header");
         } else {
            return var4;
         }
      } catch (IOException var5) {
         if (var3 != null) {
            var3.close();
         }

         throw var5;
      }
   }

   public static void applyFileAttributes(FileHeader var0, File var1) {
      try {
         Path var2 = var1.toPath();
         FileUtils.setFileAttributes(var2, var0.getExternalFileAttributes());
         FileUtils.setFileLastModifiedTime(var2, var0.getLastModifiedTime());
      } catch (NoSuchMethodError var3) {
         FileUtils.setFileLastModifiedTimeWithoutNio(var1, var0.getLastModifiedTime());
      }

   }

   public static SplitFileInputStream createSplitInputStream(ZipModel var0) throws IOException {
      File var1 = var0.getZipFile();
      return (SplitFileInputStream)(var1.getName().endsWith(".zip.001") ? new NumberedSplitFileInputStream(var0.getZipFile()) : new ZipStandardSplitFileInputStream(var0.getZipFile(), var0.isSplitArchive(), var0.getEndOfCentralDirectoryRecord().getNumberOfThisDisk()));
   }
}
