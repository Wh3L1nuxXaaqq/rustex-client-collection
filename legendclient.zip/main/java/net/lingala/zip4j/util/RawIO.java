package net.lingala.zip4j.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import net.lingala.zip4j.exception.ZipException;

public class RawIO {
   private final byte[] shortBuff = new byte[2];
   private final byte[] intBuff = new byte[4];
   private final byte[] longBuff = new byte[8];

   public long readLongLittleEndian(RandomAccessFile var1) throws IOException {
      var1.readFully(this.longBuff);
      return this.readLongLittleEndian((byte[])this.longBuff, 0);
   }

   public long readLongLittleEndian(RandomAccessFile var1, int var2) throws IOException {
      this.resetBytes(this.longBuff);
      var1.readFully(this.longBuff, 0, var2);
      return this.readLongLittleEndian((byte[])this.longBuff, 0);
   }

   public long readLongLittleEndian(InputStream var1) throws IOException {
      this.readFully(var1, this.longBuff, this.longBuff.length);
      return this.readLongLittleEndian((byte[])this.longBuff, 0);
   }

   public long readLongLittleEndian(InputStream var1, int var2) throws IOException {
      this.resetBytes(this.longBuff);
      this.readFully(var1, this.longBuff, var2);
      return this.readLongLittleEndian((byte[])this.longBuff, 0);
   }

   public long readLongLittleEndian(byte[] var1, int var2) {
      if (var1.length - var2 < 8) {
         this.resetBytes(this.longBuff);
      }

      System.arraycopy(var1, var2, this.longBuff, 0, Math.min(var1.length - var2, 8));
      long var3 = 0L;
      var3 |= (long)(this.longBuff[7] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[6] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[5] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[4] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[3] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[2] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[1] & 255);
      var3 <<= 8;
      var3 |= (long)(this.longBuff[0] & 255);
      return var3;
   }

   public int readIntLittleEndian(RandomAccessFile var1) throws IOException {
      var1.readFully(this.intBuff);
      return this.readIntLittleEndian(this.intBuff);
   }

   public int readIntLittleEndian(InputStream var1) throws IOException {
      this.readFully(var1, this.intBuff, 4);
      return this.readIntLittleEndian(this.intBuff);
   }

   public int readIntLittleEndian(byte[] var1) {
      return this.readIntLittleEndian(var1, 0);
   }

   public int readIntLittleEndian(byte[] var1, int var2) {
      return var1[var2] & 255 | (var1[1 + var2] & 255) << 8 | (var1[2 + var2] & 255 | (var1[3 + var2] & 255) << 8) << 16;
   }

   public int readShortLittleEndian(RandomAccessFile var1) throws IOException {
      var1.readFully(this.shortBuff);
      return this.readShortLittleEndian(this.shortBuff, 0);
   }

   public int readShortLittleEndian(InputStream var1) throws IOException {
      this.readFully(var1, this.shortBuff, this.shortBuff.length);
      return this.readShortLittleEndian(this.shortBuff, 0);
   }

   public int readShortLittleEndian(byte[] var1, int var2) {
      return var1[var2] & 255 | (var1[1 + var2] & 255) << 8;
   }

   public void writeShortLittleEndian(OutputStream var1, int var2) throws IOException {
      this.writeShortLittleEndian(this.shortBuff, 0, var2);
      var1.write(this.shortBuff);
   }

   public void writeShortLittleEndian(byte[] var1, int var2, int var3) {
      var1[var2 + 1] = (byte)(var3 >>> 8);
      var1[var2] = (byte)(var3 & 255);
   }

   public void writeIntLittleEndian(OutputStream var1, int var2) throws IOException {
      this.writeIntLittleEndian(this.intBuff, 0, var2);
      var1.write(this.intBuff);
   }

   public void writeIntLittleEndian(byte[] var1, int var2, int var3) {
      var1[var2 + 3] = (byte)(var3 >>> 24);
      var1[var2 + 2] = (byte)(var3 >>> 16);
      var1[var2 + 1] = (byte)(var3 >>> 8);
      var1[var2] = (byte)(var3 & 255);
   }

   public void writeLongLittleEndian(OutputStream var1, long var2) throws IOException {
      this.writeLongLittleEndian(this.longBuff, 0, var2);
      var1.write(this.longBuff);
   }

   public void writeLongLittleEndian(byte[] var1, int var2, long var3) {
      var1[var2 + 7] = (byte)((int)(var3 >>> 56));
      var1[var2 + 6] = (byte)((int)(var3 >>> 48));
      var1[var2 + 5] = (byte)((int)(var3 >>> 40));
      var1[var2 + 4] = (byte)((int)(var3 >>> 32));
      var1[var2 + 3] = (byte)((int)(var3 >>> 24));
      var1[var2 + 2] = (byte)((int)(var3 >>> 16));
      var1[var2 + 1] = (byte)((int)(var3 >>> 8));
      var1[var2] = (byte)((int)(var3 & 255L));
   }

   private void readFully(InputStream var1, byte[] var2, int var3) throws IOException {
      int var4 = Zip4jUtil.readFully(var1, var2, 0, var3);
      if (var4 != var3) {
         throw new ZipException("Could not fill buffer");
      }
   }

   private void resetBytes(byte[] var1) {
      Arrays.fill(var1, (byte)0);
   }
}
