package net.lingala.zip4j.model;

public class DataDescriptor extends ZipHeader {
   private long crc;
   private long compressedSize;
   private long uncompressedSize;

   public long getCrc() {
      return this.crc;
   }

   public void setCrc(long var1) {
      this.crc = var1;
   }

   public long getCompressedSize() {
      return this.compressedSize;
   }

   public void setCompressedSize(long var1) {
      this.compressedSize = var1;
   }

   public long getUncompressedSize() {
      return this.uncompressedSize;
   }

   public void setUncompressedSize(long var1) {
      this.uncompressedSize = var1;
   }
}
