package net.lingala.zip4j.model;

import java.util.Objects;
import net.lingala.zip4j.headers.HeaderSignature;

public class FileHeader extends AbstractFileHeader {
   private int versionMadeBy;
   private int fileCommentLength = 0;
   private int diskNumberStart;
   private byte[] internalFileAttributes;
   private byte[] externalFileAttributes;
   private long offsetLocalHeader;
   private String fileComment;

   public FileHeader() {
      this.setSignature(HeaderSignature.CENTRAL_DIRECTORY);
   }

   public int getVersionMadeBy() {
      return this.versionMadeBy;
   }

   public void setVersionMadeBy(int var1) {
      this.versionMadeBy = var1;
   }

   public int getFileCommentLength() {
      return this.fileCommentLength;
   }

   public void setFileCommentLength(int var1) {
      this.fileCommentLength = var1;
   }

   public int getDiskNumberStart() {
      return this.diskNumberStart;
   }

   public void setDiskNumberStart(int var1) {
      this.diskNumberStart = var1;
   }

   public byte[] getInternalFileAttributes() {
      return this.internalFileAttributes;
   }

   public void setInternalFileAttributes(byte[] var1) {
      this.internalFileAttributes = var1;
   }

   public byte[] getExternalFileAttributes() {
      return this.externalFileAttributes;
   }

   public void setExternalFileAttributes(byte[] var1) {
      this.externalFileAttributes = var1;
   }

   public long getOffsetLocalHeader() {
      return this.offsetLocalHeader;
   }

   public void setOffsetLocalHeader(long var1) {
      this.offsetLocalHeader = var1;
   }

   public String getFileComment() {
      return this.fileComment;
   }

   public void setFileComment(String var1) {
      this.fileComment = var1;
   }

   public String toString() {
      return this.getFileName();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         if (!super.equals(var1)) {
            return false;
         } else {
            FileHeader var2 = (FileHeader)var1;
            return this.determineOffsetOfLocalFileHeader(this) == this.determineOffsetOfLocalFileHeader(var2);
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getFileName(), this.determineOffsetOfLocalFileHeader(this)});
   }

   private long determineOffsetOfLocalFileHeader(FileHeader var1) {
      return var1.getZip64ExtendedInfo() != null ? var1.getZip64ExtendedInfo().getOffsetLocalHeader() : var1.getOffsetLocalHeader();
   }
}
