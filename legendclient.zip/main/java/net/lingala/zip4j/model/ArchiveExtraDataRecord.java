package net.lingala.zip4j.model;

public class ArchiveExtraDataRecord extends ZipHeader {
   private int extraFieldLength;
   private String extraFieldData;

   public int getExtraFieldLength() {
      return this.extraFieldLength;
   }

   public void setExtraFieldLength(int var1) {
      this.extraFieldLength = var1;
   }

   public String getExtraFieldData() {
      return this.extraFieldData;
   }

   public void setExtraFieldData(String var1) {
      this.extraFieldData = var1;
   }
}
