package net.lingala.zip4j.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ZipModel implements Cloneable {
   private List<LocalFileHeader> localFileHeaders = new ArrayList();
   private List<DataDescriptor> dataDescriptors = new ArrayList();
   private ArchiveExtraDataRecord archiveExtraDataRecord = new ArchiveExtraDataRecord();
   private CentralDirectory centralDirectory = new CentralDirectory();
   private EndOfCentralDirectoryRecord endOfCentralDirectoryRecord = new EndOfCentralDirectoryRecord();
   private Zip64EndOfCentralDirectoryLocator zip64EndOfCentralDirectoryLocator = new Zip64EndOfCentralDirectoryLocator();
   private Zip64EndOfCentralDirectoryRecord zip64EndOfCentralDirectoryRecord = new Zip64EndOfCentralDirectoryRecord();
   private boolean splitArchive;
   private long splitLength = -1L;
   private File zipFile;
   private boolean isZip64Format = false;
   private boolean isNestedZipFile;
   private long start;
   private long end;

   public List<LocalFileHeader> getLocalFileHeaders() {
      return this.localFileHeaders;
   }

   public void setLocalFileHeaders(List<LocalFileHeader> var1) {
      this.localFileHeaders = var1;
   }

   public List<DataDescriptor> getDataDescriptors() {
      return this.dataDescriptors;
   }

   public void setDataDescriptors(List<DataDescriptor> var1) {
      this.dataDescriptors = var1;
   }

   public CentralDirectory getCentralDirectory() {
      return this.centralDirectory;
   }

   public void setCentralDirectory(CentralDirectory var1) {
      this.centralDirectory = var1;
   }

   public EndOfCentralDirectoryRecord getEndOfCentralDirectoryRecord() {
      return this.endOfCentralDirectoryRecord;
   }

   public void setEndOfCentralDirectoryRecord(EndOfCentralDirectoryRecord var1) {
      this.endOfCentralDirectoryRecord = var1;
   }

   public ArchiveExtraDataRecord getArchiveExtraDataRecord() {
      return this.archiveExtraDataRecord;
   }

   public void setArchiveExtraDataRecord(ArchiveExtraDataRecord var1) {
      this.archiveExtraDataRecord = var1;
   }

   public boolean isSplitArchive() {
      return this.splitArchive;
   }

   public void setSplitArchive(boolean var1) {
      this.splitArchive = var1;
   }

   public File getZipFile() {
      return this.zipFile;
   }

   public void setZipFile(File var1) {
      this.zipFile = var1;
   }

   public Zip64EndOfCentralDirectoryLocator getZip64EndOfCentralDirectoryLocator() {
      return this.zip64EndOfCentralDirectoryLocator;
   }

   public void setZip64EndOfCentralDirectoryLocator(Zip64EndOfCentralDirectoryLocator var1) {
      this.zip64EndOfCentralDirectoryLocator = var1;
   }

   public Zip64EndOfCentralDirectoryRecord getZip64EndOfCentralDirectoryRecord() {
      return this.zip64EndOfCentralDirectoryRecord;
   }

   public void setZip64EndOfCentralDirectoryRecord(Zip64EndOfCentralDirectoryRecord var1) {
      this.zip64EndOfCentralDirectoryRecord = var1;
   }

   public boolean isZip64Format() {
      return this.isZip64Format;
   }

   public void setZip64Format(boolean var1) {
      this.isZip64Format = var1;
   }

   public boolean isNestedZipFile() {
      return this.isNestedZipFile;
   }

   public void setNestedZipFile(boolean var1) {
      this.isNestedZipFile = var1;
   }

   public long getStart() {
      return this.start;
   }

   public void setStart(long var1) {
      this.start = var1;
   }

   public long getEnd() {
      return this.end;
   }

   public void setEnd(long var1) {
      this.end = var1;
   }

   public long getSplitLength() {
      return this.splitLength;
   }

   public void setSplitLength(long var1) {
      this.splitLength = var1;
   }

   public Object clone() throws CloneNotSupportedException {
      return super.clone();
   }
}
