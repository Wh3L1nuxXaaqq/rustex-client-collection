package net.lingala.zip4j.model;

import java.nio.charset.Charset;

public class Zip4jConfig {
   private final Charset charset;
   private final int bufferSize;
   private final boolean useUtf8CharsetForPasswords;

   public Zip4jConfig(Charset var1, int var2, boolean var3) {
      this.charset = var1;
      this.bufferSize = var2;
      this.useUtf8CharsetForPasswords = var3;
   }

   public Charset getCharset() {
      return this.charset;
   }

   public int getBufferSize() {
      return this.bufferSize;
   }

   public boolean isUseUtf8CharsetForPasswords() {
      return this.useUtf8CharsetForPasswords;
   }
}
