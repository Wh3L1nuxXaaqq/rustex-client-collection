package net.lingala.zip4j.model;

import net.lingala.zip4j.headers.HeaderSignature;

public class LocalFileHeader extends AbstractFileHeader {
   private byte[] extraField;
   private long offsetStartOfData;
   private boolean writeCompressedSizeInZip64ExtraRecord;

   public LocalFileHeader() {
      this.setSignature(HeaderSignature.LOCAL_FILE_HEADER);
   }

   public byte[] getExtraField() {
      return this.extraField;
   }

   public void setExtraField(byte[] var1) {
      this.extraField = var1;
   }

   public long getOffsetStartOfData() {
      return this.offsetStartOfData;
   }

   public void setOffsetStartOfData(long var1) {
      this.offsetStartOfData = var1;
   }

   public boolean isWriteCompressedSizeInZip64ExtraRecord() {
      return this.writeCompressedSizeInZip64ExtraRecord;
   }

   public void setWriteCompressedSizeInZip64ExtraRecord(boolean var1) {
      this.writeCompressedSizeInZip64ExtraRecord = var1;
   }
}
