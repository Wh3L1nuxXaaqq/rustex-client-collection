package net.lingala.zip4j.model;

import java.util.List;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.util.Zip4jUtil;

public abstract class AbstractFileHeader extends ZipHeader {
   private int versionNeededToExtract;
   private byte[] generalPurposeFlag;
   private CompressionMethod compressionMethod;
   private long lastModifiedTime;
   private long crc = 0L;
   private long compressedSize = 0L;
   private long uncompressedSize = 0L;
   private int fileNameLength;
   private int extraFieldLength;
   private String fileName;
   private boolean isEncrypted;
   private EncryptionMethod encryptionMethod;
   private boolean dataDescriptorExists;
   private Zip64ExtendedInfo zip64ExtendedInfo;
   private AESExtraDataRecord aesExtraDataRecord;
   private boolean fileNameUTF8Encoded;
   private List<ExtraDataRecord> extraDataRecords;
   private boolean isDirectory;

   public AbstractFileHeader() {
      this.encryptionMethod = EncryptionMethod.NONE;
   }

   public int getVersionNeededToExtract() {
      return this.versionNeededToExtract;
   }

   public void setVersionNeededToExtract(int var1) {
      this.versionNeededToExtract = var1;
   }

   public byte[] getGeneralPurposeFlag() {
      return this.generalPurposeFlag;
   }

   public void setGeneralPurposeFlag(byte[] var1) {
      this.generalPurposeFlag = var1;
   }

   public CompressionMethod getCompressionMethod() {
      return this.compressionMethod;
   }

   public void setCompressionMethod(CompressionMethod var1) {
      this.compressionMethod = var1;
   }

   public long getLastModifiedTime() {
      return this.lastModifiedTime;
   }

   public void setLastModifiedTime(long var1) {
      this.lastModifiedTime = var1;
   }

   public long getLastModifiedTimeEpoch() {
      return Zip4jUtil.dosToExtendedEpochTme(this.lastModifiedTime);
   }

   public long getCrc() {
      return this.crc;
   }

   public void setCrc(long var1) {
      this.crc = var1;
   }

   public long getCompressedSize() {
      return this.compressedSize;
   }

   public void setCompressedSize(long var1) {
      this.compressedSize = var1;
   }

   public long getUncompressedSize() {
      return this.uncompressedSize;
   }

   public void setUncompressedSize(long var1) {
      this.uncompressedSize = var1;
   }

   public int getFileNameLength() {
      return this.fileNameLength;
   }

   public void setFileNameLength(int var1) {
      this.fileNameLength = var1;
   }

   public int getExtraFieldLength() {
      return this.extraFieldLength;
   }

   public void setExtraFieldLength(int var1) {
      this.extraFieldLength = var1;
   }

   public String getFileName() {
      return this.fileName;
   }

   public void setFileName(String var1) {
      this.fileName = var1;
   }

   public boolean isEncrypted() {
      return this.isEncrypted;
   }

   public void setEncrypted(boolean var1) {
      this.isEncrypted = var1;
   }

   public EncryptionMethod getEncryptionMethod() {
      return this.encryptionMethod;
   }

   public void setEncryptionMethod(EncryptionMethod var1) {
      this.encryptionMethod = var1;
   }

   public boolean isDataDescriptorExists() {
      return this.dataDescriptorExists;
   }

   public void setDataDescriptorExists(boolean var1) {
      this.dataDescriptorExists = var1;
   }

   public Zip64ExtendedInfo getZip64ExtendedInfo() {
      return this.zip64ExtendedInfo;
   }

   public void setZip64ExtendedInfo(Zip64ExtendedInfo var1) {
      this.zip64ExtendedInfo = var1;
   }

   public AESExtraDataRecord getAesExtraDataRecord() {
      return this.aesExtraDataRecord;
   }

   public void setAesExtraDataRecord(AESExtraDataRecord var1) {
      this.aesExtraDataRecord = var1;
   }

   public boolean isFileNameUTF8Encoded() {
      return this.fileNameUTF8Encoded;
   }

   public void setFileNameUTF8Encoded(boolean var1) {
      this.fileNameUTF8Encoded = var1;
   }

   public List<ExtraDataRecord> getExtraDataRecords() {
      return this.extraDataRecords;
   }

   public void setExtraDataRecords(List<ExtraDataRecord> var1) {
      this.extraDataRecords = var1;
   }

   public boolean isDirectory() {
      return this.isDirectory;
   }

   public void setDirectory(boolean var1) {
      this.isDirectory = var1;
   }

   public boolean equals(Object var1) {
      if (var1 == null) {
         return false;
      } else {
         return !(var1 instanceof AbstractFileHeader) ? false : this.getFileName().equals(((AbstractFileHeader)var1).getFileName());
      }
   }
}
