package net.lingala.zip4j.model;

import net.lingala.zip4j.headers.HeaderSignature;

public class EndOfCentralDirectoryRecord extends ZipHeader {
   private int numberOfThisDisk;
   private int numberOfThisDiskStartOfCentralDir;
   private int totalNumberOfEntriesInCentralDirectoryOnThisDisk;
   private int totalNumberOfEntriesInCentralDirectory;
   private int sizeOfCentralDirectory;
   private long offsetOfStartOfCentralDirectory;
   private long offsetOfEndOfCentralDirectory;
   private String comment = "";

   public EndOfCentralDirectoryRecord() {
      this.setSignature(HeaderSignature.END_OF_CENTRAL_DIRECTORY);
   }

   public int getNumberOfThisDisk() {
      return this.numberOfThisDisk;
   }

   public void setNumberOfThisDisk(int var1) {
      this.numberOfThisDisk = var1;
   }

   public int getNumberOfThisDiskStartOfCentralDir() {
      return this.numberOfThisDiskStartOfCentralDir;
   }

   public void setNumberOfThisDiskStartOfCentralDir(int var1) {
      this.numberOfThisDiskStartOfCentralDir = var1;
   }

   public int getTotalNumberOfEntriesInCentralDirectoryOnThisDisk() {
      return this.totalNumberOfEntriesInCentralDirectoryOnThisDisk;
   }

   public void setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(int var1) {
      this.totalNumberOfEntriesInCentralDirectoryOnThisDisk = var1;
   }

   public int getTotalNumberOfEntriesInCentralDirectory() {
      return this.totalNumberOfEntriesInCentralDirectory;
   }

   public void setTotalNumberOfEntriesInCentralDirectory(int var1) {
      this.totalNumberOfEntriesInCentralDirectory = var1;
   }

   public int getSizeOfCentralDirectory() {
      return this.sizeOfCentralDirectory;
   }

   public void setSizeOfCentralDirectory(int var1) {
      this.sizeOfCentralDirectory = var1;
   }

   public long getOffsetOfStartOfCentralDirectory() {
      return this.offsetOfStartOfCentralDirectory;
   }

   public void setOffsetOfStartOfCentralDirectory(long var1) {
      this.offsetOfStartOfCentralDirectory = var1;
   }

   public long getOffsetOfEndOfCentralDirectory() {
      return this.offsetOfEndOfCentralDirectory;
   }

   public void setOffsetOfEndOfCentralDirectory(long var1) {
      this.offsetOfEndOfCentralDirectory = var1;
   }

   public String getComment() {
      return this.comment;
   }

   public void setComment(String var1) {
      if (var1 != null) {
         this.comment = var1;
      }

   }
}
