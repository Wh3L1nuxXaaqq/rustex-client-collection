package net.lingala.zip4j.model;

import java.util.ArrayList;
import java.util.List;

public class CentralDirectory {
   private List<FileHeader> fileHeaders = new ArrayList();
   private DigitalSignature digitalSignature = new DigitalSignature();

   public List<FileHeader> getFileHeaders() {
      return this.fileHeaders;
   }

   public void setFileHeaders(List<FileHeader> var1) {
      this.fileHeaders = var1;
   }

   public DigitalSignature getDigitalSignature() {
      return this.digitalSignature;
   }

   public void setDigitalSignature(DigitalSignature var1) {
      this.digitalSignature = var1;
   }
}
