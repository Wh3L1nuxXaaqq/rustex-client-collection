package net.lingala.zip4j.model;

public class DigitalSignature extends ZipHeader {
   private int sizeOfData;
   private String signatureData;

   public int getSizeOfData() {
      return this.sizeOfData;
   }

   public void setSizeOfData(int var1) {
      this.sizeOfData = var1;
   }

   public String getSignatureData() {
      return this.signatureData;
   }

   public void setSignatureData(String var1) {
      this.signatureData = var1;
   }
}
