package net.lingala.zip4j.model;

public class Zip64EndOfCentralDirectoryRecord extends ZipHeader {
   private long sizeOfZip64EndCentralDirectoryRecord;
   private int versionMadeBy;
   private int versionNeededToExtract;
   private int numberOfThisDisk;
   private int numberOfThisDiskStartOfCentralDirectory;
   private long totalNumberOfEntriesInCentralDirectoryOnThisDisk;
   private long totalNumberOfEntriesInCentralDirectory;
   private long sizeOfCentralDirectory;
   private long offsetStartCentralDirectoryWRTStartDiskNumber = -1L;
   private byte[] extensibleDataSector;

   public long getSizeOfZip64EndCentralDirectoryRecord() {
      return this.sizeOfZip64EndCentralDirectoryRecord;
   }

   public void setSizeOfZip64EndCentralDirectoryRecord(long var1) {
      this.sizeOfZip64EndCentralDirectoryRecord = var1;
   }

   public int getVersionMadeBy() {
      return this.versionMadeBy;
   }

   public void setVersionMadeBy(int var1) {
      this.versionMadeBy = var1;
   }

   public int getVersionNeededToExtract() {
      return this.versionNeededToExtract;
   }

   public void setVersionNeededToExtract(int var1) {
      this.versionNeededToExtract = var1;
   }

   public int getNumberOfThisDisk() {
      return this.numberOfThisDisk;
   }

   public void setNumberOfThisDisk(int var1) {
      this.numberOfThisDisk = var1;
   }

   public int getNumberOfThisDiskStartOfCentralDirectory() {
      return this.numberOfThisDiskStartOfCentralDirectory;
   }

   public void setNumberOfThisDiskStartOfCentralDirectory(int var1) {
      this.numberOfThisDiskStartOfCentralDirectory = var1;
   }

   public long getTotalNumberOfEntriesInCentralDirectoryOnThisDisk() {
      return this.totalNumberOfEntriesInCentralDirectoryOnThisDisk;
   }

   public void setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(long var1) {
      this.totalNumberOfEntriesInCentralDirectoryOnThisDisk = var1;
   }

   public long getTotalNumberOfEntriesInCentralDirectory() {
      return this.totalNumberOfEntriesInCentralDirectory;
   }

   public void setTotalNumberOfEntriesInCentralDirectory(long var1) {
      this.totalNumberOfEntriesInCentralDirectory = var1;
   }

   public long getSizeOfCentralDirectory() {
      return this.sizeOfCentralDirectory;
   }

   public void setSizeOfCentralDirectory(long var1) {
      this.sizeOfCentralDirectory = var1;
   }

   public long getOffsetStartCentralDirectoryWRTStartDiskNumber() {
      return this.offsetStartCentralDirectoryWRTStartDiskNumber;
   }

   public void setOffsetStartCentralDirectoryWRTStartDiskNumber(long var1) {
      this.offsetStartCentralDirectoryWRTStartDiskNumber = var1;
   }

   public byte[] getExtensibleDataSector() {
      return this.extensibleDataSector;
   }

   public void setExtensibleDataSector(byte[] var1) {
      this.extensibleDataSector = var1;
   }
}
