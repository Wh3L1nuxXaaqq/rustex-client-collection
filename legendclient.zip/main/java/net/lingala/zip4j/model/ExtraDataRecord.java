package net.lingala.zip4j.model;

public class ExtraDataRecord extends ZipHeader {
   private long header;
   private int sizeOfData;
   private byte[] data;

   public long getHeader() {
      return this.header;
   }

   public void setHeader(long var1) {
      this.header = var1;
   }

   public int getSizeOfData() {
      return this.sizeOfData;
   }

   public void setSizeOfData(int var1) {
      this.sizeOfData = var1;
   }

   public byte[] getData() {
      return this.data;
   }

   public void setData(byte[] var1) {
      this.data = var1;
   }
}
