package net.lingala.zip4j.model.enums;

public enum RandomAccessFileMode {
   READ("r"),
   WRITE("rw");

   private String value;

   private RandomAccessFileMode(String var3) {
      this.value = var3;
   }

   public String getValue() {
      return this.value;
   }
}
