package net.lingala.zip4j.model.enums;

import net.lingala.zip4j.exception.ZipException;

public enum CompressionMethod {
   STORE(0),
   DEFLATE(8),
   AES_INTERNAL_ONLY(99);

   private int code;

   private CompressionMethod(int var3) {
      this.code = var3;
   }

   public int getCode() {
      return this.code;
   }

   public static CompressionMethod getCompressionMethodFromCode(int var0) throws ZipException {
      for(CompressionMethod var4 : values()) {
         if (var4.getCode() == var0) {
            return var4;
         }
      }

      throw new ZipException("Unknown compression method", ZipException.Type.UNKNOWN_COMPRESSION_METHOD);
   }
}
