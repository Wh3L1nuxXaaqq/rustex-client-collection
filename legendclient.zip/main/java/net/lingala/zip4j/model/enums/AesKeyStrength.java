package net.lingala.zip4j.model.enums;

public enum AesKeyStrength {
   KEY_STRENGTH_128(1, 8, 16, 16),
   KEY_STRENGTH_192(2, 12, 24, 24),
   KEY_STRENGTH_256(3, 16, 32, 32);

   private int rawCode;
   private int saltLength;
   private int macLength;
   private int keyLength;

   private AesKeyStrength(int var3, int var4, int var5, int var6) {
      this.rawCode = var3;
      this.saltLength = var4;
      this.macLength = var5;
      this.keyLength = var6;
   }

   public int getRawCode() {
      return this.rawCode;
   }

   public int getSaltLength() {
      return this.saltLength;
   }

   public int getMacLength() {
      return this.macLength;
   }

   public int getKeyLength() {
      return this.keyLength;
   }

   public static AesKeyStrength getAesKeyStrengthFromRawCode(int var0) {
      for(AesKeyStrength var4 : values()) {
         if (var4.getRawCode() == var0) {
            return var4;
         }
      }

      return null;
   }
}
