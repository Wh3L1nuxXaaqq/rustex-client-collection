package net.lingala.zip4j.model.enums;

import net.lingala.zip4j.exception.ZipException;

public enum AesVersion {
   ONE(1),
   TWO(2);

   private int versionNumber;

   private AesVersion(int var3) {
      this.versionNumber = var3;
   }

   public int getVersionNumber() {
      return this.versionNumber;
   }

   public static AesVersion getFromVersionNumber(int var0) throws ZipException {
      for(AesVersion var4 : values()) {
         if (var4.versionNumber == var0) {
            return var4;
         }
      }

      throw new ZipException("Unsupported Aes version");
   }
}
