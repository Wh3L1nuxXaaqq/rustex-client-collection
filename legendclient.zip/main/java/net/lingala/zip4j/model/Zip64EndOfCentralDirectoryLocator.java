package net.lingala.zip4j.model;

public class Zip64EndOfCentralDirectoryLocator extends ZipHeader {
   private int numberOfDiskStartOfZip64EndOfCentralDirectoryRecord;
   private long offsetZip64EndOfCentralDirectoryRecord;
   private int totalNumberOfDiscs;

   public int getNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord() {
      return this.numberOfDiskStartOfZip64EndOfCentralDirectoryRecord;
   }

   public void setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(int var1) {
      this.numberOfDiskStartOfZip64EndOfCentralDirectoryRecord = var1;
   }

   public long getOffsetZip64EndOfCentralDirectoryRecord() {
      return this.offsetZip64EndOfCentralDirectoryRecord;
   }

   public void setOffsetZip64EndOfCentralDirectoryRecord(long var1) {
      this.offsetZip64EndOfCentralDirectoryRecord = var1;
   }

   public int getTotalNumberOfDiscs() {
      return this.totalNumberOfDiscs;
   }

   public void setTotalNumberOfDiscs(int var1) {
      this.totalNumberOfDiscs = var1;
   }
}
