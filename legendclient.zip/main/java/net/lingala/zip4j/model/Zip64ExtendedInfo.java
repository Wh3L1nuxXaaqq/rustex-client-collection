package net.lingala.zip4j.model;

public class Zip64ExtendedInfo extends ZipHeader {
   private int size;
   private long compressedSize = -1L;
   private long uncompressedSize = -1L;
   private long offsetLocalHeader = -1L;
   private int diskNumberStart = -1;

   public int getSize() {
      return this.size;
   }

   public void setSize(int var1) {
      this.size = var1;
   }

   public long getCompressedSize() {
      return this.compressedSize;
   }

   public void setCompressedSize(long var1) {
      this.compressedSize = var1;
   }

   public long getUncompressedSize() {
      return this.uncompressedSize;
   }

   public void setUncompressedSize(long var1) {
      this.uncompressedSize = var1;
   }

   public long getOffsetLocalHeader() {
      return this.offsetLocalHeader;
   }

   public void setOffsetLocalHeader(long var1) {
      this.offsetLocalHeader = var1;
   }

   public int getDiskNumberStart() {
      return this.diskNumberStart;
   }

   public void setDiskNumberStart(int var1) {
      this.diskNumberStart = var1;
   }
}
