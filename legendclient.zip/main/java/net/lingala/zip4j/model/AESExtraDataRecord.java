package net.lingala.zip4j.model;

import net.lingala.zip4j.headers.HeaderSignature;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.AesVersion;
import net.lingala.zip4j.model.enums.CompressionMethod;

public class AESExtraDataRecord extends ZipHeader {
   private int dataSize;
   private AesVersion aesVersion;
   private String vendorID;
   private AesKeyStrength aesKeyStrength;
   private CompressionMethod compressionMethod;

   public AESExtraDataRecord() {
      this.setSignature(HeaderSignature.AES_EXTRA_DATA_RECORD);
      this.dataSize = 7;
      this.aesVersion = AesVersion.TWO;
      this.vendorID = "AE";
      this.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256;
      this.compressionMethod = CompressionMethod.DEFLATE;
   }

   public int getDataSize() {
      return this.dataSize;
   }

   public void setDataSize(int var1) {
      this.dataSize = var1;
   }

   public AesVersion getAesVersion() {
      return this.aesVersion;
   }

   public void setAesVersion(AesVersion var1) {
      this.aesVersion = var1;
   }

   public String getVendorID() {
      return this.vendorID;
   }

   public void setVendorID(String var1) {
      this.vendorID = var1;
   }

   public AesKeyStrength getAesKeyStrength() {
      return this.aesKeyStrength;
   }

   public void setAesKeyStrength(AesKeyStrength var1) {
      this.aesKeyStrength = var1;
   }

   public CompressionMethod getCompressionMethod() {
      return this.compressionMethod;
   }

   public void setCompressionMethod(CompressionMethod var1) {
      this.compressionMethod = var1;
   }
}
