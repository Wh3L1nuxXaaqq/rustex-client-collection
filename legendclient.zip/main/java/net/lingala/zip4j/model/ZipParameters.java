package net.lingala.zip4j.model;

import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.AesVersion;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

public class ZipParameters {
   private CompressionMethod compressionMethod;
   private CompressionLevel compressionLevel;
   private boolean encryptFiles;
   private EncryptionMethod encryptionMethod;
   private boolean readHiddenFiles;
   private boolean readHiddenFolders;
   private AesKeyStrength aesKeyStrength;
   private AesVersion aesVersion;
   private boolean includeRootFolder;
   private long entryCRC;
   private String defaultFolderPath;
   private String fileNameInZip;
   private long lastModifiedFileTime;
   private long entrySize;
   private boolean writeExtendedLocalFileHeader;
   private boolean overrideExistingFilesInZip;
   private String rootFolderNameInZip;
   private String fileComment;
   private SymbolicLinkAction symbolicLinkAction;
   private ExcludeFileFilter excludeFileFilter;
   private boolean unixMode;

   public ZipParameters() {
      this.compressionMethod = CompressionMethod.DEFLATE;
      this.compressionLevel = CompressionLevel.NORMAL;
      this.encryptFiles = false;
      this.encryptionMethod = EncryptionMethod.NONE;
      this.readHiddenFiles = true;
      this.readHiddenFolders = true;
      this.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256;
      this.aesVersion = AesVersion.TWO;
      this.includeRootFolder = true;
      this.lastModifiedFileTime = 0L;
      this.entrySize = -1L;
      this.writeExtendedLocalFileHeader = true;
      this.overrideExistingFilesInZip = true;
      this.symbolicLinkAction = ZipParameters.SymbolicLinkAction.INCLUDE_LINKED_FILE_ONLY;
   }

   public ZipParameters(ZipParameters var1) {
      this.compressionMethod = CompressionMethod.DEFLATE;
      this.compressionLevel = CompressionLevel.NORMAL;
      this.encryptFiles = false;
      this.encryptionMethod = EncryptionMethod.NONE;
      this.readHiddenFiles = true;
      this.readHiddenFolders = true;
      this.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256;
      this.aesVersion = AesVersion.TWO;
      this.includeRootFolder = true;
      this.lastModifiedFileTime = 0L;
      this.entrySize = -1L;
      this.writeExtendedLocalFileHeader = true;
      this.overrideExistingFilesInZip = true;
      this.symbolicLinkAction = ZipParameters.SymbolicLinkAction.INCLUDE_LINKED_FILE_ONLY;
      this.compressionMethod = var1.getCompressionMethod();
      this.compressionLevel = var1.getCompressionLevel();
      this.encryptFiles = var1.isEncryptFiles();
      this.encryptionMethod = var1.getEncryptionMethod();
      this.readHiddenFiles = var1.isReadHiddenFiles();
      this.readHiddenFolders = var1.isReadHiddenFolders();
      this.aesKeyStrength = var1.getAesKeyStrength();
      this.aesVersion = var1.getAesVersion();
      this.includeRootFolder = var1.isIncludeRootFolder();
      this.entryCRC = var1.getEntryCRC();
      this.defaultFolderPath = var1.getDefaultFolderPath();
      this.fileNameInZip = var1.getFileNameInZip();
      this.lastModifiedFileTime = var1.getLastModifiedFileTime();
      this.entrySize = var1.getEntrySize();
      this.writeExtendedLocalFileHeader = var1.isWriteExtendedLocalFileHeader();
      this.overrideExistingFilesInZip = var1.isOverrideExistingFilesInZip();
      this.rootFolderNameInZip = var1.getRootFolderNameInZip();
      this.fileComment = var1.getFileComment();
      this.symbolicLinkAction = var1.getSymbolicLinkAction();
      this.excludeFileFilter = var1.getExcludeFileFilter();
      this.unixMode = var1.isUnixMode();
   }

   public CompressionMethod getCompressionMethod() {
      return this.compressionMethod;
   }

   public void setCompressionMethod(CompressionMethod var1) {
      this.compressionMethod = var1;
   }

   public boolean isEncryptFiles() {
      return this.encryptFiles;
   }

   public void setEncryptFiles(boolean var1) {
      this.encryptFiles = var1;
   }

   public EncryptionMethod getEncryptionMethod() {
      return this.encryptionMethod;
   }

   public void setEncryptionMethod(EncryptionMethod var1) {
      this.encryptionMethod = var1;
   }

   public CompressionLevel getCompressionLevel() {
      return this.compressionLevel;
   }

   public void setCompressionLevel(CompressionLevel var1) {
      this.compressionLevel = var1;
   }

   public boolean isReadHiddenFiles() {
      return this.readHiddenFiles;
   }

   public void setReadHiddenFiles(boolean var1) {
      this.readHiddenFiles = var1;
   }

   public boolean isReadHiddenFolders() {
      return this.readHiddenFolders;
   }

   public void setReadHiddenFolders(boolean var1) {
      this.readHiddenFolders = var1;
   }

   public AesKeyStrength getAesKeyStrength() {
      return this.aesKeyStrength;
   }

   public void setAesKeyStrength(AesKeyStrength var1) {
      this.aesKeyStrength = var1;
   }

   public AesVersion getAesVersion() {
      return this.aesVersion;
   }

   public void setAesVersion(AesVersion var1) {
      this.aesVersion = var1;
   }

   public boolean isIncludeRootFolder() {
      return this.includeRootFolder;
   }

   public void setIncludeRootFolder(boolean var1) {
      this.includeRootFolder = var1;
   }

   public long getEntryCRC() {
      return this.entryCRC;
   }

   public void setEntryCRC(long var1) {
      this.entryCRC = var1;
   }

   public String getDefaultFolderPath() {
      return this.defaultFolderPath;
   }

   public void setDefaultFolderPath(String var1) {
      this.defaultFolderPath = var1;
   }

   public String getFileNameInZip() {
      return this.fileNameInZip;
   }

   public void setFileNameInZip(String var1) {
      this.fileNameInZip = var1;
   }

   public long getLastModifiedFileTime() {
      return this.lastModifiedFileTime;
   }

   public void setLastModifiedFileTime(long var1) {
      if (var1 < 0L) {
         this.lastModifiedFileTime = 0L;
      } else {
         this.lastModifiedFileTime = var1;
      }
   }

   public long getEntrySize() {
      return this.entrySize;
   }

   public void setEntrySize(long var1) {
      this.entrySize = var1;
   }

   public boolean isWriteExtendedLocalFileHeader() {
      return this.writeExtendedLocalFileHeader;
   }

   public void setWriteExtendedLocalFileHeader(boolean var1) {
      this.writeExtendedLocalFileHeader = var1;
   }

   public boolean isOverrideExistingFilesInZip() {
      return this.overrideExistingFilesInZip;
   }

   public void setOverrideExistingFilesInZip(boolean var1) {
      this.overrideExistingFilesInZip = var1;
   }

   public String getRootFolderNameInZip() {
      return this.rootFolderNameInZip;
   }

   public void setRootFolderNameInZip(String var1) {
      this.rootFolderNameInZip = var1;
   }

   public String getFileComment() {
      return this.fileComment;
   }

   public void setFileComment(String var1) {
      this.fileComment = var1;
   }

   public SymbolicLinkAction getSymbolicLinkAction() {
      return this.symbolicLinkAction;
   }

   public void setSymbolicLinkAction(SymbolicLinkAction var1) {
      this.symbolicLinkAction = var1;
   }

   public ExcludeFileFilter getExcludeFileFilter() {
      return this.excludeFileFilter;
   }

   public void setExcludeFileFilter(ExcludeFileFilter var1) {
      this.excludeFileFilter = var1;
   }

   public boolean isUnixMode() {
      return this.unixMode;
   }

   public void setUnixMode(boolean var1) {
      this.unixMode = var1;
   }

   public static enum SymbolicLinkAction {
      INCLUDE_LINK_ONLY,
      INCLUDE_LINKED_FILE_ONLY,
      INCLUDE_LINK_AND_LINKED_FILE;
   }
}
