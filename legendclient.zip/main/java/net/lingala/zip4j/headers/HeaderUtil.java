package net.lingala.zip4j.headers;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jUtil;

public class HeaderUtil {
   public static FileHeader getFileHeader(ZipModel var0, String var1) throws ZipException {
      FileHeader var2 = getFileHeaderWithExactMatch(var0, var1);
      if (var2 == null) {
         var1 = var1.replaceAll("\\\\", "/");
         var2 = getFileHeaderWithExactMatch(var0, var1);
         if (var2 == null) {
            var1 = var1.replaceAll("/", "\\\\");
            var2 = getFileHeaderWithExactMatch(var0, var1);
         }
      }

      return var2;
   }

   public static String decodeStringWithCharset(byte[] var0, boolean var1, Charset var2) {
      if (var2 != null) {
         return new String(var0, var2);
      } else if (var1) {
         return new String(var0, InternalZipConstants.CHARSET_UTF_8);
      } else {
         try {
            return new String(var0, "Cp437");
         } catch (UnsupportedEncodingException var4) {
            return new String(var0);
         }
      }
   }

   public static byte[] getBytesFromString(String var0, Charset var1) {
      return var1 == null ? var0.getBytes(InternalZipConstants.ZIP4J_DEFAULT_CHARSET) : var0.getBytes(var1);
   }

   public static long getOffsetStartOfCentralDirectory(ZipModel var0) {
      return var0.isZip64Format() ? var0.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber() : var0.getEndOfCentralDirectoryRecord().getOffsetOfStartOfCentralDirectory();
   }

   public static List<FileHeader> getFileHeadersUnderDirectory(List<FileHeader> var0, String var1) {
      ArrayList var2 = new ArrayList();

      for(FileHeader var4 : var0) {
         if (var4.getFileName().startsWith(var1)) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public static long getTotalUncompressedSizeOfAllFileHeaders(List<FileHeader> var0) {
      long var1 = 0L;

      for(FileHeader var4 : var0) {
         if (var4.getZip64ExtendedInfo() != null && var4.getZip64ExtendedInfo().getUncompressedSize() > 0L) {
            var1 += var4.getZip64ExtendedInfo().getUncompressedSize();
         } else {
            var1 += var4.getUncompressedSize();
         }
      }

      return var1;
   }

   private static FileHeader getFileHeaderWithExactMatch(ZipModel var0, String var1) throws ZipException {
      if (var0 == null) {
         throw new ZipException("zip model is null, cannot determine file header with exact match for fileName: " + var1);
      } else if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("file name is null, cannot determine file header with exact match for fileName: " + var1);
      } else if (var0.getCentralDirectory() == null) {
         throw new ZipException("central directory is null, cannot determine file header with exact match for fileName: " + var1);
      } else if (var0.getCentralDirectory().getFileHeaders() == null) {
         throw new ZipException("file Headers are null, cannot determine file header with exact match for fileName: " + var1);
      } else if (var0.getCentralDirectory().getFileHeaders().size() == 0) {
         return null;
      } else {
         for(FileHeader var3 : var0.getCentralDirectory().getFileHeaders()) {
            String var4 = var3.getFileName();
            if (Zip4jUtil.isStringNotNullAndNotEmpty(var4) && var1.equals(var4)) {
               return var3;
            }
         }

         return null;
      }
   }
}
