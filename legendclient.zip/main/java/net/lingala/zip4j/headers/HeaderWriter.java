package net.lingala.zip4j.headers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.outputstream.CountingOutputStream;
import net.lingala.zip4j.io.outputstream.OutputStreamWithSplitZipSupport;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.ExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryLocator;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.Zip4jUtil;

public class HeaderWriter {
   private static final short ZIP64_EXTRA_DATA_RECORD_SIZE_LFH = 16;
   private static final short ZIP64_EXTRA_DATA_RECORD_SIZE_FH = 28;
   private static final short AES_EXTRA_DATA_RECORD_SIZE = 11;
   private final RawIO rawIO = new RawIO();
   private final byte[] longBuff = new byte[8];
   private final byte[] intBuff = new byte[4];

   public void writeLocalFileHeader(ZipModel var1, LocalFileHeader var2, OutputStream var3, Charset var4) throws IOException {
      ByteArrayOutputStream var5 = new ByteArrayOutputStream();
      Throwable var6 = null;

      try {
         this.rawIO.writeIntLittleEndian(var5, (int)var2.getSignature().getValue());
         this.rawIO.writeShortLittleEndian(var5, var2.getVersionNeededToExtract());
         var5.write(var2.getGeneralPurposeFlag());
         this.rawIO.writeShortLittleEndian(var5, var2.getCompressionMethod().getCode());
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getLastModifiedTime());
         var5.write(this.longBuff, 0, 4);
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getCrc());
         var5.write(this.longBuff, 0, 4);
         boolean var7 = var2.getCompressedSize() >= 4294967295L || var2.getUncompressedSize() >= 4294967295L;
         if (var7) {
            this.rawIO.writeLongLittleEndian(this.longBuff, 0, 4294967295L);
            var5.write(this.longBuff, 0, 4);
            var5.write(this.longBuff, 0, 4);
            var1.setZip64Format(true);
            var2.setWriteCompressedSizeInZip64ExtraRecord(true);
         } else {
            this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getCompressedSize());
            var5.write(this.longBuff, 0, 4);
            this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getUncompressedSize());
            var5.write(this.longBuff, 0, 4);
            var2.setWriteCompressedSizeInZip64ExtraRecord(false);
         }

         byte[] var8 = new byte[0];
         if (Zip4jUtil.isStringNotNullAndNotEmpty(var2.getFileName())) {
            var8 = HeaderUtil.getBytesFromString(var2.getFileName(), var4);
         }

         this.rawIO.writeShortLittleEndian(var5, var8.length);
         int var9 = 0;
         if (var7) {
            var9 += 20;
         }

         if (var2.getAesExtraDataRecord() != null) {
            var9 += 11;
         }

         this.rawIO.writeShortLittleEndian(var5, var9);
         if (var8.length > 0) {
            var5.write(var8);
         }

         if (var7) {
            this.rawIO.writeShortLittleEndian(var5, (int)HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue());
            this.rawIO.writeShortLittleEndian(var5, 16);
            this.rawIO.writeLongLittleEndian(var5, var2.getUncompressedSize());
            this.rawIO.writeLongLittleEndian(var5, var2.getCompressedSize());
         }

         if (var2.getAesExtraDataRecord() != null) {
            AESExtraDataRecord var10 = var2.getAesExtraDataRecord();
            this.rawIO.writeShortLittleEndian(var5, (int)var10.getSignature().getValue());
            this.rawIO.writeShortLittleEndian(var5, var10.getDataSize());
            this.rawIO.writeShortLittleEndian(var5, var10.getAesVersion().getVersionNumber());
            var5.write(HeaderUtil.getBytesFromString(var10.getVendorID(), var4));
            byte[] var11 = new byte[]{(byte)var10.getAesKeyStrength().getRawCode()};
            var5.write(var11);
            this.rawIO.writeShortLittleEndian(var5, var10.getCompressionMethod().getCode());
         }

         var3.write(var5.toByteArray());
      } catch (Throwable var19) {
         var6 = var19;
         throw var19;
      } finally {
         if (var5 != null) {
            if (var6 != null) {
               try {
                  var5.close();
               } catch (Throwable var18) {
                  var6.addSuppressed(var18);
               }
            } else {
               var5.close();
            }
         }

      }

   }

   public void writeExtendedLocalHeader(LocalFileHeader var1, OutputStream var2) throws IOException {
      if (var1 != null && var2 != null) {
         ByteArrayOutputStream var3 = new ByteArrayOutputStream();
         Throwable var4 = null;

         try {
            this.rawIO.writeIntLittleEndian(var3, (int)HeaderSignature.EXTRA_DATA_RECORD.getValue());
            this.rawIO.writeLongLittleEndian(this.longBuff, 0, var1.getCrc());
            var3.write(this.longBuff, 0, 4);
            if (var1.isWriteCompressedSizeInZip64ExtraRecord()) {
               this.rawIO.writeLongLittleEndian(var3, var1.getCompressedSize());
               this.rawIO.writeLongLittleEndian(var3, var1.getUncompressedSize());
            } else {
               this.rawIO.writeLongLittleEndian(this.longBuff, 0, var1.getCompressedSize());
               var3.write(this.longBuff, 0, 4);
               this.rawIO.writeLongLittleEndian(this.longBuff, 0, var1.getUncompressedSize());
               var3.write(this.longBuff, 0, 4);
            }

            var2.write(var3.toByteArray());
         } catch (Throwable var13) {
            var4 = var13;
            throw var13;
         } finally {
            if (var3 != null) {
               if (var4 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var12) {
                     var4.addSuppressed(var12);
                  }
               } else {
                  var3.close();
               }
            }

         }

      } else {
         throw new ZipException("input parameters is null, cannot write extended local header");
      }
   }

   public void finalizeZipFile(ZipModel var1, OutputStream var2, Charset var3) throws IOException {
      if (var1 != null && var2 != null) {
         ByteArrayOutputStream var4 = new ByteArrayOutputStream();
         Throwable var5 = null;

         try {
            this.processHeaderData(var1, var2);
            long var6 = this.getOffsetOfCentralDirectory(var1);
            this.writeCentralDirectory(var1, var4, this.rawIO, var3);
            int var8 = var4.size();
            if (var1.isZip64Format() || var6 >= 4294967295L || var1.getCentralDirectory().getFileHeaders().size() >= 65535) {
               if (var1.getZip64EndOfCentralDirectoryRecord() == null) {
                  var1.setZip64EndOfCentralDirectoryRecord(new Zip64EndOfCentralDirectoryRecord());
               }

               if (var1.getZip64EndOfCentralDirectoryLocator() == null) {
                  var1.setZip64EndOfCentralDirectoryLocator(new Zip64EndOfCentralDirectoryLocator());
               }

               var1.getZip64EndOfCentralDirectoryLocator().setOffsetZip64EndOfCentralDirectoryRecord(var6 + (long)var8);
               if (this.isSplitZipFile(var2)) {
                  int var9 = this.getCurrentSplitFileCounter(var2);
                  var1.getZip64EndOfCentralDirectoryLocator().setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(var9);
                  var1.getZip64EndOfCentralDirectoryLocator().setTotalNumberOfDiscs(var9 + 1);
               } else {
                  var1.getZip64EndOfCentralDirectoryLocator().setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(0);
                  var1.getZip64EndOfCentralDirectoryLocator().setTotalNumberOfDiscs(1);
               }

               Zip64EndOfCentralDirectoryRecord var19 = this.buildZip64EndOfCentralDirectoryRecord(var1, var8, var6);
               var1.setZip64EndOfCentralDirectoryRecord(var19);
               this.writeZip64EndOfCentralDirectoryRecord(var19, var4, this.rawIO);
               this.writeZip64EndOfCentralDirectoryLocator(var1.getZip64EndOfCentralDirectoryLocator(), var4, this.rawIO);
            }

            this.writeEndOfCentralDirectoryRecord(var1, var8, var6, var4, this.rawIO, var3);
            this.writeZipHeaderBytes(var1, var2, var4.toByteArray(), var3);
         } catch (Throwable var17) {
            var5 = var17;
            throw var17;
         } finally {
            if (var4 != null) {
               if (var5 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var16) {
                     var5.addSuppressed(var16);
                  }
               } else {
                  var4.close();
               }
            }

         }

      } else {
         throw new ZipException("input parameters is null, cannot finalize zip file");
      }
   }

   public void finalizeZipFileWithoutValidations(ZipModel var1, OutputStream var2, Charset var3) throws IOException {
      if (var1 != null && var2 != null) {
         ByteArrayOutputStream var4 = new ByteArrayOutputStream();
         Throwable var5 = null;

         try {
            long var6 = this.getOffsetOfCentralDirectory(var1);
            this.writeCentralDirectory(var1, var4, this.rawIO, var3);
            int var8 = var4.size();
            if (var1.isZip64Format() || var6 >= 4294967295L || var1.getCentralDirectory().getFileHeaders().size() >= 65535) {
               if (var1.getZip64EndOfCentralDirectoryRecord() == null) {
                  var1.setZip64EndOfCentralDirectoryRecord(new Zip64EndOfCentralDirectoryRecord());
               }

               if (var1.getZip64EndOfCentralDirectoryLocator() == null) {
                  var1.setZip64EndOfCentralDirectoryLocator(new Zip64EndOfCentralDirectoryLocator());
               }

               var1.getZip64EndOfCentralDirectoryLocator().setOffsetZip64EndOfCentralDirectoryRecord(var6 + (long)var8);
               Zip64EndOfCentralDirectoryRecord var9 = this.buildZip64EndOfCentralDirectoryRecord(var1, var8, var6);
               var1.setZip64EndOfCentralDirectoryRecord(var9);
               this.writeZip64EndOfCentralDirectoryRecord(var9, var4, this.rawIO);
               this.writeZip64EndOfCentralDirectoryLocator(var1.getZip64EndOfCentralDirectoryLocator(), var4, this.rawIO);
            }

            this.writeEndOfCentralDirectoryRecord(var1, var8, var6, var4, this.rawIO, var3);
            this.writeZipHeaderBytes(var1, var2, var4.toByteArray(), var3);
         } catch (Throwable var17) {
            var5 = var17;
            throw var17;
         } finally {
            if (var4 != null) {
               if (var5 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var16) {
                     var5.addSuppressed(var16);
                  }
               } else {
                  var4.close();
               }
            }

         }

      } else {
         throw new ZipException("input parameters is null, cannot finalize zip file without validations");
      }
   }

   public void updateLocalFileHeader(FileHeader var1, ZipModel var2, SplitOutputStream var3) throws IOException {
      if (var1 != null && var2 != null) {
         boolean var4 = false;
         SplitOutputStream var5;
         if (var1.getDiskNumberStart() != var3.getCurrentSplitFileCounter()) {
            String var6 = var2.getZipFile().getParent();
            String var7 = FileUtils.getZipFileNameWithoutExtension(var2.getZipFile().getName());
            if (var6 != null) {
               var8 = var6 + System.getProperty("file.separator");
            }

            if (var1.getDiskNumberStart() < 9) {
               var8 = var8 + var7 + ".z0" + (var1.getDiskNumberStart() + 1);
            } else {
               var8 = var8 + var7 + ".z" + (var1.getDiskNumberStart() + 1);
            }

            var5 = new SplitOutputStream(new File(var8));
            var4 = true;
         } else {
            var5 = var3;
         }

         long var9 = var5.getFilePointer();
         var5.seek(var1.getOffsetLocalHeader() + 14L);
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, var1.getCrc());
         var5.write(this.longBuff, 0, 4);
         this.updateFileSizesInLocalFileHeader(var5, var1);
         if (var4) {
            var5.close();
         } else {
            var3.seek(var9);
         }

      } else {
         throw new ZipException("invalid input parameters, cannot update local file header");
      }
   }

   private void updateFileSizesInLocalFileHeader(SplitOutputStream var1, FileHeader var2) throws IOException {
      if (var2.getUncompressedSize() >= 4294967295L) {
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, 4294967295L);
         var1.write(this.longBuff, 0, 4);
         var1.write(this.longBuff, 0, 4);
         int var3 = 4 + var2.getFileNameLength() + 2 + 2;
         if (var1.skipBytes(var3) != var3) {
            throw new ZipException("Unable to skip " + var3 + " bytes to update LFH");
         }

         this.rawIO.writeLongLittleEndian(var1, var2.getUncompressedSize());
         this.rawIO.writeLongLittleEndian(var1, var2.getCompressedSize());
      } else {
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getCompressedSize());
         var1.write(this.longBuff, 0, 4);
         this.rawIO.writeLongLittleEndian(this.longBuff, 0, var2.getUncompressedSize());
         var1.write(this.longBuff, 0, 4);
      }

   }

   private boolean isSplitZipFile(OutputStream var1) {
      if (var1 instanceof SplitOutputStream) {
         return ((SplitOutputStream)var1).isSplitZipFile();
      } else {
         return var1 instanceof CountingOutputStream ? ((CountingOutputStream)var1).isSplitZipFile() : false;
      }
   }

   private int getCurrentSplitFileCounter(OutputStream var1) {
      return var1 instanceof SplitOutputStream ? ((SplitOutputStream)var1).getCurrentSplitFileCounter() : ((CountingOutputStream)var1).getCurrentSplitFileCounter();
   }

   private void writeZipHeaderBytes(ZipModel var1, OutputStream var2, byte[] var3, Charset var4) throws IOException {
      if (var3 == null) {
         throw new ZipException("invalid buff to write as zip headers");
      } else if (var2 instanceof CountingOutputStream && ((CountingOutputStream)var2).checkBuffSizeAndStartNextSplitFile(var3.length)) {
         this.finalizeZipFile(var1, var2, var4);
      } else {
         var2.write(var3);
      }
   }

   private void processHeaderData(ZipModel var1, OutputStream var2) throws IOException {
      int var3 = 0;
      if (var2 instanceof OutputStreamWithSplitZipSupport) {
         var1.getEndOfCentralDirectoryRecord().setOffsetOfStartOfCentralDirectory(((OutputStreamWithSplitZipSupport)var2).getFilePointer());
         var3 = ((OutputStreamWithSplitZipSupport)var2).getCurrentSplitFileCounter();
      }

      if (var1.isZip64Format()) {
         if (var1.getZip64EndOfCentralDirectoryRecord() == null) {
            var1.setZip64EndOfCentralDirectoryRecord(new Zip64EndOfCentralDirectoryRecord());
         }

         if (var1.getZip64EndOfCentralDirectoryLocator() == null) {
            var1.setZip64EndOfCentralDirectoryLocator(new Zip64EndOfCentralDirectoryLocator());
         }

         var1.getZip64EndOfCentralDirectoryRecord().setOffsetStartCentralDirectoryWRTStartDiskNumber(var1.getEndOfCentralDirectoryRecord().getOffsetOfStartOfCentralDirectory());
         var1.getZip64EndOfCentralDirectoryLocator().setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(var3);
         var1.getZip64EndOfCentralDirectoryLocator().setTotalNumberOfDiscs(var3 + 1);
      }

      var1.getEndOfCentralDirectoryRecord().setNumberOfThisDisk(var3);
      var1.getEndOfCentralDirectoryRecord().setNumberOfThisDiskStartOfCentralDir(var3);
   }

   private void writeCentralDirectory(ZipModel var1, ByteArrayOutputStream var2, RawIO var3, Charset var4) throws ZipException {
      if (var1.getCentralDirectory() != null && var1.getCentralDirectory().getFileHeaders() != null && var1.getCentralDirectory().getFileHeaders().size() > 0) {
         for(FileHeader var6 : var1.getCentralDirectory().getFileHeaders()) {
            this.writeFileHeader(var1, var6, var2, var3, var4);
         }

      }
   }

   private void writeFileHeader(ZipModel var1, FileHeader var2, ByteArrayOutputStream var3, RawIO var4, Charset var5) throws ZipException {
      if (var2 == null) {
         throw new ZipException("input parameters is null, cannot write local file header");
      } else {
         try {
            byte[] var6 = new byte[]{0, 0};
            boolean var7 = this.isZip64Entry(var2);
            var4.writeIntLittleEndian(var3, (int)var2.getSignature().getValue());
            var4.writeShortLittleEndian(var3, var2.getVersionMadeBy());
            var4.writeShortLittleEndian(var3, var2.getVersionNeededToExtract());
            var3.write(var2.getGeneralPurposeFlag());
            var4.writeShortLittleEndian(var3, var2.getCompressionMethod().getCode());
            var4.writeLongLittleEndian(this.longBuff, 0, var2.getLastModifiedTime());
            var3.write(this.longBuff, 0, 4);
            var4.writeLongLittleEndian(this.longBuff, 0, var2.getCrc());
            var3.write(this.longBuff, 0, 4);
            if (var7) {
               var4.writeLongLittleEndian(this.longBuff, 0, 4294967295L);
               var3.write(this.longBuff, 0, 4);
               var3.write(this.longBuff, 0, 4);
               var1.setZip64Format(true);
            } else {
               var4.writeLongLittleEndian(this.longBuff, 0, var2.getCompressedSize());
               var3.write(this.longBuff, 0, 4);
               var4.writeLongLittleEndian(this.longBuff, 0, var2.getUncompressedSize());
               var3.write(this.longBuff, 0, 4);
            }

            byte[] var8 = new byte[0];
            if (Zip4jUtil.isStringNotNullAndNotEmpty(var2.getFileName())) {
               var8 = HeaderUtil.getBytesFromString(var2.getFileName(), var5);
            }

            var4.writeShortLittleEndian(var3, var8.length);
            byte[] var9 = new byte[4];
            if (var7) {
               var4.writeLongLittleEndian(this.longBuff, 0, 4294967295L);
               System.arraycopy(this.longBuff, 0, var9, 0, 4);
            } else {
               var4.writeLongLittleEndian(this.longBuff, 0, var2.getOffsetLocalHeader());
               System.arraycopy(this.longBuff, 0, var9, 0, 4);
            }

            int var10 = this.calculateExtraDataRecordsSize(var2, var7);
            var4.writeShortLittleEndian(var3, var10);
            String var11 = var2.getFileComment();
            byte[] var12 = new byte[0];
            if (Zip4jUtil.isStringNotNullAndNotEmpty(var11)) {
               var12 = HeaderUtil.getBytesFromString(var11, var5);
            }

            var4.writeShortLittleEndian(var3, var12.length);
            if (var7) {
               var4.writeIntLittleEndian(this.intBuff, 0, 65535);
               var3.write(this.intBuff, 0, 2);
            } else {
               var4.writeShortLittleEndian(var3, var2.getDiskNumberStart());
            }

            var3.write(var6);
            var3.write(var2.getExternalFileAttributes());
            var3.write(var9);
            if (var8.length > 0) {
               var3.write(var8);
            }

            if (var7) {
               var1.setZip64Format(true);
               var4.writeShortLittleEndian(var3, (int)HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue());
               var4.writeShortLittleEndian(var3, 28);
               var4.writeLongLittleEndian(var3, var2.getUncompressedSize());
               var4.writeLongLittleEndian(var3, var2.getCompressedSize());
               var4.writeLongLittleEndian(var3, var2.getOffsetLocalHeader());
               var4.writeIntLittleEndian(var3, var2.getDiskNumberStart());
            }

            if (var2.getAesExtraDataRecord() != null) {
               AESExtraDataRecord var13 = var2.getAesExtraDataRecord();
               var4.writeShortLittleEndian(var3, (int)var13.getSignature().getValue());
               var4.writeShortLittleEndian(var3, var13.getDataSize());
               var4.writeShortLittleEndian(var3, var13.getAesVersion().getVersionNumber());
               var3.write(HeaderUtil.getBytesFromString(var13.getVendorID(), var5));
               byte[] var14 = new byte[]{(byte)var13.getAesKeyStrength().getRawCode()};
               var3.write(var14);
               var4.writeShortLittleEndian(var3, var13.getCompressionMethod().getCode());
            }

            this.writeRemainingExtraDataRecordsIfPresent(var2, var3);
            if (var12.length > 0) {
               var3.write(var12);
            }

         } catch (Exception var15) {
            throw new ZipException(var15);
         }
      }
   }

   private int calculateExtraDataRecordsSize(FileHeader var1, boolean var2) {
      int var3 = 0;
      if (var2) {
         var3 += 32;
      }

      if (var1.getAesExtraDataRecord() != null) {
         var3 += 11;
      }

      if (var1.getExtraDataRecords() != null) {
         for(ExtraDataRecord var5 : var1.getExtraDataRecords()) {
            if (var5.getHeader() != HeaderSignature.AES_EXTRA_DATA_RECORD.getValue() && var5.getHeader() != HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue()) {
               var3 += 4 + var5.getSizeOfData();
            }
         }
      }

      return var3;
   }

   private void writeRemainingExtraDataRecordsIfPresent(FileHeader var1, OutputStream var2) throws IOException {
      if (var1.getExtraDataRecords() != null && var1.getExtraDataRecords().size() != 0) {
         for(ExtraDataRecord var4 : var1.getExtraDataRecords()) {
            if (var4.getHeader() != HeaderSignature.AES_EXTRA_DATA_RECORD.getValue() && var4.getHeader() != HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue()) {
               this.rawIO.writeShortLittleEndian(var2, (int)var4.getHeader());
               this.rawIO.writeShortLittleEndian(var2, var4.getSizeOfData());
               if (var4.getSizeOfData() > 0 && var4.getData() != null) {
                  var2.write(var4.getData());
               }
            }
         }

      }
   }

   private void writeZip64EndOfCentralDirectoryRecord(Zip64EndOfCentralDirectoryRecord var1, ByteArrayOutputStream var2, RawIO var3) throws IOException {
      var3.writeIntLittleEndian(var2, (int)var1.getSignature().getValue());
      var3.writeLongLittleEndian(var2, var1.getSizeOfZip64EndCentralDirectoryRecord());
      var3.writeShortLittleEndian(var2, var1.getVersionMadeBy());
      var3.writeShortLittleEndian(var2, var1.getVersionNeededToExtract());
      var3.writeIntLittleEndian(var2, var1.getNumberOfThisDisk());
      var3.writeIntLittleEndian(var2, var1.getNumberOfThisDiskStartOfCentralDirectory());
      var3.writeLongLittleEndian(var2, var1.getTotalNumberOfEntriesInCentralDirectoryOnThisDisk());
      var3.writeLongLittleEndian(var2, var1.getTotalNumberOfEntriesInCentralDirectory());
      var3.writeLongLittleEndian(var2, var1.getSizeOfCentralDirectory());
      var3.writeLongLittleEndian(var2, var1.getOffsetStartCentralDirectoryWRTStartDiskNumber());
   }

   private void writeZip64EndOfCentralDirectoryLocator(Zip64EndOfCentralDirectoryLocator var1, ByteArrayOutputStream var2, RawIO var3) throws IOException {
      var3.writeIntLittleEndian(var2, (int)HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_LOCATOR.getValue());
      var3.writeIntLittleEndian(var2, var1.getNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord());
      var3.writeLongLittleEndian(var2, var1.getOffsetZip64EndOfCentralDirectoryRecord());
      var3.writeIntLittleEndian(var2, var1.getTotalNumberOfDiscs());
   }

   private void writeEndOfCentralDirectoryRecord(ZipModel var1, int var2, long var3, ByteArrayOutputStream var5, RawIO var6, Charset var7) throws IOException {
      byte[] var8 = new byte[8];
      var6.writeIntLittleEndian(var5, (int)HeaderSignature.END_OF_CENTRAL_DIRECTORY.getValue());
      var6.writeShortLittleEndian(var5, var1.getEndOfCentralDirectoryRecord().getNumberOfThisDisk());
      var6.writeShortLittleEndian(var5, var1.getEndOfCentralDirectoryRecord().getNumberOfThisDiskStartOfCentralDir());
      long var9 = (long)var1.getCentralDirectory().getFileHeaders().size();
      long var11 = var9;
      if (var1.isSplitArchive()) {
         var11 = this.countNumberOfFileHeaderEntriesOnDisk(var1.getCentralDirectory().getFileHeaders(), var1.getEndOfCentralDirectoryRecord().getNumberOfThisDisk());
      }

      if (var11 > 65535L) {
         var11 = 65535L;
      }

      var6.writeShortLittleEndian(var5, (int)var11);
      if (var9 > 65535L) {
         var9 = 65535L;
      }

      var6.writeShortLittleEndian(var5, (int)var9);
      var6.writeIntLittleEndian(var5, var2);
      if (var3 > 4294967295L) {
         var6.writeLongLittleEndian(var8, 0, 4294967295L);
         var5.write(var8, 0, 4);
      } else {
         var6.writeLongLittleEndian(var8, 0, var3);
         var5.write(var8, 0, 4);
      }

      String var13 = var1.getEndOfCentralDirectoryRecord().getComment();
      if (Zip4jUtil.isStringNotNullAndNotEmpty(var13)) {
         byte[] var14 = HeaderUtil.getBytesFromString(var13, var7);
         var6.writeShortLittleEndian(var5, var14.length);
         var5.write(var14);
      } else {
         var6.writeShortLittleEndian(var5, 0);
      }

   }

   private long countNumberOfFileHeaderEntriesOnDisk(List<FileHeader> var1, int var2) throws ZipException {
      if (var1 == null) {
         throw new ZipException("file headers are null, cannot calculate number of entries on this disk");
      } else {
         int var3 = 0;

         for(FileHeader var5 : var1) {
            if (var5.getDiskNumberStart() == var2) {
               ++var3;
            }
         }

         return (long)var3;
      }
   }

   private boolean isZip64Entry(FileHeader var1) {
      return var1.getCompressedSize() >= 4294967295L || var1.getUncompressedSize() >= 4294967295L || var1.getOffsetLocalHeader() >= 4294967295L || var1.getDiskNumberStart() >= 65535;
   }

   private long getOffsetOfCentralDirectory(ZipModel var1) {
      return var1.isZip64Format() && var1.getZip64EndOfCentralDirectoryRecord() != null && var1.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber() != -1L ? var1.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber() : var1.getEndOfCentralDirectoryRecord().getOffsetOfStartOfCentralDirectory();
   }

   private Zip64EndOfCentralDirectoryRecord buildZip64EndOfCentralDirectoryRecord(ZipModel var1, int var2, long var3) throws ZipException {
      Zip64EndOfCentralDirectoryRecord var5 = new Zip64EndOfCentralDirectoryRecord();
      var5.setSignature(HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_RECORD);
      var5.setSizeOfZip64EndCentralDirectoryRecord(44L);
      if (var1.getCentralDirectory() != null && var1.getCentralDirectory().getFileHeaders() != null && var1.getCentralDirectory().getFileHeaders().size() > 0) {
         FileHeader var6 = (FileHeader)var1.getCentralDirectory().getFileHeaders().get(0);
         var5.setVersionMadeBy(var6.getVersionMadeBy());
         var5.setVersionNeededToExtract(var6.getVersionNeededToExtract());
      }

      var5.setNumberOfThisDisk(var1.getEndOfCentralDirectoryRecord().getNumberOfThisDisk());
      var5.setNumberOfThisDiskStartOfCentralDirectory(var1.getEndOfCentralDirectoryRecord().getNumberOfThisDiskStartOfCentralDir());
      long var10 = (long)var1.getCentralDirectory().getFileHeaders().size();
      long var8 = var10;
      if (var1.isSplitArchive()) {
         var8 = this.countNumberOfFileHeaderEntriesOnDisk(var1.getCentralDirectory().getFileHeaders(), var1.getEndOfCentralDirectoryRecord().getNumberOfThisDisk());
      }

      var5.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(var8);
      var5.setTotalNumberOfEntriesInCentralDirectory(var10);
      var5.setSizeOfCentralDirectory((long)var2);
      var5.setOffsetStartCentralDirectoryWRTStartDiskNumber(var3);
      return var5;
   }
}
