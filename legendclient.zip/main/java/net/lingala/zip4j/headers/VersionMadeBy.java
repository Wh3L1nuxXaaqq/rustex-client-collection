package net.lingala.zip4j.headers;

public enum VersionMadeBy {
   SPECIFICATION_VERSION((byte)51),
   WINDOWS((byte)0),
   UNIX((byte)3);

   private final byte code;

   private VersionMadeBy(byte var3) {
      this.code = var3;
   }

   public byte getCode() {
      return this.code;
   }
}
