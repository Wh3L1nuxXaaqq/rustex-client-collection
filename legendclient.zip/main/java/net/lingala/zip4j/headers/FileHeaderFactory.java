package net.lingala.zip4j.headers;

import java.nio.charset.Charset;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.util.BitUtils;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.Zip4jUtil;
import net.lingala.zip4j.util.ZipVersionUtils;

public class FileHeaderFactory {
   public FileHeader generateFileHeader(ZipParameters var1, boolean var2, int var3, Charset var4, RawIO var5) throws ZipException {
      FileHeader var6 = new FileHeader();
      var6.setSignature(HeaderSignature.CENTRAL_DIRECTORY);
      var6.setVersionMadeBy(ZipVersionUtils.determineVersionMadeBy(var1, var5));
      var6.setVersionNeededToExtract(ZipVersionUtils.determineVersionNeededToExtract(var1).getCode());
      if (var1.isEncryptFiles() && var1.getEncryptionMethod() == EncryptionMethod.AES) {
         var6.setCompressionMethod(CompressionMethod.AES_INTERNAL_ONLY);
         var6.setAesExtraDataRecord(this.generateAESExtraDataRecord(var1));
         var6.setExtraFieldLength(var6.getExtraFieldLength() + 11);
      } else {
         var6.setCompressionMethod(var1.getCompressionMethod());
      }

      if (var1.isEncryptFiles()) {
         if (var1.getEncryptionMethod() == null || var1.getEncryptionMethod() == EncryptionMethod.NONE) {
            throw new ZipException("Encryption method has to be set when encryptFiles flag is set in zip parameters");
         }

         var6.setEncrypted(true);
         var6.setEncryptionMethod(var1.getEncryptionMethod());
      }

      String var7 = this.validateAndGetFileName(var1.getFileNameInZip());
      var6.setFileName(var7);
      var6.setFileNameLength(this.determineFileNameLength(var7, var4));
      var6.setDiskNumberStart(var2 ? var3 : 0);
      var6.setLastModifiedTime(Zip4jUtil.epochToExtendedDosTime(var1.getLastModifiedFileTime()));
      boolean var8 = FileUtils.isZipEntryDirectory(var7);
      var6.setDirectory(var8);
      var6.setExternalFileAttributes(FileUtils.getDefaultFileAttributes(var8));
      if (var1.isWriteExtendedLocalFileHeader() && var1.getEntrySize() == -1L) {
         var6.setUncompressedSize(0L);
      } else {
         var6.setUncompressedSize(var1.getEntrySize());
      }

      if (var1.isEncryptFiles() && var1.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD) {
         var6.setCrc(var1.getEntryCRC());
      }

      var6.setGeneralPurposeFlag(this.determineGeneralPurposeBitFlag(var6.isEncrypted(), var1, var4));
      var6.setDataDescriptorExists(var1.isWriteExtendedLocalFileHeader());
      var6.setFileComment(var1.getFileComment());
      return var6;
   }

   public LocalFileHeader generateLocalFileHeader(FileHeader var1) {
      LocalFileHeader var2 = new LocalFileHeader();
      var2.setSignature(HeaderSignature.LOCAL_FILE_HEADER);
      var2.setVersionNeededToExtract(var1.getVersionNeededToExtract());
      var2.setCompressionMethod(var1.getCompressionMethod());
      var2.setLastModifiedTime(var1.getLastModifiedTime());
      var2.setUncompressedSize(var1.getUncompressedSize());
      var2.setFileNameLength(var1.getFileNameLength());
      var2.setFileName(var1.getFileName());
      var2.setEncrypted(var1.isEncrypted());
      var2.setEncryptionMethod(var1.getEncryptionMethod());
      var2.setAesExtraDataRecord(var1.getAesExtraDataRecord());
      var2.setCrc(var1.getCrc());
      var2.setCompressedSize(var1.getCompressedSize());
      var2.setGeneralPurposeFlag((byte[])var1.getGeneralPurposeFlag().clone());
      var2.setDataDescriptorExists(var1.isDataDescriptorExists());
      var2.setExtraFieldLength(var1.getExtraFieldLength());
      return var2;
   }

   private byte[] determineGeneralPurposeBitFlag(boolean var1, ZipParameters var2, Charset var3) {
      byte[] var4 = new byte[]{this.generateFirstGeneralPurposeByte(var1, var2), 0};
      if (var3 == null || InternalZipConstants.CHARSET_UTF_8.equals(var3)) {
         var4[1] = BitUtils.setBit(var4[1], 3);
      }

      return var4;
   }

   private byte generateFirstGeneralPurposeByte(boolean var1, ZipParameters var2) {
      byte var3 = 0;
      if (var1) {
         var3 = BitUtils.setBit(var3, 0);
      }

      if (CompressionMethod.DEFLATE.equals(var2.getCompressionMethod())) {
         if (CompressionLevel.NORMAL.equals(var2.getCompressionLevel())) {
            var3 = BitUtils.unsetBit(var3, 1);
            var3 = BitUtils.unsetBit(var3, 2);
         } else if (CompressionLevel.MAXIMUM.equals(var2.getCompressionLevel())) {
            var3 = BitUtils.setBit(var3, 1);
            var3 = BitUtils.unsetBit(var3, 2);
         } else if (CompressionLevel.FAST.equals(var2.getCompressionLevel())) {
            var3 = BitUtils.unsetBit(var3, 1);
            var3 = BitUtils.setBit(var3, 2);
         } else if (CompressionLevel.FASTEST.equals(var2.getCompressionLevel()) || CompressionLevel.ULTRA.equals(var2.getCompressionLevel())) {
            var3 = BitUtils.setBit(var3, 1);
            var3 = BitUtils.setBit(var3, 2);
         }
      }

      if (var2.isWriteExtendedLocalFileHeader()) {
         var3 = BitUtils.setBit(var3, 3);
      }

      return var3;
   }

   private String validateAndGetFileName(String var1) throws ZipException {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         throw new ZipException("fileNameInZip is null or empty");
      } else {
         return var1;
      }
   }

   private AESExtraDataRecord generateAESExtraDataRecord(ZipParameters var1) throws ZipException {
      AESExtraDataRecord var2 = new AESExtraDataRecord();
      if (var1.getAesVersion() != null) {
         var2.setAesVersion(var1.getAesVersion());
      }

      if (var1.getAesKeyStrength() == AesKeyStrength.KEY_STRENGTH_128) {
         var2.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_128);
      } else if (var1.getAesKeyStrength() == AesKeyStrength.KEY_STRENGTH_192) {
         var2.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_192);
      } else {
         if (var1.getAesKeyStrength() != AesKeyStrength.KEY_STRENGTH_256) {
            throw new ZipException("invalid AES key strength");
         }

         var2.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
      }

      var2.setCompressionMethod(var1.getCompressionMethod());
      return var2;
   }

   private int determineFileNameLength(String var1, Charset var2) {
      return HeaderUtil.getBytesFromString(var1, var2).length;
   }
}
