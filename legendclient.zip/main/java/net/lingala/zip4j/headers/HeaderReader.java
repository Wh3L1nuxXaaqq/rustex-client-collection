package net.lingala.zip4j.headers;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.inputstream.NumberedSplitRandomAccessFile;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.AbstractFileHeader;
import net.lingala.zip4j.model.CentralDirectory;
import net.lingala.zip4j.model.DataDescriptor;
import net.lingala.zip4j.model.DigitalSignature;
import net.lingala.zip4j.model.EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.ExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryLocator;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.Zip64ExtendedInfo;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.AesVersion;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.util.BitUtils;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.Zip4jUtil;

public class HeaderReader {
   private ZipModel zipModel;
   private final RawIO rawIO = new RawIO();
   private final byte[] intBuff = new byte[4];

   public ZipModel readAllHeaders(RandomAccessFile var1, Zip4jConfig var2) throws IOException {
      if (var1.length() == 0L) {
         return new ZipModel();
      } else if (var1.length() < 22L) {
         throw new ZipException("Zip file size less than minimum expected zip file size. Probably not a zip file or a corrupted zip file");
      } else {
         this.zipModel = new ZipModel();

         try {
            this.zipModel.setEndOfCentralDirectoryRecord(this.readEndOfCentralDirectoryRecord(var1, this.rawIO, var2));
         } catch (ZipException var4) {
            throw var4;
         } catch (IOException var5) {
            var5.printStackTrace();
            throw new ZipException("Zip headers not found. Probably not a zip file or a corrupted zip file", var5);
         }

         if (this.zipModel.getEndOfCentralDirectoryRecord().getTotalNumberOfEntriesInCentralDirectory() == 0) {
            return this.zipModel;
         } else {
            this.zipModel.setZip64EndOfCentralDirectoryLocator(this.readZip64EndOfCentralDirectoryLocator(var1, this.rawIO, this.zipModel.getEndOfCentralDirectoryRecord().getOffsetOfEndOfCentralDirectory()));
            if (this.zipModel.isZip64Format()) {
               this.zipModel.setZip64EndOfCentralDirectoryRecord(this.readZip64EndCentralDirRec(var1, this.rawIO));
               if (this.zipModel.getZip64EndOfCentralDirectoryRecord() != null && this.zipModel.getZip64EndOfCentralDirectoryRecord().getNumberOfThisDisk() > 0) {
                  this.zipModel.setSplitArchive(true);
               } else {
                  this.zipModel.setSplitArchive(false);
               }
            }

            this.zipModel.setCentralDirectory(this.readCentralDirectory(var1, this.rawIO, var2.getCharset()));
            return this.zipModel;
         }
      }
   }

   private EndOfCentralDirectoryRecord readEndOfCentralDirectoryRecord(RandomAccessFile var1, RawIO var2, Zip4jConfig var3) throws IOException {
      long var4 = this.locateOffsetOfEndOfCentralDirectory(var1);
      this.seekInCurrentPart(var1, var4 + 4L);
      EndOfCentralDirectoryRecord var6 = new EndOfCentralDirectoryRecord();
      var6.setSignature(HeaderSignature.END_OF_CENTRAL_DIRECTORY);
      var6.setNumberOfThisDisk(var2.readShortLittleEndian(var1));
      var6.setNumberOfThisDiskStartOfCentralDir(var2.readShortLittleEndian(var1));
      var6.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(var2.readShortLittleEndian(var1));
      var6.setTotalNumberOfEntriesInCentralDirectory(var2.readShortLittleEndian(var1));
      var6.setSizeOfCentralDirectory(var2.readIntLittleEndian(var1));
      var6.setOffsetOfEndOfCentralDirectory(var4);
      var1.readFully(this.intBuff);
      var6.setOffsetOfStartOfCentralDirectory(var2.readLongLittleEndian((byte[])this.intBuff, 0));
      int var7 = var2.readShortLittleEndian(var1);
      var6.setComment(this.readZipComment(var1, var7, var3.getCharset()));
      this.zipModel.setSplitArchive(var6.getNumberOfThisDisk() > 0);
      return var6;
   }

   private CentralDirectory readCentralDirectory(RandomAccessFile var1, RawIO var2, Charset var3) throws IOException {
      CentralDirectory var4 = new CentralDirectory();
      ArrayList var5 = new ArrayList();
      long var6 = HeaderUtil.getOffsetStartOfCentralDirectory(this.zipModel);
      long var8 = this.getNumberOfEntriesInCentralDirectory(this.zipModel);
      var1.seek(var6);
      byte[] var10 = new byte[2];
      byte[] var11 = new byte[4];

      for(int var12 = 0; (long)var12 < var8; ++var12) {
         FileHeader var13 = new FileHeader();
         if ((long)var2.readIntLittleEndian(var1) != HeaderSignature.CENTRAL_DIRECTORY.getValue()) {
            throw new ZipException("Expected central directory entry not found (#" + (var12 + 1) + ")");
         }

         var13.setSignature(HeaderSignature.CENTRAL_DIRECTORY);
         var13.setVersionMadeBy(var2.readShortLittleEndian(var1));
         var13.setVersionNeededToExtract(var2.readShortLittleEndian(var1));
         byte[] var14 = new byte[2];
         var1.readFully(var14);
         var13.setEncrypted(BitUtils.isBitSet(var14[0], 0));
         var13.setDataDescriptorExists(BitUtils.isBitSet(var14[0], 3));
         var13.setFileNameUTF8Encoded(BitUtils.isBitSet(var14[1], 3));
         var13.setGeneralPurposeFlag((byte[])(([B)var14).clone());
         var13.setCompressionMethod(CompressionMethod.getCompressionMethodFromCode(var2.readShortLittleEndian(var1)));
         var13.setLastModifiedTime((long)var2.readIntLittleEndian(var1));
         var1.readFully(var11);
         var13.setCrc(var2.readLongLittleEndian((byte[])var11, 0));
         var13.setCompressedSize(var2.readLongLittleEndian((RandomAccessFile)var1, 4));
         var13.setUncompressedSize(var2.readLongLittleEndian((RandomAccessFile)var1, 4));
         int var15 = var2.readShortLittleEndian(var1);
         var13.setFileNameLength(var15);
         var13.setExtraFieldLength(var2.readShortLittleEndian(var1));
         int var16 = var2.readShortLittleEndian(var1);
         var13.setFileCommentLength(var16);
         var13.setDiskNumberStart(var2.readShortLittleEndian(var1));
         var1.readFully(var10);
         var13.setInternalFileAttributes((byte[])(([B)var10).clone());
         var1.readFully(var11);
         var13.setExternalFileAttributes((byte[])(([B)var11).clone());
         var1.readFully(var11);
         var13.setOffsetLocalHeader(var2.readLongLittleEndian((byte[])var11, 0));
         if (var15 <= 0) {
            throw new ZipException("Invalid entry name in file header");
         }

         byte[] var17 = new byte[var15];
         var1.readFully(var17);
         String var18 = HeaderUtil.decodeStringWithCharset(var17, var13.isFileNameUTF8Encoded(), var3);
         var13.setFileName(var18);
         var13.setDirectory(this.isDirectory(var13.getExternalFileAttributes(), var13.getFileName()));
         this.readExtraDataRecords(var1, var13);
         this.readZip64ExtendedInfo(var13, var2);
         this.readAesExtraDataRecord(var13, var2);
         if (var16 > 0) {
            var17 = new byte[var16];
            var1.readFully(var17);
            var13.setFileComment(HeaderUtil.decodeStringWithCharset(var17, var13.isFileNameUTF8Encoded(), var3));
         }

         if (var13.isEncrypted()) {
            if (var13.getAesExtraDataRecord() != null) {
               var13.setEncryptionMethod(EncryptionMethod.AES);
            } else {
               var13.setEncryptionMethod(EncryptionMethod.ZIP_STANDARD);
            }
         }

         var5.add(var13);
      }

      var4.setFileHeaders(var5);
      DigitalSignature var19 = new DigitalSignature();
      if ((long)var2.readIntLittleEndian(var1) == HeaderSignature.DIGITAL_SIGNATURE.getValue()) {
         var19.setSignature(HeaderSignature.DIGITAL_SIGNATURE);
         var19.setSizeOfData(var2.readShortLittleEndian(var1));
         if (var19.getSizeOfData() > 0) {
            byte[] var20 = new byte[var19.getSizeOfData()];
            var1.readFully(var20);
            var19.setSignatureData(new String(var20));
         }
      }

      return var4;
   }

   private void readExtraDataRecords(RandomAccessFile var1, FileHeader var2) throws IOException {
      int var3 = var2.getExtraFieldLength();
      if (var3 > 0) {
         var2.setExtraDataRecords(this.readExtraDataRecords(var1, var3));
      }
   }

   private void readExtraDataRecords(InputStream var1, LocalFileHeader var2) throws IOException {
      int var3 = var2.getExtraFieldLength();
      if (var3 > 0) {
         var2.setExtraDataRecords(this.readExtraDataRecords(var1, var3));
      }
   }

   private List<ExtraDataRecord> readExtraDataRecords(RandomAccessFile var1, int var2) throws IOException {
      if (var2 < 4) {
         if (var2 > 0) {
            var1.skipBytes(var2);
         }

         return null;
      } else {
         byte[] var3 = new byte[var2];
         var1.read(var3);

         try {
            return this.parseExtraDataRecords(var3, var2);
         } catch (Exception var5) {
            return Collections.emptyList();
         }
      }
   }

   private List<ExtraDataRecord> readExtraDataRecords(InputStream var1, int var2) throws IOException {
      if (var2 < 4) {
         if (var2 > 0) {
            var1.skip((long)var2);
         }

         return null;
      } else {
         byte[] var3 = new byte[var2];
         Zip4jUtil.readFully(var1, var3);

         try {
            return this.parseExtraDataRecords(var3, var2);
         } catch (Exception var5) {
            return Collections.emptyList();
         }
      }
   }

   private List<ExtraDataRecord> parseExtraDataRecords(byte[] var1, int var2) {
      int var3 = 0;
      ArrayList var4 = new ArrayList();

      while(var3 < var2) {
         ExtraDataRecord var5 = new ExtraDataRecord();
         int var6 = this.rawIO.readShortLittleEndian(var1, var3);
         var5.setHeader((long)var6);
         var3 += 2;
         int var7 = this.rawIO.readShortLittleEndian(var1, var3);
         var5.setSizeOfData(var7);
         var3 += 2;
         if (var7 > 0) {
            byte[] var8 = new byte[var7];
            System.arraycopy(var1, var3, var8, 0, var7);
            var5.setData(var8);
         }

         var3 += var7;
         var4.add(var5);
      }

      return var4.size() > 0 ? var4 : null;
   }

   private Zip64EndOfCentralDirectoryLocator readZip64EndOfCentralDirectoryLocator(RandomAccessFile var1, RawIO var2, long var3) throws IOException {
      Zip64EndOfCentralDirectoryLocator var5 = new Zip64EndOfCentralDirectoryLocator();
      this.setFilePointerToReadZip64EndCentralDirLoc(var1, var3);
      int var6 = var2.readIntLittleEndian(var1);
      if ((long)var6 == HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_LOCATOR.getValue()) {
         this.zipModel.setZip64Format(true);
         var5.setSignature(HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_LOCATOR);
         var5.setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(var2.readIntLittleEndian(var1));
         var5.setOffsetZip64EndOfCentralDirectoryRecord(var2.readLongLittleEndian(var1));
         var5.setTotalNumberOfDiscs(var2.readIntLittleEndian(var1));
         return var5;
      } else {
         this.zipModel.setZip64Format(false);
         return null;
      }
   }

   private Zip64EndOfCentralDirectoryRecord readZip64EndCentralDirRec(RandomAccessFile var1, RawIO var2) throws IOException {
      if (this.zipModel.getZip64EndOfCentralDirectoryLocator() == null) {
         throw new ZipException("invalid zip64 end of central directory locator");
      } else {
         long var3 = this.zipModel.getZip64EndOfCentralDirectoryLocator().getOffsetZip64EndOfCentralDirectoryRecord();
         if (var3 < 0L) {
            throw new ZipException("invalid offset for start of end of central directory record");
         } else {
            var1.seek(var3);
            Zip64EndOfCentralDirectoryRecord var5 = new Zip64EndOfCentralDirectoryRecord();
            int var6 = var2.readIntLittleEndian(var1);
            if ((long)var6 != HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_RECORD.getValue()) {
               throw new ZipException("invalid signature for zip64 end of central directory record");
            } else {
               var5.setSignature(HeaderSignature.ZIP64_END_CENTRAL_DIRECTORY_RECORD);
               var5.setSizeOfZip64EndCentralDirectoryRecord(var2.readLongLittleEndian(var1));
               var5.setVersionMadeBy(var2.readShortLittleEndian(var1));
               var5.setVersionNeededToExtract(var2.readShortLittleEndian(var1));
               var5.setNumberOfThisDisk(var2.readIntLittleEndian(var1));
               var5.setNumberOfThisDiskStartOfCentralDirectory(var2.readIntLittleEndian(var1));
               var5.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(var2.readLongLittleEndian(var1));
               var5.setTotalNumberOfEntriesInCentralDirectory(var2.readLongLittleEndian(var1));
               var5.setSizeOfCentralDirectory(var2.readLongLittleEndian(var1));
               var5.setOffsetStartCentralDirectoryWRTStartDiskNumber(var2.readLongLittleEndian(var1));
               long var7 = var5.getSizeOfZip64EndCentralDirectoryRecord() - 44L;
               if (var7 > 0L) {
                  byte[] var9 = new byte[(int)var7];
                  var1.readFully(var9);
                  var5.setExtensibleDataSector(var9);
               }

               return var5;
            }
         }
      }
   }

   private void readZip64ExtendedInfo(FileHeader var1, RawIO var2) {
      if (var1.getExtraDataRecords() != null && var1.getExtraDataRecords().size() > 0) {
         Zip64ExtendedInfo var3 = this.readZip64ExtendedInfo(var1.getExtraDataRecords(), var2, var1.getUncompressedSize(), var1.getCompressedSize(), var1.getOffsetLocalHeader(), var1.getDiskNumberStart());
         if (var3 != null) {
            var1.setZip64ExtendedInfo(var3);
            if (var3.getUncompressedSize() != -1L) {
               var1.setUncompressedSize(var3.getUncompressedSize());
            }

            if (var3.getCompressedSize() != -1L) {
               var1.setCompressedSize(var3.getCompressedSize());
            }

            if (var3.getOffsetLocalHeader() != -1L) {
               var1.setOffsetLocalHeader(var3.getOffsetLocalHeader());
            }

            if (var3.getDiskNumberStart() != -1) {
               var1.setDiskNumberStart(var3.getDiskNumberStart());
            }

         }
      }
   }

   private void readZip64ExtendedInfo(LocalFileHeader var1, RawIO var2) throws ZipException {
      if (var1 == null) {
         throw new ZipException("file header is null in reading Zip64 Extended Info");
      } else if (var1.getExtraDataRecords() != null && var1.getExtraDataRecords().size() > 0) {
         Zip64ExtendedInfo var3 = this.readZip64ExtendedInfo(var1.getExtraDataRecords(), var2, var1.getUncompressedSize(), var1.getCompressedSize(), 0L, 0);
         if (var3 != null) {
            var1.setZip64ExtendedInfo(var3);
            if (var3.getUncompressedSize() != -1L) {
               var1.setUncompressedSize(var3.getUncompressedSize());
            }

            if (var3.getCompressedSize() != -1L) {
               var1.setCompressedSize(var3.getCompressedSize());
            }

         }
      }
   }

   private Zip64ExtendedInfo readZip64ExtendedInfo(List<ExtraDataRecord> var1, RawIO var2, long var3, long var5, long var7, int var9) {
      for(ExtraDataRecord var11 : var1) {
         if (var11 != null && HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue() == var11.getHeader()) {
            Zip64ExtendedInfo var12 = new Zip64ExtendedInfo();
            byte[] var13 = var11.getData();
            if (var11.getSizeOfData() <= 0) {
               return null;
            }

            int var14 = 0;
            if (var14 < var11.getSizeOfData() && var3 == 4294967295L) {
               var12.setUncompressedSize(var2.readLongLittleEndian(var13, var14));
               var14 += 8;
            }

            if (var14 < var11.getSizeOfData() && var5 == 4294967295L) {
               var12.setCompressedSize(var2.readLongLittleEndian(var13, var14));
               var14 += 8;
            }

            if (var14 < var11.getSizeOfData() && var7 == 4294967295L) {
               var12.setOffsetLocalHeader(var2.readLongLittleEndian(var13, var14));
               var14 += 8;
            }

            if (var14 < var11.getSizeOfData() && var9 == 65535) {
               var12.setDiskNumberStart(var2.readIntLittleEndian(var13, var14));
            }

            return var12;
         }
      }

      return null;
   }

   private void setFilePointerToReadZip64EndCentralDirLoc(RandomAccessFile var1, long var2) throws IOException {
      this.seekInCurrentPart(var1, var2 - 4L - 8L - 4L - 4L);
   }

   public LocalFileHeader readLocalFileHeader(InputStream var1, Charset var2) throws IOException {
      LocalFileHeader var3 = new LocalFileHeader();
      byte[] var4 = new byte[4];
      int var5 = this.rawIO.readIntLittleEndian(var1);
      if ((long)var5 == HeaderSignature.TEMPORARY_SPANNING_MARKER.getValue()) {
         var5 = this.rawIO.readIntLittleEndian(var1);
      }

      if ((long)var5 != HeaderSignature.LOCAL_FILE_HEADER.getValue()) {
         return null;
      } else {
         var3.setSignature(HeaderSignature.LOCAL_FILE_HEADER);
         var3.setVersionNeededToExtract(this.rawIO.readShortLittleEndian(var1));
         byte[] var6 = new byte[2];
         if (Zip4jUtil.readFully(var1, var6) != 2) {
            throw new ZipException("Could not read enough bytes for generalPurposeFlags");
         } else {
            var3.setEncrypted(BitUtils.isBitSet(var6[0], 0));
            var3.setDataDescriptorExists(BitUtils.isBitSet(var6[0], 3));
            var3.setFileNameUTF8Encoded(BitUtils.isBitSet(var6[1], 3));
            var3.setGeneralPurposeFlag((byte[])(([B)var6).clone());
            var3.setCompressionMethod(CompressionMethod.getCompressionMethodFromCode(this.rawIO.readShortLittleEndian(var1)));
            var3.setLastModifiedTime((long)this.rawIO.readIntLittleEndian(var1));
            Zip4jUtil.readFully(var1, var4);
            var3.setCrc(this.rawIO.readLongLittleEndian((byte[])var4, 0));
            var3.setCompressedSize(this.rawIO.readLongLittleEndian((InputStream)var1, 4));
            var3.setUncompressedSize(this.rawIO.readLongLittleEndian((InputStream)var1, 4));
            int var7 = this.rawIO.readShortLittleEndian(var1);
            var3.setFileNameLength(var7);
            var3.setExtraFieldLength(this.rawIO.readShortLittleEndian(var1));
            if (var7 <= 0) {
               throw new ZipException("Invalid entry name in local file header");
            } else {
               byte[] var8 = new byte[var7];
               Zip4jUtil.readFully(var1, var8);
               String var9 = HeaderUtil.decodeStringWithCharset(var8, var3.isFileNameUTF8Encoded(), var2);
               var3.setFileName(var9);
               var3.setDirectory(var9.endsWith("/") || var9.endsWith("\\"));
               this.readExtraDataRecords(var1, var3);
               this.readZip64ExtendedInfo(var3, this.rawIO);
               this.readAesExtraDataRecord(var3, this.rawIO);
               if (var3.isEncrypted() && var3.getEncryptionMethod() != EncryptionMethod.AES) {
                  if (BitUtils.isBitSet(var3.getGeneralPurposeFlag()[0], 6)) {
                     var3.setEncryptionMethod(EncryptionMethod.ZIP_STANDARD_VARIANT_STRONG);
                  } else {
                     var3.setEncryptionMethod(EncryptionMethod.ZIP_STANDARD);
                  }
               }

               return var3;
            }
         }
      }
   }

   public DataDescriptor readDataDescriptor(InputStream var1, boolean var2) throws IOException {
      DataDescriptor var3 = new DataDescriptor();
      byte[] var4 = new byte[4];
      Zip4jUtil.readFully(var1, var4);
      long var5 = this.rawIO.readLongLittleEndian((byte[])var4, 0);
      if (var5 == HeaderSignature.EXTRA_DATA_RECORD.getValue()) {
         var3.setSignature(HeaderSignature.EXTRA_DATA_RECORD);
         Zip4jUtil.readFully(var1, var4);
         var3.setCrc(this.rawIO.readLongLittleEndian((byte[])var4, 0));
      } else {
         var3.setCrc(var5);
      }

      if (var2) {
         var3.setCompressedSize(this.rawIO.readLongLittleEndian(var1));
         var3.setUncompressedSize(this.rawIO.readLongLittleEndian(var1));
      } else {
         var3.setCompressedSize((long)this.rawIO.readIntLittleEndian(var1));
         var3.setUncompressedSize((long)this.rawIO.readIntLittleEndian(var1));
      }

      return var3;
   }

   private void readAesExtraDataRecord(AbstractFileHeader var1, RawIO var2) throws ZipException {
      if (var1.getExtraDataRecords() != null && var1.getExtraDataRecords().size() > 0) {
         AESExtraDataRecord var3 = this.readAesExtraDataRecord(var1.getExtraDataRecords(), var2);
         if (var3 != null) {
            var1.setAesExtraDataRecord(var3);
            var1.setEncryptionMethod(EncryptionMethod.AES);
         }

      }
   }

   private AESExtraDataRecord readAesExtraDataRecord(List<ExtraDataRecord> var1, RawIO var2) throws ZipException {
      if (var1 == null) {
         return null;
      } else {
         for(ExtraDataRecord var4 : var1) {
            if (var4 != null && var4.getHeader() == HeaderSignature.AES_EXTRA_DATA_RECORD.getValue()) {
               byte[] var5 = var4.getData();
               if (var5 != null && var5.length == 7) {
                  AESExtraDataRecord var6 = new AESExtraDataRecord();
                  var6.setSignature(HeaderSignature.AES_EXTRA_DATA_RECORD);
                  var6.setDataSize(var4.getSizeOfData());
                  byte[] var7 = var4.getData();
                  var6.setAesVersion(AesVersion.getFromVersionNumber(var2.readShortLittleEndian(var7, 0)));
                  byte[] var8 = new byte[2];
                  System.arraycopy(var7, 2, var8, 0, 2);
                  var6.setVendorID(new String(var8));
                  var6.setAesKeyStrength(AesKeyStrength.getAesKeyStrengthFromRawCode(var7[4] & 255));
                  var6.setCompressionMethod(CompressionMethod.getCompressionMethodFromCode(var2.readShortLittleEndian(var7, 5)));
                  return var6;
               }

               throw new ZipException("corrupt AES extra data records");
            }
         }

         return null;
      }
   }

   private long getNumberOfEntriesInCentralDirectory(ZipModel var1) {
      return var1.isZip64Format() ? var1.getZip64EndOfCentralDirectoryRecord().getTotalNumberOfEntriesInCentralDirectory() : (long)var1.getEndOfCentralDirectoryRecord().getTotalNumberOfEntriesInCentralDirectory();
   }

   private long locateOffsetOfEndOfCentralDirectory(RandomAccessFile var1) throws IOException {
      long var2 = var1.length();
      if (var2 < 22L) {
         throw new ZipException("Zip file size less than size of zip headers. Probably not a zip file.");
      } else {
         this.seekInCurrentPart(var1, var2 - 22L);
         return (long)this.rawIO.readIntLittleEndian(var1) == HeaderSignature.END_OF_CENTRAL_DIRECTORY.getValue() ? var2 - 22L : this.locateOffsetOfEndOfCentralDirectoryByReverseSeek(var1);
      }
   }

   private long locateOffsetOfEndOfCentralDirectoryByReverseSeek(RandomAccessFile var1) throws IOException {
      long var2 = var1.length() - 22L;

      for(long var4 = var1.length() < 65536L ? var1.length() : 65536L; var4 > 0L && var2 > 0L; --var4) {
         this.seekInCurrentPart(var1, --var2);
         if ((long)this.rawIO.readIntLittleEndian(var1) == HeaderSignature.END_OF_CENTRAL_DIRECTORY.getValue()) {
            return var2;
         }
      }

      throw new ZipException("Zip headers not found. Probably not a zip file");
   }

   private void seekInCurrentPart(RandomAccessFile var1, long var2) throws IOException {
      if (var1 instanceof NumberedSplitRandomAccessFile) {
         (NumberedSplitRandomAccessFile)var1).seekInCurrentPart(var2;
      } else {
         var1.seek(var2);
      }

   }

   private String readZipComment(RandomAccessFile var1, int var2, Charset var3) {
      if (var2 <= 0) {
         return null;
      } else {
         try {
            byte[] var4 = new byte[var2];
            var1.readFully(var4);
            return HeaderUtil.decodeStringWithCharset(var4, false, var3 != null ? var3 : InternalZipConstants.ZIP4J_DEFAULT_CHARSET);
         } catch (IOException var5) {
            return null;
         }
      }
   }

   public boolean isDirectory(byte[] var1, String var2) {
      if (var1[0] != 0 && BitUtils.isBitSet(var1[0], 4)) {
         return true;
      } else if (var1[3] != 0 && BitUtils.isBitSet(var1[3], 6)) {
         return true;
      } else {
         return var2 != null && (var2.endsWith("/") || var2.endsWith("\\"));
      }
   }
}
