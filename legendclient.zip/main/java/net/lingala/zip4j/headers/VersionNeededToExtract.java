package net.lingala.zip4j.headers;

public enum VersionNeededToExtract {
   DEFAULT(10),
   DEFLATE_COMPRESSED(20),
   ZIP_64_FORMAT(45),
   AES_ENCRYPTED(51);

   private final int code;

   private VersionNeededToExtract(int var3) {
      this.code = var3;
   }

   public int getCode() {
      return this.code;
   }
}
