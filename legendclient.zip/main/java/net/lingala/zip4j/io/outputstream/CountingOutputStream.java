package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.exception.ZipException;

public class CountingOutputStream extends OutputStream implements OutputStreamWithSplitZipSupport {
   private OutputStream outputStream;
   private long numberOfBytesWritten = 0L;

   public CountingOutputStream(OutputStream var1) {
      this.outputStream = var1;
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.outputStream.write(var1, var2, var3);
      this.numberOfBytesWritten += (long)var3;
   }

   public int getCurrentSplitFileCounter() {
      return this.isSplitZipFile() ? ((SplitOutputStream)this.outputStream).getCurrentSplitFileCounter() : 0;
   }

   public long getOffsetForNextEntry() throws IOException {
      return this.outputStream instanceof SplitOutputStream ? ((SplitOutputStream)this.outputStream).getFilePointer() : this.numberOfBytesWritten;
   }

   public long getSplitLength() {
      return this.isSplitZipFile() ? ((SplitOutputStream)this.outputStream).getSplitLength() : 0L;
   }

   public boolean isSplitZipFile() {
      return this.outputStream instanceof SplitOutputStream && ((SplitOutputStream)this.outputStream).isSplitZipFile();
   }

   public long getNumberOfBytesWritten() throws IOException {
      return this.outputStream instanceof SplitOutputStream ? ((SplitOutputStream)this.outputStream).getFilePointer() : this.numberOfBytesWritten;
   }

   public boolean checkBuffSizeAndStartNextSplitFile(int var1) throws ZipException {
      return !this.isSplitZipFile() ? false : ((SplitOutputStream)this.outputStream).checkBufferSizeAndStartNextSplitFile(var1);
   }

   public long getFilePointer() throws IOException {
      return this.outputStream instanceof SplitOutputStream ? ((SplitOutputStream)this.outputStream).getFilePointer() : this.numberOfBytesWritten;
   }

   public void close() throws IOException {
      this.outputStream.close();
   }
}
