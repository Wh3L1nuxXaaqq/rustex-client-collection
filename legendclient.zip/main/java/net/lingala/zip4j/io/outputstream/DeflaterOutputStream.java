package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.util.zip.Deflater;
import net.lingala.zip4j.model.enums.CompressionLevel;

class DeflaterOutputStream extends CompressedOutputStream {
   private byte[] buff;
   protected Deflater deflater;

   public DeflaterOutputStream(CipherOutputStream<?> var1, CompressionLevel var2, int var3) {
      super(var1);
      this.deflater = new Deflater(var2.getLevel(), true);
      this.buff = new byte[var3];
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(int var1) throws IOException {
      byte[] var2 = new byte[]{(byte)var1};
      this.write(var2, 0, 1);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.deflater.setInput(var1, var2, var3);

      while(!this.deflater.needsInput()) {
         this.deflate();
      }

   }

   private void deflate() throws IOException {
      int var1 = this.deflater.deflate(this.buff, 0, this.buff.length);
      if (var1 > 0) {
         super.write(this.buff, 0, var1);
      }

   }

   public void closeEntry() throws IOException {
      if (!this.deflater.finished()) {
         this.deflater.finish();

         while(!this.deflater.finished()) {
            this.deflate();
         }
      }

      this.deflater.end();
      super.closeEntry();
   }
}
