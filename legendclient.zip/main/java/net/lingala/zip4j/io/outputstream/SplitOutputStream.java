package net.lingala.zip4j.io.outputstream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderSignature;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.RawIO;

public class SplitOutputStream extends OutputStream implements OutputStreamWithSplitZipSupport {
   private RandomAccessFile raf;
   private long splitLength;
   private File zipFile;
   private int currSplitFileCounter;
   private long bytesWrittenForThisPart;
   private RawIO rawIO;

   public SplitOutputStream(File var1) throws FileNotFoundException, ZipException {
      this(var1, -1L);
   }

   public SplitOutputStream(File var1, long var2) throws FileNotFoundException, ZipException {
      this.rawIO = new RawIO();
      if (var2 >= 0L && var2 < 65536L) {
         throw new ZipException("split length less than minimum allowed split length of 65536 Bytes");
      } else {
         this.raf = new RandomAccessFile(var1, RandomAccessFileMode.WRITE.getValue());
         this.splitLength = var2;
         this.zipFile = var1;
         this.currSplitFileCounter = 0;
         this.bytesWrittenForThisPart = 0L;
      }
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      if (var3 > 0) {
         if (this.splitLength == -1L) {
            this.raf.write(var1, var2, var3);
            this.bytesWrittenForThisPart += (long)var3;
         } else {
            if (this.bytesWrittenForThisPart >= this.splitLength) {
               this.startNextSplitFile();
               this.raf.write(var1, var2, var3);
               this.bytesWrittenForThisPart = (long)var3;
            } else if (this.bytesWrittenForThisPart + (long)var3 > this.splitLength) {
               if (this.isHeaderData(var1)) {
                  this.startNextSplitFile();
                  this.raf.write(var1, var2, var3);
                  this.bytesWrittenForThisPart = (long)var3;
               } else {
                  this.raf.write(var1, var2, (int)(this.splitLength - this.bytesWrittenForThisPart));
                  this.startNextSplitFile();
                  this.raf.write(var1, var2 + (int)(this.splitLength - this.bytesWrittenForThisPart), (int)((long)var3 - (this.splitLength - this.bytesWrittenForThisPart)));
                  this.bytesWrittenForThisPart = (long)var3 - (this.splitLength - this.bytesWrittenForThisPart);
               }
            } else {
               this.raf.write(var1, var2, var3);
               this.bytesWrittenForThisPart += (long)var3;
            }

         }
      }
   }

   private void startNextSplitFile() throws IOException {
      String var1 = FileUtils.getZipFileNameWithoutExtension(this.zipFile.getName());
      String var2 = this.zipFile.getAbsolutePath();
      String var3 = this.zipFile.getParent() == null ? "" : this.zipFile.getParent() + System.getProperty("file.separator");
      String var4 = ".z0" + (this.currSplitFileCounter + 1);
      if (this.currSplitFileCounter >= 9) {
         var4 = ".z" + (this.currSplitFileCounter + 1);
      }

      File var5 = new File(var3 + var1 + var4);
      this.raf.close();
      if (var5.exists()) {
         throw new IOException("split file: " + var5.getName() + " already exists in the current directory, cannot rename this file");
      } else if (!this.zipFile.renameTo(var5)) {
         throw new IOException("cannot rename newly created split file");
      } else {
         this.zipFile = new File(var2);
         this.raf = new RandomAccessFile(this.zipFile, RandomAccessFileMode.WRITE.getValue());
         ++this.currSplitFileCounter;
      }
   }

   private boolean isHeaderData(byte[] var1) {
      int var2 = this.rawIO.readIntLittleEndian(var1);

      for(HeaderSignature var6 : HeaderSignature.values()) {
         if (var6 != HeaderSignature.SPLIT_ZIP && var6.getValue() == (long)var2) {
            return true;
         }
      }

      return false;
   }

   public boolean checkBufferSizeAndStartNextSplitFile(int var1) throws ZipException {
      if (var1 < 0) {
         throw new ZipException("negative buffersize for checkBufferSizeAndStartNextSplitFile");
      } else if (!this.isBufferSizeFitForCurrSplitFile(var1)) {
         try {
            this.startNextSplitFile();
            this.bytesWrittenForThisPart = 0L;
            return true;
         } catch (IOException var3) {
            throw new ZipException(var3);
         }
      } else {
         return false;
      }
   }

   private boolean isBufferSizeFitForCurrSplitFile(int var1) {
      if (this.splitLength >= 65536L) {
         return this.bytesWrittenForThisPart + (long)var1 <= this.splitLength;
      } else {
         return true;
      }
   }

   public void seek(long var1) throws IOException {
      this.raf.seek(var1);
   }

   public int skipBytes(int var1) throws IOException {
      return this.raf.skipBytes(var1);
   }

   public void close() throws IOException {
      this.raf.close();
   }

   public long getFilePointer() throws IOException {
      return this.raf.getFilePointer();
   }

   public boolean isSplitZipFile() {
      return this.splitLength != -1L;
   }

   public long getSplitLength() {
      return this.splitLength;
   }

   public int getCurrentSplitFileCounter() {
      return this.currSplitFileCounter;
   }
}
