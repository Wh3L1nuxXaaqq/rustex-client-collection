package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.crypto.Encrypter;
import net.lingala.zip4j.model.ZipParameters;

abstract class CipherOutputStream<T extends Encrypter> extends OutputStream {
   private ZipEntryOutputStream zipEntryOutputStream;
   private T encrypter;

   public CipherOutputStream(ZipEntryOutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException {
      this.zipEntryOutputStream = var1;
      this.encrypter = this.initializeEncrypter(var1, var2, var3, var4);
   }

   public void write(int var1) throws IOException {
      this.zipEntryOutputStream.write(var1);
   }

   public void write(byte[] var1) throws IOException {
      this.zipEntryOutputStream.write(var1);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.encrypter.encryptData(var1, var2, var3);
      this.zipEntryOutputStream.write(var1, var2, var3);
   }

   public void writeHeaders(byte[] var1) throws IOException {
      this.zipEntryOutputStream.write(var1);
   }

   public void closeEntry() throws IOException {
      this.zipEntryOutputStream.closeEntry();
   }

   public void close() throws IOException {
      this.zipEntryOutputStream.close();
   }

   public long getNumberOfBytesWrittenForThisEntry() {
      return this.zipEntryOutputStream.getNumberOfBytesWrittenForThisEntry();
   }

   protected T getEncrypter() {
      return this.encrypter;
   }

   protected abstract T initializeEncrypter(OutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException;
}
