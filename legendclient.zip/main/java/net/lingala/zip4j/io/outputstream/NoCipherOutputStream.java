package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.crypto.Encrypter;
import net.lingala.zip4j.model.ZipParameters;

class NoCipherOutputStream extends CipherOutputStream<NoEncrypter> {
   public NoCipherOutputStream(ZipEntryOutputStream var1, ZipParameters var2, char[] var3) throws IOException {
      super(var1, var2, var3, true);
   }

   protected NoEncrypter initializeEncrypter(OutputStream var1, ZipParameters var2, char[] var3, boolean var4) {
      return new NoEncrypter();
   }

   static class NoEncrypter implements Encrypter {
      public int encryptData(byte[] var1) {
         return this.encryptData(var1, 0, var1.length);
      }

      public int encryptData(byte[] var1, int var2, int var3) {
         return var3;
      }
   }
}
