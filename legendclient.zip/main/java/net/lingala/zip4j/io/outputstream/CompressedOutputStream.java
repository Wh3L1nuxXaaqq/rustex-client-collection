package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;

abstract class CompressedOutputStream extends OutputStream {
   private CipherOutputStream<?> cipherOutputStream;

   public CompressedOutputStream(CipherOutputStream<?> var1) {
      this.cipherOutputStream = var1;
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.cipherOutputStream.write(var1, var2, var3);
   }

   protected void closeEntry() throws IOException {
      this.cipherOutputStream.closeEntry();
   }

   public void close() throws IOException {
      this.cipherOutputStream.close();
   }

   public long getCompressedSize() {
      return this.cipherOutputStream.getNumberOfBytesWrittenForThisEntry();
   }
}
