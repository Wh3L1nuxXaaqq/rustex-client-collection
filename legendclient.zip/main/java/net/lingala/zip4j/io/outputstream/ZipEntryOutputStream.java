package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;

class ZipEntryOutputStream extends OutputStream {
   private long numberOfBytesWrittenForThisEntry = 0L;
   private OutputStream outputStream;
   private boolean entryClosed;

   public ZipEntryOutputStream(OutputStream var1) {
      this.outputStream = var1;
      this.entryClosed = false;
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      if (this.entryClosed) {
         throw new IllegalStateException("ZipEntryOutputStream is closed");
      } else {
         this.outputStream.write(var1, var2, var3);
         this.numberOfBytesWrittenForThisEntry += (long)var3;
      }
   }

   public void closeEntry() throws IOException {
      this.entryClosed = true;
   }

   public long getNumberOfBytesWrittenForThisEntry() {
      return this.numberOfBytesWrittenForThisEntry;
   }

   public void close() throws IOException {
   }
}
