package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.zip.CRC32;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.FileHeaderFactory;
import net.lingala.zip4j.headers.HeaderSignature;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesVersion;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.Zip4jUtil;

public class ZipOutputStream extends OutputStream {
   private CountingOutputStream countingOutputStream;
   private char[] password;
   private ZipModel zipModel;
   private CompressedOutputStream compressedOutputStream;
   private FileHeader fileHeader;
   private LocalFileHeader localFileHeader;
   private FileHeaderFactory fileHeaderFactory;
   private HeaderWriter headerWriter;
   private CRC32 crc32;
   private RawIO rawIO;
   private long uncompressedSizeForThisEntry;
   private Zip4jConfig zip4jConfig;
   private boolean streamClosed;
   private boolean entryClosed;

   public ZipOutputStream(OutputStream var1) throws IOException {
      this(var1, (char[])null, (Charset)null);
   }

   public ZipOutputStream(OutputStream var1, Charset var2) throws IOException {
      this(var1, (char[])null, var2);
   }

   public ZipOutputStream(OutputStream var1, char[] var2) throws IOException {
      this(var1, var2, (Charset)null);
   }

   public ZipOutputStream(OutputStream var1, char[] var2, Charset var3) throws IOException {
      this(var1, var2, new Zip4jConfig(var3, 4096, true), new ZipModel());
   }

   public ZipOutputStream(OutputStream var1, char[] var2, Zip4jConfig var3, ZipModel var4) throws IOException {
      this.fileHeaderFactory = new FileHeaderFactory();
      this.headerWriter = new HeaderWriter();
      this.crc32 = new CRC32();
      this.rawIO = new RawIO();
      this.uncompressedSizeForThisEntry = 0L;
      this.entryClosed = true;
      if (var3.getBufferSize() < 512) {
         throw new IllegalArgumentException("Buffer size cannot be less than 512 bytes");
      } else {
         this.countingOutputStream = new CountingOutputStream(var1);
         this.password = var2;
         this.zip4jConfig = var3;
         this.zipModel = this.initializeZipModel(var4, this.countingOutputStream);
         this.streamClosed = false;
         this.writeSplitZipHeaderIfApplicable();
      }
   }

   public void putNextEntry(ZipParameters var1) throws IOException {
      this.verifyZipParameters(var1);
      ZipParameters var2 = this.cloneAndPrepareZipParameters(var1);
      this.initializeAndWriteFileHeader(var2);
      this.compressedOutputStream = this.initializeCompressedOutputStream(var2);
      this.entryClosed = false;
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.ensureStreamOpen();
      this.crc32.update(var1, var2, var3);
      this.compressedOutputStream.write(var1, var2, var3);
      this.uncompressedSizeForThisEntry += (long)var3;
   }

   public FileHeader closeEntry() throws IOException {
      this.compressedOutputStream.closeEntry();
      long var1 = this.compressedOutputStream.getCompressedSize();
      this.fileHeader.setCompressedSize(var1);
      this.localFileHeader.setCompressedSize(var1);
      this.fileHeader.setUncompressedSize(this.uncompressedSizeForThisEntry);
      this.localFileHeader.setUncompressedSize(this.uncompressedSizeForThisEntry);
      if (this.writeCrc(this.fileHeader)) {
         this.fileHeader.setCrc(this.crc32.getValue());
         this.localFileHeader.setCrc(this.crc32.getValue());
      }

      this.zipModel.getLocalFileHeaders().add(this.localFileHeader);
      this.zipModel.getCentralDirectory().getFileHeaders().add(this.fileHeader);
      if (this.localFileHeader.isDataDescriptorExists()) {
         this.headerWriter.writeExtendedLocalHeader(this.localFileHeader, this.countingOutputStream);
      }

      this.reset();
      this.entryClosed = true;
      return this.fileHeader;
   }

   public void close() throws IOException {
      if (!this.entryClosed) {
         this.closeEntry();
      }

      this.zipModel.getEndOfCentralDirectoryRecord().setOffsetOfStartOfCentralDirectory(this.countingOutputStream.getNumberOfBytesWritten());
      this.headerWriter.finalizeZipFile(this.zipModel, this.countingOutputStream, this.zip4jConfig.getCharset());
      this.countingOutputStream.close();
      this.streamClosed = true;
   }

   public void setComment(String var1) throws IOException {
      this.ensureStreamOpen();
      this.zipModel.getEndOfCentralDirectoryRecord().setComment(var1);
   }

   private void ensureStreamOpen() throws IOException {
      if (this.streamClosed) {
         throw new IOException("Stream is closed");
      }
   }

   private ZipModel initializeZipModel(ZipModel var1, CountingOutputStream var2) {
      if (var1 == null) {
         var1 = new ZipModel();
      }

      if (var2.isSplitZipFile()) {
         var1.setSplitArchive(true);
         var1.setSplitLength(var2.getSplitLength());
      }

      return var1;
   }

   private void initializeAndWriteFileHeader(ZipParameters var1) throws IOException {
      this.fileHeader = this.fileHeaderFactory.generateFileHeader(var1, this.countingOutputStream.isSplitZipFile(), this.countingOutputStream.getCurrentSplitFileCounter(), this.zip4jConfig.getCharset(), this.rawIO);
      this.fileHeader.setOffsetLocalHeader(this.countingOutputStream.getOffsetForNextEntry());
      this.localFileHeader = this.fileHeaderFactory.generateLocalFileHeader(this.fileHeader);
      this.headerWriter.writeLocalFileHeader(this.zipModel, this.localFileHeader, this.countingOutputStream, this.zip4jConfig.getCharset());
   }

   private void reset() throws IOException {
      this.uncompressedSizeForThisEntry = 0L;
      this.crc32.reset();
      this.compressedOutputStream.close();
   }

   private void writeSplitZipHeaderIfApplicable() throws IOException {
      if (this.countingOutputStream.isSplitZipFile()) {
         this.rawIO.writeIntLittleEndian(this.countingOutputStream, (int)HeaderSignature.SPLIT_ZIP.getValue());
      }
   }

   private CompressedOutputStream initializeCompressedOutputStream(ZipParameters var1) throws IOException {
      ZipEntryOutputStream var2 = new ZipEntryOutputStream(this.countingOutputStream);
      CipherOutputStream var3 = this.initializeCipherOutputStream(var2, var1);
      return this.initializeCompressedOutputStream(var3, var1);
   }

   private CipherOutputStream<?> initializeCipherOutputStream(ZipEntryOutputStream var1, ZipParameters var2) throws IOException {
      if (!var2.isEncryptFiles()) {
         return new NoCipherOutputStream(var1, var2, (char[])null);
      } else if (this.password != null && this.password.length != 0) {
         if (var2.getEncryptionMethod() == EncryptionMethod.AES) {
            return new AesCipherOutputStream(var1, var2, this.password, this.zip4jConfig.isUseUtf8CharsetForPasswords());
         } else if (var2.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD) {
            return new ZipStandardCipherOutputStream(var1, var2, this.password, this.zip4jConfig.isUseUtf8CharsetForPasswords());
         } else if (var2.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD_VARIANT_STRONG) {
            throw new ZipException(EncryptionMethod.ZIP_STANDARD_VARIANT_STRONG + " encryption method is not supported");
         } else {
            throw new ZipException("Invalid encryption method");
         }
      } else {
         throw new ZipException("password not set");
      }
   }

   private CompressedOutputStream initializeCompressedOutputStream(CipherOutputStream<?> var1, ZipParameters var2) {
      return (CompressedOutputStream)(var2.getCompressionMethod() == CompressionMethod.DEFLATE ? new DeflaterOutputStream(var1, var2.getCompressionLevel(), this.zip4jConfig.getBufferSize()) : new StoreOutputStream(var1));
   }

   private void verifyZipParameters(ZipParameters var1) {
      if (Zip4jUtil.isStringNullOrEmpty(var1.getFileNameInZip())) {
         throw new IllegalArgumentException("fileNameInZip is null or empty");
      } else if (var1.getCompressionMethod() == CompressionMethod.STORE && var1.getEntrySize() < 0L && !FileUtils.isZipEntryDirectory(var1.getFileNameInZip()) && var1.isWriteExtendedLocalFileHeader()) {
         throw new IllegalArgumentException("uncompressed size should be set for zip entries of compression type store");
      }
   }

   private boolean writeCrc(FileHeader var1) {
      boolean var2 = var1.isEncrypted() && var1.getEncryptionMethod().equals(EncryptionMethod.AES);
      return !var2 ? true : var1.getAesExtraDataRecord().getAesVersion().equals(AesVersion.ONE);
   }

   private ZipParameters cloneAndPrepareZipParameters(ZipParameters var1) {
      ZipParameters var2 = new ZipParameters(var1);
      if (FileUtils.isZipEntryDirectory(var1.getFileNameInZip())) {
         var2.setWriteExtendedLocalFileHeader(false);
         var2.setCompressionMethod(CompressionMethod.STORE);
         var2.setEncryptFiles(false);
         var2.setEntrySize(0L);
      }

      if (var1.getLastModifiedFileTime() <= 0L) {
         var2.setLastModifiedFileTime(System.currentTimeMillis());
      }

      return var2;
   }
}
