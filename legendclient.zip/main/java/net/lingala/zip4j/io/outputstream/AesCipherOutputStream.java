package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.crypto.AESEncrypter;
import net.lingala.zip4j.model.ZipParameters;

class AesCipherOutputStream extends CipherOutputStream<AESEncrypter> {
   private byte[] pendingBuffer = new byte[16];
   private int pendingBufferLength = 0;

   public AesCipherOutputStream(ZipEntryOutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException {
      super(var1, var2, var3, var4);
   }

   protected AESEncrypter initializeEncrypter(OutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException {
      AESEncrypter var5 = new AESEncrypter(var3, var2.getAesKeyStrength(), var4);
      this.writeAesEncryptionHeaderData(var5);
      return var5;
   }

   private void writeAesEncryptionHeaderData(AESEncrypter var1) throws IOException {
      this.writeHeaders(var1.getSaltBytes());
      this.writeHeaders(var1.getDerivedPasswordVerifier());
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      if (var3 >= 16 - this.pendingBufferLength) {
         System.arraycopy(var1, var2, this.pendingBuffer, this.pendingBufferLength, 16 - this.pendingBufferLength);
         super.write(this.pendingBuffer, 0, this.pendingBuffer.length);
         var2 = 16 - this.pendingBufferLength;
         var3 -= var2;
         this.pendingBufferLength = 0;
         if (var3 != 0 && var3 % 16 != 0) {
            System.arraycopy(var1, var3 + var2 - var3 % 16, this.pendingBuffer, 0, var3 % 16);
            this.pendingBufferLength = var3 % 16;
            var3 -= this.pendingBufferLength;
         }

         super.write(var1, var2, var3);
      } else {
         System.arraycopy(var1, var2, this.pendingBuffer, this.pendingBufferLength, var3);
         this.pendingBufferLength += var3;
      }
   }

   public void closeEntry() throws IOException {
      if (this.pendingBufferLength != 0) {
         super.write(this.pendingBuffer, 0, this.pendingBufferLength);
         this.pendingBufferLength = 0;
      }

      this.writeHeaders(((AESEncrypter)this.getEncrypter()).getFinalMac());
      super.closeEntry();
   }
}
