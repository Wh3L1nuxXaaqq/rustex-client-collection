package net.lingala.zip4j.io.outputstream;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.crypto.StandardEncrypter;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jUtil;

class ZipStandardCipherOutputStream extends CipherOutputStream<StandardEncrypter> {
   public ZipStandardCipherOutputStream(ZipEntryOutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException {
      super(var1, var2, var3, var4);
   }

   protected StandardEncrypter initializeEncrypter(OutputStream var1, ZipParameters var2, char[] var3, boolean var4) throws IOException {
      long var5 = this.getEncryptionKey(var2);
      StandardEncrypter var7 = new StandardEncrypter(var3, var5, var4);
      this.writeHeaders(var7.getHeaderBytes());
      return var7;
   }

   public void write(int var1) throws IOException {
      this.write(new byte[]{(byte)var1});
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      super.write(var1, var2, var3);
   }

   private long getEncryptionKey(ZipParameters var1) {
      if (var1.isWriteExtendedLocalFileHeader()) {
         long var2 = Zip4jUtil.epochToExtendedDosTime(var1.getLastModifiedFileTime());
         return (var2 & 65535L) << 16;
      } else {
         return var1.getEntryCRC();
      }
   }
}
