package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import java.io.InputStream;

class ZipEntryInputStream extends InputStream {
   private static final int MAX_RAW_READ_FULLY_RETRY_ATTEMPTS = 15;
   private InputStream inputStream;
   private long numberOfBytesRead = 0L;
   private byte[] singleByteArray = new byte[1];
   private long compressedSize;

   public ZipEntryInputStream(InputStream var1, long var2) {
      this.inputStream = var1;
      this.compressedSize = var2;
   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteArray);
      return var1 == -1 ? -1 : this.singleByteArray[0];
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (this.compressedSize != -1L) {
         if (this.numberOfBytesRead >= this.compressedSize) {
            return -1;
         }

         if ((long)var3 > this.compressedSize - this.numberOfBytesRead) {
            var3 = (int)(this.compressedSize - this.numberOfBytesRead);
         }
      }

      int var4 = this.inputStream.read(var1, var2, var3);
      if (var4 > 0) {
         this.numberOfBytesRead += (long)var4;
      }

      return var4;
   }

   public int readRawFully(byte[] var1) throws IOException {
      int var2 = this.inputStream.read(var1);
      if (var2 == -1) {
         throw new IOException("Unexpected EOF reached when trying to read stream");
      } else {
         if (var2 != var1.length) {
            var2 = this.readUntilBufferIsFull(var1, var2);
            if (var2 != var1.length) {
               throw new IOException("Cannot read fully into byte buffer");
            }
         }

         return var2;
      }
   }

   private int readUntilBufferIsFull(byte[] var1, int var2) throws IOException {
      int var3 = var1.length - var2;
      int var4 = 0;

      for(int var5 = 0; var2 < var1.length && var4 != -1 && var5 < 15; ++var5) {
         var4 += this.inputStream.read(var1, var2, var3);
         if (var4 > 0) {
            var2 += var4;
            var3 -= var4;
         }
      }

      return var2;
   }

   public void close() throws IOException {
      this.inputStream.close();
   }

   public long getNumberOfBytesRead() {
      return this.numberOfBytesRead;
   }
}
