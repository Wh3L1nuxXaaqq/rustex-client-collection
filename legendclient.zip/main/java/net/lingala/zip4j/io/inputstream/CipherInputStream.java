package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import java.io.InputStream;
import net.lingala.zip4j.crypto.Decrypter;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.util.Zip4jUtil;

abstract class CipherInputStream<T extends Decrypter> extends InputStream {
   private ZipEntryInputStream zipEntryInputStream;
   private T decrypter;
   private byte[] lastReadRawDataCache;
   private byte[] singleByteBuffer = new byte[1];
   private LocalFileHeader localFileHeader;

   public CipherInputStream(ZipEntryInputStream var1, LocalFileHeader var2, char[] var3, int var4, boolean var5) throws IOException {
      this.zipEntryInputStream = var1;
      this.decrypter = this.initializeDecrypter(var2, var3, var5);
      this.localFileHeader = var2;
      if (Zip4jUtil.getCompressionMethod(var2).equals(CompressionMethod.DEFLATE)) {
         this.lastReadRawDataCache = new byte[var4];
      }

   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteBuffer);
      return var1 == -1 ? -1 : this.singleByteBuffer[0] & 255;
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      int var4 = Zip4jUtil.readFully(this.zipEntryInputStream, var1, var2, var3);
      if (var4 > 0) {
         this.cacheRawData(var1, var4);
         this.decrypter.decryptData(var1, var2, var4);
      }

      return var4;
   }

   public void close() throws IOException {
      this.zipEntryInputStream.close();
   }

   public byte[] getLastReadRawDataCache() {
      return this.lastReadRawDataCache;
   }

   protected int readRaw(byte[] var1) throws IOException {
      return this.zipEntryInputStream.readRawFully(var1);
   }

   private void cacheRawData(byte[] var1, int var2) {
      if (this.lastReadRawDataCache != null) {
         System.arraycopy(var1, 0, this.lastReadRawDataCache, 0, var2);
      }

   }

   public T getDecrypter() {
      return this.decrypter;
   }

   protected void endOfEntryReached(InputStream var1, int var2) throws IOException {
   }

   protected long getNumberOfBytesReadForThisEntry() {
      return this.zipEntryInputStream.getNumberOfBytesRead();
   }

   public LocalFileHeader getLocalFileHeader() {
      return this.localFileHeader;
   }

   protected abstract T initializeDecrypter(LocalFileHeader var1, char[] var2, boolean var3) throws IOException;
}
