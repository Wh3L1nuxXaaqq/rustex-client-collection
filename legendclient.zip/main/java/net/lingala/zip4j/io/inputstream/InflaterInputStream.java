package net.lingala.zip4j.io.inputstream;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class InflaterInputStream extends DecompressedInputStream {
   private Inflater inflater = new Inflater(true);
   private byte[] buff;
   private byte[] singleByteBuffer = new byte[1];
   private int len;

   public InflaterInputStream(CipherInputStream<?> var1, int var2) {
      super(var1);
      this.buff = new byte[var2];
   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteBuffer);
      return var1 == -1 ? -1 : this.singleByteBuffer[0];
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      try {
         while(true) {
            int var4;
            if ((var4 = this.inflater.inflate(var1, var2, var3)) == 0) {
               if (!this.inflater.finished() && !this.inflater.needsDictionary()) {
                  if (this.inflater.needsInput()) {
                     this.fill();
                  }
                  continue;
               }

               return -1;
            }

            return var4;
         }
      } catch (DataFormatException var5) {
         throw new IOException(var5);
      }
   }

   public void endOfEntryReached(InputStream var1, int var2) throws IOException {
      if (this.inflater != null) {
         this.inflater.end();
         this.inflater = null;
      }

      super.endOfEntryReached(var1, var2);
   }

   public int pushBackInputStreamIfNecessary(PushbackInputStream var1) throws IOException {
      int var2 = this.inflater.getRemaining();
      if (var2 > 0) {
         byte[] var3 = this.getLastReadRawDataCache();
         var1.unread(var3, this.len - var2, var2);
      }

      return var2;
   }

   public void close() throws IOException {
      if (this.inflater != null) {
         this.inflater.end();
      }

      super.close();
   }

   private void fill() throws IOException {
      this.len = super.read(this.buff, 0, this.buff.length);
      if (this.len == -1) {
         throw new EOFException("Unexpected end of input stream");
      } else {
         this.inflater.setInput(this.buff, 0, this.len);
      }
   }
}
