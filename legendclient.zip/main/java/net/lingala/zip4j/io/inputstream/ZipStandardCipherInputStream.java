package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import net.lingala.zip4j.crypto.StandardDecrypter;
import net.lingala.zip4j.model.LocalFileHeader;

class ZipStandardCipherInputStream extends CipherInputStream<StandardDecrypter> {
   public ZipStandardCipherInputStream(ZipEntryInputStream var1, LocalFileHeader var2, char[] var3, int var4, boolean var5) throws IOException {
      super(var1, var2, var3, var4, var5);
   }

   protected StandardDecrypter initializeDecrypter(LocalFileHeader var1, char[] var2, boolean var3) throws IOException {
      return new StandardDecrypter(var2, var1.getCrc(), var1.getLastModifiedTime(), this.getStandardDecrypterHeaderBytes(), var3);
   }

   private byte[] getStandardDecrypterHeaderBytes() throws IOException {
      byte[] var1 = new byte[12];
      this.readRaw(var1);
      return var1;
   }
}
