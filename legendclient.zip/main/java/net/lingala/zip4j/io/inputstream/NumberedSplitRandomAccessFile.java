package net.lingala.zip4j.io.inputstream;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.util.FileUtils;

public class NumberedSplitRandomAccessFile extends RandomAccessFile {
   private long splitLength;
   private File[] allSortedSplitFiles;
   private RandomAccessFile randomAccessFile;
   private byte[] singleByteBuffer;
   private int currentOpenSplitFileCounter;
   private String rwMode;

   public NumberedSplitRandomAccessFile(String var1, String var2) throws IOException {
      this(new File(var1), var2);
   }

   public NumberedSplitRandomAccessFile(File var1, String var2) throws IOException {
      this(var1, var2, FileUtils.getAllSortedNumberedSplitFiles(var1));
   }

   public NumberedSplitRandomAccessFile(File var1, String var2, File[] var3) throws IOException {
      super(var1, var2);
      this.singleByteBuffer = new byte[1];
      this.currentOpenSplitFileCounter = 0;
      super.close();
      if (RandomAccessFileMode.WRITE.getValue().equals(var2)) {
         throw new IllegalArgumentException("write mode is not allowed for NumberedSplitRandomAccessFile");
      } else {
         this.assertAllSplitFilesExist(var3);
         this.randomAccessFile = new RandomAccessFile(var1, var2);
         this.allSortedSplitFiles = var3;
         this.splitLength = var1.length();
         this.rwMode = var2;
      }
   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteBuffer);
      return var1 == -1 ? -1 : this.singleByteBuffer[0] & 255;
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      int var4 = this.randomAccessFile.read(var1, var2, var3);
      if (var4 == -1) {
         if (this.currentOpenSplitFileCounter == this.allSortedSplitFiles.length - 1) {
            return -1;
         } else {
            this.openRandomAccessFileForIndex(this.currentOpenSplitFileCounter + 1);
            return this.read(var1, var2, var3);
         }
      } else {
         return var4;
      }
   }

   public void write(int var1) throws IOException {
      throw new UnsupportedOperationException();
   }

   public void write(byte[] var1) throws IOException {
      this.write(var1, 0, var1.length);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      throw new UnsupportedOperationException();
   }

   public void seek(long var1) throws IOException {
      int var3 = (int)(var1 / this.splitLength);
      if (var3 != this.currentOpenSplitFileCounter) {
         this.openRandomAccessFileForIndex(var3);
      }

      this.randomAccessFile.seek(var1 - (long)var3 * this.splitLength);
   }

   public long getFilePointer() throws IOException {
      return this.randomAccessFile.getFilePointer();
   }

   public long length() throws IOException {
      return this.randomAccessFile.length();
   }

   public void close() throws IOException {
      if (this.randomAccessFile != null) {
         this.randomAccessFile.close();
      }

      super.close();
   }

   public void seekInCurrentPart(long var1) throws IOException {
      this.randomAccessFile.seek(var1);
   }

   public void openLastSplitFileForReading() throws IOException {
      this.openRandomAccessFileForIndex(this.allSortedSplitFiles.length - 1);
   }

   private void openRandomAccessFileForIndex(int var1) throws IOException {
      if (this.currentOpenSplitFileCounter != var1) {
         if (var1 > this.allSortedSplitFiles.length - 1) {
            throw new IOException("split counter greater than number of split files");
         } else {
            if (this.randomAccessFile != null) {
               this.randomAccessFile.close();
            }

            this.randomAccessFile = new RandomAccessFile(this.allSortedSplitFiles[var1], this.rwMode);
            this.currentOpenSplitFileCounter = var1;
         }
      }
   }

   private void assertAllSplitFilesExist(File[] var1) throws IOException {
      int var2 = 1;

      for(File var6 : var1) {
         String var7 = FileUtils.getFileExtension(var6);

         try {
            if (var2 != Integer.parseInt(var7)) {
               throw new IOException("Split file number " + var2 + " does not exist");
            }

            ++var2;
         } catch (NumberFormatException var9) {
            throw new IOException("Split file extension not in expected format. Found: " + var7 + " expected of format: .001, .002, etc");
         }
      }

   }
}
