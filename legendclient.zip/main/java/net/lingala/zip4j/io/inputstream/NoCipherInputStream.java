package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import net.lingala.zip4j.crypto.Decrypter;
import net.lingala.zip4j.model.LocalFileHeader;

class NoCipherInputStream extends CipherInputStream<NoDecrypter> {
   public NoCipherInputStream(ZipEntryInputStream var1, LocalFileHeader var2, char[] var3, int var4) throws IOException {
      super(var1, var2, var3, var4, true);
   }

   protected NoDecrypter initializeDecrypter(LocalFileHeader var1, char[] var2, boolean var3) {
      return new NoDecrypter();
   }

   static class NoDecrypter implements Decrypter {
      public int decryptData(byte[] var1, int var2, int var3) {
         return var3;
      }
   }
}
