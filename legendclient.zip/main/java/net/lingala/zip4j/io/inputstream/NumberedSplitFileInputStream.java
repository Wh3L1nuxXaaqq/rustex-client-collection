package net.lingala.zip4j.io.inputstream;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;

public class NumberedSplitFileInputStream extends SplitFileInputStream {
   private RandomAccessFile randomAccessFile;

   public NumberedSplitFileInputStream(File var1) throws IOException {
      this.randomAccessFile = new NumberedSplitRandomAccessFile(var1, RandomAccessFileMode.READ.getValue());
   }

   public int read() throws IOException {
      return this.randomAccessFile.read();
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      return this.randomAccessFile.read(var1, var2, var3);
   }

   public void prepareExtractionForFileHeader(FileHeader var1) throws IOException {
      this.randomAccessFile.seek(var1.getOffsetLocalHeader());
   }

   public void close() throws IOException {
      if (this.randomAccessFile != null) {
         this.randomAccessFile.close();
      }

   }
}
