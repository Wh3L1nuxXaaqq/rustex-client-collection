package net.lingala.zip4j.io.inputstream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;

public class ZipStandardSplitFileInputStream extends SplitFileInputStream {
   protected RandomAccessFile randomAccessFile;
   protected File zipFile;
   private int lastSplitZipFileNumber;
   private boolean isSplitZipArchive;
   private int currentSplitFileCounter = 0;
   private byte[] singleByteArray = new byte[1];

   public ZipStandardSplitFileInputStream(File var1, boolean var2, int var3) throws FileNotFoundException {
      this.randomAccessFile = new RandomAccessFile(var1, RandomAccessFileMode.READ.getValue());
      this.zipFile = var1;
      this.isSplitZipArchive = var2;
      this.lastSplitZipFileNumber = var3;
      if (var2) {
         this.currentSplitFileCounter = var3;
      }

   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteArray);
      return var1 == -1 ? -1 : this.singleByteArray[0];
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      int var4 = this.randomAccessFile.read(var1, var2, var3);
      if ((var4 != var3 || var4 == -1) && this.isSplitZipArchive) {
         this.openRandomAccessFileForIndex(this.currentSplitFileCounter + 1);
         ++this.currentSplitFileCounter;
         if (var4 < 0) {
            var4 = 0;
         }

         int var5 = this.randomAccessFile.read(var1, var4, var3 - var4);
         if (var5 > 0) {
            var4 += var5;
         }
      }

      return var4;
   }

   public void prepareExtractionForFileHeader(FileHeader var1) throws IOException {
      if (this.isSplitZipArchive && this.currentSplitFileCounter != var1.getDiskNumberStart()) {
         this.openRandomAccessFileForIndex(var1.getDiskNumberStart());
         this.currentSplitFileCounter = var1.getDiskNumberStart();
      }

      this.randomAccessFile.seek(var1.getOffsetLocalHeader());
   }

   public void close() throws IOException {
      if (this.randomAccessFile != null) {
         this.randomAccessFile.close();
      }

   }

   protected void openRandomAccessFileForIndex(int var1) throws IOException {
      File var2 = this.getNextSplitFile(var1);
      if (!var2.exists()) {
         throw new FileNotFoundException("zip split file does not exist: " + var2);
      } else {
         this.randomAccessFile.close();
         this.randomAccessFile = new RandomAccessFile(var2, RandomAccessFileMode.READ.getValue());
      }
   }

   protected File getNextSplitFile(int var1) throws IOException {
      if (var1 == this.lastSplitZipFileNumber) {
         return this.zipFile;
      } else {
         String var2 = this.zipFile.getCanonicalPath();
         if (var1 >= 9) {
         }

         return new File(var2.substring(0, var2.lastIndexOf(".")) + var3 + (var1 + 1));
      }
   }
}
