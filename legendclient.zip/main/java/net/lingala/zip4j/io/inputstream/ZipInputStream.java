package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.charset.Charset;
import java.util.List;
import java.util.zip.CRC32;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderReader;
import net.lingala.zip4j.headers.HeaderSignature;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.DataDescriptor;
import net.lingala.zip4j.model.ExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.enums.AesVersion;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.util.PasswordCallback;
import net.lingala.zip4j.util.Zip4jUtil;

public class ZipInputStream extends InputStream {
   private PushbackInputStream inputStream;
   private DecompressedInputStream decompressedInputStream;
   private HeaderReader headerReader;
   private char[] password;
   private PasswordCallback passwordCallback;
   private LocalFileHeader localFileHeader;
   private CRC32 crc32;
   private byte[] endOfEntryBuffer;
   private boolean canSkipExtendedLocalFileHeader;
   private Zip4jConfig zip4jConfig;
   private boolean streamClosed;
   private boolean entryEOFReached;

   public ZipInputStream(InputStream var1) {
      this(var1, (char[])null, (Charset)null);
   }

   public ZipInputStream(InputStream var1, Charset var2) {
      this(var1, (char[])null, var2);
   }

   public ZipInputStream(InputStream var1, char[] var2) {
      this(var1, var2, (Charset)null);
   }

   public ZipInputStream(InputStream var1, PasswordCallback var2) {
      this(var1, var2, (Charset)null);
   }

   public ZipInputStream(InputStream var1, char[] var2, Charset var3) {
      this(var1, var2, new Zip4jConfig(var3, 4096, true));
   }

   public ZipInputStream(InputStream var1, PasswordCallback var2, Charset var3) {
      this(var1, var2, new Zip4jConfig(var3, 4096, true));
   }

   public ZipInputStream(InputStream var1, char[] var2, Zip4jConfig var3) {
      this(var1, var2, (PasswordCallback)null, var3);
   }

   public ZipInputStream(InputStream var1, PasswordCallback var2, Zip4jConfig var3) {
      this(var1, (char[])null, var2, var3);
   }

   private ZipInputStream(InputStream var1, char[] var2, PasswordCallback var3, Zip4jConfig var4) {
      this.headerReader = new HeaderReader();
      this.crc32 = new CRC32();
      this.canSkipExtendedLocalFileHeader = false;
      this.streamClosed = false;
      this.entryEOFReached = false;
      if (var4.getBufferSize() < 512) {
         throw new IllegalArgumentException("Buffer size cannot be less than 512 bytes");
      } else {
         this.inputStream = new PushbackInputStream(var1, var4.getBufferSize());
         this.password = var2;
         this.passwordCallback = var3;
         this.zip4jConfig = var4;
      }
   }

   public LocalFileHeader getNextEntry() throws IOException {
      return this.getNextEntry((FileHeader)null, true);
   }

   public LocalFileHeader getNextEntry(FileHeader var1, boolean var2) throws IOException {
      if (this.localFileHeader != null && var2) {
         this.readUntilEndOfEntry();
      }

      this.localFileHeader = this.headerReader.readLocalFileHeader(this.inputStream, this.zip4jConfig.getCharset());
      if (this.localFileHeader == null) {
         return null;
      } else {
         if (this.localFileHeader.isEncrypted() && this.password == null && this.passwordCallback != null) {
            this.setPassword(this.passwordCallback.getPassword());
         }

         this.verifyLocalFileHeader(this.localFileHeader);
         this.crc32.reset();
         if (var1 != null) {
            this.localFileHeader.setCrc(var1.getCrc());
            this.localFileHeader.setCompressedSize(var1.getCompressedSize());
            this.localFileHeader.setUncompressedSize(var1.getUncompressedSize());
            this.localFileHeader.setDirectory(var1.isDirectory());
            this.canSkipExtendedLocalFileHeader = true;
         } else {
            this.canSkipExtendedLocalFileHeader = false;
         }

         this.decompressedInputStream = this.initializeEntryInputStream(this.localFileHeader);
         this.entryEOFReached = false;
         return this.localFileHeader;
      }
   }

   public int read() throws IOException {
      byte[] var1 = new byte[1];
      int var2 = this.read(var1);
      return var2 == -1 ? -1 : var1[0] & 255;
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (this.streamClosed) {
         throw new IOException("Stream closed");
      } else if (var3 < 0) {
         throw new IllegalArgumentException("Negative read length");
      } else if (var3 == 0) {
         return 0;
      } else if (this.localFileHeader == null) {
         return -1;
      } else {
         try {
            int var4 = this.decompressedInputStream.read(var1, var2, var3);
            if (var4 == -1) {
               this.endOfCompressedDataReached();
            } else {
               this.crc32.update(var1, var2, var4);
            }

            return var4;
         } catch (IOException var5) {
            if (this.isEncryptionMethodZipStandard(this.localFileHeader)) {
               throw new ZipException(var5.getMessage(), var5.getCause(), ZipException.Type.WRONG_PASSWORD);
            } else {
               throw var5;
            }
         }
      }
   }

   public void close() throws IOException {
      if (!this.streamClosed) {
         if (this.decompressedInputStream != null) {
            this.decompressedInputStream.close();
         }

         this.streamClosed = true;
      }
   }

   public int available() throws IOException {
      this.assertStreamOpen();
      return this.entryEOFReached ? 0 : 1;
   }

   public void setPassword(char[] var1) {
      this.password = var1;
   }

   private void endOfCompressedDataReached() throws IOException {
      int var1 = this.decompressedInputStream.pushBackInputStreamIfNecessary(this.inputStream);
      this.decompressedInputStream.endOfEntryReached(this.inputStream, var1);
      this.readExtendedLocalFileHeaderIfPresent();
      this.verifyCrc();
      this.resetFields();
      this.entryEOFReached = true;
   }

   private DecompressedInputStream initializeEntryInputStream(LocalFileHeader var1) throws IOException {
      ZipEntryInputStream var2 = new ZipEntryInputStream(this.inputStream, this.getCompressedSize(var1));
      CipherInputStream var3 = this.initializeCipherInputStream(var2, var1);
      return this.initializeDecompressorForThisEntry(var3, var1);
   }

   private CipherInputStream<?> initializeCipherInputStream(ZipEntryInputStream var1, LocalFileHeader var2) throws IOException {
      if (!var2.isEncrypted()) {
         return new NoCipherInputStream(var1, var2, this.password, this.zip4jConfig.getBufferSize());
      } else if (var2.getEncryptionMethod() == EncryptionMethod.AES) {
         return new AesCipherInputStream(var1, var2, this.password, this.zip4jConfig.getBufferSize(), this.zip4jConfig.isUseUtf8CharsetForPasswords());
      } else if (var2.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD) {
         return new ZipStandardCipherInputStream(var1, var2, this.password, this.zip4jConfig.getBufferSize(), this.zip4jConfig.isUseUtf8CharsetForPasswords());
      } else {
         String var3 = String.format("Entry [%s] Strong Encryption not supported", var2.getFileName());
         throw new ZipException(var3, ZipException.Type.UNSUPPORTED_ENCRYPTION);
      }
   }

   private DecompressedInputStream initializeDecompressorForThisEntry(CipherInputStream<?> var1, LocalFileHeader var2) throws ZipException {
      CompressionMethod var3 = Zip4jUtil.getCompressionMethod(var2);
      return (DecompressedInputStream)(var3 == CompressionMethod.DEFLATE ? new InflaterInputStream(var1, this.zip4jConfig.getBufferSize()) : new StoreInputStream(var1));
   }

   private void readExtendedLocalFileHeaderIfPresent() throws IOException {
      if (this.localFileHeader.isDataDescriptorExists() && !this.canSkipExtendedLocalFileHeader) {
         DataDescriptor var1 = this.headerReader.readDataDescriptor(this.inputStream, this.checkIfZip64ExtraDataRecordPresentInLFH(this.localFileHeader.getExtraDataRecords()));
         this.localFileHeader.setCompressedSize(var1.getCompressedSize());
         this.localFileHeader.setUncompressedSize(var1.getUncompressedSize());
         this.localFileHeader.setCrc(var1.getCrc());
      }
   }

   private void verifyLocalFileHeader(LocalFileHeader var1) throws IOException {
      if (!this.isEntryDirectory(var1.getFileName()) && var1.getCompressionMethod() == CompressionMethod.STORE && var1.getUncompressedSize() < 0L) {
         throw new IOException("Invalid local file header for: " + var1.getFileName() + ". Uncompressed size has to be set for entry of compression type store which is not a directory");
      }
   }

   private boolean checkIfZip64ExtraDataRecordPresentInLFH(List<ExtraDataRecord> var1) {
      if (var1 == null) {
         return false;
      } else {
         for(ExtraDataRecord var3 : var1) {
            if (var3.getHeader() == HeaderSignature.ZIP64_EXTRA_FIELD_SIGNATURE.getValue()) {
               return true;
            }
         }

         return false;
      }
   }

   private void verifyCrc() throws IOException {
      if (this.localFileHeader.getEncryptionMethod() != EncryptionMethod.AES || !this.localFileHeader.getAesExtraDataRecord().getAesVersion().equals(AesVersion.TWO)) {
         if (this.localFileHeader.getCrc() != this.crc32.getValue()) {
            ZipException.Type var1 = ZipException.Type.CHECKSUM_MISMATCH;
            if (this.isEncryptionMethodZipStandard(this.localFileHeader)) {
               var1 = ZipException.Type.WRONG_PASSWORD;
            }

            throw new ZipException("Reached end of entry, but crc verification failed for " + this.localFileHeader.getFileName(), var1);
         }
      }
   }

   private void resetFields() {
      this.localFileHeader = null;
      this.crc32.reset();
   }

   private boolean isEntryDirectory(String var1) {
      return var1.endsWith("/") || var1.endsWith("\\");
   }

   private long getCompressedSize(LocalFileHeader var1) throws ZipException {
      if (Zip4jUtil.getCompressionMethod(var1).equals(CompressionMethod.STORE)) {
         return var1.getUncompressedSize();
      } else {
         return var1.isDataDescriptorExists() && !this.canSkipExtendedLocalFileHeader ? -1L : var1.getCompressedSize() - (long)this.getEncryptionHeaderSize(var1);
      }
   }

   private int getEncryptionHeaderSize(LocalFileHeader var1) throws ZipException {
      if (!var1.isEncrypted()) {
         return 0;
      } else if (var1.getEncryptionMethod().equals(EncryptionMethod.AES)) {
         return this.getAesEncryptionHeaderSize(var1.getAesExtraDataRecord());
      } else {
         return var1.getEncryptionMethod().equals(EncryptionMethod.ZIP_STANDARD) ? 12 : 0;
      }
   }

   private void readUntilEndOfEntry() throws IOException {
      if (this.endOfEntryBuffer == null) {
         this.endOfEntryBuffer = new byte[512];
      }

      while(this.read(this.endOfEntryBuffer) != -1) {
      }

      this.entryEOFReached = true;
   }

   private int getAesEncryptionHeaderSize(AESExtraDataRecord var1) throws ZipException {
      if (var1 != null && var1.getAesKeyStrength() != null) {
         return 12 + var1.getAesKeyStrength().getSaltLength();
      } else {
         throw new ZipException("AesExtraDataRecord not found or invalid for Aes encrypted entry");
      }
   }

   private boolean isEncryptionMethodZipStandard(LocalFileHeader var1) {
      return var1.isEncrypted() && EncryptionMethod.ZIP_STANDARD.equals(var1.getEncryptionMethod());
   }

   private void assertStreamOpen() throws IOException {
      if (this.streamClosed) {
         throw new IOException("Stream closed");
      }
   }
}
