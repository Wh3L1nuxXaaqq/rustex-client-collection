package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import net.lingala.zip4j.crypto.AESDecrypter;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.util.Zip4jUtil;

class AesCipherInputStream extends CipherInputStream<AESDecrypter> {
   private byte[] singleByteBuffer = new byte[1];
   private byte[] aes16ByteBlock = new byte[16];
   private int aes16ByteBlockPointer = 0;
   private int remainingAes16ByteBlockLength = 0;
   private int lengthToRead = 0;
   private int offsetWithAesBlock = 0;
   private int bytesCopiedInThisIteration = 0;
   private int lengthToCopyInThisIteration = 0;
   private int aes16ByteBlockReadLength = 0;

   public AesCipherInputStream(ZipEntryInputStream var1, LocalFileHeader var2, char[] var3, int var4, boolean var5) throws IOException {
      super(var1, var2, var3, var4, var5);
   }

   protected AESDecrypter initializeDecrypter(LocalFileHeader var1, char[] var2, boolean var3) throws IOException {
      return new AESDecrypter(var1.getAesExtraDataRecord(), var2, this.getSalt(var1), this.getPasswordVerifier(), var3);
   }

   public int read() throws IOException {
      int var1 = this.read(this.singleByteBuffer);
      return var1 == -1 ? -1 : this.singleByteBuffer[0];
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      this.lengthToRead = var3;
      this.offsetWithAesBlock = var2;
      this.bytesCopiedInThisIteration = 0;
      if (this.remainingAes16ByteBlockLength != 0) {
         this.copyBytesFromBuffer(var1, this.offsetWithAesBlock);
         if (this.bytesCopiedInThisIteration == var3) {
            return this.bytesCopiedInThisIteration;
         }
      }

      if (this.lengthToRead < 16) {
         this.aes16ByteBlockReadLength = super.read(this.aes16ByteBlock, 0, this.aes16ByteBlock.length);
         this.aes16ByteBlockPointer = 0;
         if (this.aes16ByteBlockReadLength == -1) {
            this.remainingAes16ByteBlockLength = 0;
            if (this.bytesCopiedInThisIteration > 0) {
               return this.bytesCopiedInThisIteration;
            }

            return -1;
         }

         this.remainingAes16ByteBlockLength = this.aes16ByteBlockReadLength;
         this.copyBytesFromBuffer(var1, this.offsetWithAesBlock);
         if (this.bytesCopiedInThisIteration == var3) {
            return this.bytesCopiedInThisIteration;
         }
      }

      int var4 = super.read(var1, this.offsetWithAesBlock, this.lengthToRead - this.lengthToRead % 16);
      if (var4 == -1) {
         return this.bytesCopiedInThisIteration > 0 ? this.bytesCopiedInThisIteration : -1;
      } else {
         return var4 + this.bytesCopiedInThisIteration;
      }
   }

   private void copyBytesFromBuffer(byte[] var1, int var2) {
      this.lengthToCopyInThisIteration = this.lengthToRead < this.remainingAes16ByteBlockLength ? this.lengthToRead : this.remainingAes16ByteBlockLength;
      System.arraycopy(this.aes16ByteBlock, this.aes16ByteBlockPointer, var1, var2, this.lengthToCopyInThisIteration);
      this.incrementAesByteBlockPointer(this.lengthToCopyInThisIteration);
      this.decrementRemainingAesBytesLength(this.lengthToCopyInThisIteration);
      this.bytesCopiedInThisIteration += this.lengthToCopyInThisIteration;
      this.lengthToRead -= this.lengthToCopyInThisIteration;
      this.offsetWithAesBlock += this.lengthToCopyInThisIteration;
   }

   protected void endOfEntryReached(InputStream var1, int var2) throws IOException {
      this.verifyContent(this.readStoredMac(var1), var2);
   }

   private void verifyContent(byte[] var1, int var2) throws IOException {
      byte[] var3 = ((AESDecrypter)this.getDecrypter()).getCalculatedAuthenticationBytes(var2);
      byte[] var4 = new byte[10];
      System.arraycopy(var3, 0, var4, 0, 10);
      if (!Arrays.equals(var1, var4)) {
         throw new IOException("Reached end of data for this entry, but aes verification failed");
      }
   }

   protected byte[] readStoredMac(InputStream var1) throws IOException {
      byte[] var2 = new byte[10];
      int var3 = Zip4jUtil.readFully(var1, var2);
      if (var3 != 10) {
         throw new ZipException("Invalid AES Mac bytes. Could not read sufficient data");
      } else {
         return var2;
      }
   }

   private byte[] getSalt(LocalFileHeader var1) throws IOException {
      if (var1.getAesExtraDataRecord() == null) {
         throw new IOException("invalid aes extra data record");
      } else {
         AESExtraDataRecord var2 = var1.getAesExtraDataRecord();
         if (var2.getAesKeyStrength() == null) {
            throw new IOException("Invalid aes key strength in aes extra data record");
         } else {
            byte[] var3 = new byte[var2.getAesKeyStrength().getSaltLength()];
            this.readRaw(var3);
            return var3;
         }
      }
   }

   private byte[] getPasswordVerifier() throws IOException {
      byte[] var1 = new byte[2];
      this.readRaw(var1);
      return var1;
   }

   private void incrementAesByteBlockPointer(int var1) {
      this.aes16ByteBlockPointer += var1;
      if (this.aes16ByteBlockPointer >= 15) {
         this.aes16ByteBlockPointer = 15;
      }

   }

   private void decrementRemainingAesBytesLength(int var1) {
      this.remainingAes16ByteBlockLength -= var1;
      if (this.remainingAes16ByteBlockLength <= 0) {
         this.remainingAes16ByteBlockLength = 0;
      }

   }
}
