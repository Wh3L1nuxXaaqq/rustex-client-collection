package net.lingala.zip4j.io.inputstream;

import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

abstract class DecompressedInputStream extends InputStream {
   private CipherInputStream<?> cipherInputStream;
   protected byte[] oneByteBuffer = new byte[1];

   public DecompressedInputStream(CipherInputStream<?> var1) {
      this.cipherInputStream = var1;
   }

   public int read() throws IOException {
      int var1 = this.read(this.oneByteBuffer);
      return var1 == -1 ? -1 : this.oneByteBuffer[0];
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      return this.cipherInputStream.read(var1, var2, var3);
   }

   public void close() throws IOException {
      this.cipherInputStream.close();
   }

   public void endOfEntryReached(InputStream var1, int var2) throws IOException {
      this.cipherInputStream.endOfEntryReached(var1, var2);
   }

   public int pushBackInputStreamIfNecessary(PushbackInputStream var1) throws IOException {
      return 0;
   }

   protected byte[] getLastReadRawDataCache() {
      return this.cipherInputStream.getLastReadRawDataCache();
   }
}
