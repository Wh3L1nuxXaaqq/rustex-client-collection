package net.lingala.zip4j.exception;

import java.io.IOException;

public class ZipException extends IOException {
   private static final long serialVersionUID = 1L;
   private Type type;

   public ZipException(String var1) {
      super(var1);
      this.type = ZipException.Type.UNKNOWN;
   }

   public ZipException(Exception var1) {
      super(var1);
      this.type = ZipException.Type.UNKNOWN;
   }

   public ZipException(String var1, Exception var2) {
      super(var1, var2);
      this.type = ZipException.Type.UNKNOWN;
   }

   public ZipException(String var1, Type var2) {
      super(var1);
      this.type = ZipException.Type.UNKNOWN;
      this.type = var2;
   }

   public ZipException(String var1, Throwable var2, Type var3) {
      super(var1, var2);
      this.type = ZipException.Type.UNKNOWN;
      this.type = var3;
   }

   public Type getType() {
      return this.type;
   }

   public static enum Type {
      WRONG_PASSWORD,
      TASK_CANCELLED_EXCEPTION,
      CHECKSUM_MISMATCH,
      UNKNOWN_COMPRESSION_METHOD,
      FILE_NOT_FOUND,
      UNSUPPORTED_ENCRYPTION,
      UNKNOWN;
   }
}
