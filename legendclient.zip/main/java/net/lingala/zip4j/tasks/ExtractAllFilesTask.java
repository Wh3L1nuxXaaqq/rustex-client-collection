package net.lingala.zip4j.tasks;

import java.io.IOException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.io.inputstream.SplitFileInputStream;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.UnzipUtil;

public class ExtractAllFilesTask extends AbstractExtractFileTask<ExtractAllFilesTaskParameters> {
   private final char[] password;
   private SplitFileInputStream splitInputStream;

   public ExtractAllFilesTask(ZipModel var1, char[] var2, UnzipParameters var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var1, var3, var4);
      this.password = var2;
   }

   protected void executeTask(ExtractAllFilesTaskParameters var1, ProgressMonitor var2) throws IOException {
      try {
         ZipInputStream var3 = this.prepareZipInputStream(var1.zip4jConfig);
         Throwable var4 = null;

         try {
            for(FileHeader var6 : this.getZipModel().getCentralDirectory().getFileHeaders()) {
               if (var6.getFileName().startsWith("__MACOSX")) {
                  var2.updateWorkCompleted(var6.getUncompressedSize());
               } else {
                  this.splitInputStream.prepareExtractionForFileHeader(var6);
                  byte[] var7 = new byte[var1.zip4jConfig.getBufferSize()];
                  this.extractFile(var3, var6, var1.outputPath, (String)null, var2, var7);
                  this.verifyIfTaskIsCancelled();
               }
            }
         } catch (Throwable var22) {
            var4 = var22;
            throw var22;
         } finally {
            if (var3 != null) {
               if (var4 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var21) {
                     var4.addSuppressed(var21);
                  }
               } else {
                  var3.close();
               }
            }

         }
      } finally {
         if (this.splitInputStream != null) {
            this.splitInputStream.close();
         }

      }

   }

   protected long calculateTotalWork(ExtractAllFilesTaskParameters var1) {
      return HeaderUtil.getTotalUncompressedSizeOfAllFileHeaders(this.getZipModel().getCentralDirectory().getFileHeaders());
   }

   private ZipInputStream prepareZipInputStream(Zip4jConfig var1) throws IOException {
      this.splitInputStream = UnzipUtil.createSplitInputStream(this.getZipModel());
      FileHeader var2 = this.getFirstFileHeader(this.getZipModel());
      if (var2 != null) {
         this.splitInputStream.prepareExtractionForFileHeader(var2);
      }

      return new ZipInputStream(this.splitInputStream, this.password, var1);
   }

   private FileHeader getFirstFileHeader(ZipModel var1) {
      return var1.getCentralDirectory() != null && var1.getCentralDirectory().getFileHeaders() != null && var1.getCentralDirectory().getFileHeaders().size() != 0 ? (FileHeader)var1.getCentralDirectory().getFileHeaders().get(0) : null;
   }

   public static class ExtractAllFilesTaskParameters extends AbstractZipTaskParameters {
      private final String outputPath;

      public ExtractAllFilesTaskParameters(String var1, Zip4jConfig var2) {
         super(var2);
         this.outputPath = var1;
      }
   }
}
