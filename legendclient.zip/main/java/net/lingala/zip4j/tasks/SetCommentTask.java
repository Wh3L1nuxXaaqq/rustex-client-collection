package net.lingala.zip4j.tasks;

import java.io.IOException;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.model.EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;

public class SetCommentTask extends AsyncZipTask<SetCommentTaskTaskParameters> {
   private final ZipModel zipModel;

   public SetCommentTask(ZipModel var1, AsyncZipTask.AsyncTaskParameters var2) {
      super(var2);
      this.zipModel = var1;
   }

   protected void executeTask(SetCommentTaskTaskParameters var1, ProgressMonitor var2) throws IOException {
      if (var1.comment == null) {
         throw new ZipException("comment is null, cannot update Zip file with comment");
      } else {
         EndOfCentralDirectoryRecord var3 = this.zipModel.getEndOfCentralDirectoryRecord();
         var3.setComment(var1.comment);
         SplitOutputStream var4 = new SplitOutputStream(this.zipModel.getZipFile());
         Throwable var5 = null;

         try {
            if (this.zipModel.isZip64Format()) {
               var4.seek(this.zipModel.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber());
            } else {
               var4.seek(var3.getOffsetOfStartOfCentralDirectory());
            }

            HeaderWriter var6 = new HeaderWriter();
            var6.finalizeZipFileWithoutValidations(this.zipModel, var4, var1.zip4jConfig.getCharset());
         } catch (Throwable var14) {
            var5 = var14;
            throw var14;
         } finally {
            if (var4 != null) {
               if (var5 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var13) {
                     var5.addSuppressed(var13);
                  }
               } else {
                  var4.close();
               }
            }

         }

      }
   }

   protected long calculateTotalWork(SetCommentTaskTaskParameters var1) {
      return 0L;
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.SET_COMMENT;
   }

   public static class SetCommentTaskTaskParameters extends AbstractZipTaskParameters {
      private String comment;

      public SetCommentTaskTaskParameters(String var1, Zip4jConfig var2) {
         super(var2);
         this.comment = var1;
      }
   }
}
