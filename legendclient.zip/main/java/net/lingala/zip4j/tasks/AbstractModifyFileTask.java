package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.FileUtils;

abstract class AbstractModifyFileTask<T> extends AsyncZipTask<T> {
   AbstractModifyFileTask(AsyncZipTask.AsyncTaskParameters var1) {
      super(var1);
   }

   File getTemporaryFile(String var1) {
      SecureRandom var2 = new SecureRandom();

      File var3;
      for(var3 = new File(var1 + var2.nextInt(10000)); var3.exists(); var3 = new File(var1 + var2.nextInt(10000))) {
      }

      return var3;
   }

   void updateOffsetsForAllSubsequentFileHeaders(List<FileHeader> var1, ZipModel var2, FileHeader var3, long var4) throws ZipException {
      int var6 = this.getIndexOfFileHeader(var1, var3);
      if (var6 == -1) {
         throw new ZipException("Could not locate modified file header in zipModel");
      } else {
         for(int var7 = var6 + 1; var7 < var1.size(); ++var7) {
            FileHeader var8 = (FileHeader)var1.get(var7);
            var8.setOffsetLocalHeader(var8.getOffsetLocalHeader() + var4);
            if (var2.isZip64Format() && var8.getZip64ExtendedInfo() != null && var8.getZip64ExtendedInfo().getOffsetLocalHeader() != -1L) {
               var8.getZip64ExtendedInfo().setOffsetLocalHeader(var8.getZip64ExtendedInfo().getOffsetLocalHeader() + var4);
            }
         }

      }
   }

   void cleanupFile(boolean var1, File var2, File var3) throws ZipException {
      if (var1) {
         this.restoreFileName(var2, var3);
      } else if (!var3.delete()) {
         throw new ZipException("Could not delete temporary file");
      }

   }

   long copyFile(RandomAccessFile var1, OutputStream var2, long var3, long var5, ProgressMonitor var7, int var8) throws IOException {
      FileUtils.copyFile(var1, var2, var3, var3 + var5, var7, var8);
      return var5;
   }

   List<FileHeader> cloneAndSortFileHeadersByOffset(List<FileHeader> var1) {
      ArrayList var2 = new ArrayList(var1);
      Collections.sort(var2, new Comparator<FileHeader>() {
         public int compare(FileHeader var1, FileHeader var2) {
            if (var1.getFileName().equals(var2.getFileName())) {
               return 0;
            } else {
               return var1.getOffsetLocalHeader() < var2.getOffsetLocalHeader() ? -1 : 1;
            }
         }
      });
      return var2;
   }

   long getOffsetOfNextEntry(List<FileHeader> var1, FileHeader var2, ZipModel var3) throws ZipException {
      int var4 = this.getIndexOfFileHeader(var1, var2);
      return var4 == var1.size() - 1 ? HeaderUtil.getOffsetStartOfCentralDirectory(var3) : ((FileHeader)var1.get(var4 + 1)).getOffsetLocalHeader();
   }

   private void restoreFileName(File var1, File var2) throws ZipException {
      if (var1.delete()) {
         if (!var2.renameTo(var1)) {
            throw new ZipException("cannot rename modified zip file");
         }
      } else {
         throw new ZipException("cannot delete old zip file");
      }
   }

   private int getIndexOfFileHeader(List<FileHeader> var1, FileHeader var2) throws ZipException {
      for(int var3 = 0; var3 < var1.size(); ++var3) {
         FileHeader var4 = (FileHeader)var1.get(var3);
         if (var4.equals(var2)) {
            return var3;
         }
      }

      throw new ZipException("Could not find file header in list of central directory file headers");
   }
}
