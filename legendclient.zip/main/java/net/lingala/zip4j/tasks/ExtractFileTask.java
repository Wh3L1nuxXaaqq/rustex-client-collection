package net.lingala.zip4j.tasks;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.io.inputstream.SplitFileInputStream;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.UnzipUtil;
import net.lingala.zip4j.util.Zip4jUtil;

public class ExtractFileTask extends AbstractExtractFileTask<ExtractFileTaskParameters> {
   private char[] password;
   private SplitFileInputStream splitInputStream;

   public ExtractFileTask(ZipModel var1, char[] var2, UnzipParameters var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var1, var3, var4);
      this.password = var2;
   }

   protected void executeTask(ExtractFileTaskParameters var1, ProgressMonitor var2) throws IOException {
      List var3 = this.getFileHeadersToExtract(var1.fileToExtract);

      try {
         ZipInputStream var4 = this.createZipInputStream(var1.zip4jConfig);
         Throwable var5 = null;

         try {
            byte[] var6 = new byte[var1.zip4jConfig.getBufferSize()];

            for(FileHeader var8 : var3) {
               this.splitInputStream.prepareExtractionForFileHeader(var8);
               String var9 = this.determineNewFileName(var1.newFileName, var1.fileToExtract, var8);
               this.extractFile(var4, var8, var1.outputPath, var9, var2, var6);
            }
         } catch (Throwable var24) {
            var5 = var24;
            throw var24;
         } finally {
            if (var4 != null) {
               if (var5 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var23) {
                     var5.addSuppressed(var23);
                  }
               } else {
                  var4.close();
               }
            }

         }
      } finally {
         if (this.splitInputStream != null) {
            this.splitInputStream.close();
         }

      }

   }

   protected long calculateTotalWork(ExtractFileTaskParameters var1) throws ZipException {
      List var2 = this.getFileHeadersToExtract(var1.fileToExtract);
      return HeaderUtil.getTotalUncompressedSizeOfAllFileHeaders(var2);
   }

   private List<FileHeader> getFileHeadersToExtract(String var1) throws ZipException {
      if (!FileUtils.isZipEntryDirectory(var1)) {
         FileHeader var2 = HeaderUtil.getFileHeader(this.getZipModel(), var1);
         if (var2 == null) {
            throw new ZipException("No file found with name " + var1 + " in zip file", ZipException.Type.FILE_NOT_FOUND);
         } else {
            return Collections.singletonList(var2);
         }
      } else {
         return HeaderUtil.getFileHeadersUnderDirectory(this.getZipModel().getCentralDirectory().getFileHeaders(), var1);
      }
   }

   private ZipInputStream createZipInputStream(Zip4jConfig var1) throws IOException {
      this.splitInputStream = UnzipUtil.createSplitInputStream(this.getZipModel());
      return new ZipInputStream(this.splitInputStream, this.password, var1);
   }

   private String determineNewFileName(String var1, String var2, FileHeader var3) {
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1)) {
         return var1;
      } else if (!FileUtils.isZipEntryDirectory(var2)) {
         return var1;
      } else {
         if (var1.endsWith("/")) {
         }

         return var3.getFileName().replaceFirst(var2, var1 + var4);
      }
   }

   public static class ExtractFileTaskParameters extends AbstractZipTaskParameters {
      private String outputPath;
      private String fileToExtract;
      private String newFileName;

      public ExtractFileTaskParameters(String var1, String var2, String var3, Zip4jConfig var4) {
         super(var4);
         this.outputPath = var1;
         this.fileToExtract = var2;
         this.newFileName = var3;
      }
   }
}
