package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.BitUtils;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.UnzipUtil;
import net.lingala.zip4j.util.Zip4jUtil;

public abstract class AbstractExtractFileTask<T> extends AsyncZipTask<T> {
   private final ZipModel zipModel;
   private final UnzipParameters unzipParameters;

   public AbstractExtractFileTask(ZipModel var1, UnzipParameters var2, AsyncZipTask.AsyncTaskParameters var3) {
      super(var3);
      this.zipModel = var1;
      this.unzipParameters = var2;
   }

   protected void extractFile(ZipInputStream var1, FileHeader var2, String var3, String var4, ProgressMonitor var5, byte[] var6) throws IOException {
      boolean var7 = this.isSymbolicLink(var2);
      if (!var7 || this.unzipParameters.isExtractSymbolicLinks()) {
         if (!var3.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
            var3 = var3 + InternalZipConstants.FILE_SEPARATOR;
         }

         File var8 = this.determineOutputFile(var2, var3, var4);
         var5.setFileName(var8.getAbsolutePath());
         this.assertCanonicalPathsAreSame(var8, var3, var2);
         this.verifyNextEntry(var1, var2);
         if (var2.isDirectory()) {
            if (!var8.exists() && !var8.mkdirs()) {
               throw new ZipException("Could not create directory: " + var8);
            }
         } else if (var7) {
            this.createSymLink(var1, var2, var8, var5);
         } else {
            this.checkOutputDirectoryStructure(var8);
            this.unzipFile(var1, var8, var5, var6);
         }

         if (!var7) {
            UnzipUtil.applyFileAttributes(var2, var8);
         }

      }
   }

   private void assertCanonicalPathsAreSame(File var1, String var2, FileHeader var3) throws IOException {
      String var4 = var1.getCanonicalPath();
      if (var1.isDirectory() && !var4.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
         var4 = var4 + InternalZipConstants.FILE_SEPARATOR;
      }

      String var5 = (new File(var2)).getCanonicalPath();
      if (!var5.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
         var5 = var5 + InternalZipConstants.FILE_SEPARATOR;
      }

      if (!var4.startsWith(var5)) {
         throw new ZipException("illegal file name that breaks out of the target directory: " + var3.getFileName());
      }
   }

   private boolean isSymbolicLink(FileHeader var1) {
      byte[] var2 = var1.getExternalFileAttributes();
      return var2 != null && var2.length >= 4 ? BitUtils.isBitSet(var2[3], 5) : false;
   }

   private void unzipFile(ZipInputStream var1, File var2, ProgressMonitor var3, byte[] var4) throws IOException {
      try {
         FileOutputStream var6 = new FileOutputStream(var2);
         Throwable var7 = null;

         try {
            int var5;
            try {
               while((var5 = var1.read(var4)) != -1) {
                  (OutputStream)var6).write(var4, 0, var5;
                  var3.updateWorkCompleted((long)var5);
                  this.verifyIfTaskIsCancelled();
               }
            } catch (Throwable var17) {
               var7 = var17;
               throw var17;
            }
         } finally {
            if (var6 != null) {
               if (var7 != null) {
                  try {
                     (OutputStream)var6).close(;
                  } catch (Throwable var16) {
                     var7.addSuppressed(var16);
                  }
               } else {
                  (OutputStream)var6).close(;
               }
            }

         }

      } catch (Exception var19) {
         if (var2.exists()) {
            var2.delete();
         }

         throw var19;
      }
   }

   private void createSymLink(ZipInputStream var1, FileHeader var2, File var3, ProgressMonitor var4) throws IOException {
      String var5 = new String(this.readCompleteEntry(var1, var2, var4));
      if (!var3.getParentFile().exists() && !var3.getParentFile().mkdirs()) {
         throw new ZipException("Could not create parent directories");
      } else {
         try {
            Path var6 = Paths.get(var5);
            if (var3.exists() && !var3.delete()) {
               throw new ZipException("Could not delete existing symlink " + var3);
            }

            Files.createSymbolicLink(var3.toPath(), var6);
         } catch (NoSuchMethodError var20) {
            FileOutputStream var7 = new FileOutputStream(var3);
            Throwable var8 = null;

            try {
               (OutputStream)var7).write(var5.getBytes();
            } catch (Throwable var18) {
               var8 = var18;
               throw var18;
            } finally {
               if (var7 != null) {
                  if (var8 != null) {
                     try {
                        (OutputStream)var7).close(;
                     } catch (Throwable var17) {
                        var8.addSuppressed(var17);
                     }
                  } else {
                     (OutputStream)var7).close(;
                  }
               }

            }
         }

      }
   }

   private byte[] readCompleteEntry(ZipInputStream var1, FileHeader var2, ProgressMonitor var3) throws IOException {
      byte[] var4 = new byte[(int)var2.getUncompressedSize()];
      int var5 = var1.read(var4);
      if (var5 != var4.length) {
         throw new ZipException("Could not read complete entry");
      } else {
         var3.updateWorkCompleted((long)var4.length);
         return var4;
      }
   }

   private void verifyNextEntry(ZipInputStream var1, FileHeader var2) throws IOException {
      if (BitUtils.isBitSet(var2.getGeneralPurposeFlag()[0], 6)) {
         throw new ZipException("Entry with name " + var2.getFileName() + " is encrypted with Strong Encryption. Zip4j does not support Strong Encryption, as this is patented.");
      } else {
         LocalFileHeader var3 = var1.getNextEntry(var2, false);
         if (var3 == null) {
            throw new ZipException("Could not read corresponding local file header for file header: " + var2.getFileName());
         } else if (!var2.getFileName().equals(var3.getFileName())) {
            throw new ZipException("File header and local file header mismatch");
         }
      }
   }

   private void checkOutputDirectoryStructure(File var1) throws ZipException {
      if (!var1.getParentFile().exists() && !var1.getParentFile().mkdirs()) {
         throw new ZipException("Unable to create parent directories: " + var1.getParentFile());
      }
   }

   private File determineOutputFile(FileHeader var1, String var2, String var3) {
      String var4 = var1.getFileName();
      if (Zip4jUtil.isStringNotNullAndNotEmpty(var3)) {
         var4 = var3;
      }

      return new File(var2, this.getFileNameWithSystemFileSeparators(var4));
   }

   private String getFileNameWithSystemFileSeparators(String var1) {
      String var2 = var1.replaceAll(":\\\\", "_");
      return var2.replaceAll("[/\\\\]", Matcher.quoteReplacement(InternalZipConstants.FILE_SEPARATOR));
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.EXTRACT_ENTRY;
   }

   public ZipModel getZipModel() {
      return this.zipModel;
   }
}
