package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.model.EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.progress.ProgressMonitor;

public class RemoveFilesFromZipTask extends AbstractModifyFileTask<RemoveFilesFromZipTaskParameters> {
   private final ZipModel zipModel;
   private final HeaderWriter headerWriter;

   public RemoveFilesFromZipTask(ZipModel var1, HeaderWriter var2, AsyncZipTask.AsyncTaskParameters var3) {
      super(var3);
      this.zipModel = var1;
      this.headerWriter = var2;
   }

   protected void executeTask(RemoveFilesFromZipTaskParameters var1, ProgressMonitor var2) throws IOException {
      if (this.zipModel.isSplitArchive()) {
         throw new ZipException("This is a split archive. Zip file format does not allow updating split/spanned files");
      } else {
         List var3 = this.filterNonExistingEntries(var1.filesToRemove);
         if (!var3.isEmpty()) {
            File var4 = this.getTemporaryFile(this.zipModel.getZipFile().getPath());
            boolean var5 = false;

            try {
               SplitOutputStream var6 = new SplitOutputStream(var4);
               Throwable var7 = null;

               try {
                  RandomAccessFile var8 = new RandomAccessFile(this.zipModel.getZipFile(), RandomAccessFileMode.READ.getValue());
                  Throwable var9 = null;

                  try {
                     long var10 = 0L;
                     List var12 = this.cloneAndSortFileHeadersByOffset(this.zipModel.getCentralDirectory().getFileHeaders());

                     for(FileHeader var14 : var12) {
                        long var15 = this.getOffsetOfNextEntry(var12, var14, this.zipModel) - var6.getFilePointer();
                        if (this.shouldEntryBeRemoved(var14, var3)) {
                           this.updateHeaders(var12, var14, var15);
                           if (!this.zipModel.getCentralDirectory().getFileHeaders().remove(var14)) {
                              throw new ZipException("Could not remove entry from list of central directory headers");
                           }

                           var10 += var15;
                        } else {
                           var10 += super.copyFile(var8, var6, var10, var15, var2, var1.zip4jConfig.getBufferSize());
                        }

                        this.verifyIfTaskIsCancelled();
                     }

                     this.headerWriter.finalizeZipFile(this.zipModel, var6, var1.zip4jConfig.getCharset());
                     var5 = true;
                  } catch (Throwable var50) {
                     var9 = var50;
                     throw var50;
                  } finally {
                     if (var8 != null) {
                        if (var9 != null) {
                           try {
                              var8.close();
                           } catch (Throwable var49) {
                              var9.addSuppressed(var49);
                           }
                        } else {
                           var8.close();
                        }
                     }

                  }
               } catch (Throwable var52) {
                  var7 = var52;
                  throw var52;
               } finally {
                  if (var6 != null) {
                     if (var7 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var48) {
                           var7.addSuppressed(var48);
                        }
                     } else {
                        var6.close();
                     }
                  }

               }
            } finally {
               this.cleanupFile(var5, this.zipModel.getZipFile(), var4);
            }

         }
      }
   }

   protected long calculateTotalWork(RemoveFilesFromZipTaskParameters var1) {
      return this.zipModel.getZipFile().length();
   }

   private List<String> filterNonExistingEntries(List<String> var1) throws ZipException {
      ArrayList var2 = new ArrayList();

      for(String var4 : var1) {
         if (HeaderUtil.getFileHeader(this.zipModel, var4) != null) {
            var2.add(var4);
         }
      }

      return var2;
   }

   private boolean shouldEntryBeRemoved(FileHeader var1, List<String> var2) {
      for(String var4 : var2) {
         if (var4.endsWith("/") && var1.getFileName().startsWith(var4)) {
            return true;
         }

         if (var1.getFileName().equals(var4)) {
            return true;
         }
      }

      return false;
   }

   private void updateHeaders(List<FileHeader> var1, FileHeader var2, long var3) throws ZipException {
      this.updateOffsetsForAllSubsequentFileHeaders(var1, this.zipModel, var2, this.negate(var3));
      EndOfCentralDirectoryRecord var5 = this.zipModel.getEndOfCentralDirectoryRecord();
      var5.setOffsetOfStartOfCentralDirectory(var5.getOffsetOfStartOfCentralDirectory() - var3);
      var5.setTotalNumberOfEntriesInCentralDirectory(var5.getTotalNumberOfEntriesInCentralDirectory() - 1);
      if (var5.getTotalNumberOfEntriesInCentralDirectoryOnThisDisk() > 0) {
         var5.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(var5.getTotalNumberOfEntriesInCentralDirectoryOnThisDisk() - 1);
      }

      if (this.zipModel.isZip64Format()) {
         this.zipModel.getZip64EndOfCentralDirectoryRecord().setOffsetStartCentralDirectoryWRTStartDiskNumber(this.zipModel.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber() - var3);
         this.zipModel.getZip64EndOfCentralDirectoryRecord().setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(this.zipModel.getZip64EndOfCentralDirectoryRecord().getTotalNumberOfEntriesInCentralDirectory() - 1L);
         this.zipModel.getZip64EndOfCentralDirectoryLocator().setOffsetZip64EndOfCentralDirectoryRecord(this.zipModel.getZip64EndOfCentralDirectoryLocator().getOffsetZip64EndOfCentralDirectoryRecord() - var3);
      }

   }

   private long negate(long var1) {
      if (var1 == Long.MIN_VALUE) {
         throw new ArithmeticException("long overflow");
      } else {
         return -var1;
      }
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.REMOVE_ENTRY;
   }

   public static class RemoveFilesFromZipTaskParameters extends AbstractZipTaskParameters {
      private final List<String> filesToRemove;

      public RemoveFilesFromZipTaskParameters(List<String> var1, Zip4jConfig var2) {
         super(var2);
         this.filesToRemove = var1;
      }
   }
}
