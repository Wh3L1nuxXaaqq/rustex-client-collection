package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.IOException;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.FileUtils;

public class AddFolderToZipTask extends AbstractAddFileToZipTask<AddFolderToZipTaskParameters> {
   public AddFolderToZipTask(ZipModel var1, char[] var2, HeaderWriter var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var1, var2, var3, var4);
   }

   protected void executeTask(AddFolderToZipTaskParameters var1, ProgressMonitor var2) throws IOException {
      List var3 = this.getFilesToAdd(var1);
      this.setDefaultFolderPath(var1);
      this.addFilesToZip(var3, var2, var1.zipParameters, var1.zip4jConfig);
   }

   protected long calculateTotalWork(AddFolderToZipTaskParameters var1) throws ZipException {
      List var2 = this.getFilesToAdd(var1);
      if (var1.zipParameters.isIncludeRootFolder()) {
         var2.add(var1.folderToAdd);
      }

      return this.calculateWorkForFiles(var2, var1.zipParameters);
   }

   private void setDefaultFolderPath(AddFolderToZipTaskParameters var1) throws IOException {
      File var3 = var1.folderToAdd;
      String var2;
      if (var1.zipParameters.isIncludeRootFolder()) {
         File var4 = var3.getCanonicalFile().getParentFile();
         if (var4 == null) {
            var2 = var3.getCanonicalPath();
         } else {
            var2 = var3.getCanonicalFile().getParentFile().getCanonicalPath();
         }
      } else {
         var2 = var3.getCanonicalPath();
      }

      var1.zipParameters.setDefaultFolderPath(var2);
   }

   private List<File> getFilesToAdd(AddFolderToZipTaskParameters var1) throws ZipException {
      List var2 = FileUtils.getFilesInDirectoryRecursive(var1.folderToAdd, var1.zipParameters);
      if (var1.zipParameters.isIncludeRootFolder()) {
         var2.add(var1.folderToAdd);
      }

      return var2;
   }

   public static class AddFolderToZipTaskParameters extends AbstractZipTaskParameters {
      private final File folderToAdd;
      private final ZipParameters zipParameters;

      public AddFolderToZipTaskParameters(File var1, ZipParameters var2, Zip4jConfig var3) {
         super(var3);
         this.folderToAdd = var1;
         this.zipParameters = var2;
      }
   }
}
