package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.io.outputstream.ZipOutputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.BitUtils;
import net.lingala.zip4j.util.CrcUtil;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.Zip4jUtil;

public abstract class AbstractAddFileToZipTask<T> extends AsyncZipTask<T> {
   private final ZipModel zipModel;
   private final char[] password;
   private final HeaderWriter headerWriter;

   AbstractAddFileToZipTask(ZipModel var1, char[] var2, HeaderWriter var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var4);
      this.zipModel = var1;
      this.password = var2;
      this.headerWriter = var3;
   }

   void addFilesToZip(List<File> var1, ProgressMonitor var2, ZipParameters var3, Zip4jConfig var4) throws IOException {
      FileUtils.assertFilesExist(var1, var3.getSymbolicLinkAction());
      byte[] var5 = new byte[var4.getBufferSize()];
      List var6 = this.removeFilesIfExists(var1, var3, var2, var4);
      SplitOutputStream var7 = new SplitOutputStream(this.zipModel.getZipFile(), this.zipModel.getSplitLength());
      Throwable var8 = null;

      try {
         ZipOutputStream var9 = this.initializeOutputStream(var7, var4);
         Throwable var10 = null;

         try {
            for(File var12 : var6) {
               this.verifyIfTaskIsCancelled();
               ZipParameters var13 = this.cloneAndAdjustZipParameters(var3, var12, var2);
               var2.setFileName(var12.getAbsolutePath());
               if (FileUtils.isSymbolicLink(var12) && this.addSymlink(var13)) {
                  this.addSymlinkToZip(var12, var9, var13, var7);
                  if (ZipParameters.SymbolicLinkAction.INCLUDE_LINK_ONLY.equals(var13.getSymbolicLinkAction())) {
                     continue;
                  }
               }

               this.addFileToZip(var12, var9, var13, var7, var2, var5);
            }
         } catch (Throwable var35) {
            var10 = var35;
            throw var35;
         } finally {
            if (var9 != null) {
               if (var10 != null) {
                  try {
                     var9.close();
                  } catch (Throwable var34) {
                     var10.addSuppressed(var34);
                  }
               } else {
                  var9.close();
               }
            }

         }
      } catch (Throwable var37) {
         var8 = var37;
         throw var37;
      } finally {
         if (var7 != null) {
            if (var8 != null) {
               try {
                  var7.close();
               } catch (Throwable var33) {
                  var8.addSuppressed(var33);
               }
            } else {
               var7.close();
            }
         }

      }

   }

   private void addSymlinkToZip(File var1, ZipOutputStream var2, ZipParameters var3, SplitOutputStream var4) throws IOException {
      ZipParameters var5 = new ZipParameters(var3);
      var5.setFileNameInZip(this.replaceFileNameInZip(var3.getFileNameInZip(), var1.getName()));
      var5.setEncryptFiles(false);
      var5.setCompressionMethod(CompressionMethod.STORE);
      var2.putNextEntry(var5);
      String var6 = FileUtils.readSymbolicLink(var1);
      var2.write(var6.getBytes());
      this.closeEntry(var2, var4, var1, true);
   }

   private void addFileToZip(File var1, ZipOutputStream var2, ZipParameters var3, SplitOutputStream var4, ProgressMonitor var5, byte[] var6) throws IOException {
      var2.putNextEntry(var3);
      if (var1.exists() && !var1.isDirectory()) {
         FileInputStream var8 = new FileInputStream(var1);
         Throwable var9 = null;

         try {
            int var7;
            try {
               while((var7 = ((InputStream)var8).read(var6)) != -1) {
                  var2.write(var6, 0, var7);
                  var5.updateWorkCompleted((long)var7);
                  this.verifyIfTaskIsCancelled();
               }
            } catch (Throwable var18) {
               var9 = var18;
               throw var18;
            }
         } finally {
            if (var8 != null) {
               if (var9 != null) {
                  try {
                     (InputStream)var8).close(;
                  } catch (Throwable var17) {
                     var9.addSuppressed(var17);
                  }
               } else {
                  (InputStream)var8).close(;
               }
            }

         }
      }

      this.closeEntry(var2, var4, var1, false);
   }

   private void closeEntry(ZipOutputStream var1, SplitOutputStream var2, File var3, boolean var4) throws IOException {
      FileHeader var5 = var1.closeEntry();
      byte[] var6 = FileUtils.getFileAttributes(var3);
      if (!var4) {
         var6[3] = BitUtils.unsetBit(var6[3], 5);
      }

      var5.setExternalFileAttributes(var6);
      this.updateLocalFileHeader(var5, var2);
   }

   long calculateWorkForFiles(List<File> var1, ZipParameters var2) throws ZipException {
      long var3 = 0L;

      for(File var6 : var1) {
         if (var6.exists()) {
            if (var2.isEncryptFiles() && var2.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD) {
               var3 += var6.length() * 2L;
            } else {
               var3 += var6.length();
            }

            String var7 = FileUtils.getRelativeFileName(var6, var2);
            FileHeader var8 = HeaderUtil.getFileHeader(this.getZipModel(), var7);
            if (var8 != null) {
               var3 += this.getZipModel().getZipFile().length() - var8.getCompressedSize();
            }
         }
      }

      return var3;
   }

   ZipOutputStream initializeOutputStream(SplitOutputStream var1, Zip4jConfig var2) throws IOException {
      if (this.zipModel.getZipFile().exists()) {
         var1.seek(HeaderUtil.getOffsetStartOfCentralDirectory(this.zipModel));
      }

      return new ZipOutputStream(var1, this.password, var2, this.zipModel);
   }

   void verifyZipParameters(ZipParameters var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("cannot validate zip parameters");
      } else if (var1.getCompressionMethod() != CompressionMethod.STORE && var1.getCompressionMethod() != CompressionMethod.DEFLATE) {
         throw new ZipException("unsupported compression type");
      } else {
         if (var1.isEncryptFiles()) {
            if (var1.getEncryptionMethod() == EncryptionMethod.NONE) {
               throw new ZipException("Encryption method has to be set, when encrypt files flag is set");
            }

            if (this.password == null || this.password.length <= 0) {
               throw new ZipException("input password is empty or null");
            }
         } else {
            var1.setEncryptionMethod(EncryptionMethod.NONE);
         }

      }
   }

   void updateLocalFileHeader(FileHeader var1, SplitOutputStream var2) throws IOException {
      this.headerWriter.updateLocalFileHeader(var1, this.getZipModel(), var2);
   }

   private ZipParameters cloneAndAdjustZipParameters(ZipParameters var1, File var2, ProgressMonitor var3) throws IOException {
      ZipParameters var4 = new ZipParameters(var1);
      if (var2.isDirectory()) {
         var4.setEntrySize(0L);
      } else {
         var4.setEntrySize(var2.length());
      }

      if (var1.getLastModifiedFileTime() <= 0L) {
         var4.setLastModifiedFileTime(var2.lastModified());
      }

      var4.setWriteExtendedLocalFileHeader(false);
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1.getFileNameInZip())) {
         String var5 = FileUtils.getRelativeFileName(var2, var1);
         var4.setFileNameInZip(var5);
      }

      if (var2.isDirectory()) {
         var4.setCompressionMethod(CompressionMethod.STORE);
         var4.setEncryptionMethod(EncryptionMethod.NONE);
         var4.setEncryptFiles(false);
      } else {
         if (var4.isEncryptFiles() && var4.getEncryptionMethod() == EncryptionMethod.ZIP_STANDARD) {
            var3.setCurrentTask(ProgressMonitor.Task.CALCULATE_CRC);
            var4.setEntryCRC(CrcUtil.computeFileCrc(var2, var3));
            var3.setCurrentTask(ProgressMonitor.Task.ADD_ENTRY);
         }

         if (var2.length() == 0L) {
            var4.setCompressionMethod(CompressionMethod.STORE);
         }
      }

      return var4;
   }

   private List<File> removeFilesIfExists(List<File> var1, ZipParameters var2, ProgressMonitor var3, Zip4jConfig var4) throws ZipException {
      ArrayList var5 = new ArrayList(var1);
      if (!this.zipModel.getZipFile().exists()) {
         return var5;
      } else {
         for(File var7 : var1) {
            if (!Zip4jUtil.isStringNotNullAndNotEmpty(var7.getName())) {
               var5.remove(var7);
            }

            String var8 = FileUtils.getRelativeFileName(var7, var2);
            FileHeader var9 = HeaderUtil.getFileHeader(this.zipModel, var8);
            if (var9 != null) {
               if (var2.isOverrideExistingFilesInZip()) {
                  var3.setCurrentTask(ProgressMonitor.Task.REMOVE_ENTRY);
                  this.removeFile(var9, var3, var4);
                  this.verifyIfTaskIsCancelled();
                  var3.setCurrentTask(ProgressMonitor.Task.ADD_ENTRY);
               } else {
                  var5.remove(var7);
               }
            }
         }

         return var5;
      }
   }

   void removeFile(FileHeader var1, ProgressMonitor var2, Zip4jConfig var3) throws ZipException {
      AsyncZipTask.AsyncTaskParameters var4 = new AsyncZipTask.AsyncTaskParameters((ExecutorService)null, false, var2);
      RemoveFilesFromZipTask var5 = new RemoveFilesFromZipTask(this.zipModel, this.headerWriter, var4);
      RemoveFilesFromZipTask.RemoveFilesFromZipTaskParameters var6 = new RemoveFilesFromZipTask.RemoveFilesFromZipTaskParameters(Collections.singletonList(var1.getFileName()), var3);
      var5.execute(var6);
   }

   private String replaceFileNameInZip(String var1, String var2) {
      return var1.contains("/") ? var1.substring(0, var1.lastIndexOf("/") + 1) + var2 : var2;
   }

   private boolean addSymlink(ZipParameters var1) {
      return ZipParameters.SymbolicLinkAction.INCLUDE_LINK_ONLY.equals(var1.getSymbolicLinkAction()) || ZipParameters.SymbolicLinkAction.INCLUDE_LINK_AND_LINKED_FILE.equals(var1.getSymbolicLinkAction());
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.ADD_ENTRY;
   }

   protected ZipModel getZipModel() {
      return this.zipModel;
   }
}
