package net.lingala.zip4j.tasks;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.progress.ProgressMonitor;

public abstract class AsyncZipTask<T> {
   private final ProgressMonitor progressMonitor;
   private final boolean runInThread;
   private final ExecutorService executorService;

   public AsyncZipTask(AsyncTaskParameters var1) {
      this.progressMonitor = var1.progressMonitor;
      this.runInThread = var1.runInThread;
      this.executorService = var1.executorService;
   }

   public void execute(final T var1) throws ZipException {
      if (this.runInThread && ProgressMonitor.State.BUSY.equals(this.progressMonitor.getState())) {
         throw new ZipException("invalid operation - Zip4j is in busy state");
      } else {
         this.initProgressMonitor();
         if (this.runInThread) {
            long var2 = this.calculateTotalWork(var1);
            this.progressMonitor.setTotalWork(var2);
            this.executorService.execute(new Runnable() {
               public void run() {
                  try {
                     AsyncZipTask.this.performTaskWithErrorHandling(var1, AsyncZipTask.this.progressMonitor);
                  } catch (ZipException var5) {
                  } finally {
                     AsyncZipTask.this.executorService.shutdown();
                  }

               }
            });
         } else {
            this.performTaskWithErrorHandling(var1, this.progressMonitor);
         }

      }
   }

   private void performTaskWithErrorHandling(T var1, ProgressMonitor var2) throws ZipException {
      try {
         this.executeTask(var1, var2);
         var2.endProgressMonitor();
      } catch (ZipException var4) {
         var2.endProgressMonitor(var4);
         throw var4;
      } catch (Exception var5) {
         var2.endProgressMonitor(var5);
         throw new ZipException(var5);
      }
   }

   protected void verifyIfTaskIsCancelled() throws ZipException {
      if (this.progressMonitor.isCancelAllTasks()) {
         this.progressMonitor.setResult(ProgressMonitor.Result.CANCELLED);
         this.progressMonitor.setState(ProgressMonitor.State.READY);
         throw new ZipException("Task cancelled", ZipException.Type.TASK_CANCELLED_EXCEPTION);
      }
   }

   private void initProgressMonitor() {
      this.progressMonitor.fullReset();
      this.progressMonitor.setState(ProgressMonitor.State.BUSY);
      this.progressMonitor.setCurrentTask(this.getTask());
   }

   protected abstract void executeTask(T var1, ProgressMonitor var2) throws IOException;

   protected abstract long calculateTotalWork(T var1) throws ZipException;

   protected abstract ProgressMonitor.Task getTask();

   public static class AsyncTaskParameters {
      private final ProgressMonitor progressMonitor;
      private final boolean runInThread;
      private final ExecutorService executorService;

      public AsyncTaskParameters(ExecutorService var1, boolean var2, ProgressMonitor var3) {
         this.executorService = var1;
         this.runInThread = var2;
         this.progressMonitor = var3;
      }
   }
}
