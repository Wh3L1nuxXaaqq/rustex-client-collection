package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.FileUtils;

public class AddFilesToZipTask extends AbstractAddFileToZipTask<AddFilesToZipTaskParameters> {
   public AddFilesToZipTask(ZipModel var1, char[] var2, HeaderWriter var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var1, var2, var3, var4);
   }

   protected void executeTask(AddFilesToZipTaskParameters var1, ProgressMonitor var2) throws IOException {
      this.verifyZipParameters(var1.zipParameters);
      List var3 = this.determineActualFilesToAdd(var1);
      this.addFilesToZip(var3, var2, var1.zipParameters, var1.zip4jConfig);
   }

   protected long calculateTotalWork(AddFilesToZipTaskParameters var1) throws ZipException {
      return this.calculateWorkForFiles(var1.filesToAdd, var1.zipParameters);
   }

   private List<File> determineActualFilesToAdd(AddFilesToZipTaskParameters var1) throws ZipException {
      ArrayList var2 = new ArrayList();

      for(File var4 : var1.filesToAdd) {
         var2.add(var4);
         boolean var5 = FileUtils.isSymbolicLink(var4);
         ZipParameters.SymbolicLinkAction var6 = var1.zipParameters.getSymbolicLinkAction();
         if (var5 && !ZipParameters.SymbolicLinkAction.INCLUDE_LINK_ONLY.equals(var6)) {
            var2.addAll(FileUtils.getFilesInDirectoryRecursive(var4, var1.zipParameters));
         }
      }

      return var2;
   }

   protected ProgressMonitor.Task getTask() {
      return super.getTask();
   }

   public static class AddFilesToZipTaskParameters extends AbstractZipTaskParameters {
      private final List<File> filesToAdd;
      private final ZipParameters zipParameters;

      public AddFilesToZipTaskParameters(List<File> var1, ZipParameters var2, Zip4jConfig var3) {
         super(var3);
         this.filesToAdd = var1;
         this.zipParameters = var2;
      }
   }
}
