package net.lingala.zip4j.tasks;

import java.io.IOException;
import java.io.InputStream;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.io.outputstream.ZipOutputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.Zip4jUtil;

public class AddStreamToZipTask extends AbstractAddFileToZipTask<AddStreamToZipTaskParameters> {
   public AddStreamToZipTask(ZipModel var1, char[] var2, HeaderWriter var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var1, var2, var3, var4);
   }

   protected void executeTask(AddStreamToZipTaskParameters var1, ProgressMonitor var2) throws IOException {
      this.verifyZipParameters(var1.zipParameters);
      if (!Zip4jUtil.isStringNotNullAndNotEmpty(var1.zipParameters.getFileNameInZip())) {
         throw new ZipException("fileNameInZip has to be set in zipParameters when adding stream");
      } else {
         this.removeFileIfExists(this.getZipModel(), var1.zip4jConfig, var1.zipParameters.getFileNameInZip(), var2);
         var1.zipParameters.setWriteExtendedLocalFileHeader(true);
         if (var1.zipParameters.getCompressionMethod().equals(CompressionMethod.STORE)) {
            var1.zipParameters.setEntrySize(0L);
         }

         SplitOutputStream var3 = new SplitOutputStream(this.getZipModel().getZipFile(), this.getZipModel().getSplitLength());
         Throwable var4 = null;

         try {
            ZipOutputStream var5 = this.initializeOutputStream(var3, var1.zip4jConfig);
            Throwable var6 = null;

            try {
               byte[] var7 = new byte[var1.zip4jConfig.getBufferSize()];
               ZipParameters var9 = var1.zipParameters;
               var5.putNextEntry(var9);
               int var8;
               if (!var9.getFileNameInZip().endsWith("/") && !var9.getFileNameInZip().endsWith("\\")) {
                  while((var8 = var1.inputStream.read(var7)) != -1) {
                     var5.write(var7, 0, var8);
                  }
               }

               FileHeader var10 = var5.closeEntry();
               if (CompressionMethod.STORE.equals(Zip4jUtil.getCompressionMethod(var10))) {
                  this.updateLocalFileHeader(var10, var3);
               }
            } catch (Throwable var32) {
               var6 = var32;
               throw var32;
            } finally {
               if (var5 != null) {
                  if (var6 != null) {
                     try {
                        var5.close();
                     } catch (Throwable var31) {
                        var6.addSuppressed(var31);
                     }
                  } else {
                     var5.close();
                  }
               }

            }
         } catch (Throwable var34) {
            var4 = var34;
            throw var34;
         } finally {
            if (var3 != null) {
               if (var4 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var30) {
                     var4.addSuppressed(var30);
                  }
               } else {
                  var3.close();
               }
            }

         }

      }
   }

   protected long calculateTotalWork(AddStreamToZipTaskParameters var1) {
      return 0L;
   }

   private void removeFileIfExists(ZipModel var1, Zip4jConfig var2, String var3, ProgressMonitor var4) throws ZipException {
      FileHeader var5 = HeaderUtil.getFileHeader(var1, var3);
      if (var5 != null) {
         this.removeFile(var5, var4, var2);
      }

   }

   public static class AddStreamToZipTaskParameters extends AbstractZipTaskParameters {
      private final InputStream inputStream;
      private final ZipParameters zipParameters;

      public AddStreamToZipTaskParameters(InputStream var1, ZipParameters var2, Zip4jConfig var3) {
         super(var3);
         this.inputStream = var1;
         this.zipParameters = var2;
      }
   }
}
