package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderUtil;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.io.outputstream.SplitOutputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.RawIO;
import net.lingala.zip4j.util.Zip4jUtil;

public class RenameFilesTask extends AbstractModifyFileTask<RenameFilesTaskParameters> {
   private final ZipModel zipModel;
   private final HeaderWriter headerWriter;
   private final RawIO rawIO;

   public RenameFilesTask(ZipModel var1, HeaderWriter var2, RawIO var3, AsyncZipTask.AsyncTaskParameters var4) {
      super(var4);
      this.zipModel = var1;
      this.headerWriter = var2;
      this.rawIO = var3;
   }

   protected void executeTask(RenameFilesTaskParameters var1, ProgressMonitor var2) throws IOException {
      Map var3 = this.filterNonExistingEntriesAndAddSeparatorIfNeeded(var1.fileNamesMap);
      if (var3.size() != 0) {
         File var4 = this.getTemporaryFile(this.zipModel.getZipFile().getPath());
         boolean var5 = false;

         try {
            RandomAccessFile var6 = new RandomAccessFile(this.zipModel.getZipFile(), RandomAccessFileMode.WRITE.getValue());
            Throwable var7 = null;

            try {
               SplitOutputStream var8 = new SplitOutputStream(var4);
               Throwable var9 = null;

               try {
                  long var10 = 0L;
                  Charset var12 = var1.zip4jConfig.getCharset();
                  List var13 = this.cloneAndSortFileHeadersByOffset(this.zipModel.getCentralDirectory().getFileHeaders());

                  for(FileHeader var15 : var13) {
                     Map.Entry var16 = this.getCorrespondingEntryFromMap(var15, var3);
                     var2.setFileName(var15.getFileName());
                     long var17 = this.getOffsetOfNextEntry(var13, var15, this.zipModel) - var8.getFilePointer();
                     if (var16 == null) {
                        var10 += this.copyFile(var6, var8, var10, var17, var2, var1.zip4jConfig.getBufferSize());
                     } else {
                        String var19 = this.getNewFileName((String)var16.getValue(), (String)var16.getKey(), var15.getFileName());
                        byte[] var20 = HeaderUtil.getBytesFromString(var19, var12);
                        int var21 = var20.length - var15.getFileNameLength();
                        var10 = this.copyEntryAndChangeFileName(var20, var15, var10, var17, var6, var8, var2, var1.zip4jConfig.getBufferSize());
                        this.updateHeadersInZipModel(var13, var15, var19, var20, var21);
                     }

                     this.verifyIfTaskIsCancelled();
                  }

                  this.headerWriter.finalizeZipFile(this.zipModel, var8, var12);
                  var5 = true;
               } catch (Throwable var55) {
                  var9 = var55;
                  throw var55;
               } finally {
                  if (var8 != null) {
                     if (var9 != null) {
                        try {
                           var8.close();
                        } catch (Throwable var54) {
                           var9.addSuppressed(var54);
                        }
                     } else {
                        var8.close();
                     }
                  }

               }
            } catch (Throwable var57) {
               var7 = var57;
               throw var57;
            } finally {
               if (var6 != null) {
                  if (var7 != null) {
                     try {
                        var6.close();
                     } catch (Throwable var53) {
                        var7.addSuppressed(var53);
                     }
                  } else {
                     var6.close();
                  }
               }

            }
         } finally {
            this.cleanupFile(var5, this.zipModel.getZipFile(), var4);
         }

      }
   }

   protected long calculateTotalWork(RenameFilesTaskParameters var1) {
      return this.zipModel.getZipFile().length();
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.RENAME_FILE;
   }

   private long copyEntryAndChangeFileName(byte[] var1, FileHeader var2, long var3, long var5, RandomAccessFile var7, OutputStream var8, ProgressMonitor var9, int var10) throws IOException {
      long var11 = var3 + this.copyFile(var7, var8, var3, 26L, var9, var10);
      this.rawIO.writeShortLittleEndian(var8, var1.length);
      var11 += 2L;
      var11 += this.copyFile(var7, var8, var11, 2L, var9, var10);
      var8.write(var1);
      var11 += (long)var2.getFileNameLength();
      long var13 = var5 - (var11 - var3);
      var11 += this.copyFile(var7, var8, var11, var13, var9, var10);
      return var11;
   }

   private Map.Entry<String, String> getCorrespondingEntryFromMap(FileHeader var1, Map<String, String> var2) {
      for(Map.Entry var4 : var2.entrySet()) {
         if (var1.getFileName().startsWith((String)var4.getKey())) {
            return var4;
         }
      }

      return null;
   }

   private void updateHeadersInZipModel(List<FileHeader> var1, FileHeader var2, String var3, byte[] var4, int var5) throws ZipException {
      FileHeader var6 = HeaderUtil.getFileHeader(this.zipModel, var2.getFileName());
      if (var6 == null) {
         throw new ZipException("could not find any header with name: " + var2.getFileName());
      } else {
         var6.setFileName(var3);
         var6.setFileNameLength(var4.length);
         this.updateOffsetsForAllSubsequentFileHeaders(var1, this.zipModel, var6, (long)var5);
         this.zipModel.getEndOfCentralDirectoryRecord().setOffsetOfStartOfCentralDirectory(this.zipModel.getEndOfCentralDirectoryRecord().getOffsetOfStartOfCentralDirectory() + (long)var5);
         if (this.zipModel.isZip64Format()) {
            this.zipModel.getZip64EndOfCentralDirectoryRecord().setOffsetStartCentralDirectoryWRTStartDiskNumber(this.zipModel.getZip64EndOfCentralDirectoryRecord().getOffsetStartCentralDirectoryWRTStartDiskNumber() + (long)var5);
            this.zipModel.getZip64EndOfCentralDirectoryLocator().setOffsetZip64EndOfCentralDirectoryRecord(this.zipModel.getZip64EndOfCentralDirectoryLocator().getOffsetZip64EndOfCentralDirectoryRecord() + (long)var5);
         }

      }
   }

   private Map<String, String> filterNonExistingEntriesAndAddSeparatorIfNeeded(Map<String, String> var1) throws ZipException {
      HashMap var2 = new HashMap();

      for(Map.Entry var4 : var1.entrySet()) {
         if (Zip4jUtil.isStringNotNullAndNotEmpty((String)var4.getKey())) {
            FileHeader var5 = HeaderUtil.getFileHeader(this.zipModel, (String)var4.getKey());
            if (var5 != null) {
               if (var5.isDirectory() && !((String)var4.getValue()).endsWith("/")) {
                  var2.put(var4.getKey(), (String)var4.getValue() + "/");
               } else {
                  var2.put(var4.getKey(), var4.getValue());
               }
            }
         }
      }

      return var2;
   }

   private String getNewFileName(String var1, String var2, String var3) throws ZipException {
      if (var3.equals(var2)) {
         return var1;
      } else if (var3.startsWith(var2)) {
         String var4 = var3.substring(var2.length());
         return var1 + var4;
      } else {
         throw new ZipException("old file name was neither an exact match nor a partial match");
      }
   }

   public static class RenameFilesTaskParameters extends AbstractZipTaskParameters {
      private final Map<String, String> fileNamesMap;

      public RenameFilesTaskParameters(Map<String, String> var1, Zip4jConfig var2) {
         super(var2);
         this.fileNamesMap = var1;
      }
   }
}
