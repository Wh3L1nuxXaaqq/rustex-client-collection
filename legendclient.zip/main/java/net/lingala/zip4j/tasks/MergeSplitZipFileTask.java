package net.lingala.zip4j.tasks;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.headers.HeaderSignature;
import net.lingala.zip4j.headers.HeaderWriter;
import net.lingala.zip4j.model.EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.Zip4jConfig;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryLocator;
import net.lingala.zip4j.model.Zip64EndOfCentralDirectoryRecord;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.enums.RandomAccessFileMode;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.FileUtils;
import net.lingala.zip4j.util.RawIO;

public class MergeSplitZipFileTask extends AsyncZipTask<MergeSplitZipFileTaskParameters> {
   private final ZipModel zipModel;
   private final RawIO rawIO = new RawIO();

   public MergeSplitZipFileTask(ZipModel var1, AsyncZipTask.AsyncTaskParameters var2) {
      super(var2);
      this.zipModel = var1;
   }

   protected void executeTask(MergeSplitZipFileTaskParameters var1, ProgressMonitor var2) throws IOException {
      if (!this.zipModel.isSplitArchive()) {
         ZipException var43 = new ZipException("archive not a split zip file");
         var2.endProgressMonitor(var43);
         throw var43;
      } else {
         try {
            FileOutputStream var3 = new FileOutputStream(var1.outputZipFile);
            Throwable var4 = null;

            try {
               long var5 = 0L;
               int var7 = this.zipModel.getEndOfCentralDirectoryRecord().getNumberOfThisDisk();
               if (var7 <= 0) {
                  throw new ZipException("zip archive not a split zip file");
               }

               byte var8 = 0;

               for(int var9 = 0; var9 <= var7; ++var9) {
                  RandomAccessFile var10 = this.createSplitZipFileStream(this.zipModel, var9);
                  Throwable var11 = null;

                  try {
                     byte var12 = 0;
                     long var13 = var10.length();
                     if (var9 == 0) {
                        if ((long)this.rawIO.readIntLittleEndian(var10) == HeaderSignature.SPLIT_ZIP.getValue()) {
                           var8 = 4;
                           var12 = 4;
                        } else {
                           var10.seek(0L);
                        }
                     }

                     if (var9 == var7) {
                        var13 = this.zipModel.getEndOfCentralDirectoryRecord().getOffsetOfStartOfCentralDirectory();
                     }

                     FileUtils.copyFile(var10, var3, (long)var12, var13, var2, var1.zip4jConfig.getBufferSize());
                     var5 += var13 - (long)var12;
                     this.updateFileHeaderOffsetsForIndex(this.zipModel.getCentralDirectory().getFileHeaders(), var9 == 0 ? 0L : var5, var9, var8);
                     this.verifyIfTaskIsCancelled();
                  } catch (Throwable var38) {
                     var11 = var38;
                     throw var38;
                  } finally {
                     if (var10 != null) {
                        if (var11 != null) {
                           try {
                              var10.close();
                           } catch (Throwable var37) {
                              var11.addSuppressed(var37);
                           }
                        } else {
                           var10.close();
                        }
                     }

                  }
               }

               this.updateHeadersForMergeSplitFileAction(this.zipModel, var5, var3, var1.zip4jConfig.getCharset());
               var2.endProgressMonitor();
            } catch (Throwable var40) {
               var4 = var40;
               throw var40;
            } finally {
               if (var3 != null) {
                  if (var4 != null) {
                     try {
                        (OutputStream)var3).close(;
                     } catch (Throwable var36) {
                        var4.addSuppressed(var36);
                     }
                  } else {
                     (OutputStream)var3).close(;
                  }
               }

            }

         } catch (CloneNotSupportedException var42) {
            throw new ZipException(var42);
         }
      }
   }

   protected long calculateTotalWork(MergeSplitZipFileTaskParameters var1) {
      if (!this.zipModel.isSplitArchive()) {
         return 0L;
      } else {
         long var2 = 0L;

         for(int var4 = 0; var4 <= this.zipModel.getEndOfCentralDirectoryRecord().getNumberOfThisDisk(); ++var4) {
            var2 += this.getNextSplitZipFile(this.zipModel, var4).length();
         }

         return var2;
      }
   }

   private void updateFileHeaderOffsetsForIndex(List<FileHeader> var1, long var2, int var4, int var5) {
      for(FileHeader var7 : var1) {
         if (var7.getDiskNumberStart() == var4) {
            var7.setOffsetLocalHeader(var7.getOffsetLocalHeader() + var2 - (long)var5);
            var7.setDiskNumberStart(0);
         }
      }

   }

   private File getNextSplitZipFile(ZipModel var1, int var2) {
      if (var2 == var1.getEndOfCentralDirectoryRecord().getNumberOfThisDisk()) {
         return var1.getZipFile();
      } else {
         if (var2 >= 9) {
         }

         String var4 = var1.getZipFile().getPath();
         String var5 = var1.getZipFile().getPath().substring(0, var4.lastIndexOf(".")) + var3 + (var2 + 1);
         return new File(var5);
      }
   }

   private RandomAccessFile createSplitZipFileStream(ZipModel var1, int var2) throws FileNotFoundException {
      File var3 = this.getNextSplitZipFile(var1, var2);
      return new RandomAccessFile(var3, RandomAccessFileMode.READ.getValue());
   }

   private void updateHeadersForMergeSplitFileAction(ZipModel var1, long var2, OutputStream var4, Charset var5) throws IOException, CloneNotSupportedException {
      ZipModel var6 = (ZipModel)var1.clone();
      var6.getEndOfCentralDirectoryRecord().setOffsetOfStartOfCentralDirectory(var2);
      this.updateSplitZipModel(var6, var2);
      HeaderWriter var7 = new HeaderWriter();
      var7.finalizeZipFileWithoutValidations(var6, var4, var5);
   }

   private void updateSplitZipModel(ZipModel var1, long var2) {
      var1.setSplitArchive(false);
      this.updateSplitEndCentralDirectory(var1);
      if (var1.isZip64Format()) {
         this.updateSplitZip64EndCentralDirLocator(var1, var2);
         this.updateSplitZip64EndCentralDirRec(var1, var2);
      }

   }

   private void updateSplitEndCentralDirectory(ZipModel var1) {
      int var2 = var1.getCentralDirectory().getFileHeaders().size();
      EndOfCentralDirectoryRecord var3 = var1.getEndOfCentralDirectoryRecord();
      var3.setNumberOfThisDisk(0);
      var3.setNumberOfThisDiskStartOfCentralDir(0);
      var3.setTotalNumberOfEntriesInCentralDirectory(var2);
      var3.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk(var2);
   }

   private void updateSplitZip64EndCentralDirLocator(ZipModel var1, long var2) {
      if (var1.getZip64EndOfCentralDirectoryLocator() != null) {
         Zip64EndOfCentralDirectoryLocator var4 = var1.getZip64EndOfCentralDirectoryLocator();
         var4.setNumberOfDiskStartOfZip64EndOfCentralDirectoryRecord(0);
         var4.setOffsetZip64EndOfCentralDirectoryRecord(var4.getOffsetZip64EndOfCentralDirectoryRecord() + var2);
         var4.setTotalNumberOfDiscs(1);
      }
   }

   private void updateSplitZip64EndCentralDirRec(ZipModel var1, long var2) {
      if (var1.getZip64EndOfCentralDirectoryRecord() != null) {
         Zip64EndOfCentralDirectoryRecord var4 = var1.getZip64EndOfCentralDirectoryRecord();
         var4.setNumberOfThisDisk(0);
         var4.setNumberOfThisDiskStartOfCentralDirectory(0);
         var4.setTotalNumberOfEntriesInCentralDirectoryOnThisDisk((long)var1.getEndOfCentralDirectoryRecord().getTotalNumberOfEntriesInCentralDirectory());
         var4.setOffsetStartCentralDirectoryWRTStartDiskNumber(var4.getOffsetStartCentralDirectoryWRTStartDiskNumber() + var2);
      }
   }

   protected ProgressMonitor.Task getTask() {
      return ProgressMonitor.Task.MERGE_ZIP_FILES;
   }

   public static class MergeSplitZipFileTaskParameters extends AbstractZipTaskParameters {
      private File outputZipFile;

      public MergeSplitZipFileTaskParameters(File var1, Zip4jConfig var2) {
         super(var2);
         this.outputZipFile = var1;
      }
   }
}
