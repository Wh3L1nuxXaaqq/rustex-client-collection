package net.lingala.zip4j.progress;

public class ProgressMonitor {
   private State state;
   private long totalWork;
   private long workCompleted;
   private int percentDone;
   private Task currentTask;
   private String fileName;
   private Result result;
   private Exception exception;
   private boolean cancelAllTasks;
   private boolean pause;

   public ProgressMonitor() {
      this.reset();
   }

   public void updateWorkCompleted(long var1) {
      this.workCompleted += var1;
      if (this.totalWork > 0L) {
         this.percentDone = (int)(this.workCompleted * 100L / this.totalWork);
         if (this.percentDone > 100) {
            this.percentDone = 100;
         }
      }

      while(this.pause) {
         try {
            Thread.sleep(150L);
         } catch (InterruptedException var4) {
         }
      }

   }

   public void endProgressMonitor() {
      this.result = ProgressMonitor.Result.SUCCESS;
      this.percentDone = 100;
      this.reset();
   }

   public void endProgressMonitor(Exception var1) {
      this.result = ProgressMonitor.Result.ERROR;
      this.exception = var1;
      this.reset();
   }

   public void fullReset() {
      this.reset();
      this.fileName = null;
      this.totalWork = 0L;
      this.workCompleted = 0L;
      this.percentDone = 0;
   }

   private void reset() {
      this.currentTask = ProgressMonitor.Task.NONE;
      this.state = ProgressMonitor.State.READY;
   }

   public State getState() {
      return this.state;
   }

   public void setState(State var1) {
      this.state = var1;
   }

   public long getTotalWork() {
      return this.totalWork;
   }

   public void setTotalWork(long var1) {
      this.totalWork = var1;
   }

   public long getWorkCompleted() {
      return this.workCompleted;
   }

   public int getPercentDone() {
      return this.percentDone;
   }

   public void setPercentDone(int var1) {
      this.percentDone = var1;
   }

   public Task getCurrentTask() {
      return this.currentTask;
   }

   public void setCurrentTask(Task var1) {
      this.currentTask = var1;
   }

   public String getFileName() {
      return this.fileName;
   }

   public void setFileName(String var1) {
      this.fileName = var1;
   }

   public Result getResult() {
      return this.result;
   }

   public void setResult(Result var1) {
      this.result = var1;
   }

   public Exception getException() {
      return this.exception;
   }

   public void setException(Exception var1) {
      this.exception = var1;
   }

   public boolean isCancelAllTasks() {
      return this.cancelAllTasks;
   }

   public void setCancelAllTasks(boolean var1) {
      this.cancelAllTasks = var1;
   }

   public boolean isPause() {
      return this.pause;
   }

   public void setPause(boolean var1) {
      this.pause = var1;
   }

   public static enum Result {
      SUCCESS,
      WORK_IN_PROGRESS,
      ERROR,
      CANCELLED;
   }

   public static enum State {
      READY,
      BUSY;
   }

   public static enum Task {
      NONE,
      ADD_ENTRY,
      REMOVE_ENTRY,
      CALCULATE_CRC,
      EXTRACT_ENTRY,
      MERGE_ZIP_FILES,
      SET_COMMENT,
      RENAME_FILE;
   }
}
