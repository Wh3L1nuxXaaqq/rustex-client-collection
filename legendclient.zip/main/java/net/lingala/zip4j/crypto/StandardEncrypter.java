package net.lingala.zip4j.crypto;

import java.security.SecureRandom;
import net.lingala.zip4j.crypto.engine.ZipCryptoEngine;
import net.lingala.zip4j.exception.ZipException;

public class StandardEncrypter implements Encrypter {
   private final ZipCryptoEngine zipCryptoEngine = new ZipCryptoEngine();
   private byte[] headerBytes;

   public StandardEncrypter(char[] var1, long var2, boolean var4) throws ZipException {
      this.init(var1, var2, var4);
   }

   private void init(char[] var1, long var2, boolean var4) throws ZipException {
      if (var1 != null && var1.length > 0) {
         this.zipCryptoEngine.initKeys(var1, var4);
         this.headerBytes = this.generateRandomBytes();
         this.zipCryptoEngine.initKeys(var1, var4);
         this.headerBytes[11] = (byte)((int)(var2 >>> 24));
         this.headerBytes[10] = (byte)((int)(var2 >>> 16));
         this.encryptData(this.headerBytes);
      } else {
         throw new ZipException("input password is null or empty, cannot initialize standard encrypter");
      }
   }

   public int encryptData(byte[] var1) throws ZipException {
      if (var1 == null) {
         throw new NullPointerException();
      } else {
         return this.encryptData(var1, 0, var1.length);
      }
   }

   public int encryptData(byte[] var1, int var2, int var3) throws ZipException {
      if (var3 < 0) {
         throw new ZipException("invalid length specified to decrpyt data");
      } else {
         for(int var4 = var2; var4 < var2 + var3; ++var4) {
            var1[var4] = this.encryptByte(var1[var4]);
         }

         return var3;
      }
   }

   protected byte encryptByte(byte var1) {
      byte var2 = (byte)(var1 ^ this.zipCryptoEngine.decryptByte() & 255);
      this.zipCryptoEngine.updateKeys(var1);
      return var2;
   }

   protected byte[] generateRandomBytes() {
      byte[] var1 = new byte[12];
      SecureRandom var2 = new SecureRandom();

      for(int var3 = 0; var3 < var1.length; ++var3) {
         var1[var3] = this.encryptByte((byte)var2.nextInt(256));
      }

      return var1;
   }

   public byte[] getHeaderBytes() {
      return this.headerBytes;
   }
}
