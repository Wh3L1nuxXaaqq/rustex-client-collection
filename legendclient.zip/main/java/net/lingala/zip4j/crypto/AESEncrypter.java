package net.lingala.zip4j.crypto;

import java.security.SecureRandom;
import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
import net.lingala.zip4j.crypto.engine.AESEngine;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.enums.AesKeyStrength;

public class AESEncrypter implements Encrypter {
   private AESEngine aesEngine;
   private MacBasedPRF mac;
   private final SecureRandom random = new SecureRandom();
   private boolean finished;
   private int nonce = 1;
   private int loopCount = 0;
   private final byte[] iv;
   private final byte[] counterBlock;
   private byte[] derivedPasswordVerifier;
   private byte[] saltBytes;

   public AESEncrypter(char[] var1, AesKeyStrength var2, boolean var3) throws ZipException {
      if (var1 != null && var1.length != 0) {
         if (var2 != AesKeyStrength.KEY_STRENGTH_128 && var2 != AesKeyStrength.KEY_STRENGTH_256) {
            throw new ZipException("Invalid AES key strength");
         } else {
            this.finished = false;
            this.counterBlock = new byte[16];
            this.iv = new byte[16];
            this.init(var1, var2, var3);
         }
      } else {
         throw new ZipException("input password is empty or null");
      }
   }

   private void init(char[] var1, AesKeyStrength var2, boolean var3) throws ZipException {
      this.saltBytes = this.generateSalt(var2.getSaltLength());
      byte[] var4 = AesCipherUtil.derivePasswordBasedKey(this.saltBytes, var1, var2, var3);
      this.derivedPasswordVerifier = AesCipherUtil.derivePasswordVerifier(var4, var2);
      this.aesEngine = AesCipherUtil.getAESEngine(var4, var2);
      this.mac = AesCipherUtil.getMacBasedPRF(var4, var2);
   }

   public int encryptData(byte[] var1) throws ZipException {
      if (var1 == null) {
         throw new ZipException("input bytes are null, cannot perform AES encryption");
      } else {
         return this.encryptData(var1, 0, var1.length);
      }
   }

   public int encryptData(byte[] var1, int var2, int var3) throws ZipException {
      if (this.finished) {
         throw new ZipException("AES Encrypter is in finished state (A non 16 byte block has already been passed to encrypter)");
      } else {
         if (var3 % 16 != 0) {
            this.finished = true;
         }

         for(int var4 = var2; var4 < var2 + var3; var4 += 16) {
            this.loopCount = var4 + 16 <= var2 + var3 ? 16 : var2 + var3 - var4;
            AesCipherUtil.prepareBuffAESIVBytes(this.iv, this.nonce);
            this.aesEngine.processBlock(this.iv, this.counterBlock);

            for(int var5 = 0; var5 < this.loopCount; ++var5) {
               var1[var4 + var5] ^= this.counterBlock[var5];
            }

            this.mac.update(var1, var4, this.loopCount);
            ++this.nonce;
         }

         return var3;
      }
   }

   private byte[] generateSalt(int var1) throws ZipException {
      if (var1 != 8 && var1 != 16) {
         throw new ZipException("invalid salt size, cannot generate salt");
      } else {
         byte var2;
         if (var1 == 8) {
            var2 = 2;
         } else {
            var2 = 4;
         }

         byte[] var3 = new byte[var1];

         for(int var4 = 0; var4 < var2; ++var4) {
            int var5 = this.random.nextInt();
            var3[var4 * 4] = (byte)(var5 >> 24);
            var3[1 + var4 * 4] = (byte)(var5 >> 16);
            var3[2 + var4 * 4] = (byte)(var5 >> 8);
            var3[3 + var4 * 4] = (byte)var5;
         }

         return var3;
      }
   }

   public byte[] getFinalMac() {
      byte[] var1 = this.mac.doFinal();
      byte[] var2 = new byte[10];
      System.arraycopy(var1, 0, var2, 0, 10);
      return var2;
   }

   public byte[] getDerivedPasswordVerifier() {
      return this.derivedPasswordVerifier;
   }

   public byte[] getSaltBytes() {
      return this.saltBytes;
   }
}
