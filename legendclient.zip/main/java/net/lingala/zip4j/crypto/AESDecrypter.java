package net.lingala.zip4j.crypto;

import java.util.Arrays;
import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
import net.lingala.zip4j.crypto.engine.AESEngine;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.enums.AesKeyStrength;

public class AESDecrypter implements Decrypter {
   private AESEngine aesEngine;
   private MacBasedPRF mac;
   private int nonce = 1;
   private byte[] iv = new byte[16];
   private byte[] counterBlock = new byte[16];

   public AESDecrypter(AESExtraDataRecord var1, char[] var2, byte[] var3, byte[] var4, boolean var5) throws ZipException {
      this.init(var3, var4, var2, var1, var5);
   }

   private void init(byte[] var1, byte[] var2, char[] var3, AESExtraDataRecord var4, boolean var5) throws ZipException {
      if (var3 != null && var3.length > 0) {
         AesKeyStrength var6 = var4.getAesKeyStrength();
         byte[] var7 = AesCipherUtil.derivePasswordBasedKey(var1, var3, var6, var5);
         byte[] var8 = AesCipherUtil.derivePasswordVerifier(var7, var6);
         if (!Arrays.equals(var2, var8)) {
            throw new ZipException("Wrong Password", ZipException.Type.WRONG_PASSWORD);
         } else {
            this.aesEngine = AesCipherUtil.getAESEngine(var7, var6);
            this.mac = AesCipherUtil.getMacBasedPRF(var7, var6);
         }
      } else {
         throw new ZipException("empty or null password provided for AES decryption", ZipException.Type.WRONG_PASSWORD);
      }
   }

   public int decryptData(byte[] var1, int var2, int var3) throws ZipException {
      for(int var4 = var2; var4 < var2 + var3; var4 += 16) {
         int var5 = var4 + 16 <= var2 + var3 ? 16 : var2 + var3 - var4;
         this.mac.update(var1, var4, var5);
         AesCipherUtil.prepareBuffAESIVBytes(this.iv, this.nonce);
         this.aesEngine.processBlock(this.iv, this.counterBlock);

         for(int var6 = 0; var6 < var5; ++var6) {
            var1[var4 + var6] ^= this.counterBlock[var6];
         }

         ++this.nonce;
      }

      return var3;
   }

   public byte[] getCalculatedAuthenticationBytes(int var1) {
      return this.mac.doFinal(var1);
   }
}
