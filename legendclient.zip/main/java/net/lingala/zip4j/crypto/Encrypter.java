package net.lingala.zip4j.crypto;

import net.lingala.zip4j.exception.ZipException;

public interface Encrypter {
   int encryptData(byte[] var1) throws ZipException;

   int encryptData(byte[] var1, int var2, int var3) throws ZipException;
}
