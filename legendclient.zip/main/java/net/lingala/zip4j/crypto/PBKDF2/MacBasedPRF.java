package net.lingala.zip4j.crypto.PBKDF2;

import java.io.ByteArrayOutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MacBasedPRF implements PRF {
   private Mac mac;
   private int hLen;
   private String macAlgorithm;
   private ByteArrayOutputStream macCache;

   public MacBasedPRF(String var1) {
      this.macAlgorithm = var1;
      this.macCache = new ByteArrayOutputStream(4096);

      try {
         this.mac = Mac.getInstance(var1);
         this.hLen = this.mac.getMacLength();
      } catch (NoSuchAlgorithmException var3) {
         throw new RuntimeException(var3);
      }
   }

   public byte[] doFinal(byte[] var1) {
      if (this.macCache.size() > 0) {
         this.doMacUpdate(0);
      }

      return this.mac.doFinal(var1);
   }

   public byte[] doFinal() {
      return this.doFinal(0);
   }

   public byte[] doFinal(int var1) {
      if (this.macCache.size() > 0) {
         this.doMacUpdate(var1);
      }

      return this.mac.doFinal();
   }

   public int getHLen() {
      return this.hLen;
   }

   public void init(byte[] var1) {
      try {
         this.mac.init(new SecretKeySpec(var1, this.macAlgorithm));
      } catch (InvalidKeyException var3) {
         throw new RuntimeException(var3);
      }
   }

   public void update(byte[] var1) {
      this.update(var1, 0, var1.length);
   }

   public void update(byte[] var1, int var2, int var3) {
      try {
         if (this.macCache.size() + var3 > 4096) {
            this.doMacUpdate(0);
         }

         this.macCache.write(var1, var2, var3);
      } catch (IllegalStateException var5) {
         throw new RuntimeException(var5);
      }
   }

   private void doMacUpdate(int var1) {
      byte[] var2 = this.macCache.toByteArray();
      int var3 = var2.length - var1;

      for(int var5 = 0; var5 < var3; var5 += 16) {
         int var4 = var5 + 16 <= var3 ? 16 : var3 - var5;
         this.mac.update(var2, var5, var4);
      }

      this.macCache.reset();
   }
}
