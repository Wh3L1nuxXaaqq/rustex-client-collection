package net.lingala.zip4j.crypto.PBKDF2;

class BinTools {
   public static final String hex = "0123456789ABCDEF";

   public static String bin2hex(byte[] var0) {
      if (var0 == null) {
         return "";
      } else {
         StringBuffer var1 = new StringBuffer(2 * var0.length);

         for(int var2 = 0; var2 < var0.length; ++var2) {
            int var3 = (256 + var0[var2]) % 256;
            var1.append("0123456789ABCDEF".charAt(var3 / 16 & 15));
            var1.append("0123456789ABCDEF".charAt(var3 % 16 & 15));
         }

         return var1.toString();
      }
   }

   public static byte[] hex2bin(String var0) {
      String var1 = var0;
      if (var0 == null) {
      } else if (var0.length() % 2 != 0) {
         var1 = "0" + var0;
      }

      byte[] var2 = new byte[var1.length() / 2];
      int var3 = 0;

      for(int var4 = 0; var3 < var1.length(); ++var4) {
         char var5 = var1.charAt(var3++);
         char var6 = var1.charAt(var3++);
         var2[var4] = (byte)(hex2bin(var5) * 16 + hex2bin(var6));
      }

      return var2;
   }

   public static int hex2bin(char var0) {
      if (var0 >= '0' && var0 <= '9') {
         return var0 - 48;
      } else if (var0 >= 'A' && var0 <= 'F') {
         return var0 - 65 + 10;
      } else if (var0 >= 'a' && var0 <= 'f') {
         return var0 - 97 + 10;
      } else {
         throw new IllegalArgumentException("Input string may only contain hex digits, but found '" + var0 + "'");
      }
   }
}
