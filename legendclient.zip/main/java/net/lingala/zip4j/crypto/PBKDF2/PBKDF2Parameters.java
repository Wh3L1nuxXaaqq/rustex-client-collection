package net.lingala.zip4j.crypto.PBKDF2;

public class PBKDF2Parameters {
   protected byte[] salt;
   protected int iterationCount;
   protected String hashAlgorithm;
   protected String hashCharset;
   protected byte[] derivedKey;

   public PBKDF2Parameters() {
      this.hashAlgorithm = null;
      this.hashCharset = "UTF-8";
      this.salt = null;
      this.iterationCount = 1000;
      this.derivedKey = null;
   }

   public PBKDF2Parameters(String var1, String var2, byte[] var3, int var4) {
      this(var1, var2, var3, var4, (byte[])null);
   }

   public PBKDF2Parameters(String var1, String var2, byte[] var3, int var4, byte[] var5) {
      this.hashAlgorithm = var1;
      this.hashCharset = var2;
      this.salt = var3;
      this.iterationCount = var4;
      this.derivedKey = var5;
   }

   public int getIterationCount() {
      return this.iterationCount;
   }

   public void setIterationCount(int var1) {
      this.iterationCount = var1;
   }

   public byte[] getSalt() {
      return this.salt;
   }

   public void setSalt(byte[] var1) {
      this.salt = var1;
   }

   public byte[] getDerivedKey() {
      return this.derivedKey;
   }

   public void setDerivedKey(byte[] var1) {
      this.derivedKey = var1;
   }

   public String getHashAlgorithm() {
      return this.hashAlgorithm;
   }

   public void setHashAlgorithm(String var1) {
      this.hashAlgorithm = var1;
   }

   public String getHashCharset() {
      return this.hashCharset;
   }

   public void setHashCharset(String var1) {
      this.hashCharset = var1;
   }
}
