package net.lingala.zip4j.crypto.PBKDF2;

interface PRF {
   void init(byte[] var1);

   byte[] doFinal(byte[] var1);

   int getHLen();
}
