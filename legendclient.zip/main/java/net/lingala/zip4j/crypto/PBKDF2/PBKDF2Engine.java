package net.lingala.zip4j.crypto.PBKDF2;

import net.lingala.zip4j.util.Zip4jUtil;

public class PBKDF2Engine {
   private PBKDF2Parameters parameters;
   private PRF prf;

   public PBKDF2Engine(PBKDF2Parameters var1) {
      this(var1, (PRF)null);
   }

   public PBKDF2Engine(PBKDF2Parameters var1, PRF var2) {
      this.parameters = var1;
      this.prf = var2;
   }

   public byte[] deriveKey(char[] var1, int var2, boolean var3) {
      if (var1 == null) {
         throw new NullPointerException();
      } else {
         byte[] var4 = Zip4jUtil.convertCharArrayToByteArray(var1, var3);
         this.assertPRF(var4);
         if (var2 == 0) {
            var2 = this.prf.getHLen();
         }

         return this.PBKDF2(this.prf, this.parameters.getSalt(), this.parameters.getIterationCount(), var2);
      }
   }

   private void assertPRF(byte[] var1) {
      if (this.prf == null) {
         this.prf = new MacBasedPRF(this.parameters.getHashAlgorithm());
      }

      this.prf.init(var1);
   }

   private byte[] PBKDF2(PRF var1, byte[] var2, int var3, int var4) {
      if (var2 == null) {
         var2 = new byte[0];
      }

      int var5 = var1.getHLen();
      int var6 = this.ceil(var4, var5);
      int var7 = var4 - (var6 - 1) * var5;
      byte[] var8 = new byte[var6 * var5];
      int var9 = 0;

      for(int var10 = 1; var10 <= var6; ++var10) {
         this._F(var8, var9, var1, var2, var3, var10);
         var9 += var5;
      }

      if (var7 < var5) {
         byte[] var11 = new byte[var4];
         System.arraycopy(var8, 0, var11, 0, var4);
         return var11;
      } else {
         return var8;
      }
   }

   private int ceil(int var1, int var2) {
      byte var3 = 0;
      if (var1 % var2 > 0) {
         var3 = 1;
      }

      return var1 / var2 + var3;
   }

   private void _F(byte[] var1, int var2, PRF var3, byte[] var4, int var5, int var6) {
      int var7 = var3.getHLen();
      byte[] var8 = new byte[var7];
      byte[] var9 = new byte[var4.length + 4];
      System.arraycopy(var4, 0, var9, 0, var4.length);
      this.INT(var9, var4.length, var6);

      for(int var10 = 0; var10 < var5; ++var10) {
         var9 = var3.doFinal(var9);
         this.xor(var8, var9);
      }

      System.arraycopy(var8, 0, var1, var2, var7);
   }

   private void xor(byte[] var1, byte[] var2) {
      for(int var3 = 0; var3 < var1.length; ++var3) {
         var1[var3] ^= var2[var3];
      }

   }

   protected void INT(byte[] var1, int var2, int var3) {
      var1[var2] = (byte)(var3 / 16777216);
      var1[var2 + 1] = (byte)(var3 / 65536);
      var1[var2 + 2] = (byte)(var3 / 256);
      var1[var2 + 3] = (byte)var3;
   }

   public PBKDF2Parameters getParameters() {
      return this.parameters;
   }

   public void setParameters(PBKDF2Parameters var1) {
      this.parameters = var1;
   }

   public void setPseudoRandomFunction(PRF var1) {
      this.prf = var1;
   }
}
