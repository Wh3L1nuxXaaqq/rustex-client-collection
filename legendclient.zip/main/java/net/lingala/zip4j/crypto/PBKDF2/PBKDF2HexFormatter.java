package net.lingala.zip4j.crypto.PBKDF2;

class PBKDF2HexFormatter {
   public boolean fromString(PBKDF2Parameters var1, String var2) {
      if (var1 != null && var2 != null) {
         String[] var3 = var2.split(":");
         if (var3.length != 3) {
            return true;
         } else {
            byte[] var4 = BinTools.hex2bin(var3[0]);
            int var5 = Integer.parseInt(var3[1]);
            byte[] var6 = BinTools.hex2bin(var3[2]);
            var1.setSalt(var4);
            var1.setIterationCount(var5);
            var1.setDerivedKey(var6);
            return false;
         }
      } else {
         return true;
      }
   }

   public String toString(PBKDF2Parameters var1) {
      String var2 = BinTools.bin2hex(var1.getSalt()) + ":" + var1.getIterationCount() + ":" + BinTools.bin2hex(var1.getDerivedKey());
      return var2;
   }
}
