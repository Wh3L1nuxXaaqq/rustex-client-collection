package net.lingala.zip4j.crypto;

import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters;
import net.lingala.zip4j.crypto.engine.AESEngine;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.enums.AesKeyStrength;

public class AesCipherUtil {
   private static final int START_INDEX = 0;

   public static byte[] derivePasswordBasedKey(byte[] var0, char[] var1, AesKeyStrength var2, boolean var3) throws ZipException {
      PBKDF2Parameters var4 = new PBKDF2Parameters("HmacSHA1", "ISO-8859-1", var0, 1000);
      PBKDF2Engine var5 = new PBKDF2Engine(var4);
      int var6 = var2.getKeyLength();
      int var7 = var2.getMacLength();
      int var8 = var6 + var7 + 2;
      byte[] var9 = var5.deriveKey(var1, var8, var3);
      if (var9 != null && var9.length == var8) {
         return var9;
      } else {
         String var10 = String.format("Derived Key invalid for Key Length [%d] MAC Length [%d]", var6, var7);
         throw new ZipException(var10);
      }
   }

   public static byte[] derivePasswordVerifier(byte[] var0, AesKeyStrength var1) {
      byte[] var2 = new byte[2];
      int var3 = var1.getKeyLength() + var1.getMacLength();
      System.arraycopy(var0, var3, var2, 0, 2);
      return var2;
   }

   public static MacBasedPRF getMacBasedPRF(byte[] var0, AesKeyStrength var1) {
      int var2 = var1.getMacLength();
      byte[] var3 = new byte[var2];
      System.arraycopy(var0, var1.getKeyLength(), var3, 0, var2);
      MacBasedPRF var4 = new MacBasedPRF("HmacSHA1");
      var4.init(var3);
      return var4;
   }

   public static AESEngine getAESEngine(byte[] var0, AesKeyStrength var1) throws ZipException {
      int var2 = var1.getKeyLength();
      byte[] var3 = new byte[var2];
      System.arraycopy(var0, 0, var3, 0, var2);
      return new AESEngine(var3);
   }

   public static void prepareBuffAESIVBytes(byte[] var0, int var1) {
      var0[0] = (byte)var1;
      var0[1] = (byte)(var1 >> 8);
      var0[2] = (byte)(var1 >> 16);
      var0[3] = (byte)(var1 >> 24);

      for(int var2 = 4; var2 <= 15; ++var2) {
         var0[var2] = 0;
      }

   }
}
