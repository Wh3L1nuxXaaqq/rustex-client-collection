package net.lingala.zip4j.crypto;

import net.lingala.zip4j.crypto.engine.ZipCryptoEngine;
import net.lingala.zip4j.exception.ZipException;

public class StandardDecrypter implements Decrypter {
   private ZipCryptoEngine zipCryptoEngine = new ZipCryptoEngine();

   public StandardDecrypter(char[] var1, long var2, long var4, byte[] var6, boolean var7) throws ZipException {
      this.init(var6, var1, var4, var2, var7);
   }

   public int decryptData(byte[] var1, int var2, int var3) throws ZipException {
      if (var2 >= 0 && var3 >= 0) {
         for(int var4 = var2; var4 < var2 + var3; ++var4) {
            int var5 = var1[var4] & 255;
            var5 = (var5 ^ this.zipCryptoEngine.decryptByte()) & 255;
            this.zipCryptoEngine.updateKeys((byte)var5);
            var1[var4] = (byte)var5;
         }

         return var3;
      } else {
         throw new ZipException("one of the input parameters were null in standard decrypt data");
      }
   }

   private void init(byte[] var1, char[] var2, long var3, long var5, boolean var7) throws ZipException {
      if (var2 != null && var2.length > 0) {
         this.zipCryptoEngine.initKeys(var2, var7);
         byte var8 = var1[0];

         for(int var9 = 0; var9 < 12; ++var9) {
            if (var9 + 1 == 12) {
               byte var10 = (byte)(var8 ^ this.zipCryptoEngine.decryptByte());
               if (var10 != (byte)((int)(var5 >> 24)) && var10 != (byte)((int)(var3 >> 8))) {
                  throw new ZipException("Wrong password!", ZipException.Type.WRONG_PASSWORD);
               }
            }

            this.zipCryptoEngine.updateKeys((byte)(var8 ^ this.zipCryptoEngine.decryptByte()));
            if (var9 + 1 != 12) {
               var8 = var1[var9 + 1];
            }
         }

      } else {
         throw new ZipException("Wrong password!", ZipException.Type.WRONG_PASSWORD);
      }
   }
}
