package net.lingala.zip4j.crypto.engine;

import net.lingala.zip4j.util.Zip4jUtil;

public class ZipCryptoEngine {
   private final int[] keys = new int[3];
   private static final int[] CRC_TABLE = new int[256];

   public void initKeys(char[] var1, boolean var2) {
      this.keys[0] = 305419896;
      this.keys[1] = 591751049;
      this.keys[2] = 878082192;
      byte[] var3 = Zip4jUtil.convertCharArrayToByteArray(var1, var2);

      for(byte var7 : var3) {
         this.updateKeys((byte)(var7 & 255));
      }

   }

   public void updateKeys(byte var1) {
      this.keys[0] = this.crc32(this.keys[0], var1);
      int[] var10000 = this.keys;
      var10000[1] += this.keys[0] & 255;
      this.keys[1] = this.keys[1] * 134775813 + 1;
      this.keys[2] = this.crc32(this.keys[2], (byte)(this.keys[1] >> 24));
   }

   private int crc32(int var1, byte var2) {
      return var1 >>> 8 ^ CRC_TABLE[(var1 ^ var2) & 255];
   }

   public byte decryptByte() {
      int var1 = this.keys[2] | 2;
      return (byte)(var1 * (var1 ^ 1) >>> 8);
   }

   static {
      for(int var0 = 0; var0 < 256; ++var0) {
         int var1 = var0;

         for(int var2 = 0; var2 < 8; ++var2) {
            if ((var1 & 1) == 1) {
               var1 = var1 >>> 1 ^ -306674912;
            } else {
               var1 >>>= 1;
            }
         }

         CRC_TABLE[var0] = var1;
      }

   }
}
