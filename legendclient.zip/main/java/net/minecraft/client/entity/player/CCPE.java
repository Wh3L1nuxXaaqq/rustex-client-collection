package net.minecraft.client.entity.player;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.world.World;

public class CCPE extends EntityPlayerSP {
   public CCPE(Minecraft var1, World var2, NetHandlerPlayClient var3, StatisticsManager var4, RecipeBook var5) {
      super(var1, var2, var3, var4, var5);
   }

   public boolean isSpectator() {
      return false;
   }
}
