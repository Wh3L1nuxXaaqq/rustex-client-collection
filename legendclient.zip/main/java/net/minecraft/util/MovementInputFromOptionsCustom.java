package net.minecraft.util;

import net.minecraft.client.settings.GameSettings;

public class MovementInputFromOptionsCustom extends MovementInputFromOptions {
   public MovementInputFromOptionsCustom(GameSettings var1) {
      super(var1);
   }

   public void updatePlayerMoveState() {
   }
}
