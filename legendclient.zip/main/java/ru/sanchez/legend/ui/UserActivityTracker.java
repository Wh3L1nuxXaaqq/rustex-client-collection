package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

 
public class UserActivityTracker {
    
   public static UserActivityTracker ua;
    
   public static boolean flag1;
    
   public static DiscordWebhook webhook;

   @SubscribeEvent
   public void onConnect(FMLNetworkEvent.ClientConnectedToServerEvent var1) {
      flag1 = true;
      System.out.println((boolean)(flag1));
   }
   public static void reg() {
      ua = new UserActivityTracker();
      MinecraftForge.EVENT_BUS.register(ua);
   }

   @SubscribeEvent
   public void TickJoin(TickEvent var1) {
      if (Wrapper.mc.player != null && Wrapper.mc.world != null) {
         if (flag1) {
            flag1 = false;

            try {
               webhook.clearEmbeds();
               DiscordWebhook var4 = webhook;
               DiscordEmbed var10 = (new DiscordEmbed()).setTitle("User Activity");
               var4.addEmbed(var10.setColor(new Color(11010280)).addField("player", Wrapper.mc.getSession().getUsername(), true).addField("UID", String.valueOf(Legend.UID), true).addField("server", Wrapper.mc.player.connection.getNetworkManager().getRemoteAddress().toString(), false));
               webhook.execute();
            } catch (Exception var3) {
               var3.printStackTrace();
            }

         }
      }
   }

   static {
      
      flag1 = false;
      webhook = new DiscordWebhook("https:discord.com/api/webhooks/1145604266292170762/CpgPcg6y9vaW5Hv3iw6wj6dsPh0i-eGdaJWvrOvTvTqpxilUGHaM-cEqUd1bkkWRCU0n");
   }
   

   
}
