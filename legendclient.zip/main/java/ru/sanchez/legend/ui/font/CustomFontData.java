package ru.sanchez.legend.ui.font;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

 
public class CustomFontData {
    
   public CharData[] charData = new CharData[256];
    
   public Font font;
    
   public boolean antiAlias;
    
   public boolean fractionalMetrics;
    
   public int fontHeight = -1;
    
   public int charOffset = 0;
    
   public DynamicTexture tex;
    
   public float imgSize = 512.0F;

   public CustomFontData(Font var1, boolean var2, boolean var3) {
      this.font = var1;
      this.antiAlias = (boolean)(var2);
      this.fractionalMetrics = (boolean)(var3);
      this.tex = this.setupTexture(var1, (boolean)var2, (boolean)var3, this.charData);
   }

   public DynamicTexture setupTexture(Font var1, boolean var2, boolean var3, CharData[] var4) {
      BufferedImage var5 = this.generateFontImage(var1, var2, var3, var4);

      try {
         return new DynamicTexture(var5);
      } catch (Exception var7) {
         var7.printStackTrace();
         return null;
      }
   }

   public BufferedImage generateFontImage(Font var1, boolean var2, boolean var3, CharData[] var4) {
      int var5 = (int)this.imgSize;
      BufferedImage var6 = new BufferedImage(var5, var5, 2);
      Graphics2D var7 = (Graphics2D)var6.getGraphics();
      var7.setFont(var1);
      var7.setColor(new Color(255, 255, 255, 0));
      var7.fillRect(0, 0, var5, var5);
      var7.setColor(Color.WHITE);
      var7.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, var3 ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
      var7.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, var2 ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
      var7.setRenderingHint(RenderingHints.KEY_ANTIALIASING, var2 ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
      FontMetrics var8 = var7.getFontMetrics();
      int var9 = 0;
      int var10 = 0;
      int var11 = 1;

      for(int var12 = 0; var12 < var4.length; ++var12) {
         char var13 = (char)var12;
         CharData var14 = new CharData(this);
         Rectangle2D var15 = var8.getStringBounds(String.valueOf(var13), var7);
         var14.width = var15.getBounds().width + 8;
         var14.height = var15.getBounds().height;
         if (var10 + var14.width >= var5) {
            var10 = 0;
            var11 += var9;
            var9 = 0;
         }

         if (var14.height > var9) {
            var9 = var14.height;
         }

         var14.storedX = var10;
         var14.storedY = var11;
         if (var14.height > this.fontHeight) {
            this.fontHeight = var14.height;
         }

         var4[var12] = var14;
         var7.drawString(String.valueOf(var13), var10 + 2, var11 + var8.getAscent());
         var10 += var14.width;
      }

      return var6;
   }

   public void drawChar(CharData[] var1, char var2, float var3, float var4) throws ArrayIndexOutOfBoundsException {
      try {
         this.drawQuad(var3, var4, (float)var1[var2].width, (float)var1[var2].height, (float)var1[var2].storedX, (float)var1[var2].storedY, (float)var1[var2].width, (float)var1[var2].height);
      } catch (Exception var6) {
         var6.printStackTrace();
      }

   }

   public void drawQuad(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = var5 / this.imgSize;
      float var10 = var6 / this.imgSize;
      float var11 = var7 / this.imgSize;
      float var12 = var8 / this.imgSize;
      GL11.glTexCoord2f(var9 + var11, var10);
      GL11.glVertex2d((double)(var1 + var3), (double)var2);
      GL11.glTexCoord2f(var9, var10);
      GL11.glVertex2d((double)var1, (double)var2);
      GL11.glTexCoord2f(var9, var10 + var12);
      GL11.glVertex2d((double)var1, (double)(var2 + var4));
      GL11.glTexCoord2f(var9, var10 + var12);
      GL11.glVertex2d((double)var1, (double)(var2 + var4));
      GL11.glTexCoord2f(var9 + var11, var10 + var12);
      GL11.glVertex2d((double)(var1 + var3), (double)(var2 + var4));
      GL11.glTexCoord2f(var9 + var11, var10);
      GL11.glVertex2d((double)(var1 + var3), (double)var2);
   }

   public int getStringHeight(String var1) {
      return this.getHeight();
   }

   public int getHeight() {
      int var10000 = this.fontHeight;
      return (var10000 - 8) / 2;
   }

   public int getStringWidth(String var1) {
      int var2 = 0;

      for(char var6 : var1.toCharArray()) {
         if (var6 < this.charData.length && var6 >= 0) {
            int var10001 = this.charData[var6].width;
            var2 += var10001 - 8 + this.charOffset;
         }
      }

      return var2 / 2;
   }

   public boolean isAntiAlias() {
      return (boolean)(this.antiAlias);
   }

   public void setAntiAlias(boolean var1) {
      if ((this.antiAlias) != var1) {
         this.antiAlias = (boolean)(var1);
         this.tex = this.setupTexture(this.font, (boolean)var1, (boolean)(this.fractionalMetrics), this.charData);
      }

   }

   public boolean isFractionalMetrics() {
      return (boolean)(this.fractionalMetrics);
   }

   public void setFractionalMetrics(boolean var1) {
      if ((this.fractionalMetrics) != var1) {
         this.fractionalMetrics = (boolean)(var1);
         this.tex = this.setupTexture(this.font, (boolean)(this.antiAlias), (boolean)var1, this.charData);
      }

   }

   public Font getFont() {
      return this.font;
   }

   public void setFont(Font var1) {
      this.font = var1;
      this.tex = this.setupTexture(var1, (boolean)(this.antiAlias), (boolean)(this.fractionalMetrics), this.charData);
   }
   

   

   
}
