package ru.sanchez.legend.ui.font;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.awt.Font;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

 
public final class CFontRenderer extends CustomFontData {
    
   public final int[] colorCode = new int[32];
    
   public CharData[] boldChars = new CharData[256];
    
   public CharData[] italicChars = new CharData[256];
    
   public CharData[] boldItalicChars = new CharData[256];
    
   public DynamicTexture texBold;
    
   public DynamicTexture texItalic;
    
   public DynamicTexture texItalicBold;

   public CFontRenderer(Font var1, boolean var2, boolean var3) {
      super(var1, var2, var3);
      this.setupMinecraftColorcodes();
      this.setupBoldItalicIDs();
   }

   public float drawString(String var1, float var2, float var3, int var4) {
      return this.drawString(var1, (double)var2, (double)var3, var4, false);
   }

   public float drawString(String var1, double var2, double var4, int var6) {
      return this.drawString(var1, var2, var4, var6, false);
   }

   public float drawStringWithShadow(String var1, float var2, float var3, int var4) {
      float var5 = this.drawString(var1, (double)var2 + (double)1.0F, (double)var3 + (double)1.0F, var4, true);
      return Math.max(var5, this.drawString(var1, (double)var2, (double)var3, var4, false));
   }

   public float drawStringWithShadow(String var1, double var2, double var4, int var6) {
      float var7 = this.drawString(var1, var2 + (double)0.5F, var4 + (double)0.5F, var6, true);
      return Math.max(var7, this.drawString(var1, var2, var4, var6, false));
   }

   public float drawCenteredString(String var1, float var2, float var3, int var4) {
      float var10003 = (float)this.getStringWidth(var1) / 2.0F;
      return this.drawString(var1, var2 - var10003, var3, var4);
   }

   public float drawCenteredString(String var1, double var2, double var4, int var6) {
      double var10003 = (double)((float)this.getStringWidth(var1) / 2.0F);
      return this.drawString(var1, var2 - var10003, var4, var6);
   }

   public float drawCenteredStringWithShadow(String var1, float var2, float var3, int var4) {
      float var10003 = (float)this.getStringWidth(var1) / 2.0F;
      this.drawString(var1, (double)(var2 - var10003) + 0.45, (double)var3 + (double)0.5F, var4, true);
      var10003 = (float)this.getStringWidth(var1) / 2.0F;
      return this.drawString(var1, var2 - var10003, var3, var4);
   }

   public void drawStringWithOutline(String var1, double var2, double var4, int var6) {
      this.drawString(var1, var2 - (double)0.5F, var4, 0);
      this.drawString(var1, var2 + (double)0.5F, var4, 0);
      this.drawString(var1, var2, var4 - (double)0.5F, 0);
      this.drawString(var1, var2, var4 + (double)0.5F, 0);
      this.drawString(var1, var2, var4, var6);
   }

   public void drawCenteredStringWithOutline(String var1, double var2, double var4, int var6) {
      this.drawCenteredString(var1, var2 - (double)0.5F, var4, 0);
      this.drawCenteredString(var1, var2 + (double)0.5F, var4, 0);
      this.drawCenteredString(var1, var2, var4 - (double)0.5F, 0);
      this.drawCenteredString(var1, var2, var4 + (double)0.5F, 0);
      this.drawCenteredString(var1, var2, var4, var6);
   }

   public float drawCenteredStringWithShadow(String var1, double var2, double var4, int var6) {
      double var10003 = (double)((float)this.getStringWidth(var1) / 2.0F);
      this.drawString(var1, var2 - var10003 + 0.45, var4 + (double)0.5F, var6, true);
      var10003 = (double)((float)this.getStringWidth(var1) / 2.0F);
      return this.drawString(var1, var2 - var10003, var4, var6);
   }

   public float drawString(String var1, double var2, double var4, int var6, boolean var7) {
      --var2;
      if (var1 == null) {
         return 0.0F;
      } else {
         if (var6 == 553648127) {
            var6 = 16777215;
         }

         if ((var6 & -67108864) == 0) {
            var6 |= -16777216;
         }

         if (var7) {
            int var23 = (var6 & 16579836) >> 2;
            var6 = var23 | var6 & (new Color(20, 20, 20, 200)).getRGB();
         }

         CharData[] var8 = this.charData;
         float var9 = (float)(var6 >> 24 & 255) / 255.0F;
         boolean var10 = false;
         boolean var11 = false;
         boolean var12 = false;
         boolean var13 = false;
         var2 *= (double)2.0F;
         var4 = (var4 - (double)3.0F) * (double)2.0F;
         GL11.glPushMatrix();
         GlStateManager.scale((double)0.5F, (double)0.5F, (double)0.5F);
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 771);
         GlStateManager.color((float)(var6 >> 16 & 255) / 255.0F, (float)(var6 >> 8 & 255) / 255.0F, (float)(var6 & 255) / 255.0F, var9);
         int var14 = var1.length();
         GlStateManager.enableTexture2D();
         GlStateManager.bindTexture(this.tex.getGlTextureId());
         GL11.glBindTexture(3553, this.tex.getGlTextureId());

         for(int var15 = 0; var15 < var14; ++var15) {
            char var16 = var1.charAt(var15);
            if ((String.valueOf(var16).equals("\ufffd")) != 0) {
               int var17 = 21;

               try {
                  var17 = "0123456789abcdefklmnor".indexOf(var1.charAt(var15 + 1));
               } catch (Exception var19) {
                  var19.printStackTrace();
               }

               if (var17 < 16) {
                  var10 = false;
                  var11 = false;
                  var13 = false;
                  var12 = false;
                  GlStateManager.bindTexture(this.tex.getGlTextureId());
                  var8 = this.charData;
                  if (var17 < 0) {
                     var17 = 15;
                  }

                  if (var7) {
                     var17 += 16;
                  }

                  int var18 = this.colorCode[var17];
                  GlStateManager.color((float)(var18 >> 16 & 255) / 255.0F, (float)(var18 >> 8 & 255) / 255.0F, (float)(var18 & 255) / 255.0F, var9);
               } else if (var17 == 17) {
                  var10 = true;
                  if (var11) {
                     GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                     var8 = this.boldItalicChars;
                  } else {
                     GlStateManager.bindTexture(this.texBold.getGlTextureId());
                     var8 = this.boldChars;
                  }
               } else if (var17 == 18) {
                  var12 = true;
               } else if (var17 == 19) {
                  var13 = true;
               } else if (var17 == 20) {
                  var11 = true;
                  if (var10) {
                     GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                     var8 = this.boldItalicChars;
                  } else {
                     GlStateManager.bindTexture(this.texItalic.getGlTextureId());
                     var8 = this.italicChars;
                  }
               } else if (var17 == 21) {
                  var10 = false;
                  var11 = false;
                  var13 = false;
                  var12 = false;
                  GlStateManager.color((float)(var6 >> 16 & 255) / 255.0F, (float)(var6 >> 8 & 255) / 255.0F, (float)(var6 & 255) / 255.0F, var9);
                  GlStateManager.bindTexture(this.tex.getGlTextureId());
                  var8 = this.charData;
               }

               ++var15;
            } else if (var16 < var8.length) {
               GL11.glBegin(4);
               this.drawChar(var8, var16, (float)var2, (float)var4);
               GL11.glEnd();
               if (var12) {
                  double var26 = var4 + (double)((float)var8[var16].height / 2.0F);
                  double var10003 = var2 + (double)var8[var16].width;
                  this.drawLine(var2, var26, var10003 - (double)8.0F, var4 + (double)((float)var8[var16].height / 2.0F), 1.0F);
               }

               if (var13) {
                  double var27 = var4 + (double)var8[var16].height;
                  var27 -= (double)2.0F;
                  double var29 = var2 + (double)var8[var16].width;
                  var29 -= (double)8.0F;
                  double var10004 = var4 + (double)var8[var16].height;
                  this.drawLine(var2, var27, var29, var10004 - (double)2.0F, 1.0F);
               }

               int var25 = var8[var16].width;
               var2 += (double)(var25 - 8 + this.charOffset);
            }
         }

         GL11.glPopMatrix();
         return (float)var2 / 2.0F;
      }
   }

   public int getStringWidth(String var1) {
      if (var1 == null) {
         return 0;
      } else {
         int var2 = 0;
         CharData[] var3 = this.charData;
         boolean var4 = false;
         boolean var5 = false;
         int var6 = var1.length();

         for(int var7 = 0; var7 < var6; ++var7) {
            char var8 = var1.charAt(var7);
            if ((String.valueOf(var8).equals("\ufffd")) != 0) {
               int var9 = "0123456789abcdefklmnor".indexOf(var8);
               if (var9 < 16) {
                  var4 = false;
                  var5 = false;
               } else if (var9 == 17) {
                  var4 = true;
                  if (var5) {
                     var3 = this.boldItalicChars;
                  } else {
                     var3 = this.boldChars;
                  }
               } else if (var9 == 20) {
                  var5 = true;
                  if (var4) {
                     var3 = this.boldItalicChars;
                  } else {
                     var3 = this.italicChars;
                  }
               } else if (var9 == 21) {
                  var4 = false;
                  var5 = false;
                  var3 = this.charData;
               }

               ++var7;
            } else if (var8 < var3.length) {
               int var10001 = var3[var8].width;
               var2 += var10001 - 8 + this.charOffset;
            }
         }

         return var2 / 2;
      }
   }

   public int getStringWidthCust(String var1) {
      if (var1 == null) {
         return 0;
      } else {
         int var2 = 0;
         CharData[] var3 = this.charData;
         boolean var4 = false;
         boolean var5 = false;
         int var6 = var1.length();

         for(int var7 = 0; var7 < var6; ++var7) {
            char var8 = var1.charAt(var7);
            if ((String.valueOf(var8).equals("\ufffd")) != 0 && var7 < var6) {
               int var9 = "0123456789abcdefklmnor".indexOf(var8);
               if (var9 < 16) {
                  var4 = false;
                  var5 = false;
               } else if (var9 == 17) {
                  var4 = true;
                  if (var5) {
                     var3 = this.boldItalicChars;
                  } else {
                     var3 = this.boldChars;
                  }
               } else if (var9 == 20) {
                  var5 = true;
                  if (var4) {
                     var3 = this.boldItalicChars;
                  } else {
                     var3 = this.italicChars;
                  }
               } else if (var9 == 21) {
                  var4 = false;
                  var5 = false;
                  var3 = this.charData;
               }

               ++var7;
            } else if (var8 < var3.length && var8 >= 0) {
               int var10001 = var3[var8].width;
               var2 += var10001 - 8 + this.charOffset;
            }
         }

         int var10 = this.charOffset;
         return (var2 - var10) / 2;
      }
   }

   public void drawTotalCenteredString(String var1, double var2, double var4, int var6) {
      double var10003 = (double)(this.getStringWidth(var1) / 2);
      double var10002 = var2 - var10003;
      double var10004 = (double)(this.getHeight() / 2);
      this.drawString(var1, var10002, var4 - var10004, var6);
   }

   public void drawTotalCenteredStringWithShadow(String var1, double var2, double var4, int var6) {
      double var10003 = (double)(this.getStringWidth(var1) / 2);
      double var10002 = var2 - var10003;
      double var10004 = (double)((float)this.getHeight() / 2.0F);
      this.drawStringWithShadow(var1, var10002, var4 - var10004, var6);
   }

   public void setFont(Font var1) {
      super.setFont(var1);
      this.setupBoldItalicIDs();
   }

   public void setAntiAlias(boolean var1) {
      super.setAntiAlias(var1);
      this.setupBoldItalicIDs();
   }

   public void setFractionalMetrics(boolean var1) {
      super.setFractionalMetrics(var1);
      this.setupBoldItalicIDs();
   }

   public void setupBoldItalicIDs() {
      this.texBold = this.setupTexture(this.font.deriveFont(1), (boolean)(this.antiAlias), (boolean)(this.fractionalMetrics), this.boldChars);
      this.texItalic = this.setupTexture(this.font.deriveFont(2), (boolean)(this.antiAlias), (boolean)(this.fractionalMetrics), this.italicChars);
      this.texItalicBold = this.setupTexture(this.font.deriveFont(3), (boolean)(this.antiAlias), (boolean)(this.fractionalMetrics), this.boldItalicChars);
   }

   public void drawLine(double var1, double var3, double var5, double var7, float var9) {
      GL11.glDisable(3553);
      GL11.glLineWidth(var9);
      GL11.glBegin(1);
      GL11.glVertex2d(var1, var3);
      GL11.glVertex2d(var5, var7);
      GL11.glEnd();
      GL11.glEnable(3553);
   }

   public void setupMinecraftColorcodes() {
      for(int var1 = 0; var1 < 32; ++var1) {
         int var2 = (var1 >> 3 & 1) * 85;
         int var3 = (var1 >> 2 & 1) * 170 + var2;
         int var4 = (var1 >> 1 & 1) * 170 + var2;
         int var5 = (var1 & 1) * 170 + var2;
         if (var1 == 6) {
            var3 += 85;
         }

         if (var1 >= 16) {
            var3 /= 4;
            var4 /= 4;
            var5 /= 4;
         }

         this.colorCode[var1] = (var3 & 255) << 16 | (var4 & 255) << 8 | var5 & 255;
      }

   }
   

   

   
}
