package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Font;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

 
public final class FontStorage {
    
   public static CFontRenderer fr;
    
   public static CFontRenderer fr1;
    
   public static CFontRenderer fr3;
    
   public static CFontRenderer fr4;
   public static Font getFontFromTTF(ResourceLocation var0, float var1, int var2) {
      try {
         Font var3 = Font.createFont(var2, Minecraft.getMinecraft().getResourceManager().getResource(var0).getInputStream());
         var3 = var3.deriveFont(var1);
         return var3;
      } catch (Exception var4) {
         return null;
      }
   }

   static {
      
      fr1 = new CFontRenderer(getFontFromTTF(new ResourceLocation("font/ab;|\u5823\u3331\u3d9f\u0dda\u32e0"), 28.0F, 0), true, true);
      fr = new CFontRenderer(getFontFromTTF(new ResourceLocation("main2.t x"), 20.0F, 0), true, true);
      fr3 = new CFontRenderer(getFontFromTTF(new ResourceLocation("rerty.t x"), 20.0F, 0), true, true);
      fr4 = new CFontRenderer(getFontFromTTF(new ResourceLocation("latoreg!r\u5823\u336d\u3dc5\u0dda\u32f2\u3be8"), 20.0F, 0), true, true);
   }
   
}
