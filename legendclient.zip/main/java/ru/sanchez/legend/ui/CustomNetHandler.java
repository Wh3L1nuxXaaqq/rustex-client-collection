package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.util.text.ITextComponent;

 
public class CustomNetHandler extends NetHandlerPlayClient {

   public CustomNetHandler(Minecraft var1, GuiScreen var2, NetworkManager var3, GameProfile var4) {
      super(var1, var2, var3, var4);
   }

   public void sendPacket(Packet<?> var1) {
      NotificationManager.add("rotation", "work", NotificationType.OK);
      super.sendPacket(var1);
   }

   public void onDisconnect(ITextComponent var1) {
      super.onDisconnect(var1);
   }
   

   
}
