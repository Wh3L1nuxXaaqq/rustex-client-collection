package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class AutoReconnectHandler {
    
   public static AutoReconnectHandler cl;

   @SubscribeEvent
   public void TickJoin(TickEvent var1) {
      if (Wrapper.mc.player != null && Wrapper.mc.world != null) {
         Legend.configManager.loadCFG("auto");
         MinecraftForge.EVENT_BUS.unregister(cl);
      }
   }
   public static void reg() {
      cl = new AutoReconnectHandler();
      MinecraftForge.EVENT_BUS.register(cl);
   }
   

   
}
