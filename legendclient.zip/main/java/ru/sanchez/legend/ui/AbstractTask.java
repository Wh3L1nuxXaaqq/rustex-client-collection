package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public abstract class AbstractTask implements ITask {
    
   public String name;
    
   public int priority;
    
   public boolean online;

   public AbstractTask(String var1, int var2) {
      this.name = var1;
      this.priority = var2;
   }

   public boolean isOnline() {
      return (boolean)(this.online);
   }

   public void setOnline(boolean var1) {
      this.online = (boolean)(var1);
   }

   public String getName() {
      return this.name;
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public int getPriority() {
      return this.priority;
   }

   public void setPriority(int var1) {
      this.priority = var1;
   }
   

   

   
}
