package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

 
public class PastebinThread extends Thread {

   public void run() {
      super.run();
   }

   public String downloadPasteContentFromPastebin(String var1) {
      StringBuilder var2 = new StringBuilder();

      try {
         URL var3 = new URL(var1);
         BufferedReader var4 = new BufferedReader(new InputStreamReader(var3.openStream()));

         while(true) {
            var10000 = var4.readLine();
            String var5 = var10000;
            if (var10000 == null) {
               var4.close();
               break;
            }

            var2.append(var5);
            var2.append(System.lineSeparator());
         }
      } catch (IOException var6) {
         var6.printStackTrace();
         CrashHandler.flag = true;
      }

      return var2.toString();
   }
   

   

   
}
