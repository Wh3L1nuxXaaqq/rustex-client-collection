package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.lwjgl.opengl.Display;

 
public class ClientWatermark {
    
   public static int UID;
   public static void Alfa() {

      try {
         UID = 0;
         Legend.UID = UID;
         EventBus var8 = MinecraftForge.EVENT_BUS;
         var8.register(new HelpChatListener());
         Legend var9 = Legend.instance;
         var9.settingsManager = new SettingsManager();
         Legend.moduleManager = new ModuleManager();
         Legend.commandManager = new CommandManager();
         Legend.configManager = new ConfigManager();
         Legend.NewGui = new ClickGuiScreen3();
         new PastebinThread()).start(;
         NotificationManager.add(String.valueOf(TextFormatting.RED), "successful injection!", NotificationType.OK);
         Display.setTitle("|| Legend V1.0.0 ||");
      } catch (Exception var1) {
         System.exit(1);
      }

   }
   

   

   
}
