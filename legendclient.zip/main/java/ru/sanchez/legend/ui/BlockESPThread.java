package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.init.Blocks;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

 
public class BlockESPThread extends Thread {

   public void run() {

      try {
         while(true) {
            String var1 = Legend.instance.settingsManager.getSettingByName(Legend.moduleManager.getModule("BlockESP"), "Mode").getValString();
            ArrayList var2 = new ArrayList();
            new ArrayList();
            Minecraft var4 = Minecraft.getMinecraft();
            int var6 = var4.gameSettings.renderDistanceChunks << 4;
            int var49 = var4.player.getPosition().getX();
            int var7 = var49 - var6;
            int var8 = var4.player.getPosition().getX() + var6;
            int var84 = var4.player.getPosition().getY();
            int var9 = Math.max(60, var84 - 92);
            int var10 = Math.min(130, var4.player.getPosition().getY() + 72);
            var49 = var4.player.getPosition().getZ();
            int var11 = var49 - var6;
            int var12 = var4.player.getPosition().getZ() + var6;
            ArrayList var13 = new ArrayList<Block>(this) {
                
               public final BlockESPThread this$0;

               public {
                  this.this$0 = var1;
                  this.add(Blocks.AIR);
                  this.add(Blocks.BEDROCK);
                  this.add(Blocks.STONE);
                  this.add(Blocks.GRASS);
                  this.add(Blocks.DIRT);
               }
               

               

               
            };

            for(int var14 = var7 >> 4; var14 <= var8 >> 4; ++var14) {
               int var15 = var14 << 4;
               if (var15 < var7) {
                  var49 = var7 - var15;
               } else {
                  var49 = 0;
               }

               int var16 = var49;
               if (var15 + 15 > var8) {
                  var49 = var8 - var15;
               } else {
                  var49 = 15;
               }

               int var17 = var49;

               for(int var18 = var11 >> 4; var18 <= var12 >> 4; ++var18) {
                  Chunk var19 = var4.world.getChunk(var14, var18);
                  if ((var19.isLoaded()) != 0) {
                     ExtendedBlockStorage[] var20 = var19.getBlockStorageArray();
                     int var21 = var18 << 4;
                     if (var21 < var11) {
                        var49 = var11 - var21;
                     } else {
                        var49 = 0;
                     }

                     int var22 = var49;
                     if (var21 + 15 > var12) {
                        var49 = var12 - var21;
                     } else {
                        var49 = 15;
                     }

                     int var23 = var49;

                     for(int var24 = var9 >> 4; var24 <= var10 >> 4; ++var24) {
                        ExtendedBlockStorage var25 = var20[var24];
                        if (var25 != null) {
                           int var26 = var24 << 4;
                           if (var26 < var9) {
                              var49 = var9 - var26;
                           } else {
                              var49 = 0;
                           }

                           int var27 = var49;
                           if (var26 + 15 > var10) {
                              var49 = var10 - var26;
                           } else {
                              var49 = 15;
                           }

                           int var28 = var49;

                           for(int var29 = var16; var29 <= var17; ++var29) {
                              for(int var30 = var27; var30 <= var28; ++var30) {
                                 for(int var31 = var22; var31 <= var23; ++var31) {
                                    IBlockState var32 = var25.get(var29, var30, var31);
                                    if ((var13.contains(var32.getBlock())) == 0) {
                                       if ((var1.equalsIgnoreCase("ore")) != 0) {
                                          if ((var32.getBlock().equals(Blocks.IRON_ORE)) != 0) {
                                             var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 0.0F, 0.5F, 1.0F));
                                          } else if ((var32.getBlock().equals(Blocks.DIAMOND_ORE)) != 0) {
                                             var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.0F, 0.0F));
                                          } else if ((var32.getBlock().equals(Blocks.GOLD_ORE)) != 0) {
                                             var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.9F, 0.0F));
                                          }
                                       } else if ((var1.equalsIgnoreCase("Door")) != 0) {
                                          if ((this.isDoorOrGateOpen(var32)) != 0) {
                                             var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.0F, 0.0F));
                                          }
                                       } else if ((var1.equalsIgnoreCase("cloth")) != 0) {
                                          try {
                                             if ((var32.equals(CommandBase.convertArgToBlockState(Blocks.TALLGRASS, "2"))) != 0) {
                                                var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.4F, 0.0F));
                                             }
                                          } catch (Exception var35) {
                                             ChatUtils.sendMessage("Error");
                                             Legend.moduleManager.getModule("BlockESP").setToggled(false);
                                          }
                                       } else if ((var1.equalsIgnoreCase("barrier")) != 0) {
                                          if ((var32.getBlock().equals(Blocks.BARRIER)) != 0) {
                                             var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.0F, 0.0F));
                                          }
                                       } else {
                                          Iterator var33 = Blockesp.search_blocks.iterator();

                                          while((var33.hasNext()) != 0) {
                                             IBlockState var34 = (IBlockState)var33.next();
                                             if ((var32.equals(var34)) != 0) {
                                                var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.0F, 0.0F));
                                             }
                                          }

                                          var33 = Blockesp.search_blocks1.iterator();

                                          while((var33.hasNext()) != 0) {
                                             Block var38 = (Block)var33.next();
                                             if ((var32.getBlock().equals(var38)) != 0) {
                                                var2.add(new ESPBlockColor(var15 + var29, var26 + var30, var21 + var31, 1.0F, 0.0F, 0.0F));
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }

            Blockesp.render.clear();
            Blockesp.render = var2;
            Thread.sleep((long)(Legend.instance.settingsManager.getSettingByName(Legend.moduleManager.getModule("BlockESP"), "UpdateTime").getValDouble() * (double)1000.0F));
         }
      } catch (InterruptedException var36) {
         RuntimeException var48 = new RuntimeException(var36);
         throw var48;
      }
   }

   public boolean isDoorOrGateOpen(IBlockState var1) {
      if (var1.getBlock() instanceof BlockDoor) {
         return (boolean)((Boolean)var1.getValue(BlockDoor.OPEN));
      } else {
         return (boolean)(var1.getBlock() instanceof BlockFenceGate ? ((Boolean)var1.getValue(BlockFenceGate.OPEN)) : 0);
      }
   }
   

   

   
}
