package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.lang.reflect.Field;

 
public class ReflectionUtils {
   public static Object getValueReflection(Object var0, Class var1) throws IllegalArgumentException, IllegalAccessException {
      Field[] var8 = var0.getClass().getDeclaredFields();
      Field[] var2 = var8;

      for(Field var7 : var2) {
         if ((var1.isAssignableFrom(var7.getType())) != 0) {
            var7.setAccessible(true);
            return var7.get(var0);
         }
      }

      return null;
   }
   public static boolean setValueToFinal(Object var0, Class var1, Object var2) {
      for(Field var6 : var0.getClass().getDeclaredFields()) {
         if (var6.getType() == var1) {
            var6.setAccessible(true);

            try {
               var6.set(var0, var2);
               return true;
            } catch (IllegalAccessException var8) {
               var8.printStackTrace();
            }
         }
      }

      return false;
   }
   

   

   
}
