package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

 
public class HttpsClient {
   public static int UID(String var0, String var1) {
      int var2 = 0;
      int var3 = 0;
      ArrayList var4 = new ArrayList();
      String var5 = "";

      try {
         SSLContext var6 = SSLContext.getInstance("SSL");
         TrustManager[] var19 = new TrustManager[1];
         var19[0] = new X509TrustManager() {

            public X509Certificate[] getAcceptedIssuers() {
               return null;
            }

            public void checkClientTrusted(X509Certificate[] var1, String var2) {
            }

            public void checkServerTrusted(X509Certificate[] var1, String var2) {
            }
            

            
         };
         TrustManager[] var7 = var19;
         var6.init((KeyManager[])null, var7, new SecureRandom());
         URL var9 = new URL(var0);
         HttpsURLConnection var10 = (HttpsURLConnection)var9.openConnection();
         var10.setSSLSocketFactory(var6.getSocketFactory());
         BufferedReader var11 = new BufferedReader(new InputStreamReader(var10.getInputStream()));

         while(true) {
            String var20 = var11.readLine();
            String var8 = var20;
            if (var20 == null) {
               break;
            }

            var4.add(var8);
         }
      } catch (Exception var12) {
      }

      Iterator var14 = var4.iterator();

      while((var14.hasNext()) != 0) {
         Object var15 = var14.next();
         var5 = String.valueOf(var15);
         if ((var5.contains(var1)) != 0) {
            var2 = var3 + 1;
         } else {
            ++var3;
         }
      }

      return var2;
   }

   static {
      
      agent1 = "User-Agent";
      agent2 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36";
   }
   

   
}
