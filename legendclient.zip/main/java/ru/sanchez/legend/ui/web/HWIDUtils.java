package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

 
public class HWIDUtils {
    
   public static final String ABOBA = "https:dengerbot.sanchez23611.repl.co";
   public static String getHWID() {
      String var0 = System.getProperty("os.name");
      String var1 = System.getProperty("user.name");
      String var2 = String.valueOf(Runtime.getRuntime().availableProcessors());
      String var3 = System.getProperty("os.arch");
      String var4 = System.getenv("COMPUTERNAME");
      String var5 = runCommand("wmic baseboard get serialNumber");
      String var7 = var0 + var1 + var2 + var3 + var4 + var5 + var6;
      return get_SHA_512_SecurePassword(var7);
   }
   public static String get_SHA_512_SecurePassword(String var0) {
      Object var1 = null;

      try {
         MessageDigest var2 = MessageDigest.getInstance("SHA-512");
         byte[] var3 = var2.digest(var0.getBytes(StandardCharsets.UTF_8));
         StringBuilder var4 = new StringBuilder();

         for(int var5 = 0; var5 < var3.length; ++var5) {
            var4.append(Integer.toString((var3[var5] & 255) + 256, 16).substring(1));
         }

         String var7 = var4.toString();
         return var7;
      } catch (NoSuchAlgorithmException var6) {
         var6.printStackTrace();
         return "Error";
      }
   }
   public static String runCommand(String var0) {

      try {
         StringBuilder var1 = new StringBuilder();
         Process var2 = Runtime.getRuntime().exec(var0);
         BufferedReader var3 = new BufferedReader(new InputStreamReader(var2.getInputStream()));

         while(true) {
            var10000 = var3.readLine();
            String var4 = var10000;
            if (var10000 == null) {
               var3.close();
               if ((var1.toString().equalsIgnoreCase(" ")) == 0 && (var1.toString().isEmpty()) == 0) {
                  return var1.toString();
               } else {
                  IOException var9 = new IOException();
                  throw var9;
               }
            }

            var1.append(var4);
         }
      } catch (Exception var5) {
         var5.printStackTrace();
         return "Error";
      }
   }
   

   

   
}
