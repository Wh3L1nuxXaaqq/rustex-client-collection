package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

 
public class BlockCollisionUtils {
   public static boolean isCollidable(Block var0) {
      return var0 != Blocks.AIR && var0 != Blocks.BEETROOTS && var0 != Blocks.CARROTS && var0 != Blocks.DEADBUSH && var0 != Blocks.DOUBLE_PLANT && var0 != Blocks.FLOWING_LAVA && var0 != Blocks.FLOWING_WATER && var0 != Blocks.LAVA && var0 != Blocks.MELON_STEM && var0 != Blocks.NETHER_WART && var0 != Blocks.POTATOES && var0 != Blocks.PUMPKIN_STEM && var0 != Blocks.RED_FLOWER && var0 != Blocks.RED_MUSHROOM && var0 != Blocks.REDSTONE_TORCH && var0 != Blocks.TALLGRASS && var0 != Blocks.TORCH && var0 != Blocks.UNLIT_REDSTONE_TORCH && var0 != Blocks.YELLOW_FLOWER && var0 != Blocks.VINE && var0 != Blocks.WATER && var0 != Blocks.WEB && var0 != Blocks.WHEAT;
   }
   

   
}
