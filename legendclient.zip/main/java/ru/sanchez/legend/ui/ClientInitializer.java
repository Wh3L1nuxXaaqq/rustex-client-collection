package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;

 
@Mod(
   modid = "legend",
   version = "V1.0.0",
   name = "Legend"
)
public class ClientInitializer {

   @EventHandler
   public void init(FMLInitializationEvent var1) throws Exception {
      Legend.instance = new Legend();
      Legend.instance.init();
   }

   @EventHandler
   public void postinit(FMLPostInitializationEvent var1) throws Exception {
      Legend.configManager.LoadFriends();
      AutoReconnectHandler.reg();
      UserActivityTracker.reg();
      CrashHandler.reg();
   }
   

   
}
