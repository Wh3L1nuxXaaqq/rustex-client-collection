package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class CrashHandler {
    
   public static boolean flag;
    
   public static CrashHandler crash;

   @SubscribeEvent
   public void TickJoin(TickEvent var1) {
      if (flag) {
         System.exit(0);
      }

   }
   public static void reg() {
      crash = new CrashHandler();
      MinecraftForge.EVENT_BUS.register(crash);
   }

   static {
      
      flag = false;
   }
   

   
}
