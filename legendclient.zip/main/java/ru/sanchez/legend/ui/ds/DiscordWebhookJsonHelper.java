package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

 
public class DiscordWebhookJsonHelper {
    
   public final HashMap<String, Object> map;
    
   public final DiscordWebhook this$0;

   public DiscordWebhookJsonHelper(DiscordWebhook var1) {
      this.this$0 = var1;
      this.map = new HashMap();
   }

   public void put(String var1, Object var2) {
      if (var2 != null) {
         this.map.put(var1, var2);
      }

   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      Set var2 = this.map.entrySet();
      var1.append("{");
      int var3 = 0;
      Iterator var4 = var2.iterator();

      while((var4.hasNext()) != 0) {
         Map.Entry var5 = (Map.Entry)var4.next();
         Object var6 = var5.getValue();
         var1.append(this.quote((String)var5.getKey())).append(":");
         if (var6 instanceof String) {
            var1.append(this.quote(String.valueOf(var6)));
         } else if (var6 instanceof Integer) {
            var1.append(Integer.valueOf(String.valueOf(var6)));
         } else if (var6 instanceof Boolean) {
            var1.append(var6);
         } else if (var6 instanceof DiscordWebhookJsonHelper) {
            var1.append(var6.toString());
         } else if ((var6.getClass().isArray()) != 0) {
            var1.append("[");
            int var7 = Array.getLength(var6);

            for(int var8 = 0; var8 < var7; ++var8) {
               StringBuilder var9 = var1.append(Array.get(var6, var8).toString());
               var9.append(var8 != var7 - 1 ? "," : "");
            }

            var1.append("]");
         }

         ++var3;
         var1.append(var3 == var2.size() ? "}" : ",");
      }

      return var1.toString();
   }

   public String quote(String var1) {
      return "\"" + var1 + "\"";
   }
   

   

   
}
