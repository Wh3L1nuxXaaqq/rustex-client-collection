package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

 
public class JSONParser {
    
   public static final int S_INIT = 0;
    
   public static final int S_IN_FINISHED_VALUE = 1;
    
   public static final int S_IN_OBJECT = 2;
    
   public static final int S_IN_ARRAY = 3;
    
   public static final int S_PASSED_PAIR_KEY = 4;
    
   public static final int S_IN_PAIR_VALUE = 5;
    
   public static final int S_END = 6;
    
   public static final int S_IN_ERROR = -1;
    
   public LinkedList handlerStatusStack;
    
   public JsonLexer lexer = new JsonLexer((Reader)null);
    
   public JsonToken token = null;
    
   public int status = 0;

   public int peekStatus(LinkedList var1) {
      if (var1.size() == 0) {
         return -1;
      } else {
         Integer var2 = (Integer)var1.getFirst();
         return var2;
      }
   }

   public void reset() {
      this.token = null;
      this.status = 0;
      this.handlerStatusStack = null;
   }

   public void reset(Reader var1) {
      this.lexer.yyreset(var1);
      this.reset();
   }

   public int getPosition() {
      return this.lexer.getPosition();
   }

   public Object parse(String var1) throws JsonParseException {
      return this.parse(var1, (JSONContainerFactory)null);
   }

   public Object parse(String var1, JSONContainerFactory var2) throws JsonParseException {
      StringReader var3 = new StringReader(var1);

      try {
         return this.parse((Reader)var3, (JSONContainerFactory)var2);
      } catch (IOException var5) {
         JsonParseException var6 = new JsonParseException(-1, 2, var5);
         throw var6;
      }
   }

   public Object parse(Reader var1) throws IOException, JsonParseException {
      return this.parse(var1, (JSONContainerFactory)null);
   }

   public Object parse(Reader var1, JSONContainerFactory var2) throws IOException, JsonParseException {
      this.reset(var1);
      LinkedList var3 = new LinkedList();
      LinkedList var4 = new LinkedList();

      try {
         do {
            this.nextToken();
            label65:
            switch (this.status) {
               case -1:
                  JsonParseException var31 = new JsonParseException(this.getPosition(), 1, this.token);
                  throw var31;
               case 0:
                  switch (this.token.type) {
                     case 0:
                        this.status = 1;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(this.token.value);
                        break label65;
                     case 1:
                        this.status = 2;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(this.createObjectContainer(var2));
                        break label65;
                     case 2:
                     default:
                        this.status = -1;
                        break label65;
                     case 3:
                        this.status = 3;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(this.createArrayContainer(var2));
                        break label65;
                  }
               case 1:
                  if (this.token.type == -1) {
                     return var4.removeFirst();
                  }
                  JsonParseException var30 = new JsonParseException(this.getPosition(), 1, this.token);
                  throw var30;
               case 2:
                  switch (this.token.type) {
                     case 0:
                        if (this.token.value instanceof String) {
                           String var15 = (String)this.token.value;
                           var4.addFirst(var15);
                           this.status = 4;
                           var3.addFirst(new Integer(this.status));
                        } else {
                           this.status = -1;
                        }
                        break label65;
                     case 2:
                        if (var4.size() > 1) {
                           var3.removeFirst();
                           var4.removeFirst();
                           this.status = this.peekStatus(var3);
                        } else {
                           this.status = 1;
                        }
                     case 5:
                        break label65;
                     default:
                        this.status = -1;
                        break label65;
                  }
               case 3:
                  switch (this.token.type) {
                     case 0:
                        List var14 = (List)var4.getFirst();
                        var14.add(this.token.value);
                        break label65;
                     case 1:
                        List var13 = (List)var4.getFirst();
                        Map var18 = this.createObjectContainer(var2);
                        var13.add(var18);
                        this.status = 2;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(var18);
                        break label65;
                     case 2:
                     default:
                        this.status = -1;
                        break label65;
                     case 3:
                        List var12 = (List)var4.getFirst();
                        List var19 = this.createArrayContainer(var2);
                        var12.add(var19);
                        this.status = 3;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(var19);
                        break label65;
                     case 4:
                        if (var4.size() > 1) {
                           var3.removeFirst();
                           var4.removeFirst();
                           this.status = this.peekStatus(var3);
                        } else {
                           this.status = 1;
                        }
                     case 5:
                        break label65;
                  }
               case 4:
                  switch (this.token.type) {
                     case 0:
                        var3.removeFirst();
                        String var11 = (String)var4.removeFirst();
                        Map var17 = (Map)var4.getFirst();
                        var17.put(var11, this.token.value);
                        this.status = this.peekStatus(var3);
                        break;
                     case 1:
                        var3.removeFirst();
                        String var10 = (String)var4.removeFirst();
                        Map var16 = (Map)var4.getFirst();
                        Map var8 = this.createObjectContainer(var2);
                        var16.put(var10, var8);
                        this.status = 2;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(var8);
                        break;
                     case 2:
                     case 4:
                     case 5:
                     default:
                        this.status = -1;
                        break;
                     case 3:
                        var3.removeFirst();
                        String var5 = (String)var4.removeFirst();
                        Map var6 = (Map)var4.getFirst();
                        List var7 = this.createArrayContainer(var2);
                        var6.put(var5, var7);
                        this.status = 3;
                        var3.addFirst(new Integer(this.status));
                        var4.addFirst(var7);
                     case 6:
                  }
            }

            if (this.status == -1) {
               JsonParseException var33 = new JsonParseException(this.getPosition(), 1, this.token);
               throw var33;
            }
         } while(this.token.type != -1);
      } catch (IOException var9) {
         throw var9;
      }
      JsonParseException var32 = new JsonParseException(this.getPosition(), 1, this.token);
      throw var32;
   }

   public void nextToken() throws JsonParseException, IOException {
      this.token = this.lexer.yylex();
      if (this.token == null) {
         this.token = new JsonToken(-1, (Object)null);
      }

   }

   public Map createObjectContainer(JSONContainerFactory var1) {
      if (var1 == null) {
         return new JSONObject();
      } else {
         Map var2 = var1.createObjectContainer();
         if (var2 == null) {
            return new JSONObject();
         } else {
            return var2;
         }
      }
   }

   public List createArrayContainer(JSONContainerFactory var1) {
      if (var1 == null) {
         return new JSONArray();
      } else {
         List var2 = var1.creatArrayContainer();
         if (var2 == null) {
            return new JSONArray();
         } else {
            return var2;
         }
      }
   }

   public void parse(String var1, JSONContentHandler var2) throws JsonParseException {
      this.parse(var1, var2, false);
   }

   public void parse(String var1, JSONContentHandler var2, boolean var3) throws JsonParseException {
      StringReader var4 = new StringReader(var1);

      try {
         this.parse((Reader)var4, var2, var3);
      } catch (IOException var6) {
         JsonParseException var7 = new JsonParseException(-1, 2, var6);
         throw var7;
      }
   }

   public void parse(Reader var1, JSONContentHandler var2) throws IOException, JsonParseException {
      this.parse(var1, var2, false);
   }

   public void parse(Reader var1, JSONContentHandler var2, boolean var3) throws IOException, JsonParseException {
      if (!var3) {
         this.reset(var1);
         this.handlerStatusStack = new LinkedList();
      } else if (this.handlerStatusStack == null) {
         var3 = false;
         this.reset(var1);
         this.handlerStatusStack = new LinkedList();
      }

      LinkedList var4 = this.handlerStatusStack;

      try {
         do {
            label175:
            switch (this.status) {
               case -1:
                  JsonParseException var24 = new JsonParseException(this.getPosition(), 1, this.token);
                  throw var24;
               case 0:
                  var2.startJSON();
                  this.nextToken();
                  switch (this.token.type) {
                     case 0:
                        this.status = 1;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.primitive(this.token.value)) == 0) {
                           return;
                        }
                        break label175;
                     case 1:
                        this.status = 2;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startObject()) == 0) {
                           return;
                        }
                        break label175;
                     case 2:
                     default:
                        this.status = -1;
                        break label175;
                     case 3:
                        this.status = 3;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startArray()) == 0) {
                           return;
                        }
                        break label175;
                  }
               case 1:
                  this.nextToken();
                  if (this.token.type == -1) {
                     var2.endJSON();
                     this.status = 6;
                     return;
                  }

                  this.status = -1;
                  JsonParseException var23 = new JsonParseException(this.getPosition(), 1, this.token);
                  throw var23;
               case 2:
                  this.nextToken();
                  switch (this.token.type) {
                     case 0:
                        if (this.token.value instanceof String) {
                           String var5 = (String)this.token.value;
                           this.status = 4;
                           var4.addFirst(new Integer(this.status));
                           if ((var2.startObjectEntry(var5)) == 0) {
                              return;
                           }
                        } else {
                           this.status = -1;
                        }
                        break label175;
                     case 2:
                        if (var4.size() > 1) {
                           var4.removeFirst();
                           this.status = this.peekStatus(var4);
                        } else {
                           this.status = 1;
                        }

                        if ((var2.endObject()) == 0) {
                           return;
                        }
                     case 5:
                        break label175;
                     default:
                        this.status = -1;
                        break label175;
                  }
               case 3:
                  this.nextToken();
                  switch (this.token.type) {
                     case 0:
                        if ((var2.primitive(this.token.value)) == 0) {
                           return;
                        }
                        break label175;
                     case 1:
                        this.status = 2;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startObject()) == 0) {
                           return;
                        }
                        break label175;
                     case 2:
                     default:
                        this.status = -1;
                        break label175;
                     case 3:
                        this.status = 3;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startArray()) == 0) {
                           return;
                        }
                        break label175;
                     case 4:
                        if (var4.size() > 1) {
                           var4.removeFirst();
                           this.status = this.peekStatus(var4);
                        } else {
                           this.status = 1;
                        }

                        if ((var2.endArray()) == 0) {
                           return;
                        }
                     case 5:
                        break label175;
                  }
               case 4:
                  this.nextToken();
                  switch (this.token.type) {
                     case 0:
                        var4.removeFirst();
                        this.status = this.peekStatus(var4);
                        if ((var2.primitive(this.token.value)) == 0) {
                           return;
                        }

                        if ((var2.endObjectEntry()) == 0) {
                           return;
                        }
                        break label175;
                     case 1:
                        var4.removeFirst();
                        var4.addFirst(new Integer(5));
                        this.status = 2;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startObject()) == 0) {
                           return;
                        }
                        break label175;
                     case 2:
                     case 4:
                     case 5:
                     default:
                        this.status = -1;
                        break label175;
                     case 3:
                        var4.removeFirst();
                        var4.addFirst(new Integer(5));
                        this.status = 3;
                        var4.addFirst(new Integer(this.status));
                        if ((var2.startArray()) == 0) {
                           return;
                        }
                     case 6:
                        break label175;
                  }
               case 5:
                  var4.removeFirst();
                  this.status = this.peekStatus(var4);
                  if ((var2.endObjectEntry()) == 0) {
                     return;
                  }
                  break;
               case 6:
                  return;
            }

            if (this.status == -1) {
               JsonParseException var26 = new JsonParseException(this.getPosition(), 1, this.token);
               throw var26;
            }
         } while(this.token.type != -1);
      } catch (IOException var6) {
         this.status = -1;
         throw var6;
      } catch (JsonParseException var7) {
         this.status = -1;
         throw var7;
      } catch (RuntimeException var8) {
         this.status = -1;
         throw var8;
      } catch (Error var9) {
         this.status = -1;
         throw var9;
      }

      this.status = -1;
      JsonParseException var25 = new JsonParseException(this.getPosition(), 1, this.token);
      throw var25;
   }
   

   

   
}
