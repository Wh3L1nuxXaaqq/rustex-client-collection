package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

 
public class JSONObject extends HashMap implements Map, JSONAware, JSONStreamAware {
    
   public static final long serialVersionUID = -503443796854799292L;

   public JSONObject() {
   }

   public JSONObject(Map var1) {
      super(var1);
   }
   public static void writeJSONString(Map var0, Writer var1) throws IOException {
      if (var0 == null) {
         var1.write("null");
      } else {
         boolean var2 = true;
         Iterator var3 = var0.entrySet().iterator();
         var1.write(123);

         while((var3.hasNext()) != 0) {
            if (var2) {
               var2 = false;
            } else {
               var1.write(44);
            }

            Map.Entry var4 = (Map.Entry)var3.next();
            var1.write(34);
            var1.write(escape(String.valueOf(var4.getKey())));
            var1.write(34);
            var1.write(58);
            JSONValue.writeJSONString(var4.getValue(), var1);
         }

         var1.write(125);
      }
   }

   public void writeJSONString(Writer var1) throws IOException {
      writeJSONString(this, var1);
   }
   public static String toJSONString(Map var0) {
      StringWriter var1 = new StringWriter();

      try {
         writeJSONString(var0, var1);
         return var1.toString();
      } catch (IOException var3) {
         RuntimeException var4 = new RuntimeException(var3);
         throw var4;
      }
   }

   public String toJSONString() {
      return toJSONString(this);
   }

   public String toString() {
      return this.toJSONString();
   }
   public static String toString(String var0, Object var1) {
      StringBuffer var2 = new StringBuffer();
      var2.append('"');
      if (var0 == null) {
         var2.append("null");
      } else {
         JSONValue.escape(var0, var2);
      }

      var2.append('"').append(':');
      var2.append(JSONValue.toJSONString(var1));
      return var2.toString();
   }
   public static String escape(String var0) {
      return JSONValue.escape(var0);
   }
   

   

   
}
