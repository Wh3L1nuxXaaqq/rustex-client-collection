package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class DiscordThumbnail {
    
   public String url;
    
   public final DiscordEmbed this$0;

   public DiscordThumbnail(DiscordEmbed var1, String var2) {
      this.this$0 = var1;
      this.url = var2;
   }

   public String getUrl() {
      return this.url;
   }
   public static String access$300(DiscordThumbnail var0) {
      return var0.getUrl();
   }
   

   
}
