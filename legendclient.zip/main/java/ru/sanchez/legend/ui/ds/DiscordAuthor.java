package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class DiscordAuthor {
    
   public String name;
    
   public String url;
    
   public String iconUrl;
    
   public final DiscordEmbed this$0;

   public DiscordAuthor(DiscordEmbed var1, String var2, String var3, String var4) {
      this.this$0 = var1;
      this.name = var2;
      this.url = var3;
      this.iconUrl = var4;
   }

   public String getName() {
      return this.name;
   }

   public String getUrl() {
      return this.url;
   }

   public String getIconUrl() {
      return this.iconUrl;
   }
   public static String access$500(DiscordAuthor var0) {
      return var0.getName();
   }
   public static String access$600(DiscordAuthor var0) {
      return var0.getUrl();
   }
   public static String access$700(DiscordAuthor var0) {
      return var0.getIconUrl();
   }
   

   
}
