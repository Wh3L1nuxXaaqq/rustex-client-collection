package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;

 
public class DiscordWebhook {
    
   public final String url;
    
   public String content;
    
   public String username;
    
   public String avatarUrl;
    
   public boolean tts;
    
   public List<DiscordEmbed> embeds = new ArrayList();

   public DiscordWebhook(String var1) {
      this.url = var1;
   }

   public void setContent(String var1) {
      this.content = var1;
   }

   public void setUsername(String var1) {
      this.username = var1;
   }

   public void setAvatarUrl(String var1) {
      this.avatarUrl = var1;
   }

   public void setTts(boolean var1) {
      this.tts = (boolean)(var1);
   }

   public void addEmbed(DiscordEmbed var1) {
      this.embeds.add(var1);
   }

   public void clearEmbeds() {
      this.embeds.clear();
   }

   public void execute() throws IOException {
      if (this.content == null && (this.embeds.isEmpty()) != 0) {
         IllegalArgumentException var32 = new IllegalArgumentException("Set content or add at least one EmbedObject");
         throw var32;
      } else {
         DiscordWebhookJsonHelper var1 = new DiscordWebhookJsonHelper(this);
         var1.put("content", this.content);
         var1.put("username", this.username);
         var1.put("avatar_url", this.avatarUrl);
         var1.put("tts", Boolean.valueOf((boolean)(this.tts)));
         if ((this.embeds.isEmpty()) == 0) {
            ArrayList var2 = new ArrayList();
            Iterator var3 = this.embeds.iterator();

            while((var3.hasNext()) != 0) {
               DiscordEmbed var4 = (DiscordEmbed)var3.next();
               DiscordWebhookJsonHelper var5 = new DiscordWebhookJsonHelper(this);
               var5.put("title", var4.getTitle());
               var5.put("description", var4.getDescription());
               var5.put("url", var4.getUrl());
               if (var4.getColor() != null) {
                  Color var6 = var4.getColor();
                  int var7 = var6.getRed();
                  var7 = (var7 << 8) + var6.getGreen();
                  var7 = (var7 << 8) + var6.getBlue();
                  var5.put("color", var7);
               }

               DiscordFooter var18 = var4.getFooter();
               DiscordThumbnail var21 = var4.getImage();
               DiscordImage var8 = var4.getThumbnail();
               DiscordAuthor var9 = var4.getAuthor();
               List var10 = var4.getFields();
               if (var18 != null) {
                  DiscordWebhookJsonHelper var11 = new DiscordWebhookJsonHelper(this);
                  var11.put("text", DiscordFooter.access$100(var18));
                  var11.put("icon_url", DiscordFooter.access$200(var18));
                  var5.put("footer", var11);
               }

               if (var21 != null) {
                  DiscordWebhookJsonHelper var22 = new DiscordWebhookJsonHelper(this);
                  var22.put("url", DiscordThumbnail.access$300(var21));
                  var5.put("image", var22);
               }

               if (var8 != null) {
                  DiscordWebhookJsonHelper var23 = new DiscordWebhookJsonHelper(this);
                  var23.put("url", DiscordImage.access$400(var8));
                  var5.put("thumbnail", var23);
               }

               if (var9 != null) {
                  DiscordWebhookJsonHelper var24 = new DiscordWebhookJsonHelper(this);
                  var24.put("name", DiscordAuthor.access$500(var9));
                  var24.put("url", DiscordAuthor.access$600(var9));
                  var24.put("icon_url", DiscordAuthor.access$700(var9));
                  var5.put("author", var24);
               }
               ArrayList var25 = new ArrayList();
               Iterator var12 = var10.iterator();

               while((var12.hasNext()) != 0) {
                  DiscordField var13 = (DiscordField)var12.next();
                  DiscordWebhookJsonHelper var14 = new DiscordWebhookJsonHelper(this);
                  var14.put("name", DiscordField.access$800(var13));
                  var14.put("value", DiscordField.access$900(var13));
                  var14.put("inline", Boolean.valueOf((boolean)(DiscordField.access$1000(var13))));
                  var25.add(var14);
               }

               var5.put("fields", var25.toArray());
               var2.add(var5);
            }

            var1.put("embeds", var2.toArray());
         }
         URL var15 = new URL(this.url);
         HttpsURLConnection var16 = (HttpsURLConnection)var15.openConnection();
         var16.addRequestProperty("Content-Type", "application/json");
         var16.addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
         var16.setDoOutput(true);
         var16.setRequestMethod("POST");
         OutputStream var17 = var16.getOutputStream();
         var17.write(var1.toString().getBytes());
         var17.flush();
         var17.close();
         var16.getInputStream().close();
         var16.disconnect();
      }
   }
   

   

   
}
