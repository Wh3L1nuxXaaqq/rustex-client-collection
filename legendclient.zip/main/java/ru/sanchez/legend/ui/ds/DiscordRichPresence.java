package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

 
public class DiscordRichPresence extends Structure {
    
   public static final List<String> FIELD_ORDER;
    
   public String state;
    
   public String details;
    
   public long startTimestamp;
    
   public long endTimestamp;
    
   public String largeImageKey;
    
   public String largeImageText;
    
   public String smallImageKey;
    
   public String smallImageText;
    
   public String partyId;
    
   public int partySize;
    
   public int partyMax;
    
   public String matchSecret;
    
   public String joinSecret;
    
   public String spectateSecret;
    
   public byte instance;

   public DiscordRichPresence(String var1) {
      this.setStringEncoding(var1);
   }

   public DiscordRichPresence() {
      this("UTF-8");
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof DiscordRichPresence)) {
         return false;
      } else {
         DiscordRichPresence var2 = (DiscordRichPresence)var1;
         return this.startTimestamp == var2.startTimestamp && this.endTimestamp == var2.endTimestamp && this.partySize == var2.partySize && this.partyMax == var2.partyMax && this.instance == var2.instance && (Objects.equals(this.state, var2.state)) != 0 && (Objects.equals(this.details, var2.details)) != 0 && (Objects.equals(this.largeImageKey, var2.largeImageKey)) != 0 && (Objects.equals(this.largeImageText, var2.largeImageText)) != 0 && (Objects.equals(this.smallImageKey, var2.smallImageKey)) != 0 && (Objects.equals(this.smallImageText, var2.smallImageText)) != 0 && (Objects.equals(this.partyId, var2.partyId)) != 0 && (Objects.equals(this.matchSecret, var2.matchSecret)) != 0 && (Objects.equals(this.joinSecret, var2.joinSecret)) != 0 && (Objects.equals(this.spectateSecret, var2.spectateSecret)) != 0;
      }
   }

   public int hashCode() {
      Object[] var12 = new Object[15];
      var12[0] = this.state;
      var12[1] = this.details;
      var12[2] = this.startTimestamp;
      var12[3] = this.endTimestamp;
      var12[4] = this.largeImageKey;
      var12[5] = this.largeImageText;
      var12[6] = this.smallImageKey;
      var12[7] = this.smallImageText;
      var12[8] = this.partyId;
      var12[9] = this.partySize;
      var12[10] = this.partyMax;
      var12[11] = this.matchSecret;
      var12[12] = this.joinSecret;
      var12[13] = this.spectateSecret;
      var12[14] = this.instance;
      return Objects.hash(var12);
   }

   public List<String> getFieldOrder() {
      return FIELD_ORDER;
   }

   static {
      
      FIELD_ORDER = Collections.unmodifiableList(Arrays.asList("state", "details", "startTimestamp", "endTimestamp", "largeImageKey", "largeImageText", "smallImageKey", "smallImageText", "partyId", "partySize", "partyMax", "matchSecret", "joinSecret", "spectateSecret", "instance"));
   }
   

   
}
