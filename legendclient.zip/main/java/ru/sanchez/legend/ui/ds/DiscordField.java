package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class DiscordField {
    
   public String name;
    
   public String value;
    
   public boolean inline;
    
   public final DiscordEmbed this$0;

   public DiscordField(DiscordEmbed var1, String var2, String var3, boolean var4) {
      this.this$0 = var1;
      this.name = var2;
      this.value = var3;
      this.inline = (boolean)(var4);
   }

   public String getName() {
      return this.name;
   }

   public String getValue() {
      return this.value;
   }

   public boolean isInline() {
      return (boolean)(this.inline);
   }
   public static String access$800(DiscordField var0) {
      return var0.getName();
   }
   public static String access$900(DiscordField var0) {
      return var0.getValue();
   }
   public static boolean access$1000(DiscordField var0) {
      return (boolean)(var0.isInline());
   }
   

   

   
}
