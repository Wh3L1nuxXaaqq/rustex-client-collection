package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class DiscordFooter {
    
   public String text;
    
   public String iconUrl;
    
   public final DiscordEmbed this$0;

   public DiscordFooter(DiscordEmbed var1, String var2, String var3) {
      this.this$0 = var1;
      this.text = var2;
      this.iconUrl = var3;
   }

   public String getText() {
      return this.text;
   }

   public String getIconUrl() {
      return this.iconUrl;
   }
   public static String access$100(DiscordFooter var0) {
      return var0.getText();
   }
   public static String access$200(DiscordFooter var0) {
      return var0.getIconUrl();
   }
   

   
}
