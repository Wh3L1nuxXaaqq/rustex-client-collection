package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

 
public class DiscordEmbed {
    
   public String title;
    
   public String description;
    
   public String url;
    
   public Color color;
    
   public DiscordFooter footer;
    
   public DiscordImage thumbnail;
    
   public DiscordThumbnail image;
    
   public DiscordAuthor author;
    
   public List<DiscordField> fields = new ArrayList();

   public String getTitle() {
      return this.title;
   }

   public String getDescription() {
      return this.description;
   }

   public String getUrl() {
      return this.url;
   }

   public Color getColor() {
      return this.color;
   }

   public DiscordFooter getFooter() {
      return this.footer;
   }

   public DiscordImage getThumbnail() {
      return this.thumbnail;
   }

   public DiscordThumbnail getImage() {
      return this.image;
   }

   public DiscordAuthor getAuthor() {
      return this.author;
   }

   public List<DiscordField> getFields() {
      return this.fields;
   }

   public DiscordEmbed setTitle(String var1) {
      this.title = var1;
      return this;
   }

   public DiscordEmbed setDescription(String var1) {
      this.description = var1;
      return this;
   }

   public DiscordEmbed setUrl(String var1) {
      this.url = var1;
      return this;
   }

   public DiscordEmbed setColor(Color var1) {
      this.color = var1;
      return this;
   }

   public DiscordEmbed setFooter(String var1, String var2) {
      this.footer = new DiscordFooter(this, var1, var2);
      return this;
   }

   public DiscordEmbed setThumbnail(String var1) {
      this.thumbnail = new DiscordImage(this, var1);
      return this;
   }

   public DiscordEmbed setImage(String var1) {
      this.image = new DiscordThumbnail(this, var1);
      return this;
   }

   public DiscordEmbed setAuthor(String var1, String var2, String var3) {
      this.author = new DiscordAuthor(this, var1, var2, var3);
      return this;
   }

   public DiscordEmbed addField(String var1, String var2, boolean var3) {
      List var4 = this.fields;
      var4.add(new DiscordField(this, var1, var2, var3));
      return this;
   }
   

   

   
}
