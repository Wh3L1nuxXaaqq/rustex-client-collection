package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.sun.jna.Library;
import com.sun.jna.Native;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

 
public interface DiscordRpcLibrary extends Library {
    
   DiscordRpcLibrary INSTANCE = (DiscordRpcLibrary)Native.loadLibrary("discord-rpc", DiscordRpcLibrary.class);
    
   int DISCORD_REPLY_NO = 0;
    
   int DISCORD_REPLY_YES = 1;
    
   int DISCORD_REPLY_IGNORE = 2;

   void Discord_Initialize(@Nonnull String var1, @Nullable DiscordEventHandlers var2, boolean var3, @Nullable String var4);

   void Discord_Shutdown();

   void Discord_RunCallbacks();

   void Discord_UpdateConnection();

   void Discord_UpdatePresence(@Nullable DiscordRichPresence var1);

   void Discord_ClearPresence();

   void Discord_Respond(@Nonnull String var1, int var2);

   void Discord_UpdateHandlers(@Nullable DiscordEventHandlers var1);

   void Discord_Register(String var1, String var2);

   void Discord_RegisterSteamGame(String var1, String var2);
}
