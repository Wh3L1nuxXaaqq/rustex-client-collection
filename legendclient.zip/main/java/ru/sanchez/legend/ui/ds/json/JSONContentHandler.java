package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.IOException;

 
public interface JSONContentHandler {
   void startJSON() throws JsonParseException, IOException;

   void endJSON() throws JsonParseException, IOException;

   boolean startObject() throws JsonParseException, IOException;

   boolean endObject() throws JsonParseException, IOException;

   boolean startObjectEntry(String var1) throws JsonParseException, IOException;

   boolean endObjectEntry() throws JsonParseException, IOException;

   boolean startArray() throws JsonParseException, IOException;

   boolean endArray() throws JsonParseException, IOException;

   boolean primitive(Object var1) throws JsonParseException, IOException;
}
