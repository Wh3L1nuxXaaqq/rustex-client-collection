package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

 
public class DiscordEventHandlers extends Structure {
    
   public static final List<String> FIELD_ORDER;
    
   public DiscordReadyCallback ready;
    
   public DiscordDisconnectCallback disconnected;
    
   public DiscordDisconnectCallback errored;
    
   public DiscordJoinCallback joinGame;
    
   public DiscordJoinCallback spectateGame;
    
   public DiscordJoinRequestCallback joinRequest;

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof DiscordEventHandlers)) {
         return false;
      } else {
         DiscordEventHandlers var2 = (DiscordEventHandlers)var1;
         return (Objects.equals(this.ready, var2.ready)) != 0 && (Objects.equals(this.disconnected, var2.disconnected)) != 0 && (Objects.equals(this.errored, var2.errored)) != 0 && (Objects.equals(this.joinGame, var2.joinGame)) != 0 && (Objects.equals(this.spectateGame, var2.spectateGame)) != 0 && (Objects.equals(this.joinRequest, var2.joinRequest)) != 0;
      }
   }

   public int hashCode() {
      Object[] var6 = new Object[6];
      var6[0] = this.ready;
      var6[1] = this.disconnected;
      var6[2] = this.errored;
      var6[3] = this.joinGame;
      var6[4] = this.spectateGame;
      var6[5] = this.joinRequest;
      return Objects.hash(var6);
   }

   public List<String> getFieldOrder() {
      return FIELD_ORDER;
   }

   static {
      
      FIELD_ORDER = Collections.unmodifiableList(Arrays.asList("ready", "disconnected", "errored", "joinGame", "spectateGame", "joinRequest"));
   }
   

   
}
