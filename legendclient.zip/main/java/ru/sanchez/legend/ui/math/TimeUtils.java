package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

 
public class TimeUtils {
   public static String getCurrentTime() {
      LocalTime var0 = LocalTime.now();
      DateTimeFormatter var1 = DateTimeFormatter.ofPattern("HH:mm");
      return var0.format(var1);
   }
   

   
}
