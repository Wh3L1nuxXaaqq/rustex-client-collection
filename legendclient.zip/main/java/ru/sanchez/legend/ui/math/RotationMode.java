package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public enum RotationMode {
    
   PACKET,
    
   CLIENT,
    
   NONE;

   static {
      
      PACKET = new RotationMode("PACKET", 0);
      CLIENT = new RotationMode("CLIENT", 1);
      NONE = new RotationMode("NONE", 2);
   }
   
}
