package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

 
public class BowAimUtils {
   public static boolean isInAttackFOV(Entity var0, int var1) {
      return getDistanceFromMouse(var0) <= var1;
   }
   public static boolean isInAttackFOV2(Entity var0, int var1) {
      return getDistanceFromMouse2(var0) <= var1;
   }
   public static int getDistanceFromMouse(Entity var0) {
      float[] var1 = getNeededRotations(var0);
      if (var1 != null) {
         float var10000 = Minecraft.getMinecraft().player.rotationYaw;
         float var10001 = var1[0];
         float var2 = var10000 - var10001;
         var10000 = Minecraft.getMinecraft().player.rotationPitch;
         var10001 = var1[1];
         float var3 = var10000 - var10001;
         float var4 = MathHelper.sqrt(var2 * var2 + var3 * var3 * 2.0F);
         return (int)var4;
      } else {
         return -1;
      }
   }
   public static int getDistanceFromMouse2(Entity var0) {
      Minecraft var1 = Wrapper.mc;
      float[] var2 = getNeededRotations2(var0);
      float var10000 = var1.player.rotationYaw;
      float var10001 = var2[0];
      float var3 = var10000 - var10001;
      var10000 = var1.player.rotationPitch;
      var10001 = var2[1];
      float var4 = var10000 - var10001;
      float var5 = MathHelper.sqrt(var3 * var3 + var4 * var4);
      return (int)var5;
   }
   public static float[] getNeededRotations(Entity var0) {
      Vec3d var1 = getEyesPos();
      double var14 = var0.posX;
      double var23 = var1.x;
      double var2 = var14 - var23;
      var14 = var0.posY + (double)1.86F;
      var23 = var1.y;
      double var4 = var14 - var23;
      int var6 = (Legend.moduleManager.getModule("BAim").isToggled());
      if (var6 != 0) {
         var4 -= (double)0.76F;
      }

      var14 = var0.posZ;
      var23 = var1.z;
      double var7 = var14 - var23;
      double var9 = Math.sqrt(var2 * var2 + var7 * var7);
      float var17 = (float)Math.toDegrees(Math.atan2(var7, var2));
      float var11 = var17 - 90.0F;
      float var12 = (float)(-Math.toDegrees(Math.atan2(var4, var9)));
      float[] var18 = new float[2];
      float var10003 = Minecraft.getMinecraft().player.rotationYaw;
      float var10005 = Minecraft.getMinecraft().player.rotationYaw;
      var18[0] = var10003 + MathHelper.wrapDegrees(var11 - var10005);
      var10003 = Minecraft.getMinecraft().player.rotationPitch;
      var10005 = Minecraft.getMinecraft().player.rotationPitch;
      var18[1] = var10003 + MathHelper.wrapDegrees(var12 - var10005);
      return var18;
   }
   public static float[] getNeededRotations2(Entity var0) {
      Minecraft var1 = Wrapper.mc;
      double var22 = var0.posX;
      double var33 = Minecraft.getMinecraft().player.posX;
      double var2 = var22 - var33;
      var22 = var0.posY + 1.86;
      var33 = var1.player.posY + (double)var1.player.getEyeHeight();
      double var4 = var22 - var33;
      var22 = var0.posZ;
      var33 = Minecraft.getMinecraft().player.posZ;
      double var6 = var22 - var33;
      int var8 = (Legend.moduleManager.getModule("BAim").isToggled());
      if (var8 != 0) {
         var22 = var0.posY + 1.36;
         var33 = var1.player.posY + (double)var1.player.getEyeHeight();
         var4 = var22 - var33;
      }

      double var9 = Math.sqrt(var2 * var2 + var6 * var6);
      Math.sqrt(var9 * var9 + var4 * var4);
      var22 = Math.toDegrees(Math.atan2(var6, var2));
      double var13 = var22 - (double)90.0F;
      double var15 = -Math.toDegrees(Math.atan2(var4, var9));
      var22 = (double)var1.player.rotationYaw;
      double var38 = (double)var1.player.rotationYaw;
      double var17 = var22 + MathHelper.wrapDegrees(var13 - var38);
      var22 = (double)var1.player.rotationPitch;
      var38 = (double)var1.player.rotationPitch;
      double var19 = var22 + MathHelper.wrapDegrees(var15 - var38);
      float[] var29 = new float[2];
      var29[0] = (float)var17;
      var29[1] = (float)var19;
      return var29;
   }
   public static Vec3d getEyesPos() {
      return new Vec3d(Minecraft.getMinecraft().player.posX, Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight(), Minecraft.getMinecraft().player.posZ);
   }
   public static String getPlayerName(EntityPlayer var0) {
      return var0.getGameProfile() != null ? var0.getGameProfile().getName() : "null";
   }
   

   

   
}
