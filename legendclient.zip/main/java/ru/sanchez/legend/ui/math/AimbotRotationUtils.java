package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

 
public class AimbotRotationUtils {
   public static float[] getAverageRotations(List var0) {
      double var1 = (double)0.0F;
      double var3 = (double)0.0F;
      double var5 = (double)0.0F;

      Entity var9;
      for(Iterator var7 = var0.iterator(); (var7.hasNext()) != 0; var5 += var9.posZ) {
         Object var8 = var7.next();
         var9 = (Entity)var8;
         var1 += var9.posX;
         double var10001 = var9.getEntityBoundingBox().maxY;
         var3 += var10001 - (double)2.0F;
      }

      float[] var13 = new float[2];
      boolean var14 = false;
      var1 /= (double)var0.size();
      var5 /= (double)var0.size();
      double var11;
      var13[0] = getRotationFromPosition(var1, var5, var11 = var3 / (double)var0.size())[0];
      var13[1] = getRotationFromPosition(var1, var5, var11)[1];
      return var13;
   }
   public static float getDistanceBetweenAngles(float var0, float var1) {
      float var2 = Math.abs(var0 - var1) % 360.0F;
      if (var2 > 180.0F) {
         var2 = 360.0F - var2;
      }

      return var2;
   }
   public static float getTrajAngleSolutionLow(float var0, float var1, float var2) {
      float var10000 = var2 * var2 * var2 * var2;
      float var10001 = 0.006F * (0.006F * var0 * var0 + 2.0F * var1 * var2 * var2);
      float var3 = var10000 - var10001;
      double var4 = (double)(var2 * var2);
      double var5 = Math.sqrt((double)var3);
      return (float)Math.toDegrees(Math.atan((var4 - var5) / (double)(0.006F * var0)));
   }
   public static float[] getRotationFromPosition(double var0, double var2, double var4) {
      double var24 = Minecraft.getMinecraft().player.posX;
      double var6 = var0 - var24;
      var24 = Minecraft.getMinecraft().player.posZ;
      double var8 = var2 - var24;
      var24 = Minecraft.getMinecraft().player.posY;
      double var16 = var4 - var24;
      double var10 = var16 - 0.6;
      double var12 = (double)MathHelper.sqrt(var6 * var6 + var8 * var8);
      float var17 = (float)(Math.atan2(var8, var6) * (double)180.0F / Math.PI);
      float var14 = var17 - 90.0F;
      float var15 = (float)(-(Math.atan2(var10, var12) * (double)180.0F / Math.PI));
      float[] var18 = new float[2];
      var18[0] = var14;
      var18[1] = var15;
      return var18;
   }
   public static float[] getNeededRotations(Entity var0) {
      double var12 = var0.posX;
      double var21 = Minecraft.getMinecraft().player.posX;
      double var1 = var12 - var21;
      var12 = var0.posZ;
      var21 = Minecraft.getMinecraft().player.posZ;
      double var3 = var12 - var21;
      var12 = var0.posY + (double)var0.getEyeHeight();
      var21 = Minecraft.getMinecraft().player.getEntityBoundingBox().minY;
      double var26 = Minecraft.getMinecraft().player.getEntityBoundingBox().maxY;
      double var10003 = Minecraft.getMinecraft().player.getEntityBoundingBox().minY;
      var21 += var26 - var10003;
      double var5 = var12 - var21;
      double var7 = (double)MathHelper.sqrt(var1 * var1 + var3 * var3);
      float var15 = (float)(MathHelper.atan2(var3, var1) * (double)180.0F / Math.PI);
      float var9 = var15 - 90.0F;
      float var10 = (float)(-(MathHelper.atan2(var5, var7) * (double)180.0F / Math.PI));
      float[] var16 = new float[2];
      var16[0] = var9;
      var16[1] = var10;
      return var16;
   }
   public static float[] getRotations(EntityLivingBase var0, String var1) {
      if (var1 == "Head") {
         double var11 = var0.posX;
         double var15 = var0.posZ;
         double var19 = var0.posY + (double)(var0.getEyeHeight() / 2.0F);
         return getRotationFromPosition(var11, var15, var19);
      } else if (var1 == "Chest") {
         double var10 = var0.posX;
         double var14 = var0.posZ;
         double var22 = var0.posY + (double)(var0.getEyeHeight() / 2.0F);
         double var18 = var22 - (double)0.75F;
         return getRotationFromPosition(var10, var14, var18);
      } else if (var1 == "Dick") {
         double var9 = var0.posX;
         double var13 = var0.posZ;
         double var21 = var0.posY + (double)(var0.getEyeHeight() / 2.0F);
         double var17 = var21 - 1.2;
         return getRotationFromPosition(var9, var13, var17);
      } else if (var1 == "Legs") {
         double var8 = var0.posX;
         double var12 = var0.posZ;
         double var20 = var0.posY + (double)(var0.getEyeHeight() / 2.0F);
         double var16 = var20 - (double)1.5F;
         return getRotationFromPosition(var8, var12, var16);
      } else {
         double var2 = var0.posX;
         double var4 = var0.posZ;
         double var10000 = var0.posY + (double)(var0.getEyeHeight() / 2.0F);
         double var6 = var10000 - (double)0.5F;
         return getRotationFromPosition(var2, var4, var6);
      }
   }
   public static float getNewAngle(float var0) {
      float var2 = var0 % 360.0F;
      var0 = var2;
      if (var2 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }
   

   

   
}
