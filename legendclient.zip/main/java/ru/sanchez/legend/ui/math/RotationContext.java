package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class RotationContext implements Wrapper {
    
   public float yaw;
    
   public float pitch;
    
   public final RotationMode rotate;

   public RotationContext(float var1, float var2, RotationMode var3) {
      this.yaw = var1;
      this.pitch = var2;
      this.rotate = var3;
   }

   public RotationContext(float var1, float var2) {
      this(var1, var2, RotationMode.NONE);
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public RotationMode getRotation() {
      return this.rotate;
   }

   public boolean isValid() {
      return (Float.isNaN(this.getYaw())) == 0 && (Float.isNaN(this.getPitch())) == 0;
   }
   

   

   
}
