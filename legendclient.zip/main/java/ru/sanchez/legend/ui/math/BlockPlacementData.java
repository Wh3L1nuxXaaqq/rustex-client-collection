package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

 
public class BlockPlacementData {
    
   public final BlockPos position;
    
   public final EnumFacing face;

   public BlockPlacementData(BlockPos var1, EnumFacing var2) {
      this.position = var1;
      this.face = var2;
   }
   public static BlockPlacementData getBlockData(BlockPos var0) {
      if (Minecraft.getMinecraft().world.getBlockState(var0.add(0, -1, 0)).getBlock() != Blocks.AIR) {
         return new BlockPlacementData(var0.add(0, -1, 0), EnumFacing.UP);
      } else if (Minecraft.getMinecraft().world.getBlockState(var0.add(-1, 0, 0)).getBlock() != Blocks.AIR) {
         return new BlockPlacementData(var0.add(-1, 0, 0), EnumFacing.EAST);
      } else if (Minecraft.getMinecraft().world.getBlockState(var0.add(1, 0, 0)).getBlock() != Blocks.AIR) {
         return new BlockPlacementData(var0.add(1, 0, 0), EnumFacing.WEST);
      } else if (Minecraft.getMinecraft().world.getBlockState(var0.add(0, 0, -1)).getBlock() != Blocks.AIR) {
         return new BlockPlacementData(var0.add(0, 0, -1), EnumFacing.SOUTH);
      } else if (Minecraft.getMinecraft().world.getBlockState(var0.add(0, 0, 1)).getBlock() != Blocks.AIR) {
         return new BlockPlacementData(var0.add(0, 0, 1), EnumFacing.NORTH);
      } else {
         return null;
      }
   }
   

   
}
