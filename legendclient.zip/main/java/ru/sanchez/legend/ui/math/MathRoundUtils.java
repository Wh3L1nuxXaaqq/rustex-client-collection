package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

 
public class MathRoundUtils {
   public static float round(float var0, int var1) {
      return (new BigDecimal((double)var0)).setScale(var1, RoundingMode.HALF_EVEN).floatValue();
   }
   public static double round(double var0, int var2) {
      return (new BigDecimal(var0)).setScale(var2, RoundingMode.HALF_EVEN).doubleValue();
   }
   

   
}
