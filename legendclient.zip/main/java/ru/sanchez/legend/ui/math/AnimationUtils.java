package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;

 
public class AnimationUtils {
    
   public static float speedTarget;
   public static float animation(float var0, float var1, float var2) {
      return animation(var0, var1, speedTarget, var2);
   }
   public static float animation(float var0, float var1, float var2, float var3) {
      float var4 = (var1 - var0) / Math.max((float)Minecraft.getDebugFPS(), 5.0F) * 15.0F;
      if (var4 > 0.0F) {
         var4 = Math.max(var3, var4);
         var4 = Math.min(var1 - var0, var4);
      } else if (var4 < 0.0F) {
         var4 = Math.min(-var3, var4);
         var4 = Math.max(var1 - var0, var4);
      }

      return var0 + var4;
   }
   public static double animate(double var0, double var2, double var4) {
      boolean var13 = var0 > var2;
      boolean var6 = var13;
      if (var4 < (double)0.0F) {
         var4 = (double)0.0F;
      } else if (var4 > (double)1.0F) {
         var4 = (double)1.0F;
      }

      double var14 = Math.max(var0, var2);
      double var18 = Math.min(var0, var2);
      double var8 = var14 - var18;
      double var10 = var8 * var4;
      if (var10 < 0.1) {
         var10 = 0.1;
      }

      if (var6) {
         var14 = var2 + var10;
      } else {
         var14 = var2 - var10;
      }

      var2 = var14;
      return var2;
   }

   static {
      
      speedTarget = 0.125F;
   }
   
}
