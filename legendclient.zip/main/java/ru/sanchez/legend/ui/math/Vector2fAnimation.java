package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public final class Vector2fAnimation {
    
   public double x;
    
   public double y;

   public Vector2fAnimation(float var1, float var2) {
      this.x = (double)var1;
      this.y = (double)var2;
   }

   public final void interpolate(double var1, double var3, double var5) {
      this.x = AnimationUtils.animate(var1, this.x, var5);
      this.y = AnimationUtils.animate(var3, this.y, var5);
   }

   public void animate(double var1, double var3) {
      this.x = AnimationUtils.animate(this.x, var1, (double)1.0F);
      this.y = AnimationUtils.animate(this.y, var3, (double)1.0F);
   }

   public double getX() {
      return this.x;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public double getY() {
      return this.y;
   }

   public void setY(double var1) {
      this.y = var1;
   }
   

   
}
