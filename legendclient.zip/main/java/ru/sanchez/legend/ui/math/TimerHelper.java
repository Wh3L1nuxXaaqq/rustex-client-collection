package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public final class TimerHelper {
    
   public long ms = this.getCurrentMS();

   public long getCurrentMS() {
      return System.currentTimeMillis();
   }

   public final long getElapsedTime() {
      return this.getCurrentMS() - this.ms;
   }

   public final boolean elapsed(long var1) {
      return this.getCurrentMS() - this.ms > var1;
   }

   public final void reset() {
      this.ms = this.getCurrentMS();
   }
   

   
}
