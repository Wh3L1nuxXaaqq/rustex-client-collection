package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;

 
public class GCDRotationUtils {
    
   public float yaw;
    
   public float pitch;
    
   public static Minecraft mc;

   public GCDRotationUtils(float var1, float var2) {
      this.yaw = var1;
      this.pitch = var2;
   }
   public static float getFixedRotation(float var0) {
      return getDeltaMouse(var0) * getGCDValue();
   }
   public static float getGCDValue() {
      return (float)((double)getGCD() * 0.15);
   }
   public static float getGCD() {
      float var1 = (float)((double)mc.gameSettings.mouseSensitivity * 0.6 + 0.2);
      float var0 = var1;
      return var1 * var0 * var0 * 8.0F;
   }
   public static float getDeltaMouse(float var0) {
      return (float)Math.round(var0 / getGCDValue());
   }

   public final float getYaw() {
      return this.yaw;
   }

   public final void setYaw(float var1) {
      this.yaw = var1;
   }

   public final float getPitch() {
      return this.pitch;
   }

   public final void setPitch(float var1) {
      this.pitch = var1;
   }

   public String toString() {
      return "Rotation(yaw=" + this.yaw + ", pitch=" + this.pitch + ")";
   }

   public int hashCode() {
      return Float.hashCode(this.yaw) * 31 + Float.hashCode(this.pitch);
   }

   public boolean equals(Object var1) {
      if (this != var1) {
         if (!(var1 instanceof GCDRotationUtils)) {
            return false;
         } else {
            GCDRotationUtils var2 = (GCDRotationUtils)var1;
            return Float.compare(this.yaw, var2.yaw) == 0 && Float.compare(this.pitch, var2.pitch) == 0;
         }
      } else {
         return true;
      }
   }

   static {
      
      mc = Minecraft.getMinecraft();
   }
   
}
