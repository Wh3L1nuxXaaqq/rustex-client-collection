package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.util.math.BlockPos;

 
public class BlockCoordId {
    
   public int x;
    
   public int y;
    
   public int z;
    
   public int id;
    
   public BlockPos pos;

   public BlockCoordId(int var1, int var2, int var3, int var4) {
      this.pos = new BlockPos(var1, var2, var3);
      this.id = var4;
   }

   public BlockCoordId(BlockPos var1) {
      this(var1, -1);
   }

   public BlockCoordId(BlockPos var1, int var2) {
      this(var1.getX(), var1.getY(), var1.getZ(), var2);
      this.pos = var1;
      this.id = var2;
   }

   public int hashCode() {
      return (this.pos.getY() + this.pos.getZ() * 859433) * 859433 + this.pos.getX();
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public int getX() {
      return this.pos.getX();
   }

   public int getY() {
      return this.pos.getY();
   }

   public int getZ() {
      return this.pos.getZ();
   }

   public int getId() {
      return this.id;
   }
   public static BlockCoordId readBytes(byte[] var0) {
      byte var1 = var0[0];
      int var2 = var0[1] & 255 | var0[2] << 8 & 32767;
      if ((var0[2] & 128) == 128) {
         var2 = -var2;
      }

      int var3 = var0[3] & 255 | var0[4] << 8 & 32767;
      if ((var0[4] & 128) == 128) {
         var3 = -var3;
      }

      int var4 = var0[5] & 255 | var0[6] << 8 & 32767;
      if ((var0[6] & 128) == 128) {
         var4 = -var4;
      }
      return new BlockCoordId(var2, var3, var4, var1);
   }

   public BlockCoordId add(int var1, int var2, int var3) {
      return new BlockCoordId(new BlockPos(this.pos.getX() + var1, this.pos.getY() + var2, this.pos.getZ() + var3), this.id);
   }

   public void setPos(BlockPos var1) {
      this.pos = var1;
   }

   public byte[] toBytes() {
      byte[] var1 = new byte[7];
      int var2 = this.getX();
      int var3 = this.getY();
      int var4 = this.getZ();
      var1[0] = (byte)(this.id & 255);
      var1[1] = (byte)(Math.abs(var2) & 255);
      var1[2] = (byte)(Math.abs(var2) >> 8 & 255 | (var2 < 0 ? 128 : 0));
      var1[3] = (byte)(Math.abs(var3) & 255);
      var1[4] = (byte)(Math.abs(var3) >> 8 & 127 | (var3 < 0 ? 128 : 0));
      var1[5] = (byte)(Math.abs(var4) & 255);
      var1[6] = (byte)(Math.abs(var4) >> 8 & 127 | (var4 < 0 ? 128 : 0));
      return var1;
   }
   

   
}
