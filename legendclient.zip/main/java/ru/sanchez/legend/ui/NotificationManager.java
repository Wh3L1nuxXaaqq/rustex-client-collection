package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

 
public class NotificationManager {
    
   public static List<String> Names;
    
   public static List<String> Tests;
    
   public static List<NotificationType> Types;
    
   public static List<Integer> Times;
    
   public static float height;
    
   public static float width;
   public static void add(String var0, String var1, NotificationType var2) {
      Names.add(var0);
      Tests.add(var1);
      Types.add(var2);
      Times.add(0);
   }
   public static void drawnotif(int var0, String var1, String var2, NotificationType var3, int var4) {
      GlStateManager.enableTexture2D();
      ScaledResolution var5 = new ScaledResolution(Minecraft.getMinecraft());
      GL11.glPushMatrix();
      if (var4 >= 110) {
         int var14 = var5.getScaledWidth();
         double var15 = (double)(var14 - 110);
         double var46 = (double)var5.getScaledHeight();
         double var59 = (double)var4 * (double)1.5F;
         GL11.glTranslated(var15, var46 - var59 + (double)10.0F, (double)0.0F);
      } else {
         int var16 = var5.getScaledWidth();
         double var17 = (double)(var16 - var4);
         double var47 = (double)var5.getScaledHeight();
         double var60 = (double)var4 * (double)1.5F;
         GL11.glTranslated(var17, var47 - var60 + (double)10.0F, (double)0.0F);
      }

      double var48 = (double)var4;
      var48 -= 7.6;
      int var6 = (int)((double)230.0F - var48);
      if (var6 >= 0) {
         if (var3 == NotificationType.Green) {
            float var61 = width;
            float var10003 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, var61, var10003, (new Color(35, 35, 40, var6)).getRGB());
            var10003 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, 7.0F, var10003, (new Color(51, 255, 0, var6)).getRGB());
            FontStorage.fr3.drawStringWithShadow(var1, 10.0F, 2.0F, RainbowUtils.getColor());
            CFontRenderer var18 = FontStorage.fr3;
            var10003 = (float)(4 + Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT);
            var18.drawString(var2, 10.0F, var10003, (new Color(255, 255, 255, var6)).getRGB());
         } else if (var3 == NotificationType.Red) {
            float var62 = width;
            float var66 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, var62, var66, (new Color(35, 35, 40, var6)).getRGB());
            var66 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, 7.0F, var66, (new Color(255, 0, 0, var6)).getRGB());
            FontStorage.fr3.drawStringWithShadow(var1, 10.0F, 2.0F, RainbowUtils.getColor());
            CFontRenderer var19 = FontStorage.fr3;
            var66 = (float)(4 + Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT);
            var19.drawString(var2, 10.0F, var66, (new Color(255, 255, 255, var6)).getRGB());
         } else if (var3 == NotificationType.OK) {
            float var63 = width;
            float var69 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, var63, var69, (new Color(35, 35, 40, var6)).getRGB());
            var69 = height;
            Render2DUtils.drawSmoothRect(0.0F, 0.0F, 7.0F, var69, (new Color(51, 255, 0, var6)).getRGB());
            FontStorage.fr3.drawStringWithShadow(var1, 10.0F, 2.0F, RainbowUtils.getColor());
            CFontRenderer var20 = FontStorage.fr3;
            var69 = (float)(4 + Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT);
            var20.drawString(var2, 10.0F, var69, (new Color(255, 255, 255, var6)).getRGB());
         }
      }

      GL11.glPopMatrix();
      GlStateManager.disableTexture2D();
   }
   public static void show() {
      for(int var0 = 0; var0 < Names.size(); ++var0) {
         if ((Integer)Times.get(var0) != 230) {
            Times.set(var0, (Integer)Times.get(var0) + 1);
         } else {
            Names.remove(var0);
            Tests.remove(var0);
            Types.remove(var0);
            Times.remove(var0);
         }
      }

      height = 22.0F;

      for(int var5 = 0; var5 < Names.size(); ++var5) {
         String var1 = (String)Names.get(var5);
         String var2 = (String)Tests.get(var5);
         NotificationType var3 = (NotificationType)Types.get(var5);
         int var4 = (Integer)Times.get(var5);
         drawnotif(var5, var1, var2, var3, var4);
      }

   }

   static {
      
      Names = new ArrayList();
      Tests = new ArrayList();
      Types = new ArrayList();
      Times = new ArrayList();
      height = 30.0F;
      width = 100.0F;
   }
   

   
}
