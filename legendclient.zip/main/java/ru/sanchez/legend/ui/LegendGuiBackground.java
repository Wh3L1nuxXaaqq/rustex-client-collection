package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

 
public class LegendGuiBackground {
   public static void main(String var0) throws Exception {
      if ((SystemTray.isSupported()) != 0) {
         SystemTray var1 = SystemTray.getSystemTray();
         Image var2 = Toolkit.getDefaultToolkit().getImage("images/bor.png");
         TrayIcon var3 = new TrayIcon(var2);
         var1.add(var3);
         var3.displayMessage("Legend", var0, MessageType.INFO);
      }

   }
   

   

   
}
