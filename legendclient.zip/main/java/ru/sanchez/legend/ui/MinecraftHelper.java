package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.Packet;

 
public class MinecraftHelper {
    
   public static volatile MinecraftHelper INSTANCE;

   public Minecraft getMinecraft() {
      return Minecraft.getMinecraft();
   }

   public InventoryPlayer inventory() {
      return this.player().inventory;
   }

   public GameSettings mcSettings() {
      return INSTANCE.mc().gameSettings;
   }

   public void sendPacket(Packet var1) {
      this.player().connection.sendPacket(var1);
   }

   public EntityPlayerSP getLocalPlayer() {
      return INSTANCE.getMinecraft().player;
   }

   public GameSettings getGameSettings() {
      return INSTANCE.getMinecraft().gameSettings;
   }

   public PlayerControllerMP controller() {
      return INSTANCE.mc().playerController;
   }

   public Minecraft mc() {
      return Minecraft.getMinecraft();
   }

   public FontRenderer fontRenderer() {
      return INSTANCE.mc().fontRenderer;
   }

   public FontRenderer getFontRenderer() {
      return INSTANCE.getMinecraft().fontRenderer;
   }

   public WorldClient getWorld() {
      return INSTANCE.getMinecraft().world;
   }

   public WorldClient world() {
      return INSTANCE.mc().world;
   }

   public EntityPlayerSP player() {
      return INSTANCE.mc().player;
   }

   static {
      
      INSTANCE = new MinecraftHelper();
   }
   
}
