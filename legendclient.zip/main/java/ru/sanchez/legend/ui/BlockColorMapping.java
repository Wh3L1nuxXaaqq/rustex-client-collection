package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

 
public enum BlockColorMapping {
    
   CLOTH;

    
   public final IBlockState blockState;
    
   public int red;
    
   public int green;
    
   public int blue;
    
   public boolean trace;

   public BlockColorMapping(IBlockState var3) {
      this.blockState = var3;
   }
   public static BlockColorMapping getBlock(BlockPos var0) {
      IBlockState var1 = Wrapper.mc.world.getBlockState(var0);

      for(BlockColorMapping var5 : (BlockColorMapping[])BlockColorMapping.class.getDeclaringClass().getEnumConstants()) {
         if ((var5.blockState.equals(var1)) != 0) {
            return var5;
         }
      }

      return null;
   }

   static {
      
      CLOTH = new BlockColorMapping("CLOTH", 0, Blocks.TALLGRASS.getStateFromMeta(2));
   }
   

   
}
