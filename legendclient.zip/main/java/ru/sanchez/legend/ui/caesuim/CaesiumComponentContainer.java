package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;

 
public abstract class CaesiumComponentContainer {
    
   public final ArrayList<ICaesiumComponent> components = new ArrayList();

   public void add(ICaesiumComponent var1) {
      this.components.add(var1);
   }

   public void clearComponents() {
      this.components.clear();
   }

   public ArrayList<ICaesiumComponent> getComponents() {
      return this.components;
   }

   public abstract void addComponents();
   

   

   
}
