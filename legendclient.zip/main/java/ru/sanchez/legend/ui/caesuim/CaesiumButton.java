package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;

 
public class CaesiumButton implements ICaesiumComponent {
    
   public static int expandedID;
    
   public int id;
    
   public String text;
    
   public ArrayList<ActionListener> clickListeners = new ArrayList();
    
   public ArrayList<ICaesiumComponent> guiComponents = new ArrayList();
    
   public int width;
    
   public int textWidth;
    
   public int posX;
    
   public int posY;

   public CaesiumButton(String var1) {
      this.text = var1;
      this.textWidth = CaesiumScreen.fR.getStringWidth(var1);
      this.id = ++ClickGuiScreen2.compID;
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.posX = var1;
      this.posY = var2;
      this.width = var3;
      int var7 = this.getHeight();
      this.renderCaesium(var1, var2, var3, var7);
   }

   public void renderCaesium(int var1, int var2, int var3, int var4) {
      int var10002 = var1 + var3;
      CaesiumRenderUtils.drawRect(var1, var2, var10002 - 1, var2 + var4, CaesiumScreen.black100);
      int var5 = CaesiumScreen.fontColor;
      Legend var10000 = Legend.instance;
      if ((Legend.moduleManager.getModule(this.getText()).isToggled()) != 0) {
         var5 = RainbowUtils.getColor();
      }

      FontRenderer var6 = CaesiumScreen.fR;
      String var10001 = this.getText();
      var10002 = var1 + var3 / 2;
      int var10003 = CaesiumScreen.fR.getStringWidth(this.getText()) / 2;
      var6.drawStringWithShadow(var10001, (float)(var10002 - var10003), (float)(var2 + 2), var5);
   }

   public void mouseClicked(int var1, int var2, int var3) {
      if (CaesiumFrame.dragID == -1 && (CaesiumRenderUtils.isHovered(this.posX, this.posY, this.width, this.getHeight(), var1, var2)) != 0) {
         if (var3 == 1) {
            expandedID = expandedID != this.id ? this.id : -1;
         } else if (var3 == 0) {
            Iterator var4 = this.clickListeners.iterator();

            while((var4.hasNext()) != 0) {
               ActionListener var5 = (ActionListener)var4.next();
               var5.actionPerformed(new ActionEvent(this, this.id, "click", System.currentTimeMillis(), 0));
            }
         }
      }

      if (expandedID == this.id) {
         Iterator var6 = this.guiComponents.iterator();

         while((var6.hasNext()) != 0) {
            ICaesiumComponent var7 = (ICaesiumComponent)var6.next();
            var7.mouseClicked(var1, var2, var3);
         }
      }

   }

   public void keyTyped(int var1, char var2) {
      if (expandedID == this.id) {
         Iterator var3 = this.guiComponents.iterator();

         while((var3.hasNext()) != 0) {
            ICaesiumComponent var4 = (ICaesiumComponent)var3.next();
            var4.keyTyped(var1, var2);
         }
      }

   }

   public int getWidth() {
      return 5 + this.textWidth;
   }

   public int getHeight() {
      return CaesiumScreen.fR.FONT_HEIGHT + 3;
   }

   public boolean allowScroll() {
      return true;
   }

   public String getText() {
      return this.text;
   }

   public int getButtonID() {
      return this.id;
   }

   public ArrayList<ICaesiumComponent> getComponents() {
      return this.guiComponents;
   }

   public void addClickListener(ActionListener var1) {
      this.clickListeners.add(var1);
   }

   public void addExtendListener(CaesiumComponentContainer var1) {
      var1.addComponents();
      this.guiComponents.addAll(var1.getComponents());
   }

   static {
      
      expandedID = -1;
   }
   

   
}
