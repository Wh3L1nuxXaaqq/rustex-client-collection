package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class GuiBaseComponent {
    
   public int x;
    
   public int y;
    
   public ClickGuiScreen parent;
    
   public Setting setting;
    
   public String displayString;
    
   public Module module;

   public void keyTyped(char var1, int var2) {
   }

   public void drawScreen(int var1, int var2) {
   }

   public boolean isInside(int var1, int var2, double var3, double var5, double var7, double var9) {
      return (double)var1 >= var3 && (double)var1 <= var7 && (double)var2 >= var5 && (double)var2 <= var9;
   }

   public void mouseClicked(int var1, int var2, int var3) {
   }

   public void mouseReleased(int var1, int var2, int var3) {
   }
   

   
}
