package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

 
public class CaesiumButtonListener implements ActionListener {
    
   public CaesiumButton button;

   public CaesiumButtonListener(CaesiumButton var1) {
      this.button = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      Legend var10000 = Legend.instance;
      Module var2 = Legend.moduleManager.getModule(this.button.getText());
      var2.toggle();
   }
   

   
}
