package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

 
public class ClickGuiScreen2 extends GuiScreen {
    
   public static int compID;
    
   public ArrayList<ICaesiumFrame> frames = new ArrayList();
    
   public final FontRenderer fr;

   public ClickGuiScreen2() {
      this.fr = Minecraft.getMinecraft().fontRenderer;
      compID = 0;
   }

   public void addFrame(ICaesiumFrame var1) {
      if ((this.frames.contains(var1)) == 0) {
         this.frames.add(var1);
      }

   }

   public ArrayList<ICaesiumFrame> getFrames() {
      return this.frames;
   }

   public void initGui() {
      Iterator var1 = this.frames.iterator();

      while((var1.hasNext()) != 0) {
         ICaesiumFrame var2 = (ICaesiumFrame)var1.next();
         var2.initialize();
      }

   }

   public void mouseClicked(int var1, int var2, int var3) throws IOException {
      Iterator var4 = this.frames.iterator();

      while((var4.hasNext()) != 0) {
         ICaesiumFrame var5 = (ICaesiumFrame)var4.next();
         var5.mouseClicked(var1, var2, var3);
      }

   }

   public void keyTyped(char var1, int var2) throws IOException {
      super.keyTyped(var1, var2);
      Iterator var3 = this.frames.iterator();

      while((var3.hasNext()) != 0) {
         ICaesiumFrame var4 = (ICaesiumFrame)var3.next();
         var4.keyTyped(var2, var1);
      }

   }

   public void drawinfo(int var1, int var2) {
      short var3 = 600;
      short var4 = 280;
      int var5 = 0;
      FontRenderer var12 = this.fontRenderer;
      float var24 = (float)(var3 + this.fontRenderer.getStringWidth("Friends") / 2);
      int var10004 = this.fontRenderer.FONT_HEIGHT;
      var12.drawStringWithShadow(var10001, var24, (float)(var4 - var10004), RainbowUtils.getColor());
      double var13 = (double)var3;
      double var22 = (double)var4;
      double var25 = (double)(var3 + 100);
      double var10003 = (double)(var4 + FriendManager.FRIENDS.size() * this.fontRenderer.FONT_HEIGHT);
      Render2DUtils.drawRect(var13, var22, var25, var10003, (new Color(50, 50, 50, 190)).getRGB());
      Render2DUtils.drawNewRect((double)(var3 - 1), (double)var4, (double)var3, (double)(var4 + FriendManager.FRIENDS.size() * this.fontRenderer.FONT_HEIGHT), RainbowUtils.getColor());
      int var14 = var3 + 100;
      Render2DUtils.drawNewRect((double)(var14 - 1), (double)var4, (double)(var3 + 100), (double)(var4 + FriendManager.FRIENDS.size() * this.fontRenderer.FONT_HEIGHT), RainbowUtils.getColor());
      double var15 = (double)var3;
      Render2DUtils.drawGlow(var15, (double)(var4 - 1), (double)(var3 + 100), (double)var4, RainbowUtils.getColor(), (double)250.0F);
      var15 = (double)var3;
      int var23 = var4 + FriendManager.FRIENDS.size() * this.fontRenderer.FONT_HEIGHT;
      Render2DUtils.drawGlow(var15, (double)(var23 - 1), (double)(var3 + 100), (double)(var4 + FriendManager.FRIENDS.size() * this.fontRenderer.FONT_HEIGHT), RainbowUtils.getColor(), (double)250.0F);

      for(Iterator var6 = FriendManager.FRIENDS.iterator(); (var6.hasNext()) != 0; var5 += this.fontRenderer.FONT_HEIGHT) {
         String var7 = (String)var6.next();
         int var8 = 0 + var3;
         int var9 = 100 + var3;
         int var10 = var5 + var4;
         int var11 = var5 + this.fontRenderer.FONT_HEIGHT + var4;
         if (var1 > var8 && var1 < var9 && var2 > var10 && var2 < var11) {
            FontRenderer var18 = this.fontRenderer;
            int var27 = var3 + 50;
            int var29 = this.fontRenderer.getStringWidth(var7) / 2;
            var18.drawString(var7, var27 - var29, var5 + var4, RainbowUtils.getColor());
            if ((Mouse.isButtonDown(1)) != 0) {
               FriendManager.toggleFriend(var7);
               return;
            }
         } else {
            FontRenderer var17 = this.fontRenderer;
            int var26 = var3 + 50;
            int var28 = this.fontRenderer.getStringWidth(var7) / 2;
            var17.drawString(var7, var26 - var28, var5 + var4, Color.white.getRGB());
         }
      }

   }

   public void drawScreen(int var1, int var2, float var3) {
      new ScaledResolution(this.mc);
      Gui.drawRect(64, 556, 0, 524, (new Color(37, 37, 37, 255)).getRGB());
      Gui.drawRect(0, 525, 64, 527, RainbowUtils.getColor());
      this.mc.fontRenderer.drawString("ByDenger", 4, 529, CaesiumScreen.fontColor);
      Iterator var5 = this.frames.iterator();

      while((var5.hasNext()) != 0) {
         ICaesiumFrame var6 = (ICaesiumFrame)var5.next();
         var6.render(var1, var2);
         this.drawinfo(var1, var2);
      }

   }

   static {
      
      compID = 0;
   }
   

   
}
