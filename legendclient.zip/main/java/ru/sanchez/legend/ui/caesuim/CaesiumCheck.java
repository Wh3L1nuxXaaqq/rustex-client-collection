package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

 
public class CaesiumCheck implements ICaesiumComponent {
    
   public String text;
    
   public boolean toggled;
    
   public int posX;
    
   public int posY;
    
   public ArrayList<ActionListener> clickListeners = new ArrayList();

   public CaesiumCheck(String var1) {
      this.text = var1;
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.posX = var1;
      this.posY = var2;
      String var7 = CaesiumScreen.theme;
      byte var8 = -1;
      switch (var7.hashCode()) {
         case -2087928939:
            if ((var7.equals("Caesium")) != 0) {
               var8 = 0;
            }
         default:
            switch (var8) {
               case 0:
                  this.renderCaesium(var1, var2);
               default:
            }
      }
   }

   public void renderCaesium(int var1, int var2) {
      int var4 = var1 + 8;
      int var10 = var2 + 7;
      Render2DUtils.drawFilledCircle(var4, var10, 6.0F, new Color(RainbowUtils.getColor()), 6);
      if ((this.toggled) == 0) {
         var4 = var1 + 8;
         var10 = var2 + 7;
         Render2DUtils.drawFilledCircle(var4, var10, 5.0F, new Color(CaesiumScreen.grey40_240), 6);
      }

      CaesiumScreen.fR.drawStringWithShadow(this.text, (float)(var1 + 17), (float)(var2 + 3), CaesiumScreen.fontColor);
   }

   public void mouseClicked(int var1, int var2, int var3) {
      int var4 = CaesiumScreen.fR.getStringWidth(this.text) + 10;
      if ((CaesiumRenderUtils.isHovered(this.posX, this.posY + 2, var4, this.getHeight(), var1, var2)) != 0) {
         this.toggled = (boolean)((this.toggled) == 0 ? 1 : 0);
         Iterator var5 = this.clickListeners.iterator();

         while((var5.hasNext()) != 0) {
            ActionListener var6 = (ActionListener)var5.next();
            var6.actionPerformed(new ActionEvent(this, this.hashCode(), "click", System.currentTimeMillis(), 0));
         }
      }

   }

   public void keyTyped(int var1, char var2) {
   }

   public int getWidth() {
      return CaesiumScreen.fR.getStringWidth(this.text) + 20;
   }

   public int getHeight() {
      return CaesiumScreen.fR.FONT_HEIGHT + 5;
   }

   public boolean allowScroll() {
      return true;
   }

   public boolean isToggled() {
      return (boolean)(this.toggled);
   }

   public void setToggled(boolean var1) {
      this.toggled = (boolean)(var1);
   }

   public void addClickListener(ActionListener var1) {
      this.clickListeners.add(var1);
   }
   

   

   
}
