package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;

 
public class GuiScreen3Check extends GuiScreen3Component {

   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if ((this.isInside(var1, var2, (double)(this.parent.posX + this.x), (double)(this.parent.posY + this.y), (double)(this.parent.posX + this.x) + (double)10.0F, (double)(this.parent.posY + this.y + 4))) != 0 && var3 == 0) {
         this.setting.setValBoolean((this.setting.getValBoolean()) == 0);
      }

   }

   public GuiScreen3Check(int var1, int var2, ClickGuiScreen3 var3, Module var4, Setting var5) {
      this.x = var1;
      this.y = var2;
      this.parent = var3;
      this.module = var4;
      this.setting = var5;
   }

   public void drawScreen(int var1, int var2) {
      super.drawScreen(var1, var2);
      int var3 = 0;
      if ((this.setting.getValBoolean()) != 0) {
         Render3DUtils.drawRect((float)(this.parent.posX + this.x), (float)(this.parent.posY + this.y + var3), (float)(this.parent.posX + this.x + 10), (float)(this.parent.posY + this.y + 4 + var3), RainbowUtils.getColor());
         var3 += 2;
         int var8 = this.parent.posX + this.x + 8;
         int var19 = this.parent.posY + this.y + var3;
         Render2DUtils.drawFilledCircle(var8, var19, 4.0F, new Color(200, 200, 200), 360);
      } else {
         float var9 = (float)(this.parent.posX + this.x);
         float var20 = (float)(this.parent.posY + this.y + var3);
         float var25 = (float)(this.parent.posX + this.x + 10);
         float var10003 = (float)(this.parent.posY + this.y + 4 + var3);
         Render3DUtils.drawRect(var9, var20, var25, var10003, (new Color(200, 200, 200)).getRGB());
         var3 += 2;
         int var10 = this.parent.posX + this.x + 2;
         int var21 = this.parent.posY + this.y + var3;
         Render2DUtils.drawFilledCircle(var10, var21, 4.0F, new Color(200, 200, 200), 360);
      }

      double var11 = (double)var3;
      double var22 = (double)FontStorage.fr3.getStringHeight(this.setting.getName()) / (double)2.0F;
      var3 = (int)(var11 - var22);
      FontStorage.fr3.drawString(this.setting.getName(), (float)(this.parent.posX + this.x + 15), (float)(this.parent.posY + this.y + var3), -1);
      int var12 = var3 + FontStorage.fr3.getStringHeight(this.setting.getName());
   }
   

   

   
}
