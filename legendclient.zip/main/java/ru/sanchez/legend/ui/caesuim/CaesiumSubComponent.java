package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

 
public class CaesiumSubComponent extends CaesiumComponentContainer {
    
   public CaesiumButton button;

   public CaesiumSubComponent(CaesiumButton var1) {
      this.button = var1;
   }

   public void addComponents() {
      this.add(new CaesiumLabel("Settings >"));
      Legend var16 = Legend.instance;
      Module var1 = Legend.moduleManager.getModule(this.button.getText());
      if (Legend.instance.settingsManager.getSettingsByMod(var1) != null) {
         Iterator var2 = Legend.instance.settingsManager.getSettingsByMod(var1).iterator();

         while((var2.hasNext()) != 0) {
            Setting var3 = (Setting)var2.next();
            if ((var3.isSlider()) != 0) {
               CaesiumSlider var4 = new CaesiumSlider(var3.getName(), (float)var3.getMin(), (float)var3.getMax(), (float)var3.getValDouble(), (var3.onlyInt()) != 0 ? 0 : 2);
               var4.addValueListener(new CaesiumValueListener(this, var3) {
                   
                  public final Setting val$set;
                   
                  public final CaesiumSubComponent this$0;

                  public {
                     this.this$0 = var1;
                     this.val$set = var2;
                  }

                  public void valueUpdated(float var1) {
                     this.val$set.setValDouble((double)var1);
                  }

                  public void valueChanged(float var1) {
                     this.val$set.setValDouble((double)var1);
                     (new Thread(() -> {
                     })).start();
                  }
                  

                  
               });
               this.add(var4);
            }

            if ((var3.isCheck()) != 0) {
               CaesiumCheck var7 = new CaesiumCheck(var3.getName());
               var7.setToggled((boolean)(var3.getValBoolean()));
               var7.addClickListener(new ActionListener(this, var3, var7) {
                   
                  public final Setting val$set;
                   
                  public final CaesiumCheck val$toggleButton;
                   
                  public final CaesiumSubComponent this$0;

                  public {
                     this.this$0 = var1;
                     this.val$set = var2;
                     this.val$toggleButton = var3;
                  }

                  public void actionPerformed(ActionEvent var1) {
                     this.val$set.setValBoolean((boolean)(this.val$toggleButton.isToggled()));
                  }
                  

                  

                  
               });
               this.add(var7);
            }

            if ((var3.isCombo()) != 0) {
               CaesiumCombo var8 = new CaesiumCombo(var3);
               var8.addComboListener(new CaesiumComboListener(this) {
                   
                  public final CaesiumSubComponent this$0;

                  public {
                     this.this$0 = var1;
                  }

                  public void comboChanged(String var1) {
                  }
                  

                  
               });
               this.add(var8);
            }
         }
      }
      CaesiumKeybind var5 = new CaesiumKeybind("KeyBind", var1.getKey());
      var5.addKeyListener(new CaesiumKeyListener(this, var1) {
          
         public final Module val$m;
          
         public final CaesiumSubComponent this$0;

         public {
            this.this$0 = var1;
            this.val$m = var2;
         }

         public void keyChanged(int var1) {
            this.val$m.setKey(var1);
            (new Thread(() -> {
            })).start();
         }
         

         
      });
      this.add(var5);
      CaesiumCheck var6 = new CaesiumCheck("Visable");
      var6.setToggled((boolean)(var1.visible));
      var6.addClickListener(new ActionListener(this, var1, var6) {
          
         public final Module val$m;
          
         public final CaesiumCheck val$toggleButton;
          
         public final CaesiumSubComponent this$0;

         public {
            this.this$0 = var1;
            this.val$m = var2;
            this.val$toggleButton = var3;
         }

         public void actionPerformed(ActionEvent var1) {
            this.val$m.visible = (boolean)(this.val$toggleButton.isToggled());
         }
         

         

         
      });
      this.add(var6);
   }
   

   

   
}
