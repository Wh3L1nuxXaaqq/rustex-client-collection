package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;

 
public class CaesiumCombo implements ICaesiumComponent {
    
   public Setting setting;
    
   public boolean extended;
    
   public int height;
    
   public int posX;
    
   public int posY;
    
   public int width;
    
   public ArrayList<CaesiumComboListener> comboListeners = new ArrayList();

   public CaesiumCombo(Setting var1) {
      this.setting = var1;
   }

   public void addComboListener(CaesiumComboListener var1) {
      this.comboListeners.add(var1);
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.posX = var1;
      this.posY = var2;
      this.width = var3;
      String var7 = CaesiumScreen.theme;
      byte var8 = -1;
      switch (var7.hashCode()) {
         case -2087928939:
            if ((var7.equals("Caesi!\u000b{")) != 0) {
               var8 = 0;
            }
         default:
            switch (var8) {
               case 0:
                  this.renderCaesium();
               default:
            }
      }
   }

   public void renderCaesium() {
      if (this.extended) {
         CaesiumRenderUtils.drawRect(this.posX, this.posY, this.posX + this.width, this.posY + CaesiumScreen.fR.FONT_HEIGHT + 2, CaesiumScreen.grey40_240);
         CaesiumRenderUtils.drawHorizontalLine(this.posX, this.posX + this.width, this.posY, CaesiumScreen.black195);
         int var7 = this.posX;
         int var21 = this.posX + this.width;
         int var28 = this.posY + CaesiumScreen.fR.FONT_HEIGHT + 2;
         CaesiumRenderUtils.drawHorizontalLine(var7, var21, var28, (new Color(0, 0, 0, 150)).getRGB());
         FontRenderer var8 = CaesiumScreen.fR;
         String var22 = this.setting.getName() + "  -";
         var28 = this.posX + this.width / 2;
         FontRenderer var10003 = CaesiumScreen.fR;
         int var31 = var10003.getStringWidth(this.setting.getName() + "  -") / 2;
         var8.drawStringWithShadow(var22, (float)(var28 - var31), (float)(this.posY + 2), CaesiumScreen.fontColor);
         int var1 = CaesiumScreen.fR.FONT_HEIGHT + 5;

         for(Iterator var2 = this.setting.getOptions().iterator(); (var2.hasNext()) != 0; var1 += CaesiumScreen.fR.FONT_HEIGHT + 2) {
            String var3 = (String)var2.next();
            if ((this.setting.getValString().equalsIgnoreCase(var3)) != 0) {
               CaesiumScreen.fR.drawStringWithShadow(var3, (float)(this.posX + 10), (float)(this.posY + var1), RainbowUtils.getColor());
            } else {
               CaesiumScreen.fR.drawStringWithShadow(var3, (float)(this.posX + 5), (float)(this.posY + var1), CaesiumScreen.fontColor);
            }
         }

         this.height = var1 + 2;
      } else {
         CaesiumRenderUtils.drawRect(this.posX, this.posY, this.posX + this.width, this.posY + CaesiumScreen.fR.FONT_HEIGHT + 2, CaesiumScreen.grey40_240);
         CaesiumRenderUtils.drawHorizontalLine(this.posX, this.posX + this.width, this.posY, CaesiumScreen.black195);
         CaesiumRenderUtils.drawHorizontalLine(this.posX, this.posX + this.width, this.posY + CaesiumScreen.fR.FONT_HEIGHT + 2, CaesiumScreen.black195);
         FontRenderer var9 = CaesiumScreen.fR;
         var10001 = this.setting.getName() + "  +";
         int var30 = this.posX + this.width / 2;
         FontRenderer var32 = CaesiumScreen.fR;
         int var33 = var32.getStringWidth(this.setting.getName() + "  +") / 2;
         var9.drawStringWithShadow(var10001, (float)(var30 - var33), (float)(this.posY + 2), CaesiumScreen.fontColor);
         this.height = CaesiumScreen.fR.FONT_HEIGHT + 4;
      }

   }

   public void mouseClicked(int var1, int var2, int var3) {
      if ((CaesiumRenderUtils.isHovered(this.posX, this.posY, this.width, CaesiumScreen.fR.FONT_HEIGHT + 2, var1, var2)) != 0) {
         this.extended = (boolean)((this.extended) == 0 ? 1 : 0);
      }

      if (this.extended && (CaesiumRenderUtils.isHovered(this.posX, this.posY + CaesiumScreen.fR.FONT_HEIGHT + 2, this.width, (CaesiumScreen.fR.FONT_HEIGHT + 2) * this.setting.getOptions().size(), var1, var2)) != 0 && var3 == 0) {
         int var4 = CaesiumScreen.fR.FONT_HEIGHT + 2;

         for(int var5 = 1; var5 <= this.setting.getOptions().size() + 1; ++var5) {
            if ((CaesiumRenderUtils.isHovered(this.posX, this.posY + var4 * var5, this.width, var4 * var5, var1, var2)) != 0) {
               Setting var10000 = this.setting;
               ArrayList var10001 = this.setting.getOptions();
               var10000.setValString((String)var10001.get(var5 - 1));
            }
         }

         Iterator var7 = this.comboListeners.iterator();

         while((var7.hasNext()) != 0) {
            CaesiumComboListener var6 = (CaesiumComboListener)var7.next();
            var6.comboChanged(this.setting.getValString());
         }
      }

   }

   public void keyTyped(int var1, char var2) {
   }

   public int getWidth() {
      return 0;
   }

   public int getHeight() {
      return this.height;
   }

   public boolean allowScroll() {
      return true;
   }

   public Setting getSetting() {
      return this.setting;
   }

   public void setSetting(Setting var1) {
      this.setting = var1;
   }
   

   

   
}
