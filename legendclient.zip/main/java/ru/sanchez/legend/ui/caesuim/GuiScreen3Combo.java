package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;

 
public class GuiScreen3Combo extends GuiScreen3Component {

   public GuiScreen3Combo(int var1, int var2, ClickGuiScreen3 var3, Module var4, Setting var5) {
      this.x = var1;
      this.y = var2;
      this.parent = var3;
      this.module = var4;
      this.setting = var5;
   }

   public void drawScreen(int var1, int var2) {
      super.drawScreen(var1, var2);
      int var3 = 0;
      if (this.parent.selectedCombo != null) {
         var3 = (this.parent.selectedCombo.equals(this));
      }

      CFontRenderer var8 = FontStorage.fr3;
      int var4 = var8.getStringWidth(this.setting.getName() + (var3 != 0 ? " <" : " >"));
      var8 = FontStorage.fr3;
      int var5 = var8.getStringHeight(this.setting.getName() + (var3 != 0 ? " <" : " >"));
      double var10 = (double)(this.parent.posX + this.x);
      double var21 = (double)(this.parent.posY + this.y);
      double var25 = (double)(this.parent.posX + this.x + var4 * 2);
      double var10003 = (double)(this.parent.posY + this.y + var5 + 4);
      Render2DUtils.drawRect(var10, var21, var25, var10003, (new Color(59, 59, 59)).getRGB());
      CFontRenderer var11 = FontStorage.fr3;
      var11.drawString(this.setting.getName() + (var3 != 0 ? " <" : " >"), (double)(this.parent.posX + this.x) + (double)var4 / (double)2.0F, (double)(this.parent.posY + this.y + 2), -1);
   }

   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      CFontRenderer var7 = FontStorage.fr3;
      int var4 = var7.getStringWidth(this.setting.getName() + " >");
      var7 = FontStorage.fr3;
      int var5 = var7.getStringHeight(this.setting.getName() + " >");
      if ((this.isInside(var1, var2, (double)(this.parent.posX + this.x), (double)(this.parent.posY + this.y), (double)(this.parent.posX + this.x + var4 * 2), (double)(this.parent.posY + this.y + var5 + 4))) != 0 && var3 == 0) {
         if (this.parent.selectedCombo != null) {
            if ((this.parent.selectedCombo.equals(this)) != 0) {
               this.parent.selectedCombo = null;
            } else {
               this.parent.selectedCombo = this;
            }
         } else {
            this.parent.selectedCombo = this;
         }
      }

   }
   

   

   
}
