package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.gui.FontRenderer;

 
public class CaesiumLabel implements ICaesiumComponent {
    
   public String text;

   public CaesiumLabel(String var1) {
      this.text = var1;
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      FontRenderer var10000 = CaesiumScreen.fR;
      String var10001 = this.text;
      int var10002 = var1 + var3 / 2;
      int var10003 = CaesiumScreen.fR.getStringWidth(this.text) / 2;
      var10000.drawStringWithShadow(var10001, (float)(var10002 - var10003), (float)(var2 + 2), CaesiumScreen.fontColor);
   }

   public void mouseClicked(int var1, int var2, int var3) {
   }

   public void keyTyped(int var1, char var2) {
   }

   public int getWidth() {
      return CaesiumScreen.fR.getStringWidth(this.text) + 4;
   }

   public int getHeight() {
      return CaesiumScreen.fR.FONT_HEIGHT + 2;
   }

   public boolean allowScroll() {
      return true;
   }
   

   
}
