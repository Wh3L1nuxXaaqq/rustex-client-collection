package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

 
public class CaesiumSlider implements ICaesiumComponent {
    
   public static int dragId;
    
   public int round;
    
   public int id;
    
   public int width;
    
   public int posX;
    
   public int posY;
    
   public float min;
    
   public float max;
    
   public float current;
    
   public double c;
    
   public boolean wasSliding;
    
   public boolean hovered;
    
   public String text;
    
   public ArrayList<CaesiumValueListener> valueListeners = new ArrayList();

   public CaesiumSlider(String var1, float var2, float var3, float var4, int var5) {
      this.text = var1;
      this.min = var2;
      this.max = var3;
      this.current = var4;
      this.c = (double)(var4 / var3);
      this.round = var5;
      this.id = ++CaesiumScreen.compID;
   }

   public void addValueListener(CaesiumValueListener var1) {
      this.valueListeners.add(var1);
   }
   public static float clamp(float var0, float var1, float var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.posX = var1;
      this.posY = var2;
      this.width = var3;
      this.hovered = (boolean)(CaesiumRenderUtils.isHovered(var1, var2, var3, this.getHeight(), var4, var5));
      if (this.hovered && var6 != 0) {
         double var19;
         if (this.min < 0.0F) {
            float var10000 = this.min;
            float var10001 = this.max;
            var19 = (double)Math.abs(var10000 - var10001);
         } else {
            float var20 = this.max;
            float var25 = this.min;
            var19 = (double)(var20 - var25);
         }

         double var7 = var19;
         double var9 = (double)(var6 / 15);
         this.current = this.round == 0 ? (float)((int)clamp((float)((double)this.current + var9), this.min, this.max)) : clamp((float)((double)this.current + var9 * (var7 / (double)100.0F)), this.min, this.max);
      }

      if ((Mouse.isButtonDown(0)) != 0 && (dragId == this.id || dragId == -1) && this.hovered) {
         if (var4 < var1 + 2) {
            this.current = this.min;
         } else if (var4 > var1 + var3) {
            this.current = this.max;
         } else {
            float var21 = this.max;
            float var26 = this.min;
            double var13 = (double)(var21 - var26);
            double var22 = (double)this.min;
            double var15 = var22 + (double)clamp((float)((double)(var4 - var1 + 3) / (double)var3), 0.0F, 1.0F) * var13;
            this.current = this.round == 0 ? (float)((int)var15) : (float)var15;
         }

         dragId = this.id;
         Iterator var16 = this.valueListeners.iterator();

         while((var16.hasNext()) != 0) {
            CaesiumValueListener var18 = (CaesiumValueListener)var16.next();
            var18.valueUpdated(this.current);
         }

         this.wasSliding = true;
      } else if ((Mouse.isButtonDown(0)) == 0 && this.wasSliding) {
         Iterator var14 = this.valueListeners.iterator();

         while((var14.hasNext()) != 0) {
            CaesiumValueListener var10 = (CaesiumValueListener)var14.next();
            var10.valueChanged(this.current);
         }

         dragId = -1;
         this.wasSliding = false;
      }

      float var23 = this.current;
      float var27 = this.min;
      var23 -= var27;
      var27 = this.max;
      float var10002 = this.min;
      double var17 = (double)(var23 / (var27 - var10002));
      String var11 = CaesiumScreen.theme;
      byte var12 = -1;
      switch (var11.hashCode()) {
         case -2087928939:
            if ((var11.equals("Caesium")) != 0) {
               var12 = 0;
            }
         default:
            switch (var12) {
               case 0:
                  this.renderCaesium(var17);
               default:
            }
      }
   }

   public void renderCaesium(double var1) {
      if (this.round == 0) {
         var10000 = "" + Math.round(this.current);
      } else {
         var10000 = "" + MathRoundUtils.round(this.current, this.round);
      }

      String var3 = var10000;
      Color var4 = new Color(RainbowUtils.getColor());
      FontRenderer var9 = CaesiumScreen.fR;
      var9.drawStringWithShadow(this.text + ":", (float)(this.posX + 3), (float)(this.posY + 3), CaesiumScreen.fontColor);
      var9 = CaesiumScreen.fR;
      int var25 = this.posX + this.width;
      int var10003 = CaesiumScreen.fR.getStringWidth(var3);
      var25 -= var10003;
      var9.drawStringWithShadow(var3, (float)(var25 - 3), (float)(this.posY + 3), CaesiumScreen.fontColor);
      int var11 = this.posX;
      int var20 = this.posY + CaesiumScreen.fR.FONT_HEIGHT + 3;
      var25 = this.posX + this.width;
      Gui.drawRect(var11, var20, var25 - 2, this.posY + CaesiumScreen.fR.FONT_HEIGHT + 5, Color.black.getRGB());
      float var12 = (float)this.posX;
      float var21 = (float)(this.posY + CaesiumScreen.fR.FONT_HEIGHT + 3);
      double var28 = var1 * (double)this.width;
      Render2DUtils.drawVGradientRect(var12, var21, (float)((int)(var28 - (double)2.0F) + this.posX), (float)(this.posY + CaesiumScreen.fR.FONT_HEIGHT + 5), var4.darker().getRGB(), var4.brighter().getRGB());
   }

   public void mouseClicked(int var1, int var2, int var3) {
   }

   public void keyTyped(int var1, char var2) {
   }

   public int getWidth() {
      FontRenderer var1 = CaesiumScreen.fR;
      return var1.getStringWidth(this.text + (this.round == 0 ? (float)Math.round(this.current) : MathRoundUtils.round(this.current, this.round))) + 68;
   }

   public int getHeight() {
      return CaesiumScreen.fR.FONT_HEIGHT + 6;
   }

   public boolean allowScroll() {
      return (this.hovered) == 0;
   }

   static {
      
      dragId = -1;
   }
   

   
}
