package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;

 
public class GuiScreen3Button extends GuiScreen3Component {
    
   public final int string_width;
    
   public final int string_height;
    
   public final String text;

   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if ((this.isInside(var1, var2, (double)(this.parent.posX + this.x), (double)(this.parent.posY + this.y), (double)(this.parent.posX + this.x + this.string_width * 2), (double)(this.parent.posY + this.y + this.string_height + 4))) != 0 && var3 == 0) {
         try {
            FontStorage.fr3.drawString(this.text, (double)(this.parent.posX + this.x) + (double)this.string_width / (double)2.0F, (double)(this.parent.posY + this.y + 2), RainbowUtils.getColor());
            this.setting.getValMethod().invoke(this.module);
         } catch (Exception var5) {
            var5.printStackTrace();
         }
      }

   }

   public GuiScreen3Button(int var1, int var2, ClickGuiScreen3 var3, Module var4, Setting var5) {
      this.x = var1;
      this.y = var2;
      this.parent = var3;
      this.module = var4;
      this.setting = var5;
      this.text = this.setting.getName();
      this.string_width = FontStorage.fr3.getStringWidth(this.text);
      this.string_height = FontStorage.fr3.getStringHeight(this.text);
   }

   public void drawScreen(int var1, int var2) {
      super.drawScreen(var1, var2);
      double var3 = (double)(this.parent.posX + this.x);
      double var5 = (double)(this.parent.posY + this.y);
      double var6 = (double)(this.parent.posX + this.x + this.string_width * 2);
      double var10003 = (double)(this.parent.posY + this.y + this.string_height + 4);
      Render2DUtils.drawRect(var3, var5, var6, var10003, (new Color(59, 59, 59)).getRGB());
      FontStorage.fr3.drawString(this.text, (double)(this.parent.posX + this.x) + (double)this.string_width / (double)2.0F, (double)(this.parent.posY + this.y + 2), -1);
   }
   

   

   
}
