package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.gui.Gui;

 
public final class CaesiumRenderUtils {
   public static void drawRect(int var0, int var1, int var2, int var3, int var4) {
      Gui.drawRect(var0, var1, var2, var3, var4);
   }
   public static void drawHorizontalLine(int var0, int var1, int var2, int var3) {
      if (var1 < var0) {
         int var4 = var0;
         var0 = var1;
         var1 = var4;
      }

      drawRect(var0, var2, var1 + 1, var2 + 1, var3);
   }
   public static void drawTrapezoid(int var0, int var1, int var2, int var3, int var4, int var5) {
      int var10000 = var2 - var3;
      int var6 = var10000 / (var4 - 1) / 2;

      for(int var7 = 0; var7 < var4; ++var7) {
         var10000 = var0 + var6 * var7;
         int var10002 = var6 * var7;
         int var10001 = var2 - var10002;
         drawHorizontalLine(var10000, var10001, var1 - var7, var5);
      }

   }
   public static void drawVerticalLine(int var0, int var1, int var2, int var3) {
      if (var2 < var1) {
         int var4 = var1;
         var1 = var2;
         var2 = var4;
      }

      drawRect(var0, var1 + 1, var0 + 1, var2, var3);
   }
   public static boolean isHovered(int var0, int var1, int var2, int var3, int var4, int var5) {
      return var4 >= var0 && var4 <= var0 + var2 && var5 >= var1 && var5 < var1 + var3;
   }
   

   
}
