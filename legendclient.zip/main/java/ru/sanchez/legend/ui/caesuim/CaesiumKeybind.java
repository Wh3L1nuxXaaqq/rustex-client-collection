package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.input.Keyboard;

 
public class CaesiumKeybind implements ICaesiumComponent {
    
   public boolean wasChanged;
    
   public boolean allowChange;
    
   public int key;
    
   public int posX;
    
   public int posY;
    
   public int width;
    
   public String text;
    
   public ArrayList<CaesiumKeyListener> keylisteners = new ArrayList();

   public CaesiumKeybind(String var1, int var2) {
      this.text = var1;
      this.key = var2;
      if (var2 < 0) {
         this.key = 0;
      }

   }

   public void addKeyListener(CaesiumKeyListener var1) {
      this.keylisteners.add(var1);
   }

   public void render(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.posX = var1;
      this.posY = var2;
      this.width = var3;
      String var7 = CaesiumScreen.theme;
      byte var8 = -1;
      switch (var7.hashCode()) {
         case -2087928939:
            if ((var7.equals("Caesium")) != 0) {
               var8 = 0;
            }
         default:
            switch (var8) {
               case 0:
                  this.renderCaesium(var1, var2);
               default:
            }
      }
   }

   public void renderCaesium(int var1, int var2) {
      String var3 = Keyboard.getKeyName(this.key);
      this.wasChanged = (boolean)(this.allowChange ? ((this.wasChanged) == 0 ? 1 : 0) : 1);
      FontRenderer var10000 = CaesiumScreen.fR;
      var10000.drawStringWithShadow(this.text + ":", (float)(var1 + 3), (float)(var2 + 3), CaesiumScreen.fontColor);
      if (this.wasChanged) {
         var10000 = CaesiumScreen.fR;
         int var8 = var1 + this.width;
         int var10003 = CaesiumScreen.fR.getStringWidth(var3);
         var8 -= var10003;
         var10000.drawStringWithShadow(var3, (float)(var8 - 3), (float)(var2 + 3), CaesiumScreen.fontColor);
      } else {
         var10000 = CaesiumScreen.fR;
         int var10 = var1 + this.width;
         int var12 = CaesiumScreen.fR.getStringWidth(var3);
         var10 -= var12;
         var10000.drawString(var3, var10 - 3, var2 + 3, CaesiumScreen.fontColor);
      }

   }

   public void mouseClicked(int var1, int var2, int var3) {
      String var4 = Keyboard.getKeyName(this.key);
      int var5 = CaesiumScreen.fR.getStringWidth(this.text);
      this.allowChange = (boolean)(CaesiumRenderUtils.isHovered(this.posX, this.posY, this.width, 11, var1, var2));
   }

   public void keyTyped(int var1, char var2) {
      if (this.allowChange) {
         Iterator var3 = this.keylisteners.iterator();

         while((var3.hasNext()) != 0) {
            CaesiumKeyListener var4 = (CaesiumKeyListener)var3.next();
            var4.keyChanged(var1);
         }

         this.key = var1;
         this.allowChange = false;
      }

   }

   public int getWidth() {
      FontRenderer var10000 = CaesiumScreen.fR;
      return var10000.getStringWidth(this.text + Keyboard.getKeyName(this.key)) + 15;
   }

   public int getHeight() {
      return CaesiumScreen.fR.FONT_HEIGHT + 4;
   }

   public boolean allowScroll() {
      return true;
   }
   

   

   
}
