package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import org.lwjgl.input.Keyboard;

 
public class GuiScreen3Keybind extends GuiScreen3Component {
    
   public boolean binding;
    
   public int string_width;
    
   public int string_height;

   public GuiScreen3Keybind(int var1, int var2, ClickGuiScreen3 var3, Module var4) {
      this.x = var1;
      this.y = var2;
      this.parent = var3;
      this.module = var4;
   }

   public void keyTyped(char var1, int var2) {
      super.keyTyped(var1, var2);
   }

   public void setBinding(boolean var1) {
      this.binding = (boolean)(var1);
   }

   public void drawScreen(int var1, int var2) {
      super.drawScreen(var1, var2);
      int var3 = this.parent.posX + this.x;
      int var4 = this.parent.posY + this.y;
      String var5 = "KeyBind: " + Keyboard.getKeyName(this.module.getKey());
      if (this.binding) {
         FontStorage.fr3.drawString(var5, (float)var3, (float)var4, -1);
      } else {
         FontStorage.fr3.drawString(var5, (float)var3, (float)var4, -1);
      }

      this.string_width = FontStorage.fr3.getStringWidth(var5);
      this.string_height = FontStorage.fr3.getStringHeight(var5);
      if (this.binding && Keyboard.getEventKey() != 0 && (Keyboard.getEventKeyState()) != 0) {
         this.module.setKey(Keyboard.getEventKey());
         this.binding = false;
      }

   }

   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if ((this.isInside(var1, var2, (double)(this.parent.posX + this.x), (double)(this.parent.posY + this.y), (double)(this.parent.posX + this.x + this.string_width), (double)(this.parent.posY + this.y + this.string_height))) != 0) {
         if ((this.binding) == 0) {
            if (var3 == 0) {
               this.setBinding(true);
            }
         } else {
            if (var3 == 0) {
               this.setBinding(false);
            }

            if (var3 == 1) {
               this.module.setKey(0);
               this.setBinding(false);
            }
         }
      }

   }
   

   

   
}
