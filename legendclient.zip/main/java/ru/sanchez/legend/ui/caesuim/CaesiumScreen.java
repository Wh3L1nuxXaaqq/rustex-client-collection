package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

 
public class CaesiumScreen extends ClickGuiScreen2 {
    
   public static HashMap<String, CaesiumFramePos> framePositions;
    
   public static FontRenderer fR;
    
   public static String theme;
    
   public static int FRAME_WIDTH;
    
   public static int color;
    
   public static int fontColor;
    
   public static int grey40_240;
    
   public static int black195;
    
   public static int black100;

   public CaesiumScreen(String var1, int var2) {
      theme = var1;
   }

   public void ref(Category var1, int var2) {
      CaesiumFrame var3 = new CaesiumFrame(var1.name(), var2, 50, true);
      Legend var9 = Legend.instance;
      Iterator var4 = Legend.moduleManager.modules.iterator();

      while((var4.hasNext()) != 0) {
         Module var5 = (Module)var4.next();
         if (var1 == var5.getCategory()) {
            CaesiumButton var6 = new CaesiumButton(var5.getName());
            var6.addClickListener(new CaesiumButtonListener(var6));
            var6.addExtendListener(new CaesiumSubComponent(var6));
            var3.addButton(var6);
         }
      }

      this.addFrame(var3);
   }

   public void initGui() {
      int var1 = 25;
      this.ref(Category.COMBAT, var1);
      var1 += 135;
      this.ref(Category.MOVEMENT, var1);
      var1 += 135;
      this.ref(Category.RENDER, var1);
      var1 += 135;
      this.ref(Category.OUTHER, var1);
      var1 += 135;
      this.ref(Category.HUD, var1);
      var1 += 135;
      this.ref(Category.EXPLOIT, var1);
      super.initGui();
   }

   public void onGuiClosed() {
      if ((this.getFrames().isEmpty()) == 0) {
         Iterator var1 = this.getFrames().iterator();

         while((var1.hasNext()) != 0) {
            ICaesiumFrame var2 = (ICaesiumFrame)var1.next();
            CaesiumFrame var3 = (CaesiumFrame)var2;
            HashMap var4 = framePositions;
            var10001 = var3.getTitle();
            var4.put(var10001, new CaesiumFramePos(var3.getPosX(), var3.getPosY(), (boolean)(var3.isExpaned())));
         }
      }

   }

   static {
      
      framePositions = new HashMap();
      fR = Minecraft.getMinecraft().fontRenderer;
      FRAME_WIDTH = 100;
      color = RainbowUtils.getColor();
      fontColor = Color.white.getRGB();
      grey40_240 = (new Color(40, 40, 40, 140)).getRGB();
      black195 = (new Color(0, 0, 0, 195)).getRGB();
      black100 = (new Color(0, 0, 0, 100)).getRGB();
   }
   

   
}
