package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

 
public class ClickGuiScreen extends GuiScreen {
    
   public int x;
    
   public int y;
    
   public int width;
    
   public int height;
    
   public boolean dragging;
    
   public int dragX;
    
   public int dragY;

   public void initGui() {
      super.initGui();
      int var10001 = this.getScaledRes().getScaledWidth() / 2;
      this.x = var10001 - 150;
      var10001 = this.getScaledRes().getScaledHeight() / 2;
      this.y = var10001 - 100;
   }

   public void drawScreen(int var1, int var2, float var3) {
      super.drawScreen(var1, var2, var3);
      ScaledResolution var4 = this.getScaledRes();
      if (this.dragging) {
         int var8 = this.dragX;
         this.x = var1 - var8;
         var8 = this.dragY;
         this.y = var2 - var8;
      }

      this.width = this.x + 228;
      this.height = this.y + 150;
      int var10000 = this.x;
      int var7 = this.y;
      int var10 = this.width;
      int var10003 = this.height;
      CaesiumRenderUtils.drawRect(var10000, var7, var10, var10003, (new Color(45, 45, 45, 249)).getRGB());
   }

   public void mouseClicked(int var1, int var2, int var3) throws IOException {
      super.mouseClicked(var1, var2, var3);
   }

   public void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
   }

   public ScaledResolution getScaledRes() {
      return new ScaledResolution(Minecraft.getMinecraft());
   }
   

   

   
}
