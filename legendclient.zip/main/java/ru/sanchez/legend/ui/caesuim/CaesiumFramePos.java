package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class CaesiumFramePos {
    
   public int posX;
    
   public int posY;
    
   public boolean isExpanded;

   public CaesiumFramePos(int var1, int var2, boolean var3) {
      this.posX = var1;
      this.posY = var2;
      this.isExpanded = (boolean)(var3);
   }

   public int getPosX() {
      return this.posX;
   }

   public void setPosX(int var1) {
      this.posX = var1;
   }

   public int getPosY() {
      return this.posY;
   }

   public void setPosY(int var1) {
      this.posY = var1;
   }

   public boolean isExpanded() {
      return (boolean)(this.isExpanded);
   }

   public void setExpanded(boolean var1) {
      this.isExpanded = (boolean)(var1);
   }
   

   

   
}
