package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

 
public class ClickGuiScreen3 extends GuiScreen {
    
   public int posX = this.getScaledRes().getScaledWidth() / 2 - 150;
    
   public int posY = this.getScaledRes().getScaledHeight() / 2 - 100;
    
   public int height;
    
   public int width;
    
   public boolean dragging = false;
    
   public int dragX;
    
   public int dragY;
    
   public Category selectedCategory;
    
   public Module selectedModule;
    
   public GuiScreen3Combo selectedCombo;
    
   public ArrayList<GuiScreen3Component> comps;

   public ClickGuiScreen3() {
      this.selectedCategory = Category.COMBAT;
      this.comps = new ArrayList();
   }

   public void initGui() {
      super.initGui();
      this.dragging = false;
      this.selectedCombo = null;
   }

   public void drawScreen(int var1, int var2, float var3) {
      super.drawScreen(var1, var2, var3);
      new ScaledResolution(this.mc);
      if (this.dragging) {
         int var189 = this.dragX;
         this.posX = var1 - var189;
         var189 = this.dragY;
         this.posY = var2 - var189;
      }

      this.width = this.posX + 455;
      this.height = this.posY + 300;
      int var56 = this.posX + 1;
      int var138 = this.posY + 3;
      int var191 = 1 + this.width;
      int var10003 = 3 + this.height;
      CaesiumRenderUtils.drawRect(var56, var138, var191, var10003, (new Color(45, 45, 45, 249)).getRGB());
      var56 = this.posX;
      var138 = this.posY + 3;
      var191 = this.height + 3;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(0, 0, 0, 255)).getRGB());
      var56 = this.width + 1;
      var138 = this.posY + 3;
      var191 = this.height + 3;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(0, 0, 0, 255)).getRGB());
      var56 = this.posX;
      var138 = this.posY + 3;
      var191 = this.width + 1;
      var10003 = this.width;
      CaesiumRenderUtils.drawTrapezoid(var56, var138, var191, var10003 - 8, 4, RainbowUtils.getColor());
      var56 = this.posX + 12;
      var138 = this.height + 3;
      var191 = this.width;
      var191 = var191 - 12 + 2;
      var10003 = this.height + 3 + 3;
      Render3DUtils.drawRoundedRect2(var56, var138, var191, var10003, 12.0F, (new Color(45, 45, 45, 249)).getRGB());
      var56 = this.posX + 1;
      var138 = this.width;
      var191 = this.posY + 3 + 60;
      CaesiumRenderUtils.drawHorizontalLine(var56, var138, var191, (new Color(100, 100, 100, 249)).getRGB());
      var56 = this.posX + 110;
      var138 = this.posY + 3 + 60;
      var191 = this.height + 3 + 14;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(100, 100, 100, 249)).getRGB());
      var56 = this.posX + 111;
      var138 = this.posY + 3 + 60 + 1;
      var191 = this.posX + 139;
      var10003 = this.height + 3 + 14;
      CaesiumRenderUtils.drawRect(var56, var138, var191, var10003, (new Color(20, 20, 20, 255)).getRGB());
      var56 = this.posX + 140;
      var138 = this.posY + 3 + 60;
      var191 = this.height + 3 + 14;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(100, 100, 100, 249)).getRGB());
      var56 = this.width + 1 + 5;
      var138 = this.posY + 3;
      var191 = 6 + this.width + 114;
      var10003 = 3 + this.height;
      CaesiumRenderUtils.drawRect(var56, var138, var191, var10003, (new Color(45, 45, 45, 249)).getRGB());
      var56 = this.width + 5;
      var138 = this.posY + 3;
      var191 = this.height + 3;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(0, 0, 0, 255)).getRGB());
      var56 = this.width + 1 + 5 + 114;
      var138 = this.posY + 3;
      var191 = this.height + 3;
      CaesiumRenderUtils.drawVerticalLine(var56, var138, var191, (new Color(0, 0, 0, 255)).getRGB());
      var56 = this.width + 5;
      var138 = this.posY + 3;
      var191 = 6 + this.width + 114;
      var10003 = 5 + this.width + 114;
      CaesiumRenderUtils.drawTrapezoid(var56, var138, var191, var10003 - 8, 4, RainbowUtils.getColor());
      var56 = this.width + 5 + 12;
      var138 = this.height + 3;
      var191 = this.width;
      var191 = var191 - 12 + 2 + 5 + 114;
      var10003 = this.height + 3 + 3;
      Render3DUtils.drawRoundedRect2(var56, var138, var191, var10003, 12.0F, (new Color(45, 45, 45, 249)).getRGB());
      var56 = this.width + 1 + 5;
      var138 = this.width + 114 + 5;
      var191 = this.posY + 3 + 15;
      CaesiumRenderUtils.drawHorizontalLine(var56, var138, var191, (new Color(100, 100, 100, 249)).getRGB());
      CFontRenderer var71 = FontStorage.fr;
      double var208 = (double)(this.width + 5) + (double)57.0F;
      double var226 = (double)FontStorage.fr.getStringWidth("Friends") / (double)2.0F;
      float var209 = (float)((int)(var208 - var226));
      double var10004 = (double)FontStorage.fr.getStringHeight("Friends") / (double)2.0F;
      var71.drawStringWithShadow(var153, var209, (float)((int)((double)10.5F - var10004 + (double)this.posY + (double)2.0F)), -1);
      int var5 = 2;

      byte var8;
      for(Iterator var6 = FriendManager.FRIENDS.iterator(); (var6.hasNext()) != 0; var5 += var8 + 2) {
         String var7 = (String)var6.next();
         var8 = 10;
         int var9 = FontStorage.fr.getStringWidth(var7);
         int var10 = 19 + this.posY;
         double var72 = (double)(this.width + 5) + (double)57.0F;
         double var154 = (double)var9 / (double)2.0F;
         int var11 = (int)(var72 - var154);
         if ((this.isInside(var1, var2, (double)var11, (double)(var10 + var5), (double)(var11 + var9), (double)(var10 + var5 + var8))) != 0) {
            FontStorage.fr3.drawString(var7, (float)var11, (float)(var10 + var5), RainbowUtils.getColor());
         } else {
            FontStorage.fr3.drawString(var7, (float)var11, (float)(var10 + var5), -1);
         }
      }

      GlStateManager.pushMatrix();
      Render3DUtils.drawImage(new ResourceLocation("2345.png"), this.posX + 3 + 10, this.posY + 3 + 3 + 10 + 5, 25, 25);
      GlStateManager.popMatrix();
      float var73 = (float)(this.posY + 3 + 3);
      var209 = (float)FontStorage.fr.getStringHeight(var22) / 2.0F;
      int var23 = (int)(var73 + (30.0F - var209));
      FontStorage.fr.drawStringWithShadow(var22, (float)(this.posX + 33), (float)var23, -1);

      try {
         this.mc.getTextureManager().bindTexture(((NetHandlerPlayClient)Objects.requireNonNull(this.mc.getConnection())).getPlayerInfo(this.mc.player.getUniqueID()).getLocationSkin());
         CFontRenderer var155 = FontStorage.fr3;
         int var156 = var155.getStringWidth("Name: " + this.mc.player.getName());
         CFontRenderer var211 = FontStorage.fr3;
         var8 = 20 + Math.max(var156, var211.getStringWidth("UID: " + Legend.UID));
         int var74 = this.width;
         var74 -= var8;
         Gui.drawScaledCustomSizeModalRect(var74 - 22, this.posY + 3 + 20, 8.0F, 8.0F, 8, 8, 22, 22, 64.0F, 64.0F);
         CFontRenderer var76 = FontStorage.fr3;
         String var157 = "Name: " + this.mc.getSession().getUsername();
         int var212 = this.width;
         var76.drawStringWithShadow(var157, (float)(var212 - var8 + 3), (float)(this.posY + 3 + 20), -1);
         var76 = FontStorage.fr3;
         var157 = "UID: " + Legend.UID;
         var212 = this.width;
         var76.drawStringWithShadow(var157, (float)(var212 - var8 + 3), (float)(this.posY + 3 + 32), -1);
      } catch (Exception var21) {
         var21.printStackTrace();
      }

      var8 = 0;
      int var26 = 0;
      int var27 = 0;

      for(Category var14 : Category.values()) {
         if (var8 % 3 == 0) {
            ++var26;
            var27 = 0;
         }

         double var15 = (double)(this.posX + 120 + var27);
         double var17 = (double)(this.posY + 3 + var26 * 20);
         int var19 = FontStorage.fr3.getStringWidth(var14.name());
         int var20 = FontStorage.fr3.getStringHeight(var14.name());
         var27 += var19;
         if ((this.isInside(var1, var2, var15, var17, var15 + (double)var19, var17 + (double)var20)) != 0) {
            FontStorage.fr3.drawString(var14.name(), (float)((int)var15), (float)((int)var17), RainbowUtils.getColor());
         } else if ((var14.equals(this.selectedCategory)) != 0) {
            FontStorage.fr3.drawString(var14.name(), (float)((int)var15), (float)((int)var17), RainbowUtils.getColor());
         } else {
            FontStorage.fr3.drawString(var14.name(), (float)((int)var15), (float)((int)var17), -1);
         }

         var27 += 6;
         ++var8;
      }

      int var30 = 0;

      for(Iterator var32 = Legend.moduleManager.getModules(this.selectedCategory).iterator(); (var32.hasNext()) != 0; var30 += 6) {
         Module var34 = (Module)var32.next();
         int var36 = FontStorage.fr3.getStringWidth(var34.getName());
         int var38 = FontStorage.fr3.getStringHeight(var34.getName());
         if ((this.isInside(var1, var2, (double)(this.posX + 3), (double)(this.posY + 3 + 60 + 5 + var30), (double)(this.posX + 3 + var36), (double)(this.posY + 3 + 60 + 5 + var30 + var38))) != 0) {
            FontStorage.fr3.drawString(var34.getName(), (float)(this.posX + 3), (float)(this.posY + 3 + 60 + 5 + var30), RainbowUtils.getColor());
         } else if ((var34.isToggled()) != 0) {
            FontStorage.fr3.drawString(var34.getName(), (float)(this.posX + 3), (float)(this.posY + 3 + 60 + 5 + var30), RainbowUtils.getColor());
         } else {
            FontStorage.fr3.drawString(var34.getName(), (float)(this.posX + 3), (float)(this.posY + 3 + 60 + 5 + var30), -1);
         }

         var30 += var38;
      }

      Iterator var33 = this.comps.iterator();

      while((var33.hasNext()) != 0) {
         (GuiScreen3Component)var33.next()).drawScreen(var1, var2;
      }

      if (this.selectedCombo != null) {
         int var78 = this.posX + 299;
         int var159 = this.posY + 3 + 60;
         int var214 = this.height + 3 + 14;
         CaesiumRenderUtils.drawVerticalLine(var78, var159, var214, (new Color(100, 100, 100, 249)).getRGB());
         var78 = this.posX + 300;
         var159 = this.posY + 3 + 60 + 1;
         var214 = this.posX + 399;
         int var227 = this.height + 3 + 14;
         CaesiumRenderUtils.drawRect(var78, var159, var214, var227, (new Color(20, 20, 20, 255)).getRGB());
         var78 = this.posX + 300 + 100;
         var159 = this.posY + 3 + 60;
         var214 = this.height + 3 + 14;
         CaesiumRenderUtils.drawVerticalLine(var78, var159, var214, (new Color(100, 100, 100, 249)).getRGB());
         int var35 = 0;

         for(Iterator var37 = this.selectedCombo.setting.getOptions().iterator(); (var37.hasNext()) != 0; var35 += var159 - 2) {
            Object var39 = var37.next();
            String var16 = (String)var39;
            if ((this.selectedCombo.setting.getValString().equals(var16)) != 0) {
               var78 = this.posX + 300;
               var159 = this.posY + 3 + 60 + 2 + var35;
               --var159;
               var214 = this.posX + 300 + 100;
               var227 = this.posY + 3 + 60 + 2 + FontStorage.fr3.getStringHeight(var16) + 2 + var35;
               CaesiumRenderUtils.drawRect(var78, var159, var214, var227 - 1, RainbowUtils.getColor());
            } else {
               var78 = this.posX + 300;
               var159 = this.posY + 3 + 60 + 2 + var35;
               --var159;
               var214 = this.posX + 300 + 100;
               var227 = this.posY + 3 + 60 + 2 + FontStorage.fr3.getStringHeight(var16) + 2 + var35;
               --var227;
               CaesiumRenderUtils.drawRect(var78, var159, var214, var227, (new Color(59, 59, 59)).getRGB());
            }

            CFontRenderer var83 = FontStorage.fr3;
            double var219 = (double)(this.posX + 300) + (double)50.0F;
            double var231 = (double)FontStorage.fr3.getStringWidth(var16) / (double)2.0F;
            var83.drawString(var16, var219 - var231, (double)(this.posY + 3 + 60 + 2 + var35 + 2), -1);
            var159 = 4 + FontStorage.fr3.getStringHeight(var16);
         }
      }

   }

   public void mouseClicked(int var1, int var2, int var3) throws IOException {
      super.mouseClicked(var1, var2, var3);
      if ((this.isInside(var1, var2, (double)this.posX, (double)this.posY, (double)(this.width + 1), (double)(this.posY + 4))) != 0 && var3 == 0) {
         this.dragging = true;
         int var54 = this.posX;
         this.dragX = var1 - var54;
         var54 = this.posY;
         this.dragY = var2 - var54;
      }

      int var4 = 0;
      int var5 = 0;
      int var6 = 0;

      for(Category var10 : Category.values()) {
         if (var4 % 3 == 0) {
            ++var5;
            var6 = 0;
         }

         double var11 = (double)(this.posX + 120 + var6);
         double var13 = (double)(this.posY + 3 + var5 * 20);
         int var15 = FontStorage.fr3.getStringWidth(var10.name());
         int var16 = FontStorage.fr3.getStringHeight(var10.name());
         var6 += var15;
         if ((this.isInside(var1, var2, var11, var13, var11 + (double)var15, var13 + (double)var16)) != 0 && var3 == 0) {
            this.selectedCategory = var10;
         }

         var6 += 6;
         ++var4;
      }

      int var18 = 0;

      for(Iterator var20 = Legend.moduleManager.getModules(this.selectedCategory).iterator(); (var20.hasNext()) != 0; var18 += 6) {
         Module var22 = (Module)var20.next();
         int var24 = FontStorage.fr3.getStringWidth(var22.getName());
         int var26 = FontStorage.fr3.getStringHeight(var22.getName());
         if ((this.isInside(var1, var2, (double)(this.posX + 3), (double)(this.posY + 3 + 60 + 5 + var18), (double)(this.posX + 3 + var24), (double)(this.posY + 3 + 60 + 5 + var18 + var26))) != 0) {
            if (var3 == 0) {
               var22.toggle();
            }

            if (var3 == 1) {
               int var12 = 3;
               this.comps.clear();
               this.selectedModule = var22;
               if (Legend.instance.settingsManager.getSettingsByMod(var22) != null) {
                  for(Iterator var29 = Legend.instance.settingsManager.getSettingsByMod(var22).iterator(); (var29.hasNext()) != 0; var12 += 3) {
                     Setting var14 = (Setting)var29.next();
                     if ((var14.isCheck()) != 0) {
                        ArrayList var33 = this.comps;
                        var33.add(new GuiScreen3Check(145, 63 + var12, this, this.selectedModule, var14));
                        var12 += 10;
                     }

                     if ((var14.isSlider()) != 0) {
                        ArrayList var34 = this.comps;
                        var34.add(new GuiScreen3Slider(145, 63 + var12, this, this.selectedModule, var14));
                        var12 += 20;
                     }

                     if ((var14.isCombo()) != 0) {
                        ArrayList var35 = this.comps;
                        var35.add(new GuiScreen3Combo(145, 63 + var12, this, this.selectedModule, var14));
                        var12 += 14;
                     }

                     if ((var14.isButton()) != 0) {
                        ArrayList var36 = this.comps;
                        var36.add(new GuiScreen3Button(145, 63 + var12, this, this.selectedModule, var14));
                        var12 += 14;
                     }
                  }
               }

               ArrayList var37 = this.comps;
               var37.add(new GuiScreen3Keybind(145, 63 + var12, this, this.selectedModule));
            }
         }

         var18 += var26;
      }

      Iterator var21 = this.comps.iterator();

      while((var21.hasNext()) != 0) {
         (GuiScreen3Component)var21.next()).mouseClicked(var1, var2, var3;
      }

      if (this.selectedCombo != null) {
         int var23 = 0;
         int var25 = 0;

         for(Iterator var27 = this.selectedCombo.setting.getOptions().iterator(); (var27.hasNext()) != 0; ++var23) {
            Object var28 = var27.next();
            String var30 = (String)var28;
            double var10003 = (double)(this.posX + 300);
            double var10004 = (double)(this.posY + 3 + 60 + 2 + var25);
            double var10005 = (double)(this.posX + 300 + 100);
            int var10006 = this.posY + 3 + 60 + 2 + FontStorage.fr3.getStringHeight(var30) + 2 + var25;
            if ((this.isInside(var1, var2, var10003, var10004, var10005, (double)(var10006 - 1))) != 0 && var3 == 0) {
               this.selectedCombo.setting.setValString((String)this.selectedCombo.setting.getOptions().get(var23));
            }

            int var49 = 4 + FontStorage.fr3.getStringHeight(var30);
            var25 += var49 - 2;
         }
      }

   }

   public void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this.dragging = false;
      Iterator var4 = this.comps.iterator();

      while((var4.hasNext()) != 0) {
         (GuiScreen3Component)var4.next()).mouseReleased(var1, var2, var3;
      }

      if (var3 == 0 && (this.isInside(var1, var2, (double)(this.width + 1 + 5), (double)(19 + this.posY), (double)(this.width + 114 + 5), (double)(19 + this.posY + 12 * FriendManager.FRIENDS.size()))) != 0) {
         CopyOnWriteArrayList var10000 = FriendManager.FRIENDS;
         int var10002 = 19 + this.posY;
         var10000.remove((int)((double)(var2 - var10002) / (double)12.0F));
      }

   }

   public boolean isInside(int var1, int var2, double var3, double var5, double var7, double var9) {
      return (double)var1 >= var3 && (double)var1 <= var7 && (double)var2 >= var5 && (double)var2 <= var9;
   }

   public ScaledResolution getScaledRes() {
      return new ScaledResolution(Minecraft.getMinecraft());
   }
   

   

   
}
