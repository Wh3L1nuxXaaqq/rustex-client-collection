package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.input.Mouse;

 
public class CaesiumFrame implements ICaesiumFrame {
    
   public ArrayList<CaesiumButton> buttons = new ArrayList();
    
   public boolean isExpaned;
    
   public boolean isDragging;
    
   public int id;
    
   public int posX;
    
   public int posY;
    
   public int prevPosX;
    
   public int prevPosY;
    
   public int scrollHeight;
    
   public static int dragID;
    
   public String title;

   public CaesiumFrame(String var1, int var2, int var3, boolean var4) {
      this.title = var1;
      this.posX = var2;
      this.posY = var3;
      this.isExpaned = (boolean)(var4);
      this.id = ++ClickGuiScreen2.compID;
      this.scrollHeight = 0;
   }

   public void render(int var1, int var2) {
      String var3 = CaesiumScreen.theme;
      byte var4 = -1;
      switch (var3.hashCode()) {
         case -2087928939:
            if ((var3.equals("Caesium")) != 0) {
               var4 = 0;
            }
         default:
            switch (var4) {
               case 0:
                  this.renderCaesium(var1, var2);
               default:
            }
      }
   }

   public void renderCaesium(int var1, int var2) {
      int var3 = RainbowUtils.getColor();
      int var4 = CaesiumScreen.fontColor;
      int var5 = Math.max(CaesiumScreen.FRAME_WIDTH, CaesiumScreen.fR.getStringWidth(this.title) + 15);
      if (this.isDragging && (Mouse.isButtonDown(0)) != 0) {
         int var54 = this.prevPosX;
         this.posX = var1 - var54;
         var54 = this.prevPosY;
         this.posY = var2 - var54;
         dragID = this.id;
      } else {
         this.isDragging = false;
         dragID = -1;
      }

      CaesiumButton var7;
      for(Iterator var6 = this.buttons.iterator(); (var6.hasNext()) != 0; var5 = Math.max(var5, var7.getWidth() + 15)) {
         var7 = (CaesiumButton)var6.next();
      }

      float var27 = (float)(this.posX + 1);
      int var43 = this.posY;
      Render2DUtils.drawVGradientRect(var27, (float)(var43 - 5), (float)(this.posX + var5), (float)(this.posY + 12), RainbowUtils.getColor(), RainbowUtils.getColor2());
      FontRenderer var28 = CaesiumScreen.fR;
      String var44 = this.title;
      int var56 = this.posX + var5 / 2;
      int var10003 = CaesiumScreen.fR.getStringWidth(this.title) / 2;
      var28.drawStringWithShadow(var44, (float)(var56 - var10003), (float)this.posY, var4);
      var28 = CaesiumScreen.fR;
      var44 = this.isExpaned ? "-" : "+";
      var56 = this.posX + var5;
      var10003 = CaesiumScreen.fR.getStringWidth(this.isExpaned ? "-" : "+");
      var56 -= var10003;
      var28.drawStringWithShadow(var44, (float)(var56 - 4), (float)this.posY, var4);
      if (this.isExpaned) {
         int var22 = 0;
         int var23 = CaesiumScreen.grey40_240;

         CaesiumButton var9;
         for(Iterator var8 = this.buttons.iterator(); (var8.hasNext()) != 0; var22 += var9.getHeight()) {
            var9 = (CaesiumButton)var8.next();
            var9.render(this.posX + 1, this.posY + var22 + 12, var5, var1, var2, 0);
            if (var9.getButtonID() == CaesiumButton.expandedID) {
               ArrayList var30 = var9.getComponents();
               ArrayList var10 = var30;
               if ((var30.isEmpty()) == 0) {
                  int var11 = 10;
                  int var12 = 0;
                  boolean var13 = true;
                  Iterator var14 = var10.iterator();

                  while((var14.hasNext()) != 0) {
                     ICaesiumComponent var15 = (ICaesiumComponent)var14.next();
                     var11 = Math.max(var11, var15.getWidth());
                     var12 += var15.getHeight();
                     if ((var15.allowScroll()) == 0) {
                        var13 = false;
                     }
                  }

                  int var24 = this.posX + var5 + 2;
                  int var25 = var24 + var11;
                  int var16 = this.posY + var22 + 12;
                  int var17 = var16 + var12 + 1;
                  int var18 = Mouse.getDWheel() * -1 / 8;
                  if (var17 + this.scrollHeight < 30) {
                     var18 *= -1;
                     this.scrollHeight += 10;
                  }

                  if (var13) {
                     this.scrollHeight += var18;
                  }

                  CaesiumRenderUtils.drawRect(var24 + 1, var16 + 1 + this.scrollHeight, var25, var17 + this.scrollHeight, CaesiumScreen.black100);
                  int var19 = 0;

                  ICaesiumComponent var21;
                  for(Iterator var20 = var10.iterator(); (var20.hasNext()) != 0; var19 += var21.getHeight()) {
                     var21 = (ICaesiumComponent)var20.next();
                     var21.render(var24, var16 + var19 + 2 + this.scrollHeight, var11, var1, var2, var18);
                  }

                  CaesiumRenderUtils.drawVerticalLine(var24, var16 + this.scrollHeight, var17 + this.scrollHeight, var3);
                  CaesiumRenderUtils.drawVerticalLine(var25, var16 + this.scrollHeight, var17 + this.scrollHeight, var3);
                  CaesiumRenderUtils.drawHorizontalLine(var24, var25, var16 + this.scrollHeight, var3);
                  CaesiumRenderUtils.drawHorizontalLine(var24, var25, var17 + this.scrollHeight, var3);
               }
            }
         }

         int var31 = this.posX + 1;
         int var46 = this.posX + var5;
         CaesiumRenderUtils.drawHorizontalLine(var31, var46 - 1, this.posY + var22 + 12, var3);
         var31 = this.posX + var5;
         var46 = this.posY;
         CaesiumRenderUtils.drawVerticalLine(var31, var46 - 5, this.posY + var22 + 14, CaesiumScreen.black100);
         var31 = this.posX + var5;
         var46 = this.posY;
         CaesiumRenderUtils.drawVerticalLine(var31, var46 - 4, this.posY + var22 + 14, CaesiumScreen.black100);
         var31 = this.posX + var5 + 1;
         var46 = this.posY;
         CaesiumRenderUtils.drawVerticalLine(var31, var46 - 4, this.posY + var22 + 15, CaesiumScreen.black100);
         var31 = this.posX + 2;
         var46 = this.posX + var5;
         CaesiumRenderUtils.drawHorizontalLine(var31, var46 - 1, this.posY + var22 + 13, CaesiumScreen.black100);
         var31 = this.posX + 2;
         var46 = this.posX + var5;
         CaesiumRenderUtils.drawHorizontalLine(var31, var46 - 1, this.posY + var22 + 13, CaesiumScreen.black100);
         CaesiumRenderUtils.drawHorizontalLine(this.posX + 3, this.posX + var5, this.posY + var22 + 14, CaesiumScreen.black100);
      }

   }

   public void mouseClicked(int var1, int var2, int var3) {
      int var4 = CaesiumScreen.FRAME_WIDTH;
      if (this.isExpaned) {
         Iterator var5 = this.buttons.iterator();

         while((var5.hasNext()) != 0) {
            CaesiumButton var6 = (CaesiumButton)var5.next();
            var4 = Math.max(var4, var6.getWidth());
            var6.mouseClicked(var1, var2, var3);
         }
      }

      if ((CaesiumRenderUtils.isHovered(this.posX, this.posY, var4, 13, var1, var2)) != 0) {
         if (var3 == 0) {
            int var10002 = this.posX;
            this.prevPosX = var1 - var10002;
            var10002 = this.posY;
            this.prevPosY = var2 - var10002;
            this.isDragging = true;
            dragID = this.id;
         } else if (var3 == 1) {
            this.isExpaned = (boolean)((this.isExpaned) == 0 ? 1 : 0);
            this.scrollHeight = 0;
            this.isDragging = false;
            dragID = -1;
         }
      }

   }

   public void keyTyped(int var1, char var2) {
      if (this.isExpaned) {
         Iterator var3 = this.buttons.iterator();

         while((var3.hasNext()) != 0) {
            CaesiumButton var4 = (CaesiumButton)var3.next();
            var4.keyTyped(var1, var2);
         }
      }

   }

   public void initialize() {
   }

   public void addButton(CaesiumButton var1) {
      if ((this.buttons.contains(var1)) == 0) {
         this.buttons.add(var1);
      }

   }

   public int getButtonID() {
      return this.id;
   }

   public boolean isExpaned() {
      return (boolean)(this.isExpaned);
   }

   public int getPosX() {
      return this.posX;
   }

   public int getPosY() {
      return this.posY;
   }

   public String getTitle() {
      return this.title;
   }
   

   

   
}
