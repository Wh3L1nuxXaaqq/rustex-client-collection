package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;

 
public class GuiScreen3Slider extends GuiScreen3Component {
    
   public boolean dragging = false;

   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      int var4 = 2 + FontStorage.fr3.getStringHeight("R:10");
      if ((this.isInside(var1, var2, (double)(this.parent.posX + this.x), (double)(this.parent.posY + this.y + var4), (double)(this.parent.posX + this.x) + (double)100.0F, (double)(this.parent.posY + this.y + 4 + var4))) != 0 && var3 == 0) {
         this.dragging = true;
      }

   }

   public GuiScreen3Slider(int var1, int var2, ClickGuiScreen3 var3, Module var4, Setting var5) {
      this.x = var1;
      this.y = var2;
      this.parent = var3;
      this.module = var4;
      this.setting = var5;
   }

   public void drawScreen(int var1, int var2) {
      super.drawScreen(var1, var2);
      int var3 = 0;
      byte var4 = 100;
      double var14 = this.setting.getMax();
      double var35 = this.setting.getMin();
      float var5 = (float)(var14 - var35);
      if (this.dragging && var1 >= this.parent.posX + this.x && var1 <= this.parent.posX + this.x + var4) {
         if ((this.setting.onlyInt()) != 0) {
            Setting var15 = this.setting;
            float var36 = var5 / (float)var4;
            int var10003 = this.parent.posX + this.x;
            var15.setValDouble((double)Math.round((double)(var36 * (float)(var1 - var10003)) + this.setting.getMin()));
         } else {
            Setting var16 = this.setting;
            float var37 = var5 / (float)var4;
            int var48 = this.parent.posX + this.x;
            var16.setValDouble((double)roundToNearestFifty((float)((double)(var37 * (float)(var1 - var48)) + this.setting.getMin())));
         }
      }

      var14 = (double)((float)var4 / var5);
      var35 = this.setting.getValDouble();
      double var46 = this.setting.getMin();
      int var6 = (int)(var14 * (var35 - var46));
      String var7 = String.valueOf(this.setting.getValDouble());
      if ((var7.contains(".")) != 0 && var7.split("\\.")[1].length() > 3) {
         Object[] var39 = new Object[1];
         var39[0] = this.setting.getValDouble();
         var7 = String.format(var18, var39);
      }

      CFontRenderer var19 = FontStorage.fr3;
      int var8 = var19.getStringHeight(this.setting.getName() + ": " + var7);
      var19 = FontStorage.fr3;
      var19.drawString(this.setting.getName() + ": " + var7, (float)(this.parent.posX + this.x), (float)(this.parent.posY + this.y + var3), -1);
      var3 += var8 + 2;
      float var21 = (float)(this.parent.posX + this.x);
      float var40 = (float)(this.parent.posY + this.y + var3);
      float var47 = (float)(this.parent.posX + this.x + var4);
      float var49 = (float)(this.parent.posY + this.y + 4 + var3);
      Render3DUtils.drawRect(var21, var40, var47, var49, (new Color(200, 200, 200)).getRGB());
      Render3DUtils.drawRect((float)(this.parent.posX + this.x), (float)(this.parent.posY + this.y + var3), (float)(this.parent.posX + this.x + var6), (float)(this.parent.posY + this.y + 4 + var3), RainbowUtils.getColor());
      var3 += 2;
      int var22 = this.parent.posX + this.x;
      var22 += var6 - 2;
      int var41 = this.parent.posY + this.y + var3;
      Render2DUtils.drawFilledCircle(var22, var41, 4.0F, new Color(200, 200, 200), 360);
   }

   public void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this.dragging = false;
   }
   public static float roundToNearestFifty(float var0) {
      return (float)Math.round(var0 * 20.0F) / 20.0F;
   }
   

   

   
}
