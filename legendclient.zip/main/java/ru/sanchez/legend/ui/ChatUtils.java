package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

 
public class ChatUtils {
    
   public static final String prefix;
   public static void sendMessage(String var0) {
      if ((Wrapper.nullCheck()) != 0) {
         EntityPlayerSP var1 = Minecraft.getMinecraft().player;
         var1.sendMessage(new TextComponentString(prefix + var0));
      }
   }
   public static void say(String var0) {
      if ((Wrapper.nullCheck()) != 0) {
         Minecraft.getMinecraft().player.sendChatMessage(var0);
      }
   }

   static {
      
      prefix = TextFormatting.GRAY + "[" + TextFormatting.RED + "Legend" + TextFormatting.GRAY + "]: " + TextFormatting.WHITE;
   }
   

   
}
