package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class SmoothAnimationTimer {
    
   public long mc;
    
   public float anim;
    
   public float anim2;
    
   public float to;
    
   public float speed;

   public SmoothAnimationTimer(float var1, float var2, float var3) {
      this.anim = var1;
      this.to = var2;
      this.speed = var3;
      this.mc = System.currentTimeMillis();
   }

   public SmoothAnimationTimer(float var1, float var2, float var3, boolean var4) {
      this.anim2 = var1;
      this.anim = var1;
      this.to = var2;
      this.speed = var3;
      this.mc = System.currentTimeMillis();
   }

   public float getAnim() {
      int var1 = (int)((System.currentTimeMillis() - this.mc) / 5L);
      if (var1 > 0) {
         this.mc = System.currentTimeMillis();
      }

      for(int var2 = 0; var2 < var1; ++var2) {
         this.anim = MathUtils.lerp(this.anim, this.to, this.speed);
      }

      return this.anim;
   }

   public float getAnim2() {
      int var1 = (int)((System.currentTimeMillis() - this.mc) / 5L);
      if (var1 > 0) {
         this.mc = System.currentTimeMillis();
      }

      for(int var2 = 0; var2 < var1; ++var2) {
         this.anim2 = MathUtils.lerp(this.anim2, this.to, this.speed);
      }

      return this.anim2;
   }

   public void reset() {
      this.mc = System.currentTimeMillis();
   }

   public void setAnim(float var1) {
      this.anim = var1;
      this.anim2 = var1;
      this.mc = System.currentTimeMillis();
   }
   

   
}
