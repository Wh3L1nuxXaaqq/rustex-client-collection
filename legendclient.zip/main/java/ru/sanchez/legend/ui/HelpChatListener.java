package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.HashSet;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class HelpChatListener {
    
   public static HashSet<EntityPlayer> Player;
    
   public static Minecraft mc;

   @SubscribeEvent
   public void ChatEvent(ClientChatEvent var1) {
      String var2 = var1.getMessage();
      var2 = var1.getMessage().toLowerCase();
      if ((var2.startsWith(".help")) != 0 || (var2.startsWith("/lhelp")) != 0) {
         try {
            ChatUtils.sendMessage(".help | /lhelp");
            Iterator var3 = Legend.commandManager.getCommands().iterator();

            while((var3.hasNext()) != 0) {
               CommandBase var4 = (CommandBase)var3.next();
               ChatUtils.sendMessage("/" + var4.getName());
            }
         } catch (Throwable var5) {
            ChatUtils.sendMessage("Error");
         }

         var1.setMessage("");
      }

   }

   static {
      
      Player = new HashSet();
      mc = Minecraft.getMinecraft();
   }
   

   
}
