package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

 
public abstract class TaskManagerBase<T extends AbstractTask> implements ITaskManager<T> {
    
   public final List<T> tasks = new ArrayList();
    
   public AbstractTask currentTask = null;

   public void addTask(T var1) {
      this.tasks.add(var1);
   }

   public void removeTask(String var1) {
      this.tasks.remove(this.getTask(var1));
   }

   public void removeTask(T var1) {
      this.tasks.remove(var1);
   }

   public List<T> getTasks() {
      return this.tasks;
   }

   public boolean startTask(T var1) {
      if (this.currentTask == var1) {
         this.currentTask.setOnline(true);
         return true;
      } else if ((this.isCurrentlyTasking()) != 0) {
         if (this.currentTask.getPriority() < var1.getPriority()) {
            this.currentTask.setOnline(false);
            this.currentTask = var1;
            this.currentTask.setOnline(true);
            return true;
         } else {
            return false;
         }
      } else {
         if ((this.isCurrentlyTasking()) == 0) {
            this.currentTask = var1;
            this.currentTask.setOnline(true);
         }

         return true;
      }
   }

   public void finishTask(T var1) {
      if (this.currentTask == var1) {
         this.currentTask.setOnline(false);
         this.currentTask = null;
      }

   }

   public T getTask(String var1) {
      AbstractTask var2 = null;
      Iterator var3 = this.getTasks().iterator();

      while((var3.hasNext()) != 0) {
         AbstractTask var4 = (AbstractTask)var3.next();
         if ((var4.getName().equalsIgnoreCase(var1)) != 0) {
            var2 = var4;
            break;
         }
      }

      return (T)var2;
   }

   public boolean comparePriority(T var1) {
      return var1.getPriority() >= this.currentTask.getPriority();
   }

   public boolean isCurrentlyTasking() {
      return (boolean)(Objects.nonNull(this.currentTask));
   }
   

   

   
}
