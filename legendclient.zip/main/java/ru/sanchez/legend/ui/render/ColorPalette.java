package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class ColorPalette {
    
   public static final int WHITE;
    
   public static final int BLACK;
    
   public static final int RED;
    
   public static final int GREEN;
    
   public static final int BLUE;
    
   public static final int ORANGE;
    
   public static final int PURPLE;
    
   public static final int GRAY;
    
   public static final int DARK_RED;
    
   public static final int YELLOW;
    
   public static final int RAINBOW = Integer.MIN_VALUE;

   static {
      
      WHITE = RainbowUtils.toRGBA(255, 255, 255, 255);
      BLACK = RainbowUtils.toRGBA(0, 0, 0, 255);
      RED = RainbowUtils.toRGBA(255, 0, 0, 255);
      GREEN = RainbowUtils.toRGBA(0, 255, 0, 255);
      BLUE = RainbowUtils.toRGBA(0, 0, 255, 255);
      ORANGE = RainbowUtils.toRGBA(255, 128, 0, 255);
      PURPLE = RainbowUtils.toRGBA(163, 73, 163, 255);
      GRAY = RainbowUtils.toRGBA(127, 127, 127, 255);
      DARK_RED = RainbowUtils.toRGBA(64, 0, 0, 255);
      YELLOW = RainbowUtils.toRGBA(255, 255, 0, 255);
   }
   
}
