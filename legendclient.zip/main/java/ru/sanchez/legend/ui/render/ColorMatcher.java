package ru.sanchez.legend.ui;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class ColorMatcher {
    
   public int r;
    
   public int g;
    
   public int b;
    
   public String name;
    
   public final RainbowUtils this$0;

   public ColorMatcher(RainbowUtils var1, String var2, int var3, int var4, int var5) {
      this.this$0 = var1;
      this.r = var3;
      this.g = var4;
      this.b = var5;
      this.name = var2;
   }

   public int computeMSE(int var1, int var2, int var3) {
      int var10001 = this.r;
      int var10000 = var1 - var10001;
      int var10002 = this.r;
      var10000 *= var1 - var10002;
      var10002 = this.g;
      var10001 = var2 - var10002;
      int var10003 = this.g;
      var10000 += var10001 * (var2 - var10003);
      var10002 = this.b;
      var10001 = var3 - var10002;
      var10003 = this.b;
      return (var10000 + var10001 * (var3 - var10003)) / 3;
   }

   public int getR() {
      return this.r;
   }

   public int getG() {
      return this.g;
   }

   public int getB() {
      return this.b;
   }

   public String getName() {
      return this.name;
   }
   

   
}
