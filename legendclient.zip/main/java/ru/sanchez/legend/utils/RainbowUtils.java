package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

 
public class RainbowUtils extends Module {
    
   public static int red;
    
   public static int green;
    
   public static int blue;
    
   public static int color;
    
   public static List<String> Modes;

   public RainbowUtils() {
      super("ClickGUI", Category.HUD);
      this.setKey(54);
      Modes.add("Caesium");
      Modes.add("Legend");
      Legend.instance.settingsManager.rSetting(new Setting("Gui", this, "Legend", (ArrayList)Modes));
      Legend.instance.settingsManager.rSetting(new Setting("Rainbow", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("Red", this, (double)225.0F, (double)0.0F, (double)225.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("Green", this, (double)0.0F, (double)0.0F, (double)225.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("Blue", this, (double)0.0F, (double)0.0F, (double)225.0F, true));
   }
   public static int getColor() {
      int var1 = (Legend.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean());
      float[] var10000 = new float[1];
      var10000[0] = (float)(System.currentTimeMillis() % 11520L) / 11520.0F;
      float[] var2 = var10000;
      int var3 = Color.HSBtoRGB(var2[0], 1.0F, 1.0F);
      int var4 = (int)Legend.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
      int var5 = (int)Legend.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
      int var6 = (int)Legend.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
      int var0 = RainbowUtils.toRGBA(var4, var5, var6, 255);
      int var7 = var1 != 0 ? RainbowUtils.genRainbow() : var0;
      return var7;
   }
   public static int getColor2() {
      int var1 = (Legend.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean());
      float[] var8 = new float[1];
      var8[0] = (float)(System.currentTimeMillis() % 11520L) / 11520.0F;
      float[] var2 = var8;
      int var3 = Color.HSBtoRGB(var2[0], 1.0F, 1.0F);
      int var4 = (int)Legend.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
      int var5 = (int)Legend.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
      int var6 = (int)Legend.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
      int var0 = RainbowUtils.toRGBA(var4, var5, var6, 195);
      int var7 = var1 != 0 ? RainbowUtils.genRainbowShadow() : var0;
      return var7;
   }
   public static float getColor3() {
      int var1 = (Legend.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean());
      float[] var8 = new float[1];
      var8[0] = (float)(System.currentTimeMillis() % 11520L) / 11520.0F;
      float[] var2 = var8;
      float var3 = (float)Color.HSBtoRGB(var2[0], 1.0F, 1.0F);
      float var4 = (float)Legend.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
      float var5 = (float)Legend.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
      float var6 = (float)Legend.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
      int var0 = RainbowUtils.toRGBA(var4, var5, var6, 255.0F);
      float var7 = var1 != 0 ? (float)RainbowUtils.genRainbowShadow() : (float)var0;
      return var7;
   }

   public void onEnable() {
      String var1 = Legend.instance.settingsManager.getSettingByName((Module)this, "Gui").getValString();
      if (mc.currentScreen == null) {
         byte var3 = -1;
         switch (var1.hashCode()) {
            case -2087928939:
               if ((var1.equals("Caesium")) != 0) {
                  var3 = 0;
               }
               break;
            case -2022707155:
               if ((var1.equals("Legend")) != 0) {
                  var3 = 1;
               }
         }

         switch (var3) {
            case 0:
               Minecraft var10000 = mc;
               var10000.displayGuiScreen(new CaesiumScreen("Caesium", 22));
               break;
            case 1:
               mc.displayGuiScreen(Legend.NewGui);
         }

         super.onEnable();
         this.setToggled(false);
      }
   }

   static {
      
      Modes = new ArrayList();
   }
   

   
}
