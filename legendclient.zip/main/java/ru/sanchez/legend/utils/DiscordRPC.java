package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class DiscordRPC extends Module {

   public DiscordRPC() {
      super("\u00103Q*C\u000e\u001e\u0015l\u5d8f", Category.OUTHER);
   }

   public void onEnable() {
      super.onEnable();

      try {
         DiscordRPC.startRPC();
      } catch (Throwable var2) {
         ChatUtils.sendMessage("\u0011(P&^");
         this.onDisableR();
      }

   }

   public void onDisable() {
      super.onDisable();

      try {
         DiscordRPC.stopRPC();
      } catch (NoClassDefFoundError var2) {
      }

   }
   

   
}
