package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

 
public class ClipboardUtils extends JFrame {

   public ClipboardUtils() {
      this.setTitle("Verification failed.");
      this.setDefaultCloseOperation(2);
      this.setLocationRelativeTo((Component)null);
      copyToClipboard();
      String var1 = "Sorry, you are not on the HWID list.\nHWID: " + SystemInfoUtils.getSystemInfo() + "\n(Copied to clipboard.)";
      JOptionPane.showMessageDialog(this, var1, "Could not verify your HWID successfully.", -1, UIManager.getIcon("OptionPane.errorIcon"));
   }
   public static void copyToClipboard() {
      StringSelection var0 = new StringSelection(SystemInfoUtils.getSystemInfo());
      Clipboard var1 = Toolkit.getDefaultToolkit().getSystemClipboard();
      var1.setContents(var0, var0);
   }
   

   
}
