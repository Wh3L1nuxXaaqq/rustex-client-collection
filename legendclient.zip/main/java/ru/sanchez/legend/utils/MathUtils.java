package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

 
public class MathUtils {
    
   public static final Random random;
   public static double getNormalDouble(double var0, int var2) {
      return (new BigDecimal(var0)).setScale(var2, RoundingMode.HALF_EVEN).doubleValue();
   }
   public static double getNormalDouble(double var0) {
      return (new BigDecimal(var0)).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
   }
   public static void drawUnfilledCircle(float var0, float var1, float var2, float var3, int var4) {
      float var5 = (float)(var4 >> 16 & 255) / 255.0F;
      float var6 = (float)(var4 >> 8 & 255) / 255.0F;
      float var7 = (float)(var4 & 255) / 255.0F;
      float var8 = (float)(var4 >> 24 & 255) / 255.0F;
      GL11.glEnable(2848);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      GlStateManager.enableBlend();
      GL11.glColor4f(var5, var6, var7, var8);
      GL11.glLineWidth(var3);
      GL11.glBegin(2);

      for(int var9 = 0; var9 <= 360; ++var9) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var9 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var9 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glEnd();
      GL11.glScalef(2.0F, 2.0F, 2.0F);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
      GlStateManager.disableBlend();
   }
   public static double getRandomInRange(double var0, double var2) {
      return var2 + (var0 - var2) * random.nextDouble();
   }
   public static BigDecimal round(float var0, int var1) {
      BigDecimal var2 = new BigDecimal(Float.toString(var0));
      var2 = var2.setScale(var1, 4);
      return var2;
   }
   public static int getRandomInRange(int var0, int var1) {
      double var10000 = (double)var1;
      return (int)(var10000 + (double)(var0 - var1) * random.nextDouble());
   }
   public static boolean isEven(int var0) {
      return var0 % 2 == 0;
   }
   public static double roundToPlace(double var0, int var2) {
      if (var2 < 0) {
         IllegalArgumentException var6 = new IllegalArgumentException();
         throw var6;
      } else {
         BigDecimal var3 = new BigDecimal(var0);
         var3 = var3.setScale(var2, RoundingMode.HALF_UP);
         return var3.doubleValue();
      }
   }
   public static double preciseRound(double var0, double var2) {
      double var4 = Math.pow((double)10.0F, var2);
      return (double)Math.round(var0 * var4) / var4;
   }
   public static double randomNumber(double var0, double var2) {
      double var10000 = Math.random();
      return var10000 * (var0 - var2) + var2;
   }
   public static int randomize(int var0, int var1) {
      int var10000 = -var1;
      double var10001 = Math.random();
      int var10003 = -var1;
      return var10000 + (int)(var10001 * (double)(var0 - var10003 + 1));
   }
   public static double getIncremental(double var0, double var2) {
      double var4 = (double)1.0F / var2;
      return (double)Math.round(var0 * var4) / var4;
   }
   public static boolean isInteger(Double var0) {
      return var0 == Math.floor(var0) && (Double.isInfinite(var0)) == 0;
   }
   public static float[] constrainAngle(float[] var0) {
      var0[0] %= 360.0F;

      for(var0[1] %= 360.0F; var0[0] <= -180.0F; var0[0] += 360.0F) {
      }

      while(var0[1] <= -180.0F) {
         var0[1] += 360.0F;
      }

      while(var0[0] > 180.0F) {
         float var10002 = var0[0];
         var0[0] = var10002 - 360.0F;
      }

      while(var0[1] > 180.0F) {
         float var1 = var0[1];
         var0[1] = var1 - 360.0F;
      }

      return var0;
   }
   public static double randomize(double var0, double var2) {
      Random var6 = new Random();
      double var7 = var2 - var0;
      double var9 = var6.nextDouble() * var7;
      if (var9 > var2) {
         var9 = var2;
      }

      double var4;
      if ((var4 = var9 + var0) > var2) {
         var4 = var2;
      }

      return var4;
   }
   public static double roundToDecimalPlace(double var0, double var2) {
      double var4 = var2 / (double)2.0F;
      double var6 = Math.floor(var0 / var2) * var2;
      if (var0 >= var6 + var4) {
         return (new BigDecimal(Math.ceil(var0 / var2) * var2, MathContext.DECIMAL64)).stripTrailingZeros().doubleValue();
      } else {
         return (new BigDecimal(var6, MathContext.DECIMAL64)).stripTrailingZeros().doubleValue();
      }
   }
   public static float lerp(float var0, float var1, float var2) {
      return var0 + var2 * (var1 - var0);
   }
   public static float clamp(float var0, float var1, float var2) {
      if (var0 <= var1) {
         var0 = var1;
      }

      if (var0 >= var2) {
         var0 = var2;
      }

      return var0;
   }

   static {
      
      random = new Random();
   }
   

   
}
