package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;

 
public class ItemUtils {
   public static ItemStack getSmallBox() {
      ItemStack var0 = new ItemStack(Items.DIAMOND_HOE, 1, 55);

      try {
         var0.setTagCompound(JsonToNBT.getTagFromJson("{Unbreak1\u58cc\u3579\u0f33\u33eb\u05c0\u0ab0\u3806"));
      } catch (Throwable var3) {
      }

      try {
         var0.setItemFrame((EntityItemFrame)null);
      } catch (Throwable var2) {
      }

      return var0;
   }
   public static ItemStack getShkaf() {
      ItemStack var5 = new ItemStack(Items.DIAMOND_HOE, 1, 56);
      ItemStack var0 = var5;

      try {
         var0.setTagCompound(JsonToNBT.getTagFromJson("{Unbreak1\u58cc\u3579\u0f33\u33eb\u05c0\u0ab0\u3806"));
      } catch (Throwable var3) {
      }

      try {
         var0.setItemFrame((EntityItemFrame)null);
      } catch (Throwable var2) {
      }

      return var0;
   }
   public static ItemStack getBigBox() {
      ItemStack var0 = new ItemStack(Items.DIAMOND_HOE, 1, 60);

      try {
         var0.setTagCompound(JsonToNBT.getTagFromJson("{Unbreak1\u58cc\u3579\u0f33\u33eb\u05c0\u0ab0\u3806"));
      } catch (Throwable var3) {
      }

      try {
         var0.setItemFrame((EntityItemFrame)null);
      } catch (Throwable var2) {
      }

      return var0;
   }
   public static ItemStack getFurance() {
      ItemStack var0 = new ItemStack(Items.DIAMOND_HOE, 1, 221);

      try {
         var0.setTagCompound(JsonToNBT.getTagFromJson("{Unbreak1\u58cc\u3579\u0f33\u33eb\u05c0\u0ab0\u3806"));
         System.out.println("TRUE");
      } catch (Throwable var3) {
      }

      try {
         var0.setItemFrame((EntityItemFrame)null);
      } catch (Throwable var2) {
      }

      return var0;
   }
   

   
}
