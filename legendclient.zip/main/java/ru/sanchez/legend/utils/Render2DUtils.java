package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

 
public class Render2DUtils implements MinecraftInterface {
    
   public static final Frustum frustrum;
    
   public static final double DOUBLE_PI = (Math.PI * 2D);
   public static double interpolate(double var0, double var2, double var4) {
      return var2 + (var0 - var2) * var4;
   }
   public static void glRenderStart() {
      GL11.glPushMatrix();
      GL11.glPushAttrib(1048575);
      GL11.glEnable(3042);
      GL11.glDisable(2884);
      GL11.glDisable(3553);
   }
   public static void glRenderStop() {
      GL11.glEnable(3553);
      GL11.glEnable(2884);
      GL11.glDisable(3042);
      GL11.glPopAttrib();
      GL11.glPopMatrix();
   }
   public static void drawCircle(float var0, float var1, float var2, int var3) {
      float var4 = (float)(var3 >> 24 & 255) / 255.0F;
      float var5 = (float)(var3 >> 16 & 255) / 255.0F;
      float var6 = (float)(var3 >> 8 & 255) / 255.0F;
      float var7 = (float)(var3 & 255) / 255.0F;
      int var8 = (GL11.glIsEnabled(3042));
      int var9 = (GL11.glIsEnabled(2848));
      int var10 = (GL11.glIsEnabled(3553));
      if (var8 == 0) {
         GL11.glEnable(3042);
      }

      if (var9 == 0) {
         GL11.glEnable(2848);
      }

      if (var10 != 0) {
         GL11.glDisable(3553);
      }

      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(var5, var6, var7, var4);
      GL11.glBegin(9);

      for(int var11 = 0; var11 <= 360; ++var11) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var11 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var11 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      if (var10 != 0) {
         GL11.glEnable(3553);
      }

      if (var9 == 0) {
         GL11.glDisable(2848);
      }

      if (var8 == 0) {
         GL11.glDisable(3042);
      }

   }
   public static void drawCircle228(float var0, float var1, float var2, int var3, int var4) {
      float var5 = (float)(var3 >> 24 & 255) / 255.0F;
      float var6 = (float)(var3 >> 16 & 255) / 255.0F;
      float var7 = (float)(var3 >> 8 & 255) / 255.0F;
      float var8 = (float)(var3 & 255) / 255.0F;
      int var9 = (GL11.glIsEnabled(3042));
      int var10 = (GL11.glIsEnabled(2848));
      int var11 = (GL11.glIsEnabled(3553));
      if (var9 == 0) {
         GL11.glEnable(3042);
      }

      if (var10 == 0) {
         GL11.glEnable(2848);
      }

      if (var11 != 0) {
         GL11.glDisable(3553);
      }

      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(var6, var7, var8, var5);
      GL11.glLineWidth(2.5F);
      GL11.glBegin(3);

      for(int var12 = 0; var12 <= var4; ++var12) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var12 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var12 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      if (var11 != 0) {
         GL11.glEnable(3553);
      }

      if (var10 == 0) {
         GL11.glDisable(2848);
      }

      if (var9 == 0) {
         GL11.glDisable(3042);
      }

   }
   public static void drawCircle228(float var0, float var1, float var2, int var3, int var4, int var5, int var6) {
      drawCircle228(var0, var1, var2, var5, var6);
   }
   public static void drawBorderedRect(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
      drawRect((double)var0, (double)var1, (double)var2, (double)var3, var6);
      float var7 = (float)(var5 >> 24 & 255) / 255.0F;
      float var8 = (float)(var5 >> 16 & 255) / 255.0F;
      float var9 = (float)(var5 >> 8 & 255) / 255.0F;
      float var10 = (float)(var5 & 255) / 255.0F;
      glRenderStart();
      GL11.glColor4f(var8, var9, var10, var7);
      GL11.glLineWidth(var4);
      GL11.glEnable(2848);
      GL11.glBegin(1);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glEnd();
      glRenderStop();
   }
   public static void setColor(Color var0) {
      GL11.glColor4d((double)((float)var0.getRed() / 255.0F), (double)((float)var0.getGreen() / 255.0F), (double)((float)var0.getBlue() / 255.0F), (double)((float)var0.getAlpha() / 255.0F));
   }
   public static void drawUnfilledCircle(float var0, float var1, float var2, float var3, int var4) {
      float var5 = (float)(var4 >> 16 & 255) / 255.0F;
      float var6 = (float)(var4 >> 8 & 255) / 255.0F;
      float var7 = (float)(var4 & 255) / 255.0F;
      float var8 = (float)(var4 >> 24 & 255) / 255.0F;
      GL11.glEnable(2848);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      GlStateManager.enableBlend();
      GL11.glColor4f(var5, var6, var7, var8);
      GL11.glLineWidth(var3);
      GL11.glBegin(2);

      for(int var9 = 0; var9 <= 360; ++var9) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var9 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var9 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glEnd();
      GL11.glScalef(2.0F, 2.0F, 2.0F);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
      GlStateManager.disableBlend();
   }
   public static void drawBorderedCircle(float var0, float var1, float var2, int var3, int var4, int var5) {
      drawCircle(var0, var1, var2, var5);
      drawUnfilledCircle(var0, var1, var2, (float)var3, var4);
   }
   public static float convertColor(int var0, int var1) {
      return (float)(var1 >> var0 & 255) / 255.0F;
   }
   public static void drawOctagon(float var0, float var1, float var2, float var3, float var4, float var5, int var6) {
      float var7 = convertColor(24, var6);
      float var8 = convertColor(16, var6);
      float var9 = convertColor(8, var6);
      float var10 = convertColor(0, var6);
      glRenderStart();
      GL11.glColor4f(var8, var9, var10, var7);
      GL11.glBegin(9);
      GL11.glVertex2d((double)(var0 + var4), (double)var1);
      float var10000 = var0 + var2;
      GL11.glVertex2d((double)(var10000 - var4), (double)var1);
      var10000 = var0 + var2;
      GL11.glVertex2d((double)(var10000 - var4), (double)var1);
      double var12 = (double)(var0 + var2);
      float var10001 = var1 + var3 / 2.0F;
      GL11.glVertex2d(var12, (double)(var10001 - var5));
      var12 = (double)(var0 + var2);
      var10001 = var1 + var3 / 2.0F;
      GL11.glVertex2d(var12, (double)(var10001 - var5));
      GL11.glVertex2d((double)(var0 + var2), (double)(var1 + var3 / 2.0F + var5));
      GL11.glVertex2d((double)(var0 + var2), (double)(var1 + var3 / 2.0F + var5));
      float var14 = var0 + var2;
      GL11.glVertex2d((double)(var14 - var4), (double)(var1 + var3));
      var14 = var0 + var2;
      GL11.glVertex2d((double)(var14 - var4), (double)(var1 + var3));
      GL11.glVertex2d((double)(var0 + var4), (double)(var1 + var3));
      GL11.glVertex2d((double)(var0 + var4), (double)(var1 + var3));
      GL11.glVertex2d((double)var0, (double)(var1 + var3 / 2.0F + var5));
      GL11.glVertex2d((double)var0, (double)(var1 + var3 / 2.0F + var5));
      double var16 = (double)var0;
      var10001 = var1 + var3 / 2.0F;
      GL11.glVertex2d(var16, (double)(var10001 - var5));
      var16 = (double)var0;
      var10001 = var1 + var3 / 2.0F;
      GL11.glVertex2d(var16, (double)(var10001 - var5));
      GL11.glVertex2d((double)(var0 + var4), (double)var1);
      GL11.glEnd();
      glRenderStop();
   }
   public static void drawLinesAroundPlayer(Entity var0, double var1, float var3, int var4, double var5, int var7, float var8) {
      GL11.glPushMatrix();
      enableGL2D3();
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glDisable(2929);
      GL11.glLineWidth((float)var5);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2929);
      GL11.glBegin(3);
      RenderManager var9 = Minecraft.getMinecraft().getRenderManager();
      double var10000 = var0.lastTickPosX;
      double var10001 = var0.posX;
      double var10002 = var0.lastTickPosX;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var9.viewerPosX;
      double var10 = var10000 - var10001;
      var10000 = var0.lastTickPosY;
      var10001 = var0.posY;
      var10002 = var0.lastTickPosY;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var9.viewerPosY;
      double var12 = var10000 - var10001 + (double)var8;
      var10000 = var0.lastTickPosZ;
      var10001 = var0.posZ;
      var10002 = var0.lastTickPosZ;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var9.viewerPosZ;
      double var14 = var10000 - var10001;
      color228(var7);

      for(int var16 = 0; var16 <= var4; ++var16) {
         GL11.glVertex3d(var10 + var1 * Math.cos((double)var16 * (Math.PI * 2D) / (double)var4), var12, var14 + var1 * Math.sin((double)var16 * (Math.PI * 2D) / (double)var4));
      }

      GL11.glEnd();
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      disableGL2D3();
      GL11.glPopMatrix();
   }
   public static void renderItem(ItemStack var0, int var1, int var2) {
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.enableDepth();
      RenderHelper.enableGUIStandardItemLighting();
      mc.getRenderItem().renderItemAndEffectIntoGUI(var0, var1, var2);
      mc.getRenderItem().renderItemOverlays(mc.fontRenderer, var0, var1, var2);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.disableDepth();
   }
   public static void drawRectWithEdge(double var0, double var2, double var4, double var6, Color var8, Color var9) {
      drawRect(var0, var2, var0 + var4, var2 + var6, var8.getRGB());
      int var10 = var9.getRGB();
      drawRect(var0 - (double)1.0F, var2, var0, var2 + var6, var10);
      drawRect(var0 + var4, var2, var0 + var4 + (double)1.0F, var2 + var6, var10);
      double var10000 = var0 - (double)1.0F;
      drawRect(var10000, var2 - (double)1.0F, var0 + var4 + (double)1.0F, var2, var10);
      drawRect(var0 - (double)1.0F, var2 + var6, var0 + var4 + (double)1.0F, var2 + var6 + (double)1.0F, var10);
   }
   public static void drawRoundedRect(double var0, double var2, double var4, double var6, int var8, int var9) {
      double var10000 = var0 + (double)0.5F;
      drawRect(var10000, var2, var4 - (double)0.5F, var2 + (double)0.5F, var9);
      var10000 = var0 + (double)0.5F;
      double var10001 = var6 - (double)0.5F;
      drawRect(var10000, var10001, var4 - (double)0.5F, var6, var9);
      var10001 = var2 + (double)0.5F;
      drawRect(var0, var10001, var4, var6 - (double)0.5F, var9);
   }
   public static void drawRoundedRect(int var0, int var1, int var2, int var3, int var4) {
      int var5 = var0 + var2;
      int var6 = var1 + var3;
      double var10000 = (double)(var0 + 1);
      double var10001 = (double)var1;
      drawRect(var10000, var10001, (double)(var5 - 1), (double)var6, var4);
      var10000 = (double)var0;
      var10001 = (double)(var1 + 1);
      double var10002 = (double)var5;
      drawRect(var10000, var10001, var10002, (double)(var6 - 1), var4);
   }
   public static void drawBoundingBox(AxisAlignedBB var0) {
      GL11.glBegin(7);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glEnd();
   }
   public static void drawFilledCircle(int var0, int var1, float var2, Color var3, int var4) {
      double var5 = (Math.PI * 2D) / (double)var4;
      GL11.glPushAttrib(8192);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glBegin(6);

      for(int var7 = 0; var7 < var4; ++var7) {
         float var8 = (float)((double)var2 * Math.sin((double)var7 * var5));
         float var9 = (float)((double)var2 * Math.cos((double)var7 * var5));
         GL11.glColor4f((float)var3.getRed() / 255.0F, (float)var3.getGreen() / 255.0F, (float)var3.getBlue() / 255.0F, (float)var3.getAlpha() / 255.0F);
         GL11.glVertex2f((float)var0 + var8, (float)var1 + var9);
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnd();
      GL11.glPopAttrib();
   }
   public static final void drawSmoothRect(float var0, float var1, float var2, float var3, int var4) {
      GL11.glEnable(3042);
      GL11.glEnable(2848);
      drawRect((double)var0, (double)var1, (double)var2, (double)var3, var4);
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      double var10000 = (double)(var0 * 2.0F);
      --var10000;
      double var10001 = (double)(var1 * 2.0F);
      double var10002 = (double)(var0 * 2.0F);
      float var10003 = var3 * 2.0F;
      drawRect(var10000, var10001, var10002, (double)(var10003 - 1.0F), var4);
      var10000 = (double)(var0 * 2.0F);
      float var9 = var1 * 2.0F;
      drawRect(var10000, (double)(var9 - 1.0F), (double)(var2 * 2.0F), (double)(var1 * 2.0F), var4);
      var10000 = (double)(var2 * 2.0F);
      double var10 = (double)(var1 * 2.0F);
      var10002 = (double)(var2 * 2.0F + 1.0F);
      var10003 = var3 * 2.0F;
      drawRect(var10000, var10, var10002, (double)(var10003 - 1.0F), var4);
      var10000 = (double)(var0 * 2.0F);
      float var11 = var3 * 2.0F;
      drawRect(var10000, (double)(var11 - 1.0F), (double)(var2 * 2.0F), (double)(var3 * 2.0F), var4);
      GL11.glDisable(3042);
      GL11.glScalef(2.0F, 2.0F, 2.0F);
   }
   public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4) {
      GL11.glEnable(2848);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glPushMatrix();
      Minecraft.getMinecraft().getTextureManager().bindTexture(var0);
      Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0F, 0.0F, var3, var4, (float)var3, (float)var4);
      disableGL2D();
      GL11.glPopMatrix();
   }
   public static int raindbow(int var0) {
      double var1 = Math.ceil((double)((System.currentTimeMillis() + (long)var0) / 20L));
      var1 %= (double)360.0F;
      return Color.getHSBColor((float)(var1 / (double)360.0F), 0.5F, 1.0F).getRGB();
   }
   public static void drawCircle(float var0, double var1, float var3, int var4, int var5) {
      GL11.glPushMatrix();
      var0 *= 2.0F;
      var1 *= (double)2.0F;
      GlStateManager.glLineWidth(6.0F);
      float var6 = (float)(var5 >> 24 & 255) / 255.0F;
      float var7 = (float)(var5 >> 16 & 255) / 255.0F;
      float var8 = (float)(var5 >> 8 & 255) / 255.0F;
      float var9 = (float)(var5 & 255) / 255.0F;
      float var10 = ((float)Math.PI / 180F);
      float var11 = (float)Math.cos((double)var10);
      float var12 = (float)Math.sin((double)var10);
      float var26 = var3 * 2.0F;
      float var13 = var26;
      float var14 = 0.0F;
      GL11.glEnable(2848);
      enableGL2D();
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      GL11.glColor4f(var7, var8, var9, var6);
      GL11.glPointSize(6.0F);
      GL11.glBegin(3);
      int[] var27 = new int[1];
      var27[0] = 1;
      int[] var15 = var27;
      int var16 = 0;

      while(true) {
         if (var16 >= 360 - var4) {
            GL11.glEnd();
            GL11.glScalef(2.0F, 2.0F, 2.0F);
            disableGL2D();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.glLineWidth(1.0F);
            GL11.glPopMatrix();
            return;
         }

         var5 = raindbow(var15[0] * 10);
         var6 = (float)(var5 >> 24 & 255) / 255.0F;
         var7 = (float)(var5 >> 16 & 255) / 255.0F;
         var8 = (float)(var5 >> 8 & 255) / 255.0F;
         var9 = (float)(var5 & 255) / 255.0F;
         GL11.glColor4f(var7, var8, var9, var6);
         GL11.glVertex2f(var13 + var0, (float)((double)var14 + var1));
         float var17 = var13;
         float var28 = var11 * var13;
         float var34 = var12 * var14;
         var13 = var28 - var34;
         var14 = var12 * var17 + var11 * var14;
         int var36 = var15[0]++;
         ++var16;
      }
   }
   public static void prepareScissorBox(float var0, float var1, float var2, float var3) {
      ScaledResolution var4 = new ScaledResolution(Minecraft.getMinecraft());
      int var5 = var4.getScaleFactor();
      int var10000 = (int)(var0 * (float)var5);
      float var8 = (float)var4.getScaledHeight();
      int var9 = (int)((var8 - var3) * (float)var5);
      int var10 = (int)((var2 - var0) * (float)var5);
      GL11.glScissor(var10000, var9, var10, (int)((var3 - var1) * (float)var5));
   }
   public static void drawGradientSideways(double var0, double var2, double var4, double var6, int var8, int var9) {
      float var10 = (float)(var8 >> 24 & 255) / 255.0F;
      float var11 = (float)(var8 >> 16 & 255) / 255.0F;
      float var12 = (float)(var8 >> 8 & 255) / 255.0F;
      float var13 = (float)(var8 & 255) / 255.0F;
      float var14 = (float)(var9 >> 24 & 255) / 255.0F;
      float var15 = (float)(var9 >> 16 & 255) / 255.0F;
      float var16 = (float)(var9 >> 8 & 255) / 255.0F;
      float var17 = (float)(var9 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(var11, var12, var13, var10);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glColor4f(var15, var16, var17, var14);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }
   public static void drawPolygonPart(double var0, double var2, int var4, int var5, int var6, int var7) {
      float var8 = (float)(var6 >> 24 & 255) / 255.0F;
      float var9 = (float)(var6 >> 16 & 255) / 255.0F;
      float var10 = (float)(var6 >> 8 & 255) / 255.0F;
      float var11 = (float)(var6 & 255) / 255.0F;
      float var12 = (float)(var7 >> 24 & 255) / 255.0F;
      float var13 = (float)(var7 >> 16 & 255) / 255.0F;
      float var14 = (float)(var7 >> 8 & 255) / 255.0F;
      float var15 = (float)(var7 & 255) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var16 = Tessellator.getInstance();
      BufferBuilder var17 = var16.getBuffer();
      var17.begin(6, DefaultVertexFormats.POSITION_COLOR);
      var17.pos(var0, var2, (double)0.0F).color(var9, var10, var11, var8).endVertex();
      double var18 = (Math.PI * 2D);

      for(int var20 = var5 * 90; var20 <= var5 * 90 + 90; ++var20) {
         double var21 = (Math.PI * 2D) * (double)var20 / (double)360.0F + Math.toRadians((double)180.0F);
         var17.pos(var0 + Math.sin(var21) * (double)var4, var2 + Math.cos(var21) * (double)var4, (double)0.0F).color(var13, var14, var15, var12).endVertex();
      }

      var16.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }
   public static void drawVGradientRect(float var0, float var1, float var2, float var3, int var4, int var5) {
      float var6 = (float)(var4 >> 24 & 255) / 255.0F;
      float var7 = (float)(var4 >> 16 & 255) / 255.0F;
      float var8 = (float)(var4 >> 8 & 255) / 255.0F;
      float var9 = (float)(var4 & 255) / 255.0F;
      float var10 = (float)(var5 >> 24 & 255) / 255.0F;
      float var11 = (float)(var5 >> 16 & 255) / 255.0F;
      float var12 = (float)(var5 >> 8 & 255) / 255.0F;
      float var13 = (float)(var5 & 255) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var14 = Tessellator.getInstance();
      BufferBuilder var15 = var14.getBuffer();
      var15.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var15.pos((double)var2, (double)var1, (double)0.0F).color(var7, var8, var9, var6).endVertex();
      var15.pos((double)var0, (double)var1, (double)0.0F).color(var7, var8, var9, var6).endVertex();
      var15.pos((double)var0, (double)var3, (double)0.0F).color(var11, var12, var13, var10).endVertex();
      var15.pos((double)var2, (double)var3, (double)0.0F).color(var11, var12, var13, var10).endVertex();
      var14.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }
   public static Color injectAlpha(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
   }
   public static void drawGlow(double var0, double var2, double var4, double var6, int var8, double var9) {
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      float var18 = (float)((int)var0);
      float var52 = (float)((int)var2);
      float var69 = (float)((int)var4);
      float var10003 = (float)((int)(var2 + (var6 - var2) / (double)2.0F));
      int var10004 = injectAlpha(new Color(var8), 0).getRGB();
      drawVGradientRect(var18, var52, var69, var10003, var10004, injectAlpha(new Color(var8), (int)var9).getRGB());
      var18 = (float)((int)var0);
      var52 = (float)((int)(var2 + (var6 - var2) / (double)2.0F));
      var69 = (float)((int)var4);
      var10003 = (float)((int)var6);
      var10004 = injectAlpha(new Color(var8), (int)var9).getRGB();
      drawVGradientRect(var18, var52, var69, var10003, var10004, injectAlpha(new Color(var8), 0).getRGB());
      int var11 = (int)((var6 - var2) / (double)2.0F);
      double var54 = var2 + (var6 - var2) / (double)2.0F;
      var10004 = injectAlpha(new Color(var8), (int)var9).getRGB();
      drawPolygonPart(var0, var54, var11, 0, var10004, injectAlpha(new Color(var8), 0).getRGB());
      var54 = var2 + (var6 - var2) / (double)2.0F;
      var10004 = injectAlpha(new Color(var8), (int)var9).getRGB();
      drawPolygonPart(var0, var54, var11, 1, var10004, injectAlpha(new Color(var8), 0).getRGB());
      var54 = var2 + (var6 - var2) / (double)2.0F;
      var10004 = injectAlpha(new Color(var8), (int)var9).getRGB();
      drawPolygonPart(var4, var54, var11, 2, var10004, injectAlpha(new Color(var8), 0).getRGB());
      var54 = var2 + (var6 - var2) / (double)2.0F;
      var10004 = injectAlpha(new Color(var8), (int)var9).getRGB();
      drawPolygonPart(var4, var54, var11, 3, var10004, injectAlpha(new Color(var8), 0).getRGB());
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }
   public static void enableGL2D() {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
   }
   public static void disableGL2D() {
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }
   public static void relativeRect(float var0, float var1, float var2, float var3, int var4) {
      if (var0 < var2) {
         float var5 = var0;
         var0 = var2;
         var2 = var5;
      }

      if (var1 < var3) {
         float var11 = var1;
         var1 = var3;
         var3 = var11;
      }

      float var12 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var8 = (float)(var4 & 255) / 255.0F;
      Tessellator var9 = Tessellator.getInstance();
      BufferBuilder var10 = var9.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(var6, var7, var8, var12);
      var10.begin(7, DefaultVertexFormats.POSITION);
      var10.pos((double)var0, (double)var3, (double)0.0F).endVertex();
      var10.pos((double)var2, (double)var3, (double)0.0F).endVertex();
      var10.pos((double)var2, (double)var1, (double)0.0F).endVertex();
      var10.pos((double)var0, (double)var1, (double)0.0F).endVertex();
      var9.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static void drawBorderedRect(double var0, double var2, double var4, double var6, double var8, int var10, int var11, boolean var12) {
      double var10001 = !var12 ? var8 : (double)0.0F;
      double var10000 = var0 - var10001;
      double var10002 = !var12 ? var8 : (double)0.0F;
      drawRect(var10000, var2 - var10002, var4 + (!var12 ? var8 : (double)0.0F), var6 + (!var12 ? var8 : (double)0.0F), var11);
      var10000 = var0 + (var12 ? var8 : (double)0.0F);
      var10001 = var2 + (var12 ? var8 : (double)0.0F);
      double var10003 = var12 ? var8 : (double)0.0F;
      var10002 = var4 - var10003;
      double var10004 = var12 ? var8 : (double)0.0F;
      drawRect(var10000, var10001, var10002, var6 - var10004, var10);
   }
   public static void drawRect(double var0, double var2, double var4, double var6, int var8) {
      if (var0 < var4) {
         double var9 = var0;
         var0 = var4;
         var4 = var9;
      }

      if (var2 < var6) {
         double var15 = var2;
         var2 = var6;
         var6 = var15;
      }

      float var16 = (float)(var8 >> 24 & 255) / 255.0F;
      float var10 = (float)(var8 >> 16 & 255) / 255.0F;
      float var11 = (float)(var8 >> 8 & 255) / 255.0F;
      float var12 = (float)(var8 & 255) / 255.0F;
      Tessellator var13 = Tessellator.getInstance();
      BufferBuilder var14 = var13.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(var10, var11, var12, var16);
      var14.begin(7, DefaultVertexFormats.POSITION);
      var14.pos(var0, var6, (double)0.0F).endVertex();
      var14.pos(var4, var6, (double)0.0F).endVertex();
      var14.pos(var4, var2, (double)0.0F).endVertex();
      var14.pos(var0, var2, (double)0.0F).endVertex();
      var13.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static void drawRectOpacity(double var0, double var2, double var4, double var6, float var8) {
      if (var0 < var4) {
         double var9 = var0;
         var0 = var4;
         var4 = var9;
      }

      if (var2 < var6) {
         double var11 = var2;
         var2 = var6;
         var6 = var11;
      }

      Tessellator var12 = Tessellator.getInstance();
      BufferBuilder var10 = var12.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(0.1F, 0.1F, 0.1F, var8);
      var10.begin(7, DefaultVertexFormats.POSITION);
      var10.pos(var0, var6, (double)0.0F).endVertex();
      var10.pos(var4, var6, (double)0.0F).endVertex();
      var10.pos(var4, var2, (double)0.0F).endVertex();
      var10.pos(var0, var2, (double)0.0F).endVertex();
      var12.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static void drawNewRect(double var0, double var2, double var4, double var6, int var8) {
      if (var0 < var4) {
         double var9 = var0;
         var0 = var4;
         var4 = var9;
      }

      if (var2 < var6) {
         double var15 = var2;
         var2 = var6;
         var6 = var15;
      }

      float var16 = (float)(var8 >> 24 & 255) / 255.0F;
      float var10 = (float)(var8 >> 16 & 255) / 255.0F;
      float var11 = (float)(var8 >> 8 & 255) / 255.0F;
      float var12 = (float)(var8 & 255) / 255.0F;
      Tessellator var13 = Tessellator.getInstance();
      BufferBuilder var14 = var13.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.color(var10, var11, var12, var16);
      var14.begin(7, DefaultVertexFormats.POSITION);
      var14.pos(var0, var6, (double)0.0F).endVertex();
      var14.pos(var4, var6, (double)0.0F).endVertex();
      var14.pos(var4, var2, (double)0.0F).endVertex();
      var14.pos(var0, var2, (double)0.0F).endVertex();
      var13.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static boolean isInViewFrustrum(Entity var0) {
      return (isInViewFrustrum(var0.getEntityBoundingBox())) != 0 || var0.ignoreFrustumCheck;
   }
   public static void drawLinesAroundPlayer(Entity var0, double var1, float var3, int var4, float var5, int var6) {
      GL11.glPushMatrix();
      enableGL2D3();
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glDisable(2929);
      GL11.glLineWidth(var5);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2929);
      GL11.glBegin(3);
      RenderManager var7 = Minecraft.getMinecraft().getRenderManager();
      double var10000 = var0.lastTickPosX;
      double var10001 = var0.posX;
      double var10002 = var0.lastTickPosX;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var7.viewerPosX;
      double var8 = var10000 - var10001;
      var10000 = var0.lastTickPosY;
      var10001 = var0.posY;
      var10002 = var0.lastTickPosY;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var7.viewerPosY;
      double var10 = var10000 - var10001;
      var10000 = var0.lastTickPosZ;
      var10001 = var0.posZ;
      var10002 = var0.lastTickPosZ;
      var10000 += (var10001 - var10002) * (double)var3;
      var10001 = var7.viewerPosZ;
      double var12 = var10000 - var10001;
      color228(var6);

      for(int var14 = 0; var14 <= var4; ++var14) {
         GL11.glVertex3d(var8 + var1 * Math.cos((double)var14 * (Math.PI * 2D) / (double)var4), var10, var12 + var1 * Math.sin((double)var14 * (Math.PI * 2D) / (double)var4));
      }

      GL11.glEnd();
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      disableGL2D3();
      GL11.glPopMatrix();
   }
   public static void enableGL2D3() {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
   }
   public static void disableGL2D3() {
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }
   public static void color228(int var0) {
      GL11.glColor4ub((byte)(var0 >> 16 & 255), (byte)(var0 >> 8 & 255), (byte)(var0 & 255), (byte)(var0 >> 24 & 255));
   }
   public static boolean isInViewFrustrum(AxisAlignedBB var0) {
      Entity var1 = mc.getRenderViewEntity();
      frustrum.setPosition(var1.posX, var1.posY, var1.posZ);
      return (boolean)(frustrum.isBoundingBoxInFrustum(var0));
   }
   public static void glColor(int var0) {
      float var1 = (float)(var0 >> 24 & 255) / 255.0F;
      float var2 = (float)(var0 >> 16 & 255) / 255.0F;
      float var3 = (float)(var0 >> 8 & 255) / 255.0F;
      float var4 = (float)(var0 & 255) / 255.0F;
      GL11.glColor4f(var2, var3, var4, var1);
   }
   public static void blockEsp(BlockPos var0, Color var1, double var2, double var4) {
      double var6 = (double)var0.getX();
      double var22 = mc.getRenderManager().viewerPosX;
      double var8 = var6 - var22;
      double var10 = (double)var0.getY();
      Minecraft.getMinecraft().getRenderManager();
      var22 = mc.getRenderManager().viewerPosY;
      double var12 = var10 - var22;
      double var14 = (double)var0.getZ();
      Minecraft.getMinecraft().getRenderManager();
      var22 = mc.getRenderManager().viewerPosZ;
      double var16 = var14 - var22;
      GL11.glPushMatrix();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(2.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4d((double)((float)var1.getRed() / 255.0F), (double)((float)var1.getGreen() / 255.0F), (double)((float)var1.getBlue() / 255.0F), 0.15);
      drawColorBox(new AxisAlignedBB(var8, var12, var16, var8 + var4, var12 + (double)1.0F, var16 + var2), 0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glColor4d((double)0.0F, (double)0.0F, (double)0.0F, (double)0.5F);
      drawSelectionBoundingBox(new AxisAlignedBB(var8, var12, var16, var8 + var4, var12 + (double)1.0F, var16 + var2));
      GL11.glLineWidth(2.0F);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }
   public static void blockEspFrame(BlockPos var0, double var1, double var3, double var5) {
      double var7 = (double)var0.getX();
      double var20 = mc.getRenderManager().viewerPosX;
      double var9 = var7 - var20;
      double var11 = (double)var0.getY();
      Minecraft.getMinecraft().getRenderManager();
      var20 = mc.getRenderManager().viewerPosY;
      double var13 = var11 - var20;
      double var15 = (double)var0.getZ();
      Minecraft.getMinecraft().getRenderManager();
      var20 = mc.getRenderManager().viewerPosZ;
      double var17 = var15 - var20;
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(1.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4d(var1, var3, var5, (double)0.5F);
      drawSelectionBoundingBox(new AxisAlignedBB(var9, var13, var17, var9 + (double)1.0F, var13 + (double)1.0F, var17 + (double)1.0F));
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
   }
   public static void drawSelectionBoundingBox(AxisAlignedBB var0) {
      Tessellator var1 = Tessellator.getInstance();
      BufferBuilder var2 = var1.getBuffer();
      var2.begin(3, DefaultVertexFormats.POSITION);
      var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var1.draw();
      var2.begin(3, DefaultVertexFormats.POSITION);
      var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var1.draw();
      var2.begin(1, DefaultVertexFormats.POSITION);
      var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
      var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
      var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
      var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
      var1.draw();
   }
   public static void drawColorBox(AxisAlignedBB var0, float var1, float var2, float var3, float var4) {
      Tessellator var5 = Tessellator.getInstance();
      BufferBuilder var6 = var5.getBuffer();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos(var0.minX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.minX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.minZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.maxY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var6.pos(var0.maxX, var0.minY, var0.maxZ).color(var1, var2, var3, var4).endVertex();
      var5.draw();
   }
   public static void rectangleBordered(double var0, double var2, double var4, double var6, double var8, int var10, int var11) {
      double var10000 = var0 + var8;
      double var10001 = var2 + var8;
      double var10002 = var4 - var8;
      drawRect(var10000, var10001, var10002, var6 - var8, var10);
      var10000 = var0 + var8;
      drawRect(var10000, var2, var4 - var8, var2 + var8, var11);
      drawRect(var0, var2, var0 + var8, var6, var11);
      drawRect(var4 - var8, var2, var4, var6, var11);
      var10000 = var0 + var8;
      var10001 = var6 - var8;
      drawRect(var10000, var10001, var4 - var8, var6, var11);
   }

   static {
      
      frustrum = new Frustum();
   }
   

   
}
