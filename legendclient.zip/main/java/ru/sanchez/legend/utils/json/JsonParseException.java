package ru.sanchez.legend.utils.json;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class JsonParseException extends Exception {
    
   public static final long serialVersionUID = -7880698968187728547L;
    
   public static final int ERROR_UNEXPECTED_CHAR = 0;
    
   public static final int ERROR_UNEXPECTED_TOKEN = 1;
    
   public static final int ERROR_UNEXPECTED_EXCEPTION = 2;
    
   public int errorType;
    
   public Object unexpectedObject;
    
   public int position;

   public JsonParseException(int var1) {
      this(-1, var1, (Object)null);
   }

   public JsonParseException(int var1, Object var2) {
      this(-1, var1, var2);
   }

   public JsonParseException(int var1, int var2, Object var3) {
      this.position = var1;
      this.errorType = var2;
      this.unexpectedObject = var3;
   }

   public int getErrorType() {
      return this.errorType;
   }

   public void setErrorType(int var1) {
      this.errorType = var1;
   }

   public int getPosition() {
      return this.position;
   }

   public void setPosition(int var1) {
      this.position = var1;
   }

   public Object getUnexpectedObject() {
      return this.unexpectedObject;
   }

   public void setUnexpectedObject(Object var1) {
      this.unexpectedObject = var1;
   }

   public String getMessage() {
      StringBuffer var1 = new StringBuffer();
      switch (this.errorType) {
         case 0:
            var1.append("Unexpe3\u001a\r\u5de6\u665b\u3795\u325c\u07f5\u3a1f\u1d9a\u3562\u16e3\u38a5\u3f96\u30bd\u33af").append(this.unexpectedObject).append(") at p?\u001d\u0001\u5df6\u6612\u3799\u325a\u07b4").append(this.position).append(".");
            break;
         case 1:
            var1.append("Unexpe3\u001a\r\u5de6\u665b\u3782\u325b\u07ff\u3a08\u1d95\u3521").append(this.unexpectedObject).append(" at po#\u0007\u001c\u5deb\u6614\u3798\u3214").append(this.position).append(".");
            break;
         case 2:
            var1.append("Unexpe3\u001a\r\u5de6\u665b\u3793\u324c\u07f7\u3a08\u1d8b\u3575\u16fe\u38af\u3f8a\u30bd\u33e6\u0bfe\u3e3d\u0521\u09c2\u0675\u07f0\u07bf\u3069\u3c3e\u1a13\u3a56").append(this.position).append(": ").append(this.unexpectedObject);
            break;
         default:
            var1.append("Unkownp\u000b\u001a\u5df0\u6614\u3784\u3214\u07f5\u3a19\u1ddb\u3571\u16f8\u38b3\u3f8d\u30e9\u33ee\u0be5\u3e73\u0571").append(this.position).append(".");
      }

      return var1.toString();
   }
   

   
}
