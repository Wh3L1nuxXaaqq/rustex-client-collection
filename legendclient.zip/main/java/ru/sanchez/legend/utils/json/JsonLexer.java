package ru.sanchez.legend.utils.json;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

 
public class JsonLexer {
    
   public static final int YYEOF = -1;
    
   public static final int ZZ_BUFFERSIZE = 16384;
    
   public static final int YYINITIAL = 0;
    
   public static final int STRING_BEGIN = 2;
    
   public static final int[] ZZ_LEXSTATE;
    
   public static final String ZZ_CMAP_PACKED = "\t\u0000\u0001\u0007\u0001\u0007\u0002\u0000\u0001\u0007\u0012\u0000\u0001\u0007\u0001\u0000\u0001\t\b\u0000\u0001\u0006\u0001\u0019\u0001\u0002\u0001\u0004\u0001\n\n\u0003\u0001\u001a\u0006\u0000\u0004\u0001\u0001\u0005\u0001\u0001\u0014\u0000\u0001\u0017\u0001\b\u0001\u0018\u0003\u0000\u0001\u0012\u0001\u000b\u0002\u0001\u0001\u0011\u0001\f\u0005\u0000\u0001\u0013\u0001\u0000\u0001\r\u0003\u0000\u0001\u000e\u0001\u0014\u0001\u000f\u0001\u0010\u0005\u0000\u0001\u0015\u0001\u0000\u0001\u0016ﾂ\u0000";
    
   public static final char[] ZZ_CMAP;
    
   public static final int[] ZZ_ACTION;
    
   public static final String ZZ_ACTION_PACKED_0 = "\u0002\u0000\u0002\u0001\u0001\u0002\u0001\u0003\u0001\u0004\u0003\u0001\u0001\u0005\u0001\u0006\u0001\u0007\u0001\b\u0001\t\u0001\n\u0001\u000b\u0001\f\u0001\r\u0005\u0000\u0001\f\u0001\u000e\u0001\u000f\u0001\u0010\u0001\u0011\u0001\u0012\u0001\u0013\u0001\u0014\u0001\u0000\u0001\u0015\u0001\u0000\u0001\u0015\u0004\u0000\u0001\u0016\u0001\u0017\u0002\u0000\u0001\u0018";
    
   public static final int[] ZZ_ROWMAP;
    
   public static final String ZZ_ROWMAP_PACKED_0 = "\u0000\u0000\u0000\u001b\u00006\u0000Q\u0000l\u0000\u0087\u00006\u0000¢\u0000½\u0000Ø\u00006\u00006\u00006\u00006\u00006\u00006\u0000ó\u0000Ď\u00006\u0000ĩ\u0000ń\u0000ş\u0000ź\u0000ƕ\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u0000ư\u0000ǋ\u0000Ǧ\u0000Ǧ\u0000ȁ\u0000Ȝ\u0000ȷ\u0000ɒ\u00006\u00006\u0000ɭ\u0000ʈ\u00006";
    
   public static final int[] ZZ_TRANS;
    
   public static final int ZZ_UNKNOWN_ERROR = 0;
    
   public static final int ZZ_NO_MATCH = 1;
    
   public static final int ZZ_PUSHBACK_2BIG = 2;
    
   public static final String[] ZZ_ERROR_MSG;
    
   public static final int[] ZZ_ATTRIBUTE;
    
   public static final String ZZ_ATTRIBUTE_PACKED_0 = "\u0002\u0000\u0001\t\u0003\u0001\u0001\t\u0003\u0001\u0006\t\u0002\u0001\u0001\t\u0005\u0000\b\t\u0001\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0004\u0000\u0002\t\u0002\u0000\u0001\t";
    
   public Reader zzReader;
    
   public int zzState;
    
   public int zzLexicalState;
    
   public char[] zzBuffer;
    
   public int zzMarkedPos;
    
   public int zzCurrentPos;
    
   public int zzStartRead;
    
   public int zzEndRead;
    
   public int yyline;
    
   public int yychar;
    
   public int yycolumn;
    
   public boolean zzAtBOL;
    
   public boolean zzAtEOF;
    
   public StringBuffer sb;
   public static int[] zzUnpackAction() {
      int[] var0 = new int[45];
      byte var1 = 0;
      zzUnpackAction("\u0002\u0000\u0002\u0001\u0001\u0002\u0001\u0003\u0001\u0004\u0003\u0001\u0001\u0005\u0001\u0006\u0001\u0007\u0001\u0008\u0001\t\u0001\n\u0001\u000b\u0001\u000c\u0001\r\u0005\u0000\u0001\u000c\u0001\u000e\u0001\u000f\u0001\u0010\u0001\u0011\u0001\u0012\u0001\u0013\u0001\u0014\u0001\u0000\u0001\u0015\u0001\u0000\u0001\u0015\u0004\u0000\u0001\u0016\u0001\u0017\u0002\u0000\u0001\u0018", var1, var0);
      return var0;
   }
   public static int zzUnpackAction(String var0, int var1, int[] var2) {
      int var3 = 0;
      int var4 = var1;

      int var6;
      for(int var5 = var0.length(); var3 < var5; --var6) {
         var6 = var0.charAt(var3++);
         char var7 = var0.charAt(var3++);

         while(true) {
            var2[var4++] = var7;
            if (var6 <= 0) {
               break;
            }
         }
      }

      return var4;
   }
   public static int[] zzUnpackRowMap() {
      int[] var0 = new int[45];
      byte var1 = 0;
      zzUnpackRowMap("\u0000\u0000\u0000\u001b\u00006\u0000Q\u0000l\u0000\u0087\u00006\u0000\u00a2\u0000\u00bd\u0000\u00d8\u00006\u00006\u00006\u00006\u00006\u00006\u0000\u00f3\u0000\u010e\u00006\u0000\u0129\u0000\u0144\u0000\u015f\u0000\u017a\u0000\u0195\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u0000\u01b0\u0000\u01cb\u0000\u01e6\u0000\u01e6\u0000\u0201\u0000\u021c\u0000\u0237\u0000\u0252\u00006\u00006\u0000\u026d\u0000\u0288\u00006", var1, var0);
      return var0;
   }
   public static int zzUnpackRowMap(String var0, int var1, int[] var2) {
      int var3 = 0;
      int var4 = var1;

      int var6;
      for(int var5 = var0.length(); var3 < var5; var2[var4++] = var6 | var0.charAt(var3++)) {
         var6 = var0.charAt(var3++) << 16;
      }

      return var4;
   }
   public static int[] zzUnpackAttribute() {
      int[] var0 = new int[45];
      byte var1 = 0;
      zzUnpackAttribute("\u0002\u0000\u0001\t\u0003\u0001\u0001\t\u0003\u0001\u0006\t\u0002\u0001\u0001\t\u0005\u0000\u0008\t\u0001\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0004\u0000\u0002\t\u0002\u0000\u0001\t", var1, var0);
      return var0;
   }
   public static int zzUnpackAttribute(String var0, int var1, int[] var2) {
      int var3 = 0;
      int var4 = var1;

      int var6;
      for(int var5 = var0.length(); var3 < var5; --var6) {
         var6 = var0.charAt(var3++);
         char var7 = var0.charAt(var3++);

         while(true) {
            var2[var4++] = var7;
            if (var6 <= 0) {
               break;
            }
         }
      }

      return var4;
   }

   public int getPosition() {
      return this.yychar;
   }

   public JsonLexer(Reader var1) {
      this.zzLexicalState = 0;
      this.zzBuffer = new char[16384];
      this.zzAtBOL = true;
      this.sb = new StringBuffer();
      this.zzReader = var1;
   }

   public JsonLexer(InputStream var1) {
      this((Reader)(new InputStreamReader(var1)));
   }
   public static char[] zzUnpackCMap(String var0) {
      char[] var1 = new char[65536];
      int var2 = 0;

      int var4;
      for(int var3 = 0; var2 < 90; --var4) {
         var4 = var0.charAt(var2++);
         char var5 = var0.charAt(var2++);

         while(true) {
            var1[var3++] = var5;
            if (var4 <= 0) {
               break;
            }
         }
      }

      return var1;
   }

   public boolean zzRefill() throws IOException {
      if (this.zzStartRead > 0) {
         char[] var7 = this.zzBuffer;
         int var21 = this.zzStartRead;
         char[] var30 = this.zzBuffer;
         int var10004 = this.zzEndRead;
         int var10005 = this.zzStartRead;
         System.arraycopy(var7, var21, var30, 0, var10004 - var10005);
         var21 = this.zzEndRead;
         int var31 = this.zzStartRead;
         this.zzEndRead = var21 - var31;
         var21 = this.zzCurrentPos;
         var31 = this.zzStartRead;
         this.zzCurrentPos = var21 - var31;
         var21 = this.zzMarkedPos;
         var31 = this.zzStartRead;
         this.zzMarkedPos = var21 - var31;
         this.zzStartRead = 0;
      }

      if (this.zzCurrentPos >= this.zzBuffer.length) {
         char[] var1 = new char[this.zzCurrentPos * 2];
         System.arraycopy(this.zzBuffer, 0, var1, 0, this.zzBuffer.length);
         this.zzBuffer = var1;
      }

      Reader var8 = this.zzReader;
      char[] var25 = this.zzBuffer;
      int var34 = this.zzEndRead;
      int var10003 = this.zzBuffer.length;
      int var35 = this.zzEndRead;
      int var3 = var8.read(var25, var34, var10003 - var35);
      if (var3 > 0) {
         this.zzEndRead += var3;
         return false;
      } else if (var3 == 0) {
         int var2 = this.zzReader.read();
         if (var2 == -1) {
            return true;
         } else {
            char[] var9 = this.zzBuffer;
            var9[this.zzEndRead++] = (char)var2;
            return false;
         }
      } else {
         return true;
      }
   }

   public final void yyclose() throws IOException {
      this.zzAtEOF = true;
      this.zzEndRead = this.zzStartRead;
      if (this.zzReader != null) {
         this.zzReader.close();
      }

   }

   public final void yyreset(Reader var1) {
      this.zzReader = var1;
      this.zzAtBOL = true;
      this.zzAtEOF = false;
      this.zzEndRead = this.zzStartRead = 0;
      this.zzCurrentPos = this.zzMarkedPos = 0;
      this.yyline = this.yychar = this.yycolumn = 0;
      this.zzLexicalState = 0;
   }

   public final int yystate() {
      return this.zzLexicalState;
   }

   public final void yybegin(int var1) {
      this.zzLexicalState = var1;
   }

   public final String yytext() {
      char[] var3 = this.zzBuffer;
      int var10003 = this.zzStartRead;
      int var10004 = this.zzMarkedPos;
      int var10005 = this.zzStartRead;
      return new String(var3, var10003, var10004 - var10005);
   }

   public final char yycharat(int var1) {
      return this.zzBuffer[this.zzStartRead + var1];
   }

   public final int yylength() {
      int var10000 = this.zzMarkedPos;
      int var10001 = this.zzStartRead;
      return var10000 - var10001;
   }

   public void zzScanError(int var1) {

      String var2;
      try {
         var2 = ZZ_ERROR_MSG[var1];
      } catch (ArrayIndexOutOfBoundsException var4) {
         var2 = ZZ_ERROR_MSG[0];
      }
      Error var5 = new Error(var2);
      throw var5;
   }

   public void yypushback(int var1) {
      if (var1 > this.yylength()) {
         this.zzScanError(2);
      }
      int var3 = this.zzMarkedPos;
      this.zzMarkedPos = var3 - var1;
   }

   public JsonToken yylex() throws IOException, JsonParseException {
      int var5 = this.zzEndRead;
      char[] var6 = this.zzBuffer;
      char[] var7 = ZZ_CMAP;
      int[] var8 = ZZ_TRANS;
      int[] var9 = ZZ_ROWMAP;
      int[] var10 = ZZ_ATTRIBUTE;

      while(true) {
         int var4 = this.zzMarkedPos;
         int var72 = this.yychar;
         int var10003 = this.zzStartRead;
         this.yychar = var72 + (var4 - var10003);
         int var2 = -1;
         int var14 = this.zzCurrentPos = this.zzStartRead = var4;
         this.zzState = ZZ_LEXSTATE[this.zzLexicalState];

         int var1;
         while(true) {
            if (var14 < var5) {
               var1 = var6[var14++];
            } else {
               if (this.zzAtEOF) {
                  var1 = -1;
                  break;
               }

               this.zzCurrentPos = var14;
               this.zzMarkedPos = var4;
               int var11 = (this.zzRefill());
               var14 = this.zzCurrentPos;
               var4 = this.zzMarkedPos;
               var6 = this.zzBuffer;
               var5 = this.zzEndRead;
               if (var11 != 0) {
                  var1 = -1;
                  break;
               }

               var1 = var6[var14++];
            }

            int var15 = var8[var9[this.zzState] + var7[var1]];
            if (var15 == -1) {
               break;
            }

            this.zzState = var15;
            int var12 = var10[this.zzState];
            if ((var12 & 1) == 1) {
               var2 = this.zzState;
               var4 = var14;
               if ((var12 & 8) == 8) {
                  break;
               }
            }
         }

         this.zzMarkedPos = var4;
         switch (var2 < 0 ? var2 : ZZ_ACTION[var2]) {
            case 1:
               int var90 = this.yychar;
               JsonParseException var33 = new JsonParseException(var90, 0, new Character(this.yycharat(0)));
               throw var33;
            case 2:
               Long var19 = Long.valueOf(this.yytext());
               return new JsonToken(0, var19);
            case 3:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
               break;
            case 4:
               this.sb = null;
               this.sb = new StringBuffer();
               this.yybegin(2);
               break;
            case 5:
               return new JsonToken(1, (Object)null);
            case 6:
               return new JsonToken(2, (Object)null);
            case 7:
               return new JsonToken(3, (Object)null);
            case 8:
               return new JsonToken(4, (Object)null);
            case 9:
               return new JsonToken(5, (Object)null);
            case 10:
               return new JsonToken(6, (Object)null);
            case 11:
               this.sb.append(this.yytext());
               break;
            case 12:
               this.sb.append('\\');
               break;
            case 13:
               this.yybegin(0);
               return new JsonToken(0, this.sb.toString());
            case 14:
               this.sb.append('"');
               break;
            case 15:
               this.sb.append('/');
               break;
            case 16:
               this.sb.append('\b');
               break;
            case 17:
               this.sb.append('\f');
               break;
            case 18:
               this.sb.append('\n');
               break;
            case 19:
               this.sb.append('\r');
               break;
            case 20:
               this.sb.append('\t');
               break;
            case 21:
               Double var18 = Double.valueOf(this.yytext());
               return new JsonToken(0, var18);
            case 22:
               return new JsonToken(0, (Object)null);
            case 23:
               Boolean var17 = Boolean.valueOf(this.yytext());
               return new JsonToken(0, var17);
            case 24:
               try {
                  int var16 = Integer.parseInt(this.yytext().substring(2), 16);
                  this.sb.append((char)var16);
                  break;
               } catch (Exception var13) {
                  JsonParseException var32 = new JsonParseException(this.yychar, 2, var13);
                  throw var32;
               }
            default:
               if (var1 == -1 && this.zzStartRead == this.zzCurrentPos) {
                  this.zzAtEOF = true;
                  return null;
               }

               this.zzScanError(1);
         }
      }
   }

   static {
      
      ZZ_LEXSTATE = new int[]{0, 0, 1, 1};
      ZZ_CMAP = zzUnpackCMap("\t\u0000\u0001\u0007\u0001\u0007\u0002\u0000\u0001\u0007\u0012\u0000\u0001\u0007\u0001\u0000\u0001\t\u0008\u0000\u0001\u0006\u0001\u0019\u0001\u0002\u0001\u0004\u0001\n\n\u0003\u0001\u001a\u0006\u0000\u0004\u0001\u0001\u0005\u0001\u0001\u0014\u0000\u0001\u0017\u0001\u0008\u0001\u0018\u0003\u0000\u0001\u0012\u0001\u000b\u0002\u0001\u0001\u0011\u0001\u000c\u0005\u0000\u0001\u0013\u0001\u0000\u0001\r\u0003\u0000\u0001\u000e\u0001\u0014\u0001\u000f\u0001\u0010\u0005\u0000\u0001\u0015\u0001\u0000\u0001\u0016\uff82\u0000");
      ZZ_ACTION = zzUnpackAction();
      ZZ_ROWMAP = zzUnpackRowMap();
      ZZ_TRANS = new int[]{2, 2, 3, 4, 2, 2, 2, 5, 2, 6, 2, 2, 7, 8, 2, 9, 2, 2, 2, 2, 2, 10, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 16, 16, 17, 18, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, 19, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 21, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 22, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 23, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, -1, -1, -1, -1, -1, -1, 24, 25, 26, 27, 28, 29, 30, 31, 32, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 33, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 34, 35, -1, -1, 34, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 37, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 38, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 39, -1, 39, -1, 39, -1, -1, -1, -1, -1, 39, 39, -1, -1, -1, -1, 39, 39, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 33, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 35, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 38, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 40, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 41, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 42, -1, 42, -1, 42, -1, -1, -1, -1, -1, 42, 42, -1, -1, -1, -1, 42, 42, -1, -1, -1, -1, -1, -1, -1, -1, -1, 43, -1, 43, -1, 43, -1, -1, -1, -1, -1, 43, 43, -1, -1, -1, -1, 43, 43, -1, -1, -1, -1, -1, -1, -1, -1, -1, 44, -1, 44, -1, 44, -1, -1, -1, -1, -1, 44, 44, -1, -1, -1, -1, 44, 44, -1, -1, -1, -1, -1, -1, -1, -1};
      ZZ_ERROR_MSG = new String[]{"Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large"};
      ZZ_ATTRIBUTE = zzUnpackAttribute();
   }
   

   
}
