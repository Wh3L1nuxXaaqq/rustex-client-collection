package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

 
public class RotationUtils implements Wrapper {
   public static RotationContext calculateAngles(Vec3d var0) {
      double var3 = Math.toDegrees(Math.atan2(var0.subtract(mc.player.getPositionEyes(1.0F)).z, var0.subtract(mc.player.getPositionEyes(1.0F)).x));
      float var1 = (float)(var3 - (double)90.0F);
      float var2 = (float)Math.toDegrees(-Math.atan2(var0.subtract(mc.player.getPositionEyes(1.0F)).y, Math.hypot(var0.subtract(mc.player.getPositionEyes(1.0F)).x, var0.subtract(mc.player.getPositionEyes(1.0F)).z)));
      return new RotationContext(MathHelper.wrapDegrees(var1), MathHelper.wrapDegrees(var2));
   }
   public static Vec3d getVectorForRotation(RotationContext var0) {
      float var5 = -var0.getYaw() * ((float)Math.PI / 180F);
      float var1 = MathHelper.cos(var5 - (float)Math.PI);
      var5 = -var0.getYaw() * ((float)Math.PI / 180F);
      float var2 = MathHelper.sin(var5 - (float)Math.PI);
      float var3 = -MathHelper.cos(-var0.getPitch() * ((float)Math.PI / 180F));
      float var4 = MathHelper.sin(-var0.getPitch() * ((float)Math.PI / 180F));
      return new Vec3d((double)(var2 * var3), (double)var4, (double)(var1 * var3));
   }
   

   
}
