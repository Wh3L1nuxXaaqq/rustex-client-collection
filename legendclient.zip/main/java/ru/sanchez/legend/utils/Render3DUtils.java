package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

 
public class Render3DUtils {
    
   public static final Frustum frustrum;
    
   public static boolean click;
    
   public float spin;
    
   public float cumSize;
    
   public static final int GL_BLEND;
    
   public static final int GL_DEPTH_TEST;
   public static ResourceLocation drawPic(double var0, double var2, double var4, double var6, ResourceLocation var8) {
      GlStateManager.enableAlpha();
      GlStateManager.disableLighting();
      GlStateManager.disableFog();
      Tessellator var9 = Tessellator.getInstance();
      BufferBuilder var10 = var9.getBuffer();
      Minecraft.getMinecraft().getTextureManager().bindTexture(var8);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      var10.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
      var10.pos(var0, var2 + var6, (double)0.0F).tex((double)0.0F, (double)1.0F).color(255, 255, 255, 255).endVertex();
      var10.pos(var0 + var4, var2 + var6, (double)0.0F).tex((double)1.0F, (double)1.0F).color(255, 255, 255, 255).endVertex();
      var10.pos(var0 + var4, var2, (double)0.0F).tex((double)1.0F, (double)0.0F).color(255, 255, 255, 255).endVertex();
      var10.pos(var0, var2, (double)0.0F).tex((double)0.0F, (double)0.0F).color(255, 255, 255, 255).endVertex();
      var9.draw();
      GlStateManager.disableAlpha();
      return var8;
   }
   public static void drawCircle228(float var0, float var1, float var2, int var3, int var4, float var5) {
      float var6 = (float)(var3 >> 24 & 255) / 255.0F;
      float var7 = (float)(var3 >> 16 & 255) / 255.0F;
      float var8 = (float)(var3 >> 8 & 255) / 255.0F;
      float var9 = (float)(var3 & 255) / 255.0F;
      int var10 = (GL11.glIsEnabled(3042));
      int var11 = (GL11.glIsEnabled(2848));
      int var12 = (GL11.glIsEnabled(3553));
      if (var10 == 0) {
         GL11.glEnable(3042);
      }

      if (var11 == 0) {
         GL11.glEnable(2848);
      }

      if (var12 != 0) {
         GL11.glDisable(3553);
      }

      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(var7, var8, var9, var6);
      GL11.glLineWidth(var5);
      GL11.glBegin(3);

      for(int var13 = 0; var13 <= var4; ++var13) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var13 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var13 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      if (var12 != 0) {
         GL11.glEnable(3553);
      }

      if (var11 == 0) {
         GL11.glDisable(2848);
      }

      if (var10 == 0) {
         GL11.glDisable(3042);
      }

   }
   public static void drawRectStatic(int var0, int var1, int var2, int var3, Color var4) {
      Gui.drawRect(var0, var1, var2, var3, var4.getRGB());
   }
   public static void drawSector2(double var0, double var2, int var4, int var5, int var6) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      GL11.glBegin(6);
      glColor((new Color(0, 0, 0, 100)).getRGB());
      GL11.glVertex2d(var0, var2);
      glColor((new Color(0, 0, 0, 0)).getRGB());

      for(int var7 = var4; var7 <= var5; ++var7) {
         GL11.glVertex2d(var0 + Math.sin((double)var7 * Math.PI / (double)180.0F) * (double)var6, var2 + Math.cos((double)var7 * Math.PI / (double)180.0F) * (double)var6);
      }

      GL11.glEnd();
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      GlStateManager.shadeModel(7424);
   }
   public static void drawESP(Entity var0, float var1, float var2, float var3, float var4, float var5) {
      try {
         double var6 = Wrapper.mc.getRenderManager().viewerPosX;
         double var8 = Wrapper.mc.getRenderManager().viewerPosY;
         double var10 = Wrapper.mc.getRenderManager().viewerPosZ;
         double var10000 = var0.lastTickPosX;
         double var10001 = var0.posX;
         double var10002 = var0.lastTickPosX;
         var10000 += (var10001 - var10002) * (double)var5;
         double var12 = var10000 - var6;
         var10000 = var0.lastTickPosY;
         var10001 = var0.posY;
         var10002 = var0.lastTickPosY;
         var10000 = var10000 + (var10001 - var10002) * (double)var5 + (double)(var0.height / 2.0F);
         double var14 = var10000 - var8;
         var10000 = var0.lastTickPosZ;
         var10001 = var0.posZ;
         var10002 = var0.lastTickPosZ;
         var10000 += (var10001 - var10002) * (double)var5;
         double var16 = var10000 - var10;
         float var18 = Wrapper.mc.getRenderManager().playerViewY;
         float var19 = Wrapper.mc.getRenderManager().playerViewX;
         boolean var20 = Wrapper.mc.getRenderManager().options.thirdPersonView == 2;
         GL11.glPushMatrix();
         GlStateManager.translate(var12, var14, var16);
         GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
         GlStateManager.rotate(-var18, 0.0F, 1.0F, 0.0F);
         GlStateManager.rotate((float)(var20 ? -1 : 1) * var19, 1.0F, 0.0F, 0.0F);
         GL11.glEnable(3042);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         GL11.glLineWidth(1.0F);
         GL11.glBlendFunc(770, 771);
         GL11.glEnable(2848);
         GL11.glColor4f(var1, var2, var3, var4);
         GL11.glBegin(1);
         GL11.glVertex3d((double)0.0F, (double)1.0F, (double)0.0F);
         GL11.glVertex3d((double)-0.5F, (double)0.5F, (double)0.0F);
         GL11.glVertex3d((double)0.0F, (double)1.0F, (double)0.0F);
         GL11.glVertex3d((double)0.5F, (double)0.5F, (double)0.0F);
         GL11.glVertex3d((double)0.0F, (double)0.0F, (double)0.0F);
         GL11.glVertex3d((double)-0.5F, (double)0.5F, (double)0.0F);
         GL11.glVertex3d((double)0.0F, (double)0.0F, (double)0.0F);
         GL11.glVertex3d((double)0.5F, (double)0.5F, (double)0.0F);
         GL11.glEnd();
         GL11.glDepthMask(true);
         GL11.glEnable(2929);
         GL11.glEnable(3553);
         GL11.glEnable(2896);
         GL11.glDisable(2848);
         GL11.glDisable(3042);
         GL11.glPopMatrix();
      } catch (Exception var21) {
         var21.printStackTrace();
      }

   }
   public static void setColor(Color var0) {
      GL11.glColor4d((double)((float)var0.getRed() / 255.0F), (double)((float)var0.getGreen() / 255.0F), (double)((float)var0.getBlue() / 255.0F), (double)((float)var0.getAlpha() / 255.0F));
   }
   public static void drawRect(double var0, double var2, double var4, double var6, int var8) {
      if (var0 < var4) {
         double var9 = var0;
         var0 = var4;
         var4 = var9;
      }

      if (var2 < var6) {
         double var15 = var2;
         var2 = var6;
         var6 = var15;
      }

      float var16 = (float)(var8 >> 24 & 255) / 255.0F;
      float var10 = (float)(var8 >> 16 & 255) / 255.0F;
      float var11 = (float)(var8 >> 8 & 255) / 255.0F;
      float var12 = (float)(var8 & 255) / 255.0F;
      Tessellator var13 = Tessellator.getInstance();
      BufferBuilder var14 = var13.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.color(var10, var11, var12, var16);
      var14.begin(7, DefaultVertexFormats.POSITION);
      var14.pos(var0, var6, (double)0.0F).endVertex();
      var14.pos(var4, var6, (double)0.0F).endVertex();
      var14.pos(var4, var2, (double)0.0F).endVertex();
      var14.pos(var0, var2, (double)0.0F).endVertex();
      var13.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static void customScaledObject2D(float var0, float var1, float var2, float var3, float var4, float var5) {
      GL11.glTranslated((double)(var2 / 2.0F), (double)(var3 / 2.0F), (double)1.0F);
      GL11.glTranslated((double)(-var0 * var4 + var0 + var2 / 2.0F * -var4), (double)(-var1 * var4 + var1 + var3 / 2.0F * -var4), (double)1.0F);
      GL11.glScaled((double)var4, (double)var4, (double)0.0F);
   }
   public static void drawDownShadow(float var0, float var1, float var2, float var3) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      GL11.glBegin(7);
      glColor((new Color(0, 0, 0, 100)).getRGB());
      GL11.glVertex2d((double)var2, (double)var3);
      glColor((new Color(0, 0, 0, 0)).getRGB());
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glVertex2d((double)var0, (double)var1);
      glColor((new Color(0, 0, 0, 100)).getRGB());
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glEnd();
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      GlStateManager.shadeModel(7424);
   }
   public static void drawShadowRect(double var0, double var2, double var4, double var6, int var8) {
      double var44 = (double)var8;
      double var35 = var2 - var44;
      int var10006 = (new Color(0, 0, 0, 100)).getRGB();
      drawGradientRect(var0, var35, var4, var2, false, true, var10006, (new Color(0, 0, 0, 0)).getRGB());
      double var10003 = var6 + (double)var8;
      var10006 = (new Color(0, 0, 0, 100)).getRGB();
      drawGradientRect(var0, var6, var4, var10003, false, false, var10006, (new Color(0, 0, 0, 0)).getRGB());
      drawSector2(var4, var6, 0, 90, var8);
      drawSector2(var4, var2, 90, 180, var8);
      drawSector2(var0, var2, 180, 270, var8);
      drawSector2(var0, var6, 270, 360, var8);
      var35 = (double)var8;
      double var14 = var0 - var35;
      var10006 = (new Color(0, 0, 0, 100)).getRGB();
      drawGradientRect(var14, var2, var0, var6, true, true, var10006, (new Color(0, 0, 0, 0)).getRGB());
      var44 = var4 + (double)var8;
      var10006 = (new Color(0, 0, 0, 100)).getRGB();
      drawGradientRect(var4, var2, var44, var6, true, false, var10006, (new Color(0, 0, 0, 0)).getRGB());
   }
   public static void enableGL2D() {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
   }
   public static void drawGradientRect(double var0, double var2, double var4, double var6, boolean var8, int var9, int var10) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.shadeModel(7425);
      glColor(var9);
      GL11.glBegin(7);
      if (var8) {
         GL11.glVertex2d(var0, var2);
         GL11.glVertex2d(var0, var6);
         glColor(var10);
         GL11.glVertex2d(var4, var6);
         GL11.glVertex2d(var4, var2);
      } else {
         GL11.glVertex2d(var0, var2);
         glColor(var10);
         GL11.glVertex2d(var0, var6);
         GL11.glVertex2d(var4, var6);
         glColor(var9);
         GL11.glVertex2d(var4, var2);
      }

      GL11.glEnd();
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      GlStateManager.shadeModel(7424);
   }
   public static void renderItem(ItemStack var0, int var1, int var2) {
      Minecraft var3 = Minecraft.getMinecraft();
      RenderItem var4 = var3.getRenderItem();
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      RenderHelper.enableStandardItemLighting();
      var4.zLevel = -100.0F;
      var4.renderItemIntoGUI(var0, var1, var2);
      var4.renderItemOverlays(var3.fontRenderer, var0, var1, var2);
      var4.zLevel = 0.0F;
      RenderHelper.disableStandardItemLighting();
      GlStateManager.enableAlpha();
      GlStateManager.disableBlend();
      GlStateManager.disableLighting();
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      GlStateManager.popMatrix();
   }
   public static void setupGuiTransform(int var0, int var1, boolean var2, float var3) {
      GlStateManager.translate((float)var0, (float)var1, 100.0F + var3);
      GlStateManager.translate(8.0F, 8.0F, 0.0F);
      GlStateManager.scale(1.0F, -1.0F, 1.0F);
      GlStateManager.scale(16.0F, 16.0F, 16.0F);
      if (var2) {
         GlStateManager.enableLighting();
      } else {
         GlStateManager.disableLighting();
      }

   }
   public static void drawRectSized(float var0, float var1, float var2, float var3, int var4) {
      drawRect(var0, var1, var0 + var2, var1 + var3, var4);
   }
   public static double lerp(double var0, double var2, double var4) {
      return ((double)1.0F - var4) * var0 + var4 * var2;
   }
   public static void draw2DRect(int var0, int var1, int var2, int var3, int var4) {
      Tessellator var5 = Tessellator.getInstance();
      BufferBuilder var6 = var5.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      var6.begin(7, DefaultVertexFormats.POSITION);
      var6.pos((double)var0, (double)(var1 + var3), (double)var4).endVertex();
      var6.pos((double)(var0 + var2), (double)(var1 + var3), (double)var4).endVertex();
      var6.pos((double)(var0 + var2), (double)var1, (double)var4).endVertex();
      var6.pos((double)var0, (double)var1, (double)var4).endVertex();
      var5.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }
   public static void setupColor(Color var0, int var1) {
      GL11.glColor4d((double)((float)var0.getRed() / 255.0F), (double)((float)var0.getGreen() / 255.0F), (double)((float)var0.getBlue() / 255.0F), (double)((float)var1 / 255.0F));
   }
   public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4, int var5) {
      GlStateManager.disableDepth();
      GlStateManager.enableBlend();
      OpenGlHelper.glBlendFunc(770, 771, 1, 0);
      glColor(var5);
      MinecraftInterface.mc.getTextureManager().bindTexture(var0);
      Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0F, 0.0F, var3, var4, (float)var3, (float)var4);
      GlStateManager.disableBlend();
      GlStateManager.enableDepth();
   }
   public static void disableSmoothLine() {
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDisable(3042);
      GL11.glEnable(3008);
      GL11.glDepthMask(true);
      GL11.glCullFace(1029);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }
   public static void drawGradient(double var0, double var2, double var4, double var6, int var8, int var9) {
      float var10 = (float)(var8 >> 24 & 255) / 255.0F;
      float var11 = (float)(var8 >> 16 & 255) / 255.0F;
      float var12 = (float)(var8 >> 8 & 255) / 255.0F;
      float var13 = (float)(var8 & 255) / 255.0F;
      float var14 = (float)(var9 >> 24 & 255) / 255.0F;
      float var15 = (float)(var9 >> 16 & 255) / 255.0F;
      float var16 = (float)(var9 >> 8 & 255) / 255.0F;
      float var17 = (float)(var9 & 255) / 255.0F;
      Render2DUtils.glRenderStart();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(var11, var12, var13, var10);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glColor4f(var15, var16, var17, var14);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
      GL11.glColor4d((double)1.0F, (double)1.0F, (double)1.0F, (double)1.0F);
      Render2DUtils.glRenderStop();
   }
   public static void drawGradientRect(double var0, double var2, double var4, double var6, boolean var8, boolean var9, int var10, int var11) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      GL11.glBegin(7);
      glColor(var10);
      if (var8) {
         if (var9) {
            GL11.glVertex2d(var4, var6);
            GL11.glVertex2d(var4, var2);
            glColor(var11);
            GL11.glVertex2d(var0, var2);
            GL11.glVertex2d(var0, var6);
         } else {
            GL11.glVertex2d(var0, var2);
            GL11.glVertex2d(var0, var6);
            glColor(var11);
            GL11.glVertex2d(var4, var6);
            GL11.glVertex2d(var4, var2);
         }
      } else if (var9) {
         GL11.glVertex2d(var4, var6);
         glColor(var11);
         GL11.glVertex2d(var4, var2);
         GL11.glVertex2d(var0, var2);
         glColor(var10);
         GL11.glVertex2d(var0, var6);
      } else {
         GL11.glVertex2d(var0, var2);
         glColor(var11);
         GL11.glVertex2d(var0, var6);
         GL11.glVertex2d(var4, var6);
         glColor(var10);
         GL11.glVertex2d(var4, var2);
      }

      GL11.glEnd();
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      GlStateManager.shadeModel(7424);
   }
   public static void blockEspFrame(BlockPos var0, float var1, float var2, float var3) {
      double var10 = (double)var0.getX();
      double var14 = MinecraftInterface.mc.getRenderManager().viewerPosX;
      double var4 = var10 - var14;
      var10 = (double)var0.getY();
      var14 = MinecraftInterface.mc.getRenderManager().viewerPosY;
      double var6 = var10 - var14;
      var10 = (double)var0.getZ();
      var14 = MinecraftInterface.mc.getRenderManager().viewerPosZ;
      double var8 = var10 - var14;
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(2.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GlStateManager.color(var1, var2, var3, 1.0F);
      Render2DUtils.drawSelectionBoundingBox(new AxisAlignedBB(var4, var6, var8, var4 + (double)1.0F, var6 + (double)1.0F, var8 + (double)1.0F));
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
   }
   public static void blockEspBox(BlockPos var0, double var1, double var3, double var5) {
      double var13 = (double)var0.getX();
      double var20 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
      double var7 = var13 - var20;
      var13 = (double)var0.getY();
      var20 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
      double var9 = var13 - var20;
      var13 = (double)var0.getZ();
      var20 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
      double var11 = var13 - var20;
      GL11.glPushMatrix();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(0);
      GL11.glLineWidth(2.0F);
      GL11.glDisable(3553);
      GL11.glDisable(0);
      GL11.glDisable(2896);
      GL11.glDepthMask(false);
      GL11.glColor4d(var1, var3, var5, (double)0.15F);
      Render2DUtils.drawColorBox(new AxisAlignedBB(var7, var9, var11, var7 + (double)1.0F, var9 + (double)1.0F, var11 + (double)1.0F), (float)var1, (float)var3, (float)var5, 0.15F);
      GL11.glDepthMask(false);
      GL11.glColor4d(var1, var3, var5, (double)0.15F);
      Render2DUtils.drawColorBox(new AxisAlignedBB(var7, var9, var11, var7 + (double)1.0F, var9 + (double)1.0F, var11 + (double)1.0F), (float)var1, (float)var3, (float)var5, 0.15F);
      GL11.glEnable(3553);
      GL11.glEnable(0);
      GL11.glEnable(2896);
      GL11.glDepthMask(true);
      GL11.glDisable(0);
      GL11.glPopMatrix();
   }
   public static void trace(Minecraft var0, Entity var1, float var2, int var3) {
      if (var0.getRenderManager().renderViewEntity != null) {
         GL11.glDisable(2929);
         GL11.glDisable(2896);
         GL11.glLineWidth(2.0F);
         GL11.glPushMatrix();
         GL11.glDepthMask(false);
         GL11.glColor4d((double)0.0F, var3 == 1 ? (double)1.0F : (double)0.0F, (double)0.0F, (double)1.0F);
         GL11.glBlendFunc(770, 771);
         GL11.glDisable(3553);
         GL11.glBegin(1);
         RenderManager var4 = var0.getRenderManager();
         Vec3d var5 = (new Vec3d((double)0.0F, (double)0.0F, (double)1.0F)).rotatePitch(-((float)Math.toRadians((double)var0.player.rotationPitch))).rotateYaw(-((float)Math.toRadians((double)var0.player.rotationYaw)));
         GL11.glVertex3d(var5.x, (double)var0.player.getEyeHeight() + var5.y, var5.z);
         double var6 = var1.lastTickPosX;
         double var10 = var1.posX;
         double var15 = var1.lastTickPosX;
         var6 += (var10 - var15) * (double)var2;
         var10 = var4.viewerPosX;
         var6 -= var10;
         var10 = var1.lastTickPosY;
         var15 = var1.posY;
         double var10003 = var1.lastTickPosY;
         var10 += (var15 - var10003) * (double)var2;
         var15 = var4.viewerPosY;
         var10 = var10 - var15 + (double)0.25F;
         var15 = var1.lastTickPosZ;
         var10003 = var1.posZ;
         double var10004 = var1.lastTickPosZ;
         var15 += (var10003 - var10004) * (double)var2;
         var10003 = var4.viewerPosZ;
         GL11.glVertex3d(var6, var10, var15 - var10003);
         GL11.glEnd();
         GL11.glDepthMask(true);
         GL11.glEnable(2929);
         GL11.glEnable(3553);
         GL11.glPopMatrix();
      }

   }
   public static void trace(Minecraft var0, ESPBlockColor var1) {
      if (var0.getRenderManager().renderViewEntity != null) {
         GL11.glDisable(2929);
         GL11.glDisable(2896);
         GL11.glLineWidth(2.0F);
         GL11.glPushMatrix();
         GL11.glDepthMask(false);
         GL11.glColor4d((double)var1.getR(), (double)var1.getG(), (double)var1.getB(), (double)1.0F);
         GL11.glBlendFunc(770, 771);
         GL11.glDisable(3553);
         GL11.glBegin(1);
         RenderManager var2 = var0.getRenderManager();
         Vec3d var3 = (new Vec3d((double)0.0F, (double)0.0F, (double)1.0F)).rotatePitch(-((float)Math.toRadians((double)var0.player.rotationPitch))).rotateYaw(-((float)Math.toRadians((double)var0.player.rotationYaw)));
         GL11.glVertex3d(var3.x, (double)var0.player.getEyeHeight() + var3.y, var3.z);
         double var4 = (double)var1.getX();
         double var7 = var2.viewerPosX;
         var4 -= var7;
         var7 = (double)var1.getY();
         double var10 = var2.viewerPosY;
         var7 -= var10;
         var10 = (double)var1.getZ();
         double var10003 = var2.viewerPosZ;
         GL11.glVertex3d(var4, var7, var10 - var10003);
         GL11.glEnd();
         GL11.glDepthMask(true);
         GL11.glEnable(2929);
         GL11.glEnable(3553);
         GL11.glPopMatrix();
      }

   }
   public static void glColor(int var0) {
      GlStateManager.color((float)(var0 >> 16 & 255) / 255.0F, (float)(var0 >> 8 & 255) / 255.0F, (float)(var0 & 255) / 255.0F, (float)(var0 >> 24 & 255) / 255.0F);
   }
   public static void drawBorderedRect(double var0, double var2, double var4, double var6, float var8, int var9, int var10) {
      drawRect((float)var0, (float)var2, (float)var4, (float)var6, var10);
      float var11 = (float)(var9 >> 24 & 255) / 255.0F;
      float var12 = (float)(var9 >> 16 & 255) / 255.0F;
      float var13 = (float)(var9 >> 8 & 255) / 255.0F;
      float var14 = (float)(var9 & 255) / 255.0F;
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glColor4f(var12, var13, var14, var11);
      GL11.glLineWidth(var8);
      GL11.glBegin(1);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glPopMatrix();
   }
   public static void drawEntityOnScreen(float var0, float var1, float var2, EntityLivingBase var3) {
      GlStateManager.pushMatrix();
      GlStateManager.enableDepth();
      GlStateManager.depthMask(true);
      GlStateManager.enableColorMaterial();
      GlStateManager.translate(var0, var1, 50.0F);
      GlStateManager.scale(-var2, var2, var2);
      GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
      RenderHelper.enableStandardItemLighting();
      GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-((float)Math.atan((double)(var3.rotationPitch / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
      GlStateManager.translate(0.0F, 0.0F, 0.0F);
      RenderManager var4 = Minecraft.getMinecraft().getRenderManager();
      var4.setPlayerViewY(180.0F);
      var4.setRenderShadow(false);
      var4.renderEntity(var3, (double)0.0F, (double)0.0F, (double)0.0F, var3.rotationYaw, 1.0F, false);
      var4.setRenderShadow(true);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GlStateManager.disableDepth();
      GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
      GlStateManager.popMatrix();
   }
   public static void putVertex3d(Vec3d var0) {
      GL11.glVertex3d(var0.x, var0.y, var0.z);
   }
   public static void renderQ(double var0, double var2, double var4, float var6, int var7, float var8) {
      Minecraft var9 = Minecraft.getMinecraft();
      double var10001 = var9.getRenderManager().viewerPosX;
      double var10 = var0 - var10001;
      var10001 = var9.getRenderManager().viewerPosY;
      double var12 = var2 - var10001;
      var10001 = var9.getRenderManager().viewerPosZ;
      double var14 = var4 - var10001;
      GL11.glPushMatrix();
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glTranslatef((float)var10, (float)var12, (float)var14);
      GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-var9.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(var9.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
      GL11.glScalef(-var6, -var6, -var6);
      GlStateManager.disableLighting();
      drawRect(-(var8 / 2.0F), 0.0F, var8 / 2.0F, var8, var7);
      GlStateManager.enableLighting();
      GL11.glEnable(2929);
      GL11.glColor3f(255.0F, 255.0F, 255.0F);
      GL11.glEnable(2929);
      GL11.glPopMatrix();
   }
   public static void drawRect(float var0, float var1, float var2, float var3, int var4) {
      float var5 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var8 = (float)(var4 & 255) / 255.0F;
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glColor4f(var6, var7, var8, var5);
      GL11.glBegin(7);
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glPopMatrix();
   }
   public static void drawUpShadow(float var0, float var1, float var2, float var3) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      GL11.glBegin(7);
      glColor((new Color(0, 0, 0, 100)).getRGB());
      GL11.glVertex2d((double)var0, (double)var1);
      glColor((new Color(0, 0, 0, 0)).getRGB());
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glVertex2d((double)var2, (double)var3);
      glColor((new Color(0, 0, 0, 100)).getRGB());
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glEnd();
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      GlStateManager.shadeModel(7424);
   }
   public static void enableSmoothLine(float var0) {
      GL11.glDisable(3008);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glEnable(2884);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      GL11.glLineWidth(var0);
   }
   public static void FillLine(Entity var0, AxisAlignedBB var1, boolean var2) {
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(2.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      if (!var2) {
         RenderGlobal.renderFilledBox(var1, 1.0F, 0.0F, 0.0F, 0.3F);
         RenderGlobal.drawSelectionBoundingBox(var1, 1.0F, 0.0F, 0.0F, 0.8F);
      } else {
         RenderGlobal.renderFilledBox(var1, 0.0F, 1.0F, 0.0F, 0.3F);
         RenderGlobal.drawSelectionBoundingBox(var1, 0.0F, 1.0F, 0.0F, 0.8F);
      }

      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
   }
   public static void glColor(Color var0, float var1) {
      GlStateManager.color((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, var1);
   }
   public static void scissorRect(float var0, float var1, float var2, double var3) {
      ScaledResolution var5 = new ScaledResolution(Minecraft.getMinecraft());
      int var6 = var5.getScaleFactor();
      int var7 = (int)(var0 * (float)var6);
      double var10 = (double)((float)var5.getScaledHeight());
      int var11 = (int)((var10 - var3) * (double)((float)var6));
      int var12 = (int)((var2 - var0) * (float)var6);
      double var10004 = (double)var1;
      GL11.glScissor(var7, var11, var12, (int)((var3 - var10004) * (double)((float)var6)));
   }
   public static Vec3d getRenderPos(double var0, double var2, double var4) {
      double var10 = MinecraftInterface.mc.getRenderManager().viewerPosX;
      var0 -= var10;
      var10 = MinecraftInterface.mc.getRenderManager().viewerPosY;
      var2 -= var10;
      var10 = MinecraftInterface.mc.getRenderManager().viewerPosZ;
      var4 -= var10;
      return new Vec3d(var0, var2, var4);
   }
   public static void renderEntity(EntityLivingBase var0, int var1, int var2, int var3) {
      GlStateManager.enableTexture2D();
      GlStateManager.depthMask(true);
      GL11.glPushAttrib(524288);
      GL11.glDisable(3089);
      GlStateManager.clear(256);
      GL11.glPopAttrib();
      GlStateManager.enableDepth();
      GlStateManager.disableAlpha();
      GlStateManager.pushMatrix();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GuiInventory.drawEntityOnScreen(var2, var3, var1, 1.0F, 1.0F, var0);
      GlStateManager.popMatrix();
      GlStateManager.disableDepth();
      GlStateManager.depthMask(false);
   }
   public static void drawEntityESP(Entity var0, Color var1) {
      GL11.glPushMatrix();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(0);
      GL11.glLineWidth(1.0F);
      GL11.glDisable(3553);
      GL11.glDisable(0);
      GL11.glDepthMask(false);
      GL11.glColor4d((double)((float)var1.getRed() / 255.0F), (double)((float)var1.getGreen() / 255.0F), (double)((float)var1.getBlue() / 255.0F), (double)0.15F);
      RenderManager var2 = Minecraft.getMinecraft().getRenderManager();
      double var10003 = var0.posX;
      double var9 = -0.05 - var10003;
      var10003 = var0.posX;
      double var10004 = var2.viewerPosX;
      var9 += var10003 - var10004;
      var10003 = -var0.posY;
      var10004 = var0.posY;
      double var10005 = var2.viewerPosY;
      var10003 += var10004 - var10005;
      var10005 = var0.posZ;
      var10004 = -0.05 - var10005;
      var10005 = var0.posZ;
      double var10006 = var2.viewerPosZ;
      var10004 += var10005 - var10006;
      var10006 = var0.posX;
      var10005 = 0.05 - var10006;
      var10006 = var0.posX;
      double var10007 = var2.viewerPosX;
      var10005 += var10006 - var10007;
      var10007 = var0.posY;
      var10006 = 0.1 - var10007;
      var10007 = var0.posY;
      double var10008 = var2.viewerPosY;
      var10006 += var10007 - var10008;
      var10008 = var0.posZ;
      var10007 = 0.05 - var10008;
      var10008 = var0.posZ;
      double var10009 = var2.viewerPosZ;
      Render2DUtils.drawColorBox(new AxisAlignedBB(var9, var10003, var10004, var10005, var10006, var10007 + (var10008 - var10009)), 0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glColor4d((double)0.0F, (double)0.0F, (double)0.0F, (double)0.5F);
      var10003 = var0.posX;
      var9 = -0.05 - var10003;
      var10003 = var0.posX;
      var10004 = var2.viewerPosX;
      var9 += var10003 - var10004;
      var10003 = -var0.posY;
      var10004 = var0.posY;
      var10005 = var2.viewerPosY;
      var10003 += var10004 - var10005;
      var10005 = var0.posZ;
      var10004 = -0.05 - var10005;
      var10005 = var0.posZ;
      var10006 = var2.viewerPosZ;
      var10004 += var10005 - var10006;
      var10006 = var0.posX;
      var10005 = 0.05 - var10006;
      var10006 = var0.posX;
      var10007 = var2.viewerPosX;
      var10005 += var10006 - var10007;
      var10007 = var0.posY;
      var10006 = 0.1 - var10007;
      var10007 = var0.posY;
      var10008 = var2.viewerPosY;
      var10006 += var10007 - var10008;
      var10008 = var0.posZ;
      var10007 = 0.05 - var10008;
      var10008 = var0.posZ;
      var10009 = var2.viewerPosZ;
      Render2DUtils.drawSelectionBoundingBox(new AxisAlignedBB(var9, var10003, var10004, var10005, var10006, var10007 + (var10008 - var10009)));
      GL11.glLineWidth(2.0F);
      GL11.glEnable(3553);
      GL11.glEnable(0);
      GL11.glDepthMask(true);
      GL11.glDisable(0);
      GL11.glPopMatrix();
   }
   public static void drawboxESP5(BlockPos var0, Color var1) {
      double var2 = (double)var0.getX();
      double var4 = Wrapper.mc.getRenderManager().viewerPosX;
      double var6 = Wrapper.mc.getRenderManager().viewerPosY;
      double var8 = Wrapper.mc.getRenderManager().viewerPosZ;
      Minecraft.getMinecraft().getRenderManager();
      double var10 = var2 - var4;
      double var12 = (double)var0.getY();
      Minecraft.getMinecraft().getRenderManager();
      double var14 = var12 - var6;
      double var16 = (double)var0.getZ();
      Minecraft.getMinecraft().getRenderManager();
      double var18 = var16 - var8;
      GL11.glBlendFunc(770, 771);
      Tessellator.getInstance().getBuffer();
      GL11.glPushMatrix();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(1.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2896);
      GL11.glDisable(2929);
      GL11.glDepthMask(true);
      GL11.glColor4d((double)((float)var1.getRed() / 255.0F), (double)((float)var1.getGreen() / 255.0F), (double)((float)var1.getBlue() / 255.0F), (double)0.25F);
      Minecraft.getMinecraft().getRenderManager();
      Render2DUtils.drawColorBox(new AxisAlignedBB(var10, var14, var18, var10 + (double)1.0F, var14 + (double)1.0F, var18 + (double)1.0F), 0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glColor4d((double)0.4F, (double)0.6F, (double)1.0F, (double)1.0F);
      GL11.glLineWidth(2.0F);
      GL11.glEnable(3553);
      GL11.glEnable(2896);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }
   public static void customScaledObject2D(float var0, float var1, float var2, float var3, float var4) {
      GL11.glTranslated((double)(var2 / 2.0F), (double)(var3 / 2.0F), (double)1.0F);
      GL11.glTranslated((double)(-var0 * var4 + var0 + var2 / 2.0F * -var4), (double)(-var1 * var4 + var1 + var3 / 2.0F * -var4), (double)1.0F);
      GL11.glScaled((double)var4, (double)var4, (double)0.0F);
   }
   public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4) {
      GL11.glEnable(2848);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glPushMatrix();
      Minecraft.getMinecraft().getTextureManager().bindTexture(var0);
      Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0F, 0.0F, var3, var4, (float)var3, (float)var4);
      GL11.glPopMatrix();
   }
   public static void disableGL2D() {
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }
   public static void drawImage(ResourceLocation var0, float var1, float var2, float var3, float var4, Color var5) {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDepthMask(false);
      OpenGlHelper.glBlendFunc(770, 771, 1, 0);
      setColor(var5.getRGB());
      Minecraft.getMinecraft().getTextureManager().bindTexture(var0);
      Gui.drawModalRectWithCustomSizedTexture((int)var1, (int)var2, 0.0F, 0.0F, (int)var3, (int)var4, var3, var4);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
   }
   public static void setColor(int var0) {
      GL11.glColor4ub((byte)(var0 >> 16 & 255), (byte)(var0 >> 8 & 255), (byte)(var0 & 255), (byte)(var0 >> 24 & 255));
   }
   public static void drawImage(ResourceLocation var0, float var1, float var2, float var3, float var4) {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDepthMask(false);
      GL11.glColor4f(0.6F, 0.6F, 0.6F, 1.0F);
      OpenGlHelper.glBlendFunc(770, 771, 1, 0);
      Minecraft.getMinecraft().getTextureManager().bindTexture(var0);
      Gui.drawModalRectWithCustomSizedTexture((int)var1, (int)var2, 0.0F, 0.0F, (int)var3, (int)var4, var3, var4);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GlStateManager.resetColor();
   }
   public static void drawRoundedRect(int var0, int var1, int var2, int var3, float var4, int var5) {
      float var10000 = (float)var0;
      float var10001 = (float)var1;
      drawRect(var10000, var10001 - var4, (float)var2, (float)var3 + var4, var5);
      var10000 = (float)var0;
      drawRect(var10000 - var4, (float)var1, (float)var0, (float)var3, var5);
      drawCircleFromTo((float)var0, (float)var1, var4, var5, 180, 270);
      drawCircleFromTo((float)var0, (float)var3, var4, var5, 270, 360);
      float var6 = (float)(var5 >> 24 & 255) / 255.0F;
      float var7 = (float)(var5 >> 16 & 255) / 255.0F;
      float var8 = (float)(var5 >> 8 & 255) / 255.0F;
      float var9 = (float)(var5 & 255) / 255.0F;
      GL11.glColor4f(var7, var8, var9, var6);
      drawRect((float)var2, (float)var1, (float)var2 + var4, (float)var3, var5);
      drawCircleFromTo((float)var2, (float)var1, var4, var5, 90, 180);
      drawCircleFromTo((float)var2, (float)var3, var4, var5, 0, 90);
   }
   public static void drawRoundedRect2(int var0, int var1, int var2, int var3, float var4, int var5) {
      drawRect((float)var0, (float)var1, (float)var2, (float)var3 + var4, var5);
      float var10000 = (float)var0;
      drawRect(var10000 - var4, (float)var1, (float)var0, (float)var3, var5);
      drawCircleFromTo((float)var0, (float)var3, var4, var5, 270, 360);
      float var6 = (float)(var5 >> 24 & 255) / 255.0F;
      float var7 = (float)(var5 >> 16 & 255) / 255.0F;
      float var8 = (float)(var5 >> 8 & 255) / 255.0F;
      float var9 = (float)(var5 & 255) / 255.0F;
      GL11.glColor4f(var7, var8, var9, var6);
      drawRect((float)var2, (float)var1, (float)var2 + var4, (float)var3, var5);
      drawCircleFromTo((float)var2, (float)var3, var4, var5, 0, 90);
   }
   public static void drawCircleFromTo(float var0, float var1, float var2, int var3, int var4, int var5) {
      float var6 = (float)(var3 >> 24 & 255) / 255.0F;
      float var7 = (float)(var3 >> 16 & 255) / 255.0F;
      float var8 = (float)(var3 >> 8 & 255) / 255.0F;
      float var9 = (float)(var3 & 255) / 255.0F;
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GL11.glColor4f(var7, var8, var9, var6);
      GL11.glBegin(9);

      for(int var10 = var4; var10 <= var5; ++var10) {
         GL11.glVertex2d((double)var0 + Math.sin((double)var10 * Math.PI / (double)180.0F) * (double)var2, (double)var1 + Math.cos((double)var10 * Math.PI / (double)180.0F) * (double)var2);
      }

      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glEnd();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }
   public static void drawStabilityRoundedRect(int var0, int var1, int var2, int var3, float var4, int var5) {
      int var10000 = (int)((float)var0 + var4);
      int var10001 = (int)((float)var1 + var4);
      float var10002 = (float)var2;
      int var6 = (int)(var10002 - var4);
      float var10003 = (float)var3;
      drawRoundedRect(var10000, var10001, var6, (int)(var10003 - var4), var4, var5);
   }
   public static void glColor(Color var0) {
      GlStateManager.color((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
   }

   static {
      
      GL_BLEND = 0;
      GL_DEPTH_TEST = 0;
      frustrum = new Frustum();
   }
   

   
}
