package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

 
public class ColorUtils {
   public static int getColor(Color var0) {
      return getColor(var0.getRed(), var0.getGreen(), var0.getBlue(), var0.getAlpha());
   }
   public static Color getColorWithOpacity(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
   }
   public static int rainbow(int var0, long var1) {
      double var3 = Math.ceil((double)(System.currentTimeMillis() + var1 + (long)var0)) / (double)15.0F;
      double var5;
      return Color.getHSBColor((float)((var5 = var3 % (double)360.0F) / (double)360.0F), 0.4F, 1.0F).getRGB();
   }
   public static Color fade(Color var0) {
      return fade(var0, 2, 100);
   }
   public static int color(int var0, int var1, int var2, int var3) {
      var3 = 255;
      return (new Color(var0, var1, var2, var3)).getRGB();
   }
   public static int getRandomColor() {
      char[] var0 = "012345678".toCharArray();

      for(int var2 = 0; var2 < 6; ++var2) {
         StringBuilder var4 = (new StringBuilder()).append(var1);
         var1 = var4.append(var0[(new Random()).nextInt(var0.length)]).toString();
      }

      return Integer.decode(var1);
   }
   public static int reAlpha(int var0, float var1) {
      Color var2 = new Color(var0);
      float var3 = 0.003921569F * (float)var2.getRed();
      float var4 = 0.003921569F * (float)var2.getGreen();
      float var5 = 0.003921569F * (float)var2.getBlue();
      return (new Color(var3, var4, var5, var1)).getRGB();
   }
   public static Color getGradientOffset(Color var0, Color var1, double var2) {
      if (var2 > (double)1.0F) {
         double var4 = var2 % (double)1.0F;
         int var6 = (int)var2;
         double var11;
         if (var6 % 2 == 0) {
            var11 = var4;
         } else {
            var11 = (double)1.0F - var4;
         }

         var2 = var11;
      }
      double var9 = (double)1.0F - var2;
      int var10 = (int)((double)var0.getRed() * var9 + (double)var1.getRed() * var2);
      int var7 = (int)((double)var0.getGreen() * var9 + (double)var1.getGreen() * var2);
      int var8 = (int)((double)var0.getBlue() * var9 + (double)var1.getBlue() * var2);
      return new Color(var10, var7, var8);
   }
   public static int getColor1(int var0) {
      return getColor(var0, var0, var0, 255);
   }
   public static int getColor(int var0, int var1, int var2) {
      return getColor(var0, var1, var2, 255);
   }
   public static int getColor(int var0, int var1, int var2, int var3) {
      int var4 = 0;
      var4 |= var3 << 24;
      var4 |= var0 << 16;
      var4 |= var1 << 8;
      int var8 = var4 | var2;
      return var8;
   }
   public static int getColor(int var0, int var1) {
      return getColor(var0, var0, var0, var1);
   }
   public static Color fade(Color var0, int var1, int var2) {
      float[] var3 = new float[3];
      Color.RGBtoHSB(var0.getRed(), var0.getGreen(), var0.getBlue(), var3);
      float var6 = ((float)(System.currentTimeMillis() % 2000L) / 1000.0F + (float)var1 / (float)var2 * 2.0F) % 2.0F;
      float var4 = Math.abs(var6 - 1.0F);
      var4 = 0.5F + 0.5F * var4;
      var3[2] = var4 % 2.0F;
      return new Color(Color.HSBtoRGB(var3[0], var3[1], var3[2]));
   }
   public static Color getHealthColor(EntityLivingBase var0) {
      float var1 = var0.getHealth();
      float[] var11 = new float[5];
      var11[0] = 0.0F;
      var11[1] = 0.15F;
      var11[2] = 0.55F;
      var11[3] = 0.7F;
      var11[4] = 0.9F;
      float[] var2 = var11;
      Color[] var12 = new Color[5];
      var12[0] = new Color(133, 0, 0);
      var12[1] = Color.RED;
      var12[2] = Color.ORANGE;
      var12[3] = Color.YELLOW;
      var12[4] = Color.GREEN;
      Color[] var3 = var12;
      float var4 = var1 / var0.getMaxHealth();
      return var1 >= 0.0F ? blendColors(var2, var3, var4).brighter() : var3[0];
   }
   public static Color blendColors(float[] var0, Color[] var1, float var2) {
      if (var0 == null) {
         IllegalArgumentException var19 = new IllegalArgumentException("Fractions can't be null");
         throw var19;
      } else if (var1 == null) {
         IllegalArgumentException var18 = new IllegalArgumentException("Colours can't be null");
         throw var18;
      } else if (var0.length != var1.length) {
         IllegalArgumentException var17 = new IllegalArgumentException("Fractions and colours must have equal number of elements");
         throw var17;
      } else {
         int[] var3 = getFractionIndicies(var0, var2);
         float[] var13 = new float[2];
         var13[0] = var0[var3[0]];
         var13[1] = var0[var3[1]];
         float[] var4 = var13;
         Color[] var14 = new Color[2];
         var14[0] = var1[var3[0]];
         var14[1] = var1[var3[1]];
         Color[] var5 = var14;
         float var15 = var4[1];
         float var39 = var4[0];
         float var6 = var15 - var39;
         var39 = var4[0];
         float var7 = var2 - var39;
         float var8 = var7 / var6;
         Color var16 = var5[0];
         Color var41 = var5[1];
         return blend(var16, var41, (double)(1.0F - var8));
      }
   }
   public static int[] getFractionIndicies(float[] var0, float var1) {
      int[] var3 = new int[2];

      int var2;
      for(var2 = 0; var2 < var0.length && var0[var2] <= var1; ++var2) {
      }

      if (var2 >= var0.length) {
         int var10000 = var0.length;
         var2 = var10000 - 1;
      }
      var3[0] = var2 - 1;
      var3[1] = var2;
      return var3;
   }
   public static Color blend(Color var0, Color var1, double var2) {
      float var4 = (float)var2;
      float var5 = 1.0F - var4;
      float[] var6 = new float[3];
      float[] var7 = new float[3];
      var0.getColorComponents(var6);
      var1.getColorComponents(var7);
      float var8 = var6[0] * var4 + var7[0] * var5;
      float var9 = var6[1] * var4 + var7[1] * var5;
      float var10 = var6[2] * var4 + var7[2] * var5;
      if (var8 < 0.0F) {
         var8 = 0.0F;
      } else if (var8 > 255.0F) {
         var8 = 255.0F;
      }

      if (var9 < 0.0F) {
         var9 = 0.0F;
      } else if (var9 > 255.0F) {
         var9 = 255.0F;
      }

      if (var10 < 0.0F) {
         var10 = 0.0F;
      } else if (var10 > 255.0F) {
         var10 = 255.0F;
      }

      Color var11 = null;

      try {
         var11 = new Color(var8, var9, var10);
      } catch (IllegalArgumentException var14) {
         NumberFormat var13 = NumberFormat.getNumberInstance();
      }

      return var11;
   }
   public static int astolfo(int var0, float var1) {
      float var3 = 3000.0F;

      float var2;
      for(var2 = Math.abs((float)(System.currentTimeMillis() % (long)var0) + -var1 / 21.0F * 2.0F); var2 > var3; var2 -= var3) {
      }

      float var6 = var2 / var3;
      var2 = var6;
      if ((double)var6 > (double)0.5F) {
         float var12 = var2 - 0.5F;
         var2 = 0.5F - var12;
      }

      var6 = var2 + 0.5F;
      return Color.HSBtoRGB(var6, 0.5F, 1.0F);
   }
   public static int Yellowastolfo(int var0, float var1) {
      float var3 = 2900.0F;
      float var6 = (float)(System.currentTimeMillis() % (long)((int)var3));
      float var13 = (float)(-var0);

      float var2;
      for(var2 = var6 + (var13 - var1) * 9.0F; var2 > var3; var2 -= var3) {
      }

      var6 = var2 / var3;
      var2 = var6;
      if ((double)var6 > 0.6) {
         var13 = var2 - 0.6F;
         var2 = 0.6F - var13;
      }

      var6 = var2 + 0.6F;
      return Color.HSBtoRGB(var6, 0.5F, 1.0F);
   }
   public static Color Yellowastolfo1(int var0, float var1) {
      float var3 = 2900.0F;
      float var6 = (float)(System.currentTimeMillis() % (long)((int)var3));
      float var15 = (float)var0;

      float var2;
      for(var2 = var6 + (var15 - var1) * 9.0F; var2 > var3; var2 -= var3) {
      }

      var6 = var2 / var3;
      var2 = var6;
      if ((double)var6 > 0.6) {
         var15 = var2 - 0.6F;
         var2 = 0.6F - var15;
      }
      float var19 = var2 + 0.6F;
      return new Color(var19, 0.5F, 1.0F);
   }
   public static Color TwoColoreffect(Color var0, Color var1, double var2) {
      double var4 = var2 / (double)4.0F % (double)1.0F;
      float var6 = MathUtils.clamp((float)Math.sin(18.84955592153876 * var4) / 2.0F + 0.5F, 0.0F, 1.0F);
      return new Color(MathUtils.lerp((float)var0.getRed() / 255.0F, (float)var1.getRed() / 255.0F, var6), MathUtils.lerp((float)var0.getGreen() / 255.0F, (float)var1.getGreen() / 255.0F, var6), MathUtils.lerp((float)var0.getBlue() / 255.0F, (float)var1.getBlue() / 255.0F, var6));
   }
   public static int astolfoColors(int var0, int var1) {
      float var3 = 2900.0F;
      float var5 = (float)(System.currentTimeMillis() % (long)((int)var3));

      float var2;
      for(var2 = var5 + (float)((var1 - var0) * 9); var2 > var3; var2 -= var3) {
      }

      var5 = var2 / var3;
      var2 = var5;
      if ((double)var5 > (double)0.5F) {
         float var12 = var2 - 0.5F;
         var2 = 0.5F - var12;
      }

      var5 = var2 + 0.5F;
      return Color.HSBtoRGB(var5, 0.5F, 1.0F);
   }
   public static int getTeamColor(Entity var0) {
      int var1 = -1;
      var10000 = var0.getDisplayName().getUnformattedText();
      int var11;
      if ((var10000.equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405cR\u043f\u0457\u0405f]\u043f\u0457\u0405c" + var0.getName())) != 0) {
         var11 = getColor(new Color(255, 60, 60));
      } else {
         String var12 = var0.getDisplayName().getUnformattedText();
         if ((var12.equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u04059B\u043f\u0457\u0405f]\u043f\u0457\u04059" + var0.getName())) != 0) {
            var11 = getColor(new Color(60, 60, 255));
         } else {
            var12 = var0.getDisplayName().getUnformattedText();
            if ((var12.equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405eY\u043f\u0457\u0405f]\u043f\u0457\u0405e" + var0.getName())) != 0) {
               var11 = getColor(new Color(255, 255, 60));
            } else {
               var12 = var0.getDisplayName().getUnformattedText();
               if ((var12.equalsIgnoreCase("\u043f\u0457\u0405f[\u043f\u0457\u0405aG\u043f\u0457\u0405f]\u043f\u0457\u0405a" + var0.getName())) != 0) {
                  var11 = getColor(new Color(60, 255, 60));
               } else {
                  var11 = getColor(new Color(255, 255, 255));
               }
            }
         }
      }

      var1 = var11;
      return var1;
   }
   public static Color astolfoColors1(int var0, int var1) {
      float var3 = 2900.0F;
      float var7 = (float)(System.currentTimeMillis() % (long)((int)var3));

      float var2;
      for(var2 = var7 + (float)((var1 - var0) * 9); var2 > var3; var2 -= var3) {
      }

      var7 = var2 / var3;
      var2 = var7;
      if ((double)var7 > (double)0.5F) {
         float var14 = var2 - 0.5F;
         var2 = 0.5F - var14;
      }
      float var17 = var2 + 0.5F;
      return new Color(var17, 0.5F, 1.0F);
   }
   public static Color rainbowCol(int var0, float var1, float var2) {
      double var3 = Math.ceil((double)((System.currentTimeMillis() + (long)var0) / 16L));
      double var5;
      return Color.getHSBColor((float)((var5 = var3 % (double)360.0F) / (double)360.0F), var1, var2);
   }
   public static int rainbowNew(int var0, float var1, float var2) {
      double var3 = Math.ceil((double)((System.currentTimeMillis() + (long)var0) / 16L));
      double var5;
      return Color.getHSBColor((float)((var5 = var3 % (double)360.0F) / (double)360.0F), var1, var2).getRGB();
   }
   

   

   
}
