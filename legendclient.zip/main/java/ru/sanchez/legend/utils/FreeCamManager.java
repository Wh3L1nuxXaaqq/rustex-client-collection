package ru.sanchez.legend.utils;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.entity.player.CCPE;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.ClientAdvancementManager;
import net.minecraft.entity.Entity;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketThreadUtil;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketAdvancementInfo;
import net.minecraft.network.play.server.SPacketAnimation;
import net.minecraft.network.play.server.SPacketBlockAction;
import net.minecraft.network.play.server.SPacketBlockBreakAnim;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketCamera;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketChunkData;
import net.minecraft.network.play.server.SPacketCloseWindow;
import net.minecraft.network.play.server.SPacketCollectItem;
import net.minecraft.network.play.server.SPacketCombatEvent;
import net.minecraft.network.play.server.SPacketConfirmTransaction;
import net.minecraft.network.play.server.SPacketCooldown;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.network.play.server.SPacketCustomSound;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.network.play.server.SPacketDisplayObjective;
import net.minecraft.network.play.server.SPacketEffect;
import net.minecraft.network.play.server.SPacketEntity;
import net.minecraft.network.play.server.SPacketEntityAttach;
import net.minecraft.network.play.server.SPacketEntityEffect;
import net.minecraft.network.play.server.SPacketEntityEquipment;
import net.minecraft.network.play.server.SPacketEntityHeadLook;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraft.network.play.server.SPacketEntityProperties;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketJoinGame;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraft.network.play.server.SPacketMaps;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.network.play.server.SPacketMultiBlockChange;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraft.network.play.server.SPacketParticles;
import net.minecraft.network.play.server.SPacketPlaceGhostRecipe;
import net.minecraft.network.play.server.SPacketPlayerAbilities;
import net.minecraft.network.play.server.SPacketPlayerListHeaderFooter;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketRecipeBook;
import net.minecraft.network.play.server.SPacketRemoveEntityEffect;
import net.minecraft.network.play.server.SPacketResourcePackSend;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketScoreboardObjective;
import net.minecraft.network.play.server.SPacketSelectAdvancementsTab;
import net.minecraft.network.play.server.SPacketServerDifficulty;
import net.minecraft.network.play.server.SPacketSetExperience;
import net.minecraft.network.play.server.SPacketSetPassengers;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.network.play.server.SPacketSignEditorOpen;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnExperienceOrb;
import net.minecraft.network.play.server.SPacketSpawnGlobalEntity;
import net.minecraft.network.play.server.SPacketSpawnMob;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.network.play.server.SPacketSpawnPainting;
import net.minecraft.network.play.server.SPacketSpawnPlayer;
import net.minecraft.network.play.server.SPacketSpawnPosition;
import net.minecraft.network.play.server.SPacketStatistics;
import net.minecraft.network.play.server.SPacketTabComplete;
import net.minecraft.network.play.server.SPacketTeams;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.network.play.server.SPacketUnloadChunk;
import net.minecraft.network.play.server.SPacketUpdateBossInfo;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.network.play.server.SPacketUpdateScore;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.network.play.server.SPacketUseBed;
import net.minecraft.network.play.server.SPacketWindowItems;
import net.minecraft.network.play.server.SPacketWindowProperty;
import net.minecraft.network.play.server.SPacketWorldBorder;
import net.minecraft.network.play.server.SPacketPlayerPosLook.EnumFlags;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.GameType;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class FreeCamManager extends NetHandlerPlayClient {
   public NetHandlerPlayClient wrapped;
   private FreeCamManager fc;
   private Minecraft mc;
   public static final ArrayList<Function<Packet<?>, Boolean>> sendProcessors = new ArrayList();

   public NetHandlerPlayClient getWrapped() {
      return this.wrapped;
   }

   public void setWrapped(NetHandlerPlayClient var1) {
      this.wrapped = var1;
   }

   public FreeCamManager(Minecraft var1, GuiScreen var2, NetworkManager var3, GameProfile var4, NetHandlerPlayClient var5, FreeCamManager var6) {
      super(var1, var2, var3, var4);
      this.wrapped = var5;
      this.fc = var6;
      this.mc = var6.mc;
   }

   public void handlePlayerPosLook_(SPacketPlayerPosLook var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.mc);
      CCPE var2 = this.fc.fakePlayer;
      boolean var3 = var1.getFlags().contains(EnumFlags.X);
      boolean var4 = var1.getFlags().contains(EnumFlags.Y);
      boolean var5 = var1.getFlags().contains(EnumFlags.Z);
      double var6;
      double var8;
      if (var3) {
         var6 = var2.motionX;
         var8 = var2.posX + var1.getX();
         var2.lastTickPosX += var1.getX();
      } else {
         var6 = (double)0.0F;
         var8 = var1.getX();
         var2.lastTickPosX = var8;
      }

      double var10;
      double var12;
      if (var4) {
         var10 = var2.motionY;
         var12 = var2.posY + var1.getY();
         var2.lastTickPosY += var1.getY();
      } else {
         var10 = (double)0.0F;
         var12 = var1.getY();
         var2.lastTickPosY = var12;
      }

      double var14;
      double var16;
      if (var5) {
         var14 = var2.motionZ;
         var16 = var2.posZ + var1.getZ();
         var2.lastTickPosZ += var1.getZ();
      } else {
         var14 = (double)0.0F;
         var16 = var1.getZ();
         var2.lastTickPosZ = var16;
      }

      var2.setPosition(var8, var12, var16);
      var2.prevPosX = var8;
      var2.prevPosY = var12;
      var2.prevPosZ = var16;
      var2.setVelocity(var6, var10, var14);
      float var18 = var1.getYaw();
      float var19 = var1.getPitch();
      if (var1.getFlags().contains(EnumFlags.X_ROT)) {
         var19 += var2.rotationPitch;
      }

      if (var1.getFlags().contains(EnumFlags.Y_ROT)) {
         var18 += var2.rotationYaw;
      }

      var2.setPositionAndRotation(var8, var12, var16, var18, var19);
      var2.setPosition(var8, var12, var16);
      var2.prevPosX = var8;
      var2.prevPosY = var12;
      var2.prevPosZ = var16;
      var2.lastTickPosX = var8;
      var2.lastTickPosY = var12;
      var2.lastTickPosZ = var16;
   }

   public void handlePlayerPosLook(SPacketPlayerPosLook var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.mc);
      if (this.fc.isEnabled()) {
         this.handlePlayerPosLook_(var1);
         this.wrapped.sendPacket(new CPacketConfirmTeleport(var1.getTeleportId()));
         this.wrapped.sendPacket(new CPacketPlayer.PositionRotation(var1.getX(), var1.getY(), var1.getZ(), var1.getYaw(), var1.getPitch(), false));
      } else {
         this.wrapped.handlePlayerPosLook(var1);
      }

   }

   public void sendPacket(Packet<?> var1) {
      for(Function var3 : sendProcessors) {
         if ((Boolean)var3.apply(var1)) {
            return;
         }
      }

      this.wrapped.sendPacket(var1);
   }

   public void handleChangeGameState(SPacketChangeGameState var1) {
      if (!this.fc.isEnabled()) {
         this.wrapped.handleChangeGameState(var1);
      }

   }

   public void handlePlayerAbilities(SPacketPlayerAbilities var1) {
      if (!this.fc.isEnabled()) {
         this.wrapped.handlePlayerAbilities(var1);
      } else {
         PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.mc);
         CCPE var2 = this.fc.fakePlayer;
         var2.capabilities.isFlying = var1.isFlying();
         var2.capabilities.isCreativeMode = var1.isCreativeMode();
         var2.capabilities.disableDamage = var1.isInvulnerable();
         var2.capabilities.allowFlying = var1.isAllowFlying();
         var2.capabilities.setFlySpeed(var1.getFlySpeed());
         var2.capabilities.setPlayerWalkSpeed(var1.getWalkSpeed());
      }

   }

   public void setGameType(UUID var1, GameType var2) {
      NetworkPlayerInfo var3 = this.wrapped.getPlayerInfo(var1);
      var3.setGameType(var2);
   }

   public void cleanup() {
      this.wrapped.cleanup();
   }

   public void handleJoinGame(SPacketJoinGame var1) {
      this.wrapped.handleJoinGame(var1);
   }

   public void handleSpawnObject(SPacketSpawnObject var1) {
      this.wrapped.handleSpawnObject(var1);
   }

   public void handleSpawnExperienceOrb(SPacketSpawnExperienceOrb var1) {
      this.wrapped.handleSpawnExperienceOrb(var1);
   }

   public void handleSpawnPainting(SPacketSpawnPainting var1) {
      this.wrapped.handleSpawnPainting(var1);
   }

   public void handleEntityVelocity(SPacketEntityVelocity var1) {
      if (this.fc.isEnabled() && this.mc.player.getEntityId() == var1.getEntityID()) {
         CCPE var2 = this.fc.fakePlayer;
         if (var2 != null) {
            (Entity)var2).setVelocity((double)var1.getMotionX() / (double)8000.0F, (double)var1.getMotionY() / (double)8000.0F, (double)var1.getMotionZ() / (double)8000.0F;
            return;
         }
      }

      this.wrapped.handleEntityVelocity(var1);
   }

   public void handleEntityMetadata(SPacketEntityMetadata var1) {
      this.wrapped.handleEntityMetadata(var1);
   }

   public void handleSpawnPlayer(SPacketSpawnPlayer var1) {
      this.wrapped.handleSpawnPlayer(var1);
   }

   public void handleEntityTeleport(SPacketEntityTeleport var1) {
      this.wrapped.handleEntityTeleport(var1);
   }

   public void handleHeldItemChange(SPacketHeldItemChange var1) {
      this.wrapped.handleHeldItemChange(var1);
   }

   public void handleEntityMovement(SPacketEntity var1) {
      if (this.fc.isEnabled()) {
         Entity var2 = var1.getEntity(this.mc.world);
         if (var2 instanceof EntityPlayerSP) {
            ReflectionUtils.setValueToFinal(var1, Integer.TYPE, this.fc.fakePlayer.getEntityId());
         }
      }

      this.wrapped.handleEntityMovement(var1);
   }

   public void handleEntityHeadLook(SPacketEntityHeadLook var1) {
      this.wrapped.handleEntityHeadLook(var1);
   }

   public void handleDestroyEntities(SPacketDestroyEntities var1) {
      this.wrapped.handleDestroyEntities(var1);
   }

   public void handleMultiBlockChange(SPacketMultiBlockChange var1) {
      this.wrapped.handleMultiBlockChange(var1);
   }

   public void handleChunkData(SPacketChunkData var1) {
      this.wrapped.handleChunkData(var1);
   }

   public void processChunkUnload(SPacketUnloadChunk var1) {
      this.wrapped.processChunkUnload(var1);
   }

   public void handleDisconnect(SPacketDisconnect var1) {
      this.wrapped.handleDisconnect(var1);
   }

   public void onDisconnect(ITextComponent var1) {
      this.wrapped.onDisconnect(var1);
   }

   public void handleCollectItem(SPacketCollectItem var1) {
      this.wrapped.handleCollectItem(var1);
   }

   public void handleChat(SPacketChat var1) {
      this.wrapped.handleChat(var1);
   }

   public void handleSpawnMob(SPacketSpawnMob var1) {
      this.wrapped.handleSpawnMob(var1);
   }

   public void handleSetPassengers(SPacketSetPassengers var1) {
      this.wrapped.handleSetPassengers(var1);
   }

   public void handleEntityStatus(SPacketEntityStatus var1) {
      if (this.fc.isEnabled() && var1.getEntity(this.mc.world) instanceof EntityPlayerSP && var1.getOpCode() != 35 && var1.getOpCode() != 21) {
         Legend.moduleManager.getModule("FreeCam").onDisable();
      }

      this.wrapped.handleEntityStatus(var1);
   }

   public void handleUpdateHealth(SPacketUpdateHealth var1) {
      this.wrapped.handleUpdateHealth(var1);
   }

   public void handleSetExperience(SPacketSetExperience var1) {
      this.wrapped.handleSetExperience(var1);
   }

   public void handleRespawn(SPacketRespawn var1) {
      this.wrapped.handleRespawn(var1);
   }

   public void handleExplosion(SPacketExplosion var1) {
      this.wrapped.handleExplosion(var1);
   }

   public void handleSetSlot(SPacketSetSlot var1) {
      this.wrapped.handleSetSlot(var1);
   }

   public void handleConfirmTransaction(SPacketConfirmTransaction var1) {
      this.wrapped.handleConfirmTransaction(var1);
   }

   public void handleWindowItems(SPacketWindowItems var1) {
      this.wrapped.handleWindowItems(var1);
   }

   public void handleUpdateTileEntity(SPacketUpdateTileEntity var1) {
      this.wrapped.handleUpdateTileEntity(var1);
   }

   public void handleWindowProperty(SPacketWindowProperty var1) {
      this.wrapped.handleWindowProperty(var1);
   }

   public void handleEntityEquipment(SPacketEntityEquipment var1) {
      this.wrapped.handleEntityEquipment(var1);
   }

   public void handleCloseWindow(SPacketCloseWindow var1) {
      this.wrapped.handleCloseWindow(var1);
   }

   public void handleBlockAction(SPacketBlockAction var1) {
      this.wrapped.handleBlockAction(var1);
   }

   public void handleAdvancementInfo(SPacketAdvancementInfo var1) {
      this.wrapped.handleAdvancementInfo(var1);
   }

   public void handleSelectAdvancementsTab(SPacketSelectAdvancementsTab var1) {
      this.wrapped.handleSelectAdvancementsTab(var1);
   }

   public void handleTabComplete(SPacketTabComplete var1) {
      this.wrapped.handleTabComplete(var1);
   }

   public void handleStatistics(SPacketStatistics var1) {
      this.wrapped.handleStatistics(var1);
   }

   public void handleRecipeBook(SPacketRecipeBook var1) {
      this.wrapped.handleRecipeBook(var1);
   }

   public void handleServerDifficulty(SPacketServerDifficulty var1) {
      this.wrapped.handleServerDifficulty(var1);
   }

   public void handleCamera(SPacketCamera var1) {
      this.wrapped.handleCamera(var1);
   }

   public void handleWorldBorder(SPacketWorldBorder var1) {
      this.wrapped.handleWorldBorder(var1);
   }

   public void handleTitle(SPacketTitle var1) {
      this.wrapped.handleTitle(var1);
   }

   public void handlePlayerListHeaderFooter(SPacketPlayerListHeaderFooter var1) {
      this.wrapped.handlePlayerListHeaderFooter(var1);
   }

   public void handleRemoveEntityEffect(SPacketRemoveEntityEffect var1) {
      this.wrapped.handleRemoveEntityEffect(var1);
   }

   public void handlePlayerListItem(SPacketPlayerListItem var1) {
      this.wrapped.handlePlayerListItem(var1);
   }

   public void handleKeepAlive(SPacketKeepAlive var1) {
      this.wrapped.handleKeepAlive(var1);
   }

   public void handleUpdateBossInfo(SPacketUpdateBossInfo var1) {
      this.wrapped.handleUpdateBossInfo(var1);
   }

   public void handleCooldown(SPacketCooldown var1) {
      this.wrapped.handleCooldown(var1);
   }

   public void handleMoveVehicle(SPacketMoveVehicle var1) {
      this.wrapped.handleMoveVehicle(var1);
   }

   public void handleScoreboardObjective(SPacketScoreboardObjective var1) {
      this.wrapped.handleScoreboardObjective(var1);
   }

   public void handleUpdateScore(SPacketUpdateScore var1) {
      this.wrapped.handleUpdateScore(var1);
   }

   public void handleDisplayObjective(SPacketDisplayObjective var1) {
      this.wrapped.handleDisplayObjective(var1);
   }

   public void handleTeams(SPacketTeams var1) {
      this.wrapped.handleTeams(var1);
   }

   public void handleEntityProperties(SPacketEntityProperties var1) {
      this.wrapped.handleEntityProperties(var1);
   }

   public NetworkManager getNetworkManager() {
      return this.wrapped.getNetworkManager();
   }

   public Collection<NetworkPlayerInfo> getPlayerInfoMap() {
      return this.wrapped.getPlayerInfoMap();
   }

   @Nullable
   public NetworkPlayerInfo getPlayerInfo(UUID var1) {
      return this.wrapped.getPlayerInfo(var1);
   }

   @Nullable
   public NetworkPlayerInfo getPlayerInfo(String var1) {
      return this.wrapped.getPlayerInfo(var1);
   }

   public GameProfile getGameProfile() {
      return this.wrapped.getGameProfile();
   }

   public ClientAdvancementManager getAdvancementManager() {
      return this.wrapped.getAdvancementManager();
   }

   public int hashCode() {
      return this.wrapped.hashCode();
   }

   public boolean equals(Object var1) {
      return this.wrapped.equals(var1);
   }

   public String toString() {
      return this.wrapped.toString();
   }

   public void handleSpawnGlobalEntity(SPacketSpawnGlobalEntity var1) {
      this.wrapped.handleSpawnGlobalEntity(var1);
   }

   public void handleBlockChange(SPacketBlockChange var1) {
      this.wrapped.handleBlockChange(var1);
   }

   public void handleAnimation(SPacketAnimation var1) {
      this.wrapped.handleAnimation(var1);
   }

   public void handleUseBed(SPacketUseBed var1) {
      this.wrapped.handleUseBed(var1);
   }

   public void handleTimeUpdate(SPacketTimeUpdate var1) {
      this.wrapped.handleTimeUpdate(var1);
   }

   public void handleSpawnPosition(SPacketSpawnPosition var1) {
      this.wrapped.handleSpawnPosition(var1);
   }

   public void handleEntityAttach(SPacketEntityAttach var1) {
      this.wrapped.handleEntityAttach(var1);
   }

   public void handleOpenWindow(SPacketOpenWindow var1) {
      this.wrapped.handleOpenWindow(var1);
   }

   public void handleSignEditorOpen(SPacketSignEditorOpen var1) {
      this.wrapped.handleSignEditorOpen(var1);
   }

   public void handleBlockBreakAnim(SPacketBlockBreakAnim var1) {
      this.wrapped.handleBlockBreakAnim(var1);
   }

   public void handleMaps(SPacketMaps var1) {
      this.wrapped.handleMaps(var1);
   }

   public void handleEffect(SPacketEffect var1) {
      this.wrapped.handleEffect(var1);
   }

   public void handleEntityEffect(SPacketEntityEffect var1) {
      this.wrapped.handleEntityEffect(var1);
   }

   public void handleCombatEvent(SPacketCombatEvent var1) {
      this.wrapped.handleCombatEvent(var1);
   }

   public void handleSoundEffect(SPacketSoundEffect var1) {
      this.wrapped.handleSoundEffect(var1);
   }

   public void handleCustomSound(SPacketCustomSound var1) {
      this.wrapped.handleCustomSound(var1);
   }

   public void handleResourcePack(SPacketResourcePackSend var1) {
      this.wrapped.handleResourcePack(var1);
   }

   public void handleCustomPayload(SPacketCustomPayload var1) {
      this.wrapped.handleCustomPayload(var1);
   }

   public void handleParticles(SPacketParticles var1) {
      this.wrapped.handleParticles(var1);
   }

   public void handlePlaceGhostRecipe(SPacketPlaceGhostRecipe var1) {
      this.wrapped.handlePlaceGhostRecipe(var1);
   }
}
