package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

 
public class DiscordUser extends Structure {
    
   public static final List<String> FIELD_ORDER;
    
   public String userId;
    
   public String username;
    
   public String discriminator;
    
   public String avatar;

   public DiscordUser(String var1) {
      this.setStringEncoding(var1);
   }

   public DiscordUser() {
      this("UTF-8");
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof DiscordUser)) {
         return false;
      } else {
         DiscordUser var2 = (DiscordUser)var1;
         return (Objects.equals(this.userId, var2.userId)) != 0 && (Objects.equals(this.username, var2.username)) != 0 && (Objects.equals(this.discriminator, var2.discriminator)) != 0 && (Objects.equals(this.avatar, var2.avatar)) != 0;
      }
   }

   public int hashCode() {
      Object[] var2 = new Object[4];
      var2[0] = this.userId;
      var2[1] = this.username;
      var2[2] = this.discriminator;
      var2[3] = this.avatar;
      return Objects.hash(var2);
   }

   public List<String> getFieldOrder() {
      return FIELD_ORDER;
   }

   static {
      
      FIELD_ORDER = Collections.unmodifiableList(Arrays.asList("userId", "username", "discriminator", "avatar"));
   }
   

   
}
