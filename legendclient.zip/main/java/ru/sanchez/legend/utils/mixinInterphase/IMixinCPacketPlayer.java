package ru.sanchez.legend.utils.mixinInterphase;

public interface IMixinCPacketPlayer {
   void setYaw(float var1);

   void setPitch(float var1);

   void setX(double var1);

   void setY(double var1);

   void setZ(double var1);
}
