package ru.sanchez.legend.utils.mixinInterphase;

public interface IMixinEntity {
   void setInWater(boolean var1);
}
