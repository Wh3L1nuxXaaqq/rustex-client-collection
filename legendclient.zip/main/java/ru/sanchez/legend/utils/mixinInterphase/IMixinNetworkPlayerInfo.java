package ru.sanchez.legend.utils.mixinInterphase;

import net.minecraft.world.GameType;

public interface IMixinNetworkPlayerInfo {
   void setGameType(GameType var1);
}
