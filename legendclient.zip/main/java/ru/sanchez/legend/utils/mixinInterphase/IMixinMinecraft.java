package ru.sanchez.legend.utils.mixinInterphase;

public interface IMixinMinecraft {
   void setTimer(float var1);
}
