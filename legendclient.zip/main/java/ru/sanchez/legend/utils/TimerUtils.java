package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public class TimerUtils {
    
   public long lastMS = 0L;
    
   public long prevMS = 0L;

   public boolean isDelay(long var1) {
      return System.currentTimeMillis() - this.lastMS >= var1;
   }

   public long getCurrentMS() {
      return System.nanoTime() / 1000000L;
   }

   public void setLastMS(long var1) {
      this.lastMS = var1;
   }

   public void setLastMS() {
      this.lastMS = System.currentTimeMillis();
   }

   public int convertToMS(int var1) {
      return 1000 / var1;
   }

   public boolean hasReached(float var1) {
      return (float)(this.getCurrentMS() - this.lastMS) >= var1;
   }

   public void reset() {
      this.lastMS = this.getCurrentMS();
   }

   public boolean delay(float var1) {
      return (float)(this.getTime() - this.prevMS) >= var1;
   }

   public long getTime() {
      return System.nanoTime() / 1000000L;
   }
   

   
}
