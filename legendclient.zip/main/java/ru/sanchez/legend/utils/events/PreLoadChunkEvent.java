package ru.sanchez.legend.utils.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class PreLoadChunkEvent extends Event {
}
