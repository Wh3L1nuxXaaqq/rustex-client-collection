package ru.sanchez.legend.utils.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class EventMotionUpdates extends Event {
   private float yaw;
   private float pitch;
   private boolean isSneaking;
   private boolean isSprinting;

   public EventMotionUpdates(float var1, float var2, boolean var3, boolean var4) {
      this.yaw = var1;
      this.pitch = var2;
      this.isSneaking = var3;
      this.isSprinting = var4;
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public boolean isSneaking() {
      return this.isSneaking;
   }

   public void setSneaking(boolean var1) {
      this.isSneaking = var1;
   }

   public boolean isSprinting() {
      return this.isSprinting;
   }

   public void setSprinting(boolean var1) {
      this.isSprinting = var1;
   }

   public static class Post extends EventMotionUpdates {
      public Post(float var1, float var2, boolean var3, boolean var4) {
         super(var1, var2, var3, var4);
      }
   }

   public static class Pre extends EventMotionUpdates {
      public Pre(float var1, float var2, boolean var3, boolean var4) {
         super(var1, var2, var3, var4);
      }
   }
}
