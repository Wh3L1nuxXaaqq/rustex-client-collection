package ru.sanchez.legend.utils.events.event;

public class EventUpdate extends Event {
   double posX;
   double posY;
   double posZ;
   float rotationYaw;
   float rotationPitch;
   boolean onGround;

   public EventUpdate(double var1, double var3, double var5, float var7, float var8, boolean var9) {
      this.posX = var1;
      this.posY = var3;
      this.posZ = var5;
      this.rotationYaw = var7;
      this.rotationPitch = var8;
      this.onGround = var9;
   }

   public double getPosY() {
      return this.posY;
   }

   public double getPosX() {
      return this.posX;
   }

   public double getPosZ() {
      return this.posZ;
   }

   public float getRotationPitch() {
      return this.rotationPitch;
   }

   public float getRotationYaw() {
      return this.rotationYaw;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public void setPosY(double var1) {
      this.posY = var1;
   }

   public void setPosX(double var1) {
      this.posX = var1;
   }

   public void setOnGround(boolean var1) {
      this.onGround = var1;
   }

   public void setPosZ(double var1) {
      this.posZ = var1;
   }

   public void setRotationPitch(float var1) {
      this.rotationPitch = var1;
   }

   public void setRotationYaw(float var1) {
      this.rotationYaw = var1;
   }
}
