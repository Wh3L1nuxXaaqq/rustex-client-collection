package ru.sanchez.legend.utils.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class UpdateEvent extends Event {
}
