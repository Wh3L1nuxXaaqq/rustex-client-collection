package ru.sanchez.legend.utils.events.event;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import ru.sanchez.legend.utils.events.EventTarget;

public class EventManager {
   private static final Map<Class<? extends Event>, ArrayHelper<Data>> REGISTRY_MAP = new HashMap();

   public void register(Object var1) {
      for(Method var5 : var1.getClass().getDeclaredMethods()) {
         if (!isMethodBad(var5)) {
            this.register(var5, var1);
         }
      }

   }

   public void register(Object var1, Class<? extends Event> var2) {
      for(Method var6 : var1.getClass().getDeclaredMethods()) {
         if (!isMethodBad(var6, var2)) {
            this.register(var6, var1);
         }
      }

   }

   private void register(Method var1, Object var2) {
      Class var3 = var1.getParameterTypes()[0];
      final Data var4 = new Data(var2, var1, ((EventTarget)var1.getAnnotation(EventTarget.class)).value());
      if (!var4.target.isAccessible()) {
         var4.target.setAccessible(true);
      }

      if (REGISTRY_MAP.containsKey(var3)) {
         if (!((ArrayHelper)REGISTRY_MAP.get(var3)).contains(var4)) {
            (ArrayHelper)REGISTRY_MAP.get(var3)).add(var4;
            this.sortListValue(var3);
         }
      } else {
         REGISTRY_MAP.put(var3, new ArrayHelper<Data>() {
            {
               this.add(var4);
            }
         });
      }

   }

   public void unregister(Object var1) {
      for(ArrayHelper var3 : REGISTRY_MAP.values()) {
         for(Data var5 : var3) {
            if (var5.source.equals(var1)) {
               var3.remove(var5);
            }
         }
      }

      this.cleanMap(true);
   }

   public void unregister(Object var1, Class<? extends Event> var2) {
      if (REGISTRY_MAP.containsKey(var2)) {
         for(Data var4 : (ArrayHelper)REGISTRY_MAP.get(var2)) {
            if (var4.source.equals(var1)) {
               (ArrayHelper)REGISTRY_MAP.get(var2)).remove(var4;
            }
         }

         this.cleanMap(true);
      }

   }

   public void cleanMap(boolean var1) {
      Iterator var2 = REGISTRY_MAP.entrySet().iterator();

      while(var2.hasNext()) {
         if (!var1 || ((ArrayHelper)((Map.Entry)var2.next()).getValue()).isEmpty()) {
            var2.remove();
         }
      }

   }

   public void removeEnty(Class<? extends Event> var1) {
      Iterator var2 = REGISTRY_MAP.entrySet().iterator();

      while(var2.hasNext()) {
         if (((Class)((Map.Entry)var2.next()).getKey()).equals(var1)) {
            var2.remove();
            break;
         }
      }

   }

   private void sortListValue(Class<? extends Event> var1) {
      ArrayHelper var2 = new ArrayHelper();

      for(byte var6 : Priority.VALUE_ARRAY) {
         for(Data var8 : (ArrayHelper)REGISTRY_MAP.get(var1)) {
            if (var8.priority == var6) {
               var2.add(var8);
            }
         }
      }

      REGISTRY_MAP.put(var1, var2);
   }

   private static boolean isMethodBad(Method var0) {
      return var0.getParameterTypes().length != 1 || !var0.isAnnotationPresent(EventTarget.class);
   }

   private static boolean isMethodBad(Method var0, Class<? extends Event> var1) {
      return isMethodBad(var0) || var0.getParameterTypes()[0].equals(var1);
   }

   public static ArrayHelper<Data> get(Class<? extends Event> var0) {
      return (ArrayHelper)REGISTRY_MAP.get(var0);
   }

   public static void shutdown() {
      REGISTRY_MAP.clear();
   }
}
