package ru.sanchez.legend.utils.events.event;

import java.lang.reflect.Method;

public class Data {
   public final Object source;
   public final Method target;
   public final byte priority;

   public Data(Object var1, Method var2, byte var3) {
      this.source = var1;
      this.target = var2;
      this.priority = var3;
   }
}
