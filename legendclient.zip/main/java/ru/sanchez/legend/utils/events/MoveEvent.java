package ru.sanchez.legend.utils.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class MoveEvent extends Event {
   public double motionX;
   public double motionY;
   public double motionZ;

   public MoveEvent(double var1, double var3, double var5) {
      this.motionX = var1;
      this.motionY = var3;
      this.motionZ = var5;
   }
}
