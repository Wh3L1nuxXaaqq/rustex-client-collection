package ru.sanchez.legend.utils.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderModelEvent extends Event {
   private final IBlockState state;

   public RenderModelEvent(IBlockState var1) {
      this.state = var1;
   }

   public IBlockState getState() {
      return this.state;
   }
}
