package ru.sanchez.legend.utils.events;

import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class GuiCloseEvent extends Event {
   private final GuiScreen gui;

   public GuiCloseEvent(GuiScreen var1) {
      this.gui = var1;
   }

   public GuiScreen getGui() {
      return this.gui;
   }
}
