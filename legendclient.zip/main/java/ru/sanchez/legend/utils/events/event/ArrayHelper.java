package ru.sanchez.legend.utils.events.event;

import java.util.Iterator;

public class ArrayHelper<T> implements Iterable<T> {
   private T[] elements;

   public ArrayHelper(T[] var1) {
      this.elements = (T[])var1;
   }

   public ArrayHelper() {
      this.elements = (T[])(new Object[0]);
   }

   public void add(T var1) {
      if (var1 != null) {
         Object[] var2 = new Object[this.size() + 1];

         for(int var3 = 0; var3 < var2.length; ++var3) {
            if (var3 < this.size()) {
               var2[var3] = this.get(var3);
            } else {
               var2[var3] = var1;
            }
         }

         this.set(var2);
      }

   }

   public boolean contains(T var1) {
      Object[] var2;
      for(Object var5 : var2 = this.array()) {
         if (var5.equals(var1)) {
            return true;
         }
      }

      return false;
   }

   public void remove(T var1) {
      if (this.contains(var1)) {
         Object[] var2 = new Object[this.size() - 1];
         boolean var3 = true;

         for(int var4 = 0; var4 < this.size(); ++var4) {
            if (var3 && this.get(var4).equals(var1)) {
               var3 = false;
            } else {
               var2[var3 ? var4 : var4 - 1] = this.get(var4);
            }
         }

         this.set(var2);
      }

   }

   public T[] array() {
      return this.elements;
   }

   public int size() {
      return this.array().length;
   }

   public void set(T[] var1) {
      this.elements = (T[])var1;
   }

   public T get(int var1) {
      return (T)this.array()[var1];
   }

   public void clear() {
      this.elements = (T[])(new Object[0]);
   }

   public boolean isEmpty() {
      return this.size() == 0;
   }

   public Iterator<T> iterator() {
      return new Iterator<T>() {
         private int index = 0;

         public boolean hasNext() {
            return this.index < ArrayHelper.this.size() && ArrayHelper.this.get(this.index) != null;
         }

         public T next() {
            return (T)ArrayHelper.this.get(this.index++);
         }

         public void remove() {
            ArrayHelper.this.remove(ArrayHelper.this.get(this.index));
         }
      };
   }
}
