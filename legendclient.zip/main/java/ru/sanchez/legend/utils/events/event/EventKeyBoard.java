package ru.sanchez.legend.utils.events.event;

public class EventKeyBoard extends Event {
   int key;

   public EventKeyBoard(int var1) {
      this.key = var1;
   }

   public int getKey() {
      return this.key;
   }
}
