package ru.sanchez.legend.utils.events.event;

import java.lang.reflect.InvocationTargetException;

public abstract class Event {
   private boolean cancelled;

   public Event call() {
      this.cancelled = false;
      call(this);
      return this;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }

   private static void call(Event var0) {
      EventManager var1 = Legend.eventManager;
      ArrayHelper var2 = EventManager.get(var0.getClass());
      if (var2 != null) {
         for(Data var4 : var2) {
            try {
               var4.target.invoke(var4.source, var0);
            } catch (IllegalAccessException var6) {
               var6.printStackTrace();
            } catch (InvocationTargetException var7) {
               var7.printStackTrace();
            }
         }
      }

   }
}
