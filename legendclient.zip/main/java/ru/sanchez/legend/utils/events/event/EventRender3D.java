package ru.sanchez.legend.utils.events.event;

public class EventRender3D extends Event {
   float partialTicks;

   public EventRender3D(float var1) {
      this.partialTicks = var1;
   }

   public float getPartialTicks() {
      return this.partialTicks;
   }
}
