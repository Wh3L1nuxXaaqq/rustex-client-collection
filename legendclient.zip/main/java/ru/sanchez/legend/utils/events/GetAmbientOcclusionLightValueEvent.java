package ru.sanchez.legend.utils.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GetAmbientOcclusionLightValueEvent extends Event {
   private float lightValue;

   public GetAmbientOcclusionLightValueEvent(IBlockState var1) {
      this.lightValue = var1.getBlock().getAmbientOcclusionLightValue(var1);
   }

   public float getLightValue() {
      return this.lightValue;
   }

   public void setLightValue(float var1) {
      this.lightValue = var1;
   }
}
