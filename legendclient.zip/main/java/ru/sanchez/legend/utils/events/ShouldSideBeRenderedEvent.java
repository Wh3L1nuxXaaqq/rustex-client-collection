package ru.sanchez.legend.utils.events;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.Event;

public class ShouldSideBeRenderedEvent extends Event {
   private final IBlockState blockState;
   private boolean shouldBeRendered;

   public ShouldSideBeRenderedEvent(IBlockState var1, boolean var2) {
      this.blockState = var1;
      this.shouldBeRendered = var2;
   }

   public IBlockState getBlockState() {
      return this.blockState;
   }

   public boolean getShouldBeRendered() {
      return this.shouldBeRendered;
   }

   public void setShouldBeRendered(boolean var1) {
      this.shouldBeRendered = var1;
   }
}
