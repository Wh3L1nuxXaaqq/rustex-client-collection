package ru.sanchez.legend.utils.events;

import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class SendPacketEvent extends Event {
   private Packet<?> packet;

   public SendPacketEvent(Packet<?> var1) {
      this.packet = var1;
   }

   public Packet<?> getPacket() {
      return this.packet;
   }

   public void setPacket(Packet<?> var1) {
      this.packet = var1;
   }
}
