package ru.sanchez.legend.utils.events.event;

public class EventRender2D extends Event {
   float partialTicks;

   public EventRender2D(float var1) {
      this.partialTicks = var1;
   }

   public float getPartialTicks() {
      return this.partialTicks;
   }
}
