package ru.sanchez.legend.utils.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class PlayerMoveEvent extends Event {
   public double x;
   public double y;
   public double z;

   public PlayerMoveEvent(double var1, double var3, double var5) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
   }
}
