package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import ru.sanchez.legend.utils.events.GetAmbientOcclusionLightValueEvent;
import ru.sanchez.legend.utils.events.GetLiquidCollisionBoundingBoxEvent;
import ru.sanchez.legend.utils.events.PlayerIsUserEvent;
import ru.sanchez.legend.utils.events.ReceivePacketEvent;
import ru.sanchez.legend.utils.events.RenderModelEvent;
import ru.sanchez.legend.utils.events.SendPacketEvent;
import ru.sanchez.legend.utils.events.SetOpaqueCubeEvent;
import ru.sanchez.legend.utils.events.ShouldSideBeRenderedEvent;
import ru.sanchez.legend.utils.events.UpdateWalkingPlayerEvent;

 
public class ForgeHookManager {
   public static boolean setOpaqueCube() {
      SetOpaqueCubeEvent var0 = new SetOpaqueCubeEvent();
      return (boolean)(MinecraftForge.EVENT_BUS.post(var0));
   }
   public static Packet<?> onSendPacket(Packet<?> var0) {
      SendPacketEvent var1 = new SendPacketEvent(var0);
      return (MinecraftForge.EVENT_BUS.post(var1)) != 0 ? null : var1.getPacket();
   }
   public static Packet<?> onReceivePacket(Packet<?> var0) {
      ReceivePacketEvent var1 = new ReceivePacketEvent(var0);
      return (MinecraftForge.EVENT_BUS.post(var1)) != 0 ? null : var1.getPacket();
   }
   public static boolean renderBlock(IBlockState var0) {
      EventBus var10000 = MinecraftForge.EVENT_BUS;
      return (boolean)(var10000.post(new RenderModelEvent(var0)));
   }
   public static boolean shouldSideBeRendered(IBlockState var0, IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      ShouldSideBeRenderedEvent var4 = new ShouldSideBeRenderedEvent(var0, (boolean)(var0.getBlock().shouldSideBeRendered(var0, var1, var2, var3)));
      MinecraftForge.EVENT_BUS.post(var4);
      return (boolean)(var4.getShouldBeRendered());
   }
   public static float getAmbientOcclusionLightValue(IBlockState var0) {
      GetAmbientOcclusionLightValueEvent var1 = new GetAmbientOcclusionLightValueEvent(var0);
      MinecraftForge.EVENT_BUS.post(var1);
      return var1.getLightValue();
   }
   public static AxisAlignedBB getCollisionBoundingBox() {
      GetLiquidCollisionBoundingBoxEvent var0 = new GetLiquidCollisionBoundingBoxEvent();
      MinecraftForge.EVENT_BUS.post(var0);
      return var0.getCollisionBoundingBox();
   }
   public static boolean isUser() {
      EventBus var0 = MinecraftForge.EVENT_BUS;
      return (var0.post(new PlayerIsUserEvent())) == 0;
   }
   public static boolean onUpdateWalkingPlayer() {
      EventBus var0 = MinecraftForge.EVENT_BUS;
      return (boolean)(var0.post(new UpdateWalkingPlayerEvent()));
   }
   

   

   
}
