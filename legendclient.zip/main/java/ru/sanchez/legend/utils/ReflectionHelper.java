package ru.sanchez.legend.utils;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

 
public class ReflectionHelper {
    
   public final Object Instance;
    
   public final Class aClass;
    
   public Field localField = null;

   public ReflectionHelper(Object var1, Class var2, int var3) {
      this.Instance = var1;
      this.aClass = var2;
      this.localField = this.aClass.getDeclaredFields()[var3];
   }

   public ReflectionHelper(Object var1, Class var2, Class var3) {
      this.Instance = var1;
      this.aClass = var2;

      for(Field var7 : this.aClass.getDeclaredFields()) {
         if ((var7.getType().equals(var3)) != 0) {
            this.localField = var7;
         }
      }

   }

   public ReflectionHelper(Object var1, Class var2, String var3) {
      this.Instance = var1;
      this.aClass = var2;

      try {
         this.localField = this.aClass.getDeclaredField(var3);
      } catch (Exception var5) {
         System.out.println("Error field " + var3);
      }

   }

   public Object getValue() {
      this.localField.setAccessible(true);

      try {
         return this.localField.get(this.Instance);
      } catch (IllegalAccessException var2) {
         return null;
      }
   }

   public void setValue(Object var1) {
      try {
         this.localField.setAccessible(true);
         this.localField.set(this.Instance, var1);
      } catch (Exception var3) {
         System.out.println(var3);
      }

   }

   public void setFinalValue(Object var1) {
      try {
         Field var2 = Field.class.getDeclaredField("modifiers");
         var2.setAccessible(true);
         var2.setInt(this.localField, this.localField.getModifiers() & -17);
         this.setValue(var1);
      } catch (Exception var3) {
         System.out.println(var3);
      }

   }

   public void setProtectValue(Object var1) {
      try {
         Field var2 = Field.class.getDeclaredField("modifiers");
         var2.setAccessible(true);
         var2.setInt(this.localField, this.localField.getModifiers() & -5);
         this.setValue(var1);
      } catch (Exception var3) {
         System.out.println(var3);
      }

   }

   public void setProtectFinalValue(Object var1) {
      try {
         Field var2 = Field.class.getDeclaredField("modifiers");
         var2.setAccessible(true);
         var2.setInt(this.localField, this.localField.getModifiers() & -5);
         var2.setInt(this.localField, this.localField.getModifiers() & -17);
         this.setValue(var1);
      } catch (Exception var3) {
         System.out.println(var3);
      }

   }
   public static void updateMethodCode(Class<?> var0, Method var1, String var2) {

      try {
         Field var3 = Method.class.getDeclaredField("modifiers");
         var3.setAccessible(true);
         var3.setInt(var1, var1.getModifiers() & -3);
         Class var4 = var1.getClass();
         Field var5 = var4.getDeclaredField("methodAccessor");
         var5.setAccessible(true);
         Object var6 = var5.get(var1);
         Class var7 = var6.getClass();
         Class[] var28 = new Class[2];
         var28[0] = Object.class;
         var28[1] = Object[].class;
         Method var8 = var7.getDeclaredMethod(var10001, var28);
         var8.setAccessible(true);
         Object[] var29 = new Object[2];
         var29[0] = var1;
         Object[] var10005 = new Object[1];
         var10005[0] = var2;
         var29[1] = var10005;
         var8.invoke(var6, var29);
      } catch (Exception var9) {
         var9.printStackTrace();
      }

   }
   

   

   
}
