package ru.sanchez.legend;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;
import ru.sanchez.legend.utils.events.event.EventManager;

 
public class Legend {
    
   public static int UID;
    
   public static CommandManager commandManager;
    
   public static ConfigManager configManager;
    
   public static ModuleManager moduleManager;
    
   public static EventManager eventManager;
    
   public static Legend instance;
    
   public SettingsManager settingsManager;
    
   public RotationManager rotationManager;
    
   public static Color color;
    
   public static ClickGuiScreen3 NewGui;
    
   public static boolean mixinResourcePackRepositoryLegendFirst;

   public RotationManager getRotationManager() {
      if (this.rotationManager == null) {
         this.rotationManager = new RotationManager();
      }

      return this.rotationManager;
   }

   public Minecraft mc() {
      return Minecraft.getMinecraft();
   }

   public void init() throws Exception {
      MinecraftForge.EVENT_BUS.register(this);
      this.rotationManager = new RotationManager();
      ClientWatermark.Alfa();
      EventBus var1 = FMLCommonHandler.instance().bus();
      var1.register(new FreeCamManager());
   }

   @SubscribeEvent
   public void key(InputEvent.KeyInputEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         try {
            if ((Keyboard.isCreated()) != 0 && (Keyboard.getEventKeyState()) != 0) {
               int var2 = Keyboard.getEventKey();
               if (var2 <= 0) {
                  return;
               }

               Iterator var3 = moduleManager.modules.iterator();

               while((var3.hasNext()) != 0) {
                  Module var4 = (Module)var3.next();
                  if (var4.getKey() == var2 && var2 > 0) {
                     var4.toggle();
                  }
               }
            }
         } catch (Exception var5) {
            var5.printStackTrace();
         }

      }
   }

   static {
      
      UID = 0;
      color = Color.red;
      mixinResourcePackRepositoryLegendFirst = true;
   }
   

   
}
