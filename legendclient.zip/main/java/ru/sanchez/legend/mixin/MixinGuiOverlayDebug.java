package ru.sanchez.legend.mixin;

import java.util.List;
import net.minecraft.client.gui.GuiOverlayDebug;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GuiOverlayDebug.class})
public abstract class MixinGuiOverlayDebug {
   @Inject(
      method = {"call"},
      at = {@At("RETURN")},
      cancellable = true
   )
   protected void onCall(CallbackInfoReturnable<List<String>> var1) {
      List var2 = (List)var1.getReturnValue();
      var2.set(0, "Minecraft 1.12.2 (OptiFine 1.12.2/vanilla)");
      var1.setReturnValue(var2);
   }
}
