package ru.sanchez.legend.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerControllerMP.class})
public abstract class MixinPlayerControllerMP {
   @Shadow
   @Final
   private Minecraft mc;

   @Inject(
      method = {"windowClick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onWindowClick(int var1, int var2, int var3, ClickType var4, EntityPlayer var5, CallbackInfoReturnable<ItemStack> var6) {
      if (this.mc.player.motionX != (double)0.0F || this.mc.player.motionZ != (double)0.0F) {
         var6.setReturnValue(ItemStack.EMPTY);
         var6.cancel();
      }
   }
}
