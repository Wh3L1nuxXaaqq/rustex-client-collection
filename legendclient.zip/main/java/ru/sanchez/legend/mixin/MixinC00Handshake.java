package ru.sanchez.legend.mixin;

import java.io.IOException;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.handshake.client.C00Handshake;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({C00Handshake.class})
public class MixinC00Handshake {
   @Shadow
   private int protocolVersion;
   @Shadow
   private String ip;
   @Shadow
   private int port;
   @Shadow
   private EnumConnectionState requestedState;

   @Inject(
      method = {"writePacketData"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onWritePacketData(PacketBuffer var1, CallbackInfo var2) throws IOException {
      var1.writeVarInt(this.protocolVersion);
      var1.writeString(this.ip);
      var1.writeShort(this.port);
      var1.writeVarInt(this.requestedState.getId());
      var2.cancel();
   }
}
