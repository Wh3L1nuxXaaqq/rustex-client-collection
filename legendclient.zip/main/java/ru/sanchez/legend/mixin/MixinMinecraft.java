package ru.sanchez.legend.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.sanchez.legend.utils.events.ClickMouseEvent;
import ru.sanchez.legend.utils.mixinInterphase.IMixinMinecraft;

@Mixin({Minecraft.class})
public abstract class MixinMinecraft implements IMixinMinecraft {
   @Shadow
   @Final
   @Mutable
   private Timer timer;
   @Shadow
   private int leftClickCounter;

   public void setTimer(float var1) {
      this.timer = new Timer(var1);
   }

   @Inject(
      method = {"clickMouse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onclickMouse(CallbackInfo var1) {
      if (this.leftClickCounter <= 0) {
         ClickMouseEvent var2 = new ClickMouseEvent();
         MinecraftForge.EVENT_BUS.post(var2);
         if (var2.isCanceled()) {
            var1.cancel();
            return;
         }
      }

   }
}
