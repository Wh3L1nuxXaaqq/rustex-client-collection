package ru.sanchez.legend.mixin;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import net.minecraft.client.renderer.OpenGlHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiScreenResourcePacks.class})
public abstract class MixinGuiScreenResourcePacks extends GuiScreen {
   @Inject(
      method = {"actionPerformed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void actionPerformed(GuiButton var1, CallbackInfo var2) {
      if (var1.enabled && var1.id == 2) {
         File var3 = this.getFile();

         assert var3 != null;

         OpenGlHelper.openFile(var3);
         var2.cancel();
      }

   }

   @Unique
   private File getFile() {
      try {
         File var1 = this.mc.getResourcePackRepository().getDirResourcepacks();
         File var2 = new File(this.mc.gameDir, "Legend");
         if (!var2.exists()) {
            var2.mkdir();
         } else {
            File var3 = new File(var2, "path_to_resourcepacks.txt");
            if (!var3.exists()) {
               var3.createNewFile();
            }

            if (var3.length() > 0L) {
               Scanner var4 = new Scanner(new FileReader(var3));
               String var5 = var4.nextLine();
               var4.close();
               var1 = new File(var5);
            }
         }

         return var1;
      } catch (Exception var6) {
         var6.printStackTrace();
         return null;
      }
   }
}
