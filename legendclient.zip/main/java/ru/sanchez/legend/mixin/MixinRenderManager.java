package ru.sanchez.legend.mixin;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ReportedException;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderManager.class})
public abstract class MixinRenderManager {
   @Shadow
   public TextureManager renderEngine;
   @Shadow
   private boolean renderOutlines;
   @Shadow
   private boolean debugBoundingBox;
   @Shadow
   private double renderPosX;
   @Shadow
   private double renderPosY;
   @Shadow
   private double renderPosZ;

   @Inject(
      method = {"renderEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onRenderEntity(Entity var1, double var2, double var4, double var6, float var8, float var9, boolean var10, CallbackInfo var11) {
      Render var12 = null;

      try {
         var12 = Wrapper.mc.getRenderManager().getEntityRenderObject(var1);
         if (var12 != null && this.renderEngine != null) {
            try {
               var12.setRenderOutlines(this.renderOutlines);
               var12.doRender(var1, var2, var4, var6, var8, var9);
            } catch (Throwable var18) {
               throw new ReportedException(CrashReport.makeCrashReport(var18, "Rendering entity in world"));
            }

            try {
               if (!this.renderOutlines) {
                  var12.doRenderShadowAndFire(var1, var2, var4, var6, var8, var9);
               }
            } catch (Throwable var19) {
               throw new ReportedException(CrashReport.makeCrashReport(var19, "Post-rendering entity in world"));
            }

            if (this.debugBoundingBox && !var1.isInvisible()) {
               try {
                  this.renderDebugBoundingBox(var1, var2, var4, var6, var8, var9);
               } catch (Throwable var17) {
                  throw new ReportedException(CrashReport.makeCrashReport(var17, "Rendering entity hitbox in world"));
               }
            }
         }
      } catch (Throwable var20) {
         CrashReport var14 = CrashReport.makeCrashReport(var20, "Rendering entity in world");
         CrashReportCategory var15 = var14.makeCategory("Entity being rendered");
         var1.addEntityCrashInfo(var15);
         CrashReportCategory var16 = var14.makeCategory("Renderer details");
         var16.addCrashSection("Assigned renderer", var12);
         var16.addCrashSection("Location", CrashReportCategory.getCoordinateInfo(var2, var4, var6));
         var16.addCrashSection("Rotation", var8);
         var16.addCrashSection("Delta", var9);
         throw new ReportedException(var14);
      }

      var11.cancel();
   }

   private void renderDebugBoundingBox(Entity var1, double var2, double var4, double var6, float var8, float var9) {
      GlStateManager.depthMask(false);
      GlStateManager.disableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableCull();
      GlStateManager.disableBlend();
      float var10 = var1.width / 2.0F;
      AxisAlignedBB var11 = var1.getEntityBoundingBox();
      RenderGlobal.drawBoundingBox(var11.minX - var1.posX + var2, var11.minY - var1.posY + var4, var11.minZ - var1.posZ + var6, var11.maxX - var1.posX + var2, var11.maxY - var1.posY + var4, var11.maxZ - var1.posZ + var6, 1.0F, 1.0F, 1.0F, 1.0F);
      Entity[] var12 = var1.getParts();
      if (var12 != null) {
         for(Entity var16 : var12) {
            double var17 = (var16.posX - var16.prevPosX) * (double)var9;
            double var19 = (var16.posY - var16.prevPosY) * (double)var9;
            double var21 = (var16.posZ - var16.prevPosZ) * (double)var9;
            AxisAlignedBB var23 = var16.getEntityBoundingBox();
            RenderGlobal.drawBoundingBox(var23.minX - this.renderPosX + var17, var23.minY - this.renderPosY + var19, var23.minZ - this.renderPosZ + var21, var23.maxX - this.renderPosX + var17, var23.maxY - this.renderPosY + var19, var23.maxZ - this.renderPosZ + var21, 0.25F, 1.0F, 0.0F, 1.0F);
         }
      }

      if (var1 instanceof EntityLivingBase) {
         float var24 = 0.01F;
         RenderGlobal.drawBoundingBox(var2 - (double)var10, var4 + (double)var1.getEyeHeight() - (double)0.01F, var6 - (double)var10, var2 + (double)var10, var4 + (double)var1.getEyeHeight() + (double)0.01F, var6 + (double)var10, 1.0F, 0.0F, 0.0F, 1.0F);
      }

      Tessellator var25 = Tessellator.getInstance();
      BufferBuilder var26 = var25.getBuffer();
      Vec3d var27 = var1.getLook(var9);
      var26.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var26.pos(var2, var4 + (double)var1.getEyeHeight(), var6).color(0, 0, 255, 255).endVertex();
      var26.pos(var2 + var27.x * (double)2.0F, var4 + (double)var1.getEyeHeight() + var27.y * (double)2.0F, var6 + var27.z * (double)2.0F).color(0, 0, 255, 255).endVertex();
      var25.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.enableLighting();
      GlStateManager.enableCull();
      GlStateManager.disableBlend();
      GlStateManager.depthMask(true);
   }
}
