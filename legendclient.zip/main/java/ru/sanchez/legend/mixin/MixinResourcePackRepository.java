package ru.sanchez.legend.mixin;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.lingala.zip4j.ZipFile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.ResourcePackRepository;
import org.apache.commons.io.FileUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ResourcePackRepository.class})
public abstract class MixinResourcePackRepository {
   @Final
   @Shadow
   private final File dirResourcepacks = (File)(new ReflectionHelper(Minecraft.getMinecraft(), Minecraft.class, 5)).getValue();
   @Final
   @Shadow
   private static final FileFilter RESOURCE_PACK_FILTER = new FileFilter() {
      public boolean accept(File var1) {
         boolean var2 = var1.isFile() && var1.getName().endsWith(".zip");
         boolean var3 = var1.isDirectory() && (new File(var1, "pack.mcmeta")).isFile();
         return var2 || var3;
      }
   };

   @Inject(
      method = {"getResourcePackFiles"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void actionPerformed(CallbackInfoReturnable<List<File>> var1) {
      if (!this.dirResourcepacks.isDirectory()) {
         var1.setReturnValue(Collections.emptyList());
         var1.cancel();
      }

      ArrayList var2 = new ArrayList();

      for(File var4 : Arrays.asList(this.dirResourcepacks.listFiles(RESOURCE_PACK_FILTER))) {
         if (!var4.isFile()) {
            var2.add(var4);
         } else {
            var2.add(this.legend$getFile(var4));
         }
      }

      var1.setReturnValue(var2);
      var1.cancel();
   }

   @Unique
   private File legend$getFile(File var1) {
      try {
         ZipFile var2 = new ZipFile(var1);
         if (!var2.isEncrypted()) {
            return var1;
         } else {
            var2.setPassword("SeaxaLoxSanchezTop228JBV13".toCharArray());
            String var3 = System.getProperty("java.io.tmpdir");
            File var4 = new File(var3 + var2.getFile().getName() + File.separator);
            if (var4.exists() && !Legend.mixinResourcePackRepositoryLegendFirst) {
               return var4;
            } else {
               Legend.mixinResourcePackRepositoryLegendFirst = false;
               var4.mkdir();
               var2.extractAll(var4.getPath());
               FileUtils.forceDeleteOnExit(var4);
               return var4;
            }
         }
      } catch (Exception var5) {
         var5.printStackTrace();
         return var1;
      }
   }
}
