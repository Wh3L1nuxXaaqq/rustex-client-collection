package ru.sanchez.legend.mixin;

import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.sanchez.legend.utils.events.GuiCloseEvent;

@Mixin({GuiScreen.class})
public class MixinGuiScreen {
   @Inject(
      method = {"onGuiClosed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onGuiClose(CallbackInfo var1) {
      GuiCloseEvent var2 = new GuiCloseEvent((GuiScreen)this);
      MinecraftForge.EVENT_BUS.post(var2);
      if (var2.isCanceled()) {
         var1.cancel();
      }

   }
}
