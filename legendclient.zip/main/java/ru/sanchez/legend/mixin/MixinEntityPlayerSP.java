package ru.sanchez.legend.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.MoverType;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.sanchez.legend.utils.events.EventMotionUpdates;
import ru.sanchez.legend.utils.events.MoveEvent;
import ru.sanchez.legend.utils.events.UpdateEvent;

@Mixin({EntityPlayerSP.class})
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer {
   @Shadow
   public abstract boolean isSneaking();

   @Shadow
   public abstract void setSprinting(boolean var1);

   public MixinEntityPlayerSP(World var1, GameProfile var2) {
      super(var1, var2);
   }

   @Inject(
      method = {"onUpdate"},
      at = {@At("HEAD")}
   )
   public void onUpdatePre(CallbackInfo var1) {
      UpdateEvent var2 = new UpdateEvent();
      MinecraftForge.EVENT_BUS.post(var2);
   }

   @Inject(
      method = {"onUpdateWalkingPlayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onUpdateWalkingPlayerPre(CallbackInfo var1) {
      EventMotionUpdates.Pre var2 = new EventMotionUpdates.Pre(this.rotationYaw, this.rotationPitch, this.isSneaking(), this.isSprinting());
      MinecraftForge.EVENT_BUS.post(var2);
      if (((EventMotionUpdates)var2).isCanceled()) {
         var1.cancel();
      } else {
         this.rotationYaw = ((EventMotionUpdates)var2).getYaw();
         this.rotationPitch = ((EventMotionUpdates)var2).getPitch();
         this.setSneaking(((EventMotionUpdates)var2).isSneaking());
         this.setSprinting(((EventMotionUpdates)var2).isSprinting());
      }
   }

   @Inject(
      method = {"onUpdateWalkingPlayer"},
      at = {@At("RETURN")},
      cancellable = false
   )
   public void onUpdateWalkingPlayerPost(CallbackInfo var1) {
      EventMotionUpdates.Post var2 = new EventMotionUpdates.Post(this.rotationYaw, this.rotationPitch, this.isSneaking(), this.isSprinting());
      MinecraftForge.EVENT_BUS.post(var2);
      this.rotationYaw = ((EventMotionUpdates)var2).getYaw();
      this.rotationPitch = ((EventMotionUpdates)var2).getPitch();
      this.setSneaking(((EventMotionUpdates)var2).isSneaking());
   }

   @Redirect(
      method = {"move"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"
)
   )
   public void move(AbstractClientPlayer var1, MoverType var2, double var3, double var5, double var7) {
      MoveEvent var9 = new MoveEvent(var3, var5, var7);
      MinecraftForge.EVENT_BUS.post(var9);
      super.move(var2, var9.motionX, var9.motionY, var9.motionZ);
   }
}
