package ru.sanchez.legend.mixin;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.sanchez.legend.utils.events.ReceivePacketEvent;
import ru.sanchez.legend.utils.events.SendPacketEvent;

@Mixin({NetworkManager.class})
public abstract class MixinNetworkManager {
   @Inject(
      method = {"sendPacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void sendPacket(Packet<?> var1, CallbackInfo var2) {
      if (!Minecraft.getMinecraft().isIntegratedServerRunning()) {
         if (var1 instanceof FMLProxyPacket) {
            var2.cancel();
         } else {
            if (var1 instanceof CPacketCustomPayload) {
               CPacketCustomPayload var3 = (CPacketCustomPayload)var1;
               String var4 = var3.getChannelName();
               if (!var4.startsWith("MC|")) {
                  var2.cancel();
               } else if (var4.equalsIgnoreCase("MC|Brand")) {
                  PacketBuffer var5 = (new PacketBuffer(Unpooled.buffer())).writeString("vanilla");

                  try {
                     Field var6 = var3.getClass().getDeclaredField("data");
                     var6.setAccessible(true);
                     var6.set(var3, var5);
                  } catch (NoSuchFieldException var9) {
                     try {
                        Field var7 = var3.getClass().getDeclaredField("data");
                        var7.setAccessible(true);
                        var7.set(var3, var5);
                     } catch (IllegalAccessException | NoSuchFieldException var8) {
                        (ReflectiveOperationException)var8).printStackTrace(;
                     }
                  } catch (IllegalAccessException var10) {
                     var10.printStackTrace();
                  }
               }
            }

         }
      }
   }

   @Inject(
      method = {"sendPacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onsendPacket(Packet<?> var1, CallbackInfo var2) {
      SendPacketEvent var3 = new SendPacketEvent(var1);
      MinecraftForge.EVENT_BUS.post(var3);
      if (var3.isCanceled()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"channelRead0"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void onchannelRead0(ChannelHandlerContext var1, Packet<?> var2, CallbackInfo var3) throws Exception {
      ReceivePacketEvent var4 = new ReceivePacketEvent(var2);
      MinecraftForge.EVENT_BUS.post(var4);
      if (var4.isCanceled()) {
         var3.cancel();
      }
   }
}
