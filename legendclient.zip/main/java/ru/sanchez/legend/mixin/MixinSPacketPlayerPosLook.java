package ru.sanchez.legend.mixin;

import net.minecraft.network.play.server.SPacketPlayerPosLook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import ru.sanchez.legend.utils.mixinInterphase.IMixinSPacketPlayerPosLook;

@Mixin({SPacketPlayerPosLook.class})
public class MixinSPacketPlayerPosLook implements IMixinSPacketPlayerPosLook {
   @Shadow
   private float yaw;
   @Shadow
   private float pitch;
   @Shadow
   private double x;
   @Shadow
   private double y;
   @Shadow
   private double z;

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public void setY(double var1) {
      this.y = var1;
   }

   public void setZ(double var1) {
      this.z = var1;
   }
}
