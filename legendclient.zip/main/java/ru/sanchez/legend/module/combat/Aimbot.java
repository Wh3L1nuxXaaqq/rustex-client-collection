package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.util.vector.Vector3f;

 
public class Aimbot extends Module {
    
   public float[] facing;
    
   public float[] drawcords;
    
   public TimerUtils timer = new TimerUtils();
    
   public TimerUtils timer2 = new TimerUtils();
    
   public TimerUtils timer3 = new TimerUtils();
    
   public Logger LOGGER;

   public Aimbot() {
      super("AimBot", Category.COMBAT);
      ArrayList var1 = new ArrayList(Arrays.asList("Distance", "FOV"));
      Legend.instance.settingsManager.rSetting(new Setting("Priority", this, "Distance", var1));
      Legend.instance.settingsManager.rSetting(new Setting("Range", this, (double)100.0F, (double)1.0F, (double)101.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Predict", this, 4.8, (double)0.0F, (double)7.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("VPredict", this, (double)1.0F, (double)0.0F, (double)5.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("FOV", this, (double)30.0F, (double)1.0F, (double)180.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("FovRender", this, true));
      Legend.instance.settingsManager.rSetting(new Setting("Wall", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("Visible(-FPS)", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("AutoShoot", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("AutoShootDeley", this, (double)100.0F, (double)2.0F, (double)500.0F, true));
      this.LOGGER = LogManager.getLogger("AIM");
   }

   public float[] getPredict(Entity var1) {
      double var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Predict").getValDouble();
      double var4 = Legend.instance.settingsManager.getSettingByName((Module)this, "Range").getValDouble();
      double var27 = var1.posX;
      double var47 = var1.prevPosX;
      double var6 = var27 - var47;
      var27 = var1.posZ;
      var47 = var1.prevPosZ;
      double var8 = var27 - var47;
      double var10 = (double)this.getDistance(getNextTickPlayerPos(), var1);
      double var12 = var2 + var10 / var4;
      double var14 = var1.posX + var6 * var12;
      double var16 = var1.posZ + var8 * var12;
      double var18 = Legend.instance.settingsManager.getSettingByName((Module)this, "VPredict").getValDouble();
      var12 -= var2;
      double var20 = var1.posY;
      if (var18 > (double)0.0F) {
         var20 += var18 * var12 * var12 / (double)2.0F;
      }

      int var22 = (Legend.moduleManager.getModule("NoPredict").isToggled());
      if (var22 != 0) {
         float[] var30 = new float[3];
         var30[0] = (float)var1.posX;
         var30[1] = (float)var1.posZ;
         var30[2] = (float)var20;
         return var30;
      } else {
         float[] var29 = new float[3];
         var29[0] = (float)var14;
         var29[1] = (float)var16;
         var29[2] = (float)var20;
         return var29;
      }
   }

   public float[] getPredict(Entity var1, Vec3d var2) {
      double var3 = Legend.instance.settingsManager.getSettingByName((Module)this, "Predict").getValDouble();
      double var5 = Legend.instance.settingsManager.getSettingByName((Module)this, "Range").getValDouble();
      double var26 = var1.posX;
      double var46 = var1.prevPosX;
      double var7 = var26 - var46;
      var26 = var1.posZ;
      var46 = var1.prevPosZ;
      double var9 = var26 - var46;
      double var11 = (double)mc.player.getDistance(var1);
      double var13 = var3 + var11 / var5;
      double var15 = var2.x + var7 * var13;
      double var17 = var2.z + var9 * var13;
      double var19 = Legend.instance.settingsManager.getSettingByName((Module)this, "VPredict").getValDouble();
      var13 -= var3;
      double var21 = var1.posY;
      if (var19 > (double)0.0F) {
         var21 += var19 * var13 * var13 / (double)2.0F;
      }

      int var23 = (Legend.moduleManager.getModule("NoPredict").isToggled());
      if (var23 != 0) {
         float[] var29 = new float[3];
         var29[0] = (float)var2.x;
         var29[1] = (float)var2.z;
         var29[2] = (float)var21;
         return var29;
      } else {
         float[] var28 = new float[3];
         var28[0] = (float)var15;
         var28[1] = (float)var17;
         var28[2] = (float)var21;
         return var28;
      }
   }
   public static float[] faceHead(float var0, float var1, float var2, float var3, float var4, boolean var5) {
      double var23 = (double)var0;
      double var33 = getNextTickPlayerPos().x;
      double var6 = var23 - var33;
      var23 = (double)var2;
      var33 = getNextTickPlayerPos().z;
      double var8 = var23 - var33;
      var23 = (double)var1 + 1.86;
      var33 = Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight();
      double var10 = var23 - var33;
      int var12 = (Legend.moduleManager.getModule("BAim").isToggled());
      if (var12 != 0) {
         var23 = (double)var1 + 1.1;
         var33 = Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight();
         var10 = var23 - var33;
      }

      double var13 = (double)MathHelper.sqrt(var6 * var6 + var8 * var8);
      float var27 = (float)(Math.atan2(var8, var6) * (double)180.0F / Math.PI);
      float var15 = var27 - 90.0F;
      float var16 = (float)(-(Math.atan2(var10 - 0.15, var13) * (double)180.0F / Math.PI));
      float var17 = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
      float var18 = var17 * var17 * var17 * 1.2F;
      float var19 = updateRotation(Minecraft.getMinecraft().player.rotationPitch, var16, var4);
      float var20 = updateRotation(Minecraft.getMinecraft().player.rotationYaw, var15, var3);
      float var37 = var20 % var18;
      var20 -= var37;
      var37 = var19 % var18;
      var19 -= var37;
      float[] var28 = new float[2];
      var28[0] = var20;
      var28[1] = var19;
      return var28;
   }
   public static float[] faceHitBox(float var0, float var1, float var2, float var3, float var4) {
      double var23 = (double)var0;
      double var34 = Minecraft.getMinecraft().player.posX;
      double var5 = var23 - var34;
      var23 = (double)var2;
      var34 = Minecraft.getMinecraft().player.posZ;
      double var7 = var23 - var34;
      var23 = (double)var1;
      var34 = Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight();
      double var9 = var23 - var34;
      int var11 = (Legend.moduleManager.getModule("BAim").isToggled());
      if (var11 != 0) {
         var23 = (double)var1;
         var23 -= 0.76;
         var34 = Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight();
         var9 = var23 - var34;
      }

      double var12 = (double)MathHelper.sqrt(var5 * var5 + var7 * var7);
      float var28 = (float)(Math.atan2(var7, var5) * (double)180.0F / Math.PI);
      float var14 = var28 - 90.0F;
      float var15 = (float)(-(Math.atan2(var9 - 0.15, var12) * (double)180.0F / Math.PI));
      float var16 = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
      float var17 = var16 * var16 * var16 * 1.2F;
      float var18 = updateRotation(Minecraft.getMinecraft().player.rotationPitch, var15, var4);
      float var19 = updateRotation(Minecraft.getMinecraft().player.rotationYaw, var14, var3);
      float var38 = var19 % var17;
      var19 -= var38;
      var38 = var18 % var17;
      var18 -= var38;
      float[] var29 = new float[2];
      var29[0] = var19;
      var29[1] = var18;
      return var29;
   }
   public static float updateRotation(float var0, float var1, float var2) {
      float var3 = MathHelper.wrapDegrees(var1 - var0);
      if (var3 > var2) {
         var3 = var2;
      }

      if (var3 < -var2) {
         var3 = -var2;
      }

      return var0 + var3;
   }

   public boolean lambdagetTarget(Entity var1) {
      return (boolean)(this.attackCheck(var1));
   }

   public Entity getTarget() {
      try {
         String var1 = Legend.instance.settingsManager.getSettingByName((Module)this, "Priority").getValString();
         if ((var1.equalsIgnoreCase("Distance")) != 0) {
            if (mc.player != null && (mc.player.isDead) == 0) {
               List var2 = (List)mc.world.loadedEntityList.stream().filter((var0) -> var0 != mc.player).filter((var0) -> mc.player.getDistance(var0) <= 200.0F).filter((var0) -> (var0.isDead) == 0).filter(this::lambdagetTarget).sorted(Comparator.comparing((var0) -> mc.player.getDistance(var0))).collect(Collectors.toList());
               return var2.size() > 0 ? (Entity)var2.get(0) : null;
            }
         } else if ((var1.equalsIgnoreCase("FOV")) != 0) {
            List var4 = (List)mc.world.loadedEntityList.stream().filter((var0) -> var0 != mc.player).filter((var0) -> mc.player.getDistance(var0) <= 200.0F).filter((var0) -> (var0.isDead) == 0).filter(this::lambdagetTarget).sorted(Comparator.comparing(BowAimUtils::getDistanceFromMouse)).collect(Collectors.toList());
            return var4.size() > 0 ? (Entity)var4.get(0) : null;
         }

         return null;
      } catch (Throwable var3) {
         return null;
      }
   }

   public boolean attackCheck(Entity var1) {
      int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Wall").getValBoolean());
      int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Visible(-FPS)").getValBoolean());
      if (var2 != 0) {
         return var1 instanceof EntityPlayer && (FriendManager.FRIENDS.contains(var1.getName())) == 0;
      } else if (var3 != 0) {
         return var1 instanceof EntityPlayer && (FriendManager.FRIENDS.contains(var1.getName())) == 0;
      } else {
         return var2 == 0 && (mc.player.canEntityBeSeen(var1)) != 0 && var1 instanceof EntityPlayer && (FriendManager.FRIENDS.contains(var1.getName())) == 0;
      }
   }

   @SubscribeEvent
   public void onLivingUpdate(TickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Visible(-FPS)").getValBoolean());
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "AutoShoot").getValBoolean());
         float var4 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "AutoShootDeley").getValDouble();
         EntityPlayer var5 = (EntityPlayer)this.getTarget();
         if (var5 != null && (FriendManager.FRIENDS.contains(var5.getName())) == 0 && (BowAimUtils.isInAttackFOV(var5, (int)Legend.instance.settingsManager.getSettingByName((Module)this, "FOV").getValDouble())) != 0 && (Antibot.isBot((Entity)var5)) == 0) {
            try {
               if (var2 == 0) {
                  this.facing = this.getPredict(var5);
                  this.facing = faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0F, 360.0F, false);
               } else {
                  if ((this.timer3.isDelay(15L)) == 0) {
                     return;
                  }

                  Vec3d var6 = VisiblePos(var5);
                  this.timer3.setLastMS();
                  this.facing = this.getPredict(var5, var6);
                  if (var6 == null) {
                     return;
                  }

                  this.facing = faceHitBox(this.facing[0], this.facing[2], this.facing[1], 360.0F, 360.0F);
               }
            } catch (Throwable var8) {
               return;
            }

            float var9 = this.facing[0];
            float var7 = this.facing[1];
            if ((this.timer2.isDelay(1L)) != 0) {
               mc.player.rotationYaw = this.facing[0];
               mc.player.rotationPitch = this.facing[1];
               this.timer2.setLastMS();
               if (Minecraft.getMinecraft().currentScreen == null && (this.timer.isDelay((long)var4)) != 0 && var3 != 0) {
                  mc.player.swingArm(EnumHand.MAIN_HAND);
                  this.timer.setLastMS();
               }
            }
         }

      }
   }

   @SubscribeEvent
   public void fovrender(RenderGameOverlayEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         float var2 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "FOV").getValDouble();
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "FovRender").getValBoolean());
         if (var1.getType() == ElementType.TEXT) {
            ScaledResolution var4 = var1.getResolution();
            if (var3 != 0) {
               double var5 = (double)(var2 * (float)var4.getScaledWidth() / 2.0F / mc.gameSettings.fovSetting);
               Render3DUtils.drawCircle228((float)(var4.getScaledWidth() / 2), (float)(var4.getScaledHeight() / 2), (float)((int)((double)var2 * (double)3.5F)), Color.RED.getRGB(), 360, 0.5F);
            }
         }

      }
   }
   public static Vec3d VisiblePos(EntityPlayer var0) {
      AxisAlignedBB var1 = var0.getEntityBoundingBox();
      Vec3d var2 = null;
      double var19 = var1.maxX;
      double var26 = var1.minX;
      double var3 = (var19 - var26) / (double)10.0F;
      var19 = var1.maxY;
      var26 = var1.minY;
      double var5 = (var19 - var26) / (double)20.0F;
      var19 = var1.maxZ;
      var26 = var1.minZ;
      double var7 = (var19 - var26) / (double)10.0F;
      Vec3d var9 = new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ);

      for(double var10 = var1.maxY; var10 >= var1.minY && var2 == null; var10 -= var5) {
         for(double var12 = var1.minX; var12 <= var1.maxX && var2 == null; var12 += var3) {
            for(double var14 = var1.minZ; var14 <= var1.maxZ && var2 == null; var14 += var7) {
               Vec3d var16 = new Vec3d(var12, var10, var14);
               RayTraceResult var17 = mc.world.rayTraceBlocks(var9, var16, false, true, false);
               if (var17 == null || var17.typeOfHit == Type.ENTITY) {
                  var2 = var16;
                  break;
               }
            }
         }
      }

      return var2;
   }

   public float getDistance(Vector3f var1) {
      double var10000 = mc.player.posX;
      double var10001 = (double)var1.x;
      float var2 = (float)(var10000 - var10001);
      var10000 = mc.player.posZ;
      var10001 = (double)var1.z;
      float var3 = (float)(var10000 - var10001);
      var10000 = mc.player.posY;
      var10001 = (double)var1.y;
      float var4 = (float)(var10000 - var10001);
      return MathHelper.sqrt(var2 * var2 + var3 * var3 + var4 * var4);
   }

   public float getDistance(Vec3d var1, Entity var2) {
      double var10000 = var2.posX;
      double var10001 = var1.x;
      float var3 = (float)(var10000 - var10001);
      var10000 = var2.posZ;
      var10001 = var1.z;
      float var4 = (float)(var10000 - var10001);
      var10000 = var2.posY;
      var10001 = var1.y;
      float var5 = (float)(var10000 - var10001);
      return MathHelper.sqrt(var3 * var3 + var4 * var4 + var5 * var5);
   }
   public static Vec3d getNextTickPlayerPos() {
      double var1 = mc.player.posX;
      double var10003 = mc.player.posX;
      double var10004 = mc.player.prevPosX;
      var1 += var10003 - var10004;
      var10003 = mc.player.posY;
      var10004 = mc.player.posZ;
      double var10005 = mc.player.posZ;
      double var10006 = mc.player.prevPosZ;
      return new Vec3d(var1, var10003, var10004 + (var10005 - var10006));
   }

   public float getDistance(Entity var1) {
      double var10000 = mc.player.posX;
      double var10001 = var1.posX;
      float var2 = (float)(var10000 - var10001);
      var10000 = mc.player.posZ;
      var10001 = var1.posZ;
      float var3 = (float)(var10000 - var10001);
      return MathHelper.sqrt(var2 * var2 + var3 * var3);
   }

   public void onDisable() {
      super.onDisable();
   }
   

   

   
}
