package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import ru.sanchez.legend.utils.events.SendPacketEvent;

 
public class Aimbot2 extends Module {
    
   public TimerUtils timer;
    
   public float[] silent;
    
   public float[] old;
    
   public boolean flag = false;

   public Aimbot2() {
      super("AimBot2", Category.COMBAT);
      Legend.instance.settingsManager.rSetting(new Setting("Wall", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("Silent", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("FOV", this, (double)30.0F, (double)1.0F, (double)180.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("Predict", this, (double)1.0F, (double)0.0F, (double)10.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Range", this, (double)1.0F, (double)1.0F, (double)200.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("DisableRange", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("VPredict", this, (double)0.0F, (double)0.0F, (double)10.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("AutoShoot", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("AutoShootDelay", this, (double)100.0F, (double)2.0F, (double)500.0F, true));
      this.timer = new TimerUtils();
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @SubscribeEvent
   public void onLivingUpdate(TickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "FOV").getValDouble();
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Silent").getValBoolean());
         int var4 = (Legend.instance.settingsManager.getSettingByName((Module)this, "AutoShoot").getValBoolean());
         int var5 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "AutoShootDelay").getValDouble();
         EntityPlayer var8 = this.getTarget();
         if (var8 != null) {
            if ((Antibot.isBot((Entity)var8)) == 0) {
               if ((BowAimUtils.isInAttackFOV2(var8, var2)) != 0) {
                  Vec3d var7 = this.getPredict(var8);
                  float[] var6 = faceHead(var7.x, var7.y, var7.z);
                  if (var3 != 0) {
                     this.silent = var6;
                  } else {
                     mc.player.rotationYaw = var6[0];
                     mc.player.rotationPitch = var6[1];
                  }

                  if (var4 != 0 && Minecraft.getMinecraft().currentScreen == null && (this.timer.isDelay((long)var5)) != 0) {
                     mc.player.swingArm(EnumHand.MAIN_HAND);
                     this.timer.setLastMS();
                  }

               }
            }
         }
      }
   }

   public EntityPlayer getTarget() {
      try {
         List var1 = (List)mc.world.playerEntities.stream().filter((var0) -> var0 != mc.player).filter((var0) -> (var0.isDead) == 0).filter(this::attackCheck).sorted(Comparator.comparing(BowAimUtils::getDistanceFromMouse)).collect(Collectors.toList());
         return var1.size() > 0 ? (EntityPlayer)var1.get(0) : null;
      } catch (Exception var2) {
         var2.printStackTrace();
         return null;
      }
   }

   public boolean attackCheck(EntityPlayer var1) {
      int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Wall").getValBoolean());
      if (var2 != 0) {
         return (FriendManager.FRIENDS.contains(var1.getName())) == 0;
      } else {
         return var2 == 0 && (mc.player.canEntityBeSeen(var1)) != 0 && (FriendManager.FRIENDS.contains(var1.getName())) == 0;
      }
   }

   public Vec3d getPredict(EntityPlayer var1) {
      double var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Predict").getValDouble();
      double var4 = Legend.instance.settingsManager.getSettingByName((Module)this, "VPredict").getValDouble() / (double)10.0F;
      double var6 = Legend.instance.settingsManager.getSettingByName((Module)this, "Range").getValDouble() / (double)100.0F;
      double var30 = mc.player.posX;
      double var10003 = mc.player.posX;
      double var10004 = mc.player.prevPosX;
      var30 += var10003 - var10004;
      var10003 = mc.player.posY;
      var10004 = mc.player.posZ;
      double var10005 = mc.player.posZ;
      double var10006 = mc.player.prevPosZ;
      Vec3d var8 = new Vec3d(var30, var10003, var10004 + (var10005 - var10006));
      var30 = var1.posX;
      var10003 = var1.posX;
      var10004 = var1.prevPosX;
      var30 += var10003 - var10004;
      var10003 = var1.posY;
      var10004 = var1.posZ;
      var10005 = var1.posZ;
      var10006 = var1.prevPosZ;
      Vec3d var9 = new Vec3d(var30, var10003, var10004 + (var10005 - var10006));
      double var10 = this.getDistance(var8, var9);
      double var12 = (double)0.0F;
      if ((Legend.instance.settingsManager.getSettingByName((Module)this, "DisableRange").getValBoolean()) == 0) {
         var12 = calculateTime(var10, var2, var6);
      } else {
         var12 = var10 / var2;
      }
      var30 = var1.posX;
      var10003 = var1.posX;
      var10004 = var1.prevPosX;
      var30 += (var10003 - var10004) * var12;
      var10003 = var1.posY + var4 * var12 * var12 / (double)2.0F;
      var10004 = var1.posZ;
      var10005 = var1.posZ;
      var10006 = var1.prevPosZ;
      Vec3d var14 = new Vec3d(var30, var10003, var10004 + (var10005 - var10006) * var12);
      int var15 = (Legend.moduleManager.getModule("NoPredict").isToggled());
      if (var15 != 0) {
         return new Vec3d(var1.posX, var1.posY + var4 * var12, var1.posZ);
      } else {
         return var14;
      }
   }
   public static double calculateTime(double var0, double var2, double var4) {
      double var6 = Math.pow(var2, (double)2.0F) + (double)2.0F * var4 * var0;
      double var8 = Math.sqrt(var6);
      double var10 = (-var2 + var8) / var4;
      double var10000 = -var2;
      double var12 = (var10000 - var8) / var4;
      return var10 >= (double)0.0F ? var10 : var12;
   }

   public double getDistance(Vec3d var1, Vec3d var2) {
      double var10000 = var1.x;
      double var10001 = var2.x;
      double var3 = var10000 - var10001;
      var10000 = var1.y;
      var10001 = var2.y;
      double var5 = var10000 - var10001;
      var10000 = var1.z;
      var10001 = var2.z;
      double var7 = var10000 - var10001;
      return Math.sqrt(var3 * var3 + var5 * var5 + var7 * var7);
   }
   public static float[] faceHead(double var0, double var2, double var4, float var6, float var7) {
      double var33 = mc.player.posX;
      double var25 = var0 - var33;
      var33 = mc.player.posX;
      double var41 = mc.player.prevPosX;
      double var8 = var25 + (var33 - var41);
      var33 = mc.player.posZ;
      var25 = var4 - var33;
      var33 = mc.player.posZ;
      var41 = mc.player.prevPosZ;
      double var10 = var25 + (var33 - var41);
      var25 = var2 + 1.86;
      var33 = Minecraft.getMinecraft().player.posY + (double)Minecraft.getMinecraft().player.getEyeHeight();
      double var12 = var25 - var33;
      double var14 = (double)MathHelper.sqrt(var8 * var8 + var10 * var10);
      float var28 = (float)(Math.atan2(var10, var8) * (double)180.0F / Math.PI);
      float var16 = var28 - 90.0F;
      float var17 = (float)(-(Math.atan2(var12 - 0.15, var14) * (double)180.0F / Math.PI));
      float var18 = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
      float var19 = var18 * var18 * var18 * 1.2F;
      float var20 = updateRotation(Minecraft.getMinecraft().player.rotationPitch, var17, var7);
      float var21 = updateRotation(Minecraft.getMinecraft().player.rotationYaw, var16, var6);
      float var38 = var21 % var19;
      var21 -= var38;
      var38 = var20 % var19;
      var20 -= var38;
      float[] var29 = new float[2];
      var29[0] = var21;
      var29[1] = var20;
      return var29;
   }
   public static float[] faceHead(double var0, double var2, double var4) {
      double var35 = Minecraft.getMinecraft().player.posX;
      double var6 = var0 - var35;
      double var25 = var2 + 1.86;
      var35 = mc.player.posY + (double)mc.player.getEyeHeight();
      double var8 = var25 - var35;
      var35 = Minecraft.getMinecraft().player.posZ;
      double var10 = var4 - var35;
      int var12 = (Legend.moduleManager.getModule("BAim").isToggled());
      if (var12 != 0) {
         var25 = var2 + 1.1;
         var35 = mc.player.posY + (double)mc.player.getEyeHeight();
         var8 = var25 - var35;
      }

      double var13 = Math.sqrt(var6 * var6 + var10 * var10);
      Math.sqrt(var13 * var13 + var8 * var8);
      var25 = Math.toDegrees(Math.atan2(var10, var6));
      double var17 = var25 - (double)90.0F;
      double var19 = -Math.toDegrees(Math.atan2(var8, var13));
      var25 = (double)mc.player.rotationYaw;
      double var40 = (double)mc.player.rotationYaw;
      double var21 = var25 + MathHelper.wrapDegrees(var17 - var40);
      var25 = (double)mc.player.rotationPitch;
      var40 = (double)mc.player.rotationPitch;
      double var23 = var25 + MathHelper.wrapDegrees(var19 - var40);
      float[] var30 = new float[2];
      var30[0] = (float)var21;
      var30[1] = (float)var23;
      return var30;
   }
   public static float updateRotation(float var0, float var1, float var2) {
      float var3 = MathHelper.wrapDegrees(var1 - var0);
      if (var3 > var2) {
         var3 = var2;
      }

      if (var3 < -var2) {
         var3 = -var2;
      }

      return var0 + var3;
   }

   @SubscribeEvent
   public void fovrender(RenderGameOverlayEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (var1.getType() == ElementType.TEXT) {
            int var2 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "FOV").getValDouble();
            ScaledResolution var3 = var1.getResolution();
            Render3DUtils.drawCircle228((float)(var3.getScaledWidth() / 2), (float)(var3.getScaledHeight() / 2), (float)((int)((double)var2 * (double)3.5F)), Color.RED.getRGB(), 360, 0.5F);
         }
      }
   }

   @SubscribeEvent
   public void onSendPacket(SendPacketEvent var1) {
      int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Silent").getValBoolean());
      if (var2 != 0) {
         try {
            if (var1.getPacket() instanceof CPacketAnimation) {
               if ((this.flag) == 0 && this.silent != null) {
                  var1.setCanceled(true);
                  this.flag = true;
                  NetHandlerPlayClient var7 = mc.player.connection;
                  var7.sendPacket(new CPacketPlayer.Rotation(this.silent[0], this.silent[1], (boolean)(mc.player.onGround)));
                  var7 = mc.player.connection;
                  var7.sendPacket(new CPacketPlayer.Rotation(this.silent[0], this.silent[1], (boolean)(mc.player.onGround)));
                  var7 = mc.player.connection;
                  var7.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
               } else {
                  this.flag = false;
               }

               this.silent = null;
            }
         } catch (Exception var4) {
            var4.printStackTrace();
         }

      }
   }
   

   

   
}
