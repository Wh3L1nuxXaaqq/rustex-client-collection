package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook.EnumFlags;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ru.sanchez.legend.utils.events.ReceivePacketEvent;
import ru.sanchez.legend.utils.mixinInterphase.IMixinSPacketPlayerPosLook;

 
public class Norotate extends Module {

   public Norotate() {
      super("NoRotate", Category.COMBAT);
   }

   @SubscribeEvent
   public void onReceivePacket(ReceivePacketEvent var1) {

      try {
         if (var1.getPacket() instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook var2 = (SPacketPlayerPosLook)var1.getPacket();
            IMixinSPacketPlayerPosLook var3 = (IMixinSPacketPlayerPosLook)var2;
            if ((var2.getFlags().contains(EnumFlags.X_ROT)) != 0) {
               var3.setPitch(0.0F);
               NetHandlerPlayClient var7 = mc.player.connection;
               var7.sendPacket(new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, (boolean)(mc.player.onGround)));
            }

            if ((var2.getFlags().contains(EnumFlags.Y_ROT)) != 0) {
               var3.setYaw(0.0F);
               NetHandlerPlayClient var8 = mc.player.connection;
               var8.sendPacket(new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, (boolean)(mc.player.onGround)));
            }

            if ((var2.getFlags().contains(EnumFlags.X_ROT)) == 0 || (var2.getFlags().contains(EnumFlags.Y_ROT)) == 0) {
               var3.setPitch(mc.player.rotationPitch);
               var3.setYaw(mc.player.rotationYaw);
               NetHandlerPlayClient var9 = mc.player.connection;
               var9.sendPacket(new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, (boolean)(mc.player.onGround)));
            }
         }
      } catch (NullPointerException var4) {
      }

   }
   

   

   
}
