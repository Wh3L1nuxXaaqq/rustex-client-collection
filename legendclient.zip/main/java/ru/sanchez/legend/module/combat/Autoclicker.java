package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import io.netty.util.internal.ThreadLocalRandom;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

 
public class Autoclicker extends Module {
    
   public double holdLength;
    
   public double min;
    
   public long hold;
    
   public double max;
    
   public double speed;
    
   public long lastClick;

   public void onEnable() {
      super.onEnable();
      this.updateVals();
   }

   public Autoclicker() {
      super("AutoClicker", Category.COMBAT);
      Legend.instance.settingsManager.rSetting(new Setting("MinCPS", this, (double)8.0F, (double)1.0F, (double)20.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("MaxCPS", this, (double)12.0F, (double)1.0F, (double)20.0F, false));
   }

   public void updateVals() {
      this.min = Legend.instance.settingsManager.getSettingByName((Module)this, "MinCPS").getValDouble();
      this.max = Legend.instance.settingsManager.getSettingByName((Module)this, "MaxCPS").getValDouble();
      if (this.min >= this.max) {
         this.max = this.min + (double)1.0F;
      }

      ThreadLocalRandom var10002 = ThreadLocalRandom.current();
      double var10003 = this.min;
      this.speed = (double)1.0F / var10002.nextDouble(var10003 - 0.2, this.max);
      this.holdLength = this.speed / ThreadLocalRandom.current().nextDouble(this.min, this.max);
   }

   @SubscribeEvent
   public void onTick(TickEvent.RenderTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if ((Mouse.isButtonDown(0)) != 0 && mc.currentScreen == null) {
            if ((double)(System.currentTimeMillis() - this.lastClick) > this.speed * (double)1000.0F) {
               this.lastClick = System.currentTimeMillis();
               if (this.hold < this.lastClick) {
                  this.hold = this.lastClick;
               }

               mc.player.swingArm(EnumHand.MAIN_HAND);
               this.updateVals();
            } else if ((double)(System.currentTimeMillis() - this.hold) > this.holdLength * (double)1000.0F) {
               KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
               this.updateVals();
            }
         }

      }
   }
   

   

   
}
