package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Autoreload extends Module {

   public void onEnable() {
      super.onEnable();
   }

   public Autoreload() {
      super("AutoReload", Category.COMBAT);
   }

   @SubscribeEvent
   public void onTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         ItemStack var2 = mc.player.inventory.getCurrentItem();
         if ((var2.getItem().equals(Items.DIAMOND_SWORD)) != 0) {
            var10000 = var2.getDisplayName();
            int var8 = var2.getDisplayName().length();
            String var3 = var10000.substring(var8 - 3);
            if ((var3.contains("0")) != 0) {
               try {
                  Integer.parseInt(String.valueOf(var3.toCharArray()[0]));
                  return;
               } catch (NumberFormatException var5) {
                  (new Thread(() -> {
                     try {
                        Thread.sleep(100L);
                        mc.player.dropItem(false);
                     } catch (InterruptedException var1) {
                     }

                  })).start();
               }
            }
         }

      }
   }
   

   

   
}
