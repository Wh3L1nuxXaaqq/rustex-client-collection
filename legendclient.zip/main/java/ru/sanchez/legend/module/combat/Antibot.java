package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Antibot extends Module {
    
   public static List<String> BOTS;
    
   public static boolean toggle;
    
   public static final boolean $assertionsDisabled;

   public Antibot() {
      super("AntiBot", Category.COMBAT);
      Legend.instance.settingsManager.rSetting(new Setting("Remove", this, true));
   }

   public void onEnable() {
      super.onEnable();
      toggle = true;
   }

   public void onDisable() {
      super.onDisable();
      toggle = false;
      BOTS.clear();
   }
   public static boolean isBot(String var0) {
      if (toggle) {
         Iterator var1 = BOTS.iterator();

         while((var1.hasNext()) != 0) {
            String var2 = (String)var1.next();
            if ((var2.equalsIgnoreCase(var0)) != 0) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }
   public static boolean isBlockMaterial(BlockPos var0, Block var1) {
      return getBlock(var0) == Blocks.AIR;
   }
   public static Block getBlock(BlockPos var0) {
      return getState(var0).getBlock();
   }
   public static IBlockState getState(BlockPos var0) {
      return mc.world.getBlockState(var0);
   }

   @SubscribeEvent
   public void onTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Remove").getValBoolean());
         Iterator var3 = mc.world.loadedEntityList.iterator();

         while((var3.hasNext()) != 0) {
            Entity var4 = (Entity)var3.next();
            if (var4 != mc.player && var4.ticksExisted < 5 && var4 instanceof EntityOtherPlayerMP && (var4.isInvisible()) != 0) {
               BOTS.add(var4.getName());
               if (var2 != 0) {
                  mc.world.removeEntity(var4);
               }
            }
         }

      }
   }
   public static boolean isBot(Entity var0) {
      if (($assertionsDisabled) == 0 && var0 == null) {
         AssertionError var2 = new AssertionError();
         throw var2;
      } else {
         return (boolean)(var0 != mc.player && var0.ticksExisted < 5 && (FriendManager.FRIENDS.contains(var0.getName())) == 0 && var0 instanceof EntityOtherPlayerMP ? (var0.isInvisible()) : 0);
      }
   }

   static {
      
      $assertionsDisabled = (boolean)(Antibot.class.desiredAssertionStatus() == 0 ? 1 : 0);
      BOTS = new ArrayList();
   }
   

   
}
