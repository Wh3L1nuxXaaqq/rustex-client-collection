package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Hitbox extends Module {

   public Hitbox() {
      super("HitBox", Category.COMBAT);
      Legend.instance.settingsManager.rSetting(new Setting("Size", this, 0.3, 0.3, (double)5.0F, false));
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @SubscribeEvent
   public void onUpdate(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if ((this.isToggled()) != 0) {
            float var2 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Size").getValDouble();
            Iterator var3 = mc.world.playerEntities.iterator();

            while((var3.hasNext()) != 0) {
               EntityPlayer var4 = (EntityPlayer)var3.next();
               if ((var4.equals(mc.player)) == 0 && (FriendManager.isFriend(var4.getName())) == 0) {
                  double var10003 = var4.posX;
                  double var10004 = (double)var2;
                  var10003 -= var10004;
                  var10004 = var4.getEntityBoundingBox().minY;
                  double var10005 = var4.posZ;
                  double var10006 = (double)var2;
                  var10005 -= var10006;
                  var10006 = var4.posX + (double)var2;
                  double var10008 = var4.posZ + (double)var2;
                  var4.setEntityBoundingBox(new AxisAlignedBB(var10003, var10004, var10005, var10006, var4.getEntityBoundingBox().maxY, var10008));
               }
            }
         } else {
            Iterator var5 = mc.world.playerEntities.iterator();

            while((var5.hasNext()) != 0) {
               EntityPlayer var6 = (EntityPlayer)var5.next();
               if (var6 != null && var6 != mc.player) {
                  double var13 = var6.posX;
                  var13 -= (double)0.3F;
                  double var16 = var6.getEntityBoundingBox().minY;
                  double var18 = var6.posZ;
                  var6.setEntityBoundingBox(new AxisAlignedBB(var13, var16, var18 - (double)0.3F, var6.posX + (double)0.3F, var6.getEntityBoundingBox().maxY, var6.posZ + (double)0.3F));
               }
            }
         }

      }
   }
   

   

   
}
