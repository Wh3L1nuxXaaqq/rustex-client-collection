package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Killjest extends Module {

   public Killjest() {
      super("KillJest", Category.COMBAT);
   }

   @SubscribeEvent
   public void onUpdate(LivingEvent.LivingUpdateEvent var1) {
      EntityPlayer var2 = this.getTarget();
      if (var2 != null) {
         if (mc.player.ticksExisted % 2 != 0) {
            mc.playerController.attackEntity(mc.player, var2);
         }
      }
   }

   public EntityPlayer getTarget() {
      List var1 = (List)mc.world.playerEntities.stream().filter((var0) -> var0 != mc.player).filter((var0) -> (var0.isDead) == 0).filter((var0) -> (FriendManager.isFriend(var0.getName())) == 0).sorted(Comparator.comparing(this::getDistance)).collect(Collectors.toList());
      return (var1.isEmpty()) != 0 ? null : (EntityPlayer)var1.get(0);
   }

   public double getDistance(EntityPlayer var1) {
      return (double)mc.player.getDistance(var1);
   }
   

   

   
}
