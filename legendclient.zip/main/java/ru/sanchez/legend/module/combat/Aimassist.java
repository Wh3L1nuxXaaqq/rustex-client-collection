package ru.sanchez.legend.module.combat;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Comparator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Aimassist extends Module {

   public Aimassist() {
      super("AimAssist", Category.COMBAT);
      Legend.instance.settingsManager.rSetting(new Setting("Range", this, (double)3.0F, (double)1.0F, (double)10.0F, true));
   }

   @SubscribeEvent
   public void onUpdate(LivingEvent.LivingUpdateEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         double var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Range").getValDouble();
         EntityPlayer var4 = (EntityPlayer)mc.world.playerEntities.stream().filter((var0) -> var0 != mc.player).min(Comparator.comparing((var0) -> var0.getDistance(mc.player))).filter((var2x) -> (double)var2x.getDistance(mc.player) <= var2).orElse((Object)null);
         if (var4 != null && (mc.player.canEntityBeSeen(var4)) != 0) {
            if ((FriendManager.isFriend(var4.getName())) != 0) {
               return;
            }

            mc.player.rotationYaw = this.rotations(var4)[0];
            mc.player.rotationPitch = this.rotations(var4)[1];
         }

      }
   }

   public float[] rotations(EntityPlayer var1) {
      double var13 = var1.posX;
      double var21 = mc.player.posX;
      double var2 = var13 - var21;
      var13 = var1.posY;
      var21 = mc.player.posY + (double)mc.player.getEyeHeight();
      double var4 = var13 - var21 + (double)1.5F;
      var13 = var1.posZ;
      var21 = mc.player.posZ;
      double var6 = var13 - var21;
      double var8 = (double)MathHelper.sqrt(var2 * var2 + var6 * var6);
      var13 = MathHelper.atan2(var6, var2) * (180D / Math.PI);
      float var10 = (float)(var13 - (double)90.0F);
      float var11 = (float)(-MathHelper.atan2(var4, var8) * (180D / Math.PI));
      float[] var17 = new float[2];
      var17[0] = var10;
      var17[1] = var11;
      return var17;
   }
   

   

   
}
