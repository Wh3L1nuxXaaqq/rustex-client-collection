package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

 
public class Autofarm extends Module {
    
   public TimerUtils timer = new TimerUtils();
    
   public final Logger LOGGER = LogManager.getLogger("AutoFarm");

   public Autofarm() {
      super("AutoFarm", Category.OUTHER);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         Iterator var2 = mc.world.loadedEntityList.iterator();

         while((var2.hasNext()) != 0) {
            Entity var3 = (Entity)var2.next();
            if (var3 instanceof EntityArmorStand) {
               EntityArmorStand var4 = (EntityArmorStand)var3;
               if ((var4.getDisplayName().getUnformattedText().contains("\u2600")) != 0 || (var4.getDisplayName().getUnformattedText().contains("\u2717")) != 0) {
                  if (mc.player.getDistance(var4) > 5.0F) {
                     return;
                  }
                  Vec2f var5 = new Vec2f(mc.player.rotationPitch, mc.player.rotationYaw);
                  Vec2f var6 = this.rotations(new Vec3d(var4.posX, var4.posY, var4.posZ));
                  Vec2f var7 = this.subVec2f(var6, var5);
                  mc.player.rotationYaw = var6.y;
                  mc.player.rotationPitch = var6.x;
                  if ((double)var7.x > (double)0.0F && (double)var7.x < (double)9.0F && (double)var7.y < (double)3.0F && (double)var7.y > (double)-3.0F && (mc.player.canEntityBeSeen(var4)) != 0) {
                     mc.player.swingArm(EnumHand.MAIN_HAND);
                  }
               }
            }
         }

      }
   }

   public void onEnable() {
      super.onEnable();
   }

   public Vec2f rotations(Vec3d var1) {
      double var12 = var1.x;
      double var17 = mc.player.posX;
      double var2 = var12 - var17;
      var12 = var1.y;
      var17 = mc.player.posY + (double)mc.player.getEyeHeight();
      double var4 = var12 - var17 + 0.3;
      var12 = var1.z;
      var17 = mc.player.posZ;
      double var6 = var12 - var17;
      double var8 = (double)MathHelper.sqrt(var2 * var2 + var6 * var6);
      var12 = MathHelper.atan2(var6, var2) * (180D / Math.PI);
      float var10 = (float)(var12 - (double)90.0F);
      float var11 = (float)(-MathHelper.atan2(var4, var8) * (180D / Math.PI));
      return new Vec2f(var11, var10);
   }

   public Vec2f subVec2f(Vec2f var1, Vec2f var2) {
      Vec2f var3 = new Vec2f(-var2.x, -var2.y);
      float var4 = (float)transform((double)(var1.y + var3.y));
      return new Vec2f(var1.x + var3.x, var4);
   }
   public static double transform(double var0) {
      double var2 = var0;
      if (Math.abs(var0) >= (double)360.0F) {
         var2 = var0 % (double)360.0F;
      }

      return var2;
   }
   

   

   
}
