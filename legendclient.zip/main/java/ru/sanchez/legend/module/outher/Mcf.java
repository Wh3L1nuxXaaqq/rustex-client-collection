package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

 
public class Mcf extends Module {

   public Mcf() {
      super("MCF", Category.OUTHER);
   }

   @SubscribeEvent
   public void onMiddleClick(InputEvent.MouseInputEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (mc.player != null && mc.world != null) {
            if ((Mouse.getEventButtonState()) != 0 && Mouse.getEventButton() == 2 && mc.objectMouseOver.entityHit instanceof EntityPlayer) {
               this.clickFriend();
            }

         }
      }
   }

   public void clickFriend() {
      String var1 = mc.objectMouseOver.entityHit.getName();
      if ((FriendManager.isFriend(var1)) != 0) {
         FriendManager.FRIENDS.remove(var1);
         NotificationManager.add(TextFormatting.RED + var1, "Remove from Friend list", NotificationType.OK);
      } else {
         FriendManager.FRIENDS.add(var1);
         NotificationManager.add(TextFormatting.GREEN + var1, "add in Friends list", NotificationType.OK);
      }

   }
   

   

   
}
