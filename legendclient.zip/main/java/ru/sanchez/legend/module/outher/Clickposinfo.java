package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Clickposinfo extends Module {

   public Clickposinfo() {
      super("ClickPosInfo", Category.OUTHER);
   }

   @SubscribeEvent
   public void onRightClickBlock(PlayerInteractEvent.RightClickBlock var1) {
      if ((Wrapper.nullCheck()) != 0) {
         BlockPos var2 = var1.getPos();
         double var3 = (double)var2.getX();
         double var5 = (double)var2.getY();
         double var7 = (double)var2.getZ();
         ChatUtils.sendMessage(var3 + " " + var5 + " " + var7);
         ChatUtils.sendMessage(String.valueOf(mc.world.getBlockState(var2)));
      }
   }
   

   

   
}
