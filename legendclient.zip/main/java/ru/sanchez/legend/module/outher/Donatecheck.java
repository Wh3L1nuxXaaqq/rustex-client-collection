package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import net.minecraft.client.network.NetworkPlayerInfo;

 
public class Donatecheck extends Module {
    
   public Thread thread;

   public Donatecheck() {
      super("DonateCheck", Category.OUTHER);
   }

   public void onEnable() {
      super.onEnable();
      if ((Wrapper.nullCheck()) != 0) {
         ArrayList var1 = new ArrayList();
         Iterator var2 = mc.player.connection.getPlayerInfoMap().iterator();

         while((var2.hasNext()) != 0) {
            NetworkPlayerInfo var3 = (NetworkPlayerInfo)var2.next();
            var1.add(var3.getGameProfile().getName());
         }
         this.thread = new Thread(() -> {

            try {
               for(int var1x = 0; var1x < var1.size(); ++var1x) {
                  StringBuilder var6 = (new StringBuilder()).append("/m ").append((String)var1.get(var1x)).append(" ");
                  ChatUtils.say(var6.append((new Random()).nextInt(1000) + 1).toString());
                  Thread.sleep((long)(((double)(new Random()).nextFloat() * (double)0.5F + (double)4.0F) * (double)1000.0F));
               }

            } catch (InterruptedException var2) {
               RuntimeException var5 = new RuntimeException(var2);
               throw var5;
            }
         });
         this.thread.start();
      }
   }

   public void onDisable() {
      super.onDisable();
      this.thread.interrupt();
   }
   

   

   
}
