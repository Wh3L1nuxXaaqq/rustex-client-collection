package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.Display;

 
public class Selfdestruct extends Module {
    
   public static boolean self;

   public Selfdestruct() {
      super("SelfDestruct", Category.OUTHER);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
   }

   public void onEnable() {
      super.onEnable();
      if ((Wrapper.nullCheck()) != 0) {
         mc.displayGuiScreen((GuiScreen)null);
         Display.setTitle("Minecraft 1.12.2");
         Iterator var1 = Legend.moduleManager.getModuleList().iterator();

         while((var1.hasNext()) != 0) {
            Module var2 = (Module)var1.next();
            if ((var2.getName().equals("SelfDestruct")) == 0 && (var2.isToggled()) != 0) {
               var2.toggle();
            }
         }

         self = true;
         mc.player.rotationYaw = 0.0F;
         mc.player.rotationPitch = 0.0F;
      }
   }

   static {
      
      self = false;
   }
   

   
}
