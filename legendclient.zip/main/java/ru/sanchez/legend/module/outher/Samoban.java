package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

 
public class Samoban extends Module {

   public Samoban() {
      super("SamoBan", Category.OUTHER);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         mc.playerController.attackEntity(mc.player, mc.player);
         mc.playerController.attackEntity(mc.player, mc.player);
      }
   }

   public void onEnable() {
      (new Thread(() -> {
         int var1 = JOptionPane.showConfirmDialog(new JDialog(), "\u0412\u044b \u0445\u043e\u0442\u0438\u0442\u0435 \u043e\u0442\u043b\u0435\u0442\u0435\u0442\u044c \u0432 \u0431\u0430\u043d?", "BAN", 0);
         if (var1 == 0) {
            super.onEnable();
         } else {
            super.setToggled(false);
         }

      })).start();
   }

   @SubscribeEvent
   public void onPlayerLeave(FMLNetworkEvent.ClientDisconnectionFromServerEvent var1) {
      this.toggle();
   }
   

   

   
}
