package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

 
public class Freecam extends Module {

   public Freecam() {
      super("FreeCam", Category.OUTHER);
   }

   public void onEnable() {
      if (mc.player != null && mc.player.connection != null && mc.world != null && mc.player.connection.getNetworkManager() != null) {
         super.onEnable();
         FreeCamManager.getInstance().Enable(true);
      }
   }

   public void onDisable() {
      super.onDisable();
      FreeCamManager.getInstance().Disable();
   }

   @SubscribeEvent
   public void onPlayerLeave(FMLNetworkEvent.ClientDisconnectionFromServerEvent var1) {
      this.toggle();
   }
   

   
}
