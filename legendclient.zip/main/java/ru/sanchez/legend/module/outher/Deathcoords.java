package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Deathcoords extends Module {
    
   public static int deley;

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (mc.player.getHealth() < 0.0F || mc.player.isDead || (mc.player.isEntityAlive()) == 0) {
            ++deley;
            if (deley == 0) {
               ChatUtils.sendMessage(String.valueOf((new StringBuilder()).append(" DeathCoords! X:").append((int)mc.player.posX).append(" Y:").append((int)mc.player.posY).append(" Z:").append((int)mc.player.posZ)));
            }

            if (deley >= 10) {
               deley = -1;
            }
         }

      }
   }

   public Deathcoords() {
      super("DeathCoords", Category.OUTHER);
   }

   public void onDisable() {
      super.onDisable();
   }
   

   

   
}
