package ru.sanchez.legend.module.outher;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Autoarmor extends Module {
    
   public TimerUtils timer = new TimerUtils();

   public Autoarmor() {
      super("AutoArmor", Category.OUTHER);
   }
   public static boolean isNullOrEmpty(ItemStack var0) {
      return var0 == null;
   }

   @SubscribeEvent
   public void onClientTickEvent(TickEvent.ClientTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (!(mc.currentScreen instanceof GuiContainer) || mc.currentScreen instanceof InventoryEffectRenderer) {
            InventoryPlayer var2 = mc.player.inventory;
            if (mc.player.movementInput.moveStrafe == 0.0F && mc.player.movementInput.moveStrafe == 0.0F) {
               int[] var3 = new int[4];
               int[] var4 = new int[4];

               for(int var5 = 0; var5 < 4; ++var5) {
                  var3[var5] = -1;
                  ItemStack var6 = var2.armorItemInSlot(var5);
                  if ((isNullOrEmpty(var6)) == 0 && var6.getItem() instanceof ItemArmor) {
                     var4[var5] = this.getArmorValue((ItemArmor)var6.getItem(), var6);
                  }
               }

               for(int var10 = 0; var10 < 36; ++var10) {
                  ItemStack var12 = var2.getStackInSlot(var10);
                  if ((isNullOrEmpty(var12)) == 0 && var12.getItem() instanceof ItemArmor) {
                     ItemArmor var7 = (ItemArmor)var12.getItem();
                     int var8 = var7.armorType.getIndex();
                     int var9 = this.getArmorValue(var7, var12);
                     if (var9 > var4[var8]) {
                        var3[var8] = var10;
                        var4[var8] = var9;
                     }
                  }
               }
               Integer[] var42 = new Integer[4];
               var42[0] = 0;
               var42[1] = 1;
               var42[2] = 2;
               var42[3] = 3;
               ArrayList var11 = new ArrayList(Arrays.asList(var42));
               Collections.shuffle(var11);
               Iterator var13 = var11.iterator();

               while((var13.hasNext()) != 0) {
                  int var14 = (Integer)var13.next();
                  int var15 = var3[var14];
                  if (var15 != -1) {
                     ItemStack var21 = var2.armorItemInSlot(var14);
                     ItemStack var16 = var21;
                     if ((isNullOrEmpty(var21)) != 0 || var2.getFirstEmptyStack() != -1) {
                        if (var15 < 9) {
                           var15 += 36;
                        }

                        if ((isNullOrEmpty(var16)) == 0) {
                           PlayerControllerMP var22 = mc.playerController;
                           var22.windowClick(0, 8 - var14, 0, ClickType.QUICK_MOVE, mc.player);
                        }

                        mc.playerController.windowClick(0, var15, 0, ClickType.QUICK_MOVE, mc.player);
                        break;
                     }
                  }
               }
            }
         }

      }
   }

   public int getArmorValue(ItemArmor var1, ItemStack var2) {
      int var3 = var1.damageReduceAmount;
      int var4 = (int)var1.toughness;
      int var5 = var1.getArmorMaterial().getDamageReductionAmount(EntityEquipmentSlot.LEGS);
      Enchantment var6 = Enchantments.PROTECTION;
      return var3 * 5 + var6.calcModifierDamage(EnchantmentHelper.getEnchantmentLevel(var6, var2), DamageSource.causePlayerDamage(mc.player)) * 3 + var4 + var5;
   }
   

   

   
}
