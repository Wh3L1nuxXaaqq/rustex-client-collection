package ru.sanchez.legend.module;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

 
public enum Category {
    
   COMBAT,
    
   MOVEMENT,
    
   RENDER,
    
   OUTHER,
    
   HUD,
    
   EXPLOIT;

   static {
      
      COMBAT = new Category("COMBAT", 0);
      MOVEMENT = new Category("MOVEMENT", 1);
      RENDER = new Category("RENDER", 2);
      OUTHER = new Category("OUTHER", 3);
      HUD = new Category("HUD", 4);
      EXPLOIT = new Category("EXPLOIT", 5);
   }
   
}
