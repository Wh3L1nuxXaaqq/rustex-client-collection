package ru.sanchez.legend.module;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;

 
public abstract class Module {
    
   public static Minecraft mc;
    
   public String name;
    
   public String description;
    
   public int key;
    
   public float anim;
    
   public SmoothAnimationTimer animx = new SmoothAnimationTimer(1.0F, 1.0F, 0.05F);
    
   public Category category;
    
   public boolean toggled;
    
   public boolean visible = true;

   public Module(String var1, Category var2) {
      this.name = var1;
      this.description = this.description;
      this.key = 0;
      this.category = var2;
      this.toggled = false;
   }

   public String getDescription() {
      return this.description;
   }

   public void setDescription(String var1) {
      this.description = var1;
   }

   public int getKey() {
      return this.key;
   }

   public void setKey(int var1) {
      this.key = var1;
   }

   public boolean isToggled() {
      return (boolean)(this.toggled);
   }

   public void setToggled(boolean var1) {
      this.toggled = (boolean)(var1);
      if ((Selfdestruct.self) == 0) {
         if (this.toggled) {
            this.onEnable();
         } else {
            this.onDisable();
         }
      }

   }

   public void toggle() {
      this.toggled = (boolean)((this.toggled) == 0 ? 1 : 0);
      if ((Selfdestruct.self) == 0) {
         if (this.toggled) {
            this.onEnableR();
         } else {
            this.onDisableR();
         }
      }

   }

   public void onEnable() {
      MinecraftForge.EVENT_BUS.register(this);
      String var1 = TextFormatting.GREEN + "Enable!";
      NotificationManager.add(this.name, var1, NotificationType.Green);
   }

   public void onEnableR() {
      this.onEnable();
   }

   public void onDisableR() {
      this.onDisable();
   }

   public void onDisable() {
      MinecraftForge.EVENT_BUS.unregister(this);
      String var1 = TextFormatting.RED + "Enable!";
      NotificationManager.add(this.name, var1, NotificationType.Red);
   }

   public String getName() {
      return this.name;
   }

   public Category getCategory() {
      return this.category;
   }

   public void onCameraSetup(EntityViewRenderEvent.CameraSetup var1) {
   }

   static {
      
      mc = Minecraft.getMinecraft();
   }
   

   
}
