package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Chams extends Module {
    
   public float zLevel;

   public Chams() {
      super("Chams", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("R", this, (double)255.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("G", this, (double)0.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("B", this, (double)0.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("A", this, (double)50.0F, (double)0.0F, (double)100.0F, true));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onRenderLiving(RenderLivingEvent.Pre var1) {
      if ((Wrapper.nullCheck()) != 0) {
         GlStateManager.pushMatrix();
         GlStateManager.pushAttrib();
         EntityLivingBase var2 = var1.getEntity();
         if (var2 instanceof EntityPlayer) {
            if ((((Entity)var2).equals(mc.player)) != 0 || (FriendManager.isFriend(((Entity)var2).getName())) != 0) {
               return;
            }

            int var3 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "R").getValDouble();
            int var4 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "G").getValDouble();
            int var5 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "B").getValDouble();
            int var6 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "A").getValDouble();
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            GlStateManager.color((float)var3 / 255.0F, (float)var4 / 255.0F, (float)var5 / 255.0F, (float)var6 / 100.0F);
         }

      }
   }

   @SubscribeEvent
   public void onRenderLiving(RenderLivingEvent.Post var1) {
      if ((Wrapper.nullCheck()) != 0) {
         GlStateManager.popMatrix();
         GlStateManager.popAttrib();
      }
   }
   

   

   
}
