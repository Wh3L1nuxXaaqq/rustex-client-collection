package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.entity.EntityOtherPlayerMP;

 
public class Fakeplayer extends Module {
    
   public EntityOtherPlayerMP fakePlayer;

   public Fakeplayer() {
      super("FakePlayer", Category.RENDER);
   }

   public void onEnable() {
      if ((Wrapper.nullCheck()) != 0) {
         this.fakePlayer = new EntityOtherPlayerMP(mc.world, mc.player.getGameProfile());
         this.fakePlayer.setEntityId(-1882);
         this.fakePlayer.copyLocationAndAnglesFrom(mc.player);
         this.fakePlayer.rotationYawHead = mc.player.rotationYawHead;
         mc.world.addEntityToWorld(this.fakePlayer.getEntityId(), this.fakePlayer);
         if (mc.player.connection != null) {
         }

      }
   }

   public void onDisable() {
      if (this.fakePlayer != null) {
         mc.world.removeEntityFromWorld(this.fakePlayer.getEntityId());
      }

   }
   

   

   
}
