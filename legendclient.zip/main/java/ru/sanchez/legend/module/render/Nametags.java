package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Nametags extends Module {

   public Nametags() {
      super("NameTags", Category.RENDER);
      ArrayList var1 = new ArrayList();
      var1.add("Old");
      var1.add("New");
      Legend.instance.settingsManager.rSetting(new Setting("Mode", this, "New", var1));
      Legend.instance.settingsManager.rSetting(new Setting("Size", this, (double)1.5F, (double)1.0F, (double)3.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("IndentDown", this, (double)3.0F, (double)1.0F, (double)50.0F, false));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onRender3D(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if ((Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString().equalsIgnoreCase("old")) == 0) {
            Iterator var2 = mc.world.loadedEntityList.iterator();

            while((var2.hasNext()) != 0) {
               Entity var3 = (Entity)var2.next();
               if (var3 instanceof EntityPlayer) {
                  if (var3 != mc.player) {
                     double var24 = var3.lastTickPosX;
                     double var38 = var3.posX;
                     double var49 = var3.lastTickPosX;
                     var38 -= var49;
                     var24 += var38 * (double)mc.getRenderPartialTicks();
                     var38 = mc.getRenderManager().viewerPosX;
                     double var4 = var24 - var38;
                     var24 = var3.lastTickPosY;
                     var38 = var3.posY;
                     var49 = var3.lastTickPosY;
                     var38 -= var49;
                     var24 += var38 * (double)mc.getRenderPartialTicks();
                     var38 = mc.getRenderManager().viewerPosY;
                     double var6 = var24 - var38;
                     var24 = var3.lastTickPosZ;
                     var38 = var3.posZ;
                     var49 = var3.lastTickPosZ;
                     var38 -= var49;
                     var24 += var38 * (double)mc.getRenderPartialTicks();
                     var38 = mc.getRenderManager().viewerPosZ;
                     double var8 = var24 - var38;
                     GL11.glPushMatrix();
                     GL11.glDisable(2929);
                     GL11.glEnable(3042);
                     GL11.glBlendFunc(770, 771);
                     GL11.glNormal3f(0.0F, 1.0F, 0.0F);
                     float var10 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Size").getValDouble();
                     float var11 = Math.min(Math.max(var10 * mc.player.getDistance(var3) * 0.15F, 1.25F), 50.0F) * 0.015F;
                     float var12 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "IndentDown").getValDouble();
                     GL11.glTranslatef((float)var4, (float)var6 + var3.height + 0.6F + mc.player.getDistance(var3) / (10.0F * var12), (float)var8);
                     GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
                     GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                     GlStateManager.rotate(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
                     GL11.glScalef(-var11, -var11, -var11);
                     int var13 = (int)(((EntityPlayer)var3).getHealth() / ((EntityPlayer)var3).getMaxHealth() * 100.0F);
                     String var14 = var3.getDisplayName().getUnformattedText() + " HP: " + var13;
                     float var15 = (float)(FontStorage.fr4.getStringWidth(var14) + 10);
                     Render3DUtils.drawShadowRect((double)(-(var15 / 2.0F)), (double)0.0F, (double)(var15 / 2.0F), (double)15.0F, 3);
                     float var30 = -(var15 / 2.0F);
                     float var52 = var15 / 2.0F;
                     Render3DUtils.drawRect(var30, 0.0F, var52, 15.0F, (new Color(30, 30, 30)).getRGB());
                     int var16 = (int)(var15 - 4.0F);
                     Render3DUtils.drawShadowRect((double)(-(var15 / 2.0F) + 2.0F), (double)11.0F, (double)(-(var15 / 2.0F) + 2.0F + (float)var16 / ((EntityPlayer)var3).getMaxHealth() * ((EntityPlayer)var3).getHealth()), (double)13.0F, 1);
                     Render3DUtils.drawRect(-(var15 / 2.0F) + 2.0F, 11.0F, -(var15 / 2.0F) + 2.0F + (float)var16 / ((EntityPlayer)var3).getMaxHealth() * ((EntityPlayer)var3).getHealth(), 13.0F, RainbowUtils.getColor());
                     CFontRenderer var31 = FontStorage.fr4;
                     int var10004 = FontStorage.fr4.getHeight() / 2;
                     var31.drawCenteredString(var14, 0.0F, (float)(5 - var10004), -1);
                     ArrayList var17 = new ArrayList();
                     if (!(((EntityPlayer)var3).getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemAir)) {
                        var17.add(((EntityPlayer)var3).getHeldItem(EnumHand.MAIN_HAND));
                     }

                     Iterator var18 = var3.getArmorInventoryList().iterator();

                     while((var18.hasNext()) != 0) {
                        ItemStack var19 = (ItemStack)var18.next();
                        if (!(var19.getItem() instanceof ItemAir)) {
                           var17.add(var19);
                        }
                     }

                     if (!(((EntityPlayer)var3).getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemAir)) {
                        var17.add(((EntityPlayer)var3).getHeldItem(EnumHand.OFF_HAND));
                     }

                     int var21 = -(var17.size() * 16 / 2);

                     for(Iterator var22 = var17.iterator(); (var22.hasNext()) != 0; var21 += 16) {
                        ItemStack var20 = (ItemStack)var22.next();
                        Render3DUtils.renderItem(var20, var21, -20);
                     }

                     GL11.glEnable(2929);
                     GL11.glPopMatrix();
                  }
               }
            }

         }
      }
   }

   public int getcenter(String var1) {
      return FontStorage.fr4.getStringWidth(var1) / 2;
   }

   public int getcenter(int var1) {
      return FontStorage.fr4.getStringWidth(String.valueOf(var1)) / 2;
   }

   @SubscribeEvent
   public void onRender(RenderLivingEvent.Specials.Pre var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if ((Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString().equalsIgnoreCase("old")) != 0) {
            EntityLivingBase var2 = var1.getEntity();
            if (var2 instanceof EntityPlayer && var2 != mc.player) {
               if ((var2.isDead) == 0 && !(var2.getHealth() < 0.0F) && (var2.isInvisible()) == 0) {
                  GL11.glPushMatrix();
                  Vec3d var3 = new Vec3d(var1.getX(), var1.getY() + (double)var2.height / (double)1.5F, var1.getZ());
                  GL11.glTranslated(var3.x, var3.y + (double)1.0F, var3.z);
                  double var4 = Math.max((double)1.0F, var3.distanceTo(new Vec3d((double)0.0F, (double)0.0F, (double)0.0F)) / (double)6.0F);
                  GL11.glScaled(var4, var4, var4);
                  int var6 = (int)Math.ceil((double)var2.getHealth());
                  FontRenderer var9 = mc.fontRenderer;
                  var10001 = var2.getDisplayName().getFormattedText() + TextFormatting.RED + " " + var6;
                  boolean var10008 = mc.gameSettings.thirdPersonView == 2;
                  EntityRenderer.drawNameplate(var9, var10001, 0.0F, 0.0F, 0.0F, 0, mc.getRenderManager().playerViewY, mc.getRenderManager().playerViewX, var10008, false);
                  GL11.glPopMatrix();
                  var1.setCanceled(true);
               }
            }
         }
      }
   }
   

   

   
}
