package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Wallhack extends Module {

   public void render(Entity var1, float var2) {
      try {
         if (var1 == null || var1 == Minecraft.getMinecraft().player) {
            return;
         }

         if (var1 == Minecraft.getMinecraft().getRenderViewEntity() && Minecraft.getMinecraft().gameSettings.thirdPersonView == 0) {
            return;
         }

         Minecraft.getMinecraft().entityRenderer.disableLightmap();
         Minecraft.getMinecraft().getRenderManager().renderEntityStatic(var1, var2, false);
         Minecraft.getMinecraft().entityRenderer.enableLightmap();
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Mob").getValBoolean());
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Animal").getValBoolean());
         int var4 = (Legend.instance.settingsManager.getSettingByName((Module)this, "ArmorStand").getValBoolean());
         GlStateManager.clear(256);
         RenderHelper.enableStandardItemLighting();
         Iterator var5 = Minecraft.getMinecraft().world.loadedEntityList.iterator();

         while((var5.hasNext()) != 0) {
            Entity var6 = (Entity)var5.next();
            if (var2 != 0 && var6 instanceof EntityMob) {
               if (var6 == Minecraft.getMinecraft().getRenderViewEntity()) {
                  continue;
               }

               this.render(var6, var1.getPartialTicks());
            }

            if (var3 != 0 && var6 instanceof EntityAnimal) {
               if (var6 == Minecraft.getMinecraft().getRenderViewEntity()) {
                  continue;
               }

               this.render(var6, var1.getPartialTicks());
            }

            if (var4 != 0 && var6 instanceof EntityArmorStand && var6 != Minecraft.getMinecraft().getRenderViewEntity()) {
               this.render(var6, var1.getPartialTicks());
            }
         }

         RenderHelper.disableStandardItemLighting();
      }
   }

   public Wallhack() {
      super("WallHack", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("Mob", this, true));
      Legend.instance.settingsManager.rSetting(new Setting("Animal", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("ArmorStand", this, false));
   }
   

   

   
}
