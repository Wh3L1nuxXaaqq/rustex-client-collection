package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Itemesp extends Module {

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   public Itemesp() {
      super("ItemESP", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("R", this, (double)225.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("G", this, (double)0.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("B", this, (double)0.0F, (double)0.0F, (double)255.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("Name", this, true));
      Legend.instance.settingsManager.rSetting(new Setting("Size", this, 1.15, 0.1, (double)4.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("MinSize", this, (double)0.0F, (double)0.0F, (double)3.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("MaxSize", this, (double)0.0F, (double)0.0F, (double)20.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Scale", this, (double)0.0F, (double)0.0F, (double)1.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Icon", this, false));
   }

   public ArrayList<EntityItem> getItems() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = mc.world.loadedEntityList.iterator();

      while((var2.hasNext()) != 0) {
         Entity var3 = (Entity)var2.next();
         if (var3 instanceof EntityItem) {
            var1.add((EntityItem)var3);
         }
      }

      return var1;
   }

   public double distanceSq(double var1, double var3, double var5) {
      double var10000 = mc.player.posX;
      double var7 = var10000 - var1;
      var10000 = mc.player.posY;
      double var9 = var10000 - var3;
      var10000 = mc.player.posZ;
      double var11 = var10000 - var5;
      return var7 * var7 + var9 * var9 + var11 * var11;
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      Iterator var2 = mc.world.loadedEntityList.iterator();

      while((var2.hasNext()) != 0) {
         Entity var3 = (Entity)var2.next();
         if (var3 instanceof EntityItem) {
            EntityItem var4 = (EntityItem)var3;
            AxisAlignedBB var5 = this.getBox(var4);
            float var6 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "R").getValDouble() / 255.0F;
            float var7 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "G").getValDouble() / 255.0F;
            float var8 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "B").getValDouble() / 255.0F;
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glLineWidth(2.0F);
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            RenderGlobal.renderFilledBox(var5, var6, var7, var8, 0.3F);
            RenderGlobal.drawSelectionBoundingBox(var5, var6, var7, var8, 0.8F);
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            GL11.glEnable(3553);
            GL11.glDisable(3042);
            int var9 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Name").getValBoolean());
            int var10 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Icon").getValBoolean());
            if (var9 != 0 || var10 != 0) {
               GlStateManager.pushMatrix();
               GlStateManager.disableDepth();
               GL11.glDisable(2929);
               GL11.glEnable(3042);
               GL11.glBlendFunc(770, 771);
               double var10000 = var4.posX;
               double var10001 = mc.getRenderManager().viewerPosX;
               var10000 -= var10001;
               var10001 = var4.posY;
               double var10002 = mc.getRenderManager().viewerPosY;
               var10001 -= var10002;
               var10002 = var4.posZ;
               double var10003 = mc.getRenderManager().viewerPosZ;
               GlStateManager.translate(var10000, var10001, var10002 - var10003);
               GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
               GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
               GlStateManager.rotate(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
               float var12 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Size").getValDouble() / 10.0F;
               float var13 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "MinSize").getValDouble();
               float var14 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "MaxSize").getValDouble();
               float var15 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Scale").getValDouble();
               float var16 = (float)(Math.min(Math.max((double)var12 * this.distanceSq(var4.posX, var4.posY, var4.posZ) * (double)0.2F, (double)1.0F), (double)25.0F) * (double)0.015F);
               if (var13 != 0.0F && var14 != 0.0F && var15 != 0.0F) {
                  var16 = (float)(Math.min(Math.max((double)var12 * this.distanceSq(var4.posX, var4.posY, var4.posZ) * (double)var15, (double)var13), (double)var14) * (double)0.015F);
               }

               GL11.glScalef(-var16, -var16, -var16);
               ItemStack var17 = var4.getItem();
               if (var9 != 0) {
                  String var18 = var17.getDisplayName().replaceAll("\u00a7.", "");
                  int var19 = mc.fontRenderer.getStringWidth(var18);
                  mc.fontRenderer.drawString(var18, -var19 / 2, 0, -1);
                  if (var10 != 0) {
                     int var23 = -var19 / 2;
                     Render3DUtils.renderItem(var17, var23 - 18, 0);
                  }
               } else if (var10 != 0) {
                  Render3DUtils.renderItem(var17, 0, 0);
               }

               GL11.glEnable(3042);
               GL11.glDisable(2929);
               GlStateManager.enableDepth();
               GlStateManager.popMatrix();
            }
         }
      }

   }

   public AxisAlignedBB getBox(Entity var1) {
      double var3 = var1.getEntityBoundingBox().minX;
      var3 -= 0.05;
      double var10003 = var1.posX;
      var3 -= var10003;
      var10003 = var1.posX;
      double var10004 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
      var3 += var10003 - var10004;
      var10003 = var1.getEntityBoundingBox().minY;
      var10004 = var1.posY;
      var10003 -= var10004;
      var10004 = var1.posY;
      double var10005 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
      var10003 += var10004 - var10005;
      var10004 = var1.getEntityBoundingBox().minZ;
      var10004 -= 0.05;
      var10005 = var1.posZ;
      var10004 -= var10005;
      var10005 = var1.posZ;
      double var10006 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
      var10004 += var10005 - var10006;
      var10005 = var1.getEntityBoundingBox().maxX + 0.05;
      var10006 = var1.posX;
      var10005 -= var10006;
      var10006 = var1.posX;
      double var10007 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
      var10005 += var10006 - var10007;
      var10006 = var1.getEntityBoundingBox().maxY + 0.1;
      var10007 = var1.posY;
      var10006 -= var10007;
      var10007 = var1.posY;
      double var10008 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
      var10006 += var10007 - var10008;
      var10007 = var1.getEntityBoundingBox().maxZ + 0.05;
      var10008 = var1.posZ;
      var10007 -= var10008;
      var10008 = var1.posZ;
      double var10009 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
      return new AxisAlignedBB(var3, var10003, var10004, var10005, var10006, var10007 + (var10008 - var10009));
   }
   

   

   
}
