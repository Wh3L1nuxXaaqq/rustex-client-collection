package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

 
public class Chinahat extends Module {
    
   public static List<String> Modes;

   public Chinahat() {
      super("ChinaHat", Category.RENDER);
      Modes.add("V2");
      Modes.add("V1");
      Legend.instance.settingsManager.rSetting(new Setting("Mode", this, "V2", (ArrayList)Modes));
   }

   @SubscribeEvent
   public void onWorldRender(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         String var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
         if ((Objects.equals(var2, "V2")) != 0) {
            double var3 = (mc.player.isSneaking()) != 0 ? -0.1 : 0.12;
            if (mc.gameSettings.thirdPersonView == 1 || mc.gameSettings.thirdPersonView == 2) {
               GlStateManager.pushMatrix();
               GL11.glBlendFunc(770, 771);
               GlStateManager.disableDepth();
               GlStateManager.disableTexture2D();
               Render3DUtils.enableSmoothLine(2.5F);
               GL11.glShadeModel(7425);
               GL11.glDisable(2884);
               GL11.glEnable(3042);
               GL11.glEnable(2929);
               GL11.glTranslatef(0.0F, (float)((double)mc.player.height + var3), 0.0F);
               GL11.glRotatef(-mc.player.rotationYaw, 0.0F, 1.0F, 0.0F);
               Color var5 = Color.WHITE;
               Color var6 = new Color(105, 55, 255);
               GL11.glBegin(6);
               Render3DUtils.glColor(var6, 255.0F);
               GL11.glVertex3d((double)0.0F, 0.3, (double)0.0F);

               for(float var7 = 0.0F; (double)var7 < (double)360.5F; ++var7) {
                  Render3DUtils.glColor(RainbowUtils.getColor());
                  GL11.glVertex3d(Math.cos((double)var7 * Math.PI / (double)180.0F) * 0.66, (double)0.0F, Math.sin((double)var7 * Math.PI / (double)180.0F) * 0.66);
               }

               GL11.glVertex3d((double)0.0F, 0.3, (double)0.0F);
               GL11.glEnd();
               GL11.glBegin(2);

               for(float var10 = 0.0F; (double)var10 < (double)360.5F; ++var10) {
                  Render3DUtils.glColor(RainbowUtils.getColor());
                  GL11.glVertex3d(Math.cos((double)var10 * Math.PI / (double)180.0F) * 0.66, (double)0.0F, Math.sin((double)var10 * Math.PI / (double)180.0F) * 0.66);
               }

               GL11.glEnd();
               GlStateManager.enableAlpha();
               Render3DUtils.disableSmoothLine();
               GL11.glShadeModel(7424);
               GL11.glEnable(2884);
               GL11.glDisable(3042);
               GlStateManager.enableTexture2D();
               GlStateManager.enableDepth();
               GlStateManager.resetColor();
               GlStateManager.popMatrix();
            }
         } else if ((Objects.equals(var2, "V1")) != 0) {
            double var8 = (mc.player.isSneaking()) != 0 ? -0.18 : 0.04;
            GL11.glPushMatrix();
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glDisable(3553);
            GL11.glDepthMask(false);
            GL11.glColor4f((float)Color.magenta.getRed() / 255.0F, (float)Color.magenta.getGreen() / 255.0F, (float)Color.magenta.getBlue() / 255.0F, 0.49019608F);
            GL11.glTranslatef(0.0F, (float)((double)((float)((double)mc.player.height + 0.36)) + var8), 0.0F);
            GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
            Cylinder var9 = new Cylinder();
            var9.setDrawStyle(100000);
            var9.setDrawStyle(100011);
            var9.draw(0.0F, 0.55F, 0.3F, 150, 100);
            GL11.glEnable(3553);
            GL11.glDepthMask(true);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
         }

      }
   }

   static {
      
      Modes = new ArrayList();
   }
   

   
}
