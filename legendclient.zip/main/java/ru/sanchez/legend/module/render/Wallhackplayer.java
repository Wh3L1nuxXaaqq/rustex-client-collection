package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Wallhackplayer extends Module {

   public Wallhackplayer() {
      super("WallHackPlayer", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("Friends", this, false));
   }

   public void render(Entity var1, float var2) {
      try {
         if (var1 == null || var1 == Minecraft.getMinecraft().player) {
            return;
         }

         if (var1 == Minecraft.getMinecraft().getRenderViewEntity() && Minecraft.getMinecraft().gameSettings.thirdPersonView == 0) {
            return;
         }

         Minecraft.getMinecraft().entityRenderer.disableLightmap();
         Minecraft.getMinecraft().getRenderManager().renderEntityStatic(var1, var2, false);
         Minecraft.getMinecraft().entityRenderer.enableLightmap();
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         GlStateManager.clear(256);
         RenderHelper.enableStandardItemLighting();
         Iterator var2 = Minecraft.getMinecraft().world.loadedEntityList.iterator();

         while((var2.hasNext()) != 0) {
            Entity var3 = (Entity)var2.next();
            if (var3 instanceof EntityPlayer && var3 != Minecraft.getMinecraft().getRenderViewEntity()) {
               int var4 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Friends").getValBoolean());
               if ((FriendManager.isFriend(var3.getName())) != 0 && var4 != 0) {
                  this.render(var3, var1.getPartialTicks());
               } else {
                  this.render(var3, var1.getPartialTicks());
               }
            }
         }

      }
   }
   

   

   
}
