package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Blockesp extends Module {
    
   public static boolean trace;
    
   public static ArrayList<ESPBlockColor> render;
    
   public static ArrayList<IBlockState> search_blocks;
    
   public static ArrayList<Block> search_blocks1;
    
   public Thread search;

   public Blockesp() {
      super("BlockESP", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("UpdateTime", this, (double)2.0F, 0.1, (double)10.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Trace", this, true));
      Legend.instance.settingsManager.rSetting(new Setting("Mode", this, "ore", new ArrayList<String>(this) {
          
         public final Blockesp this$0;

         public {
            this.this$0 = var1;
            this.add("ore");
            this.add("cus $z");
            this.add("doo&");
            this.add("clo #");
            this.add("bar&\"rc");
         }
         

         

         
      }));

      try {
         Legend.instance.settingsManager.fSetting(new Setting("Select", this, this.getClass().getDeclaredMethod("execute")));
      } catch (Exception var2) {
         var2.printStackTrace();
      }

      this.search = new BlockESPThread();
   }

   public void onEnable() {
      super.onEnable();
      render = new ArrayList();
      this.search = new BlockESPThread();
      this.search.start();
   }

   @SubscribeEvent
   public void onRender(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         trace = (boolean)(Legend.instance.settingsManager.getSettingByName((Module)this, "Trace").getValBoolean());

         try {
            ArrayList var2 = new ArrayList(render);
            Iterator var3 = var2.iterator();

            while((var3.hasNext()) != 0) {
               ESPBlockColor var4 = (ESPBlockColor)var3.next();
               Render3DUtils.blockEspFrame(new BlockPos(var4.getX(), var4.getY(), var4.getZ()), var4.getR(), var4.getG(), var4.getB());
               if (trace) {
                  Render3DUtils.trace(mc, var4);
               }
            }
         } catch (Throwable var5) {
         }

      }
   }

   public void onDisable() {
      super.onDisable();
      this.search.interrupt();
   }

   public void execute() {
      Minecraft var1 = mc;
      var1.displayGuiScreen(new ClickGuiScreen());
   }

   static {
      
      render = new ArrayList();
      search_blocks = new ArrayList();
      search_blocks1 = new ArrayList();
   }
   

   
}
