package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Soundesp extends Module {
    
   public CopyOnWriteArrayList<PlaySoundEvent> sounds;
    
   public TimerUtils timer = new TimerUtils();

   public Soundesp() {
      super("SoundESP", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("Size", this, (double)1.5F, 0.01, (double)3.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Time", this, (double)1.5F, (double)0.0F, (double)5.0F, false));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
      this.sounds = new CopyOnWriteArrayList();
      this.timer.setLastMS();
   }

   @SubscribeEvent
   public void Render3D(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         Iterator var2 = this.sounds.iterator();

         while((var2.hasNext()) != 0) {
            PlaySoundEvent var3 = (PlaySoundEvent)var2.next();
            double var14 = (double)var3.getSound().getXPosF();
            double var20 = mc.getRenderManager().viewerPosX;
            double var4 = var14 - var20;
            var14 = (double)var3.getSound().getYPosF();
            var20 = mc.getRenderManager().viewerPosY;
            double var6 = var14 - var20;
            var14 = (double)var3.getSound().getZPosF();
            var20 = mc.getRenderManager().viewerPosZ;
            double var8 = var14 - var20;
            GL11.glPushMatrix();
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glNormal3f(0.0F, 1.0F, 0.0F);
            float var10 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Size").getValDouble();
            float var11 = (float)(Math.min(Math.max((double)var10 * this.getDistance(var3) * (double)0.15F, (double)0.5F), (double)50.0F) * (double)0.015F);
            GL11.glTranslatef((float)var4, (float)var6, (float)var8);
            GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
            GL11.glScalef(-var11, -var11, -var11);
            String var12 = var3.getName();
            float var13 = (float)(FontStorage.fr4.getStringWidth(var12) + 10);
            Render3DUtils.drawShadowRect((double)(-(var13 / 2.0F)), (double)0.0F, (double)(var13 / 2.0F), (double)15.0F, 3);
            float var17 = -(var13 / 2.0F);
            float var23 = var13 / 2.0F;
            Render3DUtils.drawRect(var17, 0.0F, var23, 15.0F, (new Color(30, 30, 30)).getRGB());
            CFontRenderer var18 = FontStorage.fr4;
            int var10004 = FontStorage.fr4.getHeight() / 2;
            var18.drawCenteredString(var12, 0.0F, (float)(5 - var10004), -1);
            GL11.glEnable(2929);
            GL11.glColor3f(255.0F, 255.0F, 255.0F);
            GL11.glEnable(2929);
            GL11.glPopMatrix();
         }

      }
   }

   @SubscribeEvent
   public void SoundEvent(PlaySoundEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         this.sounds.add(var1);
         (new Thread(() -> {
            try {
               long var2 = (long)(Legend.instance.settingsManager.getSettingByName((Module)this, "Time").getValDouble() * (double)1000.0F);
               Thread.sleep(var2);
               this.sounds.remove(var1);
            } catch (InterruptedException var4) {
            }

         })).start();
      }
   }

   public double getDistance(PlaySoundEvent var1) {
      double var10000 = mc.player.posX;
      double var10001 = (double)var1.getSound().getXPosF();
      double var2 = var10000 - var10001;
      var10000 = mc.player.posY;
      var10001 = (double)var1.getSound().getYPosF();
      double var4 = var10000 - var10001;
      var10000 = mc.player.posZ;
      var10001 = (double)var1.getSound().getZPosF();
      double var6 = var10000 - var10001;
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }
   

   

   
}
