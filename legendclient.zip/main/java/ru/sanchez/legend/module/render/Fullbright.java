package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Fullbright extends Module {
    
   public float oldgamma;

   public Fullbright() {
      super("FullBright", Category.RENDER);
   }

   public void onEnable() {
      super.onEnable();
      this.oldgamma = mc.gameSettings.gammaSetting;
      mc.gameSettings.gammaSetting = 10000.0F;
   }

   public void onDisable() {
      super.onDisable();
      mc.gameSettings.gammaSetting = this.oldgamma;
   }

   @SubscribeEvent
   public void onLivingUpdate(LivingEvent.LivingUpdateEvent var1) {
   }
   

   
}
