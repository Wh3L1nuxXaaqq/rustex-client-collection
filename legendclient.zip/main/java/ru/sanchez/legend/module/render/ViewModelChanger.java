package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class ViewModelChanger extends Module {
    
   public static List<String> listA;

   public ViewModelChanger() {
      super("ViewModelChanger", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("X", this, (double)0.0F, (double)-2.0F, (double)2.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Y", this, (double)0.0F, (double)-2.0F, (double)2.0F, false));
      Legend.instance.settingsManager.rSetting(new Setting("Z", this, (double)0.0F, (double)-2.0F, (double)2.0F, false));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onRender(RenderSpecificHandEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         float var2 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "X").getValDouble();
         float var3 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Y").getValDouble();
         float var4 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Z").getValDouble();
         GL11.glTranslated((double)var2, (double)var3, (double)var4);
      }
   }

   static {
      
      listA = new ArrayList();
   }
   

   
}
