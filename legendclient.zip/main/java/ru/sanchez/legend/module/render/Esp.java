package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Esp extends Module {
    
   public static List<String> Modes;
   public static void renderEntityBoundingBox(Entity var0, float var1, float var2, float var3, float var4) {
      RenderManager var5 = Minecraft.getMinecraft().getRenderManager();
      Vec3d var6 = interpolateEntity(var0);
      GlStateManager.glLineWidth(5.0F);
      double var9 = var6.x;
      double var10003 = (double)(var0.width / 2.0F);
      var9 -= var10003;
      var10003 = var6.y;
      double var10004 = var6.z;
      double var10005 = (double)(var0.width / 2.0F);
      RenderGlobal.drawSelectionBoundingBox((new AxisAlignedBB(var9, var10003, var10004 - var10005, var6.x + (double)(var0.width / 2.0F), var6.y + (double)var0.height, var6.z + (double)(var0.width / 2.0F))).offset(-var5.viewerPosX, -var5.viewerPosY, -var5.viewerPosZ), var1, var2, var3, var4);
      GlStateManager.glLineWidth(1.0F);
   }

   public void onDisable() {
      super.onDisable();
      Iterator var1 = mc.world.loadedEntityList.iterator();

      while((var1.hasNext()) != 0) {
         Entity var2 = (Entity)var1.next();
         if (var2 instanceof EntityPlayer && (var2.isGlowing()) != 0) {
            var2.setGlowing(false);
         }
      }

   }
   public static void renderEntityFilledBoundingBox(Entity var0, float var1, float var2, float var3, float var4) {
      RenderManager var5 = Minecraft.getMinecraft().getRenderManager();
      Vec3d var6 = interpolateEntity(var0);
      double var9 = var6.x;
      double var10003 = (double)(var0.width / 2.0F);
      var9 -= var10003;
      var10003 = var6.y;
      double var10004 = var6.z;
      double var10005 = (double)(var0.width / 2.0F);
      RenderGlobal.renderFilledBox((new AxisAlignedBB(var9, var10003, var10004 - var10005, var6.x + (double)(var0.width / 2.0F), var6.y + (double)var0.height, var6.z + (double)(var0.width / 2.0F))).offset(-var5.viewerPosX, -var5.viewerPosY, -var5.viewerPosZ), var1, var2, var3, var4);
   }

   public void onEnable() {
      super.onEnable();
   }
   public static Vec3d interpolateEntity(Entity var0) {
      double var1 = (double)Minecraft.getMinecraft().getRenderPartialTicks();
      double var4 = var0.lastTickPosX;
      double var10003 = var0.posX;
      double var10004 = var0.lastTickPosX;
      var4 += (var10003 - var10004) * var1;
      var10003 = var0.lastTickPosY;
      var10004 = var0.posY;
      double var10005 = var0.lastTickPosY;
      var10003 += (var10004 - var10005) * var1;
      var10004 = var0.lastTickPosZ;
      var10005 = var0.posZ;
      double var10006 = var0.lastTickPosZ;
      return new Vec3d(var4, var10003, var10004 + (var10005 - var10006) * var1);
   }

   public Esp() {
      super("ESP", Category.RENDER);
      Modes.add("NoneCode");
      Modes.add("Ricardo");
      Modes.add("Glowing");
      Modes.add("Corners");
      Modes.add("OnHeal");
      Modes.add("Old");
      Legend.instance.settingsManager.rSetting(new Setting("Mode", this, "NoneCode", (ArrayList)Modes));
      Legend.instance.settingsManager.fSetting(new Setting("ArmorStand", this, false));
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         String var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "ArmorStand").getValBoolean());
         if ((Objects.equals(var2, "Glowing")) != 0) {
            Iterator var4 = mc.world.loadedEntityList.iterator();

            while((var4.hasNext()) != 0) {
               Entity var5 = (Entity)var4.next();
               if (var5 instanceof EntityPlayer && var5 != mc.player && (var5.isGlowing()) == 0) {
                  var5.setGlowing(true);
               }
            }
         }

         if (var3 != 0) {
            Iterator var12 = mc.world.loadedEntityList.iterator();

            while((var12.hasNext()) != 0) {
               Entity var17 = (Entity)var12.next();
               if (var17 instanceof EntityArmorStand) {
                  double var83 = var17.getEntityBoundingBox().minX;
                  var83 -= 0.05;
                  double var10003 = var17.posX;
                  var83 -= var10003;
                  var10003 = (double)((float)var17.lastTickPosX);
                  double var10004 = var17.posX;
                  double var10005 = var17.lastTickPosX;
                  var10003 = (double)((float)(var10003 + (var10004 - var10005) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10004 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
                  var83 += var10003 - var10004;
                  var10003 = var17.getEntityBoundingBox().minY;
                  var10004 = var17.posY;
                  var10003 -= var10004;
                  var10004 = (double)((float)var17.lastTickPosY);
                  var10005 = var17.posY;
                  double var10006 = var17.lastTickPosY;
                  var10004 = (double)((float)(var10004 + (var10005 - var10006) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10005 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
                  var10003 += var10004 - var10005;
                  var10004 = var17.getEntityBoundingBox().minZ;
                  var10004 -= 0.05;
                  var10005 = var17.posZ;
                  var10004 -= var10005;
                  var10005 = (double)((float)var17.lastTickPosZ);
                  var10006 = var17.posZ;
                  double var10007 = var17.lastTickPosZ;
                  var10005 = (double)((float)(var10005 + (var10006 - var10007) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10006 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
                  var10004 += var10005 - var10006;
                  var10005 = var17.getEntityBoundingBox().maxX + 0.05;
                  var10006 = var17.posX;
                  var10005 -= var10006;
                  var10006 = (double)((float)var17.lastTickPosX);
                  var10007 = var17.posX;
                  double var10008 = var17.lastTickPosX;
                  var10006 = (double)((float)(var10006 + (var10007 - var10008) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10007 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
                  var10005 += var10006 - var10007;
                  var10006 = var17.getEntityBoundingBox().maxY + 0.1;
                  var10007 = var17.posY;
                  var10006 -= var10007;
                  var10007 = (double)((float)var17.lastTickPosY);
                  var10008 = var17.posY;
                  double var10009 = var17.lastTickPosY;
                  var10007 = (double)((float)(var10007 + (var10008 - var10009) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10008 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
                  var10006 += var10007 - var10008;
                  var10007 = var17.getEntityBoundingBox().maxZ + 0.05;
                  var10008 = var17.posZ;
                  var10007 -= var10008;
                  var10008 = (double)((float)var17.lastTickPosZ);
                  var10009 = var17.posZ;
                  double var10010 = var17.lastTickPosZ;
                  var10008 = (double)((float)(var10008 + (var10009 - var10010) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                  var10009 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
                  AxisAlignedBB var6 = new AxisAlignedBB(var83, var10003, var10004, var10005, var10006, var10007 + (var10008 - var10009));
                  Render3DUtils.FillLine(var17, var6, false);
               }
            }
         }

         if ((Objects.equals(var2, "NoneCode")) != 0) {
            Iterator var16 = mc.world.loadedEntityList.iterator();

            while((var16.hasNext()) != 0) {
               Entity var21 = (Entity)var16.next();
               if (var21 instanceof EntityPlayer && (var21 != mc.player || mc.gameSettings.thirdPersonView == 1)) {
                  double var47 = var21.lastTickPosX;
                  double var76 = var21.posX;
                  double var97 = var21.lastTickPosX;
                  var47 += (var76 - var97) * (double)mc.getRenderPartialTicks();
                  var76 = mc.getRenderManager().viewerPosX;
                  double var25 = var47 - var76;
                  var47 = var21.lastTickPosY;
                  var76 = var21.posY;
                  var97 = var21.lastTickPosY;
                  var47 += (var76 - var97) * (double)mc.getRenderPartialTicks();
                  var76 = mc.getRenderManager().viewerPosY;
                  double var27 = var47 - var76;
                  var47 = var21.lastTickPosZ;
                  var76 = var21.posZ;
                  var97 = var21.lastTickPosZ;
                  var47 += (var76 - var97) * (double)mc.getRenderPartialTicks();
                  var76 = mc.getRenderManager().viewerPosZ;
                  double var29 = var47 - var76;
                  GL11.glPushMatrix();
                  GL11.glDisable(2929);
                  GL11.glDisable(3553);
                  GL11.glTranslatef((float)var25, (float)var27, (float)var29);
                  GL11.glNormal3f(0.0F, 1.0F, 0.0F);
                  GL11.glRotatef(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                  GL11.glRotatef(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
                  GL11.glLineWidth(3.0F);
                  GL11.glColor3f(0.0F, 0.0F, 0.0F);
                  GL11.glBegin(3);
                  GL11.glVertex3d((double)var21.width + 0.1, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.1, (double)var21.height + 0.4, (double)0.0F);
                  var47 = (double)(-var21.width);
                  GL11.glVertex3d(var47 - 0.1, (double)var21.height + 0.4, (double)0.0F);
                  var47 = (double)(-var21.width);
                  GL11.glVertex3d(var47 - 0.1, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.1, -0.4, (double)0.0F);
                  GL11.glEnd();
                  GL11.glLineWidth(0.7F);
                  GL11.glColor3f(255.0F, 255.0F, 255.0F);
                  GL11.glBegin(3);
                  GL11.glVertex3d((double)var21.width + 0.1, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.1, (double)var21.height + 0.4, (double)0.0F);
                  var47 = (double)(-var21.width);
                  GL11.glVertex3d(var47 - 0.1, (double)var21.height + 0.4, (double)0.0F);
                  var47 = (double)(-var21.width);
                  GL11.glVertex3d(var47 - 0.1, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.1, -0.4, (double)0.0F);
                  GL11.glEnd();
                  GL11.glColor3f(0.0F, 0.0F, 0.0F);
                  GL11.glLineWidth(3.0F);
                  GL11.glBegin(3);
                  GL11.glVertex3d((double)var21.width + 0.4, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.4, (double)var21.height + 0.4, (double)0.0F);
                  GL11.glEnd();
                  GL11.glColor3f((float)Color.GRAY.getRed(), (float)Color.GRAY.getGreen(), (float)Color.GRAY.getBlue());
                  GL11.glLineWidth(0.7F);
                  GL11.glBegin(3);
                  GL11.glVertex3d((double)var21.width + 0.4, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.4, (double)var21.height + 0.4, (double)0.0F);
                  GL11.glEnd();
                  GL11.glColor3f(0.0F, 255.0F, 0.0F);
                  GL11.glBegin(3);
                  GL11.glVertex3d((double)var21.width + 0.4, -0.4, (double)0.0F);
                  GL11.glVertex3d((double)var21.width + 0.4, (double)(((EntityPlayer)var21).getHealth() / ((EntityPlayer)var21).getMaxHealth()) * ((double)var21.height + 0.4), (double)0.0F);
                  GL11.glEnd();
                  GL11.glBegin(3);
                  GL11.glEnd();
                  GL11.glEnable(2929);
                  GL11.glEnable(3553);
                  GL11.glColor3f(255.0F, 255.0F, 255.0F);
                  GL11.glPopMatrix();
               }
            }

         } else {
            if ((Objects.equals(var2, "Corners")) != 0) {
               Iterator var13 = mc.world.loadedEntityList.iterator();

               while((var13.hasNext()) != 0) {
                  Entity var18 = (Entity)var13.next();
                  if (var18 instanceof EntityPlayer && var18 != mc.player) {
                     double var31 = var18.lastTickPosX;
                     double var60 = var18.posX;
                     double var87 = var18.lastTickPosX;
                     var31 += (var60 - var87) * (double)var1.getPartialTicks();
                     var60 = mc.getRenderManager().viewerPosX;
                     double var22 = var31 - var60;
                     var31 = var18.lastTickPosY;
                     var60 = var18.posY;
                     var87 = var18.lastTickPosY;
                     var31 += (var60 - var87) * (double)var1.getPartialTicks();
                     var60 = mc.getRenderManager().viewerPosY;
                     double var8 = var31 - var60;
                     var31 = var18.lastTickPosZ;
                     var60 = var18.posZ;
                     var87 = var18.lastTickPosZ;
                     var31 += (var60 - var87) * (double)var1.getPartialTicks();
                     var60 = mc.getRenderManager().viewerPosZ;
                     double var10 = var31 - var60;
                     GL11.glPushMatrix();
                     GL11.glDisable(2929);
                     GL11.glDisable(3553);
                     GL11.glTranslated(var22, var8, var10);
                     GL11.glNormal3f(0.0F, 1.0F, 0.0F);
                     GL11.glRotatef(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                     GL11.glLineWidth(3.0F);
                     GL11.glColor3f(0.0F, 0.0F, 0.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)var18.width, 0.2, (double)0.0F);
                     GL11.glVertex3d((double)var18.width, -0.3, (double)0.0F);
                     GL11.glVertex3d(0.15, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)(-var18.width), 0.2, (double)0.0F);
                     GL11.glVertex3d((double)(-var18.width), -0.3, (double)0.0F);
                     GL11.glVertex3d(-0.15, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d(0.15, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)var18.width, (double)var18.height + 0.3, (double)0.0F);
                     var31 = (double)var18.width;
                     var60 = (double)var18.height;
                     GL11.glVertex3d(var31, var60 - 0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d(-0.15, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)(-var18.width), (double)var18.height + 0.3, (double)0.0F);
                     var31 = (double)(-var18.width);
                     var60 = (double)var18.height;
                     GL11.glVertex3d(var31, var60 - 0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glLineWidth(1.0F);
                     GL11.glColor3f((float)Color.CYAN.darker().getRed(), (float)Color.CYAN.darker().getGreen(), (float)Color.CYAN.darker().getBlue());
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)var18.width, 0.2, (double)0.0F);
                     GL11.glVertex3d((double)var18.width, -0.3, (double)0.0F);
                     GL11.glVertex3d(0.15, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)(-var18.width), 0.2, (double)0.0F);
                     GL11.glVertex3d((double)(-var18.width), -0.3, (double)0.0F);
                     GL11.glVertex3d(-0.15, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d(0.15, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)var18.width, (double)var18.height + 0.3, (double)0.0F);
                     var31 = (double)var18.width;
                     var60 = (double)var18.height;
                     GL11.glVertex3d(var31, var60 - 0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3d(-0.15, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)(-var18.width), (double)var18.height + 0.3, (double)0.0F);
                     var31 = (double)(-var18.width);
                     var60 = (double)var18.height;
                     GL11.glVertex3d(var31, var60 - 0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glColor3f(0.0F, 0.0F, 0.0F);
                     GL11.glLineWidth(3.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)var18.width + 0.2, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)var18.width + 0.2, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glColor3f(255.0F, 255.0F, 255.0F);
                     GL11.glLineWidth(1.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)var18.width + 0.2, (double)var18.height + 0.3, (double)0.0F);
                     GL11.glVertex3d((double)var18.width + 0.2, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glColor3f(0.0F, 255.0F, 0.0F);
                     GL11.glLineWidth(1.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3d((double)var18.width + 0.2, (double)(((EntityPlayer)var18).getHealth() / ((EntityPlayer)var18).getMaxHealth()) * ((double)var18.height + 0.3), (double)0.0F);
                     GL11.glVertex3d((double)var18.width + 0.2, -0.3, (double)0.0F);
                     GL11.glEnd();
                     GL11.glColor3f(1.0F, 1.0F, 1.0F);
                     GL11.glDisable(2960);
                     GL11.glEnable(2929);
                     GL11.glEnable(3553);
                     GL11.glPopMatrix();
                  }
               }
            } else if ((Objects.equals(var2, "OnHeal")) != 0) {
               Iterator var14 = mc.world.loadedEntityList.iterator();

               while((var14.hasNext()) != 0) {
                  Entity var19 = (Entity)var14.next();
                  if (var19 instanceof EntityPlayer && var19 != mc.player) {
                     double var41 = var19.lastTickPosX;
                     double var70 = var19.posX;
                     double var90 = var19.lastTickPosX;
                     var41 += (var70 - var90) * (double)var1.getPartialTicks();
                     var70 = mc.getRenderManager().viewerPosX;
                     double var23 = var41 - var70;
                     var41 = var19.lastTickPosY;
                     var70 = var19.posY;
                     var90 = var19.lastTickPosY;
                     var41 += (var70 - var90) * (double)var1.getPartialTicks();
                     var70 = mc.getRenderManager().viewerPosY;
                     double var26 = var41 - var70;
                     var41 = var19.lastTickPosZ;
                     var70 = var19.posZ;
                     var90 = var19.lastTickPosZ;
                     var41 += (var70 - var90) * (double)var1.getPartialTicks();
                     var70 = mc.getRenderManager().viewerPosZ;
                     double var28 = var41 - var70;
                     GL11.glPushMatrix();
                     GL11.glDisable(2929);
                     GL11.glDisable(3553);
                     GL11.glTranslatef((float)var23, (float)var26, (float)var28);
                     GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
                     GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                     GlStateManager.rotate(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
                     GL11.glLineWidth(4.7F);
                     GL11.glColor3f(0.0F, 0.0F, 0.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3f(0.4F, 0.0F, 0.0F);
                     GL11.glVertex3f(0.4F, var19.height, 0.0F);
                     GL11.glEnd();
                     GL11.glColor3f(0.0F, 255.0F, 0.0F);
                     GL11.glLineWidth(0.8F);
                     GL11.glColor3f(255.0F, 255.0F, 255.0F);
                     GL11.glBegin(3);
                     GL11.glVertex3f(0.4F, 0.0F, 0.0F);
                     GL11.glVertex3f(0.4F, var19.height, 0.0F);
                     GL11.glColor3f(0.0F, 255.0F, 0.0F);
                     GL11.glEnd();
                     GL11.glBegin(3);
                     GL11.glVertex3f(0.4F, 0.0F, 0.0F);
                     GL11.glVertex3f(0.4F, ((EntityPlayer)var19).getHealth() / ((EntityPlayer)var19).getMaxHealth() * var19.height, 0.0F);
                     GL11.glEnd();
                     GL11.glEnable(3553);
                     GL11.glEnable(2929);
                     GL11.glColor3f(255.0F, 255.0F, 255.0F);
                     GL11.glPopMatrix();
                  }
               }
            }

            if ((Objects.equals(var2, "Old")) != 0) {
               Iterator var15 = mc.world.playerEntities.iterator();

               while((var15.hasNext()) != 0) {
                  EntityPlayer var20 = (EntityPlayer)var15.next();
                  if (var20 != null && var20 != mc.player) {
                     double var93 = var20.getEntityBoundingBox().minX;
                     var93 -= 0.05;
                     double var105 = var20.posX;
                     var93 -= var105;
                     var105 = (double)((float)var20.lastTickPosX);
                     double var119 = var20.posX;
                     double var136 = var20.lastTickPosX;
                     var105 = (double)((float)(var105 + (var119 - var136) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var119 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
                     var93 += var105 - var119;
                     var105 = var20.getEntityBoundingBox().minY;
                     var119 = var20.posY;
                     var105 -= var119;
                     var119 = (double)((float)var20.lastTickPosY);
                     var136 = var20.posY;
                     double var153 = var20.lastTickPosY;
                     var119 = (double)((float)(var119 + (var136 - var153) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var136 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
                     var105 += var119 - var136;
                     var119 = var20.getEntityBoundingBox().minZ;
                     var119 -= 0.05;
                     var136 = var20.posZ;
                     var119 -= var136;
                     var136 = (double)((float)var20.lastTickPosZ);
                     var153 = var20.posZ;
                     double var169 = var20.lastTickPosZ;
                     var136 = (double)((float)(var136 + (var153 - var169) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var153 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
                     var119 += var136 - var153;
                     var136 = var20.getEntityBoundingBox().maxX + 0.05;
                     var153 = var20.posX;
                     var136 -= var153;
                     var153 = (double)((float)var20.lastTickPosX);
                     var169 = var20.posX;
                     double var182 = var20.lastTickPosX;
                     var153 = (double)((float)(var153 + (var169 - var182) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var169 = Minecraft.getMinecraft().getRenderManager().viewerPosX;
                     var136 += var153 - var169;
                     var153 = var20.getEntityBoundingBox().maxY + 0.1;
                     var169 = var20.posY;
                     var153 -= var169;
                     var169 = (double)((float)var20.lastTickPosY);
                     var182 = var20.posY;
                     double var190 = var20.lastTickPosY;
                     var169 = (double)((float)(var169 + (var182 - var190) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var182 = Minecraft.getMinecraft().getRenderManager().viewerPosY;
                     var153 += var169 - var182;
                     var169 = var20.getEntityBoundingBox().maxZ + 0.05;
                     var182 = var20.posZ;
                     var169 -= var182;
                     var182 = (double)((float)var20.lastTickPosZ);
                     var190 = var20.posZ;
                     double var193 = var20.lastTickPosZ;
                     var182 = (double)((float)(var182 + (var190 - var193) * (double)Minecraft.getMinecraft().getRenderPartialTicks()));
                     var190 = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
                     AxisAlignedBB var24 = new AxisAlignedBB(var93, var105, var119, var136, var153, var169 + (var182 - var190));
                     Render3DUtils.FillLine(var20, var24, (boolean)(FriendManager.isFriend(var20.getName())));
                  }
               }
            }

         }
      }
   }

   static {
      
      Modes = new ArrayList();
      Modes = new ArrayList();
   }
   

   
}
