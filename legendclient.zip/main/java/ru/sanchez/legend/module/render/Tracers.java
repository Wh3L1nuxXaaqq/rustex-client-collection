package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Tracers extends Module {
    
   public static final boolean $assertionsDisabled;

   public Tracers() {
      super("Tracers", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("Width", this, 0.02, (double)1.0E-6F, (double)3.0F, false));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onRender(RenderWorldLastEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         float var2 = (float)Legend.instance.settingsManager.getSettingByName((Module)this, "Width").getValDouble();
         mc.gameSettings.viewBobbing = false;
         GL11.glPushMatrix();
         GL11.glEnable(2848);
         GL11.glDisable(2929);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         GL11.glDepthMask(false);
         GL11.glBlendFunc(770, 771);
         GL11.glEnable(2848);
         GL11.glEnable(3042);
         GL11.glLineWidth(var2);
         Iterator var3 = mc.world.loadedEntityList.iterator();

         while((var3.hasNext()) != 0) {
            Entity var4 = (Entity)var3.next();
            if (($assertionsDisabled) == 0 && var4 == null) {
               AssertionError var24 = new AssertionError();
               throw var24;
            }
            if (var4 != mc.player && var4 instanceof EntityPlayer) {
               if (($assertionsDisabled) == 0) {
                  if (mc.getRenderViewEntity() == null) {
                     AssertionError var23 = new AssertionError();
                     throw var23;
                  }
               }

               if ((Antibot.isBot(var4)) != 0) {
                  mc.world.removeEntity(var4);
               } else {
                  mc.player.getDistance(var4);
                  double var16 = var4.lastTickPosX;
                  double var31 = var4.posX;
                  double var39 = var4.lastTickPosX;
                  var16 += var31 - var39;
                  var31 = mc.getRenderManager().viewerPosX;
                  double var5 = var16 - var31;
                  var16 = var4.lastTickPosY;
                  var31 = var4.posY;
                  var39 = var4.lastTickPosY;
                  var16 += var31 - var39;
                  var31 = mc.getRenderManager().viewerPosY;
                  double var7 = var16 - var31;
                  var16 = var4.lastTickPosZ;
                  var31 = var4.posZ;
                  var39 = var4.lastTickPosZ;
                  var16 += var31 - var39;
                  var31 = mc.getRenderManager().viewerPosZ;
                  double var9 = var16 - var31;
                  Vec3d var11 = new Vec3d((double)0.0F, (double)0.0F, (double)1.0F);
                  var11 = var11.rotatePitch(-((float)Math.toRadians((double)mc.player.rotationPitch)));
                  Vec3d var12 = var11.rotateYaw(-((float)Math.toRadians((double)mc.player.rotationYaw)));
                  GL11.glBegin(2);
                  if ((FriendManager.isFriend(var4.getName())) != 0) {
                     Render3DUtils.glColor(RainbowUtils.getColor());
                  } else {
                     Render3DUtils.glColor(Color.white.getRGB());
                  }

                  var16 = var12.x;
                  GL11.glVertex3d(var16, (double)mc.player.getEyeHeight() + var12.y, var12.z);
                  GL11.glVertex3d(var5, var7 + 1.1, var9);
                  GL11.glEnd();
               }
            }
         }

         GL11.glDisable(3042);
         GL11.glDepthMask(true);
         GL11.glDisable(2848);
         GL11.glEnable(3553);
         GL11.glEnable(2929);
         GL11.glDisable(2848);
         GL11.glPopMatrix();
      }
   }

   static {
      
      $assertionsDisabled = (boolean)(Tracers.class.desiredAssertionStatus() == 0 ? 1 : 0);
   }
   

   
}
