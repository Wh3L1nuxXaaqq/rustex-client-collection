package ru.sanchez.legend.module.render;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Zoom extends Module {
    
   public static float FOV;

   public Zoom() {
      super("Zoom", Category.RENDER);
      Legend.instance.settingsManager.rSetting(new Setting("Zoom", this, (double)1.0F, (double)1.0F, (double)10.0F, true));
   }

   public void onEnable() {
      super.onEnable();
      if ((Wrapper.nullCheck()) != 0) {
         FOV = mc.gameSettings.fovSetting;
         double var1 = Legend.instance.settingsManager.getSettingByName((Module)this, "Zoom").getValDouble();
         mc.gameSettings.fovSetting = (float)((double)FOV / var1);
      }
   }

   public void onDisable() {
      super.onDisable();
      mc.gameSettings.fovSetting = FOV;
   }

   @SubscribeEvent
   public void onUpdate(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         double var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Zoom").getValDouble();
         mc.gameSettings.fovSetting = (float)((double)FOV / var2);
      }
   }
   

   

   
}
