package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Strafe extends Module {
   public static void strafe() {
      strafe(getSpeed());
   }
   public static void strafe(float var0) {
      if ((isMoving()) != 0) {
         double var1 = getDirection();
         mc.player.motionX = -Math.sin(var1) * (double)var0;
         mc.player.motionZ = Math.cos(var1) * (double)var0;
      }
   }

   public Strafe() {
      super("Strafe", Category.MOVEMENT);
   }
   public static float getSpeed() {
      return (float)Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
   }
   public static double getDirection() {
      float var0 = mc.player.rotationYaw;
      if (mc.player.moveForward < 0.0F) {
         var0 += 180.0F;
      }

      float var1 = 1.0F;
      if (mc.player.moveForward < 0.0F) {
         var1 = -0.5F;
      } else if (mc.player.moveForward > 0.0F) {
         var1 = 0.5F;
      }

      if (mc.player.moveStrafing > 0.0F) {
         float var10001 = 90.0F * var1;
         var0 -= var10001;
      }

      if (mc.player.moveStrafing < 0.0F) {
         var0 += 90.0F * var1;
      }

      return Math.toRadians((double)var0);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         strafe();
      }
   }
   public static boolean isMoving() {
      return mc.player != null && (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F);
   }
   

   

   
}
