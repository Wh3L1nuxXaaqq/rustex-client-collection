package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Random;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ru.sanchez.legend.utils.events.EventMotionUpdates;
import ru.sanchez.legend.utils.events.ReceivePacketEvent;

 
public class Fly extends Module {
    
   public TimerUtils timer;
    
   public Random random;

   public Fly() {
      super("Fly", Category.MOVEMENT);
      Legend.instance.settingsManager.rSetting(new Setting("Speed", this, (double)10.0F, (double)8.0F, (double)40.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("EnableSpeed", this, false));
      this.timer = new TimerUtils();
      this.random = new Random();
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onUpdate(ReceivePacketEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (var1.getPacket() instanceof SPacketPlayerPosLook && mc.currentScreen == null) {
            SPacketPlayerPosLook var2 = (SPacketPlayerPosLook)var1.getPacket();
            NetHandlerPlayClient var4 = mc.player.connection;
            var4.sendPacket(new CPacketConfirmTeleport(var2.getTeleportId()));
            var4 = mc.player.connection;
            var4.sendPacket(new CPacketPlayer.PositionRotation(var2.getX(), var2.getY(), var2.getZ(), var2.getYaw(), var2.getPitch(), false));
            mc.player.setPosition(var2.getX(), var2.getY(), var2.getZ());
            var1.setCanceled(true);
         }

      }
   }

   @SubscribeEvent
   public void onPlayerUpdate2(EventMotionUpdates.Pre var1) {
      if ((Wrapper.nullCheck()) != 0) {
         mc.player.setVelocity((double)0.0F, (double)0.0F, (double)0.0F);
         var1.setCanceled(true);
         float var2 = 0.0F;
         int var3 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "Speed").getValDouble();
         int var4 = (Legend.instance.settingsManager.getSettingByName((Module)this, "EnableSpeed").getValBoolean());
         if (var4 != 0) {
            if (mc.player.ticksExisted % var3 == 0) {
               var2 -= 0.08F;
            } else if (mc.player.movementInput.jump && mc.player.ticksExisted % 1 == 0) {
               var2 += 0.031F;
            }
         } else if (mc.player.movementInput.jump) {
            var2 += 0.031F;
         }

         double[] var5 = this.directionSpeed(0.031);
         mc.player.motionX = (double)0.0F;
         mc.player.motionY = (double)var2;
         mc.player.motionZ = (double)0.0F;
         if ((mc.world.collidesWithAnyBlock(mc.player.getEntityBoundingBox().offset(mc.player.motionX, mc.player.motionY, mc.player.motionZ))) == 0) {
            NetHandlerPlayClient var13 = mc.player.connection;
            var13.sendPacket(new CPacketPlayer.PositionRotation(mc.player.posX + mc.player.motionX, mc.player.posY + mc.player.motionY, mc.player.posZ + mc.player.motionZ, mc.player.rotationYaw, mc.player.rotationPitch, (boolean)(mc.player.onGround)));
            double var6 = mc.player.posX + mc.player.motionX;
            double var8 = mc.player.posY + mc.player.motionY;
            double var10 = mc.player.posZ + mc.player.motionZ;
            var13 = mc.player.connection;
            double var12;
            var13.sendPacket(new CPacketPlayer.Position(var6, var12 = var8 - (double)999.0F, var10, (boolean)(mc.player.onGround)));
         }

      }
   }

   @SubscribeEvent
   public void onKeyUpdate(InputUpdateEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         mc.player.movementInput.moveForward = 0.0F;
         mc.player.movementInput.forwardKeyDown = false;
         mc.player.movementInput.moveStrafe = 0.0F;
         mc.player.movementInput.rightKeyDown = false;
         mc.player.movementInput.leftKeyDown = false;
         mc.player.movementInput.backKeyDown = false;
      }
   }

   public BlockPos getFirstSolidBlock(EntityPlayer var1, int var2) {
      BlockPos var3 = var1.getPosition();
      int var8 = var3.getX();

      for(int var4 = var8 - var2; var4 <= var3.getX() + var2; ++var4) {
         var8 = var3.getY();

         for(int var5 = var8 - var2; var5 <= var3.getY() + var2; ++var5) {
            var8 = var3.getZ();

            for(int var6 = var8 - var2; var6 <= var3.getZ() + var2; ++var6) {
               BlockPos var7 = new BlockPos(var4, var5, var6);
               if ((var1.world.getBlockState(var7).isFullBlock()) != 0) {
                  return var7;
               }
            }
         }
      }

      return null;
   }

   public double[] directionSpeed(double var1) {
      float var3 = mc.player.movementInput.moveForward;
      float var4 = mc.player.movementInput.moveStrafe;
      float var15 = mc.player.prevRotationYaw;
      float var23 = mc.player.rotationYaw;
      float var26 = mc.player.prevRotationYaw;
      float var5 = var15 + (var23 - var26) * mc.getRenderPartialTicks();
      if (var3 != 0.0F) {
         if (var4 > 0.0F) {
            var5 += (float)(var3 > 0.0F ? -45 : 45);
         } else if (var4 < 0.0F) {
            var5 += (float)(var3 > 0.0F ? 45 : -45);
         }

         var4 = 0.0F;
         if (var3 > 0.0F) {
            var3 = 1.0F;
         } else if (var3 < 0.0F) {
            var3 = -1.0F;
         }
      }

      double var6 = Math.sin(Math.toRadians((double)(var5 + 90.0F)));
      double var8 = Math.cos(Math.toRadians((double)(var5 + 90.0F)));
      double var10 = (double)var3 * var1 * var8 + (double)var4 * var1 * var6;
      double var16 = (double)var3 * var1 * var6;
      double var24 = (double)var4 * var1 * var8;
      double var12 = var16 - var24;
      double[] var17 = new double[2];
      var17[0] = var10;
      var17[1] = var12;
      return var17;
   }
   

   

   
}
