package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

 
public class Guiwalk extends Module {
    
   public boolean sprint = false;

   public Guiwalk() {
      super("GuiWalk", Category.MOVEMENT);
      Legend.instance.settingsManager.rSetting(new Setting("Sneak", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("Chat", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("Swap", this, false));
      Legend.instance.settingsManager.rSetting(new Setting("AllGui", this, true));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void onKeyUpdate(InputUpdateEvent var1) {

      try {
         int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Sneak").getValBoolean());
         int var3 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Chat").getValBoolean());
         int var4 = (Legend.instance.settingsManager.getSettingByName((Module)this, "AllGui").getValBoolean());
         int var5 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Swap").getValBoolean());
         if (mc.world != null && mc.player != null && mc.currentScreen != null) {
            if (!(mc.currentScreen instanceof GuiChat) || var3 != 0 || var4 == 0 && (mc.currentScreen instanceof GuiContainer || mc.currentScreen instanceof GuiIngameMenu || mc.currentScreen instanceof GuiOptions || mc.currentScreen instanceof ClickGuiScreen2 || mc.currentScreen instanceof ClickGuiScreen3 || var3 != 0 && mc.currentScreen instanceof GuiChat)) {
               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())) != 0) {
                  MovementInput var10 = mc.player.movementInput;
                  ++var10.moveForward;
                  mc.player.movementInput.forwardKeyDown = true;
               }

               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode())) != 0) {
                  MovementInput var11 = mc.player.movementInput;
                  float var28 = var11.moveForward;
                  var11.moveForward = var28 - 1.0F;
                  mc.player.movementInput.backKeyDown = true;
               }

               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode())) != 0) {
                  MovementInput var12 = mc.player.movementInput;
                  float var29 = var12.moveStrafe;
                  var12.moveStrafe = var29 - 1.0F;
                  mc.player.movementInput.rightKeyDown = true;
               }

               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode())) != 0) {
                  MovementInput var13 = mc.player.movementInput;
                  ++var13.moveStrafe;
                  mc.player.movementInput.rightKeyDown = true;
               }

               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindSwapHands.getKeyCode())) != 0 && var5 != 0) {
                  NetHandlerPlayClient var14 = mc.player.connection;
                  var14.sendPacket(new CPacketPlayerDigging(Action.SWAP_HELD_ITEMS, BlockPos.ORIGIN, EnumFacing.DOWN));
               }

               mc.player.movementInput.jump = (boolean)(Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()));
               mc.player.movementInput.sneak = (boolean)(var2 != 0 && Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode()) != 0 ? 1 : 0);
               boolean var6 = (float)mc.player.getFoodStats().getFoodLevel() > 6.0F || mc.player.capabilities.allowFlying;
               if (mc.player.movementInput.moveForward < 0.8F || mc.player.collidedHorizontally || !var6) {
                  this.sprint = false;
               }

               if ((Keyboard.isKeyDown(mc.gameSettings.keyBindSprint.getKeyCode())) != 0 || (Legend.moduleManager.getModule("Sprint").isToggled()) != 0) {
                  this.sprint = true;
               }

               mc.player.setSprinting((boolean)(this.sprint));
               if (mc.player.movementInput.sneak) {
                  mc.player.movementInput.moveStrafe = (float)((double)mc.player.movementInput.moveStrafe * 0.3);
                  mc.player.movementInput.moveForward = (float)((double)mc.player.movementInput.moveForward * 0.3);
               }
            } else {
               this.sprint = (boolean)(mc.player.isSprinting());
            }
         }
      } catch (Throwable var7) {
         System.out.println("GuiWalk Error");
      }

   }
   

   

   
}
