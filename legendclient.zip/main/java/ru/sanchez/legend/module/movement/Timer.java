package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import ru.sanchez.legend.utils.mixinInterphase.IMixinMinecraft;

 
public class Timer extends Module {

   public Timer() {
      super("Timer", Category.MOVEMENT);
      Legend.instance.settingsManager.rSetting(new Setting("TPS", this, (double)21.4F, (double)20.0F, (double)25.0F, false));
   }

   public void onDisable() {
      super.onDisable();
      (IMixinMinecraft)mc).setTimer(20.0F;
   }

   public void onEnable() {
      super.onEnable();
      (IMixinMinecraft)mc).setTimer((float)Legend.instance.settingsManager.getSettingByName((Module)this, "TPS").getValDouble();
   }
   

   
}
