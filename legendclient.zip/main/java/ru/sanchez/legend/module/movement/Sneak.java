package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import ru.sanchez.legend.utils.events.ReceivePacketEvent;

 
public class Sneak extends Module {
    
   public static ArrayList<String> Modes;
    
   public boolean sneak = false;

   public Sneak() {
      super("Sneak", Category.MOVEMENT);
      Modes.add("Defaul$");
      Modes.add("Packet");
      Legend.instance.settingsManager.rSetting(new Setting("Mode", this, "NoneCo4\u001c", Modes));
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         String var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
         if ((var2.equals("Defaul$")) != 0) {
            if ((mc.gameSettings.keyBindSneak.isPressed()) != 0) {
               this.sneak = (boolean)((this.sneak) == 0 ? 1 : 0);
            }

            if (this.sneak) {
               KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
            }

         }
      }
   }

   public void onEnable() {
      super.onEnable();
      String var1 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
      if ((var1.equals("Packet")) != 0) {
         NetHandlerPlayClient var2 = mc.player.connection;
         var2.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
      }
   }

   @SubscribeEvent
   public void onReceivePacket(ReceivePacketEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         String var2 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
         if ((var2.equals("Packet")) != 0) {
            Packet var3 = var1.getPacket();
            if (var3 instanceof CPacketEntityAction && (((CPacketEntityAction)var3).getAction().equals(Action.STOP_SNEAKING)) != 0) {
               var1.setCanceled(true);
            }

         }
      }
   }

   public void onDisable() {
      super.onDisable();
      String var1 = Legend.instance.settingsManager.getSettingByName((Module)this, "Mode").getValString();
      if ((var1.equals("Packet")) != 0) {
         NetHandlerPlayClient var2 = mc.player.connection;
         var2.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
      }
   }

   static {
      
      Modes = new ArrayList();
   }
   

   
}
