package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Sprint extends Module {

   public Sprint() {
      super("Sprint", Category.MOVEMENT);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
      }
   }

   public void onDisable() {
      super.onDisable();
      KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
   }

   public void onEnable() {
      super.onEnable();
   }
   

   

   
}
