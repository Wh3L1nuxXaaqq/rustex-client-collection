package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ru.sanchez.legend.utils.events.EventMotionUpdates;

 
public class Nofall extends Module {

   public Nofall() {
      super("NoFall", Category.MOVEMENT);
      Legend.instance.settingsManager.rSetting(new Setting("AutoDisable", this, true));
   }

   @SubscribeEvent
   public void onUpdate(EventMotionUpdates var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (var1 instanceof EventMotionUpdates.Pre) {
            if (mc.player.fallDistance > 2.0F) {
               mc.player.onGround = true;
            }
         } else if (mc.player.fallDistance > 2.0F) {
            mc.player.onGround = false;
         }

      }
   }

   @SubscribeEvent
   public void onMessage(ClientChatReceivedEvent var1) {
      if ((Legend.instance.settingsManager.getSettingByName((Module)this, "AutoDisable").getValBoolean()) != 0) {
         if ((var1.getMessage().getUnformattedText().contains("Teleporting...")) != 0) {
            this.toggle();
         }

      }
   }
   

   

   
}
