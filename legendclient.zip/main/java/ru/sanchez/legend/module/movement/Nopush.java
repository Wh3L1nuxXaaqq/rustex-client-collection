package ru.sanchez.legend.module.movement;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

 
public class Nopush extends Module {

   public Nopush() {
      super("NoPush", Category.MOVEMENT);
   }

   @SubscribeEvent
   public void onPlayerTick(TickEvent.PlayerTickEvent var1) {
      mc.player.entityCollisionReduction = 1.0F;
   }

   public void onDisable() {
      super.onDisable();
      mc.player.entityCollisionReduction = 0.0F;
   }
   

   
}
