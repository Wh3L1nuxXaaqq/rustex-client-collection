package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Castom extends Module {
    
   public static int xx;
    
   public static int yy;
    
   public Minecraft mc = Minecraft.getMinecraft();

   public Castom() {
      super("Castom", Category.HUD);
      Legend.instance.settingsManager.rSetting(new Setting("PosX1", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("PosY1", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("PosX2", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("PosY2", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("PosX", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("PosY", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("xx", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
      Legend.instance.settingsManager.rSetting(new Setting("yy", this, (double)10.0F, (double)0.0F, (double)1000.0F, true));
   }

   @SubscribeEvent
   public void onRenderGameOverlay(RenderGameOverlayEvent var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "xx").getValDouble();
         int var3 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "yy").getValDouble();
         int var4 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosX1").getValDouble();
         int var5 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosY1").getValDouble();
         int var6 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosX2").getValDouble();
         int var7 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosY2").getValDouble();
         int var8 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosX").getValDouble();
         int var9 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "PosY").getValDouble();
         FontStorage.fr.drawString("TestTextForCord", (float)var8, (float)var9, RainbowUtils.genRainbow());
         FontStorage.fr.drawString("TestTextForCord", 5.0F, 5.0F, RainbowUtils.genRainbow());
         if (this.mc.player != null && this.mc.world != null) {
            Gui.drawRect(var4, var5, var6, var7, (new Color(37, 37, 37, 255)).getRGB());
         }

      }
   }
   

   

   
}
