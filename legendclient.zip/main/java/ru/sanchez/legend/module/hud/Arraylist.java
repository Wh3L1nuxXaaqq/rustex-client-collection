package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Arraylist extends Module {

   public Arraylist() {
      super("ArrayList", Category.HUD);
   }

   public void onDisable() {
      super.onDisable();

      Module var2;
      for(Iterator var1 = Legend.moduleManager.modules.iterator(); (var1.hasNext()) != 0; var2.anim = 0.0F) {
         var2 = (Module)var1.next();
      }

   }

   @SubscribeEvent
   public void onOverlayRender(RenderGameOverlayEvent.Text var1) {
      if ((Wrapper.nullCheck()) != 0) {
         this.animx.getAnim();
         int var2 = 20;
         ArrayList var3 = new ArrayList();
         Iterator var4 = Legend.moduleManager.modules.iterator();

         while((var4.hasNext()) != 0) {
            Module var5 = (Module)var4.next();
            if ((var5.isToggled()) != 0) {
               var5.animx.to = 1.0F;
            } else {
               var5.animx.to = 3.0F;
            }

            if (!(var5.animx.getAnim() >= 2.0F) && !(var5.animx.getAnim() <= -2.0F)) {
               var3.add(var5);
            } else {
               var3.remove(var5);
            }
         }

         for(Iterator var9 = var3.iterator(); (var9.hasNext()) != 0; var2 += FontStorage.fr.getHeight() + 3) {
            Module var10 = (Module)var9.next();
            ScaledResolution var6 = new ScaledResolution(mc);
            int var11 = var6.getScaledWidth();
            int var7 = var11 - 7;
            int var21 = FontStorage.fr.getStringWidth(var10.getName());
            int var8 = var7 - var21;
            double var12 = (double)((float)(var8 - 2) * var10.animx.getAnim());
            double var22 = (double)var2;
            double var25 = (double)((float)(var7 + 2) * var10.animx.getAnim());
            double var10003 = (double)(var2 + FontStorage.fr.getStringHeight(var10.getName()) + 3);
            Render2DUtils.drawRect(var12, var22, var25, var10003, (new Color(-1641206483, true)).hashCode());
            Render2DUtils.drawRect((double)((float)(var7 + 2) * var10.animx.getAnim()), (double)var2, (double)((float)(var7 + 5) * var10.animx.getAnim()), (double)(var2 + FontStorage.fr.getStringHeight(var10.getName()) + 3), RainbowUtils.getColor());
            FontStorage.fr.drawString(var10.getName(), (float)var8 * var10.animx.getAnim(), (float)(var2 + 2), -1);
         }

      }
   }
   

   

   
}
