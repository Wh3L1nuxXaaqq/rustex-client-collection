package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Notifications extends Module {
    
   public static RenderItem itemRender;
    
   public Entity target;

   public Notifications() {
      super("Notifications", Category.HUD);
   }

   @SubscribeEvent
   public void onRender(RenderGameOverlayEvent.Text var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if (var1.getType() == ElementType.TEXT && (Minecraft.getMinecraft().gameSettings.showDebugInfo) == 0) {
            NotificationManager.show();
         }
      }
   }
   

   

   
}
