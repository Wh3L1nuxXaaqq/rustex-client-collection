package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Watermark extends Module {
    
   public static int Xpos;
    
   public static int Ypos;
    
   public static int textwidth;

   public Watermark() {
      super("Watermark", Category.HUD);
      Legend.instance.settingsManager.rSetting(new Setting("Show Name", this, true));
   }

   @SubscribeEvent
   public void onOverlayRender(RenderGameOverlayEvent.Text var1) {
      if ((Wrapper.nullCheck()) != 0) {
         int var2 = (Legend.instance.settingsManager.getSettingByName((Module)this, "Show Name").getValBoolean());
         String var3 = var2 != 0 ? mc.player.getName() : "NoName";
         String var4 = TimeUtils.getCurrentTime();
         String var5 = "Legend Client V1.0.0 | " + var3 + " | " + var4;
         Gui.drawRect(4, 3, FontStorage.fr.getStringWidth(var5) + 7, 22, RainbowUtils.getColor());
         int var17 = FontStorage.fr.getStringWidth(var5) + 6;
         Gui.drawRect(5, 5, var17, 21, (new Color(37, 37, 37, 255)).getRGB());
         var17 = FontStorage.fr.getStringWidth(var5) + 7;
         Gui.drawRect(5, 9, var17, 9, (new Color(20, 20, 20, 100)).getRGB());
         FontStorage.fr.drawString(var5, 6.0F, 9.0F, -1);
      }
   }

   static {
      
      Xpos = 10;
      Ypos = 10;
   }
   

   
}
