package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

 
public class Inventory extends Module {
    
   public float zLevel;

   public Inventory() {
      super("Inventory", Category.HUD);
      Legend.instance.settingsManager.rSetting(new Setting("X", this, (double)3.0F, (double)0.0F, (double)mc.displayWidth, true));
      Legend.instance.settingsManager.rSetting(new Setting("Y", this, (double)3.0F, (double)0.0F, (double)mc.displayHeight, true));
      Legend.instance.settingsManager.rSetting(new Setting("Location", this, "left-bottom", new ArrayList<String>(this) {
          
         public final Inventory this$0;

         public {
            this.this$0 = var1;
            this.add("left-top");
            this.add("left-bottom");
            this.add("right-top");
            this.add("right-bottom");
            this.add("custom");
         }
         

         

         
      }));
   }

   public void onDisable() {
      super.onDisable();
   }

   public void onEnable() {
      super.onEnable();
   }

   @SubscribeEvent
   public void inventory_render(RenderGameOverlayEvent.Post var1) {
      if ((Wrapper.nullCheck()) != 0) {
         if ((var1.getType().equals(ElementType.HOTBAR)) != 0) {
            int var2 = var1.getResolution().getScaledWidth();
            int var3 = var1.getResolution().getScaledHeight();
            Legend.instance.settingsManager.getSettingByName((Module)this, "X").setMax((double)var2);
            Legend.instance.settingsManager.getSettingByName((Module)this, "Y").setMax((double)var3);
            int var4 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "X").getValDouble();
            int var5 = (int)Legend.instance.settingsManager.getSettingByName((Module)this, "Y").getValDouble();
            int var6 = 0;
            int var7 = 0;
            String var8 = Legend.instance.settingsManager.getSettingByName((Module)this, "Location").getValString();
            if ((var8.equals("left-top")) != 0) {
               var7 = 5;
               var6 = 5;
            } else if ((var8.equals("left-bottom")) != 0) {
               var7 = 5;
               int var10000 = var3 - 5;
               var6 = var10000 - 78;
            } else if ((var8.equals("right-top")) != 0) {
               int var14 = var2 - 5;
               var7 = var14 - 168;
               var6 = 5;
            } else if ((var8.equals("right-bottom")) != 0) {
               int var15 = var2 - 5;
               var7 = var15 - 168;
               var15 = var3 - 5;
               var6 = var15 - 78;
            } else {
               var6 = var5;
               var7 = var4;
            }

            int var9 = 9;
            int var17 = var7 - 3;
            int var10001 = var6 - 3;
            int var10002 = var7 + 6 + 162;
            CaesiumRenderUtils.drawRect(var17, var10001, var10002, var6 - 3 + 1, RainbowUtils.getColor());
            var17 = var7 - 3;
            var10001 = var6 - 3;
            CaesiumRenderUtils.drawRect(var17, var10001, var7 - 3 + 1, var6 + 6 + 72, RainbowUtils.getColor());
            var17 = var7 + 6 + 162;
            --var17;
            CaesiumRenderUtils.drawRect(var17, var6 - 3, var7 + 6 + 162, var6 + 6 + 72, RainbowUtils.getColor());
            var17 = var7 - 3;
            var10001 = var6 + 6 + 72;
            CaesiumRenderUtils.drawRect(var17, var10001 - 1, var7 + 6 + 162, var6 + 6 + 72, RainbowUtils.getColor());

            for(int var10 = var6; var10 < 72 + var6; var10 += 18) {
               for(int var11 = var7; var11 < 162 + var7; var11 += 18) {
                  this.drawSlot(mc.player.inventoryContainer.getSlot(var9), var10, var11);
                  ++var9;
               }
            }
         }

      }
   }

   public void drawSlot(Slot var1, int var2, int var3) {
      ItemStack var6 = var1.getStack();
      Object var7 = null;
      this.zLevel = 100.0F;
      mc.getRenderItem().zLevel = 100.0F;
      GL11.glPushMatrix();
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableBlend();
      RenderHelper.enableGUIStandardItemLighting();
      mc.getRenderItem().renderItemAndEffectIntoGUI(mc.player, var6, var3, var2);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, var6, var3, var2, (String)var7);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableBlend();
      GL11.glPopMatrix();
      mc.getRenderItem().zLevel = 0.0F;
      this.zLevel = 0.0F;
   }
   

   

   
}
