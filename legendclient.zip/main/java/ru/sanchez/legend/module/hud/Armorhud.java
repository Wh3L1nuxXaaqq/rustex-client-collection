package ru.sanchez.legend.module.hud;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

 
public class Armorhud extends Module {
    
   public static RenderItem itemRender;

   public Armorhud() {
      super("ArmorHUD", Category.HUD);
      Legend.instance.settingsManager.rSetting(new Setting("Enemy", this, false));
   }

   @SubscribeEvent
   public void onRender(RenderGameOverlayEvent.Text var1) {
      if ((Wrapper.nullCheck()) != 0) {
         GlStateManager.enableTexture2D();
         ScaledResolution var2 = new ScaledResolution(mc);
         int var3 = var2.getScaledWidth() / 2;
         int var4 = 0;
         int var24 = var2.getScaledHeight();
         var24 -= 55;
         int var5 = var24 - 10;
         Iterator var6 = mc.player.inventory.armorInventory.iterator();

         while((var6.hasNext()) != 0) {
            ItemStack var7 = (ItemStack)var6.next();
            ++var4;
            if ((var7.isEmpty()) == 0) {
               var24 = var3 - 90;
               int var8 = var24 + (9 - var4) * 20 + 2;
               GlStateManager.enableDepth();
               itemRender.zLevel = 200.0F;
               itemRender.renderItemAndEffectIntoGUI(var7, var8, var5);
               itemRender.renderItemOverlayIntoGUI(mc.fontRenderer, var7, var8, var5, "");
               itemRender.zLevel = 0.0F;
               GlStateManager.enableTexture2D();
               GlStateManager.disableLighting();
               GlStateManager.disableDepth();
               String var27;
               if (var7.getCount() > 1) {
                  var27 = var7.getCount() + "";
               } else {
               }

               String var9 = var27;
               FontRenderer var28 = mc.fontRenderer;
               int var52 = var8 + 19;
               var52 -= 2;
               int var10003 = mc.fontRenderer.getStringWidth(var9);
               var28.drawStringWithShadow(var9, (float)(var52 - var10003), (float)(var5 + 9), 16777215);
               float var29 = (float)var7.getMaxDamage();
               float var44 = (float)var7.getItemDamage();
               float var10 = (var29 - var44) / (float)var7.getMaxDamage();
               float var11 = 1.0F - var10;
               int var45 = (int)(var11 * 100.0F);
               int var12 = 100 - var45;
               FontRenderer var30 = mc.fontRenderer;
               String var46 = var12 + "";
               var52 = var8 + 8;
               FontRenderer var57 = mc.fontRenderer;
               int var58 = var57.getStringWidth(var12 + "") / 2;
               float var55 = (float)(var52 - var58);
               var30.drawStringWithShadow(var46, var55, (float)(var5 - 11), toHex((int)(var11 * 255.0F), (int)(var10 * 255.0F), 0));
            }
         }

         if ((Legend.instance.settingsManager.getSettingByName((Module)this, "Enemy").getValBoolean()) != 0) {
            int var15 = 0;
            Iterator var16 = mc.world.playerEntities.iterator();

            while((var16.hasNext()) != 0) {
               EntityPlayer var17 = (EntityPlayer)var16.next();
               if (var17 != null && var17 != mc.player && (FriendManager.isFriend(var17.getName())) == 0 && (Antibot.isBot((Entity)var17)) == 0) {
                  ++var15;
                  int var18 = var2.getScaledWidth();
                  int var19 = 0;
                  var24 = var2.getScaledHeight();
                  int var47 = 20 * var15;
                  int var20 = var24 - var47;
                  Iterator var21 = var17.inventory.armorInventory.iterator();

                  while((var21.hasNext()) != 0) {
                     ItemStack var13 = (ItemStack)var21.next();
                     ++var19;
                     if ((var13.isEmpty()) == 0) {
                        int var14 = var18 - 90 + 19 * var19;
                        Render3DUtils.renderItem(var13, var14, var20);
                     }
                  }

                  ItemStack var32 = var17.getHeldItemMainhand();
                  Render3DUtils.renderItem(var32, var18 - 96, var20);
                  FontRenderer var33 = mc.fontRenderer;
                  String var48 = var17.getDisplayNameString();
                  int var56 = var18 - 77;
                  var33.drawString(var48, var56, var20 - 5, -1);
                  if (var15 > 11) {
                     var15 = 0;
                  }
               }
            }
         }

         GlStateManager.enableDepth();
         GlStateManager.disableLighting();
      }
   }
   public static int toHex(int var0, int var1, int var2) {
      return -16777216 | (var0 & 255) << 16 | (var1 & 255) << 8 | var2 & 255;
   }

   static {
      
      itemRender = Minecraft.getMinecraft().getRenderItem();
   }
   

   
}
