package ru.sanchez.legend.command;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;

 
public class CommandVaim extends CommandBase {

   public String getName() {
      return "vaim";
   }

   public int getRequiredPermissionLevel() {
      return 0;
   }

   public String getUsage(ICommandSender var1) {
      return "/vaim <vpredict>";
   }

   public void execute(MinecraftServer var1, ICommandSender var2, String[] var3) throws CommandException {

      try {
         if (var3.length == 1) {
            Legend.instance.settingsManager.getSettingByName(Legend.moduleManager.getModule("AimBot"), "VPredict").setValDouble(Double.parseDouble(var3[0]));
            Legend.instance.settingsManager.getSettingByName(Legend.moduleManager.getModule("AimBot2"), "VPredict").setValDouble(Double.parseDouble(var3[0]));
         } else {
            WrongUsageException var7 = new WrongUsageException(this.getUsage(var2), new Object[0]);
            throw var7;
         }
      } catch (Throwable var5) {
         WrongUsageException var6 = new WrongUsageException(this.getUsage(var2), new Object[0]);
         throw var6;
      }
   }
   

   
}
