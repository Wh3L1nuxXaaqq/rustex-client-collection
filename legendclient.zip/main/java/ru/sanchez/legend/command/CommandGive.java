package ru.sanchez.legend.command;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.CommandResultStats;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.command.CommandResultStats.Type;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

 
public class CommandGive extends CommandBase {
    
   public List<String> items = new ArrayList();

   public String getName() {
      return "give";
   }

   public int getRequiredPermissionLevel() {
      return 0;
   }

   public String getUsage(ICommandSender var1) {
      return "commands.give.usage";
   }

   public CommandGive() {
      Iterator var1 = Item.REGISTRY.getKeys().iterator();

      while((var1.hasNext()) != 0) {
         ResourceLocation var2 = (ResourceLocation)var1.next();
         Item var3 = (Item)ForgeRegistries.ITEMS.getValue(var2);
         if (var3 != null) {
            String var4 = var2.toString().split(":")[1];
            this.items.add(var4);
         }
      }

   }

   public void execute(MinecraftServer var1, ICommandSender var2, String[] var3) throws CommandException {
      if (var3.length < 2) {
         WrongUsageException var20 = new WrongUsageException("commands.give.usage", new Object[0]);
         throw var20;
      } else {
         EntityPlayerSP var4 = Minecraft.getMinecraft().player;
         Item var5 = getItemByText(var2, var3[1]);
         int var6 = var3.length >= 3 ? parseInt(var3[2], 1, 64) : 1;
         int var7 = var3.length >= 4 ? parseInt(var3[3]) : 0;
         ItemStack var8 = new ItemStack(var5, var6, var7);
         if (var3.length >= 5) {
            String var9 = buildString(var3, 4);

            try {
               var8.setTagCompound(JsonToNBT.getTagFromJson(var9));
            } catch (NBTException var11) {
               Object[] var10003 = new Object[1];
               var10003[0] = var11.getMessage();
               CommandException var18 = new CommandException(var10002, var10003);
               throw var18;
            }
         }

         int var12 = (var4.inventory.addItemStackToInventory(var8));
         if (var12 != 0) {
            World var19 = var4.world;
            EntityPlayer var37 = (EntityPlayer)null;
            double var46 = var4.posX;
            double var48 = var4.posY;
            double var10004 = var4.posZ;
            SoundEvent var10005 = SoundEvents.ENTITY_ITEM_PICKUP;
            SoundCategory var10006 = SoundCategory.PLAYERS;
            float var10008 = ((EntityPlayer)var4).getRNG().nextFloat();
            float var10009 = ((EntityPlayer)var4).getRNG().nextFloat();
            var19.playSound(var37, var46, var48, var10004, var10005, var10006, 0.2F, ((var10008 - var10009) * 0.7F + 1.0F) * 2.0F);
            var4.inventoryContainer.detectAndSendChanges();
         }

         if (var12 != 0 && (var8.isEmpty()) != 0) {
            var8.setCount(1);
            var2.setCommandStat(Type.AFFECTED_ITEMS, var6);
            EntityItem var13 = ((EntityPlayer)var4).dropItem(var8, false);
            if (var13 != null) {
               var13.makeFakeItem();
            }
         } else {
            CommandResultStats.Type var38 = Type.AFFECTED_ITEMS;
            int var49 = var8.getCount();
            var2.setCommandStat(var38, var6 - var49);
            EntityItem var10 = ((EntityPlayer)var4).dropItem(var8, false);
            if (var10 != null) {
               var10.setNoPickupDelay();
               var10.setOwner(((EntityPlayer)var4).getName());
            }
         }
         Object[] var50 = new Object[3];
         var50[0] = var8.getTextComponent();
         var50[1] = var6;
         var50[2] = ((EntityPlayer)var4).getName();
         notifyCommandListener(var2, this, var10002, var50);
      }
   }

   public List<String> getTabCompletions(MinecraftServer var1, ICommandSender var2, String[] var3, @Nullable BlockPos var4) {
      if (var3.length <= 1) {
         ArrayList var7 = new ArrayList();
         var7.add(Wrapper.mc.player.getName());
         return var7;
      } else {
         String var5 = var3[1];
         if (var5 != null) {
            ArrayList var6 = new ArrayList(CommandManager.sortWithStart(this.items, var3[1]));
            return var6;
         } else {
            return this.items;
         }
      }
   }

   public boolean isUsernameIndex(String[] var1, int var2) {
      return var2 == 0;
   }
   

   

   
}
