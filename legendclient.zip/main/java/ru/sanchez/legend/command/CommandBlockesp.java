package ru.sanchez.legend.command;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

 
public class CommandBlockesp extends CommandBase {
    
   public List<String> blocks = new ArrayList();

   public String getName() {
      return "blockesp";
   }

   public int getRequiredPermissionLevel() {
      return 0;
   }

   public String getUsage(ICommandSender var1) {
      return "/blockesp <add/remove/list> <block> <state>";
   }

   public CommandBlockesp() {
      Iterator var1 = Block.REGISTRY.getKeys().iterator();

      while((var1.hasNext()) != 0) {
         ResourceLocation var2 = (ResourceLocation)var1.next();
         Block var3 = (Block)ForgeRegistries.BLOCKS.getValue(var2);
         if (var3 != null) {
            String var4 = var2.toString().split(":")[1];
            this.blocks.add(var4);
         }
      }

   }

   public void execute(MinecraftServer var1, ICommandSender var2, String[] var3) throws CommandException {
      if (var3.length < 2) {
         if (var3.length == 1 && (var3[0].equalsIgnoreCase("list")) != 0) {
            ChatUtils.sendMessage(this.getList().toString());
         } else {
            WrongUsageException var6 = new WrongUsageException(this.getUsage(var2), new Object[0]);
            throw var6;
         }
      } else {
         if ((var3[0].equalsIgnoreCase("add")) != 0) {
            if (var3.length > 2) {
               Blockesp.search_blocks.add(convertArgToBlockState(getBlockByText(var2, var3[1]), var3[2]));
            } else {
               Blockesp.search_blocks1.add(getBlockByText(var2, var3[1]));
            }
            ChatUtils.sendMessage(TextFormatting.GREEN + "Added");
         } else if ((var3[0].equalsIgnoreCase("remove")) != 0) {
            if (var3.length > 2) {
               Blockesp.search_blocks.remove(convertArgToBlockState(getBlockByText(var2, var3[1]), var3[2]));
            } else {
               Blockesp.search_blocks1.remove(getBlockByText(var2, var3[1]));
            }
            ChatUtils.sendMessage(TextFormatting.RED + "Removed");
         }

      }
   }

   public List<String> getTabCompletions(MinecraftServer var1, ICommandSender var2, String[] var3, @Nullable BlockPos var4) {
      if (var3.length <= 1) {
         ArrayList var8 = new ArrayList();
         var8.add("add");
         var8.add("remove");
         var8.add("list");
         return CommandManager.sortWithStart(var8, var3[0]);
      } else {
         if (var3.length == 2) {
            if ((var3[0].equalsIgnoreCase("add")) != 0) {
               String var7 = var3[1];
               if (var7 != null) {
                  ArrayList var6 = new ArrayList(CommandManager.sortWithStart(this.blocks, var3[1]));
                  return var6;
               }

               return this.blocks;
            }

            if ((var3[0].equalsIgnoreCase("remove")) != 0) {
               String var5 = var3[1];
               if (var5 != null) {
                  return this.getList(var5);
               }

               return this.getList();
            }
         }

         return Collections.emptyList();
      }
   }

   public List<String> getList() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = Blockesp.search_blocks.iterator();

      while((var2.hasNext()) != 0) {
         IBlockState var3 = (IBlockState)var2.next();
         String var4 = var3.getBlock().getRegistryName().toString().split(":")[1];
         var1.add(var4);
      }

      var2 = Blockesp.search_blocks1.iterator();

      while((var2.hasNext()) != 0) {
         Block var6 = (Block)var2.next();
         String var7 = var6.getRegistryName().toString().split(":")[1];
         var1.add(var7);
      }

      return var1;
   }

   public List<String> getList(String var1) {
      ArrayList var2 = new ArrayList();
      Iterator var3 = Blockesp.search_blocks.iterator();

      while((var3.hasNext()) != 0) {
         IBlockState var4 = (IBlockState)var3.next();
         String var5 = var4.getBlock().getRegistryName().toString().split(":")[1];
         if ((var5.startsWith(var1)) != 0) {
            var2.add(var5);
         }
      }

      var3 = Blockesp.search_blocks1.iterator();

      while((var3.hasNext()) != 0) {
         Block var7 = (Block)var3.next();
         String var8 = var7.getRegistryName().toString().split(":")[1];
         if ((var8.startsWith(var1)) != 0) {
            var2.add(var8);
         }
      }

      return var2;
   }
   

   

   
}
