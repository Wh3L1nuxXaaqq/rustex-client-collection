package ru.sanchez.legend.command;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;

 
public class CommandConfig extends CommandBase {

   public String getName() {
      return "config";
   }

   public List<String> getAliases() {
      ArrayList var1 = new ArrayList();
      var1.add("cfg");
      return var1;
   }

   public int getRequiredPermissionLevel() {
      return 0;
   }

   public String getUsage(ICommandSender var1) {
      return ".config <save|delete|load|list> [name]";
   }

   public void execute(MinecraftServer var1, ICommandSender var2, String[] var3) throws CommandException {
      if (var3.length < 2) {
         if (var3.length == 1 && var3[0].equals("list")) {
            ChatUtils.sendMessage(Arrays.toString(Legend.configManager.getConfigs().toArray()));
         } else {
            throw new WrongUsageException(this.getUsage(var2), new Object[0]);
         }
      } else {
         String var4 = var3[0];
         switch (var4) {
            case "save":
               Legend.configManager.saveCFG(var3[1]);
               break;
            case "delete":
               Legend.configManager.removeCFG(var3[1]);
               break;
            case "load":
               Legend.configManager.loadCFG(var3[1]);
               break;
            default:
               throw new WrongUsageException(this.getUsage(var2), new Object[0]);
         }
      }
   }

   public List<String> getTabCompletions(MinecraftServer var1, ICommandSender var2, String[] var3, @Nullable BlockPos var4) {
      if (var3.length == 1) {
         ArrayList var7 = new ArrayList();
         var7.add("save");
         var7.add("delete");
         var7.add("load");
         var7.add("list");
         return CommandManager.sortWithStart(var7, var3[0]);
      } else if (var3.length == 2 && (var3[0].equals("delete") || var3[0].equals("load"))) {
         String var5 = var3[1];
         if (var5 != null) {
            return new ArrayList(CommandManager.sortWithStart(Legend.configManager.getConfigs(), var3[1]));
         } else {
            return Legend.configManager.getConfigs();
         }
      } else {
         return Collections.emptyList();
      }
   }
   

   
}
