package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;

 
public class FriendManager {
    
   public static CopyOnWriteArrayList<String> FRIENDS;
   public static void toggleFriend(String var0) {
      if ((isFriend(var0)) != 0) {
         FRIENDS.remove(var0);
         NotificationManager.add(TextFormatting.RED + var0, "Remove from Friend list", NotificationType.OK);
      } else {
         FRIENDS.add(var0);
         NotificationManager.add(TextFormatting.GREEN + var0, "add in Friends list", NotificationType.OK);
      }

   }
   public static boolean isFriend(String var0) {
      return (boolean)(FRIENDS.contains(var0));
   }
   public static Entity ifFreand2(String var0) {
      EntityPlayer.getOfflineUUID(var0);
      return ifFreand2(var0);
   }

   static {
      
      FRIENDS = new CopyOnWriteArrayList();
   }
   

   
}
