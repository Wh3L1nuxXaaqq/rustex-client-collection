package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ru.sanchez.legend.utils.events.GuiCloseEvent;

 
public class ConfigManager {
    
   public final String path;

   public ConfigManager() {
      this.path = (new File(Wrapper.mc.gameDir, "Legend")).getPath();
      File var1 = new File(this.path);
      if ((var1.exists()) == 0) {
         var1.mkdir();
      }

      MinecraftForge.EVENT_BUS.register(this);
   }

   @SubscribeEvent
   public void onGuiOpen(GuiCloseEvent var1) {
      GuiScreen var2 = var1.getGui();
      if (var2 instanceof ClickGuiScreen2 || var2 instanceof ClickGuiScreen3) {
         this.autoSave();
         this.SaveFriends();
      }

   }

   public void saveCFG(String var1) {

      try {
         String var2 = this.getJson();
         File var3 = new File(this.path + File.separator + var1 + ".json");
         if ((var3.exists()) == 0) {
            try {
               if ((var3.createNewFile()) != 0) {
                  ChatUtils.sendMessage("Created " + var1 + ".json");
               } else {
                  ChatUtils.sendMessage("Error");
               }
            } catch (IOException var19) {
               var19.printStackTrace();
            }
         }

         try {
            FileWriter var4 = new FileWriter(var3);
            Object var5 = null;

            try {
               try {
                  var4.write(var2);
                  ChatUtils.sendMessage("Saved " + var1 + ".json");
               } catch (Throwable var18) {
                  throw var18;
               }
            } catch (Throwable var20) {
               if (var4 != null) {
                  if (var5 != null) {
                     try {
                        var4.close();
                     } catch (Throwable var16) {
                        (Throwable)var5).addSuppressed(var16;
                     }
                  } else {
                     var4.close();
                  }
               }
               throw var20;
            }

            if (var4 != null) {
               if (var5 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var17) {
                     (Throwable)var5).addSuppressed(var17;
                  }
               } else {
                  var4.close();
               }
            }
         } catch (IOException var21) {
            var21.printStackTrace();
         }
      } catch (Throwable var22) {
         var22.printStackTrace();
         ChatUtils.sendMessage("Error");
      }

   }

   public void autoSave() {

      try {
         String var1 = this.getJson();
         File var2 = new File(this.path + File.separator + "auto.json");
         if ((var2.exists()) == 0) {
            try {
               var2.createNewFile();
            } catch (IOException var18) {
               var18.printStackTrace();
            }
         }

         try {
            FileWriter var3 = new FileWriter(var2);
            Object var4 = null;

            try {
               try {
                  var3.write(var1);
               } catch (Throwable var17) {
                  throw var17;
               }
            } catch (Throwable var19) {
               if (var3 != null) {
                  if (var4 != null) {
                     try {
                        var3.close();
                     } catch (Throwable var15) {
                        (Throwable)var4).addSuppressed(var15;
                     }
                  } else {
                     var3.close();
                  }
               }
               throw var19;
            }

            if (var3 != null) {
               if (var4 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var16) {
                     (Throwable)var4).addSuppressed(var16;
                  }
               } else {
                  var3.close();
               }
            }
         } catch (IOException var20) {
            var20.printStackTrace();
         }
      } catch (Throwable var21) {
         var21.printStackTrace();
      }

   }

   public void SaveFriends() {

      try {
         String var1 = this.getJsonFriends();
         File var2 = new File(this.path + File.separator + "friends.json");
         if ((var2.exists()) == 0) {
            try {
               var2.createNewFile();
            } catch (IOException var18) {
               var18.printStackTrace();
            }
         }

         try {
            FileWriter var3 = new FileWriter(var2);
            Object var4 = null;

            try {
               try {
                  var3.write(var1);
               } catch (Throwable var17) {
                  throw var17;
               }
            } catch (Throwable var19) {
               if (var3 != null) {
                  if (var4 != null) {
                     try {
                        var3.close();
                     } catch (Throwable var15) {
                        (Throwable)var4).addSuppressed(var15;
                     }
                  } else {
                     var3.close();
                  }
               }
               throw var19;
            }

            if (var3 != null) {
               if (var4 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var16) {
                     (Throwable)var4).addSuppressed(var16;
                  }
               } else {
                  var3.close();
               }
            }
         } catch (IOException var20) {
            var20.printStackTrace();
         }
      } catch (Throwable var21) {
         var21.printStackTrace();
      }

   }

   public void LoadFriends() {

      try {
         File var1 = new File(this.path, "friends.json");
         FileReader var2 = new FileReader(var1.getPath());
         JSONParser var3 = new JSONParser();
         JSONArray var4 = (JSONArray)var3.parse((Reader)var2);
         Iterator var5 = var4.iterator();

         while((var5.hasNext()) != 0) {
            JSONObject var6 = (JSONObject)var5.next();
            String var7 = (String)var6.get("Name");
            FriendManager.FRIENDS.add(var7);
         }
      } catch (IOException | JsonParseException var8) {
         (Exception)var8).printStackTrace(;
      }

   }

   public void removeCFG(String var1) {

      try {
         File var2 = new File(this.path + File.separator + var1 + ".json");
         if ((var2.exists()) == 0) {
            return;
         }

         ChatUtils.sendMessage((var2.delete()) != 0 ? "Deleted" : "Error");
      } catch (Throwable var3) {
         var3.printStackTrace();
         ChatUtils.sendMessage("Error");
      }

   }

   public void loadCFG(String var1) {

      try {
         var10002 = this.path;
         File var2 = new File(var10002, var1 + ".json");
         if ((var2.exists()) == 0) {
            ChatUtils.sendMessage("Not Found");
         } else {
            FileReader var3 = new FileReader(var2.getPath());
            JSONParser var4 = new JSONParser();
            JSONArray var5 = (JSONArray)var4.parse((Reader)var3);
            Iterator var6 = var5.iterator();

            while(true) {
               String var7;
               int var8;
               int var9;
               Module var10;
               JSONObject var11;
               while(true) {
                  if ((var6.hasNext()) == 0) {
                     ChatUtils.sendMessage(var1 + " Loaded");
                     return;
                  }

                  var11 = (JSONObject)var6.next();
                  var7 = (String)var11.get("Module");
                  var9 = ((Boolean)var11.get("IsToggled"));
                  var8 = (int)(Long)var11.get("Key");

                  try {
                     var10 = Legend.moduleManager.getModule(var7);
                     if (var10 == null) {
                        continue;
                     }
                     break;
                  } catch (NullPointerException var25) {
                  }
               }

               if ((var7.equals("FreeCam")) == 0 && (var10.isToggled()) != var9) {
                  var10.toggle();
               }

               var10.setKey(var8);
               JSONArray var12 = (JSONArray)var11.get("Settings");
               Iterator var13 = var12.iterator();

               while((var13.hasNext()) != 0) {
                  JSONObject var20 = (JSONObject)var13.next();
                  String var14 = (String)var20.get("Type");
                  String var15 = (String)var20.get("Setting");
                  if ((var14.equals("Check")) != 0) {
                     int var18 = ((Boolean)var20.get("Val"));

                     try {
                        Legend.instance.settingsManager.getSettingByName(var10, var15).setValBoolean((boolean)var18);
                     } catch (NullPointerException var24) {
                     }
                  } else if ((var14.equals("Slider")) != 0) {
                     double var16 = (Double)var20.get("Val");

                     try {
                        Legend.instance.settingsManager.getSettingByName(var10, var15).setValDouble(var16);
                     } catch (NullPointerException var23) {
                     }
                  } else {
                     String var19 = (String)var20.get("Val");

                     try {
                        Legend.instance.settingsManager.getSettingByName(var10, var15).setValString(var19);
                     } catch (NullPointerException var22) {
                     }
                  }
               }
            }
         }
      } catch (IOException | JsonParseException var26) {
         (Exception)var26).printStackTrace(;
         ChatUtils.sendMessage("Error");
      }
   }

   public String getJson() {
      JSONArray var1 = new JSONArray();
      Iterator var2 = Legend.moduleManager.modules.iterator();

      while((var2.hasNext()) != 0) {
         Module var3 = (Module)var2.next();
         JSONObject var4 = new JSONObject();
         var4.put("Module", var3.getName());
         var4.put("IsToggled", Boolean.valueOf((boolean)(var3.isToggled())));
         var4.put("Key", var3.getKey());
         JSONArray var5 = new JSONArray();
         ArrayList var6 = new ArrayList();
         if (Legend.instance.settingsManager.getSettingsByMod(var3) != null) {
            var6.addAll(Legend.instance.settingsManager.getSettingsByMod(var3));
         }

         Iterator var7 = var6.iterator();

         while((var7.hasNext()) != 0) {
            Setting var8 = (Setting)var7.next();
            JSONObject var9 = new JSONObject();
            var9.put("Setting", var8.getName());
            if ((var8.isCheck()) != 0) {
               var9.put("Type", "Check");
               var9.put("Val", Boolean.valueOf((boolean)(var8.getValBoolean())));
            } else if ((var8.isSlider()) != 0) {
               var9.put("Type", "Slider");
               var9.put("Val", var8.getValDouble());
            } else {
               var9.put("Type", "Combo");
               var9.put("Val", var8.getValString());
            }

            var5.add(var9);
         }

         var4.put("Settings", var5);
         var1.add(var4);
      }

      return var1.toJSONString();
   }

   public String getJsonFriends() {
      JSONArray var1 = new JSONArray();
      Iterator var2 = FriendManager.FRIENDS.iterator();

      while((var2.hasNext()) != 0) {
         String var3 = (String)var2.next();
         JSONObject var4 = new JSONObject();
         var4.put("Name", var3);
         var1.add(var4);
      }

      return var1.toJSONString();
   }

   public List<String> getConfigs() {
      ArrayList var1 = new ArrayList();

      for(File var5 : (File[])Objects.requireNonNull((new File(this.path)).listFiles())) {
         String var6 = var5.getName();
         if ((var6.endsWith(".json")) != 0) {
            int var10003 = var6.length();
            int var10004 = ".json".length();
            var1.add(var6.substring(0, var10003 - var10004));
         }
      }

      return var1;
   }
   

   

   
}
