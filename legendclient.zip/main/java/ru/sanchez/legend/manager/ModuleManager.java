package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import com.google.common.collect.UnmodifiableIterator;
import com.google.common.reflect.ClassPath;
import java.util.ArrayList;
import java.util.Iterator;

 
public class ModuleManager {
    
   public ArrayList<Module> modules;

   public ModuleManager() {
      this.modules = new ArrayList()).clear(;
      this.modules.add(new Killjest());
      this.modules.add(new Nopush());
      this.modules.add(new Samoban());
      this.modules.add(new Itemesp());
      this.modules.add(new Hitbox());
      this.modules.add(new Blink());
      this.modules.add(new Selfdestruct());
      this.modules.add(new Autoreload());
      this.modules.add(new Soundesp());
      this.modules.add(new Aimbot2());
      this.modules.add(new Inventory());
      this.modules.add(new Chams());
      this.modules.add(new Nofall());
      this.modules.add(new Donatecheck());
      this.modules.add(new Fly());
      this.modules.add(new AirLock());
      this.modules.add(new Baim());
      this.modules.add(new Nopredict());
      this.modules.add(new Autofarm());
      this.modules.add(new Autocode());
      this.modules.add(new NoSlowdown());
      this.modules.add(new Timer());
      this.modules.add(new Blockesp());
      this.modules.add(new Norotate());
      this.modules.add(new DiscordRPC());
      this.modules.add(new Fakecreative());
      this.modules.add(new Joincheck());
      this.modules.add(new Zoom());
      this.modules.add(new Clickposinfo());
      this.modules.add(new Sneak());
      this.modules.add(new Aimbot());
      this.modules.add(new Aimassist());
      this.modules.add(new RainbowUtils());
      this.modules.add(new Sprint());
      this.modules.add(new Antibot());
      this.modules.add(new Esp());
      this.modules.add(new Tracers());
      this.modules.add(new Guiwalk());
      this.modules.add(new Fullbright());
      this.modules.add(new Nametags());
      this.modules.add(new Strafe());
      this.modules.add(new Wallhackplayer());
      this.modules.add(new Wallhack());
      this.modules.add(new Armorhud());
      this.modules.add(new Arraylist());
      this.modules.add(new ViewModelChanger());
      this.modules.add(new Notifications());
      this.modules.add(new Fakeplayer());
      this.modules.add(new Mcf());
      this.modules.add(new Chinahat());
      this.modules.add(new Deathcoords());
      this.modules.add(new Autoarmor());
      this.modules.add(new Watermark());
      this.modules.add(new Castom());
      this.modules.add(new Autoclicker());
      this.modules.add(new Freecam());
      this.modules.sort((var0, var1) -> {
         int var10000 = FontStorage.fr.getStringWidth(var1.getName());
         int var10001 = FontStorage.fr.getStringWidth(var0.getName());
         return var10000 - var10001;
      });
   }
   public static ArrayList<Class<?>> getClasses(String var0) {
      ArrayList var1 = new ArrayList();

      try {
         ClassLoader var2 = Thread.currentThread().getContextClassLoader();
         UnmodifiableIterator var3 = ClassPath.from(var2).getAllClasses().iterator();

         while((var3.hasNext()) != 0) {
            ClassPath.ClassInfo var4 = (ClassPath.ClassInfo)var3.next();
            if ((var4.getName().startsWith(var0)) != 0) {
               var1.add(var4.load());
            }
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      return var1;
   }

   public Module getModule(String var1) {
      Iterator var2 = this.modules.iterator();

      while((var2.hasNext()) != 0) {
         Module var3 = (Module)var2.next();
         if ((var3.getName().equalsIgnoreCase(var1)) != 0) {
            return var3;
         }
      }

      return null;
   }

   public ArrayList<Module> getModuleList() {
      return this.modules;
   }

   public ArrayList<Module> getModulesInCategory(Category var1) {
      ArrayList var2 = new ArrayList();
      Iterator var3 = this.modules.iterator();

      while((var3.hasNext()) != 0) {
         Module var4 = (Module)var3.next();
         if (var4.getCategory() == var1) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public ArrayList<Module> getModules(Category var1) {
      ArrayList var2 = new ArrayList();
      Iterator var3 = this.modules.iterator();

      while((var3.hasNext()) != 0) {
         Module var4 = (Module)var3.next();
         if (var4.getCategory() == var1) {
            var2.add(var4);
         }
      }

      return var2;
   }
   

   

   
}
