package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import net.minecraft.client.Minecraft;

 
public final class RotationManager {
    
   public final RotationTaskManager factory = new RotationTaskManager();
    
   public float yaw;
    
   public float pitch;

   public void addTask(RotationTask var1) {
      this.factory.addTask(var1);
   }

   public void removeTask(RotationTask var1) {
      this.factory.removeTask(var1);
   }

   public void removeTask(String var1) {
      this.factory.removeTask(var1);
   }

   public void startTask(RotationTask var1) {
      this.factory.startTask(var1);
   }

   public void finishTask(RotationTask var1) {
      this.factory.finishTask(var1);
   }

   public void updateRotations() {
      this.yaw = Minecraft.getMinecraft().player.rotationYaw;
      this.pitch = Minecraft.getMinecraft().player.rotationPitch;
   }

   public void restoreRotations() {
      Minecraft.getMinecraft().player.rotationYaw = this.yaw;
      Minecraft.getMinecraft().player.rotationYawHead = this.yaw;
      Minecraft.getMinecraft().player.rotationPitch = this.pitch;
   }

   public void setPlayerRotations(float var1, float var2) {
      Minecraft.getMinecraft().player.rotationYaw = var1;
      Minecraft.getMinecraft().player.rotationYawHead = var1;
      Minecraft.getMinecraft().player.rotationPitch = var2;
   }

   public void setPlayerYaw(float var1) {
      Minecraft.getMinecraft().player.rotationYaw = var1;
      Minecraft.getMinecraft().player.rotationYawHead = var1;
   }

   public void setPlayerPitch(float var1) {
      Minecraft.getMinecraft().player.rotationPitch = var1;
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public RotationTaskManager getFactory() {
      return this.factory;
   }
   

   

   
}
