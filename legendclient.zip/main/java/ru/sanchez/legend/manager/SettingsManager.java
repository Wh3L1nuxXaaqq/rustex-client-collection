package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;

 
public class SettingsManager {
    
   public ArrayList<Setting> settings = new ArrayList();

   public void rSetting(Setting var1) {
      this.settings.add(var1);
   }

   public void fSetting(Setting var1) {
      this.settings.add(var1);
   }

   public ArrayList<Setting> getSettings() {
      return this.settings;
   }

   public ArrayList<Setting> getSettingsByMod(Module var1) {
      ArrayList var2 = new ArrayList();
      Iterator var3 = this.getSettings().iterator();

      while((var3.hasNext()) != 0) {
         Setting var4 = (Setting)var3.next();
         if ((var4.getParentMod().equals(var1)) != 0) {
            var2.add(var4);
         }
      }

      if ((var2.isEmpty()) != 0) {
         return null;
      } else {
         return var2;
      }
   }

   public Setting getSettingByName(String var1, String var2) {
      Iterator var3 = this.getSettings().iterator();

      while((var3.hasNext()) != 0) {
         Setting var4 = (Setting)var3.next();
         if ((var4.getName().equalsIgnoreCase(var1)) != 0) {
            return var4;
         }
      }

      PrintStream var5 = System.out;
      var5.println("Setting not found! (" + var1 + ").");
      return null;
   }

   public Setting getSettingByName(Module var1, String var2) {
      Iterator var3 = this.getSettings().iterator();

      while((var3.hasNext()) != 0) {
         Setting var4 = (Setting)var3.next();
         if ((var4.getName().equalsIgnoreCase(var2)) != 0 && var4.getParentMod() == var1) {
            return var4;
         }
      }

      PrintStream var5 = System.err;
      var5.println("[Tutorial] Error Setting NOT found: '" + var2 + "'!");
      return null;
   }
   

   

   
}
