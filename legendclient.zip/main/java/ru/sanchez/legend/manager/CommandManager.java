package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraftforge.client.ClientCommandHandler;

 
public class CommandManager {
    
   public ArrayList<CommandBase> commands;

   public CommandManager() {
      this.commands = new ArrayList()).clear(;
      this.commands.add(new CommandGive());
      this.commands.add(new CommandBlockesp());
      this.commands.add(new CommandAim());
      this.commands.add(new CommandVaim());
      this.commands.add(new CommandRange());
      this.commands.add(new CommandConfig());
      Iterator var1 = this.commands.iterator();

      while((var1.hasNext()) != 0) {
         CommandBase var2 = (CommandBase)var1.next();
         ClientCommandHandler.instance.registerCommand(var2);
      }

   }

   public ArrayList<CommandBase> getCommands() {
      return this.commands;
   }
   public static List<String> sortWithStart(List<String> var0, String var1) {
      if (var1 != null) {
         ArrayList var2 = new ArrayList();
         Iterator var3 = var0.iterator();

         while((var3.hasNext()) != 0) {
            String var4 = (String)var3.next();
            if ((var4.startsWith(var1)) != 0) {
               var2.add(var4);
            }
         }

         if ((var2.isEmpty()) != 0) {
            return var0;
         } else {
            return var2;
         }
      } else {
         return var0;
      }
   }
   

   

   
}
