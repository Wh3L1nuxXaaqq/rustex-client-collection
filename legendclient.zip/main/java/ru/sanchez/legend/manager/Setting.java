package ru.sanchez.legend.manager;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.lang.reflect.Method;
import java.util.ArrayList;

 
public class Setting {
    
   public String name;
    
   public Module parent;
    
   public String mode;
    
   public String sval;
    
   public ArrayList<String> options;
    
   public boolean bval;
    
   public double dval;
    
   public int key;
    
   public double min;
    
   public double max;
    
   public boolean onlyint = false;
    
   public Method method;

   public Setting(String var1, Module var2, String var3, ArrayList<String> var4) {
      this.name = var1;
      this.parent = var2;
      this.sval = var3;
      this.options = var4;
      this.mode = "Combo";
   }

   public Setting(String var1, Module var2, boolean var3) {
      this.name = var1;
      this.parent = var2;
      this.bval = (boolean)(var3);
      this.mode = "Check";
   }

   public Setting(int var1) {
      this.key = var1;
      this.mode = "KeyBind";
   }

   public Setting(String var1, Module var2, double var3, double var5, double var7, boolean var9) {
      this.name = var1;
      this.parent = var2;
      this.dval = var3;
      this.min = var5;
      this.max = var7;
      this.onlyint = (boolean)(var9);
      this.mode = "Slider";
   }

   public Setting(String var1, Module var2, Method var3) {
      this.name = var1;
      this.parent = var2;
      this.method = var3;
      this.mode = "Button";
   }

   public String getName() {
      return this.name;
   }

   public Module getParentMod() {
      return this.parent;
   }

   public String getValString() {
      return this.sval;
   }

   public void setValString(String var1) {
      this.sval = var1;
   }

   public ArrayList<String> getOptions() {
      return this.options;
   }

   public boolean getValBoolean() {
      return (boolean)(this.bval);
   }

   public void setValBoolean(boolean var1) {
      this.bval = (boolean)(var1);
   }

   public Method getValMethod() {
      return this.method;
   }

   public double getValDouble() {
      if (this.onlyint) {
         this.dval = (double)((int)this.dval);
      }

      return this.dval;
   }

   public void setValDouble(double var1) {
      this.dval = var1;
   }

   public int getValKey() {
      return this.key;
   }

   public void setValKey(int var1) {
      this.key = var1;
   }

   public double getMin() {
      return this.min;
   }

   public double getMax() {
      return this.max;
   }

   public void setMin(double var1) {
      this.min = var1;
   }

   public void setMax(double var1) {
      this.max = var1;
   }

   public boolean isCombo() {
      return (this.mode.equalsIgnoreCase("Combo")) != 0;
   }

   public boolean isCheck() {
      return (this.mode.equalsIgnoreCase("Check")) != 0;
   }

   public boolean isSlider() {
      return (this.mode.equalsIgnoreCase("Slider")) != 0;
   }

   public boolean isButton() {
      return (this.mode.equalsIgnoreCase("Button")) != 0;
   }

   public boolean onlyInt() {
      return (boolean)(this.onlyint);
   }
   

   

   
}
