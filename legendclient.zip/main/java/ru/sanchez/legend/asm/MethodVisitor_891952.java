package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

 
public class MethodVisitor_891952 extends MethodVisitor {

   public MethodVisitor_891952(MethodVisitor var1) {
      super(327680, var1);
   }

   public void visitCode() {
      super.visitCode();
      this.mv.visitVarInsn(25, 1);
      this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "onSendPacket", "(Lnet/minecraft/network/Packet;)Lnet/minecraft/network/Packet;", false);
      this.mv.visitVarInsn(58, 1);
      this.mv.visitVarInsn(25, 1);
      Label var1 = new Label();
      this.mv.visitJumpInsn(199, var1);
      this.mv.visitInsn(177);
      this.mv.visitLabel(var1);
      this.mv.visitFrame(3, 0, (Object[])null, 0, (Object[])null);
   }
   

   
}
