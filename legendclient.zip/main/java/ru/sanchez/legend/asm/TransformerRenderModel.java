package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerRenderModel extends ClassVisitor {
    
   public final String RENDER_MODEL_FLAT;
    
   public final String RENDER_BLOCK_DESCRIPTOR;

   public TransformerRenderModel(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.RENDER_MODEL_FLAT = var2 ? "a" : "renderBlock";
      this.RENDER_BLOCK_DESCRIPTOR = var2 ? "(Lawt;Let;Lamy;Lbuk;)Z" : "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/client/renderer/BufferBuilder;)Z";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = super.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.RENDER_MODEL_FLAT)) != 0 && (var3.equals(this.RENDER_BLOCK_DESCRIPTOR)) != 0) {
         PrintStream var7 = System.out;
         var7.println("Method " + var2 + " transformed");
         var6 = new MethodVisitor_189010((MethodVisitor)var6);
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
