package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

 
public class MethodVisitor_178527 extends MethodVisitor {

   public MethodVisitor_178527(MethodVisitor var1) {
      super(327680, var1);
   }

   public void visitCode() {
      this.mv.visitTypeInsn(187, "ru/terrar/bobr/events/PlayerMoveEvent");
      this.mv.visitInsn(89);
      this.mv.visitVarInsn(24, 2);
      this.mv.visitVarInsn(24, 4);
      this.mv.visitVarInsn(24, 6);
      this.mv.visitMethodInsn(183, "ru/internali/events/PlayerMoveEvent", "<init>", "(DDD)V", false);
      this.mv.visitVarInsn(58, 8);
      this.mv.visitFieldInsn(178, "net/minecraftforge/common/MinecraftForge", "EVENT_BUS", "Lnet/minecraftforge/fml/common/eventhandler/EventBus;");
      this.mv.visitVarInsn(25, 8);
      this.mv.visitMethodInsn(182, "net/minecraftforge/fml/common/eventhandler/EventBus", "post", "(Lnet/minecraftforge/fml/common/eventhandler/Event;)Z", false);
      Label var1 = new Label();
      this.mv.visitJumpInsn(153, var1);
      this.mv.visitInsn(177);
      this.mv.visitLabel(var1);
      MethodVisitor var3 = this.mv;
      Object[] var10003 = new Object[1];
      var10003[0] = "ru/internali/events/PlayerMoveEvent";
      var3.visitFrame(1, 1, var10003, 0, (Object[])null);
      this.mv.visitVarInsn(25, 8);
      this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "x", "D");
      this.mv.visitVarInsn(57, 2);
      this.mv.visitVarInsn(25, 8);
      this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "y", "D");
      this.mv.visitVarInsn(57, 4);
      this.mv.visitVarInsn(25, 8);
      this.mv.visitFieldInsn(180, "ru/internali/events/PlayerMoveEvent", "z", "D");
      this.mv.visitVarInsn(57, 6);
      super.visitCode();
   }
   

   
}
