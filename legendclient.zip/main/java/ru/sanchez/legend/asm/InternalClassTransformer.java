package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import java.util.Arrays;
import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;

 
public class InternalClassTransformer implements IClassTransformer {
    
   public static final String[] transformedClasses;

   public byte[] transform(String var1, String var2, byte[] var3) {
      boolean var4 = (var1.equals(var2)) == 0;
      int var5 = Arrays.asList(transformedClasses).indexOf(var2);
      return var5 != -1 ? this.transform(var5, var3, var4) : var3;
   }

   public byte[] transform(int var1, byte[] var2, boolean var3) {
      PrintStream var17 = System.out;
      var17.println("Trans2o'\u000b\u5d79\u3d1b\u0d95\u01e6" + transformedClasses[var1]);

      try {
         ClassReader var5 = new ClassReader(var2);
         ClassWriter var6 = new ClassWriter(3);
         Object var4;
         switch (var1) {
            case 0:
               var4 = new ASMSetOpaqueCube(var6, var3);
               break;
            case 1:
               var4 = new TransformerEntityRenderer(var6, var3);
               break;
            case 2:
               var4 = new TransformerNetworkManager(var6, var3);
               break;
            case 3:
               var4 = new TransformerRenderModel(var6, var3);
               break;
            case 4:
               var4 = new TransformerBlockState(var6, var3);
               break;
            case 5:
               var4 = new TransformerBlockCollision(var6, var3);
               break;
            case 6:
               var4 = new TransformerEntityPlayerSP(var6, var3);
               break;
            default:
               var4 = new ClassVisitor(this, 327680, var6) {
                   
                  public final InternalClassTransformer this$0;

                  public {
                     this.this$0 = var1;
                  }
                  

                  
               };
         }

         var5.accept((ClassVisitor)var4, 0);
         return var6.toByteArray();
      } catch (Exception var7) {
         var7.printStackTrace();
         return var2;
      }
   }

   static {
      
      transformedClasses = new String[]{"net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386b\u3a9e\u3307\u33f4\u3f32\u39f5\u0de1\u3d28\u3a14\u0084\u0bb8\u018b\u0144\u308d\u0e23\u2b43\u3f60\u185d\u02ee\u052a\u01a4\u20e3\u1257\u3103\u3c7f\u0cc9\u3f8d\u36ff\u09fe\u3f6c", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386b\u3a9e\u3307\u33f4\u3f32\u39f5\u0de1\u3d28\u3a14\u0084\u0bb8\u018b\u0144\u308d\u0e23\u2b43\u3f46\u185b\u02ef\u052d\u01bb\u20b4\u1253\u310f\u3c62\u0cea\u3f9a\u36ec\u09eb\u3f76", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u3866\u3a97\u331a\u33e6\u3f33\u39f3\u0da4\u3d74\u3a3f\u008f\u0ba8\u0199\u0159\u309a\u0e3a\u2b20\u3f62\u185b\u02fa\u0523\u01aa\u20bf", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386b\u3a9e\u3307\u33f4\u3f32\u39f5\u0de1\u3d28\u3a14\u0084\u0bb8\u018b\u0144\u308d\u0e23\u2b43\u3f41\u1859\u02f4\u0527\u01a4\u209f\u1264\u3104\u3c68\u0ceb\u3f8d\u36fb\u09fc\u3f40\u2de7\u2589\u01c5\u355c\u2e36\u2ccf\u37db\u0a4f\u3349", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386a\u3a9e\u3301\u33f2\u3f37\u39af\u0dbc\u3d2e\u3a10\u009e\u0bb9\u01c0\u0174\u3084\u0e3e\u2b0e\u3f68\u1866\u02ef\u0525\u01bb\u20a8\u1242\u3105\u3c62\u0cfa\u3f9e\u36f7\u09e0\u3f61\u2dfc\u25de\u01e6\u3549\u2e23\u2cd8\u37d6\u0a63\u3356\u3046\u0bd3\u3e17\u07ac\u20a8\u14e2\u3540\u0fb1\u10e3\u2837\u39d4\u0875", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386a\u3a9e\u3301\u33f2\u3f37\u39af\u0d8d\u3d36\u3a1e\u0089\u0bb7\u01a2\u015f\u3099\u0e24\u2b04\u3f67", "net.m=n0\u0005\u5d62\u3d14\u0d94\u01b2\u33bc\u386b\u3a9e\u3307\u33f4\u3f32\u39f5\u0de1\u3d3f\u3a1f\u009e\u0bb5\u019a\u014f\u30c6\u0e14\u2b03\u3f77\u185c\u02ef\u053d\u019f\u20a1\u1260\u3113\u3c69\u0cfc\u3fac\u36ce"};
   }
   

   
}
