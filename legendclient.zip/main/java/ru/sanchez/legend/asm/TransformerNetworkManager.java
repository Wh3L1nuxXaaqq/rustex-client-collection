package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerNetworkManager extends ClassVisitor {
    
   public final String SEND_PACKET;
    
   public final String SEND_PACKET_DESCRIPTOR;
    
   public final String SEND_PACKET_DESCRIPTOR2;
    
   public final String CHANNEL_READ_0;
    
   public final String CHANNEL_READ_0_DESCRIPTOR;

   public TransformerNetworkManager(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.SEND_PACKET = var2 ? "a" : "sendPacket";
      this.SEND_PACKET_DESCRIPTOR = var2 ? "(Lht;)V" : "(Lnet/minecraft/network/Packet;)V";
      this.SEND_PACKET_DESCRIPTOR2 = var2 ? "(Lht;Lio/netty/util/concurrent/GenericFutureListener;[Lio/netty/util/concurrent/GenericFutureListener;)V" : "(Lnet/minecraft/network/Packet;Lio/netty/util/concurrent/GenericFutureListener;[Lio/netty/util/concurrent/GenericFutureListener;)V";
      this.CHANNEL_READ_0 = var2 ? "a" : "channelRead0";
      this.CHANNEL_READ_0_DESCRIPTOR = var2 ? "(Lio/netty/channel/ChannelHandlerContext;Lht;)V" : "(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/Packet;)V";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = this.cv.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.SEND_PACKET)) == 0 || (var3.equals(this.SEND_PACKET_DESCRIPTOR)) == 0 && (var3.equals(this.SEND_PACKET_DESCRIPTOR2)) == 0) {
         if ((var2.equals(this.CHANNEL_READ_0)) != 0 && (var3.equals(this.CHANNEL_READ_0_DESCRIPTOR)) != 0) {
            var6 = new MethodVisitor_590378((MethodVisitor)var6);
         }
      } else {
         var6 = new MethodVisitor_891952((MethodVisitor)var6);
         PrintStream var8 = System.out;
         var8.println("Method " + this.SEND_PACKET + " transformed");
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
