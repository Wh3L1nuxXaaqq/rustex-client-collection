package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import org.objectweb.asm.MethodVisitor;

 
public class MethodVisitor_421432 extends MethodVisitor {

   public MethodVisitor_421432(MethodVisitor var1) {
      super(327680, var1);
   }

   public void visitInsn(int var1) {
      if (var1 == 176) {
         this.mv.visitMethodInsn(184, "ru/internali/utils/EventFactory", "getCollisionBoundingBox", "()Lnet/minecraft/util/math/AxisAlignedBB;", false);
      }

      super.visitInsn(var1);
   }
   

   
}
