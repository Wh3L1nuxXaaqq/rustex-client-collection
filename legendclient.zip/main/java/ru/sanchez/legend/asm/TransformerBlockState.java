package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerBlockState extends ClassVisitor {
    
   public final String SHOULD_SIDE;
    
   public final String SHOULD_SIDE_DESCRIPTOR;
    
   public final String GET_LIGHT;
    
   public final String GET_LIGHT_DESCRIPTOR;

   public TransformerBlockState(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.SHOULD_SIDE = var2 ? "c" : "shouldSideBeRendered";
      this.SHOULD_SIDE_DESCRIPTOR = var2 ? "(Lamy;Let;Lfa;)Z" : "(Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z";
      this.GET_LIGHT = var2 ? "j" : "getAmbientOcclusionLightValue";
      this.GET_LIGHT_DESCRIPTOR = "()F";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = super.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.SHOULD_SIDE)) != 0 && (var3.equals(this.SHOULD_SIDE_DESCRIPTOR)) != 0) {
         var6 = new MethodVisitor_023290((MethodVisitor)var6);
         PrintStream var10 = System.out;
         var10.println("Method " + var2 + " transformed");
      } else if ((var2.equals(this.GET_LIGHT)) != 0 && (var3.equals(this.GET_LIGHT_DESCRIPTOR)) != 0) {
         var6 = new MethodVisitor_735768((MethodVisitor)var6);
         PrintStream var9 = System.out;
         var9.println("Method " + var2 + " transformed");
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
