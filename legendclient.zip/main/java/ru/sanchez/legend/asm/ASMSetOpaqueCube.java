package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class ASMSetOpaqueCube extends ClassVisitor {
    
   public final String SET_OPAQUE;
    
   public final String SET_OPAQUE_DESCRIPTOR;

   public ASMSetOpaqueCube(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.SET_OPAQUE = var2 ? "a" : "setOpaqueCube";
      this.SET_OPAQUE_DESCRIPTOR = var2 ? "(Let;)V" : "(Lnet/minecraft/util/math/BlockPos;)V";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = this.cv.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.SET_OPAQUE)) != 0 && (var3.equals(this.SET_OPAQUE_DESCRIPTOR)) != 0) {
         var6 = new MethodVisitor_eCube2((MethodVisitor)var6);
         PrintStream var7 = System.out;
         var7.println("Method " + this.SET_OPAQUE + " transformed");
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
