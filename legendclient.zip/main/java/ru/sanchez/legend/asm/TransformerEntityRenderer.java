package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerEntityRenderer extends ClassVisitor {
    
   public final String UPDATE_CAMERA;
    
   public final String UPDATE_CAMERA_DESCRIPTOR;
    
   public boolean isObfuscated;

   public TransformerEntityRenderer(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.UPDATE_CAMERA = var2 != 0 ? "a" : "upd5[*a\u0002N\u544d\u0ed6\u15be\u228d\u3f29\u0da1\u3a1e\u35a8\u0777\u0156\u35d2\u1356";
      this.UPDATE_CAMERA_DESCRIPTOR = var2 != 0 ? "(FJ}y" : "(FJ}y";
      this.isObfuscated = (boolean)(var2);
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = super.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.UPDATE_CAMERA)) != 0 && (var3.equals(this.UPDATE_CAMERA_DESCRIPTOR)) != 0) {
         var6 = new TransformerMinecraft((MethodVisitor)var6, (boolean)(this.isObfuscated));
         PrintStream var7 = System.out;
         var7.println("Met<@+\u0002" + this.UPDATE_CAMERA + " tr5A<D\u000cQ\u5445\u0ec1\u15bb");
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
