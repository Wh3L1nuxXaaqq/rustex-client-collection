package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerBlockCollision extends ClassVisitor {
    
   public final String GET_COLLISION;
    
   public final String GET_COLLISION_DESC;

   public TransformerBlockCollision(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.GET_COLLISION = var2 ? "a" : "getCollisionBoundingBox";
      this.GET_COLLISION_DESC = var2 ? "(Lawt;Lamy;Let;)Lbhb;" : "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB;";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = super.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.GET_COLLISION)) != 0 && (var3.equals(this.GET_COLLISION_DESC)) != 0) {
         PrintStream var7 = System.out;
         var7.println("Method " + var2 + " transformed");
         var6 = new MethodVisitor_421432((MethodVisitor)var6);
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
