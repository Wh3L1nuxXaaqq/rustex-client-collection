package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerMinecraft extends MethodVisitor {
    
   public boolean line1033;
    
   public boolean line1039;
    
   public boolean isObfuscated;

   public TransformerMinecraft(MethodVisitor var1, boolean var2) {
      super(327680, var1);
      this.isObfuscated = (boolean)(var2);
   }

   public void visitLineNumber(int var1, Label var2) {
      super.visitLineNumber(var1, var2);
      this.line1033 = (boolean)(var1 == 1033 ? 1 : 0);
      this.line1039 = (boolean)(var1 == 1039 ? 1 : 0);
   }

   public void visitFieldInsn(int var1, String var2, String var3, String var4) {
      if ((this.line1033 || this.line1039) && (var2.equals(this.isObfuscated ? "bib" : "net/minecraft/client/Minecraft")) != 0) {
         this.mv.visitMethodInsn(182, this.isObfuscated ? "bib" : "net/minecraft/client/Minecraft", this.isObfuscated ? "aa" : "getRenderViewEntity", this.isObfuscated ? "()Lvg;" : "()Lnet/minecraft/entity/Entity;", false);
      } else {
         super.visitFieldInsn(var1, var2, var3, var4);
      }

   }

   public void visitMethodInsn(int var1, String var2, String var3, String var4, boolean var5) {
      if ((this.line1033) == 0 && (this.line1039) == 0) {
         super.visitMethodInsn(var1, var2, var3, var4, var5);
      } else {
         this.mv.visitMethodInsn(182, this.isObfuscated ? "vg" : "net/minecraft/entity/Entity", this.isObfuscated ? "c" : "turn", "(FF)V", false);
      }

   }
   

   

   
}
