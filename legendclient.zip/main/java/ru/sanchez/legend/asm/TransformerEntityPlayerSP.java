package ru.sanchez.legend.asm;

import ru.sanchez.legend.*;
import ru.sanchez.legend.asm.*;
import ru.sanchez.legend.command.*;
import ru.sanchez.legend.manager.*;
import ru.sanchez.legend.module.*;
import ru.sanchez.legend.module.combat.*;
import ru.sanchez.legend.module.exploit.*;
import ru.sanchez.legend.module.hud.*;
import ru.sanchez.legend.module.movement.*;
import ru.sanchez.legend.module.outher.*;
import ru.sanchez.legend.module.render.*;
import ru.sanchez.legend.ui.*;
import ru.sanchez.legend.utils.*;

import java.io.PrintStream;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;

 
public class TransformerEntityPlayerSP extends ClassVisitor {
    
   public final String IS_USER;
    
   public final String IS_USER_DESC;
    
   public final String MOVE;
    
   public final String MOVE_DESC;
    
   public final String ON_UPDATE_WALKING_PLAYER;
    
   public final String ON_UPDATE_WALKING_PLAYER_DESC;

   public TransformerEntityPlayerSP(ClassVisitor var1, boolean var2) {
      super(327680, var1);
      this.IS_USER = var2 ? "cZ" : "isUser";
      this.IS_USER_DESC = "()Z";
      this.MOVE = var2 ? "a" : "move";
      this.MOVE_DESC = var2 ? "(Lvv;DDD)V" : "(Lnet/minecraft/entity/MoverType;DDD)V";
      this.ON_UPDATE_WALKING_PLAYER = var2 ? "N" : "onUpdateWalkingPlayer";
      this.ON_UPDATE_WALKING_PLAYER_DESC = "()V";
   }

   public MethodVisitor visitMethod(int var1, String var2, String var3, String var4, String[] var5) {
      Object var6 = super.visitMethod(var1, var2, var3, var4, var5);
      if ((var2.equals(this.IS_USER)) != 0 && (var3.equals(this.IS_USER_DESC)) != 0) {
         PrintStream var13 = System.out;
         var13.println("Method " + var2 + " transformed");
         var6 = new MethodVisitor_916312((MethodVisitor)var6);
      } else if ((var2.equals(this.MOVE)) != 0 && (var3.equals(this.MOVE_DESC)) != 0) {
         PrintStream var12 = System.out;
         var12.println("Method " + var2 + " transformed");
         var6 = new MethodVisitor_178527((MethodVisitor)var6);
      } else if ((var2.equals(this.ON_UPDATE_WALKING_PLAYER)) != 0 && (var3.equals(this.ON_UPDATE_WALKING_PLAYER_DESC)) != 0) {
         PrintStream var11 = System.out;
         var11.println("Method " + var2 + " transformed");
         var6 = new MethodVisitor_684176((MethodVisitor)var6);
      }

      return (MethodVisitor)var6;
   }
   

   

   
}
