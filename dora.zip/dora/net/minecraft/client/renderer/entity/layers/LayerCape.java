package net.minecraft.client.renderer.entity.layers;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;
import ru.moonware.client.utilsystem.impl.render.SmoothCapeRender;

public class LayerCape
implements LayerRenderer<AbstractClientPlayer> {
    private final RenderPlayer playerRenderer;
    private final SmoothCapeRender smoothCapeRenderer = new SmoothCapeRender();

    public LayerCape(RenderPlayer playerRendererIn, ModelBase modelBaseIn) {
        this.playerRenderer = playerRendererIn;
        this.buildMesh(modelBaseIn);
    }

    private void buildMesh(ModelBase model) {
        for (int i = 0; i < 16; ++i) {
            ModelRenderer base = new ModelRenderer(model, 0, i);
            base.setTextureSize(64, 32);
        }
    }

    @Override
    public void doRenderLayer(AbstractClientPlayer entitylivingbaseIn, float p_177141_2_, float p_177141_3_, float partialTicks, float p_177141_5_, float p_177141_6_, float p_177141_7_, float scale) {
        if (!(entitylivingbaseIn instanceof EntityPlayerSP)) {
            return;
        }
        entitylivingbaseIn.updateSimulation(entitylivingbaseIn, 16);
        this.playerRenderer.bindTexture(new ResourceLocation("bomb/skidma.png"));
        this.smoothCapeRenderer.renderSmoothCape(this, entitylivingbaseIn, partialTicks);
    }

    public float getNatrualWindSwing(int part) {
        long highlightedPart = System.currentTimeMillis() / 3L % 360L;
        float relativePart = (float)(part + 1) / 16.0f;
        return (float)(Math.sin(Math.toRadians(relativePart * 360.0f - (float)highlightedPart)) * 3.0);
    }

    private static float easeOutSine(float x) {
        return (float)Math.sin((double)x * Math.PI / 2.0);
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
