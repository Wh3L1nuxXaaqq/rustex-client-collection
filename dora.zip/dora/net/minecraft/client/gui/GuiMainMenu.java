package net.minecraft.client.gui;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import ru.moonware.client.font.FontUtil;
import ru.moonware.client.ui.GuiAlt;

public class GuiMainMenu
extends GuiScreen {
    private static final ResourceLocation BACKGROUND_IMAGE = new ResourceLocation("textures/gui/title/background/mikualt.png");
    private static final ResourceLocation ALT_MANAGER_ICON = new ResourceLocation("textures/gui/title/background/altmana.png");
    private final List<MenuItem> menuItems = new ArrayList<MenuItem>();
    private final Minecraft mc = Minecraft.getMinecraft();

    public GuiMainMenu() {
        if (this.mc != null) {
            this.menuItems.add(new MenuItemWithIcon("Alt Manager", ALT_MANAGER_ICON, () -> this.mc.displayGuiScreen(new GuiAlt(this))));
            this.menuItems.add(new MenuItem("Singleplayer", () -> this.mc.displayGuiScreen(new GuiWorldSelection(this))));
            this.menuItems.add(new MenuItem("Multiplayer", () -> this.mc.displayGuiScreen(new GuiMultiplayer(this))));
            this.menuItems.add(new MenuItem("Settings", () -> this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings))));
            this.menuItems.add(new MenuItem("Quit", this.mc::shutdown));
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (this.mc == null) {
            return;
        }
        this.mc.getTextureManager().bindTexture(BACKGROUND_IMAGE);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GuiMainMenu.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, this.width, this.height, (float)this.width, (float)this.height);
        int leftMargin = 50;
        int centerY = this.height / 2 - 50;
        int offset = 0;
        for (MenuItem item : this.menuItems) {
            int textX = leftMargin;
            int textY = centerY + offset;
            if (item instanceof MenuItemWithIcon) {
                MenuItemWithIcon iconItem = (MenuItemWithIcon)item;
                int iconSize = 20;
                int iconX = this.width - iconSize - 4;
                int n = 10;
            } else {
                FontUtil.rust.drawString(item.text, textX, textY, 0xFFFFFF);
            }
            offset += FontUtil.rust.getHeight() + 10;
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawIcon(ResourceLocation icon, int x, int y, int size) {
        this.mc.getTextureManager().bindTexture(icon);
        GuiMainMenu.drawModalRectWithCustomSizedTexture(x, y, 0.0f, 0.0f, size, size, (float)size, (float)size);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.mc == null) {
            return;
        }
        int leftMargin = 50;
        int centerY = this.height / 2 - 50;
        int offset = 0;
        for (MenuItem item : this.menuItems) {
            int textX = leftMargin;
            int textY = centerY + offset;
            double textWidth = FontUtil.rust.getStringWidth(item.text);
            double textHeight = FontUtil.rust.getHeight();
            if (item instanceof MenuItemWithIcon) {
                MenuItemWithIcon iconItem = (MenuItemWithIcon)item;
                int iconSize = 32;
                int iconX = this.width - iconSize - 10;
                int iconY = 10;
                if (mouseX >= iconX && mouseX <= iconX + iconSize && mouseY >= iconY && mouseY <= iconY + iconSize) {
                    iconItem.action.run();
                }
            } else if (mouseX >= textX && (double)mouseX <= (double)textX + textWidth && mouseY >= textY && (double)mouseY <= (double)textY + textHeight) {
                item.action.run();
            }
            offset = (int)((double)offset + (textHeight + 10.0));
        }
        int iconSize = 26;
        int margin = 3;
        int xPos = this.width - iconSize - margin;
        int yPos = this.height / 2 + 220;
        if (this.isMouseOver(mouseX, mouseY, xPos, yPos - 2 * (iconSize + margin), iconSize)) {
            this.openWebpage("https://www.youtube.com/@pituhzxc");
        } else if (this.isMouseOver(mouseX, mouseY, xPos, yPos - (iconSize + margin), iconSize)) {
            this.openWebpage("https://t.me/+kw6gLmeYzVtjNTZi");
        } else if (this.isMouseOver(mouseX, mouseY, xPos, yPos, iconSize)) {
            this.openWebpage("https://discord.gg/fzwANAZr");
        }
    }

    private boolean isMouseOver(int mouseX, int mouseY, int x, int y, int size) {
        return mouseX >= x && mouseX <= x + size && mouseY >= y && mouseY <= y + size;
    }

    private void openWebpage(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class MenuItemWithIcon
    extends MenuItem {
        ResourceLocation icon;

        MenuItemWithIcon(String text, ResourceLocation icon, Runnable action) {
            super(text, action);
            this.icon = icon;
        }
    }

    private static class MenuItem {
        String text;
        Runnable action;

        MenuItem(String text, Runnable action) {
            this.text = text;
            this.action = action;
        }
    }
}
