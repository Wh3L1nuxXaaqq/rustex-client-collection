package org.luaj.vm2.lib;

import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.LibFunction;

public abstract class ThreeArgFunction
extends LibFunction {
    @Override
    public abstract LuaValue call(LuaValue var1, LuaValue var2, LuaValue var3);

    @Override
    public final LuaValue call() {
        return this.call(NIL, NIL, NIL);
    }

    @Override
    public final LuaValue call(LuaValue arg) {
        return this.call(arg, NIL, NIL);
    }

    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2) {
        return this.call(arg1, arg2, NIL);
    }

    @Override
    public Varargs invoke(Varargs varargs) {
        return this.call(varargs.arg1(), varargs.arg(2), varargs.arg(3));
    }
}
