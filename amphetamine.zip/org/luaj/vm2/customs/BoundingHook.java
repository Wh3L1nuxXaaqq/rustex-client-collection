package org.luaj.vm2.customs;

import net.minecraft.util.math.AxisAlignedBB;

public class BoundingHook {
    private AxisAlignedBB bb;

    public BoundingHook(AxisAlignedBB bb) {
        this.bb = bb;
    }

    public double minX() {
        return this.bb.minX;
    }

    public double maxX() {
        return this.bb.maxX;
    }

    public double minY() {
        return this.bb.minY;
    }

    public double maxY() {
        return this.bb.maxY;
    }

    public double minZ() {
        return this.bb.minZ;
    }

    public double maxZ() {
        return this.bb.maxZ;
    }
}
