package org.luaj.vm2.customs.events;

import amph.main.event.ThePacket;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketChat;
import org.luaj.vm2.customs.EventHook;

public class EventPacketHook
extends EventHook {
    private ThePacket.EventSendPacket sendPacket;
    private ThePacket.EventReceivePacket receivePacket;

    public EventPacketHook(ThePacket.EventSendPacket event) {
        super(event);
        this.sendPacket = event;
    }

    public EventPacketHook(ThePacket.EventReceivePacket event) {
        super(event);
        this.receivePacket = event;
    }

    public boolean isServerPacket(String string) {
        return switch (string.toLowerCase()) {
            case "spacketchat" -> this.receivePacket.getPacket() instanceof SPacketChat;
            default -> false;
        };
    }

    public boolean isClientPacket(String string) {
        return switch (string.toLowerCase()) {
            case "cpacketchatmessage" -> this.sendPacket.getPacket() instanceof CPacketChatMessage;
            default -> false;
        };
    }

    public void cancelSend() {
        this.sendPacket.setCancelled(true);
    }

    public void cancelReceive() {
        this.receivePacket.setCancelled(true);
    }

    @Override
    public String getName() {
        return "packet_event";
    }
}
