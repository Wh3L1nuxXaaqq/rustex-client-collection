package org.luaj.vm2.compiler.jse;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LoadState;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.compiler.LuaC;
import org.luaj.vm2.compiler.jse.JseBaseLib;
import org.luaj.vm2.compiler.jse.JseIoLib;
import org.luaj.vm2.compiler.jse.JseMathLib;
import org.luaj.vm2.compiler.jse.JseOsLib;
import org.luaj.vm2.compiler.jse.JseStringLib;
import org.luaj.vm2.compiler.jse.LuajavaLib;
import org.luaj.vm2.lib.Bit32Lib;
import org.luaj.vm2.lib.CoroutineLib;
import org.luaj.vm2.lib.DebugLib;
import org.luaj.vm2.lib.PackageLib;
import org.luaj.vm2.lib.TableLib;

public class JsePlatform {
    public static Globals standardGlobals() {
        Globals globals = new Globals();
        globals.load(new JseBaseLib());
        globals.load(new PackageLib());
        globals.load(new Bit32Lib());
        globals.load(new TableLib());
        globals.load(new JseStringLib());
        globals.load(new CoroutineLib());
        globals.load(new JseMathLib());
        globals.load(new JseIoLib());
        globals.load(new JseOsLib());
        globals.load(new LuajavaLib());
        LoadState.install(globals);
        LuaC.install(globals);
        return globals;
    }

    public static Globals debugGlobals() {
        Globals globals = JsePlatform.standardGlobals();
        globals.load(new DebugLib());
        return globals;
    }

    public static Varargs luaMain(LuaValue mainChunk, String[] args) {
        Globals g = JsePlatform.standardGlobals();
        int n = args.length;
        LuaValue[] vargs = new LuaValue[args.length];
        for (int i = 0; i < n; ++i) {
            vargs[i] = LuaValue.valueOf(args[i]);
        }
        LuaTable arg = LuaValue.listOf(vargs);
        arg.set("n", n);
        g.set("arg", (LuaValue)arg);
        mainChunk.initupvalue1(g);
        return mainChunk.invoke(LuaValue.varargsOf(vargs));
    }
}
