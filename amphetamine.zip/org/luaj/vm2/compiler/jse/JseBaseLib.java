package org.luaj.vm2.compiler.jse;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.BaseLib;

public class JseBaseLib
extends BaseLib {
    @Override
    public LuaValue call(LuaValue modname, LuaValue env) {
        super.call(modname, env);
        env.checkglobals().STDIN = System.in;
        return env;
    }

    @Override
    public InputStream findResource(String filename) {
        File f = new File(filename);
        if (!f.exists()) {
            return super.findResource(filename);
        }
        try {
            return new BufferedInputStream(new FileInputStream(f));
        }
        catch (IOException ioe) {
            return null;
        }
    }
}
