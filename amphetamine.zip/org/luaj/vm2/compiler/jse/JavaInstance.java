package org.luaj.vm2.compiler.jse;

import java.lang.reflect.Field;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaUserdata;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.compiler.jse.CoerceJavaToLua;
import org.luaj.vm2.compiler.jse.CoerceLuaToJava;
import org.luaj.vm2.compiler.jse.JavaClass;

class JavaInstance
extends LuaUserdata {
    JavaClass jclass;

    JavaInstance(Object instance) {
        super(instance);
    }

    @Override
    public LuaValue get(LuaValue key) {
        Field f;
        if (this.jclass == null) {
            this.jclass = JavaClass.forClass(this.m_instance.getClass());
        }
        if ((f = this.jclass.getField(key)) != null) {
            try {
                return CoerceJavaToLua.coerce(f.get(this.m_instance));
            }
            catch (Exception e) {
                throw new LuaError(e);
            }
        }
        LuaValue m = this.jclass.getMethod(key);
        if (m != null) {
            return m;
        }
        Class c = this.jclass.getInnerClass(key);
        if (c != null) {
            return JavaClass.forClass(c);
        }
        return super.get(key);
    }

    @Override
    public void set(LuaValue key, LuaValue value) {
        Field f;
        if (this.jclass == null) {
            this.jclass = JavaClass.forClass(this.m_instance.getClass());
        }
        if ((f = this.jclass.getField(key)) != null) {
            try {
                f.set(this.m_instance, CoerceLuaToJava.coerce(value, f.getType()));
                return;
            }
            catch (Exception e) {
                throw new LuaError(e);
            }
        }
        super.set(key, value);
    }
}
