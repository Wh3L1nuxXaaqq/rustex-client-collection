package amph.main.command;

import amph.main.command.Command;
import amph.main.utility.misc.ChatUtility;

public abstract class CommandAbstract {
    public String name = this.getClass().getAnnotation(Command.class).name();
    public String description = this.getClass().getAnnotation(Command.class).description();
    public String[] alias = this.getClass().getAnnotation(Command.class).alias();

    public abstract void error();

    public abstract void execute(String[] var1) throws Exception;

    public void sendMessage(String message) {
        ChatUtility.addChatMessage(message);
    }
}
