package amph.main.command;

import amph.main.command.CommandAbstract;
import amph.main.command.CommandHandler;
import amph.main.command.impl.BindCommand;
import amph.main.command.impl.ConfigCommand;
import amph.main.command.impl.FriendCommand;
import amph.main.command.impl.GPSCommand;
import amph.main.command.impl.HCLIP;
import amph.main.command.impl.HelpCommand;
import amph.main.command.impl.MacroCommand;
import amph.main.command.impl.NameProtectCommand;
import amph.main.command.impl.ParseCommand;
import amph.main.command.impl.PrefixCommand;
import amph.main.command.impl.ReloadCommand;
import amph.main.command.impl.RofolComanda;
import amph.main.command.impl.Teleport;
import amph.main.command.impl.VCLIP;
import amph.main.command.impl.report.ReportCommand;
import com.darkmagician6.eventapi.EventManager;
import java.util.ArrayList;
import java.util.List;

public class CommandManager {
    private final ArrayList<CommandAbstract> commands = new ArrayList();
    private static String prefix = "%";

    public CommandManager() {
        EventManager.register(new CommandHandler(this));
        this.commands.add(new PrefixCommand());
        this.commands.add(new ConfigCommand());
        this.commands.add(new FriendCommand());
        this.commands.add(new ReloadCommand());
        this.commands.add(new BindCommand());
        this.commands.add(new GPSCommand());
        this.commands.add(new MacroCommand());
        this.commands.add(new ParseCommand());
        this.commands.add(new HelpCommand());
        this.commands.add(new VCLIP());
        this.commands.add(new HCLIP());
        this.commands.add(new RofolComanda());
        this.commands.add(new ReportCommand());
        this.commands.add(new NameProtectCommand());
        this.commands.add(new Teleport());
    }

    public List<CommandAbstract> getCommands() {
        return this.commands;
    }

    public boolean execute(String args) {
        for (CommandAbstract command : this.commands) {
            String[] split = args.substring(1).split(" ");
            for (String c : command.alias) {
                if (!split[0].equalsIgnoreCase(c.replace("%", ""))) continue;
                try {
                    command.execute(split);
                }
                catch (Exception e) {
                    command.error();
                }
                return true;
            }
        }
        return false;
    }

    public static String getPrefix() {
        return prefix;
    }

    public static void setPrefix(String prefix) {
        CommandManager.prefix = prefix;
    }
}
