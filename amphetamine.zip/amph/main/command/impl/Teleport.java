package amph.main.command.impl;

import amph.main.command.Command;
import amph.main.command.CommandAbstract;
import amph.main.utility.Utility;
import amph.main.utility.misc.ChatUtility;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.Vec3d;

@Command(name="teleport", description="\u0442\u043f", alias={"tp", "teleport"})
public class Teleport
extends CommandAbstract {
    @Override
    public void error() {
        ChatUtility.addChatMessage("\u041e\u0448\u0438\u0431\u043a\u0430!");
    }

    @Override
    public void execute(String ... args) {
        int i;
        for (i = 0; i < 10; ++i) {
            Utility.mc.player.connection.sendPacket(new CPacketPlayer.Position(Utility.mc.player.posX, Utility.mc.player.posY, Utility.mc.player.posZ, false));
        }
        for (i = 0; i < 10; ++i) {
            Utility.mc.player.connection.sendPacket(new CPacketPlayer.Position(Double.parseDouble(args[1]), Double.parseDouble(args[2]), Double.parseDouble(args[3]), false));
        }
        Utility.mc.player.setPosition(Double.parseDouble(args[1]), Double.parseDouble(args[2]), Double.parseDouble(args[3]));
        String cords = "X: " + args[1] + ", Y: " + args[2] + ", Z: " + args[3];
        ChatUtility.addChatMessage("\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043b \u043d\u0430 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b: " + cords);
    }

    private void sendPackets(double x, double y, double z) {
        Vec3d nextPos = new Vec3d(Utility.mc.player.posX + x, Utility.mc.player.posY + y, Utility.mc.player.posZ + z);
        Vec3d bounds = this.getBoundsVec(x, z);
        CPacketPlayer.Position nextPosPacket = new CPacketPlayer.Position(nextPos.xCoord, nextPos.yCoord, nextPos.zCoord, Utility.mc.player.onGround);
        Utility.mc.player.connection.sendPacket(nextPosPacket);
        CPacketPlayer.Position boundsPacket = new CPacketPlayer.Position(bounds.xCoord, bounds.yCoord, bounds.zCoord, Utility.mc.player.onGround);
        Utility.mc.player.connection.sendPacket(boundsPacket);
        Utility.mc.player.connection.sendPacket(new CPacketConfirmTeleport(1));
    }

    private Vec3d getBoundsVec(double x, double z) {
        return new Vec3d(Utility.mc.player.posX + x, Utility.mc.player.posY - 1337.0, Utility.mc.player.posZ + z);
    }
}
