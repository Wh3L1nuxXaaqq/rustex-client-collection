package amph.main.command.impl;

import amph.main.Amphetamine;
import amph.main.command.Command;
import amph.main.command.CommandAbstract;
import amph.main.module.Utils;
import amph.main.utility.misc.ChatUtility;
import net.minecraft.util.text.TextFormatting;

@Command(name="debug", description="show debug info", alias={"debug", "predict"})
public class RofolComanda
extends CommandAbstract {
    @Override
    public void execute(String[] args) throws Exception {
        ChatUtility.addChatMessage("item damage - " + Utils.mc.player.getHeldItemMainhand().itemDamage);
        ChatUtility.addChatMessage("\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 - " + Amphetamine.getInstance().getUserInfo().getName());
        ChatUtility.addChatMessage("\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 \u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 - " + Amphetamine.getInstance().getUserInfo().getUid());
        ChatUtility.addChatMessage("\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 - " + Amphetamine.getInstance().getUserInfo().getRole());
        ChatUtility.addChatMessage("\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 \u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 - " + (float)Utils.mc.getConnection().getPlayerInfo(Utils.mc.player.getUniqueID()).getResponseTime() / 20.0f);
        ChatUtility.addChatMessage("\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405\u043f\u0457\u0405 - " + Utils.mc.getConnection().getPlayerInfo(Utils.mc.player.getUniqueID()).getResponseTime());
        System.gc();
    }

    @Override
    public void error() {
        this.sendMessage(String.valueOf((Object)TextFormatting.GOLD) + "Error");
    }
}
