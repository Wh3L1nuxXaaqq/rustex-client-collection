package amph.main.command.impl;

import amph.main.command.Command;
import amph.main.command.CommandAbstract;
import amph.main.utility.Utility;
import amph.main.utility.misc.ChatUtility;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;

@Command(name="hclip", description="\u0442\u043f \u043f\u043e \u0433\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u0438", alias={"hclip"})
public class HCLIP
extends CommandAbstract {
    @Override
    public void error() {
        ChatUtility.addChatMessage("\u041e\u0448\u0438\u0431\u043a\u0430!");
    }

    @Override
    public void execute(String ... args) {
        int i;
        float f = Utility.mc.player.rotationYaw * ((float)Math.PI / 180);
        double speed = Double.parseDouble(args[1]);
        double x = -((double)MathHelper.sin(f) * speed);
        double z = (double)MathHelper.cos(f) * speed;
        for (i = 0; i < 10; ++i) {
            Utility.mc.player.connection.sendPacket(new CPacketPlayer.Position(Utility.mc.player.posX, Utility.mc.player.posY, Utility.mc.player.posZ, false));
        }
        for (i = 0; i < 10; ++i) {
            Utility.mc.player.connection.sendPacket(new CPacketPlayer.Position(Utility.mc.player.posX + x, Utility.mc.player.posY, Utility.mc.player.posZ + z, false));
        }
        Utility.mc.player.setPosition(Utility.mc.player.posX + x, Utility.mc.player.posY, Utility.mc.player.posZ + z);
        ChatUtility.addChatMessage("\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043b \u043d\u0430 " + args[1].replace("-", "") + " \u0431\u043b\u043e\u043a\u043e\u0432 " + (args[1].startsWith("-") ? "\u043d\u0430\u0437\u0430\u0434" : "\u0432\u043f\u0435\u0440\u0435\u0434"));
    }
}
