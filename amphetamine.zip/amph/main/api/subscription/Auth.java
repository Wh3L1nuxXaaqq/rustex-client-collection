package amph.main.api.subscription;

import amph.main.Amphetamine;
import amph.main.utility.misc.CryptorUtility;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import javax.imageio.ImageIO;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import org.apache.commons.codec.digest.DigestUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class Auth {
    public static String hwid;
    public static String key;
    private static BufferedImage avatar;
    private static Auth instance;
    private static boolean NBwh;
    protected static boolean passedCheck;

    public static void setInstance(Auth instance) {
        Auth.instance = instance;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void Server(boolean print) throws IOException {
        block26: {
            block25: {
                try {
                    String keysDec;
                    String dec;
                    String decryptedResponse;
                    String base64EncryptedResponse;
                    String line;
                    if (print) {
                        System.out.println("[Amphetamine] -> \u041f\u043e\u043b\u0443\u0447\u0435\u043d \u043a\u043b\u044e\u0447 \u0434\u043b\u044f \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u0430\u0446\u0438\u0438 \u0432 \u043a\u043b\u0438\u0435\u043d\u0442\u0435! [" + key + "]");
                    }
                    URL url = new URL("https://Amphetamineclient.ru/api/v1/auth/authorization.php?key=" + key + "&hwid=" + hwid);
                    HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
                    String domain = url.getHost();
                    InetAddress addresses = InetAddress.getByName(domain);
                    if (addresses.getHostAddress().equalsIgnoreCase("127.0.0.1")) return;
                    int responseCode = connection.getResponseCode();
                    if (responseCode != 200) return;
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    if (addresses.getHostAddress().equalsIgnoreCase("127.0.0.1")) return;
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    if (jsonResponse == null) return;
                    String base64Key = jsonResponse.getString("key");
                    if (base64Key == null) {
                        System.out.println("JVM Error: 0x99, 0xDE don't verify!");
                        System.exit(-1);
                    }
                    if ((base64EncryptedResponse = jsonResponse.getString("data")) == null) {
                        System.out.println("JVM Error: 0x99, 0xDE don't verify!");
                        System.exit(-1);
                    }
                    if ((decryptedResponse = Auth.decrypt(base64EncryptedResponse, dec = Auth.decrypt(base64Key, keysDec = CryptorUtility.decrypt("fN5yDE9XhyMTfVpwgzZRxM9RMGIQklv2Bo+yevIlN8ktvjoPEH2vxGiKzighoEic", "wadswadasdawdasd")))).contains(":")) {
                        if (print) {
                            System.out.println("[Amphetamine] -> \u0423\u0441\u043f\u0435\u0448\u043d\u0430\u044f \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u0430\u0446\u0438\u044f.");
                        }
                    } else {
                        if (decryptedResponse.equalsIgnoreCase("fuck")) {
                            if (print) {
                                System.out.println("[Amphetamine] -> \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043d\u0430\u043b\u0438\u0447\u0438\u0435 \u043f\u043e\u0434\u043f\u0438\u0441\u043a\u0438. [HWID: " + hwid + "]");
                            }
                            while (true) {
                                // Infinite loop
                            }
                        }
                        if (print) {
                            System.out.println("[Amphetamine] -> \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043d\u0430\u043b\u0438\u0447\u0438\u0435 \u043f\u043e\u0434\u043f\u0438\u0441\u043a\u0438. [HWID: " + hwid + "]");
                        }
                        while (true) {
                            // Infinite loop
                        }
                    }
                    if (decryptedResponse == null) {
                        System.out.println("JVM Error: 0x99, 0xDE don't verify!");
                        System.exit(-1);
                    }
                    if (addresses.getHostAddress().equalsIgnoreCase("127.0.0.1")) {
                        while (true) {
                            // Infinite loop
                        }
                    }
                    if (!decryptedResponse.contains(":")) return;
                    String[] parts = decryptedResponse.split(":");
                    if (parts[0].equalsIgnoreCase("null")) {
                        System.exit(-1);
                    }
                    if (parts[4].equalsIgnoreCase("null")) {
                        System.exit(-1);
                    }
                    if (parts[0].equalsIgnoreCase("")) {
                        System.out.println("JVM Error: 0x99, 0xDE don't verify!");
                        System.exit(-1);
                    }
                    Amphetamine.getInstance().username = parts[0];
                    Amphetamine.getInstance().userid = Integer.parseInt(parts[1]);
                    Amphetamine.getInstance().userrole = parts[4];
                    Amphetamine.getInstance().usertill = parts[3];
                    Auth.decodeAndProcessImage();
                    NBwh = true;
                    passedCheck = false;
                    BehaviorDefaultDispenseItem.isDispense = true;
                    return;
                }
                catch (IOException e) {
                    System.out.println(e);
                    System.out.println("[Amphetamine] -> \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u043a \u0441\u0435\u0440\u0432\u0435\u0440\u0443. [HWID: " + hwid + "]");
                    System.out.println("[Amphetamine] -> \u041a\u043e\u0434 \u043e\u0448\u0438\u0431\u043a\u0438: IO (1)");
                }
                catch (JSONException e) {
                    System.out.println((Object)e);
                    System.out.println("[Amphetamine] -> \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u043a \u0441\u0435\u0440\u0432\u0435\u0440\u0443. [HWID: " + hwid + "]");
                    System.out.println("[Amphetamine] -> \u041a\u043e\u0434 \u043e\u0448\u0438\u0431\u043a\u0438: JSON (2)");
                    break block25;
                }
                catch (NumberFormatException e) {
                    System.out.println(e);
                    System.out.println("[Amphetamine] -> \u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u043a \u0441\u0435\u0440\u0432\u0435\u0440\u0443. [HWID: " + hwid + "]");
                    System.out.println("[Amphetamine] -> \u041a\u043e\u0434 \u043e\u0448\u0438\u0431\u043a\u0438: NUMBER (3)");
                    break block26;
                }
                while (true) {
                    // Infinite loop
                }
            }
            while (true) {
                // Infinite loop
            }
        }
        while (true) {
            // Infinite loop
        }
    }

    private static String decrypt(String encryptedData, String key) {
        StringBuilder result = new StringBuilder();
        int dataLength = encryptedData.length();
        int keyLength = key.length();
        for (int i = 0; i < dataLength; ++i) {
            result.append((char)(encryptedData.charAt(i) ^ key.charAt(i % keyLength)));
        }
        return result.toString();
    }

    private static String decoder(String input) {
        byte[] decodedBytes = Base64.getDecoder().decode(input);
        return new String(decodedBytes, StandardCharsets.UTF_8);
    }

    private static void decodeAndProcessImage() throws IOException {
        int responseCode;
        URL url = new URL("https://Amphetamineclient.ru/api/v1/auth/avatar.php?key=" + key + "&hwid=" + hwid);
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setRequestMethod("GET");
        connection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
        String domain = url.getHost();
        InetAddress addresses = InetAddress.getByName(domain);
        if (!addresses.getHostAddress().equalsIgnoreCase("127.0.0.1") && (responseCode = connection.getResponseCode()) == 200) {
            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            String base64 = String.valueOf(response);
            byte[] imageBytes = Base64.getDecoder().decode(base64);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
            avatar = ImageIO.read(bis);
        }
    }

    private static String generateHwid() throws IOException {
        return DigestUtils.md5Hex((String)DigestUtils.md5Hex((String)(System.getenv("os") + System.getProperty("os.arch") + System.getenv("HOMEDRIVE") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("PROCESSOR_LEVEL") + System.getProperty("os.version") + System.getProperty("os.name") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("COMPUTERNAME") + System.getenv("user.name") + System.getenv("PHYSICAL_MEMORY_SIZE"))));
    }

    public static String getHwid() {
        return hwid;
    }

    public static void setHwid(String hwid) {
        Auth.hwid = hwid;
    }

    public static String getKey() {
        return key;
    }

    public static void setKey(String key) {
        Auth.key = key;
    }

    public static BufferedImage getAvatar() {
        return avatar;
    }

    public static void setAvatar(BufferedImage avatar) {
        Auth.avatar = avatar;
    }

    public static Auth getInstance() {
        return instance;
    }

    public static boolean isNBwh() {
        return NBwh;
    }

    public static void setNBwh(boolean NBwh) {
        Auth.NBwh = NBwh;
    }

    static {
        NBwh = false;
        passedCheck = true;
        try {
            hwid = Auth.generateHwid();
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }
}
