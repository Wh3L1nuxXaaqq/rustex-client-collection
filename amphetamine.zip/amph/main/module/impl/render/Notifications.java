package amph.main.module.impl.render;

import amph.main.event.TheRender;
import amph.main.manager.notification.Notification;
import amph.main.manager.notification.NotificationManager;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.utility.render.RenderUtility;
import amph.main.utility.render.animation.Animation;
import amph.main.utility.render.animation.Direction;
import amph.main.utility.render.font.Fonts;
import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;

@ModuleAnnotation(name="Notifications", category=Category.DISPLAY)
public class Notifications
extends Module {
    @EventTarget
    public void onRender2D(TheRender.EventRender2D event) {
        int W = event.getResolution().getScaledWidth();
        int H = event.getResolution().getScaledHeight();
        GlStateManager.pushMatrix();
        float startY = (float)H - 8.0f;
        for (int i = NotificationManager.getNotifications().size() - 1; i >= 0; --i) {
            Notification notif = NotificationManager.getNotifications().get(i);
            Animation anim = notif.getAnimation();
            boolean expired = notif.getTimerHelper().hasReached(notif.getTime());
            anim.setDirection(expired ? Direction.BACKWARDS : Direction.FORWARDS);
            if (anim.finished(Direction.BACKWARDS)) {
                NotificationManager.getNotifications().remove(i);
                continue;
            }
            float animOut = anim.getOutput();
            float notifW = Math.max(160.0f, (float)(Fonts.mntssb14.getStringWidth(notif.getTitle()) + Fonts.mntssb13.getStringWidth("  " + notif.getDescription()) + 20));
            float notifH = 22.0f;
            float x = (float)W - notifW * animOut - 4.0f;
            float y = startY - notifH;
            RenderUtility.drawRoundedRect(x, y, notifW, notifH, 3.0f, new Color(20, 20, 20, (int)(220.0f * animOut)).getRGB());
            int stripColor = this.getTypeColor(notif);
            RenderUtility.drawRoundedRect(x, y, 3.0f, notifH, 2.0f, new Color(stripColor, true).getRGB());
            float textY = y + notifH / 2.0f - (float)Fonts.mntssb14.getFontHeight() / 2.0f;
            Fonts.mntssb14.drawString(notif.getTitle(), x + 8.0f, textY, this.applyAlpha(Color.WHITE.getRGB(), (int)(255.0f * animOut)));
            Fonts.mntssb13.drawString(notif.getDescription(), x + 8.0f + (float)Fonts.mntssb14.getStringWidth(notif.getTitle()) + 4.0f, textY + 1.0f, this.applyAlpha(new Color(160, 160, 160).getRGB(), (int)(255.0f * animOut)));
            startY -= (notifH + 4.0f) * animOut;
        }
        GlStateManager.popMatrix();
    }

    private int getTypeColor(Notification notif) {
        switch (notif.getType()) {
            case SUCCESS: {
                return new Color(50, 200, 80, 200).getRGB();
            }
            case ERROR: {
                return new Color(200, 50, 50, 200).getRGB();
            }
            case INFO: {
                return new Color(80, 80, 200, 200).getRGB();
            }
        }
        return new Color(150, 150, 150, 200).getRGB();
    }

    private int applyAlpha(int color, int alpha) {
        Color c = new Color(color, true);
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.min(255, (int)((double)c.getAlpha() / 255.0 * (double)alpha))).getRGB();
    }

    public void displayNotif(Notification notif) {
        NotificationManager.getNotifications().add(notif);
    }
}
