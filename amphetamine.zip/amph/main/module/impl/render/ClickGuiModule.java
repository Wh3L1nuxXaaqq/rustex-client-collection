package amph.main.module.impl.render;

import amph.main.Amphetamine;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.module.setting.impl.BooleanSetting;
import amph.main.module.setting.impl.NumberSetting;
import amph.main.utility.misc.SoundUtility;

@ModuleAnnotation(name="ClickGui", category=Category.RENDER)
public class ClickGuiModule
extends Module {
    public static BooleanSetting blur = new BooleanSetting("Blur", true);
    public static NumberSetting blurRadius = new NumberSetting("Blur Radius", 5.0f, 1.0f, 15.0f, 1.0f);
    public static BooleanSetting sounds = new BooleanSetting("Sounds", true);

    public ClickGuiModule() {
        this.bind = 54;
        blurRadius.setVisible(() -> blur.get());
    }

    @Override
    public void onEnable() {
        super.onEnable();
        mc.displayGuiScreen(Amphetamine.getInstance().getRemasteredGUI());
        if (sounds.get()) {
            SoundUtility.playSound("guienabledev2.wav", 1.0f);
        }
        this.setToggled(false);
    }
}
