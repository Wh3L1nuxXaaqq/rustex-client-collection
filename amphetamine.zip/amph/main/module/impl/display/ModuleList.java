package amph.main.module.impl.display;

import amph.main.Amphetamine;
import amph.main.event.TheRender;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.module.setting.impl.BooleanSetting;
import amph.main.utility.render.RenderUtility;
import amph.main.utility.render.animation.Animation;
import amph.main.utility.render.animation.Direction;
import amph.main.utility.render.font.Fonts;
import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.renderer.GlStateManager;

@ModuleAnnotation(name="ArrayList", category=Category.DISPLAY)
public class ModuleList
extends Module {
    public final BooleanSetting lowerCase = new BooleanSetting("Lower Case", false);
    public final BooleanSetting hideRender = new BooleanSetting("Hide Render", false);
    public final BooleanSetting shadow = new BooleanSetting("Shadow", true);
    private static final float ROW_H = 11.0f;
    private static final float PAD_X = 4.0f;
    private static final float BAR_W = 2.0f;
    private static final float RADIUS = 3.0f;

    @EventTarget
    public void onRender2D(TheRender.EventRender2D event) {
        if (ModuleList.mc.gameSettings.showDebugInfo) {
            return;
        }
        GlStateManager.pushMatrix();
        List<Module> modules = this.getSorted();
        float x = 5.0f;
        float y = 6.0f;
        int c1 = Amphetamine.getInstance().getC(0).getRGB();
        int c2 = Amphetamine.getInstance().getC(500).getRGB();
        int rowIndex = 0;
        for (Module m : modules) {
            float alpha;
            Animation anim = m.getAnimation();
            anim.setDirection(m.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);
            if (!m.isEnabled() && anim.finished(Direction.BACKWARDS) || (alpha = anim.getOutput()) < 0.01f) continue;
            String name = this.lowerCase.get() ? m.getName().toLowerCase() : m.getName();
            float w = (float)Fonts.mntssb14.getStringWidth(name) + 8.0f + 2.0f;
            if (this.shadow.get()) {
                RenderUtility.drawRoundedRect(x + 1.0f, y + 1.0f, w, 11.0f, 3.0f, this.applyAlpha(new Color(0, 0, 0).getRGB(), (int)(80.0f * alpha)));
            }
            RenderUtility.drawRoundedRect(x, y, w, 11.0f, 3.0f, this.applyAlpha(new Color(20, 20, 20).getRGB(), (int)(210.0f * alpha)));
            Color topColor = new Color(Amphetamine.getInstance().getC(rowIndex * 40).getRGB(), true);
            Color bottomColor = new Color(Amphetamine.getInstance().getC(rowIndex * 40 + 200).getRGB(), true);
            RenderUtility.drawRoundedGradientRect(x, y, 2.0f, 11.0f, 3.0f, 1.0f, this.applyAlpha(topColor.getRGB(), (int)(255.0f * alpha)), this.applyAlpha(topColor.getRGB(), (int)(255.0f * alpha)), this.applyAlpha(bottomColor.getRGB(), (int)(255.0f * alpha)), this.applyAlpha(bottomColor.getRGB(), (int)(255.0f * alpha)));
            float textY = y + 5.5f - (float)Fonts.mntssb14.getFontHeight() / 2.0f;
            Fonts.mntssb14.drawString(name, x + 2.0f + 4.0f, textY, this.applyAlpha(Color.WHITE.getRGB(), (int)(255.0f * alpha)));
            y += 11.0f * alpha + 1.0f;
            ++rowIndex;
        }
        GlStateManager.popMatrix();
    }

    private List<Module> getSorted() {
        return Amphetamine.getInstance().getModuleManager().getModules().stream().filter(m -> !this.hideRender.get() || m.getCategory() != Category.RENDER).sorted(Comparator.comparingInt(m -> Fonts.mntssb14.getStringWidth(this.lowerCase.get() ? m.getName().toLowerCase() : m.getName())).reversed()).collect(Collectors.toList());
    }

    private int applyAlpha(int color, int alpha) {
        Color c = new Color(color, true);
        int a = (int)((double)c.getAlpha() / 255.0 * (double)Math.min(255, alpha));
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), a).getRGB();
    }
}
