package amph.main.module.impl.combat;

import amph.main.event.ThePlayer;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.EntityPlayer;

@ModuleAnnotation(name="AntiBot", category=Category.COMBAT)
public class AntiBot
extends Module {
    @EventTarget
    public void onUpdate(ThePlayer.EventUpdate event) {
        for (int i = 0; i < AntiBot.mc.world.loadedEntityList.size(); ++i) {
            EntityPlayer player;
            if (!(AntiBot.mc.world.loadedEntityList.get(i) instanceof EntityPlayer) || !(player = (EntityPlayer)AntiBot.mc.world.loadedEntityList.get(i)).isInvisible() || player == AntiBot.mc.player) continue;
            AntiBot.mc.world.removeEntity(player);
        }
    }
}
