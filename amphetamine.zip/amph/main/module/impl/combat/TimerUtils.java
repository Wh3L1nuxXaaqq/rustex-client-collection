package amph.main.module.impl.combat;

public class TimerUtils {
    long mc = System.currentTimeMillis();

    public void reset() {
        this.mc = System.currentTimeMillis();
    }

    public long getMc() {
        return System.currentTimeMillis() - this.mc;
    }

    public boolean hasReached(long time) {
        return System.currentTimeMillis() - this.mc > time;
    }
}
