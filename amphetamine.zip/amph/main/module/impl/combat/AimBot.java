package amph.main.module.impl.combat;

import amph.main.Amphetamine;
import amph.main.event.ThePlayer;
import amph.main.event.TheRender;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.module.setting.impl.BooleanSetting;
import amph.main.module.setting.impl.ColorSetting;
import amph.main.module.setting.impl.NumberSetting;
import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

@ModuleAnnotation(name="AimBot", category=Category.COMBAT)
public class AimBot
extends Module {
    public static NumberSetting predict = new NumberSetting("Predict", 5.5f, 0.0f, 10.0f, 0.01f);
    public static NumberSetting fov = new NumberSetting("FOV", 100.0f, 0.0f, 360.0f, 1.0f);
    public static NumberSetting vPredict = new NumberSetting("VPredict", 0.0f, -5.0f, 5.0f, 0.1f);
    public static BooleanSetting renderFov = new BooleanSetting("Render FOV", false);
    public static BooleanSetting throughWalls = new BooleanSetting("Through Walls", false);
    public static BooleanSetting sync = new BooleanSetting("Sync", false);
    public static ColorSetting fovColor = new ColorSetting("FOV Color", Color.WHITE.getRGB());
    public static EntityPlayer target = null;

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
    }

    @EventTarget
    public void onUpdate(ThePlayer.EventUpdate event) {
        if (AimBot.mc.world == null || AimBot.mc.player == null) {
            return;
        }
        if (sync.get() && AimBot.mc.player.ticksExisted % 2 != 0) {
            return;
        }
        target = this.getTarget();
        if (target != null) {
            float[] rotations = this.getAim(target);
            float clampedPitch = MathHelper.clamp(rotations[1], -90.0f, 90.0f);
            AimBot.mc.player.rotationYaw = rotations[0];
            AimBot.mc.player.rotationPitch = clampedPitch;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public void onRender2D(TheRender.EventRender2D event) {
        if (!renderFov.get()) {
            return;
        }
        float cx = (float)event.getResolution().getScaledWidth() / 2.0f;
        float cy = (float)event.getResolution().getScaledHeight() / 2.0f;
        float gameFov = AimBot.mc.gameSettings.fovSetting;
        int radius = (int)(fov.get() / gameFov * ((float)event.getResolution().getScaledWidth() / 4.5f));
        GL11.glPushAttrib((int)1048575);
        GL11.glPushMatrix();
        try {
            GL11.glEnable((int)3042);
            GL11.glDisable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glLineWidth((float)2.0f);
            Color c = new Color(fovColor.get(), true);
            GL11.glColor4f((float)((float)c.getRed() / 255.0f), (float)((float)c.getGreen() / 255.0f), (float)((float)c.getBlue() / 255.0f), (float)0.6f);
            GL11.glBegin((int)2);
            for (int i = 0; i <= 360; ++i) {
                double angle = Math.toRadians(i);
                GL11.glVertex2d((double)((double)cx + Math.cos(angle) * (double)radius), (double)((double)cy + Math.sin(angle) * (double)radius));
            }
            GL11.glEnd();
            GL11.glEnable((int)3553);
            GL11.glDisable((int)3042);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        finally {
            GL11.glPopMatrix();
            GL11.glPopAttrib();
        }
    }

    private float[] getAim(EntityPlayer t) {
        double vx = t.posX - t.lastTickPosX;
        double vz = t.posZ - t.lastTickPosZ;
        double vy = t.posY - t.lastTickPosY;
        double px = t.posX + vx * (double)predict.get();
        double pz = t.posZ + vz * (double)predict.get();
        double py = t.posY + vy + (double)t.getEyeHeight() + (double)vPredict.get();
        double dx = px - AimBot.mc.player.posX;
        double dy = py - (AimBot.mc.player.posY + (double)AimBot.mc.player.getEyeHeight());
        double dz = pz - AimBot.mc.player.posZ;
        double dist = MathHelper.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float pitch = (float)(-Math.atan2(dy, dist) * 57.29577951308232);
        return new float[]{yaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
    }

    private EntityPlayer getTarget() {
        ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        for (Entity e : AimBot.mc.world.loadedEntityList) {
            EntityPlayer p2;
            if (!(e instanceof EntityPlayer) || (p2 = (EntityPlayer)e) == AimBot.mc.player || p2.isInvisible() || p2.getHealth() <= 0.0f || p2.isPotionActive(MobEffects.INVISIBILITY) || Amphetamine.getInstance().getFriendManager().isFriend(p2.getName()) || !throughWalls.get() && !AimBot.mc.player.canEntityBeSeen(p2) || !this.isInFov(p2)) continue;
            list.add(p2);
        }
        list.sort(Comparator.comparingDouble(p -> p.getDistanceToEntity(AimBot.mc.player)));
        return list.isEmpty() ? null : (EntityPlayer)list.get(0);
    }

    private boolean isInFov(EntityPlayer t) {
        double dx = t.posX - AimBot.mc.player.posX;
        double dz = t.posZ - AimBot.mc.player.posZ;
        double dist = MathHelper.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float diff = MathHelper.wrapDegrees(yaw - AimBot.mc.player.rotationYaw);
        return Math.abs(diff) <= fov.get() / 2.0f;
    }
}
