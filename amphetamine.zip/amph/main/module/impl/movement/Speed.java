package amph.main.module.impl.movement;

import amph.main.event.ThePlayer;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.utility.move.MovementUtility;
import com.darkmagician6.eventapi.EventTarget;
import java.util.Random;
import net.minecraft.network.play.client.CPacketPlayer;

@ModuleAnnotation(name="Speed", category=Category.MOVEMENT)
public class Speed
extends Module {
    public double randomHorizontal() {
        int randomValue = new Random().nextInt(29000000) + 500;
        if (new Random().nextBoolean()) {
            return randomValue;
        }
        return -randomValue;
    }

    public Speed() {
        this.premiumModule = true;
    }

    @Override
    public void onEnable() {
        Speed.mc.player.capabilities.isFlying = false;
        Speed.mc.player.capabilities.setFlySpeed(0.05f);
        Speed.mc.player.motionY = 0.0;
        Speed.mc.player.motionX = 0.0;
        Speed.mc.player.motionZ = 0.0;
        Speed.mc.player.connection.sendPacket(new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), Speed.mc.player.onGround));
        Speed.mc.player.setSprinting(false);
        Speed.mc.player.onGround = true;
        super.onEnable();
    }

    @EventTarget
    public void onTick(ThePlayer.EventMove e) {
        Speed.mc.timer.field_194147_b = 2.0f;
        if (MovementUtility.isMoving()) {
            if (Speed.mc.player.ticksExisted % 35 == 0) {
                Speed.mc.timer.field_194147_b = 2.0f;
                Speed.mc.player.capabilities.isFlying = false;
                Speed.mc.player.capabilities.setFlySpeed(0.05f);
                Speed.mc.player.motionY = 0.0;
                Speed.mc.player.motionX = 0.0;
                Speed.mc.player.motionZ = 0.0;
                Speed.mc.player.connection.sendPacket(new CPacketPlayer.Position(this.randomHorizontal(), 1.0, this.randomHorizontal(), Speed.mc.player.onGround));
                Speed.mc.player.setSprinting(false);
                Speed.mc.player.onGround = true;
            } else {
                Speed.mc.player.setSprinting(false);
                Speed.mc.player.onGround = true;
                Speed.mc.timer.field_194147_b = 0.85003f;
            }
        }
    }
}
