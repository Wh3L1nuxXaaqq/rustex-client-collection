package amph.main.module.impl.player;

import amph.main.Amphetamine;
import amph.main.event.TheInput;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.utility.misc.ChatUtility;
import com.darkmagician6.eventapi.EventTarget;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.text.TextFormatting;

@ModuleAnnotation(name="MCF", category=Category.PLAYER)
public class MiddleClick
extends Module {
    @EventTarget
    public void onMouse(TheInput.EventMouse event) {
        if (event.getButton() == 2 && MiddleClick.mc.pointedEntity instanceof EntityLivingBase) {
            String name = MiddleClick.mc.pointedEntity.getName();
            if (name.equals(MiddleClick.mc.player.getName())) {
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u041d\u0435\u043b\u044c\u0437\u044f \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u0430\u043c\u043e\u0433\u043e \u0441\u0435\u0431\u044f \u0432 \u0434\u0440\u0443\u0437\u044c\u044f :)");
                return;
            }
            if (Amphetamine.getInstance().getFriendManager().isFriend(name)) {
                Amphetamine.getInstance().getFriendManager().removeFriend(name);
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + name + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430 \u0434\u0440\u0443\u0437\u0435\u0439.");
            } else {
                Amphetamine.getInstance().getFriendManager().addFriend(name);
                ChatUtility.addChatMessage(String.valueOf(ChatFormatting.GRAY) + "\u0418\u0433\u0440\u043e\u043a " + String.valueOf((Object)TextFormatting.GOLD) + name + String.valueOf(ChatFormatting.GRAY) + " \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0434\u0440\u0443\u0437\u044c\u044f!");
            }
        }
    }
}
