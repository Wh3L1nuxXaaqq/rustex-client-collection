package amph.main.module.impl.player;

import amph.main.event.ThePlayer;
import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;
import amph.main.module.Utils;
import amph.main.module.setting.impl.NumberSetting;
import amph.main.utility.misc.TimerHelper;
import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

@ModuleAnnotation(name="AutoMine", category=Category.PLAYER)
public class AutoFarm
extends Module {
    private final NumberSetting distance = new NumberSetting("Distance", 4.0f, 1.0f, 10.0f, 0.5f);
    private final NumberSetting delay = new NumberSetting("Delay", 230.0f, 50.0f, 1000.0f, 10.0f);
    private final TimerHelper timer = new TimerHelper();
    private BlockPos targetBlock;

    @EventTarget
    public void onUpdate(ThePlayer.EventUpdate event) {
        if (AutoFarm.mc.world == null || AutoFarm.mc.player == null) {
            return;
        }
        for (Entity entity : AutoFarm.mc.world.loadedEntityList) {
            if (entity == null || !(entity instanceof EntityArmorStand) || entity.posX == 0.0 && entity.posY == 0.0 && entity.posZ == 0.0 || entity.getDistanceToEntity(AutoFarm.mc.player) > this.distance.get()) continue;
            ArrayList<BlockPos> candidates = new ArrayList<BlockPos>();
            int ex = (int)entity.posX;
            int ez = (int)entity.posZ;
            for (int x = -2; x < 2; ++x) {
                for (int z = -2; z < 2; ++z) {
                    BlockPos pos = new BlockPos(ex + x, (int)entity.posY, ez + z);
                    Block block = AutoFarm.mc.world.getBlockState(pos).getBlock();
                    if (block == Blocks.AIR || !this.isTargetBlock(block)) continue;
                    candidates.add(pos);
                }
            }
            if (candidates.isEmpty()) continue;
            candidates.sort(Comparator.comparingDouble(entity::getDistanceSq));
            this.targetBlock = (BlockPos)candidates.get(0);
            float[] rot = Utils.getNeededRotations(entity.posX, entity.posY + 0.37, entity.posZ, AutoFarm.mc.player.posX, AutoFarm.mc.player.posY + (double)AutoFarm.mc.player.getEyeHeight(), AutoFarm.mc.player.posZ);
            event.setRotationYaw(rot[0]);
            event.setRotationPitch(rot[1]);
            if (!this.timer.hasReached(this.delay.get()) || mc.getConnection() == null) continue;
            mc.getConnection().sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.targetBlock, EnumFacing.DOWN));
            mc.getConnection().sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.targetBlock, EnumFacing.DOWN));
            AutoFarm.mc.player.swingArm(EnumHand.MAIN_HAND);
            this.timer.reset();
        }
    }

    private boolean isTargetBlock(Block b) {
        return b == Blocks.STAINED_HARDENED_CLAY || b == Blocks.DIAMOND_ORE || b == Blocks.GOLD_ORE || b == Blocks.IRON_ORE || b == Blocks.REDSTONE_ORE || b == Blocks.LOG || b == Blocks.LOG2;
    }
}
