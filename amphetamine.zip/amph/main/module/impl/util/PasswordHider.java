package amph.main.module.impl.util;

import amph.main.module.Category;
import amph.main.module.Module;
import amph.main.module.ModuleAnnotation;

@ModuleAnnotation(name="PasswordHider", category=Category.UTIL)
public class PasswordHider
extends Module {
}
