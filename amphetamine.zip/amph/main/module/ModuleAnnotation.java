package amph.main.module;

import amph.main.module.Category;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(value=RetentionPolicy.RUNTIME)
public @interface ModuleAnnotation {
    public String name();

    public Category category();
}
