package amph.main.ui.menu.altmanager;

import amph.main.ui.menu.altmanager.alt.Alt;
import amph.main.ui.menu.altmanager.alt.AltManager;
import amph.main.ui.menu.main.newgui.NewMainMenu;
import amph.main.utility.render.RenderUtility;
import amph.main.utility.render.StencilUtility;
import amph.main.utility.render.font.FontRenderer;
import amph.main.utility.render.font.Fonts;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.util.Session;
import net.minecraft.util.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.lwjgl.input.Mouse;

public class GuiAltManager
extends GuiScreen {
    private String inputText = "";
    private boolean typing = false;
    private String editingName = null;
    private float scroll = 0.0f;
    private float scrollAn = 0.0f;
    private float hAdd = 0.0f;
    private float hRandom = 0.0f;
    private float hBack = 0.0f;
    private final List<Alt> deletedAccounts = new ArrayList<Alt>();
    private boolean showDeleted = false;
    private static FontRenderer iconFont;
    private boolean fontsReady = false;

    private void initFonts() {
        if (this.fontsReady) {
            return;
        }
        iconFont = Fonts.getHudFont("icon.ttf", 14.0f);
        if (iconFont == null) {
            iconFont = Fonts.mntssb13;
        }
        this.fontsReady = true;
    }

    @Override
    public void initGui() {
        ScaledResolution sr = new ScaledResolution(this.mc);
        this.width = sr.getScaledWidth();
        this.height = sr.getScaledHeight();
    }

    @Override
    public void updateScreen() {
        this.scrollAn += (this.scroll - this.scrollAn) * 0.2f;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.initFonts();
        ScaledResolution sr = new ScaledResolution(this.mc);
        int W = sr.getScaledWidth();
        int H = sr.getScaledHeight();
        float cx = (float)W / 2.0f;
        float cy = (float)H / 2.0f;
        this.scroll += (float)Mouse.getDWheel() / 120.0f * 40.0f;
        RenderUtility.drawRect(0.0f, 0.0f, W, H, new Color(12, 15, 18).getRGB());
        int bg = new Color(25, 26, 33, 230).getRGB();
        int bg2 = new Color(34, 34, 34, 179).getRGB();
        int text = new Color(200, 200, 200).getRGB();
        int dim = new Color(150, 150, 150).getRGB();
        String currentNick = this.mc.session.getUsername();
        float nickBarW = 300.0f;
        float nickBarH = 28.0f;
        float nickBarX = cx - nickBarW / 2.0f;
        float nickBarY = cy - 130.0f;
        RenderUtility.drawRoundedRect(nickBarX, nickBarY, nickBarW, nickBarH, 6.0f, bg);
        RenderUtility.drawRoundedOutlineRect(nickBarX, nickBarY, nickBarW, nickBarH, 6.0f, 1.0f, bg2);
        String nickLabel = "Your nick: " + currentNick;
        Fonts.mntssb14.drawCenteredString(nickLabel, cx, nickBarY + nickBarH / 2.0f - (float)Fonts.mntssb14.getFontHeight() / 2.0f, text);
        float panelW = 360.0f;
        float panelH = 200.0f;
        float panelX = cx - panelW / 2.0f;
        float panelY = cy - 90.0f;
        RenderUtility.drawRoundedRect(panelX, panelY, panelW, panelH, 6.0f, bg);
        RenderUtility.drawRoundedOutlineRect(panelX, panelY, panelW, panelH, 6.0f, 1.0f, bg2);
        Fonts.mntssb16.drawCenteredString("Alt Manager", cx, panelY + 8.0f, text);
        float recycleX = panelX + panelW - 28.0f;
        float recycleY = panelY + 6.0f;
        boolean recycleHov = this.isIn(mouseX, mouseY, recycleX, recycleY, 20.0f, 20.0f);
        RenderUtility.drawRoundedRect(recycleX, recycleY, 20.0f, 20.0f, 5.0f, bg);
        RenderUtility.drawRoundedOutlineRect(recycleX, recycleY, 20.0f, 20.0f, 5.0f, 1.0f, recycleHov ? new Color(80, 180, 80, 150).getRGB() : bg2);
        iconFont.drawCenteredString("r", recycleX + 10.0f, recycleY + 10.0f - (float)iconFont.getFontHeight() / 2.0f, recycleHov ? text : dim);
        float inputX = panelX + 10.0f;
        float inputY = panelY + 30.0f;
        float inputW = panelW - 20.0f;
        float inputH = 24.0f;
        boolean inputHov = this.isIn(mouseX, mouseY, inputX, inputY, inputW, inputH);
        RenderUtility.drawRoundedRect(inputX, inputY, inputW, inputH, 5.0f, bg);
        RenderUtility.drawRoundedOutlineRect(inputX, inputY, inputW, inputH, 5.0f, 1.0f, this.typing ? new Color(80, 120, 200, 150).getRGB() : (inputHov ? new Color(80, 80, 100, 150).getRGB() : bg2));
        String displayText = this.inputText.isEmpty() && !this.typing ? "Enter Username" : this.inputText + (this.typing && System.currentTimeMillis() % 1000L > 500L ? "_" : "");
        int inputTextColor = this.inputText.isEmpty() && !this.typing ? dim : text;
        Fonts.mntssb14.drawString(displayText, inputX + 8.0f, inputY + inputH / 2.0f - (float)Fonts.mntssb14.getFontHeight() / 2.0f, inputTextColor);
        float listX = panelX + 10.0f;
        float listY = panelY + 62.0f;
        float listW = panelW - 20.0f;
        float listH = 90.0f;
        StencilUtility.initStencilToWrite();
        RenderUtility.drawRect(listX, listY, listW, listH, -1);
        StencilUtility.readStencilBuffer(1);
        float offset = this.scrollAn;
        int size = AltManager.registry.size();
        float maxScroll = Math.max(0.0f, (float)size * 40.0f - listH);
        this.scroll = Math.max(-maxScroll, Math.min(0.0f, this.scroll));
        for (int i = 0; i < AltManager.registry.size(); ++i) {
            Alt alt = AltManager.registry.get(i);
            float acY = listY + offset + (float)i * 40.0f;
            if (acY + 35.0f < listY || acY > listY + listH) continue;
            boolean isSelected = alt.getUsername().equalsIgnoreCase(this.mc.session.getUsername());
            boolean isHov = this.isIn(mouseX, mouseY, listX, acY, listW - 50.0f, 35.0f);
            int rowBg = isSelected ? new Color(30, 50, 80, 200).getRGB() : new Color(30, 32, 40, 200).getRGB();
            RenderUtility.drawRoundedRect(listX, acY, listW - 50.0f, 35.0f, 5.0f, rowBg);
            RenderUtility.drawRoundedOutlineRect(listX, acY, listW - 50.0f, 35.0f, 5.0f, 1.0f, isHov || isSelected ? new Color(80, 120, 200, 120).getRGB() : bg2);
            GlStateManager.pushMatrix();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            if (alt.getSkin() == null) {
                alt.setSkin(AbstractClientPlayer.getLocationSkin(alt.getUsername()));
                this.loadSkin(alt);
            } else {
                this.mc.getTextureManager().bindTexture(alt.getSkin());
                GlStateManager.enableTexture2D();
                StencilUtility.initStencilToWrite();
                RenderUtility.drawRoundedRect(listX + 5.0f, acY + 5.0f, 25.0f, 25.0f, 3.0f, Color.BLACK.getRGB());
                StencilUtility.readStencilBuffer(1);
                Gui.drawScaledCustomSizeModalRect((int)(listX + 5.0f), (int)(acY + 5.0f), 8.0f, 8.0f, 8, 8, 25, 25, 64.0f, 64.0f);
                StencilUtility.uninitStencilBuffer();
            }
            GlStateManager.popMatrix();
            Fonts.mntssb14.drawString(alt.getUsername(), listX + 35.0f, acY + 8.0f, isSelected ? new Color(100, 200, 100).getRGB() : text);
            Fonts.mntssb12.drawString(alt.getDate(), listX + 35.0f, acY + 21.0f, dim);
            float editX = listX + listW - 48.0f;
            float editY = acY + 7.0f;
            boolean editHov = this.isIn(mouseX, mouseY, editX, editY, 20.0f, 20.0f);
            RenderUtility.drawRoundedRect(editX, editY, 20.0f, 20.0f, 4.0f, bg);
            RenderUtility.drawRoundedOutlineRect(editX, editY, 20.0f, 20.0f, 4.0f, 1.0f, editHov ? new Color(80, 180, 80, 150).getRGB() : bg2);
            iconFont.drawCenteredString("q", editX + 10.0f, editY + 10.0f - (float)iconFont.getFontHeight() / 2.0f, editHov ? text : dim);
            float delX = listX + listW - 24.0f;
            float delY = acY + 7.0f;
            boolean delHov = this.isIn(mouseX, mouseY, delX, delY, 20.0f, 20.0f);
            RenderUtility.drawRoundedRect(delX, delY, 20.0f, 20.0f, 4.0f, bg);
            RenderUtility.drawRoundedOutlineRect(delX, delY, 20.0f, 20.0f, 4.0f, 1.0f, delHov ? new Color(180, 60, 60, 150).getRGB() : bg2);
            iconFont.drawCenteredString("p", delX + 10.0f, delY + 10.0f - (float)iconFont.getFontHeight() / 2.0f, delHov ? text : dim);
        }
        StencilUtility.uninitStencilBuffer();
        float btnY = panelY + panelH - 35.0f;
        float btnW = 90.0f;
        float btnH = 25.0f;
        float btnGap = 10.0f;
        float totalBtnW = btnW * 3.0f + btnGap * 2.0f;
        float btnStartX = cx - totalBtnW / 2.0f;
        this.hAdd = this.lerp(this.hAdd, this.isIn(mouseX, mouseY, btnStartX, btnY, btnW, btnH) ? 1.0f : 0.0f, 0.15f);
        this.hRandom = this.lerp(this.hRandom, this.isIn(mouseX, mouseY, btnStartX + btnW + btnGap, btnY, btnW, btnH) ? 1.0f : 0.0f, 0.15f);
        this.hBack = this.lerp(this.hBack, this.isIn(mouseX, mouseY, btnStartX + (btnW + btnGap) * 2.0f, btnY, btnW, btnH) ? 1.0f : 0.0f, 0.15f);
        this.drawBtn(btnStartX, btnY, btnW, btnH, "Add Alt", this.hAdd, bg, bg2, text);
        this.drawBtn(btnStartX + btnW + btnGap, btnY, btnW, btnH, "Random Nick", this.hRandom, bg, bg2, text);
        this.drawBtn(btnStartX + (btnW + btnGap) * 2.0f, btnY, btnW, btnH, "Back", this.hBack, bg, bg2, text);
        if (this.showDeleted) {
            float dpX = panelX + panelW + 10.0f;
            float dpY = panelY;
            float dpW = 180.0f;
            float dpH = 200.0f;
            RenderUtility.drawRoundedRect(dpX, dpY, dpW, dpH, 6.0f, bg);
            RenderUtility.drawRoundedOutlineRect(dpX, dpY, dpW, dpH, 6.0f, 1.0f, bg2);
            Fonts.mntssb14.drawCenteredString("Deleted Accounts", dpX + dpW / 2.0f, dpY + 8.0f, text);
            for (int i = 0; i < this.deletedAccounts.size(); ++i) {
                Alt da = this.deletedAccounts.get(i);
                float daY = dpY + 30.0f + (float)i * 38.0f;
                if (daY + 30.0f > dpY + dpH) break;
                boolean daHov = this.isIn(mouseX, mouseY, dpX + 5.0f, daY, dpW - 10.0f, 30.0f);
                RenderUtility.drawRoundedRect(dpX + 5.0f, daY, dpW - 10.0f, 30.0f, 5.0f, daHov ? new Color(35, 40, 50, 200).getRGB() : new Color(30, 32, 40, 200).getRGB());
                RenderUtility.drawRoundedOutlineRect(dpX + 5.0f, daY, dpW - 10.0f, 30.0f, 5.0f, 1.0f, bg2);
                GlStateManager.pushMatrix();
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                if (da.getSkin() != null) {
                    this.mc.getTextureManager().bindTexture(da.getSkin());
                    GlStateManager.enableTexture2D();
                    Gui.drawScaledCustomSizeModalRect((int)(dpX + 8.0f), (int)(daY + 3.0f), 8.0f, 8.0f, 8, 8, 22, 22, 64.0f, 64.0f);
                }
                GlStateManager.popMatrix();
                Fonts.mntssb13.drawString(da.getUsername(), dpX + 34.0f, daY + 10.0f, text);
                float restX = dpX + dpW - 30.0f;
                float restY = daY + 5.0f;
                boolean restHov = this.isIn(mouseX, mouseY, restX, restY, 20.0f, 20.0f);
                RenderUtility.drawRoundedRect(restX, restY, 20.0f, 20.0f, 4.0f, bg);
                RenderUtility.drawRoundedOutlineRect(restX, restY, 20.0f, 20.0f, 4.0f, 1.0f, restHov ? new Color(80, 180, 80, 150).getRGB() : bg2);
                iconFont.drawCenteredString("b", restX + 10.0f, restY + 10.0f - (float)iconFont.getFontHeight() / 2.0f, restHov ? text : dim);
            }
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawBtn(float x, float y, float w, float h, String label, float hov, int bg, int bg2, int text) {
        int br = (int)(hov * 15.0f);
        Color base = new Color(30 + br, 32 + br, 42 + br);
        RenderUtility.drawRoundedRect(x, y, w, h, 6.0f, base.getRGB());
        RenderUtility.drawRoundedOutlineRect(x, y, w, h, 6.0f, 1.0f, new Color(80, 90, 120, (int)(60.0f + hov * 100.0f)).getRGB());
        Fonts.mntssb13.drawCenteredString(label, x + w / 2.0f, y + h / 2.0f - (float)Fonts.mntssb13.getFontHeight() / 2.0f, new Color(160 + (int)(hov * 40.0f), 160 + (int)(hov * 40.0f), 160 + (int)(hov * 40.0f)).getRGB());
    }

    private void loadSkin(Alt alt) {
        TextureManager tm = this.mc.getTextureManager();
        tm.getTexture(alt.getSkin());
        ThreadDownloadImageData tex = new ThreadDownloadImageData(null, String.format("https://minotar.net/skin/%s", StringUtils.stripControlCodes(alt.getUsername())), DefaultPlayerSkin.getDefaultSkin(AbstractClientPlayer.getOfflineUUID(alt.getUsername())), new ImageBufferDownload());
        tm.loadTexture(alt.getSkin(), tex);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (btn != 0) {
            super.mouseClicked(mx, my, btn);
            return;
        }
        ScaledResolution sr = new ScaledResolution(this.mc);
        int W = sr.getScaledWidth();
        int H = sr.getScaledHeight();
        float cx = (float)W / 2.0f;
        float cy = (float)H / 2.0f;
        float panelX = cx - 180.0f;
        float panelY = cy - 90.0f;
        float panelW = 360.0f;
        float panelH = 200.0f;
        float inputX = panelX + 10.0f;
        float inputY = panelY + 30.0f;
        float inputW = panelW - 20.0f;
        float inputH = 24.0f;
        if (this.isIn(mx, my, inputX, inputY, inputW, inputH)) {
            this.typing = !this.typing;
            return;
        }
        float recycleX = panelX + panelW - 28.0f;
        float recycleY = panelY + 6.0f;
        if (this.isIn(mx, my, recycleX, recycleY, 20.0f, 20.0f)) {
            this.showDeleted = !this.showDeleted;
            return;
        }
        float btnW = 90.0f;
        float btnGap = 10.0f;
        float totalBtnW = btnW * 3.0f + btnGap * 2.0f;
        float btnStartX = cx - totalBtnW / 2.0f;
        float btnY = panelY + panelH - 35.0f;
        float btnH = 25.0f;
        if (this.isIn(mx, my, btnStartX, btnY, btnW, btnH)) {
            if (!this.inputText.isEmpty()) {
                if (this.editingName != null) {
                    AltManager.registry.removeIf(a -> a.getUsername().equals(this.editingName));
                    AltManager.addAccount(new Alt(this.inputText, "", Alt.getCurrentDate()));
                    this.editingName = null;
                } else {
                    AltManager.addAccount(new Alt(this.inputText, "", Alt.getCurrentDate()));
                }
                this.inputText = "";
                this.typing = false;
            }
            return;
        }
        if (this.isIn(mx, my, btnStartX + btnW + btnGap, btnY, btnW, btnH)) {
            String rnd = RandomStringUtils.randomAlphabetic((int)8);
            AltManager.addAccount(new Alt(rnd, "", Alt.getCurrentDate()));
            this.mc.session = new Session(rnd, "", "", "mojang");
            return;
        }
        if (this.isIn(mx, my, btnStartX + (btnW + btnGap) * 2.0f, btnY, btnW, btnH)) {
            this.mc.displayGuiScreen(new NewMainMenu());
            return;
        }
        float listX = panelX + 10.0f;
        float listY = panelY + 62.0f;
        float listW = panelW - 20.0f;
        float offset = this.scrollAn;
        for (int i = 0; i < AltManager.registry.size(); ++i) {
            Alt alt = AltManager.registry.get(i);
            float editX = listX + listW - 48.0f;
            float acY = listY + offset + (float)i * 40.0f;
            float editY = acY + 7.0f;
            if (this.isIn(mx, my, editX, editY, 20.0f, 20.0f)) {
                this.inputText = alt.getUsername();
                this.editingName = alt.getUsername();
                this.typing = true;
                return;
            }
            float delX = listX + listW - 24.0f;
            float delY = acY + 7.0f;
            if (this.isIn(mx, my, delX, delY, 20.0f, 20.0f)) {
                this.deletedAccounts.add(0, alt);
                if (this.deletedAccounts.size() > 5) {
                    this.deletedAccounts.remove(this.deletedAccounts.size() - 1);
                }
                AltManager.removeAccount(alt);
                return;
            }
            if (!this.isIn(mx, my, listX, acY, listW - 50.0f, 35.0f)) continue;
            this.mc.session = new Session(alt.getUsername(), "", "", "mojang");
            return;
        }
        if (this.showDeleted) {
            float dpX = panelX + panelW + 10.0f;
            float dpY = panelY;
            float dpW = 180.0f;
            for (int i = 0; i < this.deletedAccounts.size(); ++i) {
                float restX = dpX + dpW - 30.0f;
                float daY = dpY + 30.0f + (float)i * 38.0f;
                float restY = daY + 5.0f;
                if (!this.isIn(mx, my, restX, restY, 20.0f, 20.0f)) continue;
                AltManager.addAccount(this.deletedAccounts.remove(i));
                return;
            }
        }
        super.mouseClicked(mx, my, btn);
    }

    @Override
    public void keyTyped(char c, int key) throws IOException {
        if (!this.typing) {
            if (key == 1) {
                this.mc.displayGuiScreen(new NewMainMenu());
            }
            return;
        }
        if (key == 14) {
            if (!this.inputText.isEmpty()) {
                this.inputText = this.inputText.substring(0, this.inputText.length() - 1);
            }
        } else if (key == 28) {
            if (!this.inputText.isEmpty()) {
                if (this.editingName != null) {
                    AltManager.registry.removeIf(a -> a.getUsername().equals(this.editingName));
                    AltManager.addAccount(new Alt(this.inputText, "", Alt.getCurrentDate()));
                    this.editingName = null;
                } else {
                    AltManager.addAccount(new Alt(this.inputText, "", Alt.getCurrentDate()));
                }
                this.inputText = "";
                this.typing = false;
            }
        } else if (key == 1) {
            this.typing = false;
            this.inputText = "";
        } else if (Character.isDefined(c) && !Character.isISOControl(c) && this.inputText.length() < 16) {
            this.inputText = this.inputText + c;
        }
    }

    private boolean isIn(double mx, double my, float x, float y, float w, float h) {
        return mx >= (double)x && mx <= (double)(x + w) && my >= (double)y && my <= (double)(y + h);
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
