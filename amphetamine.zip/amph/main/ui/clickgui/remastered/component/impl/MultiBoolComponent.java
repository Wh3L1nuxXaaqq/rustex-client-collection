package amph.main.ui.clickgui.remastered.component.impl;

import amph.main.Amphetamine;
import amph.main.module.setting.impl.MultiBooleanSetting;
import amph.main.ui.clickgui.remastered.component.Component;
import amph.main.ui.clickgui.remastered.component.impl.ModuleComponent;
import amph.main.utility.render.RenderUtility;
import amph.main.utility.render.font.Fonts;
import java.awt.Color;
import java.util.Comparator;
import java.util.stream.Collectors;

public class MultiBoolComponent
extends Component {
    public ModuleComponent moduleComponent;
    public MultiBooleanSetting setting;

    public MultiBoolComponent(ModuleComponent moduleComponent, MultiBooleanSetting setting) {
        super(0.0f, 0.0f, 0.0f, 18.0f);
        this.moduleComponent = moduleComponent;
        this.setting = setting;
    }

    @Override
    public void render(int mouseX, int mouseY) {
        super.render(mouseX, mouseY);
        Fonts.mntssb13.drawString(this.setting.getName(), this.x + 5.0f, this.y + 3.0f, Color.WHITE.getRGB());
        float availableWidth = this.width - 10.0f;
        float xOffset = 2.0f;
        float yOffset = 6.0f;
        float spacing = 3.5f;
        for (String mode : this.setting.values.stream().sorted(Comparator.comparingDouble(this::getEnabledWidth)).collect(Collectors.toList())) {
            float enabledWidth = this.getEnabledWidth(mode);
            float enabledHeight = Fonts.mntssb13.getFontHeight() + 6;
            if (xOffset + enabledWidth > availableWidth) {
                xOffset = 2.0f;
                yOffset += enabledHeight + spacing;
            }
            if (this.setting.selectedValues.get(this.setting.values.indexOf(mode)).booleanValue()) {
                RenderUtility.drawRoundedGradientRect(this.x + 3.0f + xOffset, this.y + (float)Fonts.mntssb13.getFontHeight() + yOffset, enabledWidth, enabledHeight, 3.0f, 1.0f, Amphetamine.getInstance().getC(0).getRGB(), Amphetamine.getInstance().getC(0).getRGB(), Amphetamine.getInstance().getC(500).getRGB(), Amphetamine.getInstance().getC(500).getRGB());
            } else {
                RenderUtility.drawRoundedRect(this.x + 3.0f + xOffset, this.y + (float)Fonts.mntssb13.getFontHeight() + yOffset, enabledWidth, enabledHeight, 3.0f, new Color(52, 52, 52).getRGB());
            }
            Fonts.mntssb13.drawString(mode, this.x + 5.0f + xOffset, this.y + 3.5f + (float)Fonts.mntssb13.getFontHeight() + yOffset, Color.WHITE.getRGB());
            xOffset += enabledWidth + spacing;
        }
        this.height = 18.0f + yOffset;
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        float availableWidth = this.width - 10.0f;
        float xOffset = 2.0f;
        float yOffset = 4.0f;
        float spacing = 3.0f;
        for (String mode : this.setting.values.stream().sorted(Comparator.comparingDouble(this::getEnabledWidth)).collect(Collectors.toList())) {
            float enabledWidth = this.getEnabledWidth(mode);
            float enabledHeight = Fonts.mntssb13.getFontHeight() + 6;
            if (xOffset + enabledWidth > availableWidth) {
                xOffset = 2.0f;
                yOffset += enabledHeight + spacing;
            }
            if (RenderUtility.isHovered(mouseX, mouseY, (double)(this.x + 3.0f + xOffset), (double)(this.y + (float)Fonts.mntssb13.getFontHeight() + yOffset), (double)enabledWidth, (double)enabledHeight)) {
                int index = this.setting.values.indexOf(mode);
                this.setting.selectedValues.set(index, this.setting.selectedValues.get(index) == false);
            }
            xOffset += enabledWidth + spacing;
        }
    }

    private float getEnabledWidth(String mode) {
        return Fonts.mntssb13.getStringWidth(mode) + 4;
    }

    @Override
    public boolean isVisible() {
        return this.setting.getVisible().get();
    }
}
