package amph.main.utility.blur;

import amph.main.utility.blur.ShaderUtility;
import amph.main.utility.blur.StencilUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL11;

public class SmartStencil {
    public static Framebuffer framebuffer = new Framebuffer(1, 1, false);

    public static void update(Framebuffer framebuffer) {
        if (framebuffer.framebufferWidth != Minecraft.getMinecraft().displayWidth || framebuffer.framebufferHeight != Minecraft.getMinecraft().displayHeight) {
            framebuffer.createBindFramebuffer(Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        }
    }

    public static void renderStart(Runnable clamp) {
        SmartStencil.update(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        clamp.run();
        framebuffer.unbindFramebuffer();
        Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(true);
        if (framebuffer != null) {
            GL11.glPushMatrix();
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(516, 0.0f);
            GlStateManager.enableBlend();
            OpenGlHelper.glBlendFunc(770, 771, 1, 0);
            Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(true);
            ShaderUtility.bindTexture(SmartStencil.framebuffer.framebufferTexture);
            StencilUtil.initStencilToWrite();
            clamp.run();
            StencilUtil.readStencilBuffer(1);
        }
    }

    public static void renderEnd() {
        if (framebuffer != null) {
            StencilUtil.uninitStencilBuffer();
            Minecraft.getMinecraft().getFramebuffer().bindFramebuffer(false);
            GlStateManager.disableAlpha();
            GL11.glPopMatrix();
        }
    }
}
