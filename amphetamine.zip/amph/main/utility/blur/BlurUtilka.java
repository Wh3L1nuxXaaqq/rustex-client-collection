package amph.main.utility.blur;

import amph.main.utility.Utility;
import amph.main.utility.blur.BloomUtil;
import amph.main.utility.blur.ShaderUtility;
import amph.main.utility.blur.StencilUtil;
import amph.main.utility.render.blur.GaussianBlur;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.shader.Framebuffer;

public class BlurUtilka
implements Utility {
    public static Framebuffer bloomFramebuffer = ShaderUtility.createFrameBuffer(new Framebuffer(new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth(), new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight(), true));

    public static void drawBlur(float radius, Runnable data) {
        StencilUtil.initStencilToWrite();
        data.run();
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(radius);
        StencilUtil.uninitStencilBuffer();
    }

    public static void drawBlurRect(float radius, Runnable data, float corner) {
        StencilUtil.initStencilToWrite();
        data.run();
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlurRect(radius, corner);
        StencilUtil.uninitStencilBuffer();
    }

    public static void drawShadow(float radius, float des, Runnable data, int c, boolean fill) {
        bloomFramebuffer = ShaderUtility.createFrameBuffer(bloomFramebuffer);
        bloomFramebuffer.framebufferClear();
        bloomFramebuffer.bindFramebuffer(true);
        data.run();
        bloomFramebuffer.unbindFramebuffer();
        BloomUtil.renderBlur(BlurUtilka.bloomFramebuffer.framebufferTexture, (int)radius, 1, c, des, !fill);
    }
}
