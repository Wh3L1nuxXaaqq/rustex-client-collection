package amph.main.utility.misc;

import java.security.Key;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptorUtility {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final int IV_LENGTH = 16;

    public static String encrypt(String data, String secretKey) {
        try {
            SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            SecureRandom secureRandom = new SecureRandom();
            byte[] iv = new byte[16];
            secureRandom.nextBytes(iv);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            cipher.init(1, (Key)keySpec, ivParameterSpec);
            byte[] encryptedBytes = cipher.doFinal(data.getBytes());
            byte[] result = new byte[16 + encryptedBytes.length];
            System.arraycopy(iv, 0, result, 0, 16);
            System.arraycopy(encryptedBytes, 0, result, 16, encryptedBytes.length);
            return Base64.getEncoder().encodeToString(result);
        }
        catch (Exception e) {
            System.err.println("Encryption error: " + e.getMessage());
            return null;
        }
    }

    public static String decrypt(String encryptedData, String secretKey) {
        try {
            byte[] encryptedBytesWithIV = Base64.getDecoder().decode(encryptedData);
            SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            byte[] iv = new byte[16];
            System.arraycopy(encryptedBytesWithIV, 0, iv, 0, 16);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            cipher.init(2, (Key)keySpec, ivParameterSpec);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytesWithIV, 16, encryptedBytesWithIV.length - 16);
            return new String(decryptedBytes);
        }
        catch (Exception e) {
            System.err.println("Decryption error: " + e.getMessage());
            return null;
        }
    }

    public static String adjustKeyLength(String key) {
        int length = 32;
        if (((String)key).length() < length) {
            while (((String)key).length() < length) {
                key = (String)key + "0";
            }
        } else if (((String)key).length() > length) {
            key = ((String)key).substring(0, length);
        }
        return key;
    }
}
