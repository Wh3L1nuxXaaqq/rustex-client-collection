package amph.main.utility.misc;

import amph.main.Amphetamine;
import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import net.minecraft.client.Minecraft;

public class Discord {
    private static final String discordID = "1067032653590700093";
    private static volatile boolean running = false;

    public static void startRPC() {
        try {
            Discord.doStart();
        }
        catch (Throwable t) {
            System.out.println("[DiscordRPC] Skipped: " + t.getMessage());
        }
    }

    private static void doStart() throws Throwable {
        DiscordEventHandlers handlers = new DiscordEventHandlers();
        handlers.ready = user -> System.out.println("[DiscordRPC] Ready: " + user.username);
        handlers.errored = (code, msg) -> System.out.println("[DiscordRPC] Error " + code + ": " + msg);
        handlers.disconnected = (code, msg) -> System.out.println("[DiscordRPC] Disconnected " + code);
        DiscordRPC rpc = DiscordRPC.INSTANCE;
        rpc.Discord_Initialize(discordID, handlers, true, null);
        DiscordRichPresence presence = new DiscordRichPresence();
        presence.startTimestamp = System.currentTimeMillis() / 1000L;
        presence.largeImageKey = "Amphetamine";
        presence.largeImageText = "discord.gg/rqyw3P2f2w";
        running = true;
        Thread thread = new Thread(() -> {
            while (running) {
                try {
                    String name = Amphetamine.getInstance().getUserInfo().getName();
                    String role = Amphetamine.getInstance().getUserInfo().getRole();
                    presence.details = "User: " + name + " | Role: " + role;
                    presence.state = Minecraft.getMinecraft().getCurrentServerData() != null ? "Playing on " + Minecraft.getMinecraft().getCurrentServerData().serverIP : "In main menu";
                    rpc.Discord_UpdatePresence(presence);
                    rpc.Discord_RunCallbacks();
                    Thread.sleep(2000L);
                }
                catch (Throwable throwable) {}
            }
        }, "DiscordRPC");
        thread.setDaemon(true);
        thread.start();
    }

    public static void stopRPC() {
        running = false;
        try {
            DiscordRPC.INSTANCE.Discord_Shutdown();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}
