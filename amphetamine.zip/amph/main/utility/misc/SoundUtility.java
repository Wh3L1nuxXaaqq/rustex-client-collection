package amph.main.utility.misc;

import amph.main.utility.Utility;
import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import net.minecraft.util.ResourceLocation;

public class SoundUtility
implements Utility {
    public static synchronized void playSound(String string, float volume) {
        try {
            Clip clip = AudioSystem.getClip();
            InputStream inputStream = mc.getResourceManager().getResource(new ResourceLocation("Amphetamine/sounds/" + string)).getInputStream();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(bufferedInputStream);
            clip.open(audioInputStream);
            clip.start();
            FloatControl control = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
            control.setValue(volume);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
