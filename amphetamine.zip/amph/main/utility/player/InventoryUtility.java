package amph.main.utility.player;

import amph.main.utility.Utility;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;

public class InventoryUtility
implements Utility {
    public static boolean doesHotbarHaveAxe() {
        for (int i = 0; i < 9; ++i) {
            InventoryUtility.mc.player.inventory.getStackInSlot(i);
            if (!(InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemAxe)) continue;
            return true;
        }
        return false;
    }

    public static int getAxe() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtility.mc.player.inventory.getStackInSlot(i);
            if (!(itemStack.getItem() instanceof ItemAxe)) continue;
            return i;
        }
        return 1;
    }

    public static int getItemSlot(Item item, boolean isHotbar) {
        for (int i = 0; i < (isHotbar ? 9 : 45); ++i) {
            if (InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem() != item) continue;
            return i;
        }
        return -1;
    }

    public static int getItemSlot(Item input) {
        if (input == InventoryUtility.mc.player.getHeldItemOffhand().getItem()) {
            return -2;
        }
        for (int i = 36; i >= 0; --i) {
            Item item = InventoryUtility.mc.player.inventory.getStackInSlot(i).getItem();
            if (item != input) continue;
            if (i < 9) {
                i += 36;
            }
            return i;
        }
        return -1;
    }
}
