package net.java.games.input;

import java.io.IOException;
import net.java.games.input.LinuxDeviceTask;
import net.java.games.input.LinuxEventDevice;

class LinuxEventDevice.1
extends LinuxDeviceTask {
    LinuxEventDevice.1() {
    }

    protected final Object execute() throws IOException {
        LinuxEventDevice.nClose(LinuxEventDevice.this.fd);
        return null;
    }
}
