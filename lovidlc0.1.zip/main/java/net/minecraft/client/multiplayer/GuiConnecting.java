package net.minecraft.client.multiplayer;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.CPacketLoginStart;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GuiConnecting
extends GuiScreen {
    private static final AtomicInteger CONNECTION_ID = new AtomicInteger(0);
    private static final Logger LOGGER = LogManager.getLogger();
    private NetworkManager networkManager;
    private boolean cancel;
    private final GuiScreen previousGuiScreen;

    public GuiConnecting(GuiScreen parent, Minecraft mcIn, ServerData serverDataIn) {
        this.mc = mcIn;
        this.previousGuiScreen = parent;
        ServerAddress serveraddress = ServerAddress.fromString(serverDataIn.serverIP);
        mcIn.loadWorld(null);
        mcIn.setServerData(serverDataIn);
        this.connect(serveraddress.getIP(), serveraddress.getPort());
    }

    public GuiConnecting(GuiScreen parent, Minecraft mcIn, String hostName, int port) {
        this.mc = mcIn;
        this.previousGuiScreen = parent;
        mcIn.loadWorld(null);
        this.connect(hostName, port);
    }

    private void connect(final String ip, final int port) {
        LOGGER.info("Connecting to {}, {}", (Object)ip, (Object)port);
        new Thread("Server Connector #" + CONNECTION_ID.incrementAndGet()){

            @Override
            public void run() {
                InetAddress inetaddress = null;
                try {
                    if (GuiConnecting.access$000(GuiConnecting.this)) {
                        return;
                    }
                    inetaddress = InetAddress.getByName(ip);
                    GuiConnecting.access$102(GuiConnecting.this, NetworkManager.createNetworkManagerAndConnect(inetaddress, port, GuiConnecting.access$200((GuiConnecting)GuiConnecting.this).gameSettings.isUsingNativeTransport()));
                    GuiConnecting.access$100(GuiConnecting.this).setNetHandler(new NetHandlerLoginClient(GuiConnecting.access$100(GuiConnecting.this), GuiConnecting.access$300(GuiConnecting.this), GuiConnecting.access$400(GuiConnecting.this)));
                    GuiConnecting.access$100(GuiConnecting.this).sendPacket(new C00Handshake(ip, port, EnumConnectionState.LOGIN));
                    GuiConnecting.access$100(GuiConnecting.this).sendPacket(new CPacketLoginStart(GuiConnecting.access$500(GuiConnecting.this).getSession().getProfile()));
                }
                catch (UnknownHostException unknownhostexception) {
                    if (GuiConnecting.access$000(GuiConnecting.this)) {
                        return;
                    }
                    GuiConnecting.access$600().error("Couldn't connect to server", (Throwable)unknownhostexception);
                    GuiConnecting.access$700(GuiConnecting.this).displayGuiScreen(new GuiDisconnected(GuiConnecting.access$400(GuiConnecting.this), "connect.failed", new TextComponentTranslation("disconnect.genericReason", "Unknown host")));
                }
                catch (Exception exception) {
                    if (GuiConnecting.access$000(GuiConnecting.this)) {
                        return;
                    }
                    GuiConnecting.access$600().error("Couldn't connect to server", (Throwable)exception);
                    String s = exception.toString();
                    if (inetaddress != null) {
                        String s1 = inetaddress + ":" + port;
                        s = s.replaceAll(s1, "");
                    }
                    GuiConnecting.access$800(GuiConnecting.this).displayGuiScreen(new GuiDisconnected(GuiConnecting.access$400(GuiConnecting.this), "connect.failed", new TextComponentTranslation("disconnect.genericReason", s)));
                }
            }
        }.start();
    }

    @Override
    public void updateScreen() {
        if (this.networkManager != null) {
            if (this.networkManager.isChannelOpen()) {
                this.networkManager.processReceivedPackets();
            } else {
                this.networkManager.checkDisconnected();
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, I18n.format("gui.cancel", new Object[0])));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) {
            this.cancel = true;
            if (this.networkManager != null) {
                this.networkManager.closeChannel(new TextComponentString("Aborted"));
            }
            this.mc.displayGuiScreen(this.previousGuiScreen);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        if (this.networkManager == null) {
            this.drawCenteredString(this.fontRendererObj, I18n.format("connect.connecting", new Object[0]), this.width / 2, this.height / 2 - 50, 0xFFFFFF);
        } else {
            this.drawCenteredString(this.fontRendererObj, I18n.format("connect.authorizing", new Object[0]), this.width / 2, this.height / 2 - 50, 0xFFFFFF);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    static boolean access$000(GuiConnecting x0) {
        return x0.cancel;
    }

    static NetworkManager access$102(GuiConnecting x0, NetworkManager x1) {
        x0.networkManager = x1;
        return x0.networkManager;
    }

    static Minecraft access$200(GuiConnecting x0) {
        return x0.mc;
    }

    static NetworkManager access$100(GuiConnecting x0) {
        return x0.networkManager;
    }

    static Minecraft access$300(GuiConnecting x0) {
        return x0.mc;
    }

    static GuiScreen access$400(GuiConnecting x0) {
        return x0.previousGuiScreen;
    }

    static Minecraft access$500(GuiConnecting x0) {
        return x0.mc;
    }

    static Logger access$600() {
        return LOGGER;
    }

    static Minecraft access$700(GuiConnecting x0) {
        return x0.mc;
    }

    static Minecraft access$800(GuiConnecting x0) {
        return x0.mc;
    }
}
