package wartyxx.lovidlcfree.utils.discord;

//import club.minnced.discord.rpc.DiscordEventHandlers;
//import club.minnced.discord.rpc.DiscordRichPresence;

public class DiscordRPC {
    /*private static final String APPLICATION_ID = "1545474544222085231";
    private static final club.minnced.discord.rpc.DiscordRPC rpc = club.minnced.discord.rpc.DiscordRPC.INSTANCE;
    private static DiscordRichPresence presence = new DiscordRichPresence();
    private static Thread rpcThread;
    private static boolean running;*/

    public static void start() {
        /*if (running) {
            return;
        }
        DiscordEventHandlers handlers = new DiscordEventHandlers();
        rpc.Discord_Initialize(APPLICATION_ID, handlers, true, "");
        DiscordRPC.presence.startTimestamp = System.currentTimeMillis() / 1000L;
        DiscordRPC.presence.details = "Role: User";
        DiscordRPC.presence.state = "t.me/LoviDLC";
        DiscordRPC.presence.largeImageKey = "logo";
        DiscordRPC.presence.largeImageText = "LoviDLC Free";
        DiscordRPC.presence.smallImageKey = "online";
        DiscordRPC.presence.smallImageText = "Playing";
        rpc.Discord_UpdatePresence(presence);
        running = true;
        rpcThread = new Thread(() -> {
            while (running) {
                rpc.Discord_RunCallbacks();
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException interruptedException) {}
            }
        });
        rpcThread.setDaemon(true);
        rpcThread.start();*/
    }

    public static void stop() {
        /*running = false;
        if (rpcThread != null) {
            rpcThread.interrupt();
        }
        rpc.Discord_Shutdown();*/
    }

    public static void setServer(String serverIp) {
        //DiscordRPC.presence.details = serverIp != null && !serverIp.isEmpty() ? serverIp : "Role: User";
        //rpc.Discord_UpdatePresence(presence);
    }

    static {
        //running = false;
    }
}
