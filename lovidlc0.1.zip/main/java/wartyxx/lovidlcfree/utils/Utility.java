package wartyxx.lovidlcfree.utils;

import net.minecraft.client.Minecraft;

public class Utility {
    protected static final Minecraft mc = Minecraft.getMinecraft();
}
