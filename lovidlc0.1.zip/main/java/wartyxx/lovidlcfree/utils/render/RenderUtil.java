package wartyxx.lovidlcfree.utils.render;

import java.awt.Color;
import wartyxx.lovidlcfree.utils.render.RoundUtil;

public class RenderUtil {
    public static void drawRoundRect(float x, float y, float width, float height, float radius, Color color) {
        RoundUtil.drawRound(x, y, width, height, radius, color);
    }
}
