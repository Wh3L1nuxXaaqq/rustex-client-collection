package wartyxx.lovidlcfree.utils.render;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class RoundUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static int programId = -1;
    private static final String VERTEX_SHADER = "#version 120\nvoid main() {\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n    gl_TexCoord[0] = gl_MultiTexCoord0;\n}";
    private static final String FRAGMENT_SHADER = "#version 120\nuniform vec2 u_size;\nuniform float u_radius;\nuniform vec4 u_color;\n\nfloat sdRoundedBox(vec2 p, vec2 b, float r) {\n    vec2 q = abs(p) - b + vec2(r);\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;\n}\n\nvoid main() {\n    vec2 st = gl_TexCoord[0].st * u_size;\n    vec2 halfSize = u_size * 0.5;\n    float distance = sdRoundedBox(st - halfSize, halfSize, u_radius);\n    float smoothedAlpha = 1.0 - smoothstep(-1.0, 1.0, distance);\n    gl_FragColor = vec4(u_color.rgb, u_color.a * smoothedAlpha);\n}";

    private static void initShader() {
        if (programId != -1) {
            return;
        }
        int vert = GL20.glCreateShader(35633);
        GL20.glShaderSource(vert, VERTEX_SHADER);
        GL20.glCompileShader(vert);
        int frag = GL20.glCreateShader(35632);
        GL20.glShaderSource(frag, FRAGMENT_SHADER);
        GL20.glCompileShader(frag);
        programId = GL20.glCreateProgram();
        GL20.glAttachShader(programId, vert);
        GL20.glAttachShader(programId, frag);
        GL20.glLinkProgram(programId);
    }

    public static void drawRound(float x, float y, float width, float height, float radius, Color color) {
        RoundUtil.initShader();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL20.glUseProgram(programId);
        ScaledResolution sr = new ScaledResolution(mc);
        float factor = sr.getScaleFactor();
        GL20.glUniform2f(GL20.glGetUniformLocation(programId, "u_size"), width * factor, height * factor);
        GL20.glUniform1f(GL20.glGetUniformLocation(programId, "u_radius"), radius * factor);
        GL20.glUniform4f(GL20.glGetUniformLocation(programId, "u_color"), (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex2f(x, y);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex2f(x, y + height);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex2f(x + width, y + height);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex2f(x + width, y);
        GL11.glEnd();
        GL20.glUseProgram(0);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
}
