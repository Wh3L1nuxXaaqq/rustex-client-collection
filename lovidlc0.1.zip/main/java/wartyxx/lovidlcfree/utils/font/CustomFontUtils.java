package wartyxx.lovidlcfree.utils.font;

import java.awt.Font;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import wartyxx.lovidlcfree.utils.font.CustomFontRenderer;

public final class CustomFontUtils {
    public static CustomFontRenderer aboba12 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/aboba.ttf"), 12.0f, 0), true, true);
    public static CustomFontRenderer aboba14 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/aboba.ttf"), 14.0f, 0), true, true);
    public static CustomFontRenderer aboba16 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/aboba.ttf"), 16.0f, 0), true, true);
    public static CustomFontRenderer aboba18 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/aboba.ttf"), 18.0f, 0), true, true);
    public static CustomFontRenderer aboba20 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/aboba.ttf"), 20.0f, 0), true, true);
    public static CustomFontRenderer icons12 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/icons.ttf"), 12.0f, 0), true, true);
    public static CustomFontRenderer icons14 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/icons.ttf"), 14.0f, 0), true, true);
    public static CustomFontRenderer icons18 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/icons.ttf"), 18.0f, 0), true, true);
    public static CustomFontRenderer icons32 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/icons.ttf"), 32.0f, 0), true, true);
    public static CustomFontRenderer icons40 = new CustomFontRenderer(CustomFontUtils.getFontFromTTF(new ResourceLocation("lovidlcrecode/fonts/icons.ttf"), 40.0f, 0), true, true);

    public static Font getFontFromTTF(ResourceLocation loc, float fontSize, int fontType) {
        try {
            Font output = Font.createFont(0, Minecraft.getMinecraft().getResourceManager().getResource(loc).getInputStream());
            return output.deriveFont(fontType, fontSize);
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
