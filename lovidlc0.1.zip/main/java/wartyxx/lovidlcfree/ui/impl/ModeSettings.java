package wartyxx.lovidlcfree.ui.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import wartyxx.lovidlcfree.ui.impl.Setting;

public class ModeSettings
extends Setting {
    private String currentMode;
    private final List<String> modes;

    public ModeSettings(String name, String currentMode, List<String> modes) {
        super(name);
        this.modes = new ArrayList<String>(modes);
        this.currentMode = this.modes.contains(currentMode) ? currentMode : (this.modes.isEmpty() ? "" : this.modes.get(0));
    }

    public ModeSettings(String name, String currentMode, String ... modes) {
        this(name, currentMode, Arrays.asList(modes));
    }

    public String getCurrentMode() {
        return this.currentMode;
    }

    public void setCurrentMode(String currentMode) {
        if (this.modes.contains(currentMode)) {
            this.currentMode = currentMode;
        }
    }

    public List<String> getModes() {
        return this.modes;
    }
}
