package wartyxx.lovidlcfree.ui.impl;

import wartyxx.lovidlcfree.ui.impl.Setting;

public class BoolSettings
extends Setting {
    private boolean state;

    public BoolSettings(String name, boolean state) {
        super(name);
        this.state = state;
    }

    public boolean isState() {
        return this.state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public void toggle() {
        this.state = !this.state;
    }
}
