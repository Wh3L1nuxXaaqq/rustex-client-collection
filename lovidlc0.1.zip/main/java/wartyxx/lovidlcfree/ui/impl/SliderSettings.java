package wartyxx.lovidlcfree.ui.impl;

import wartyxx.lovidlcfree.ui.impl.Setting;

public class SliderSettings
extends Setting {
    private float value;
    private final float min;
    private final float max;
    private final float increment;

    public SliderSettings(String name, float value, float min, float max, float increment) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.increment = increment;
    }

    public float getValue() {
        return this.value;
    }

    public void setValue(float value) {
        float precision = 1.0f / this.increment;
        this.value = Math.max(this.min, Math.min(this.max, (float)Math.round(value * precision) / precision));
    }

    public float getMin() {
        return this.min;
    }

    public float getMax() {
        return this.max;
    }
}
