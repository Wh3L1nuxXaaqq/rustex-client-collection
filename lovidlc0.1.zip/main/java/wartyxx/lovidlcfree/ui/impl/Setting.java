package wartyxx.lovidlcfree.ui.impl;

public abstract class Setting {
    private final String name;

    public Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
