package wartyxx.lovidlcfree.ui;

import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import wartyxx.lovidlcfree.LoviDLC;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.BoolSettings;
import wartyxx.lovidlcfree.ui.impl.ModeSettings;
import wartyxx.lovidlcfree.ui.impl.Setting;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;
import wartyxx.lovidlcfree.utils.font.CustomFontUtils;
import wartyxx.lovidlcfree.utils.render.RenderUtil;

public class Screen
extends GuiScreen {
    public static Category selectedCategory = Category.Combat;
    public static Module selectedModule = null;
    private Module bindingModule = null;
    private float guiX = 100.0f;
    private float guiY = 100.0f;
    private final float width = 450.0f;
    private final float height = 280.0f;
    private boolean draggingSlider = false;
    private SliderSettings currentSlider = null;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        boolean active;
        this.guiX = (this.width - this.width) / 2.0f + 100.0f;
        this.guiY = (this.height - this.height) / 2.0f + 50.0f;
        RenderUtil.drawRoundRect(this.guiX, this.guiY, 450.0f, 280.0f, 6.0f, new Color(20, 20, 24, 240));
        RenderUtil.drawRoundRect(this.guiX, this.guiY, 90.0f, 280.0f, 6.0f, new Color(15, 15, 18, 255));
        float titleHeight = CustomFontUtils.aboba18.getHeight();
        CustomFontUtils.aboba18.drawString("LoviDLC Free", this.guiX + 10.0f, this.guiY + 14.0f - titleHeight / 2.0f, new Color(255, 255, 255).getRGB());
        float catY = this.guiY + 40.0f;
        float catHeight = 18.0f;
        for (Category category : Category.values()) {
            int color;
            active = category == selectedCategory;
            int n = color = active ? new Color(90, 130, 255).getRGB() : new Color(140, 140, 145).getRGB();
            if (active) {
                RenderUtil.drawRoundRect(this.guiX + 5.0f, catY, 80.0f, catHeight, 3.0f, new Color(30, 30, 40, 255));
            }
            float textY = catY + catHeight / 2.0f - (float)CustomFontUtils.aboba16.getHeight() / 2.0f;
            CustomFontUtils.aboba16.drawString(category.name(), this.guiX + 12.0f, textY, color);
            catY += 24.0f;
        }
        RenderUtil.drawRoundRect(this.guiX + 95.0f, this.guiY + 10.0f, 165.0f, 260.0f, 4.0f, new Color(25, 25, 30, 255));
        float modY = this.guiY + 18.0f;
        float modHeight = 22.0f;
        for (Module module : LoviDLC.instance.moduleManager.getModulesByCategory(selectedCategory)) {
            int textCol;
            active = module == selectedModule;
            boolean toggled = module.isToggled();
            RenderUtil.drawRoundRect(this.guiX + 100.0f, modY, 155.0f, modHeight, 3.0f, toggled ? new Color(35, 40, 55, 255) : new Color(18, 18, 22, 255));
            int n = textCol = toggled ? new Color(100, 180, 255).getRGB() : new Color(180, 180, 180).getRGB();
            if (active) {
                textCol = new Color(255, 255, 255).getRGB();
            }
            float modTextY = modY + modHeight / 2.0f - (float)CustomFontUtils.aboba16.getHeight() / 2.0f;
            CustomFontUtils.aboba16.drawString(module.getName(), this.guiX + 108.0f, modTextY, textCol);
            String keyName = this.bindingModule == module ? "[...]" : (module.getKey() == 0 ? "[N/A]" : "[" + Keyboard.getKeyName(module.getKey()) + "]");
            float keyWidth = CustomFontUtils.aboba12.getStringWidth(keyName);
            float keyTextY = modY + modHeight / 2.0f - (float)CustomFontUtils.aboba12.getHeight() / 2.0f;
            CustomFontUtils.aboba12.drawString(keyName, this.guiX + 250.0f - keyWidth, keyTextY, new Color(110, 110, 120).getRGB());
            modY += 26.0f;
        }
        RenderUtil.drawRoundRect(this.guiX + 265.0f, this.guiY + 10.0f, 175.0f, 260.0f, 4.0f, new Color(25, 25, 30, 255));
        if (selectedModule != null) {
            CustomFontUtils.aboba16.drawString(selectedModule.getName() + " Settings", this.guiX + 275.0f, this.guiY + 18.0f, new Color(220, 220, 220).getRGB());
            float setY = this.guiY + 38.0f;
            for (Setting setting : selectedModule.getSettings()) {
                if (setting instanceof BoolSettings) {
                    BoolSettings bool = (BoolSettings)setting;
                    float boolToggleHeight = 10.0f;
                    float boolTextY = setY + boolToggleHeight / 2.0f - (float)CustomFontUtils.aboba14.getHeight() / 2.0f + 1.0f;
                    CustomFontUtils.aboba14.drawString(bool.getName(), this.guiX + 275.0f, boolTextY, new Color(170, 170, 170).getRGB());
                    RenderUtil.drawRoundRect(this.guiX + 415.0f, setY + 2.0f, 16.0f, boolToggleHeight, 5.0f, bool.isState() ? new Color(90, 130, 255) : new Color(50, 50, 60));
                    RenderUtil.drawRoundRect(bool.isState() ? this.guiX + 422.0f : this.guiX + 416.0f, setY + 3.0f, 8.0f, 8.0f, 4.0f, new Color(240, 240, 240));
                    setY += 20.0f;
                    continue;
                }
                if (setting instanceof SliderSettings) {
                    SliderSettings slider = (SliderSettings)setting;
                    CustomFontUtils.aboba14.drawString(slider.getName() + ": " + slider.getValue(), this.guiX + 275.0f, setY, new Color(170, 170, 170).getRGB());
                    float sliderWidth = 155.0f;
                    float currentWidth = (slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin()) * sliderWidth;
                    RenderUtil.drawRoundRect(this.guiX + 275.0f, setY + 12.0f, sliderWidth, 6.0f, 2.0f, new Color(40, 40, 50));
                    RenderUtil.drawRoundRect(this.guiX + 275.0f, setY + 12.0f, currentWidth, 6.0f, 2.0f, new Color(90, 130, 255));
                    if (this.draggingSlider && this.currentSlider == slider) {
                        float diff = Math.min(sliderWidth, Math.max(0.0f, (float)mouseX - (this.guiX + 275.0f)));
                        float newValue = slider.getMin() + diff / sliderWidth * (slider.getMax() - slider.getMin());
                        slider.setValue(newValue);
                    }
                    setY += 26.0f;
                    continue;
                }
                if (!(setting instanceof ModeSettings)) continue;
                ModeSettings mode = (ModeSettings)setting;
                CustomFontUtils.aboba14.drawString(mode.getName(), this.guiX + 275.0f, setY, new Color(170, 170, 170).getRGB());
                setY += 14.0f;
                float tileWidth = 48.0f;
                float tileHeight = 16.0f;
                float startX = this.guiX + 275.0f;
                for (int i = 0; i < mode.getModes().size(); ++i) {
                    String modeName = mode.getModes().get(i);
                    boolean isSelected = modeName.equalsIgnoreCase(mode.getCurrentMode());
                    int colIndex = i % 3;
                    int rowIndex = i / 3;
                    float tileX = startX + (float)colIndex * (tileWidth + 4.0f);
                    float currentTileY = setY + (float)rowIndex * (tileHeight + 4.0f);
                    Color tileBg = isSelected ? new Color(90, 130, 255) : new Color(40, 40, 50);
                    int tileTxt = isSelected ? new Color(255, 255, 255).getRGB() : new Color(150, 150, 160).getRGB();
                    RenderUtil.drawRoundRect(tileX, currentTileY, tileWidth, tileHeight, 3.0f, tileBg);
                    float modeTextY = currentTileY + tileHeight / 2.0f - (float)CustomFontUtils.aboba12.getHeight() / 2.0f;
                    CustomFontUtils.aboba12.drawCenteredString(modeName, tileX + tileWidth / 2.0f, modeTextY, tileTxt);
                }
                int rows = (int)Math.ceil((double)mode.getModes().size() / 3.0);
                setY += (float)rows * (tileHeight + 4.0f) + 6.0f;
            }
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.bindingModule != null) {
            if (mouseButton == 0) {
                this.bindingModule.setKey(0);
            }
            this.bindingModule = null;
            return;
        }
        float catY = this.guiY + 40.0f;
        for (Category category : Category.values()) {
            if (mouseButton == 0 && (float)mouseX >= this.guiX + 5.0f && (float)mouseX <= this.guiX + 85.0f && (float)mouseY >= catY && (float)mouseY <= catY + 18.0f) {
                selectedCategory = category;
                selectedModule = null;
                return;
            }
            catY += 24.0f;
        }
        float modY = this.guiY + 18.0f;
        for (Module module : LoviDLC.instance.moduleManager.getModulesByCategory(selectedCategory)) {
            if ((float)mouseX >= this.guiX + 100.0f && (float)mouseX <= this.guiX + 255.0f && (float)mouseY >= modY && (float)mouseY <= modY + 22.0f) {
                if (mouseButton == 0) {
                    module.toggle();
                } else if (mouseButton == 1) {
                    selectedModule = module;
                } else if (mouseButton == 2) {
                    this.bindingModule = module;
                }
                return;
            }
            modY += 26.0f;
        }
        if (selectedModule != null) {
            float setY = this.guiY + 38.0f;
            for (Setting setting : selectedModule.getSettings()) {
                if (setting instanceof BoolSettings) {
                    if (mouseButton == 0 && (float)mouseX >= this.guiX + 415.0f && (float)mouseX <= this.guiX + 431.0f && (float)mouseY >= setY + 2.0f && (float)mouseY <= setY + 12.0f) {
                        ((BoolSettings)setting).toggle();
                    }
                    setY += 20.0f;
                    continue;
                }
                if (setting instanceof SliderSettings) {
                    SliderSettings slider = (SliderSettings)setting;
                    if (mouseButton == 0 && (float)mouseX >= this.guiX + 275.0f && (float)mouseX <= this.guiX + 430.0f && (float)mouseY >= setY + 12.0f && (float)mouseY <= setY + 18.0f) {
                        this.draggingSlider = true;
                        this.currentSlider = slider;
                    }
                    setY += 26.0f;
                    continue;
                }
                if (!(setting instanceof ModeSettings)) continue;
                ModeSettings mode = (ModeSettings)setting;
                setY += 14.0f;
                float tileWidth = 48.0f;
                float tileHeight = 16.0f;
                float startX = this.guiX + 275.0f;
                for (int i = 0; i < mode.getModes().size(); ++i) {
                    int colIndex = i % 3;
                    int rowIndex = i / 3;
                    float tileX = startX + (float)colIndex * (tileWidth + 4.0f);
                    float currentTileY = setY + (float)rowIndex * (tileHeight + 4.0f);
                    if (mouseButton != 0 || !((float)mouseX >= tileX) || !((float)mouseX <= tileX + tileWidth) || !((float)mouseY >= currentTileY) || !((float)mouseY <= currentTileY + tileHeight)) continue;
                    mode.setCurrentMode(mode.getModes().get(i));
                    break;
                }
                int rows = (int)Math.ceil((double)mode.getModes().size() / 3.0);
                setY += (float)rows * (tileHeight + 4.0f) + 6.0f;
            }
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (this.bindingModule != null) {
            if (keyCode == 1 || keyCode == 211) {
                this.bindingModule.setKey(0);
            } else {
                this.bindingModule.setKey(keyCode);
            }
            this.bindingModule = null;
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        if (state == 0) {
            this.draggingSlider = false;
            this.currentSlider = null;
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
