package wartyxx.lovidlcfree.managers;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class FriendManager {
    private static final List<String> friends = new CopyOnWriteArrayList<String>();

    public static void addFriend(String name) {
        if (name != null && !FriendManager.isFriend(name)) {
            friends.add(name);
        }
    }

    public static void removeFriend(String name) {
        if (name != null) {
            friends.removeIf(friend -> friend.equalsIgnoreCase(name));
        }
    }

    public static boolean isFriend(String name) {
        if (name == null) {
            return false;
        }
        for (String friend : friends) {
            if (!friend.equalsIgnoreCase(name)) continue;
            return true;
        }
        return false;
    }

    public static List<String> getFriends() {
        return friends;
    }

    public static void clear() {
        friends.clear();
    }
}
