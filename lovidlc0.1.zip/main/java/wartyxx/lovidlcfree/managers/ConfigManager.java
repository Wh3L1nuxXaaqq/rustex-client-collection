package wartyxx.lovidlcfree.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Desktop;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import wartyxx.lovidlcfree.LoviDLC;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.BoolSettings;
import wartyxx.lovidlcfree.ui.impl.ModeSettings;
import wartyxx.lovidlcfree.ui.impl.Setting;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;

public class ConfigManager {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final File configDir = new File(ConfigManager.mc.mcDataDir, "LoviDLCFreeMcDayz/configs");
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static String prefix = ".cfg";

    public static void init() {
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
    }

    public static boolean saveConfig(String name) {
        try {
            File file = new File(configDir, name + ".lovi");
            JsonObject root = new JsonObject();
            for (Module module : LoviDLC.instance.moduleManager.getModules()) {
                JsonObject moduleData = new JsonObject();
                moduleData.addProperty("toggled", module.isToggled());
                moduleData.addProperty("key", module.getKey());
                JsonObject settings = new JsonObject();
                for (Setting setting : module.getSettings()) {
                    if (setting instanceof BoolSettings) {
                        settings.addProperty(setting.getName(), ((BoolSettings)setting).isState());
                        continue;
                    }
                    if (setting instanceof SliderSettings) {
                        settings.addProperty(setting.getName(), Float.valueOf(((SliderSettings)setting).getValue()));
                        continue;
                    }
                    if (!(setting instanceof ModeSettings)) continue;
                    settings.addProperty(setting.getName(), ((ModeSettings)setting).getCurrentMode());
                }
                moduleData.add("settings", settings);
                root.add(module.getName(), moduleData);
            }
            try (FileWriter writer = new FileWriter(file);){
                gson.toJson((JsonElement)root, (Appendable)writer);
            }
            ConfigManager.sendMessage("\u00a7aConfig \u00a7f" + name + " \u00a7asaved!");
            return true;
        }
        catch (Exception e) {
            ConfigManager.sendMessage("\u00a7cFailed to save config!");
            return false;
        }
    }

    public static boolean loadConfig(String name) {
        try {
            File file = new File(configDir, name + ".lovi");
            if (!file.exists()) {
                ConfigManager.sendMessage("\u00a7cConfig \u00a7f" + name + " \u00a7cnot found!");
                return false;
            }
            FileReader reader = new FileReader(file);
            JsonObject root = new JsonParser().parse(reader).getAsJsonObject();
            reader.close();
            for (Module module : LoviDLC.instance.moduleManager.getModules()) {
                if (!root.has(module.getName())) continue;
                JsonObject moduleData = root.getAsJsonObject(module.getName());
                if (moduleData.has("toggled")) {
                    boolean toggled = moduleData.get("toggled").getAsBoolean();
                    if (module.isToggled() != toggled) {
                        module.toggle();
                    }
                }
                if (moduleData.has("key")) {
                    module.setKey(moduleData.get("key").getAsInt());
                }
                if (!moduleData.has("settings")) continue;
                JsonObject settings = moduleData.getAsJsonObject("settings");
                for (Setting setting : module.getSettings()) {
                    if (!settings.has(setting.getName())) continue;
                    if (setting instanceof BoolSettings) {
                        ((BoolSettings)setting).setState(settings.get(setting.getName()).getAsBoolean());
                        continue;
                    }
                    if (setting instanceof SliderSettings) {
                        ((SliderSettings)setting).setValue(settings.get(setting.getName()).getAsFloat());
                        continue;
                    }
                    if (!(setting instanceof ModeSettings)) continue;
                    ((ModeSettings)setting).setCurrentMode(settings.get(setting.getName()).getAsString());
                }
            }
            ConfigManager.sendMessage("\u00a7aConfig \u00a7f" + name + " \u00a7aloaded!");
            return true;
        }
        catch (Exception e) {
            ConfigManager.sendMessage("\u00a7cFailed to load config!");
            return false;
        }
    }

    public static boolean deleteConfig(String name) {
        try {
            File file = new File(configDir, name + ".lovi");
            if (file.exists()) {
                file.delete();
                ConfigManager.sendMessage("\u00a7aConfig \u00a7f" + name + " \u00a7adeleted!");
                return true;
            }
            ConfigManager.sendMessage("\u00a7cConfig \u00a7f" + name + " \u00a7cnot found!");
            return false;
        }
        catch (Exception e) {
            ConfigManager.sendMessage("\u00a7cFailed to delete config!");
            return false;
        }
    }

    public static List<String> getConfigs() {
        ArrayList<String> configs = new ArrayList<String>();
        File[] files = configDir.listFiles((dir, name) -> name.endsWith(".lovi"));
        if (files != null) {
            for (File file : files) {
                configs.add(file.getName().replace(".lovi", ""));
            }
        }
        return configs;
    }

    public static void listConfigs() {
        List<String> configs = ConfigManager.getConfigs();
        if (configs.isEmpty()) {
            ConfigManager.sendMessage("\u00a7cNo configs found!");
        } else {
            ConfigManager.sendMessage("\u00a7aAvailable configs:");
            for (String cfg : configs) {
                ConfigManager.sendMessage(" \u00a78- \u00a7f" + cfg);
            }
        }
    }

    public static void openDir() {
        try {
            Desktop.getDesktop().open(configDir);
            ConfigManager.sendMessage("\u00a7aOpened config directory!");
        }
        catch (Exception e) {
            ConfigManager.sendMessage("\u00a7cFailed to open directory!");
        }
    }

    public static void executeCommand(String message) {
        String action;
        if (!message.startsWith(prefix)) {
            return;
        }
        String[] parts = message.substring(prefix.length()).trim().split(" ");
        if (parts.length < 1 || parts[0].isEmpty()) {
            ConfigManager.sendMessage("\u00a7cUsage: " + prefix + " <help|save|load|list|rem|dir> [name]");
            return;
        }
        switch (action = parts[0].toLowerCase()) {
            case "help": {
                ConfigManager.sendMessage("\u00a7aCommands:");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " help \u00a77- Show this help");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " save <name> \u00a77- Save config");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " load <name> \u00a77- Load config");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " list \u00a77- List all configs");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " rem <name> \u00a77- Delete config");
                ConfigManager.sendMessage(" \u00a78- " + prefix + " dir \u00a77- Open config folder");
                break;
            }
            case "save": {
                if (parts.length > 1) {
                    ConfigManager.saveConfig(parts[1]);
                    break;
                }
                ConfigManager.sendMessage("\u00a7cUsage: " + prefix + " save <name>");
                break;
            }
            case "load": {
                if (parts.length > 1) {
                    ConfigManager.loadConfig(parts[1]);
                    break;
                }
                ConfigManager.sendMessage("\u00a7cUsage: " + prefix + " load <name>");
                break;
            }
            case "list": {
                ConfigManager.listConfigs();
                break;
            }
            case "rem": {
                if (parts.length > 1) {
                    ConfigManager.deleteConfig(parts[1]);
                    break;
                }
                ConfigManager.sendMessage("\u00a7cUsage: " + prefix + " rem <name>");
                break;
            }
            case "dir": {
                ConfigManager.openDir();
                break;
            }
            default: {
                ConfigManager.sendMessage("\u00a7cUnknown command! Use " + prefix + " help");
            }
        }
    }

    private static void sendMessage(String text) {
        if (ConfigManager.mc.player != null) {
            ConfigManager.mc.player.addChatMessage(new TextComponentString("\u00a78[\u00a7bLoviDLC\u00a78] \u00a77" + text));
        }
    }

    public static String getPrefix() {
        return prefix;
    }

    public static void setPrefix(String prefix) {
        ConfigManager.prefix = prefix;
    }

    public static File getConfigDir() {
        return configDir;
    }
}
