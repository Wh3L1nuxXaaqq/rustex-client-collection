package wartyxx.lovidlcfree.modules;

import java.util.ArrayList;
import java.util.List;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.modules.impl.combat.Aimbot;
import wartyxx.lovidlcfree.modules.impl.combat.HitEffect;
import wartyxx.lovidlcfree.modules.impl.combat.HitSound;
import wartyxx.lovidlcfree.modules.impl.combat.HoldClicker;
import wartyxx.lovidlcfree.modules.impl.display.ClickGui;
import wartyxx.lovidlcfree.modules.impl.display.ModuleList;
import wartyxx.lovidlcfree.modules.impl.display.Watermark;
import wartyxx.lovidlcfree.modules.impl.misc.FakePlayer;
import wartyxx.lovidlcfree.modules.impl.misc.MCF;
import wartyxx.lovidlcfree.modules.impl.misc.NoZoomSmooth;
import wartyxx.lovidlcfree.modules.impl.misc.Optimizer;
import wartyxx.lovidlcfree.modules.impl.movement.NoJumpDelay;
import wartyxx.lovidlcfree.modules.impl.movement.NoPush;
import wartyxx.lovidlcfree.modules.impl.movement.Sprint;
import wartyxx.lovidlcfree.modules.impl.visuals.Arrows;
import wartyxx.lovidlcfree.modules.impl.visuals.Bright;
import wartyxx.lovidlcfree.modules.impl.visuals.ESP;
import wartyxx.lovidlcfree.modules.impl.visuals.ItemESP;
import wartyxx.lovidlcfree.modules.impl.visuals.NameTags;
import wartyxx.lovidlcfree.modules.impl.visuals.Tracers;
import wartyxx.lovidlcfree.modules.impl.visuals.ViewModel;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();

    public ModuleManager() {
        this.modules.add(new Aimbot());
        this.modules.add(new HoldClicker());
        this.modules.add(new HitSound());
        this.modules.add(new HitEffect());
        this.modules.add(new Sprint());
        this.modules.add(new NoJumpDelay());
        this.modules.add(new NoPush());
        this.modules.add(new Bright());
        this.modules.add(new ESP());
        this.modules.add(new Arrows());
        this.modules.add(new ItemESP());
        this.modules.add(new NameTags());
        this.modules.add(new ViewModel());
        this.modules.add(new Tracers());
        this.modules.add(new FakePlayer());
        this.modules.add(new MCF());
        this.modules.add(new NoZoomSmooth());
        this.modules.add(new Optimizer());
        this.modules.add(new Watermark());
        this.modules.add(new ModuleList());
        this.modules.add(new ClickGui());
    }

    public void onRender2D() {
        for (Module module : this.modules) {
            if (!module.isToggled()) continue;
            module.onRender2D();
        }
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        ArrayList<Module> list = new ArrayList<Module>();
        for (Module m : this.modules) {
            if (m.getCategory() != category) continue;
            list.add(m);
        }
        return list;
    }
}
