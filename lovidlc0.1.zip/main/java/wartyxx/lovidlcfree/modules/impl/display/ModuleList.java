package wartyxx.lovidlcfree.modules.impl.display;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import wartyxx.lovidlcfree.LoviDLC;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.modules.impl.display.Watermark;
import wartyxx.lovidlcfree.utils.font.CustomFontUtils;
import wartyxx.lovidlcfree.utils.render.RenderUtil;

public class ModuleList
extends Module {
    public ModuleList() {
        super("ModuleList", Category.Display, 0, true);
    }

    @Override
    public void onRender2D() {
        if (!this.isToggled() || ModuleList.mc.player == null) {
            return;
        }
        ScaledResolution sr = new ScaledResolution(mc);
        float x = 8.0f;
        ArrayList<Module> modules = new ArrayList<Module>();
        for (Module m2 : LoviDLC.instance.moduleManager.getModules()) {
            if (!m2.isToggled() || m2 instanceof ModuleList || m2 instanceof Watermark) continue;
            modules.add(m2);
        }
        modules.sort(Comparator.comparingDouble(m -> {
            String bind = m.getKey() == 0 ? "" : "[" + Keyboard.getKeyName(m.getKey()) + "]";
            String fullText = bind.isEmpty() ? m.getName() : bind + " " + m.getName();
            return -CustomFontUtils.aboba18.getStringWidth(fullText);
        }));
        float y = 28.0f;
        float padding = 3.0f;
        for (Module module : modules) {
            String bind = module.getKey() == 0 ? "" : "[" + Keyboard.getKeyName(module.getKey()) + "]";
            String name = module.getName();
            String fullText = bind.isEmpty() ? name : bind + " " + name;
            float textWidth = CustomFontUtils.aboba18.getStringWidth(fullText);
            float rectH = CustomFontUtils.aboba18.getHeight() + 6;
            float rectY = y - 2.0f;
            RenderUtil.drawRoundRect(x, rectY, textWidth + 10.0f, rectH, 4.0f, new Color(15, 15, 17, 230));
            float textY = y + 2.0f;
            if (!bind.isEmpty()) {
                float bindWidth = CustomFontUtils.aboba18.getStringWidth(bind);
                CustomFontUtils.aboba18.drawString(bind, x + 5.0f, textY, new Color(130, 130, 140, 255).getRGB());
                CustomFontUtils.aboba18.drawString(name, x + 5.0f + bindWidth + 2.0f, textY, new Color(200, 200, 205, 255).getRGB());
            } else {
                CustomFontUtils.aboba18.drawString(name, x + 5.0f, textY, new Color(200, 200, 205, 255).getRGB());
            }
            y += rectH + padding;
        }
    }
}
