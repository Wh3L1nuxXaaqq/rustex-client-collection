package wartyxx.lovidlcfree.modules.impl.display;

import java.awt.Color;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.utils.font.CustomFontUtils;
import wartyxx.lovidlcfree.utils.render.RenderUtil;

public class Watermark
extends Module {
    public Watermark() {
        super("Watermark", Category.Display, 0, true);
    }

    @Override
    public void onRender2D() {
        if (!this.isToggled()) {
            return;
        }
        String name = "LoviDLC Free";
        String sep = " \u00bb ";
        String branch = "Release";
        String fps = mc.getDebugFPS() + " fps";
        float wName = CustomFontUtils.aboba16.getStringWidth(name);
        float wSep = CustomFontUtils.aboba16.getStringWidth(sep);
        float wBranch = CustomFontUtils.aboba16.getStringWidth(branch);
        float wFps = CustomFontUtils.aboba16.getStringWidth(fps);
        float totalWidth = wName + wSep + wBranch + wSep + wFps;
        float pad = 7.0f;
        float h = 15.0f;
        float w = totalWidth + pad * 2.0f;
        float x = 6.0f;
        float y = 6.0f;
        Color bg = new Color(15, 15, 17, 240);
        int cMain = new Color(200, 200, 205, 255).getRGB();
        int cSub = new Color(140, 140, 145, 255).getRGB();
        int cSep = new Color(90, 90, 95, 255).getRGB();
        RenderUtil.drawRoundRect(x, y, w, h, 3.5f, bg);
        float textY = y + 6.0f;
        float curX = x + pad;
        CustomFontUtils.aboba16.drawString(name, curX, textY, cMain);
        CustomFontUtils.aboba16.drawString(sep, curX += wName, textY, cSep);
        CustomFontUtils.aboba16.drawString(branch, curX += wSep, textY, cSub);
        CustomFontUtils.aboba16.drawString(sep, curX += wBranch, textY, cSep);
        CustomFontUtils.aboba16.drawString(fps, curX += wSep, textY, cSub);
    }
}
