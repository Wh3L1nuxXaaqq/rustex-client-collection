package wartyxx.lovidlcfree.modules.impl.display;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.Screen;

public class ClickGui
extends Module {
    public ClickGui() {
        super("ClickGui", Category.Display, 54, false);
    }

    @Override
    public void onEnable() {
        if (ClickGui.mc.currentScreen == null) {
            mc.displayGuiScreen(new Screen());
        }
        this.setToggled(false);
    }
}
