package wartyxx.lovidlcfree.modules.impl.misc;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class NoZoomSmooth
extends Module {
    public NoZoomSmooth() {
        super("NoZoomSmooth", Category.Misc, 0, false);
    }

    @Override
    public void onRender2D() {
        if (!this.isToggled() || NoZoomSmooth.mc.gameSettings == null) {
            return;
        }
        NoZoomSmooth.mc.gameSettings.smoothCamera = false;
    }
}
