package wartyxx.lovidlcfree.modules.impl.misc;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class Optimizer
extends Module {
    public Optimizer() {
        super("Optimizer", Category.Misc, 0, false);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (Optimizer.mc.gameSettings != null) {
            Optimizer.mc.gameSettings.ofFastMath = true;
            Optimizer.mc.gameSettings.clouds = 0;
        }
        Optimizer.mc.renderChunksMany = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (Optimizer.mc.gameSettings != null) {
            Optimizer.mc.gameSettings.ofFastMath = false;
            Optimizer.mc.gameSettings.clouds = 1;
        }
        Optimizer.mc.renderChunksMany = false;
    }
}
