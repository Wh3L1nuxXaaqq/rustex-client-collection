package wartyxx.lovidlcfree.modules.impl.misc;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class FakePlayer
extends Module {
    private EntityOtherPlayerMP fakePlayer;

    public FakePlayer() {
        super("FakePlayer", Category.Misc, 0, false);
    }

    @Override
    public void onEnable() {
        if (FakePlayer.mc.player == null || FakePlayer.mc.world == null) {
            return;
        }
        this.fakePlayer = new EntityOtherPlayerMP(FakePlayer.mc.world, new GameProfile(UUID.fromString("c8d003a2-0922-482f-8700-111111111111"), "LoviDLC"));
        this.fakePlayer.setEntityId(-1488);
        this.fakePlayer.copyLocationAndAnglesFrom(FakePlayer.mc.player);
        this.fakePlayer.rotationYawHead = FakePlayer.mc.player.rotationYawHead;
        this.fakePlayer.renderYawOffset = FakePlayer.mc.player.renderYawOffset;
        this.fakePlayer.inventory.copyInventory(FakePlayer.mc.player.inventory);
        FakePlayer.mc.world.addEntityToWorld(-1488, this.fakePlayer);
    }

    @Override
    public void onDisable() {
        if (FakePlayer.mc.world != null && this.fakePlayer != null) {
            FakePlayer.mc.world.removeEntityFromWorld(-1488);
            this.fakePlayer = null;
        }
    }
}
