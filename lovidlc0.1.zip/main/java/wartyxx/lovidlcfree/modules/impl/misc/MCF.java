package wartyxx.lovidlcfree.modules.impl.misc;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Mouse;
import wartyxx.lovidlcfree.managers.FriendManager;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class MCF
extends Module {
    private boolean onFriend = true;

    public MCF() {
        super("MCF", Category.Misc, 0, false);
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled() || MCF.mc.player == null || MCF.mc.world == null) {
            return;
        }
        if (Mouse.isButtonDown(2) && MCF.mc.pointedEntity != null && MCF.mc.pointedEntity instanceof EntityLivingBase && this.onFriend) {
            this.onFriend = false;
            EntityLivingBase target = (EntityLivingBase)MCF.mc.pointedEntity;
            String targetName = TextFormatting.getTextWithoutFormattingCodes(target.getName());
            if (FriendManager.isFriend(targetName)) {
                FriendManager.removeFriend(targetName);
            } else {
                FriendManager.addFriend(targetName);
            }
        }
        if (!Mouse.isButtonDown(2)) {
            this.onFriend = true;
        }
    }
}
