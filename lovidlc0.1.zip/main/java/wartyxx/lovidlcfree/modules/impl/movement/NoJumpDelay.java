package wartyxx.lovidlcfree.modules.impl.movement;

import java.lang.reflect.Field;
import net.minecraft.entity.EntityLivingBase;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class NoJumpDelay
extends Module {
    private static Field jumpTicksField;

    public NoJumpDelay() {
        super("NoJumpDelay", Category.Movement, 0, false);
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled() || NoJumpDelay.mc.player == null) {
            return;
        }
        if (jumpTicksField != null) {
            try {
                jumpTicksField.setInt(NoJumpDelay.mc.player, 0);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static {
        try {
            jumpTicksField = EntityLivingBase.class.getDeclaredField("field_70773_bE");
            jumpTicksField.setAccessible(true);
        }
        catch (Exception e1) {
            try {
                jumpTicksField = EntityLivingBase.class.getDeclaredField("jumpTicks");
                jumpTicksField.setAccessible(true);
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
