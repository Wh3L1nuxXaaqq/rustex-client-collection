package wartyxx.lovidlcfree.modules.impl.movement;

import org.lwjgl.input.Keyboard;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class Sprint
extends Module {
    public Sprint() {
        super("Sprint", Category.Movement, 0, false);
    }

    @Override
    public void onUpdate() {
        if (Sprint.mc.player != null && Sprint.mc.world != null) {
            boolean isMovingForward;
            boolean bl = isMovingForward = Sprint.mc.player.moveForward > 0.0f || Keyboard.isKeyDown(Sprint.mc.gameSettings.keyBindForward.getKeyCode());
            if (isMovingForward && !Sprint.mc.player.isSneaking() && !Sprint.mc.player.isCollidedHorizontally && Sprint.mc.player.getFoodStats().getFoodLevel() > 6) {
                Sprint.mc.player.setSprinting(true);
            }
        }
    }
}
