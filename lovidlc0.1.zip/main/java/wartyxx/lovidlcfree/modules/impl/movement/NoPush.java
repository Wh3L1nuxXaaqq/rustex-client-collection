package wartyxx.lovidlcfree.modules.impl.movement;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class NoPush
extends Module {
    public NoPush() {
        super("NoPush", Category.Movement, 0, false);
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled() || NoPush.mc.player == null) {
            if (NoPush.mc.player != null) {
                NoPush.mc.player.entityCollisionReduction = 0.0f;
            }
            return;
        }
        NoPush.mc.player.entityCollisionReduction = 1.0f;
    }

    @Override
    public void onDisable() {
        if (NoPush.mc.player != null) {
            NoPush.mc.player.entityCollisionReduction = 0.0f;
        }
        super.onDisable();
    }
}
