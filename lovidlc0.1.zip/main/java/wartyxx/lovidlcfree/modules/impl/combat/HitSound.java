package wartyxx.lovidlcfree.modules.impl.combat;

import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import net.minecraft.client.Minecraft;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.ModeSettings;

public class HitSound
extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private final ModeSettings sound = new ModeSettings("Sound", "Bell", "Bonk", "Bell", "Bubble", "Crime", "Rust", "Hit", "UwU");

    public HitSound() {
        super("HitSound", Category.Combat, 0, false);
        this.addSettings(this.sound);
    }

    public void onTitleReceived(String text) {
        if (!this.isToggled() || HitSound.mc.player == null || HitSound.mc.world == null) {
            return;
        }
        if (text.contains("\u0412 \u0442\u0435\u043b\u043e!") || text.contains("\u0412 \u0433\u043e\u043b\u043e\u0432\u0443!")) {
            this.playSound();
        }
    }

    private void playSound() {
        try {
            String fileName = this.sound.getCurrentMode().toLowerCase() + ".wav";
            String path = "/assets/minecraft/lovidlcrecode/sounds/" + fileName;
            InputStream is = this.getClass().getResourceAsStream(path);
            if (is == null) {
                return;
            }
            BufferedInputStream bufferedIn = new BufferedInputStream(is);
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(bufferedIn);
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
