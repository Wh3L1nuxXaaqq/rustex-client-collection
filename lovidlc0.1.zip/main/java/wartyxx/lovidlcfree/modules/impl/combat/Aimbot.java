package wartyxx.lovidlcfree.modules.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.BoolSettings;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;

public class Aimbot
extends Module {
    private final SliderSettings fov;
    private final SliderSettings predict;
    private final BoolSettings wallCheck;
    private final BoolSettings renderFov;
    private final BoolSettings antiBot;
    private EntityLivingBase currentTarget;
    private float serverYaw;
    private float serverPitch;
    private float yaw;
    private float pitch;
    private Vec3d targetPos;
    private final Random random = new Random();
    private long lastRandomTime;
    private float randomYawOffset;
    private float randomPitchOffset;
    private long randomSeed;

    public Aimbot() {
        super("DayzAim", Category.Combat, 0, false);
        this.fov = new SliderSettings("FOV", 100.0f, 10.0f, 360.0f, 1.0f);
        this.predict = new SliderSettings("Predict", 5.0f, 0.0f, 10.0f, 0.1f);
        this.wallCheck = new BoolSettings("Wall Check", false);
        this.renderFov = new BoolSettings("Render FOV", true);
        this.antiBot = new BoolSettings("Anti Bot", true);
        this.addSettings(this.fov, this.predict, this.wallCheck, this.renderFov, this.antiBot);
    }

    @Override
    public void onDisable() {
        this.currentTarget = null;
        this.targetPos = null;
        super.onDisable();
    }

    @Override
    public void onUpdate() {
        EntityLivingBase target;
        if (!this.isToggled() || Aimbot.mc.player == null || Aimbot.mc.world == null) {
            return;
        }
        this.currentTarget = target = this.getTarget();
        if (target != null) {
            float[] rotations = this.getRotations(target);
            this.serverYaw = rotations[0];
            this.serverPitch = rotations[1];
            this.yaw = rotations[0];
            this.pitch = rotations[1];
            Aimbot.mc.player.rotationYaw = rotations[0];
            Aimbot.mc.player.rotationPitch = rotations[1];
        }
    }

    private EntityLivingBase getTarget() {
        ArrayList<EntityLivingBase> targets = new ArrayList<EntityLivingBase>();
        for (Entity entity : Aimbot.mc.world.loadedEntityList) {
            EntityLivingBase living;
            if (!(entity instanceof EntityPlayer) || (living = (EntityLivingBase)entity) == Aimbot.mc.player || living.getHealth() <= 0.0f || !living.isEntityAlive() || !this.isInFov(living) || this.wallCheck.isState() && !Aimbot.mc.player.canEntityBeSeen(living) || this.antiBot.isState() && this.isBot(living)) continue;
            targets.add(living);
        }
        if (!targets.isEmpty()) {
            targets.sort(Comparator.comparingDouble(Aimbot.mc.player::getDistanceToEntity));
            EntityLivingBase target = (EntityLivingBase)targets.get(0);
            this.calculateTargetPos(target);
            return target;
        }
        this.targetPos = null;
        return null;
    }

    private boolean isBot(EntityLivingBase entity) {
        if (mc.getConnection() == null) {
            return true;
        }
        EntityPlayer player = (EntityPlayer)entity;
        NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(player.getUniqueID());
        return info == null;
    }

    private void calculateTargetPos(EntityLivingBase target) {
        float predictValue = this.predict.getValue();
        Vec3d targetVec = target.getPositionEyes(1.0f);
        Vec3d targetMotion = new Vec3d(target.posX - target.lastTickPosX, target.posY - target.lastTickPosY, target.posZ - target.lastTickPosZ);
        double posX = targetVec.xCoord + targetMotion.xCoord * (double)predictValue;
        double posY = targetVec.yCoord + targetMotion.yCoord * (double)predictValue;
        double posZ = targetVec.zCoord + targetMotion.zCoord * (double)predictValue;
        long currentTime = System.currentTimeMillis();
        double distance = Aimbot.mc.player.getDistanceToEntity(target);
        this.randomSeed = currentTime;
        double amplitude = Math.min(1.0, Math.max(0.1, distance * 0.35)) * 0.08;
        double time = (double)currentTime * 0.0019;
        double time2 = (double)currentTime * 0.0031;
        double time3 = (double)currentTime * 7.3E-4;
        double sin1 = Math.sin(time) * 0.6;
        double sin2 = Math.sin(time2 * 1.5 + 1.8) * 0.25;
        double cos1 = Math.cos(time3 * 2.8 + 0.4) * 0.15;
        double randomX = (sin1 + sin2 + cos1) * amplitude;
        double cos2 = Math.cos(time * 1.2 + 0.7) * 0.6;
        double cos3 = Math.cos(time2 * 1.4 + 2.9) * 0.25;
        double sin3 = Math.sin(time3 * 2.5 + 1.3) * 0.15;
        double randomZ = (cos2 + cos3 + sin3) * amplitude;
        double yAmplitude = Math.max(0.015, 0.07 / (1.0 + distance * 0.4));
        double sin4 = Math.sin(time * 2.1 + 0.3) * 0.5;
        double cos4 = Math.cos(time2 * 1.1 + 2.2) * 0.5;
        double randomY = (sin4 + cos4) * yAmplitude;
        this.targetPos = new Vec3d(posX + randomX, posY + randomY, posZ + randomZ);
    }

    private boolean isInFov(EntityLivingBase target) {
        float fovValue = this.fov.getValue() / 2.0f;
        double angle = ((double)(Aimbot.mc.player.rotationYaw - this.getYawToEntity(target)) % 360.0 + 540.0) % 360.0 - 180.0;
        return angle >= (double)(-fovValue) && angle <= (double)fovValue;
    }

    private float getYawToEntity(Entity entity) {
        double x = entity.posX - Aimbot.mc.player.posX;
        double z = entity.posZ - Aimbot.mc.player.posZ;
        return (float)(-Math.toDegrees(Math.atan2(x, z)));
    }

    private float[] getRotations(EntityLivingBase target) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastRandomTime > 50L) {
            double distance = Aimbot.mc.player.getDistanceToEntity(target);
            float randomStrength = (float)(0.16 / (1.0 + distance * 0.3));
            this.randomYawOffset = (this.random.nextFloat() - 0.5f) * 0.18f;
            this.randomPitchOffset = (this.random.nextFloat() - 0.5f) * randomStrength;
            this.lastRandomTime = currentTime;
        }
        Vec3d eyesPos = Aimbot.mc.player.getPositionEyes(1.0f);
        double diffX = this.targetPos.xCoord - eyesPos.xCoord;
        double diffY = this.targetPos.yCoord - eyesPos.yCoord;
        double diffZ = this.targetPos.zCoord - eyesPos.zCoord;
        double diffXZ = Math.max(0.05, Math.sqrt(diffX * diffX + diffZ * diffZ));
        float yaw = (float)(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0) + this.randomYawOffset;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ))) + this.randomPitchOffset;
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90.0f, 90.0f)};
    }

    @Override
    public void onRender2D() {
        if (!this.isToggled() || Aimbot.mc.player == null || Aimbot.mc.world == null) {
            return;
        }
        if (this.renderFov.isState()) {
            ScaledResolution resolution = new ScaledResolution(mc);
            double radius = (double)(this.fov.getValue() * (float)resolution.getScaledHeight()) / 2.0 / 100.0 / 2.0;
            int centerX = resolution.getScaledWidth() / 2;
            int centerY = resolution.getScaledHeight() / 2;
            this.drawFOVCircle(centerX, centerY, (float)radius);
        }
    }

    private void drawFOVCircle(float x, float y, float radius) {
        boolean blend = GL11.glIsEnabled(3042);
        boolean lineSmooth = GL11.glIsEnabled(2848);
        boolean texture2D = GL11.glIsEnabled(3553);
        if (!blend) {
            GL11.glEnable(3042);
        }
        if (!lineSmooth) {
            GL11.glEnable(2848);
        }
        if (texture2D) {
            GL11.glDisable(3553);
        }
        GL11.glBlendFunc(770, 771);
        GL11.glLineWidth(2.0f);
        if (this.currentTarget != null) {
            GL11.glColor4f(1.0f, 0.0f, 0.0f, 0.8f);
        } else {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
        }
        GL11.glBegin(3);
        for (int i = 0; i <= 360; ++i) {
            double angle = Math.toRadians(i);
            GL11.glVertex2d((double)x + Math.sin(angle) * (double)radius, (double)y + Math.cos(angle) * (double)radius);
        }
        GL11.glEnd();
        if (texture2D) {
            GL11.glEnable(3553);
        }
        if (!lineSmooth) {
            GL11.glDisable(2848);
        }
        if (!blend) {
            GL11.glDisable(3042);
        }
    }

    public SliderSettings getFov() {
        return this.fov;
    }

    public SliderSettings getPredict() {
        return this.predict;
    }

    public BoolSettings getWallCheck() {
        return this.wallCheck;
    }

    public BoolSettings getRenderFov() {
        return this.renderFov;
    }

    public BoolSettings getAntiBot() {
        return this.antiBot;
    }

    public EntityLivingBase getCurrentTarget() {
        return this.currentTarget;
    }

    public float getServerYaw() {
        return this.serverYaw;
    }

    public float getServerPitch() {
        return this.serverPitch;
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }
}
