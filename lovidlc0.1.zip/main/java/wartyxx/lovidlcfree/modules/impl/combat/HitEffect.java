package wartyxx.lovidlcfree.modules.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import wartyxx.lovidlcfree.LoviDLC;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.modules.impl.combat.Aimbot;

public class HitEffect
extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public HitEffect() {
        super("HitEffect", Category.Combat, 0, false);
    }

    public void onTitleReceived(String text) {
        EntityLivingBase target;
        if (!this.isToggled() || HitEffect.mc.player == null || HitEffect.mc.world == null) {
            return;
        }
        if ((text.contains("\u0412 \u0442\u0435\u043b\u043e!") || text.contains("\u0412 \u0433\u043e\u043b\u043e\u0432\u0443!")) && (target = this.getTarget()) != null) {
            HitEffect.mc.world.addWeatherEffect(new EntityLightningBolt(HitEffect.mc.world, target.posX, target.posY, target.posZ, true));
        }
    }

    private EntityLivingBase getTarget() {
        if (LoviDLC.getInstance() != null && LoviDLC.getInstance().getModuleManager() != null) {
            for (Module m : LoviDLC.getInstance().getModuleManager().getModules()) {
                if (!(m instanceof Aimbot) || !m.isToggled()) continue;
                return ((Aimbot)m).getCurrentTarget();
            }
        }
        return null;
    }
}
