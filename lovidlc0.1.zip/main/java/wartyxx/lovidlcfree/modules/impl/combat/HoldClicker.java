package wartyxx.lovidlcfree.modules.impl.combat;

import java.lang.reflect.Method;
import java.util.Random;
import net.minecraft.client.Minecraft;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;

public class HoldClicker
extends Module {
    private final SliderSettings minCps = new SliderSettings("Min CPS", 8.0f, 1.0f, 20.0f, 1.0f);
    private final SliderSettings maxCps = new SliderSettings("Max CPS", 12.0f, 1.0f, 20.0f, 1.0f);
    private final Random random = new Random();
    private long lastClickTime;
    private long nextClickDelay;
    private Method clickMouse;

    public HoldClicker() {
        super("HoldClicker", Category.Combat, 0, false);
        try {
            this.clickMouse = Minecraft.class.getDeclaredMethod("clickMouse", new Class[0]);
            this.clickMouse.setAccessible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        this.addSettings(this.minCps, this.maxCps);
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled() || HoldClicker.mc.player == null || HoldClicker.mc.world == null) {
            return;
        }
        if (HoldClicker.mc.currentScreen != null) {
            return;
        }
        if (HoldClicker.mc.gameSettings.keyBindAttack.isKeyDown()) {
            long currentTime = System.currentTimeMillis();
            if (this.lastClickTime == 0L) {
                this.lastClickTime = currentTime;
                this.nextClickDelay = this.getNextDelay();
                return;
            }
            if (currentTime - this.lastClickTime >= this.nextClickDelay) {
                try {
                    this.clickMouse.invoke((Object)mc, new Object[0]);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                this.lastClickTime = currentTime;
                this.nextClickDelay = this.getNextDelay();
            }
        } else {
            this.lastClickTime = 0L;
            this.nextClickDelay = 0L;
        }
    }

    private long getNextDelay() {
        float max;
        float min = this.minCps.getValue();
        if (min > (max = this.maxCps.getValue())) {
            float temp = min;
            min = max;
            max = temp;
        }
        float cps = min + (max - min) * this.random.nextFloat();
        return (long)(1000.0f / cps);
    }

    public SliderSettings getMinCps() {
        return this.minCps;
    }

    public SliderSettings getMaxCps() {
        return this.maxCps;
    }
}
