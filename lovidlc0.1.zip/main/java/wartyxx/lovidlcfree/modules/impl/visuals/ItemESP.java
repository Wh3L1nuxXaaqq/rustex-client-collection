package wartyxx.lovidlcfree.modules.impl.visuals;

import java.awt.Color;
import java.text.DecimalFormat;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StringUtils;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class ItemESP
extends Module {
    private final DecimalFormat df = new DecimalFormat("#.#");

    public ItemESP() {
        super("ItemESP", Category.Visuals, 0, false);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onRender3D() {
        if (!this.isToggled() || ItemESP.mc.world == null || ItemESP.mc.player == null) {
            return;
        }
        float partialTicks = mc.getRenderPartialTicks();
        GlStateManager.pushMatrix();
        try {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
            GlStateManager.enableTexture2D();
            for (Object obj : ItemESP.mc.world.loadedEntityList) {
                ItemStack stack;
                if (!(obj instanceof EntityItem)) continue;
                EntityItem item = (EntityItem)obj;
                if (item.isDead || ItemESP.mc.player.getDistanceToEntity(item) > 50.0f || (stack = item.getEntityItem()) == null) continue;
                double x = item.lastTickPosX + (item.posX - item.lastTickPosX) * (double)partialTicks - ItemESP.mc.getRenderManager().viewerPosX;
                double y = item.lastTickPosY + (item.posY - item.lastTickPosY) * (double)partialTicks - ItemESP.mc.getRenderManager().viewerPosY;
                double z = item.lastTickPosZ + (item.posZ - item.lastTickPosZ) * (double)partialTicks - ItemESP.mc.getRenderManager().viewerPosZ;
                GlStateManager.pushMatrix();
                GlStateManager.translate(x, y + (double)item.height / 2.0, z);
                GlStateManager.rotate(-ItemESP.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate((float)(ItemESP.mc.gameSettings.thirdPersonView == 2 ? -1 : 1) * ItemESP.mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
                float scale = 0.02f;
                GlStateManager.scale(-scale, -scale, scale);
                this.drawOutlineBox(-10.0f, -10.0f, 10.0f, 10.0f, 1.5f, new Color(255, 255, 255, 200).getRGB());
                this.drawRect(-10.0f, -10.0f, 10.0f, 10.0f, new Color(0, 0, 0, 40).getRGB());
                GlStateManager.popMatrix();
                this.drawItemName(x, y + (double)item.height / 2.0, z, item, stack);
            }
        }
        finally {
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.enableLighting();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }

    private void drawOutlineBox(float left, float top, float right, float bottom, float lineWidth, int color) {
        GL11.glLineWidth(lineWidth);
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(r, g, b, a);
        GL11.glBegin(2);
        GL11.glVertex2f(left, top);
        GL11.glVertex2f(right, top);
        GL11.glVertex2f(right, bottom);
        GL11.glVertex2f(left, bottom);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private void drawRect(float left, float top, float right, float bottom, int color) {
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(r, g, b, a);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(7, DefaultVertexFormats.POSITION);
        buffer.pos(left, bottom, 0.0).endVertex();
        buffer.pos(right, bottom, 0.0).endVertex();
        buffer.pos(right, top, 0.0).endVertex();
        buffer.pos(left, top, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private void drawItemName(double x, double y, double z, EntityItem item, ItemStack stack) {
        String name = stack.getDisplayName();
        if (name == null || name.isEmpty()) {
            name = stack.getItem().getItemStackDisplayName(stack);
        }
        name = StringUtils.stripControlCodes(name);
        float distance = ItemESP.mc.player.getDistanceToEntity(item);
        String displayText = name + " (" + this.df.format(distance) + "m)";
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.rotate(-ItemESP.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate((float)(ItemESP.mc.gameSettings.thirdPersonView == 2 ? -1 : 1) * ItemESP.mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
        float scale = 0.02f;
        GlStateManager.scale(-scale, -scale, scale);
        String cleanText = StringUtils.stripControlCodes(displayText);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        ItemESP.mc.fontRendererObj.drawStringWithShadow(cleanText, (float)(-ItemESP.mc.fontRendererObj.getStringWidth(cleanText)) / 2.0f, -8.0f, -1);
        GlStateManager.popMatrix();
    }
}
