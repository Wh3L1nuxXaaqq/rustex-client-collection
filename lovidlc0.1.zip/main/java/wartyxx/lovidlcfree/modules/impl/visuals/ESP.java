package wartyxx.lovidlcfree.modules.impl.visuals;

import java.awt.Color;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.managers.FriendManager;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class ESP
extends Module {
    public ESP() {
        super("ESP", Category.Visuals, 0, false);
    }

    private boolean isValid(EntityPlayer player) {
        if (player == ESP.mc.player) {
            return false;
        }
        if (player.getEntityId() == ESP.mc.player.getEntityId()) {
            return false;
        }
        if (player.isDead) {
            return false;
        }
        return !(player.getHealth() <= 0.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onRender3D() {
        if (!this.isToggled() || ESP.mc.world == null || ESP.mc.player == null || mc.getRenderManager() == null) {
            return;
        }
        boolean blend = GL11.glIsEnabled(3042);
        boolean texture = GL11.glIsEnabled(3553);
        boolean depth = GL11.glIsEnabled(2929);
        boolean lighting = GL11.glIsEnabled(2896);
        GlStateManager.pushMatrix();
        try {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.disableLighting();
            GlStateManager.disableTexture2D();
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
            float partialTicks = mc.getRenderPartialTicks();
            RenderManager renderManager = mc.getRenderManager();
            for (Entity entity : ESP.mc.world.loadedEntityList) {
                EntityPlayer player;
                if (!(entity instanceof EntityPlayer) || !this.isValid(player = (EntityPlayer)entity)) continue;
                String name = TextFormatting.getTextWithoutFormattingCodes(player.getName());
                Color color = FriendManager.isFriend(name) ? Color.GREEN : Color.WHITE;
                double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)partialTicks - renderManager.viewerPosX;
                double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)partialTicks - renderManager.viewerPosY;
                double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)partialTicks - renderManager.viewerPosZ;
                float width = player.width / 1.2f * 2.0f;
                float height = player.height + 0.2f;
                GlStateManager.pushMatrix();
                GlStateManager.translate(x, y + (double)(height / 2.0f), z);
                GlStateManager.rotate(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
                this.drawBox(-width / 2.0f, -height / 2.0f, width, height, color);
                GlStateManager.popMatrix();
            }
        }
        finally {
            GlStateManager.depthMask(true);
            if (depth) {
                GlStateManager.enableDepth();
            } else {
                GlStateManager.disableDepth();
            }
            if (texture) {
                GlStateManager.enableTexture2D();
            } else {
                GlStateManager.disableTexture2D();
            }
            if (blend) {
                GlStateManager.enableBlend();
            } else {
                GlStateManager.disableBlend();
            }
            if (lighting) {
                GlStateManager.enableLighting();
            } else {
                GlStateManager.disableLighting();
            }
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }

    private void drawBox(float x, float y, float w, float h, Color color) {
        float r = (float)color.getRed() / 255.0f;
        float g = (float)color.getGreen() / 255.0f;
        float b = (float)color.getBlue() / 255.0f;
        float thick = 0.02f;
        this.drawRect(x, y, w, thick, r, g, b, 1.0f);
        this.drawRect(x, y + h - thick, w, thick, r, g, b, 1.0f);
        this.drawRect(x, y, thick, h, r, g, b, 1.0f);
        this.drawRect(x + w - thick, y, thick, h, r, g, b, 1.0f);
    }

    private void drawRect(float x, float y, float w, float h, float r, float g, float b, float a) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        buffer.pos(x, y, 0.0).color(r, g, b, a).endVertex();
        buffer.pos(x, y + h, 0.0).color(r, g, b, a).endVertex();
        buffer.pos(x + w, y + h, 0.0).color(r, g, b, a).endVertex();
        buffer.pos(x + w, y, 0.0).color(r, g, b, a).endVertex();
        tessellator.draw();
    }
}
