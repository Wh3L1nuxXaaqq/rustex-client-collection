package wartyxx.lovidlcfree.modules.impl.visuals;

import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.managers.FriendManager;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;

public class Arrows
extends Module {
    private final SliderSettings radius = new SliderSettings("Radius", 50.0f, 20.0f, 100.0f, 1.0f);
    private final SliderSettings size = new SliderSettings("Size", 32.0f, 8.0f, 32.0f, 1.0f);
    private static final ResourceLocation ARROW_TEX = new ResourceLocation("minecraft", "lovidlcrecode/textures/arr.png");

    public Arrows() {
        super("Arrows", Category.Visuals, 0, false);
        this.addSettings(this.radius, this.size);
    }

    @Override
    public void onRender2D() {
        if (!this.isToggled() || Arrows.mc.player == null || Arrows.mc.world == null) {
            return;
        }
        ScaledResolution sr = new ScaledResolution(mc);
        float centerX = (float)sr.getScaledWidth() / 2.0f;
        float centerY = (float)sr.getScaledHeight() / 2.0f;
        boolean blend = GL11.glIsEnabled(3042);
        boolean tex = GL11.glIsEnabled(3553);
        boolean alpha = GL11.glIsEnabled(3008);
        for (EntityPlayer entity : Arrows.mc.world.playerEntities) {
            if (entity == null || entity == Arrows.mc.player || entity.isDead) continue;
            String name = TextFormatting.getTextWithoutFormattingCodes(entity.getName());
            boolean isFriend = FriendManager.isFriend(name);
            Color color = isFriend ? new Color(0, 255, 0, 255) : new Color(255, 255, 255, 255);
            double dx = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)mc.getRenderPartialTicks() - Arrows.mc.player.posX;
            double dz = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)mc.getRenderPartialTicks() - Arrows.mc.player.posZ;
            double yawTarget = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double diffYaw = MathHelper.wrapDegrees(yawTarget - (double)Arrows.mc.player.rotationYaw);
            double angleRad = Math.toRadians(diffYaw);
            float x = centerX + (float)(Math.sin(angleRad) * (double)this.radius.getValue());
            float y = centerY - (float)(Math.cos(angleRad) * (double)this.radius.getValue());
            float rotation = (float)Math.toDegrees(angleRad);
            GlStateManager.pushMatrix();
            GlStateManager.translate(x, y, 0.0f);
            GlStateManager.rotate(rotation, 0.0f, 0.0f, 1.0f);
            mc.getTextureManager().bindTexture(ARROW_TEX);
            GlStateManager.enableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            float half = this.size.getValue() / 2.0f;
            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();
            buffer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            float r = (float)color.getRed() / 255.0f;
            float g = (float)color.getGreen() / 255.0f;
            float b = (float)color.getBlue() / 255.0f;
            float a = (float)color.getAlpha() / 255.0f;
            buffer.pos(-half, -half, 0.0).tex(0.0, 0.0).color(r, g, b, a).endVertex();
            buffer.pos(-half, half, 0.0).tex(0.0, 1.0).color(r, g, b, a).endVertex();
            buffer.pos(half, half, 0.0).tex(1.0, 1.0).color(r, g, b, a).endVertex();
            buffer.pos(half, -half, 0.0).tex(1.0, 0.0).color(r, g, b, a).endVertex();
            tessellator.draw();
            if (!blend) {
                GlStateManager.disableBlend();
            }
            if (tex) {
                GlStateManager.enableTexture2D();
            } else {
                GlStateManager.disableTexture2D();
            }
            if (alpha) {
                GlStateManager.enableAlpha();
            } else {
                GlStateManager.disableAlpha();
            }
            GlStateManager.popMatrix();
        }
    }

    public SliderSettings getRadius() {
        return this.radius;
    }

    public SliderSettings getSize() {
        return this.size;
    }
}
