package wartyxx.lovidlcfree.modules.impl.visuals;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.BoolSettings;
import wartyxx.lovidlcfree.utils.font.CustomFontUtils;

public class NameTags
extends Module {
    private final BoolSettings holdItem = new BoolSettings("Hold Item", true);

    public NameTags() {
        super("NameTags", Category.Visuals, 0, false);
        this.addSettings(this.holdItem);
    }

    public boolean isHoldItem() {
        return this.holdItem.isState();
    }

    private boolean isValid(EntityPlayer player) {
        if (player == NameTags.mc.player) {
            return false;
        }
        if (player.getEntityId() == NameTags.mc.player.getEntityId()) {
            return false;
        }
        if (player.isDead) {
            return false;
        }
        if (player.getHealth() <= 0.0f) {
            return false;
        }
        return !player.isInvisible();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onRender3D() {
        if (!this.isToggled() || NameTags.mc.world == null || NameTags.mc.player == null || mc.getRenderManager() == null) {
            return;
        }
        boolean blend = GL11.glIsEnabled(3042);
        boolean texture = GL11.glIsEnabled(3553);
        boolean depth = GL11.glIsEnabled(2929);
        boolean lighting = GL11.glIsEnabled(2896);
        GlStateManager.pushMatrix();
        try {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
            float partialTicks = mc.getRenderPartialTicks();
            RenderManager renderManager = mc.getRenderManager();
            for (Entity entity : NameTags.mc.world.loadedEntityList) {
                String itemName;
                ItemStack held;
                EntityPlayer player;
                if (!(entity instanceof EntityPlayer) || !this.isValid(player = (EntityPlayer)entity)) continue;
                String name = TextFormatting.getTextWithoutFormattingCodes(player.getName());
                double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)partialTicks - renderManager.viewerPosX;
                double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)partialTicks - renderManager.viewerPosY;
                double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)partialTicks - renderManager.viewerPosZ;
                float distance = NameTags.mc.player.getDistanceToEntity(player);
                float scale = Math.min(Math.max(1.2f * (distance * 0.15f), 1.25f), 6.0f) * 0.015f;
                GlStateManager.pushMatrix();
                GlStateManager.translate((float)x, (float)y + player.height + 0.6f, (float)z);
                GlStateManager.rotate(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
                GlStateManager.scale(-scale, -scale, scale);
                GlStateManager.enableTexture2D();
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                CustomFontUtils.aboba18.drawStringWithShadow(name, -CustomFontUtils.aboba18.getStringWidth(name) / 2, -6.0f, -1);
                GlStateManager.popMatrix();
                if (!this.holdItem.isState() || (held = player.getHeldItemMainhand()) == null || held.func_190926_b() || (itemName = held.getDisplayName()) == null || itemName.isEmpty()) continue;
                GlStateManager.pushMatrix();
                GlStateManager.translate((float)x, (float)y - 0.15f, (float)z);
                GlStateManager.rotate(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
                GlStateManager.scale(-scale, -scale, scale);
                GlStateManager.enableTexture2D();
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                CustomFontUtils.aboba18.drawStringWithShadow(itemName, -CustomFontUtils.aboba18.getStringWidth(itemName) / 2, 0.0f, -1);
                GlStateManager.popMatrix();
            }
        }
        finally {
            GlStateManager.depthMask(true);
            if (depth) {
                GlStateManager.enableDepth();
            } else {
                GlStateManager.disableDepth();
            }
            if (texture) {
                GlStateManager.enableTexture2D();
            } else {
                GlStateManager.disableTexture2D();
            }
            if (blend) {
                GlStateManager.enableBlend();
            } else {
                GlStateManager.disableBlend();
            }
            if (lighting) {
                GlStateManager.enableLighting();
            } else {
                GlStateManager.disableLighting();
            }
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }
}
