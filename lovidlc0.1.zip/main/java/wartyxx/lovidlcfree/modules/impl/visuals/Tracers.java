package wartyxx.lovidlcfree.modules.impl.visuals;

import java.util.ArrayList;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import wartyxx.lovidlcfree.managers.FriendManager;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class Tracers
extends Module {
    public Tracers() {
        super("Tracers", Category.Visuals, 0, false);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onRender3D() {
        if (!this.isToggled() || Tracers.mc.world == null || Tracers.mc.player == null) {
            return;
        }
        float partialTicks = mc.getRenderPartialTicks();
        double rx = Tracers.mc.getRenderManager().viewerPosX;
        double ry = Tracers.mc.getRenderManager().viewerPosY;
        double rz = Tracers.mc.getRenderManager().viewerPosZ;
        ArrayList<EntityPlayer> players = new ArrayList<EntityPlayer>();
        for (EntityPlayer player : Tracers.mc.world.playerEntities) {
            if (player == null || player == Tracers.mc.player || player.isDead) continue;
            players.add(player);
        }
        if (players.isEmpty()) {
            return;
        }
        Vec3d eyeVector = new Vec3d(0.0, 0.0, 1.0).rotatePitch((float)(-Math.toRadians(Tracers.mc.player.rotationPitch))).rotateYaw((float)(-Math.toRadians(Tracers.mc.player.rotationYaw)));
        double startX = eyeVector.xCoord;
        double startY = (double)Tracers.mc.player.getEyeHeight() + eyeVector.yCoord;
        double startZ = eyeVector.zCoord;
        GlStateManager.pushMatrix();
        try {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.disableDepth();
            GlStateManager.disableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.depthMask(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            GL11.glLineWidth(1.5f);
            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();
            buffer.begin(1, DefaultVertexFormats.POSITION_COLOR);
            for (EntityPlayer player : players) {
                double targetX = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)partialTicks - rx;
                double targetY = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)partialTicks + (double)player.height / 2.0 - ry;
                double targetZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)partialTicks - rz;
                String name = TextFormatting.getTextWithoutFormattingCodes(player.getName());
                boolean isFriend = FriendManager.isFriend(name);
                float red = isFriend ? 0.0f : 1.0f;
                float green = isFriend ? 1.0f : 0.0f;
                float blue = 0.0f;
                float alpha = 0.8f;
                buffer.pos(startX, startY, startZ).color(red, green, blue, alpha).endVertex();
                buffer.pos(targetX, targetY, targetZ).color(red, green, blue, alpha).endVertex();
            }
            tessellator.draw();
        }
        finally {
            GL11.glDisable(2848);
            GL11.glLineWidth(1.0f);
            GlStateManager.depthMask(true);
            GlStateManager.enableLighting();
            GlStateManager.enableTexture2D();
            GlStateManager.enableDepth();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            RenderHelper.enableStandardItemLighting();
            GlStateManager.popMatrix();
        }
    }
}
