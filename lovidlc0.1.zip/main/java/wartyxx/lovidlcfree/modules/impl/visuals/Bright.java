package wartyxx.lovidlcfree.modules.impl.visuals;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;

public class Bright
extends Module {
    private float oldGamma;

    public Bright() {
        super("Bright", Category.Visuals, 0, false);
    }

    @Override
    public void onEnable() {
        if (Bright.mc.gameSettings != null) {
            this.oldGamma = Bright.mc.gameSettings.gammaSetting;
            Bright.mc.gameSettings.gammaSetting = 1000.0f;
        }
    }

    @Override
    public void onDisable() {
        if (Bright.mc.gameSettings != null) {
            Bright.mc.gameSettings.gammaSetting = this.oldGamma;
        }
    }
}
