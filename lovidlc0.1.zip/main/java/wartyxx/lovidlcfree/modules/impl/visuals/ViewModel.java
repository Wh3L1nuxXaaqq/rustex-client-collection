package wartyxx.lovidlcfree.modules.impl.visuals;

import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.modules.Module;
import wartyxx.lovidlcfree.ui.impl.SliderSettings;

public class ViewModel
extends Module {
    private SliderSettings posX = new SliderSettings("Pos X", 0.0f, -2.0f, 2.0f, 0.05f);
    private SliderSettings posY = new SliderSettings("Pos Y", 0.0f, -2.0f, 2.0f, 0.05f);
    private SliderSettings posZ = new SliderSettings("Pos Z", 0.0f, -2.0f, 2.0f, 0.05f);

    public ViewModel() {
        super("ViewModel", Category.Visuals, 0, false);
        this.addSettings(this.posX, this.posY, this.posZ);
    }

    public SliderSettings getPosX() {
        return this.posX;
    }

    public SliderSettings getPosY() {
        return this.posY;
    }

    public SliderSettings getPosZ() {
        return this.posZ;
    }
}
