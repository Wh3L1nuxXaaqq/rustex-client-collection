package wartyxx.lovidlcfree.modules;

public enum Category {
    Combat,
    Movement,
    Visuals,
    Misc,
    Display;

}
