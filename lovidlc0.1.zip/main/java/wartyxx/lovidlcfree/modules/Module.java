package wartyxx.lovidlcfree.modules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import wartyxx.lovidlcfree.modules.Category;
import wartyxx.lovidlcfree.ui.impl.Setting;

public class Module {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    private final String name;
    private final Category category;
    private int key;
    private boolean toggled;
    private final List<Setting> settings = new ArrayList<Setting>();

    public Module(String name, Category category, int key) {
        this(name, category, key, false);
    }

    public Module(String name, Category category, int key, boolean toggled) {
        this.name = name;
        this.category = category;
        this.key = key;
        this.toggled = toggled;
        if (toggled) {
            this.onEnable();
        }
    }

    public void addSettings(Setting ... settings) {
        this.settings.addAll(Arrays.asList(settings));
    }

    public List<Setting> getSettings() {
        return this.settings;
    }

    public void toggle() {
        boolean bl = this.toggled = !this.toggled;
        if (this.toggled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onUpdate() {
    }

    public void onRender2D() {
    }

    public void onRender3D() {
    }

    public String getName() {
        return this.name;
    }

    public Category getCategory() {
        return this.category;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public void setToggled(boolean toggled) {
        if (this.toggled != toggled) {
            this.toggle();
        }
    }
}
