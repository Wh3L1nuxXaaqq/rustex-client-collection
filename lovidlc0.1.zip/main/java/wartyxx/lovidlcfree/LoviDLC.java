package wartyxx.lovidlcfree;

import wartyxx.lovidlcfree.managers.ConfigManager;
import wartyxx.lovidlcfree.modules.ModuleManager;
import wartyxx.lovidlcfree.utils.discord.DiscordRPC;

public class LoviDLC {
    public static final String NAME = "LoviDLC Free";
    public static final String VERSION = "0.1";
    public static LoviDLC instance = new LoviDLC();
    public ModuleManager moduleManager;

    public void init() {
        ConfigManager.init();
        this.moduleManager = new ModuleManager();
        DiscordRPC.start();
    }

    public void shutdown() {
        DiscordRPC.stop();
    }

    public static LoviDLC getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }
}
