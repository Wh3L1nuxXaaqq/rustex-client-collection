package com.Blood.Ware.manager;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.combat.AimAssist;
import com.Blood.Ware.module.combat.AimBot;
import com.Blood.Ware.module.combat.AntiBot;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.module.hud.HUD;
import com.Blood.Ware.module.hud.Keystrokes;
import com.Blood.Ware.module.hud.Notifications;
import com.Blood.Ware.module.hud.Watermark;
import com.Blood.Ware.module.misc.FakeCreative;
import com.Blood.Ware.module.misc.FogColor;
import com.Blood.Ware.module.misc.InvViewer;
import com.Blood.Ware.module.misc.MiddleClick;
import com.Blood.Ware.module.movement.GuiWalk;
import com.Blood.Ware.module.movement.NoPush;
import com.Blood.Ware.module.movement.Sprint;
import com.Blood.Ware.module.render.BlockEsp;
import com.Blood.Ware.module.render.ChinaHat;
import com.Blood.Ware.module.render.ESP;
import com.Blood.Ware.module.render.FakePlayer;
import com.Blood.Ware.module.render.Freecam;
import com.Blood.Ware.module.render.FullBright;
import com.Blood.Ware.module.render.HouseEsp;
import com.Blood.Ware.module.render.ItemESP;
import com.Blood.Ware.module.render.NameTags;
import com.Blood.Ware.module.render.PenisESP;
import com.Blood.Ware.module.render.Tracers;
import com.Blood.Ware.module.render.ViewModel;
import com.Blood.Ware.module.render.WallHack;
import com.Blood.Ware.module.render.WallHackPlayer;
import com.google.common.reflect.ClassPath;
import java.util.ArrayList;

public class ModuleManager {
    public static ArrayList<Module> modules;

    public ModuleManager() {
        modules = new ArrayList();
        modules.clear();
        modules.add(new BlockEsp());
        modules.add(new AimBot());
        modules.add(new FakeCreative());
        modules.add(new ClickGUI());
        modules.add(new ESP());
        modules.add(new HouseEsp());
        modules.add(new PenisESP());
        modules.add(new ItemESP());
        modules.add(new Tracers());
        modules.add(new GuiWalk());
        modules.add(new FogColor());
        modules.add(new Freecam());
        modules.add(new FullBright());
        modules.add(new InvViewer());
        modules.add(new NameTags());
        modules.add(new WallHackPlayer());
        modules.add(new Keystrokes());
        modules.add(new HUD());
        modules.add(new ViewModel());
        modules.add(new Notifications());
        modules.add(new FakePlayer());
        modules.add(new MiddleClick());
        modules.add(new ChinaHat());
        modules.add(new Sprint());
        modules.add(new NoPush());
        modules.add(new AimAssist());
        modules.add(new AntiBot());
        modules.add(new WallHack());
        modules.add(new Watermark());
        for (Module module : modules) {
        }
    }

    public static ArrayList<Class<?>> getClasses(String packageName) {
        ArrayList classes = new ArrayList();
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            for (ClassPath.ClassInfo info : ClassPath.from(loader).getAllClasses()) {
                if (!info.getName().startsWith(packageName)) continue;
                classes.add(info.load());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return classes;
    }

    public Module getModule(String name) {
        for (Module m : modules) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    public ArrayList<Module> getModuleList() {
        return modules;
    }

    public ArrayList<Module> getModulesInCategory(Category c) {
        ArrayList<Module> mods = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getCategory() != c) continue;
            mods.add(m);
        }
        return mods;
    }

    public ArrayList<Module> getModules(Category category) {
        ArrayList<Module> modules2 = new ArrayList<Module>();
        for (Module module : modules) {
            if (module.getCategory() != category) continue;
            modules2.add(module);
        }
        return modules2;
    }
}
