package com.Blood.Ware.module.misc;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.world.GameType;

public class FakeCreative
extends Module {
    public GameType oldType;

    public FakeCreative() {
        super("FakeCreative", Category.OUTHER);
    }

    @Override
    public void onEnable() {
        if (this.nullCheck()) {
            return;
        }
        this.oldType = FakeCreative.mc.field_71442_b.func_178889_l();
        if (FakeCreative.mc.field_71439_g != null) {
            FakeCreative.mc.field_71442_b.func_78746_a(GameType.CREATIVE);
        } else {
            this.toggle();
        }
    }

    private boolean nullCheck() {
        return false;
    }

    @Override
    public void onDisable() {
        if (this.nullCheck()) {
            return;
        }
        if (FakeCreative.mc.field_71439_g != null) {
            if (this.oldType == GameType.SURVIVAL) {
                FakeCreative.mc.field_71442_b.func_78746_a(GameType.SURVIVAL);
            }
            if (this.oldType == GameType.SPECTATOR) {
                FakeCreative.mc.field_71442_b.func_78746_a(GameType.SPECTATOR);
            }
            if (this.oldType == GameType.ADVENTURE) {
                FakeCreative.mc.field_71442_b.func_78746_a(GameType.ADVENTURE);
            }
            if (this.oldType == GameType.CREATIVE) {
                FakeCreative.mc.field_71442_b.func_78746_a(GameType.CREATIVE);
            }
        }
    }
}
