package com.Blood.Ware.module.misc;

import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.notifications.notifications;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

public class MiddleClick
extends Module {
    public MiddleClick() {
        super("MCF", Category.OUTHER);
    }

    @SubscribeEvent
    public void onMiddleClick(InputEvent.MouseInputEvent event) {
        if (MiddleClick.mc.field_71439_g == null || MiddleClick.mc.field_71441_e == null) {
            return;
        }
        if (Mouse.getEventButtonState() && Mouse.getEventButton() == 2 && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
            this.clickFriend();
        }
    }

    private void clickFriend() {
        String name = MiddleClick.mc.field_71476_x.field_72308_g.func_70005_c_();
        if (FriendManager.isFriend(name)) {
            FriendManager.FRIENDS.remove(name);
            notifications.add(TextFormatting.RED + name, "Remove from Friend list", Type.OK);
        } else {
            FriendManager.FRIENDS.add(name);
            notifications.add(TextFormatting.GREEN + name, "add in Friends list", Type.OK);
        }
    }
}
