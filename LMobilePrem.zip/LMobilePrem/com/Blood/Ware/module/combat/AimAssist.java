package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AimAssist
extends Module {
    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Range", this, 3.0, 1.0, 10.0, true));
    }

    @SubscribeEvent
    public void onUpdate(RenderWorldLastEvent e) {
        double range = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        EntityPlayer target = AimAssist.mc.field_71441_e.field_73010_i.stream().filter(entityPlayer -> entityPlayer != AimAssist.mc.field_71439_g).min(Comparator.comparing(entityPlayer -> Float.valueOf(entityPlayer.func_70032_d((Entity)AimAssist.mc.field_71439_g)))).filter(entityPlayer -> (double)entityPlayer.func_70032_d((Entity)AimAssist.mc.field_71439_g) <= range).orElse(null);
        if (target != null && AimAssist.mc.field_71439_g.func_70685_l((Entity)target) && !FriendManager.isFriend(this.getName())) {
            AimAssist.mc.field_71439_g.field_70177_z = this.rotations(target)[0];
            AimAssist.mc.field_71439_g.field_70125_A = this.rotations(target)[1];
        }
    }

    public float[] rotations(EntityPlayer entity) {
        double x = entity.field_70165_t - AimAssist.mc.field_71439_g.field_70165_t;
        double y = entity.field_70163_u - (AimAssist.mc.field_71439_g.field_70163_u + (double)AimAssist.mc.field_71439_g.func_70047_e()) + 1.5;
        double z = entity.field_70161_v - AimAssist.mc.field_71439_g.field_70161_v;
        double u = MathHelper.func_76133_a((double)(x * x + z * z));
        float u2 = (float)(MathHelper.func_181159_b((double)z, (double)x) * 57.29577951308232 - 90.0);
        float u3 = (float)(-MathHelper.func_181159_b((double)y, (double)u) * 57.29577951308232);
        return new float[]{u2, u3};
    }
}
