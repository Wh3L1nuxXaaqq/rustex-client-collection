package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.FovUtils;
import com.Blood.Ware.utils.TimerUtils;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class AimBot
extends Module {
    public float[] facing;
    public String[] gunlist = new String[]{""};
    public TimerUtils timer = new TimerUtils();
    public TimerUtils timer2 = new TimerUtils();

    public AimBot() {
        super("AimBot(Prem)", Category.COMBAT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Range", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Predict", this, 6.1, 0.0, 7.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("VPredict", this, 300.0, 0.0, 300.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("BAim", this, 0.0, 0.0, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("FOV", this, 48.0, 1.0, 360.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Wall", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Smooth", this, 5.0, 1.0, 20.0, true));
    }

    public float[] getPredict(Entity e) {
        float VPredict = (float)BloodWare.instance.settingsManager.getSettingByName(this, "VPredict").getValDouble();
        float Predict = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Predict").getValDouble();
        float Range = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        float smooth = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Smooth").getValDouble();
        double n = mc.func_184121_ak();
        double d = e.field_70142_S + (e.field_70165_t - e.field_70142_S) * n;
        double d2 = e.field_70137_T + (e.field_70163_u - e.field_70137_T) * n;
        double d3 = e.field_70136_U + (e.field_70161_v - e.field_70136_U) * n;
        double xDiff = e.field_70165_t - e.field_70169_q;
        double zDiff = e.field_70161_v - e.field_70166_s;
        float predict = Predict + this.getDistance(e) / Range;
        double WillPosX = d + xDiff * (double)predict;
        double WillPosZ = d3 + zDiff * (double)predict;
        double WillPosY = VPredict != 0.0f ? d2 + (double)(this.getDistance(e) / VPredict) : d2;
        return new float[]{(float)WillPosX, (float)WillPosZ, (float)WillPosY};
    }

    public static float[] faceHead(float posX, float posY, float posZ, float p_706252, float p_706253, boolean miss) {
        double offset = BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("AimBot(Prem)"), "BAim").getValDouble();
        double var4 = (double)posX - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        double var5 = (double)posZ - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double var6 = (double)posY + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        if (offset == -1.0) {
            var6 = (double)posY + 1.86 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
        } else {
            float distance = AimBot.getDistance(new BlockPos((double)posX, (double)posY, (double)posZ));
            if ((double)distance <= offset) {
                var6 = (double)posY + 1.6 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e());
            }
        }
        double var7 = MathHelper.func_76133_a((double)(var4 * var4 + var5 * var5));
        float var8 = (float)(Math.atan2(var5, var4) * 180.0 / Math.PI) - 90.0f;
        float var9 = (float)(-(Math.atan2(var6 - 0.15, var7) * 180.0 / Math.PI));
        float f = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        float pitch = AimBot.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70125_A, var9, p_706253);
        float yaw = AimBot.updateRotation(Minecraft.func_71410_x().field_71439_g.field_70177_z, var8, p_706252);
        yaw -= yaw % gcd;
        pitch -= pitch % gcd;
        return new float[]{yaw, pitch};
    }

    public static float updateRotation(float current, float intended, float speed) {
        float f = MathHelper.func_76142_g((float)(intended - current));
        if (f > speed) {
            f = speed;
        }
        if (f < -speed) {
            f = -speed;
        }
        return current + f;
    }

    private boolean lambdagetTarget(Entity entity) {
        return this.attackCheck(entity);
    }

    public Entity getTarget() throws Throwable {
        if (AimBot.mc.field_71439_g != null && !AimBot.mc.field_71439_g.field_70128_L) {
            List list = AimBot.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity != AimBot.mc.field_71439_g).filter(entity -> !entity.field_70128_L).filter(this::lambdagetTarget).sorted(Comparator.comparing(FovUtils::getDistanceFromMouse)).collect(Collectors.toList());
            return list.size() > 0 ? (Entity)list.get(0) : null;
        }
        return null;
    }

    public boolean attackCheck(Entity target) {
        boolean Walls = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        if (Walls) {
            return target instanceof EntityPlayer && !FriendManager.FRIENDS.contains(target.func_70005_c_());
        }
        return !Walls && AimBot.mc.field_71439_g.func_70685_l(target) && target instanceof EntityPlayer && !FriendManager.FRIENDS.contains(target.func_70005_c_());
    }

    private float lerp(float start, float end, float percent) {
        return start + percent * (end - start);
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) throws Throwable {
        boolean Wall = BloodWare.instance.settingsManager.getSettingByName(this, "Wall").getValBoolean();
        float Range = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Range").getValDouble();
        EntityPlayer target = (EntityPlayer)this.getTarget();
        if (target != null && !FriendManager.FRIENDS.contains(target.func_70005_c_()) && FovUtils.isInAttackFOV((Entity)target, (int)BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble())) {
            this.facing = this.getPredict((Entity)target);
            this.facing = AimBot.faceHead(this.facing[0], this.facing[2], this.facing[1], 360.0f, 360.0f, false);
            if (!BloodWare.instance.settingsManager.getSettingByName(this, "Smooth").getValBoolean() && this.timer2.isDelay(1L)) {
                float lerpedYaw = this.lerp(AimBot.mc.field_71439_g.field_70177_z, this.facing[0], 0.7f);
                float lerpedPitch = this.lerp(AimBot.mc.field_71439_g.field_70125_A, this.facing[1], 0.7f);
                AimBot.mc.field_71439_g.field_70177_z = lerpedYaw;
                AimBot.mc.field_71439_g.field_70125_A = lerpedPitch;
                this.timer2.setLastMS();
            }
        }
    }

    private float getDistance(Entity entityIn) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - entityIn.field_70165_t);
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - entityIn.field_70161_v);
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    private static float getDistance(BlockPos blockPos) {
        float f = (float)(AimBot.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n());
        float f2 = (float)(AimBot.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p());
        return MathHelper.func_76129_c((float)(f * f + f2 * f2));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        double p = BloodWare.instance.settingsManager.getSettingByName(this, "FOV").getValDouble() / (double)Minecraft.func_71410_x().field_71474_y.field_74334_X;
        ScaledResolution scaledResolution = event.getResolution();
        AimBot.drawCircle228(scaledResolution.func_78326_a() / 2, scaledResolution.func_78328_b() / 2, (int)(p * 485.0), Color.RED.getRGB(), 360, 0.5f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawCircle228(float n, float n2, float n3, int n4, int n5, float width) {
        float n6 = (float)(n4 >> 24 & 0xFF) / 255.0f;
        float n7 = (float)(n4 >> 16 & 0xFF) / 255.0f;
        float n8 = (float)(n4 >> 8 & 0xFF) / 255.0f;
        float n9 = (float)(n4 & 0xFF) / 255.0f;
        boolean glIsEnabled = GL11.glIsEnabled((int)3042);
        boolean glIsEnabled2 = GL11.glIsEnabled((int)2848);
        boolean glIsEnabled3 = GL11.glIsEnabled((int)3553);
        if (!glIsEnabled) {
            GL11.glEnable((int)3042);
        }
        if (!glIsEnabled2) {
            GL11.glEnable((int)2848);
        }
        if (glIsEnabled3) {
            GL11.glDisable((int)3553);
        }
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)n7, (float)n8, (float)n9, (float)n6);
        GL11.glLineWidth((float)width);
        GL11.glBegin((int)3);
        for (int i = 0; i <= n5; ++i) {
            GL11.glVertex2d((double)((double)n + Math.sin((double)i * Math.PI / 180.0) * (double)n3), (double)((double)n2 + Math.cos((double)i * Math.PI / 180.0) * (double)n3));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        if (glIsEnabled3) {
            GL11.glEnable((int)3553);
        }
        if (!glIsEnabled2) {
            GL11.glDisable((int)2848);
        }
        if (!glIsEnabled) {
            GL11.glDisable((int)3042);
        }
    }
}
