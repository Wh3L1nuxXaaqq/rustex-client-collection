package com.Blood.Ware.module.combat;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AntiBot
extends Module {
    public static List<String> BOTS = new ArrayList<String>();
    public static boolean toggle;

    public AntiBot() {
        super("AntiBot", Category.COMBAT);
        BloodWare.instance.settingsManager.rSetting(new Setting("Remove", this, true));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        toggle = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        toggle = false;
        BOTS.clear();
    }

    public static boolean isBot(String nick) {
        if (toggle) {
            for (String friend : BOTS) {
                if (!friend.equalsIgnoreCase(nick)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public static boolean isBlockMaterial(BlockPos blockPos, Block block) {
        return AntiBot.getBlock(blockPos) == Blocks.field_150350_a;
    }

    public static Block getBlock(BlockPos pos) {
        return AntiBot.getState(pos).func_177230_c();
    }

    public static IBlockState getState(BlockPos pos) {
        return AntiBot.mc.field_71441_e.func_180495_p(pos);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        boolean Remove = BloodWare.instance.settingsManager.getSettingByName(this, "Remove").getValBoolean();
        for (Entity e : AntiBot.mc.field_71441_e.field_72996_f) {
            if (e == AntiBot.mc.field_71439_g || e.field_70173_aa >= 5 || !(e instanceof EntityOtherPlayerMP) || !(AntiBot.mc.field_71439_g.func_70068_e(e) <= 15.0)) continue;
            if (AntiBot.isBlockMaterial(new BlockPos(e).func_177977_b(), Blocks.field_150350_a)) {
                BOTS.add(e.func_70005_c_());
                if (Remove) {
                    AntiBot.mc.field_71441_e.func_72900_e(e);
                }
            }
            if (!e.func_82150_aj()) continue;
            BOTS.add(e.func_70005_c_());
            if (!Remove) continue;
            AntiBot.mc.field_71441_e.func_72900_e(e);
        }
    }
}
