package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public class FakePlayer
extends Module {
    EntityOtherPlayerMP fakePlayer;

    public FakePlayer() {
        super("FakePlayer", Category.RENDER);
    }

    @Override
    public void onEnable() {
        this.fakePlayer = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, FakePlayer.mc.field_71439_g.func_146103_bH());
        this.fakePlayer.func_145769_d(-1882);
        this.fakePlayer.func_82149_j((Entity)FakePlayer.mc.field_71439_g);
        this.fakePlayer.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
        FakePlayer.mc.field_71441_e.func_73027_a(this.fakePlayer.func_145782_y(), (Entity)this.fakePlayer);
    }

    @Override
    public void onDisable() {
        FakePlayer.mc.field_71441_e.func_73028_b(this.fakePlayer.func_145782_y());
    }
}
