package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ViewModel
extends Module {
    public ViewModel() {
        super("ViewModel", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("Position X", this, 0.0, -10.0, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Position Y", this, -0.23, -10.0, 10.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Position Z", this, -0.45, -10.0, 10.0, false));
    }

    @SubscribeEvent
    public void onRender(RenderSpecificHandEvent e) {
        double x = BloodWare.instance.settingsManager.getSettingByName(this, "Position X").getValDouble();
        double y = BloodWare.instance.settingsManager.getSettingByName(this, "Position Y").getValDouble();
        double z = BloodWare.instance.settingsManager.getSettingByName(this, "Position Z").getValDouble();
        GL11.glTranslated((double)x, (double)y, (double)z);
    }
}
