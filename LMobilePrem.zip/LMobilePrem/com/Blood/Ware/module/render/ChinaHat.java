package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

public class ChinaHat
extends Module {
    public static List<String> Modes = new ArrayList<String>();

    public ChinaHat() {
        super("LooseHat", Category.RENDER);
        Modes.add("V2");
        Modes.add("V1");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "V2", (ArrayList<String>)((ArrayList)Modes)));
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent renderWorldLastEvent) {
        String valString = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        if (Objects.equals(valString, "V2")) {
            double n;
            double d = n = ChinaHat.mc.field_71439_g.func_70093_af() ? -0.1 : 0.12;
            if (ChinaHat.mc.field_71474_y.field_74320_O == 1 || ChinaHat.mc.field_71474_y.field_74320_O == 2) {
                GlStateManager.func_179094_E();
                GL11.glBlendFunc((int)770, (int)771);
                GlStateManager.func_179097_i();
                GlStateManager.func_179090_x();
                RenderUtils.enableSmoothLine(2.5f);
                GL11.glShadeModel((int)7425);
                GL11.glDisable((int)2884);
                GL11.glEnable((int)3042);
                GL11.glEnable((int)2929);
                GL11.glTranslatef((float)0.0f, (float)((float)((double)ChinaHat.mc.field_71439_g.field_70131_O + n)), (float)0.0f);
                GL11.glRotatef((float)(-ChinaHat.mc.field_71439_g.field_70177_z), (float)0.0f, (float)1.0f, (float)0.0f);
                Color white = Color.WHITE;
                Color color = new Color(105, 55, 255);
                GL11.glBegin((int)6);
                RenderUtils.glColor(color, 255.0f);
                GL11.glVertex3d((double)0.0, (double)0.3, (double)0.0);
                float n2 = 0.0f;
                while ((double)n2 < 360.5) {
                    RenderUtils.glColor(ClickGUI.getColor());
                    GL11.glVertex3d((double)(Math.cos((double)n2 * Math.PI / 180.0) * 0.66), (double)0.0, (double)(Math.sin((double)n2 * Math.PI / 180.0) * 0.66));
                    n2 += 1.0f;
                }
                GL11.glVertex3d((double)0.0, (double)0.3, (double)0.0);
                GL11.glEnd();
                GL11.glBegin((int)2);
                float n3 = 0.0f;
                while ((double)n3 < 360.5) {
                    RenderUtils.glColor(ClickGUI.getColor());
                    GL11.glVertex3d((double)(Math.cos((double)n3 * Math.PI / 180.0) * 0.66), (double)0.0, (double)(Math.sin((double)n3 * Math.PI / 180.0) * 0.66));
                    n3 += 1.0f;
                }
                GL11.glEnd();
                GlStateManager.func_179141_d();
                RenderUtils.disableSmoothLine();
                GL11.glShadeModel((int)7424);
                GL11.glEnable((int)2884);
                GL11.glDisable((int)3042);
                GlStateManager.func_179098_w();
                GlStateManager.func_179126_j();
                GlStateManager.func_179117_G();
                GlStateManager.func_179121_F();
            }
        } else if (Objects.equals(valString, "V1")) {
            double n4 = ChinaHat.mc.field_71439_g.func_70093_af() ? -0.18 : 0.04;
            GL11.glPushMatrix();
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)3553);
            GL11.glDepthMask((boolean)false);
            GL11.glColor4f((float)((float)Color.magenta.getRed() / 255.0f), (float)((float)Color.magenta.getGreen() / 255.0f), (float)((float)Color.magenta.getBlue() / 255.0f), (float)0.49019608f);
            GL11.glTranslatef((float)0.0f, (float)((float)((double)((float)((double)ChinaHat.mc.field_71439_g.field_70131_O + 0.36)) + n4)), (float)0.0f);
            GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            Cylinder cylinder = new Cylinder();
            cylinder.setDrawStyle(100000);
            cylinder.setDrawStyle(100011);
            cylinder.draw(0.0f, 0.55f, 0.3f, 150, 100);
            GL11.glEnable((int)3553);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
        }
    }
}
