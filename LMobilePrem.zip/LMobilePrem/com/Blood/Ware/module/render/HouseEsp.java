package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HouseEsp
extends Module {
    ArrayList armorStands = new ArrayList();

    public HouseEsp() {
        super("HouseEsp", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("Wallhack", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Glowing", this, false));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity entity : HouseEsp.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || !entity.func_184202_aL()) continue;
            entity.func_184195_f(false);
        }
    }

    void render(Entity entity, float n) {
        try {
            if (entity == null || entity == HouseEsp.mc.field_71439_g) {
                return;
            }
            if (entity == mc.func_175606_aa() && HouseEsp.mc.field_71474_y.field_74320_O == 0) {
                return;
            }
            HouseEsp.mc.field_71460_t.func_175072_h();
            mc.func_175598_ae().func_188388_a(entity, n, false);
            HouseEsp.mc.field_71460_t.func_180436_i();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void ShkafRender(RenderWorldLastEvent renderWorldLastEvent) {
        GlStateManager.func_179086_m((int)256);
        RenderHelper.func_74519_b();
        boolean valBoolean = BloodWare.instance.settingsManager.getSettingByName(this, "Wallhack").getValBoolean();
        boolean valBoolean2 = BloodWare.instance.settingsManager.getSettingByName(this, "Glowing").getValBoolean();
        for (Entity entity : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityArmorStand) || entity == Minecraft.func_71410_x().func_175606_aa()) continue;
            if (valBoolean) {
                this.render(entity, renderWorldLastEvent.getPartialTicks());
            }
            if (!valBoolean2 || entity.func_184202_aL()) continue;
            entity.func_184195_f(true);
        }
    }
}
