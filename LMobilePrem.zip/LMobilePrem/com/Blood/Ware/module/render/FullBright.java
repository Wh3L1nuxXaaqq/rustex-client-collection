package com.Blood.Ware.module.render;

import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FullBright
extends Module {
    public float oldgamma;

    public FullBright() {
        super("FullBright", Category.RENDER);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.oldgamma = FullBright.mc.field_71474_y.field_74333_Y;
        FullBright.mc.field_71474_y.field_74333_Y = 10000.0f;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        FullBright.mc.field_71474_y.field_74333_Y = this.oldgamma;
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) {
    }
}
