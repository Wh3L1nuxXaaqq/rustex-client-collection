package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ESP
extends Module {
    public static List listA = new ArrayList();
    public static List Heal;
    public static List Modes;

    public static void renderEntityBoundingBox(Entity entity, float n, float n2, float n3, float n4) {
        RenderManager getRenderManager = Minecraft.func_71410_x().func_175598_ae();
        Vec3d interpolateEntity = ESP.interpolateEntity(entity);
        GlStateManager.func_187441_d((float)5.0f);
        RenderGlobal.func_189697_a((AxisAlignedBB)new AxisAlignedBB(interpolateEntity.field_72450_a - (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72448_b, interpolateEntity.field_72449_c - (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72450_a + (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72448_b + (double)entity.field_70131_O, interpolateEntity.field_72449_c + (double)(entity.field_70130_N / 2.0f)).func_72317_d(-getRenderManager.field_78730_l, -getRenderManager.field_78731_m, -getRenderManager.field_78728_n), (float)n, (float)n2, (float)n3, (float)n4);
        GlStateManager.func_187441_d((float)1.0f);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityPlayer) || !entity.func_184202_aL()) continue;
            entity.func_184195_f(false);
        }
    }

    public static void renderEntityFilledBoundingBox(Entity entity, float n, float n2, float n3, float n4) {
        RenderManager getRenderManager = Minecraft.func_71410_x().func_175598_ae();
        Vec3d interpolateEntity = ESP.interpolateEntity(entity);
        RenderGlobal.func_189696_b((AxisAlignedBB)new AxisAlignedBB(interpolateEntity.field_72450_a - (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72448_b, interpolateEntity.field_72449_c - (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72450_a + (double)(entity.field_70130_N / 2.0f), interpolateEntity.field_72448_b + (double)entity.field_70131_O, interpolateEntity.field_72449_c + (double)(entity.field_70130_N / 2.0f)).func_72317_d(-getRenderManager.field_78730_l, -getRenderManager.field_78731_m, -getRenderManager.field_78728_n), (float)n, (float)n2, (float)n3, (float)n4);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    public static Vec3d interpolateEntity(Entity entity) {
        double n = Minecraft.func_71410_x().func_184121_ak();
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * n, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * n, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * n);
    }

    public ESP() {
        super("ESP", Category.RENDER);
        Modes.add("3D");
        Modes.add("2D");
        Modes.add("NoneCode");
        Modes.add("Glowing");
        Modes.add("Corners");
        Modes.add("OnHeal");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "2D", (ArrayList<String>)((ArrayList)Modes)));
        BloodWare.instance.settingsManager.rSetting(new Setting("Health[2D]", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("healthValue[2D]", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Box[2D]", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Tag[2D]", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Show item[2D]", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("3DAlpha[3D]", this, 0.7, 0.0, 1.0, false));
        Heal.add("Right");
        Heal.add("Left");
        BloodWare.instance.settingsManager.rSetting(new Setting("PosHp[2D]", (Module)this, "Right", (ArrayList<String>)((ArrayList)Heal)));
        BloodWare.instance.settingsManager.rSetting(new Setting("redBox[2D]", this, 0.8, 0.1, 255.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("greenBox[2D]", this, 0.8, 0.1, 255.0, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("blueBox[2D]", this, 0.8, 0.1, 255.0, false));
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        block35: {
            float n;
            String valString2;
            block34: {
                String valString = BloodWare.instance.settingsManager.getSettingByName(this, "PosHp[2D]").getValString();
                valString2 = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
                boolean valBoolean = BloodWare.instance.settingsManager.getSettingByName(this, "Health[2D]").getValBoolean();
                boolean valBoolean2 = BloodWare.instance.settingsManager.getSettingByName(this, "healthValue[2D]").getValBoolean();
                boolean valBoolean3 = BloodWare.instance.settingsManager.getSettingByName(this, "Box[2D]").getValBoolean();
                boolean valBoolean4 = BloodWare.instance.settingsManager.getSettingByName(this, "Tag[2D]").getValBoolean();
                boolean valBoolean5 = BloodWare.instance.settingsManager.getSettingByName(this, "Show item[2D]").getValBoolean();
                n = (float)BloodWare.instance.settingsManager.getSettingByName(this, "3DAlpha[3D]").getValDouble();
                float n2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "redBox[2D]").getValDouble();
                float n3 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "greenBox[2D]").getValDouble();
                float n4 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "blueBox[2D]").getValDouble();
                if (!Objects.equals(valString2, "2D")) break block34;
                Iterator iterator = ESP.mc.field_71441_e.field_72996_f.iterator();
                if (!iterator.hasNext()) break block35;
                Entity entity = (Entity)iterator.next();
                for (Entity entity2 : ESP.mc.field_71441_e.field_72996_f) {
                    if (!(entity2 instanceof EntityPlayer) || entity2 == ESP.mc.field_71441_e.field_72996_f) continue;
                    double n5 = entity2.field_70142_S + (entity2.field_70165_t - entity2.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                    double n6 = entity2.field_70137_T + (entity2.field_70163_u - entity2.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                    double n7 = entity2.field_70136_U + (entity2.field_70161_v - entity2.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                    GL11.glPushMatrix();
                    GL11.glLineWidth((float)1.5f);
                    GL11.glTranslated((double)n5, (double)n6, (double)n7);
                    GL11.glDisable((int)3553);
                    GL11.glDisable((int)2929);
                    GL11.glRotated((double)(-ESP.mc.func_175598_ae().field_78735_i), (double)0.0, (double)1.0, (double)0.0);
                    if (valBoolean3) {
                        if (FriendManager.FRIENDS.contains(entity2.func_70005_c_())) {
                            GL11.glColor4d((double)0.0, (double)255.0, (double)0.0, (double)255.0);
                            GL11.glBegin((int)3);
                            GL11.glVertex3d((double)0.55, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.55, (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glVertex3d((double)((double)entity2.field_70130_N - 1.15), (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glVertex3d((double)((double)entity2.field_70130_N - 1.15), (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.55, (double)-0.2, (double)0.0);
                            GL11.glEnd();
                        } else {
                            GL11.glColor4d((double)n2, (double)n3, (double)n4, (double)255.0);
                            GL11.glBegin((int)3);
                            GL11.glVertex3d((double)0.55, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.55, (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glVertex3d((double)((double)entity2.field_70130_N - 1.15), (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glVertex3d((double)((double)entity2.field_70130_N - 1.15), (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.55, (double)-0.2, (double)0.0);
                            GL11.glEnd();
                        }
                    }
                    if (valBoolean) {
                        if (Objects.equals(valString, "Right")) {
                            Color color = Color.GREEN.darker();
                            if (((EntityPlayer)entity2).func_110143_aJ() >= 16.0f) {
                                color = Color.GREEN.darker();
                            } else if (((EntityPlayer)entity2).func_110143_aJ() >= 8.0f && ((EntityPlayer)entity2).func_110143_aJ() <= 16.0f) {
                                color = Color.YELLOW;
                            } else if (((EntityPlayer)entity2).func_110143_aJ() > 0.0f && ((EntityPlayer)entity2).func_110143_aJ() <= 8.0f) {
                                color = Color.RED;
                            }
                            GL11.glLineWidth((float)6.0f);
                            GL11.glBegin((int)3);
                            GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
                            GL11.glVertex3d((double)-0.7, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)-0.7, (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glEnd();
                            GL11.glBegin((int)3);
                            GL11.glColor4d((double)((float)color.getRed() / 255.0f), (double)((float)color.getGreen() / 255.0f), (double)((float)color.getBlue() / 255.0f), (double)((float)color.getAlpha() / 255.0f));
                            GL11.glVertex3d((double)-0.7, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)-0.7, (double)((double)(((EntityLivingBase)entity2).func_110143_aJ() / ((EntityLivingBase)entity2).func_110138_aP()) * ((double)entity2.field_70131_O + 0.2)), (double)0.0);
                            GL11.glVertex3d((double)-0.7, (double)-0.2, (double)0.0);
                            GL11.glEnd();
                        } else if (Objects.equals(valString, "Left")) {
                            Color color2 = Color.GREEN.darker();
                            if (((EntityPlayer)entity2).func_110143_aJ() >= 16.0f) {
                                color2 = Color.GREEN.darker();
                            } else if (((EntityPlayer)entity2).func_110143_aJ() >= 8.0f && ((EntityPlayer)entity2).func_110143_aJ() <= 16.0f) {
                                color2 = Color.YELLOW;
                            } else if (((EntityPlayer)entity2).func_110143_aJ() > 0.0f && ((EntityPlayer)entity2).func_110143_aJ() <= 8.0f) {
                                color2 = Color.RED;
                            }
                            GL11.glLineWidth((float)6.0f);
                            GL11.glBegin((int)3);
                            GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
                            GL11.glVertex3d((double)0.7, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.7, (double)((double)entity2.field_70131_O + 0.2), (double)0.0);
                            GL11.glEnd();
                            GL11.glBegin((int)3);
                            GL11.glColor4d((double)((float)color2.getRed() / 255.0f), (double)((float)color2.getGreen() / 255.0f), (double)((float)color2.getBlue() / 255.0f), (double)((float)color2.getAlpha() / 255.0f));
                            GL11.glVertex3d((double)0.7, (double)-0.2, (double)0.0);
                            GL11.glVertex3d((double)0.7, (double)((double)(((EntityLivingBase)entity2).func_110143_aJ() / ((EntityLivingBase)entity2).func_110138_aP()) * ((double)entity2.field_70131_O + 0.2)), (double)0.0);
                            GL11.glVertex3d((double)0.7, (double)-0.2, (double)0.0);
                            GL11.glEnd();
                        }
                    }
                    GL11.glScaled((double)-0.013f, (double)-0.013f, (double)-0.013f);
                    if (valBoolean4) {
                        GL11.glEnable((int)3553);
                        ESP.mc.field_71466_p.func_175063_a(entity2.func_70005_c_(), (float)(1 - ESP.mc.field_71466_p.func_78256_a(entity2.func_70005_c_()) / 2), -170.0f, -1);
                        GL11.glDisable((int)3553);
                    }
                    if (valBoolean2 && valBoolean) {
                        GL11.glEnable((int)3553);
                        ESP.mc.field_71466_p.func_175063_a(String.valueOf((int)(((EntityPlayer)entity2).func_110143_aJ() / ((EntityPlayer)entity2).func_110138_aP() * 100.0f)), (float)(-50 - ESP.mc.field_71466_p.func_78256_a(String.valueOf((int)(((EntityPlayer)entity2).func_110143_aJ() / ((EntityPlayer)entity2).func_110138_aP() * 100.0f)))), (float)((int)((double)(((EntityLivingBase)entity2).func_110143_aJ() / ((EntityLivingBase)entity2).func_110138_aP()) * ((double)entity2.field_70131_O + 0.2))), -1);
                        GL11.glDisable((int)3553);
                    }
                    if (valBoolean5 && !(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemBlock) && !(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof ItemAir)) {
                        GL11.glEnable((int)3553);
                        ESP.mc.field_71466_p.func_175063_a(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND).func_82833_r(), (float)(1 - ESP.mc.field_71466_p.func_78256_a(((EntityPlayer)entity2).func_184586_b(EnumHand.MAIN_HAND).func_82833_r()) / 2), 20.0f, -1);
                        GL11.glDisable((int)3553);
                    }
                    GL11.glEnable((int)2929);
                    GL11.glEnable((int)3553);
                    GL11.glPopMatrix();
                }
                break block35;
            }
            if (Objects.equals(valString2, "Glowing")) {
                for (Entity entity3 : ESP.mc.field_71441_e.field_72996_f) {
                    if (!(entity3 instanceof EntityPlayer) || entity3 == ESP.mc.field_71439_g || entity3.func_184202_aL()) continue;
                    entity3.func_184195_f(true);
                }
            } else if (Objects.equals(valString2, "3D")) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179090_x();
                GlStateManager.func_179118_c();
                GlStateManager.func_179147_l();
                GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
                GlStateManager.func_179097_i();
                for (Entity entity4 : ESP.mc.field_71441_e.field_72996_f) {
                    if (!(entity4 instanceof EntityPlayer) || entity4 == ESP.mc.field_71439_g) continue;
                    ESP.renderEntityBoundingBox(entity4, (float)Color.RED.getRed() / 255.0f, (float)Color.RED.getGreen() / 255.0f, (float)Color.RED.getBlue() / 255.0f, n);
                }
                GlStateManager.func_179126_j();
                GlStateManager.func_179084_k();
                GlStateManager.func_179098_w();
                GlStateManager.func_179141_d();
                GlStateManager.func_179121_F();
            } else {
                if (Objects.equals(valString2, "NoneCode")) {
                    for (Entity entity5 : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity5 instanceof EntityPlayer) || entity5 == ESP.mc.field_71439_g && ESP.mc.field_71474_y.field_74320_O != 1) continue;
                        double n8 = entity5.field_70142_S + (entity5.field_70165_t - entity5.field_70142_S) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78730_l;
                        double n9 = entity5.field_70137_T + (entity5.field_70163_u - entity5.field_70137_T) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78731_m;
                        double n10 = entity5.field_70136_U + (entity5.field_70161_v - entity5.field_70136_U) * (double)mc.func_184121_ak() - ESP.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glDisable((int)2929);
                        GL11.glDisable((int)3553);
                        GL11.glTranslatef((float)((float)n8), (float)((float)n9), (float)((float)n10));
                        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glRotatef((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glRotatef((float)ESP.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                        GL11.glLineWidth((float)3.0f);
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity5.field_70130_N) - 0.1), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity5.field_70130_N) - 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glEnd();
                        GL11.glLineWidth((float)0.7f);
                        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity5.field_70130_N) - 0.1), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glVertex3d((double)((double)(-entity5.field_70130_N) - 0.1), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.1), (double)-0.4, (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glLineWidth((float)3.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)Color.GRAY.getRed(), (float)Color.GRAY.getGreen(), (float)Color.GRAY.getBlue());
                        GL11.glLineWidth((float)0.7f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)((double)entity5.field_70131_O + 0.4), (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)-0.4, (double)0.0);
                        GL11.glVertex3d((double)((double)entity5.field_70130_N + 0.4), (double)((double)(((EntityPlayer)entity5).func_110143_aJ() / ((EntityPlayer)entity5).func_110138_aP()) * ((double)entity5.field_70131_O + 0.4)), (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glEnd();
                        GL11.glEnable((int)2929);
                        GL11.glEnable((int)3553);
                        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                        GL11.glPopMatrix();
                    }
                    return;
                }
                if (Objects.equals(valString2, "Corners")) {
                    for (Entity entity6 : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity6 instanceof EntityPlayer) || entity6 == ESP.mc.field_71439_g) continue;
                        double n11 = entity6.field_70142_S + (entity6.field_70165_t - entity6.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                        double n12 = entity6.field_70137_T + (entity6.field_70163_u - entity6.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                        double n13 = entity6.field_70136_U + (entity6.field_70161_v - entity6.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glDisable((int)2929);
                        GL11.glDisable((int)3553);
                        GL11.glTranslated((double)n11, (double)n12, (double)n13);
                        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glRotatef((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                        GL11.glLineWidth((float)3.0f);
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)0.2, (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)-0.3, (double)0.0);
                        GL11.glVertex3d((double)0.15, (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)0.2, (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)-0.3, (double)0.0);
                        GL11.glVertex3d((double)-0.15, (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)0.15, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)((double)entity6.field_70131_O - 0.3), (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)-0.15, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)((double)entity6.field_70131_O - 0.3), (double)0.0);
                        GL11.glEnd();
                        GL11.glLineWidth((float)1.0f);
                        GL11.glColor3f((float)Color.CYAN.darker().getRed(), (float)Color.CYAN.darker().getGreen(), (float)Color.CYAN.darker().getBlue());
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)0.2, (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)-0.3, (double)0.0);
                        GL11.glVertex3d((double)0.15, (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)0.2, (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)-0.3, (double)0.0);
                        GL11.glVertex3d((double)-0.15, (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)0.15, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)entity6.field_70130_N, (double)((double)entity6.field_70131_O - 0.3), (double)0.0);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)-0.15, (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)(-entity6.field_70130_N), (double)((double)entity6.field_70131_O - 0.3), (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glLineWidth((float)3.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                        GL11.glLineWidth((float)1.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)((double)entity6.field_70131_O + 0.3), (double)0.0);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                        GL11.glLineWidth((float)1.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)((double)(((EntityPlayer)entity6).func_110143_aJ() / ((EntityPlayer)entity6).func_110138_aP()) * ((double)entity6.field_70131_O + 0.3)), (double)0.0);
                        GL11.glVertex3d((double)((double)entity6.field_70130_N + 0.2), (double)-0.3, (double)0.0);
                        GL11.glEnd();
                        GL11.glColor3f((float)1.0f, (float)1.0f, (float)1.0f);
                        GL11.glDisable((int)2960);
                        GL11.glEnable((int)2929);
                        GL11.glEnable((int)3553);
                        GL11.glPopMatrix();
                    }
                } else if (Objects.equals(valString2, "OnHeal")) {
                    for (Entity entity7 : ESP.mc.field_71441_e.field_72996_f) {
                        if (!(entity7 instanceof EntityPlayer) || entity7 == ESP.mc.field_71439_g) continue;
                        double n14 = entity7.field_70142_S + (entity7.field_70165_t - entity7.field_70142_S) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78730_l;
                        double n15 = entity7.field_70137_T + (entity7.field_70163_u - entity7.field_70137_T) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78731_m;
                        double n16 = entity7.field_70136_U + (entity7.field_70161_v - entity7.field_70136_U) * (double)renderWorldLastEvent.getPartialTicks() - ESP.mc.func_175598_ae().field_78728_n;
                        GL11.glPushMatrix();
                        GL11.glDisable((int)2929);
                        GL11.glDisable((int)3553);
                        GL11.glTranslatef((float)((float)n14), (float)((float)n15), (float)((float)n16));
                        GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
                        GlStateManager.func_179114_b((float)(-ESP.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                        GlStateManager.func_179114_b((float)ESP.mc.func_175598_ae().field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
                        GL11.glLineWidth((float)4.7f);
                        GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                        GL11.glVertex3f((float)0.4f, (float)entity7.field_70131_O, (float)0.0f);
                        GL11.glEnd();
                        GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                        GL11.glLineWidth((float)0.8f);
                        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                        GL11.glBegin((int)3);
                        GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                        GL11.glVertex3f((float)0.4f, (float)entity7.field_70131_O, (float)0.0f);
                        GL11.glColor3f((float)0.0f, (float)255.0f, (float)0.0f);
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3f((float)0.4f, (float)0.0f, (float)0.0f);
                        GL11.glVertex3f((float)0.4f, (float)(((EntityPlayer)entity7).func_110143_aJ() / ((EntityPlayer)entity7).func_110138_aP() * entity7.field_70131_O), (float)0.0f);
                        GL11.glEnd();
                        GL11.glEnable((int)3553);
                        GL11.glEnable((int)2929);
                        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
                        GL11.glPopMatrix();
                    }
                }
            }
        }
    }

    static {
        Modes = new ArrayList();
        Heal = new ArrayList();
    }
}
