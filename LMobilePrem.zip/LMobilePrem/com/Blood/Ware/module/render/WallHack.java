package com.Blood.Ware.module.render;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WallHack
extends Module {
    void render(Entity entity, float n) {
        try {
            if (entity == null || entity == Minecraft.func_71410_x().field_71439_g) {
                return;
            }
            if (entity == Minecraft.func_71410_x().func_175606_aa() && Minecraft.func_71410_x().field_71474_y.field_74320_O == 0) {
                return;
            }
            Minecraft.func_71410_x().field_71460_t.func_175072_h();
            Minecraft.func_71410_x().func_175598_ae().func_188388_a(entity, n, false);
            Minecraft.func_71410_x().field_71460_t.func_180436_i();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        boolean valBoolean = BloodWare.instance.settingsManager.getSettingByName(this, "Mob").getValBoolean();
        boolean valBoolean2 = BloodWare.instance.settingsManager.getSettingByName(this, "Animal").getValBoolean();
        GlStateManager.func_179086_m((int)256);
        RenderHelper.func_74519_b();
        if (valBoolean) {
            for (Entity entity : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityMob) || entity == Minecraft.func_71410_x().func_175606_aa()) continue;
                this.render(entity, renderWorldLastEvent.getPartialTicks());
            }
        }
        if (valBoolean2) {
            for (Entity entity2 : Minecraft.func_71410_x().field_71441_e.field_72996_f) {
                if (!(entity2 instanceof EntityAnimal) || entity2 == Minecraft.func_71410_x().func_175606_aa()) continue;
                this.render(entity2, renderWorldLastEvent.getPartialTicks());
            }
        }
    }

    public WallHack() {
        super("WallHackMob", Category.RENDER);
        BloodWare.instance.settingsManager.rSetting(new Setting("Mob", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Animal", this, false));
    }
}
