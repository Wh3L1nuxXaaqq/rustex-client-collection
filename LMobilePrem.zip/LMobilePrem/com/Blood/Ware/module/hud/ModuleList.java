package com.Blood.Ware.module.hud;

import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.MathUtils;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ModuleList
extends Module {
    ArrayList<SubModule> modules = new ArrayList();

    public ModuleList() {
        super("ArrayList", Category.HUD);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent.Text text) {
        int x = text.getResolution().func_78326_a() - 15;
        int y = 22;
        for (SubModule module : this.modules) {
            if (module.getModule().isToggled() && module.getModule().visible) {
                module.setAnim(MathUtils.lerp(module.getAnim(), 1.0f, 0.1f));
                module.setY((int)MathUtils.lerp(module.getY(), CastomFontUtils.fr4.getHeight() + 10, 0.1f));
                continue;
            }
            module.setAnim(MathUtils.lerp(module.getAnim(), 0.0f, 0.1f));
            module.setY((int)MathUtils.lerp(module.getY(), 0.0f, 0.1f));
        }
        this.modules.sort(new Comparator<SubModule>(){

            @Override
            public int compare(SubModule o1, SubModule o2) {
                return CastomFontUtils.fr4.getStringWidth(o2.getModule().getName()) - CastomFontUtils.fr4.getStringWidth(o1.getModule().getName());
            }
        });
        int i = 0;
        for (SubModule module2 : this.modules) {
            GL11.glPushMatrix();
            float oXpos = x - CastomFontUtils.fr4.getStringWidth(module2.getModule().getName());
            float oYpos = 22 + i;
            float oWidth = CastomFontUtils.fr4.getStringWidth(module2.getModule().getName());
            float oHeight = 10.0f;
            GL11.glTranslated((double)oWidth, (double)10.0, (double)1.0);
            GL11.glTranslated((double)(-oXpos * module2.getAnim() + oXpos + oWidth * -module2.getAnim()), (double)(-oYpos * 1.0f + oYpos + -10.0f), (double)1.0);
            GL11.glScaled((double)module2.getAnim(), (double)1.0, (double)0.0);
            RenderUtils.drawShadowRect(x - CastomFontUtils.fr4.getStringWidth(module2.getModule().getName()), 22 + i, x, 22 + i + 10, 2);
            RenderUtils.drawRect(x - CastomFontUtils.fr4.getStringWidth(module2.getModule().getName()), 22 + i, x, 22 + i + 9, new Color(30, 30, 30, 200).getRGB());
            CastomFontUtils.fr4.drawString(module2.getModule().getName(), x - CastomFontUtils.fr4.getStringWidth(module2.getModule().getName()), 22 + i, ClickGUI.getColor());
            GL11.glPopMatrix();
            i += module2.getY();
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        int x = 955;
        this.modules.clear();
        for (Module module : ModuleManager.modules) {
            this.modules.add(new SubModule(module));
        }
    }

    static class SubModule {
        Module module;
        int y = 0;
        float anim = 0.0f;

        public SubModule(Module module) {
            this.module = module;
        }

        public float getAnim() {
            return this.anim;
        }

        public void setAnim(float anim) {
            this.anim = anim;
        }

        public Module getModule() {
            return this.module;
        }

        public int getY() {
            return this.y;
        }

        public void setY(int y) {
            this.y = y;
        }
    }
}
