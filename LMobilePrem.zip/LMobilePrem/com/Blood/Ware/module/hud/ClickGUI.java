package com.Blood.Ware.module.hud;

import Caesium.Panel;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ColourUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;

public class ClickGUI
extends Module {
    public static int red;
    public static int green;
    public static int blue;
    public static int color;
    public static List<String> Modes;

    public ClickGUI() {
        super("ClickGUI", Category.HUD);
        this.setKey(54);
        Modes.add("Castom");
        Modes.add("New");
        Modes.add("Old");
        BloodWare.instance.settingsManager.rSetting(new Setting("Gui", (Module)this, "Old", (ArrayList<String>)((ArrayList)Modes)));
        BloodWare.instance.settingsManager.rSetting(new Setting("Rainbow", this, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Red", this, 225.0, 0.0, 225.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Green", this, 0.0, 0.0, 225.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Blue", this, 0.0, 0.0, 225.0, true));
    }

    public static int getColor() {
        boolean setcolor = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        int rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        int red = (int)BloodWare.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        int green = (int)BloodWare.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        int blue = (int)BloodWare.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 255);
        int TheColor = setcolor ? ColourUtils.genRainbow() : color;
        return TheColor;
    }

    public static int getColor2() {
        boolean setcolor = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        int rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        int red = (int)BloodWare.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        int green = (int)BloodWare.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        int blue = (int)BloodWare.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 195);
        int TheColor = setcolor ? ColourUtils.genRainbowShadow() : color;
        return TheColor;
    }

    public static float getColor3() {
        boolean setcolor = BloodWare.instance.settingsManager.getSettingByName("Rainbow", "Range").getValBoolean();
        float[] hue = new float[]{(float)(System.currentTimeMillis() % 11520L) / 11520.0f};
        float rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        float red = (float)BloodWare.instance.settingsManager.getSettingByName("Red", "Range").getValDouble();
        float green = (float)BloodWare.instance.settingsManager.getSettingByName("Green", "Range").getValDouble();
        float blue = (float)BloodWare.instance.settingsManager.getSettingByName("Blue", "Range").getValDouble();
        int color = ColourUtils.toRGBA(red, green, blue, 255.0f);
        float TheColor = setcolor ? (float)ColourUtils.genRainbowShadow() : (float)color;
        return TheColor;
    }

    @Override
    public void onEnable() {
        String Mode;
        switch (Mode = BloodWare.instance.settingsManager.getSettingByName(this, "Gui").getValString()) {
            case "New": {
                mc.func_147108_a((GuiScreen)new Panel("Caesium", 22));
                break;
            }
            case "Old": {
                mc.func_147108_a((GuiScreen)BloodWare.bobrGui);
                break;
            }
            case "Castom": {
                mc.func_147108_a((GuiScreen)BloodWare.CastomGui);
            }
        }
        super.onEnable();
        this.setToggled(false);
    }

    static {
        Modes = new ArrayList<String>();
    }
}
