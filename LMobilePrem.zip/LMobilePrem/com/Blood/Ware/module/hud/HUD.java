package com.Blood.Ware.module.hud;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ColorUtils;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.TimerUtils;
import com.google.common.base.Strings;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import scala.reflect.runtime.Settings;

public class HUD
extends Module {
    public int oYpos;
    float animX = 0.0f;
    public int oHeight;
    float animY = 1.0f;
    public static ArrayList<String> Modes = new ArrayList();
    private static RenderItem kappita;
    public int oWidth;
    TimerUtils timer = new TimerUtils();
    public int width;
    private Entity target;
    private static final RenderItem itemRender;
    private int y;
    public int oXpos;
    public int height;
    private final FontRenderer fr;
    private ArrayList<Module> modulesSorted;
    Settings.BooleanSetting info;
    String text = "connecting";
    private float anima;
    float animYMot = 1.4f;
    private int x;
    float animXMot = 1.4f;

    public HUD() {
        super("HUD", Category.HUD);
        this.fr = Minecraft.func_71410_x().field_71466_p;
        Modes.add("Loose");
        Modes.add("LooseOne");
        Modes.add("LooseSkeet");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "LooseSkeet", Modes));
        BloodWare.instance.settingsManager.rSetting(new Setting("InfoWorld", this, false));
        BloodWare.instance.settingsManager.rSetting(new Setting("Horizontal", this, 30.0, 0.0, 810.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("Vertical", this, 60.0, 0.0, 490.0, true));
    }

    public static void drawRectangleCorrectly(int n, int n2, int n3, int n4, int n5) {
        GL11.glLineWidth((float)1.0f);
        Gui.func_73734_a((int)n, (int)n2, (int)(n + n3), (int)(n2 + n4), (int)n5);
    }

    public static int RGBtoHex(int n, int n2, int n3) {
        return n << 16 | n2 << 8 | n3;
    }

    private int rainbow(long n, float n2) {
        Color color = new Color((int)Long.parseLong(Integer.toHexString(Color.HSBtoRGB((float)(System.nanoTime() + n) / 2.0E10f % 1.0f + 100000.0f, 1.0f, 1.0f)), 16));
        return new Color((float)color.getRed() / 255.0f * n2, (float)color.getGreen() / 255.0f * n2, (float)color.getBlue() / 255.0f * n2, (float)color.getAlpha() / 255.0f).getRGB();
    }

    public static int[] getRainbow(int n, float n2) {
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        float n6 = 6.0f * (float)((System.currentTimeMillis() - (long)Math.round(n2 * 1000.0f)) % (long)(n * 1000)) / (float)(n * 1000);
        int round = Math.round(255.0f * (n6 - (float)Math.floor(n6)));
        if (n6 < 1.0f) {
            n3 = 255;
            n4 = round;
        } else if (n6 < 2.0f) {
            n3 = 255 - round;
            n4 = 255;
        } else if (n6 < 3.0f) {
            n4 = 255;
            n5 = round;
        } else if (n6 < 4.0f) {
            n4 = 255 - round;
            n5 = 255;
        } else if (n6 < 5.0f) {
            n3 = round;
            n5 = 255;
        } else if (n6 < 6.0f) {
            n3 = 255;
            n5 = 255 - round;
        }
        return new int[]{n3, n4, n5};
    }

    public void sortList() {
        this.modulesSorted = new ArrayList<Module>(BloodWare.moduleManager.getModuleList());
        this.modulesSorted.sort(HUD::lambda$sortList$0);
    }

    @SubscribeEvent
    public void InfoCOMP(RenderGameOverlayEvent.Text text) {
        boolean valBoolean = BloodWare.instance.settingsManager.getSettingByName(this, "InfoWorld").getValBoolean();
        float n = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Horizontal").getValDouble();
        float n2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "Vertical").getValDouble();
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT && valBoolean) {
            String value = String.valueOf(new StringBuilder().append("").append(Minecraft.func_175610_ah()));
            String value2 = String.valueOf(new StringBuilder().append("").append(Math.round(HUD.mc.field_71439_g.field_70165_t)));
            String value3 = String.valueOf(new StringBuilder().append("").append(Math.round(HUD.mc.field_71439_g.field_70163_u)));
            String value4 = String.valueOf(new StringBuilder().append("").append(Math.round(HUD.mc.field_71439_g.field_70161_v)));
            HUD.mc.field_71466_p.func_175063_a("X: ", n, n2, BloodWare.color.getRGB());
            HUD.mc.field_71466_p.func_175063_a(value2, n + 10.0f, n2, -1);
            HUD.mc.field_71466_p.func_175063_a("Y: ", n + 30.0f + (float)HUD.mc.field_71466_p.func_78256_a(value2) - 17.0f, n2, BloodWare.color.getRGB());
            HUD.mc.field_71466_p.func_175063_a(value3, n + 40.0f + (float)HUD.mc.field_71466_p.func_78256_a(value2) - 17.0f, n2, -1);
            HUD.mc.field_71466_p.func_175063_a("Z: ", n + 66.0f + (float)HUD.mc.field_71466_p.func_78256_a(value2) - 23.0f + (float)HUD.mc.field_71466_p.func_78256_a(value3) - 17.0f, n2, BloodWare.color.getRGB());
            HUD.mc.field_71466_p.func_175063_a(value4, n + 76.0f + (float)HUD.mc.field_71466_p.func_78256_a(value2) - 23.0f + (float)HUD.mc.field_71466_p.func_78256_a(value3) - 17.0f, n2, -1);
            HUD.mc.field_71466_p.func_175063_a("FPS: ", n, n2 + 11.0f, BloodWare.color.getRGB());
            HUD.mc.field_71466_p.func_175063_a(value, n + 22.0f, n2 + 11.0f, -1);
        }
    }

    public static int raindbow(int n) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + (long)n) / 20L) % 360.0 / 360.0), 0.5f, 1.0f).getRGB();
    }

    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent.Text text) {
        String valString = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        if (valString.equals("Loose")) {
            if (text.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
                return;
            }
            int[] rainbow = HUD.getRainbow(5, 0.1f);
            HUD.RGBtoHex(rainbow[0], rainbow[1], rainbow[2]);
            this.sortList();
            ArrayList<String> list = new ArrayList<String>();
            for (Module module : this.modulesSorted) {
                if (module.getName().equalsIgnoreCase("HUD") || !module.isToggled() || !module.visible) continue;
                list.add(module.getName());
            }
            int FONT_HEIGHT = HUD.mc.field_71466_p.field_78288_b;
            ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
            long n = 0L;
            int n2 = 0;
            ScaledResolution scaledResolution2 = new ScaledResolution(mc);
            int[] array = new int[]{1};
            int n3 = 0;
            for (int i = 0; i < list.size(); ++i) {
                n3 += HUD.mc.field_71466_p.field_78288_b + 5;
            }
            for (int j = 0; j < list.size(); ++j) {
                String s = (String)list.get(j);
                if (Strings.isNullOrEmpty(s)) continue;
                int FONT_HEIGHT2 = HUD.mc.field_71466_p.field_78288_b;
                int n4 = scaledResolution2.func_78326_a() - 2 - HUD.mc.field_71466_p.func_78256_a(s);
                int n5 = 1 + (FONT_HEIGHT2 + 2) * j;
                int astolfoColors = ColorUtils.astolfoColors(array[0] * 15, n3);
                BloodWare.color = new Color(astolfoColors);
                if (j == 0) {
                    // empty if block
                }
                Gui.func_73734_a((int)(n4 + HUD.mc.field_71466_p.func_78256_a(s)), (int)(n5 - 1), (int)(n4 + HUD.mc.field_71466_p.func_78256_a(s) + 1), (int)(n5 + 11), (int)astolfoColors);
                RenderUtil.drawRect(n4 - 2, n5, n4 + HUD.mc.field_71466_p.func_78256_a(s), n5 + 11, 0x44000000);
                HUD.mc.field_71466_p.func_78256_a(s);
                if (j == this.modulesSorted.size() - 1) {
                    RenderUtil.drawGlow(n4 - 2, n5 + 10, n4 + HUD.mc.field_71466_p.func_78256_a(s), n5 + 11, astolfoColors, 1000.0);
                }
                HUD.mc.field_71466_p.func_78276_b(s, n4, n5 + 1, astolfoColors);
                ++n;
                ++n2;
                int[] array2 = array;
                boolean n6 = false;
                array2[0] = array2[0] + 1;
            }
            this.modulesSorted.clear();
        } else if (valString.equals("LooseOne")) {
            if (text.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
                return;
            }
            this.sortList();
            ArrayList<String> list2 = new ArrayList<String>();
            for (Module module2 : this.modulesSorted) {
                if (module2.getName().equalsIgnoreCase("HUD") || !module2.isToggled() || !module2.visible) continue;
                list2.add(module2.getName());
            }
            int FONT_HEIGHT3 = HUD.mc.field_71466_p.field_78288_b;
            ScaledResolution scaledResolution3 = new ScaledResolution(Minecraft.func_71410_x());
            long n7 = 0L;
            int n8 = 0;
            ScaledResolution scaledResolution4 = new ScaledResolution(mc);
            int[] array3 = new int[]{1};
            int n9 = 0;
            for (int k = 0; k < list2.size(); ++k) {
                n9 += HUD.mc.field_71466_p.field_78288_b + 5;
            }
            for (int l = 0; l < list2.size(); ++l) {
                String s2 = (String)list2.get(l);
                if (Strings.isNullOrEmpty(s2)) continue;
                int FONT_HEIGHT4 = HUD.mc.field_71466_p.field_78288_b;
                int n10 = scaledResolution4.func_78326_a() - 1 - HUD.mc.field_71466_p.func_78256_a(s2);
                int n11 = 1 + (FONT_HEIGHT4 + 2) * l;
                int astolfoColors2 = ColorUtils.astolfoColors(array3[0] * 15, n9);
                BloodWare.color = new Color(astolfoColors2);
                if (l == 0) {
                    // empty if block
                }
                Gui.func_73734_a((int)(n10 + HUD.mc.field_71466_p.func_78256_a(s2)), (int)(n11 - 1), (int)(n10 + HUD.mc.field_71466_p.func_78256_a(s2) + 1), (int)(n11 + 11), (int)astolfoColors2);
                RenderUtil.drawRect(n10 - 2, n11, n10 + HUD.mc.field_71466_p.func_78256_a(s2), n11 + 11, 0x44000000);
                HUD.mc.field_71466_p.func_78256_a(s2);
                if (l == this.modulesSorted.size() - 1) {
                    RenderUtil.drawGlow(n10 - 2, n11 + 10, n10 + HUD.mc.field_71466_p.func_78256_a(s2), n11 + 11, astolfoColors2, 1000.0);
                }
                HUD.mc.field_71466_p.func_78276_b(s2, n10, n11 + 1, astolfoColors2);
                ++n7;
                ++n8;
                int[] array4 = array3;
                boolean n12 = false;
                array4[0] = array4[0] + 1;
            }
            this.modulesSorted.clear();
        } else if (valString.equals("LooseSkeet")) {
            if (text.getType() != RenderGameOverlayEvent.ElementType.TEXT || Minecraft.func_71410_x().field_71474_y.field_74330_P) {
                return;
            }
            this.sortList();
            ArrayList<String> list3 = new ArrayList<String>();
            for (Module module3 : this.modulesSorted) {
                if (module3.getName().equalsIgnoreCase("HUD") || !module3.isToggled() || !module3.visible) continue;
                list3.add(module3.getName());
            }
            int FONT_HEIGHT5 = HUD.mc.field_71466_p.field_78288_b;
            ScaledResolution scaledResolution5 = new ScaledResolution(Minecraft.func_71410_x());
            long n13 = 0L;
            int n14 = 0;
            int n15 = 0;
            int getStringWidth = 0;
            int n16 = 0;
            ScaledResolution scaledResolution6 = new ScaledResolution(mc);
            for (int index = 0; index < list3.size(); ++index) {
                String s3 = (String)list3.get(index);
                if (Strings.isNullOrEmpty(s3)) continue;
                int FONT_HEIGHT6 = HUD.mc.field_71466_p.field_78288_b;
                int n17 = scaledResolution6.func_78326_a() - 1 - HUD.mc.field_71466_p.func_78256_a(s3);
                int n18 = 1 + (FONT_HEIGHT6 + 2) * index;
                int rainbowChams = HUD.getRainbowChams(6000, -15);
                if (index == 0) {
                    Gui.func_73734_a((int)(n17 - 2), (int)(n18 - 1), (int)(n17 + HUD.mc.field_71466_p.func_78256_a(s3)), (int)n18, (int)rainbowChams);
                }
                Gui.func_73734_a((int)(n17 - 2), (int)n18, (int)(n17 + HUD.mc.field_71466_p.func_78256_a(s3)), (int)(n18 + 11), (int)0x44000000);
                Gui.func_73734_a((int)(n17 - 3), (int)(n18 - 1), (int)(n17 - 2), (int)(n18 + 11), (int)rainbowChams);
                Gui.func_73734_a((int)n15, (int)n16, (int)(n15 + (getStringWidth - HUD.mc.field_71466_p.func_78256_a(s3))), (int)(n16 + 1), (int)rainbowChams);
                getStringWidth = HUD.mc.field_71466_p.func_78256_a(s3);
                n15 = n17 - 2;
                n16 = n18 + 10;
                Gui.func_73734_a((int)(n17 + HUD.mc.field_71466_p.func_78256_a(s3)), (int)(n18 - 1), (int)(n17 + HUD.mc.field_71466_p.func_78256_a(s3) + 1), (int)(n18 + 11), (int)rainbowChams);
                if (index == this.modulesSorted.size() - 1) {
                    Gui.func_73734_a((int)(n17 - 2), (int)(n18 + 10), (int)(n17 + HUD.mc.field_71466_p.func_78256_a(s3)), (int)(n18 + 11), (int)rainbowChams);
                }
                HUD.mc.field_71466_p.func_78276_b(s3, n17, n18 + 1, rainbowChams);
                ++n13;
                ++n14;
            }
            this.modulesSorted.clear();
        }
    }

    public static int getRainbowChams(int n, int n2) {
        return Color.getHSBColor((float)((System.currentTimeMillis() * 1L + (long)(n2 / 2)) % (long)n * 2L) / (float)n, 1.0f, 1.0f).getRGB();
    }

    private static int lambda$sortList$0(Module module, Module module2) {
        if (HUD.mc.field_71466_p.func_78256_a(module.getName()) < HUD.mc.field_71466_p.func_78256_a(module2.getName())) {
            return 1;
        }
        if (HUD.mc.field_71466_p.func_78256_a(module.getName()) > HUD.mc.field_71466_p.func_78256_a(module2.getName())) {
            return -1;
        }
        return 0;
    }

    public void drawitem(ItemStack itemStack, int n, int n2) {
        GlStateManager.func_179126_j();
        HUD.itemRender.field_77023_b = 200.0f;
        itemRender.func_180450_b(itemStack, n, n2);
        itemRender.func_180453_a(HUD.mc.field_71466_p, itemStack, n, n2, "");
        GlStateManager.func_179098_w();
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        if (itemStack.func_190916_E() == 0 || itemStack.func_190916_E() == 1) {
            this.fr.func_78276_b("", n + 13, n2 + 10, Color.white.getRGB());
        } else {
            this.fr.func_78276_b(String.valueOf(new StringBuilder().append("").append(itemStack.func_190916_E())), n + 13, n2 + 10, Color.white.getRGB());
        }
    }

    static {
        itemRender = Minecraft.func_71410_x().func_175599_af();
    }
}
