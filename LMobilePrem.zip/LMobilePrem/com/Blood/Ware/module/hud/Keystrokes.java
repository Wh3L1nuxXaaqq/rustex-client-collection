package com.Blood.Ware.module.hud;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Keystrokes
extends Module {
    public int color;

    public Keystrokes() {
        super("Keystrokes", Category.HUD);
        BloodWare.instance.settingsManager.rSetting(new Setting("keyX", this, 1.0, 1.0, 897.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("keyY", this, 1.0, -105.0, 340.0, true));
        BloodWare.instance.settingsManager.rSetting(new Setting("mouseButtons", this, false));
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text text) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            float n = (float)BloodWare.instance.settingsManager.getSettingByName(this, "keyX").getValDouble();
            float n2 = (float)BloodWare.instance.settingsManager.getSettingByName(this, "keyY").getValDouble();
            boolean valBoolean = BloodWare.instance.settingsManager.getSettingByName(this, "mouseButtons").getValBoolean();
            GlStateManager.func_179094_E();
            if (!Keystrokes.mc.field_71474_y.field_74330_P) {
                int n3 = (int)n;
                int n4 = (int)n2;
                this.color = Color.WHITE.getRGB();
                RenderUtils.drawRect(n3 + 20, n4 + 111, n3 + 41, n4 + 130, -1879048192);
                RenderUtils.drawRect(n3 + 1, n4 + 130, n3 + 61, n4 + 150, -1879048192);
                if (Keystrokes.mc.field_71474_y.field_74351_w.func_151468_f()) {
                    RenderUtils.drawRect(n3 + 21, n4 + 112, n3 + 40, n4 + 130, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74368_y.func_151468_f()) {
                    RenderUtils.drawRect(n3 + 21, n4 + 131, n3 + 40, n4 + 149, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74370_x.func_151468_f()) {
                    RenderUtils.drawRect(n3 + 2, n4 + 131, n3 + 20, n4 + 149, this.color);
                }
                if (Keystrokes.mc.field_71474_y.field_74366_z.func_151468_f()) {
                    RenderUtils.drawRect(n3 + 41, n4 + 131, n3 + 60, n4 + 149, this.color);
                }
                if (valBoolean) {
                    RenderUtils.drawRect(n3 + 30, n4 + 170, n3 + 61, n4 + 150, -1879048192);
                    RenderUtils.drawRect(n3 + 1, n4 + 170, n3 + 30, n4 + 150, -1879048192);
                    if (Keystrokes.mc.field_71474_y.field_74312_F.func_151468_f()) {
                        RenderUtils.drawRect(n3 + 2, n4 + 150, n3 + 30, n4 + 169, this.color);
                    }
                    if (Keystrokes.mc.field_71474_y.field_74313_G.func_151468_f()) {
                        RenderUtils.drawRect(n3 + 60, n4 + 150, n3 + 31, n4 + 169, this.color);
                    }
                    Keystrokes.mc.field_71466_p.func_175063_a("LMB", (float)(n3 + 7), (float)(n4 + 156), -1);
                    Keystrokes.mc.field_71466_p.func_175063_a("RMB", (float)(n3 + 37), (float)(n4 + 156), -1);
                }
                Keystrokes.mc.field_71466_p.func_175063_a("W", (float)(n3 + 28), (float)(n4 + 117), -1);
                Keystrokes.mc.field_71466_p.func_175063_a("A", (float)(n3 + 8), (float)(n4 + 136), -1);
                Keystrokes.mc.field_71466_p.func_175063_a("S", (float)(n3 + 28), (float)(n4 + 136), -1);
                Keystrokes.mc.field_71466_p.func_175063_a("D", (float)(n3 + 48), (float)(n4 + 136), -1);
            }
            GlStateManager.func_179121_F();
        }
    }
}
