package com.Blood.Ware.module.hud;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ColorUtils;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Watermark
extends Module {
    public static List Modes = new ArrayList();
    private final FontRenderer fr;

    @SubscribeEvent
    public void onOverlayRender(RenderGameOverlayEvent.Text text) {
        String valString = BloodWare.instance.settingsManager.getSettingByName(this, "Mode").getValString();
        if (text.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            if (Objects.equals(valString, "Anim")) {
                int[] rainbow = Watermark.getRainbow(5, 0.1f);
                Watermark.RGBtoHex(rainbow[0], rainbow[1], rainbow[2]);
                String format = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
                String str = "LooseOne ";
                switch ((int)(System.currentTimeMillis() / 700L % 42L)) {
                    case 1: {
                        str = "  ";
                        break;
                    }
                    case 2: {
                        str = " | ";
                        break;
                    }
                    case 3: {
                        str = " |/ ";
                        break;
                    }
                    case 4: {
                        str = " |// ";
                        break;
                    }
                    case 5: {
                        str = "L ";
                        break;
                    }
                    case 6: {
                        str = "L0 ";
                        break;
                    }
                    case 7: {
                        str = "Lo ";
                        break;
                    }
                    case 8: {
                        str = "Loo_- ";
                        break;
                    }
                    case 9: {
                        str = "Loo\\_- ";
                        break;
                    }
                    case 10: {
                        str = "Loos ";
                        break;
                    }
                    case 11: {
                        str = "LooseHUJ ";
                        break;
                    }
                    case 12: {
                        str = "Loose| ";
                        break;
                    }
                    case 13: {
                        str = "Loose|2 ";
                        break;
                    }
                    case 14: {
                        str = "LooseO_ ";
                        break;
                    }
                    case 15: {
                        str = "LooseOne ";
                        break;
                    }
                    case 16: {
                        str = "LooseOne P/ ";
                        break;
                    }
                    case 17: {
                        str = "LooseOne Pr";
                        break;
                    }
                    case 18: {
                        str = "LooseOne Pre@# ";
                        break;
                    }
                    case 19: {
                        str = "LooseOne Prem";
                        break;
                    }
                    case 20: {
                        str = "LooseOne Pre/ ";
                        break;
                    }
                    case 21: {
                        str = "LooseOne Pr";
                        break;
                    }
                    case 22: {
                        str = "LooseOne Pr|/ ";
                        break;
                    }
                    case 23: {
                        str = "LooseOne";
                        break;
                    }
                    case 24: {
                        str = "LooseOn@# ";
                        break;
                    }
                    case 25: {
                        str = "LooseO ";
                        break;
                    }
                    case 26: {
                        str = "Loose/ ";
                        break;
                    }
                    case 27: {
                        str = "Loos ";
                        break;
                    }
                    case 28: {
                        str = "Loos|_ ";
                        break;
                    }
                    case 29: {
                        str = "Lo2 ";
                        break;
                    }
                    case 30: {
                        str = "|&\u00e6|_3|~k@##@";
                        break;
                    }
                    case 31: {
                        str = " |// ";
                        break;
                    }
                    case 32: {
                        str = " |/ ";
                        break;
                    }
                    case 33: {
                        str = " | ";
                        break;
                    }
                    case 34: {
                        str = "  ";
                    }
                }
                String value = String.valueOf(new StringBuilder().append(str).append(" | ").append(format).append(" |  Fps ").append(Minecraft.func_175610_ah()));
                Gui.func_73734_a((int)5, (int)5, (int)(this.fr.func_78256_a(value) + 25), (int)21, (int)new Color(37, 37, 37, 255).getRGB());
                Gui.func_73734_a((int)5, (int)9, (int)(this.fr.func_78256_a(value) + 25), (int)9, (int)new Color(20, 20, 20, 100).getRGB());
                this.fr.func_175063_a(value, 8.0f, 11.0f, -1);
            } else if (Objects.equals(valString, "Static")) {
                int[] rainbow2 = Watermark.getRainbow(5, 0.1f);
                Watermark.RGBtoHex(rainbow2[0], rainbow2[1], rainbow2[2]);
                String format2 = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
                String str2 = "LooseOne ";
                switch ((int)(System.currentTimeMillis() / 700L % 15L)) {
                    case 1: {
                        str2 = "LooseOne";
                    }
                }
                String lowerCase = mc.func_71356_B() ? "localhost" : Watermark.mc.func_147104_D().field_78845_b.toLowerCase();
                String value2 = String.valueOf(new StringBuilder().append(str2).append(" | ").append(format2).append(" |  Fps ").append(Minecraft.func_175610_ah()).append("  | ").append(lowerCase));
                Gui.func_73734_a((int)5, (int)5, (int)(this.fr.func_78256_a(value2) + 21), (int)21, (int)new Color(37, 37, 37, 255).getRGB());
                Gui.func_73734_a((int)5, (int)9, (int)(this.fr.func_78256_a(value2) + 21), (int)9, (int)new Color(20, 20, 20, 100).getRGB());
                this.fr.func_175063_a(value2, 8.0f, 8.0f, -1);
            } else if (Objects.equals(valString, "Skeet")) {
                int[] rainbow3 = Watermark.getRainbow(5, 0.1f);
                Watermark.RGBtoHex(rainbow3[0], rainbow3[1], rainbow3[2]);
                StringBuilder obj = new StringBuilder(String.valueOf(new StringBuilder().append((Object)new StringBuilder(String.valueOf(new StringBuilder().append((Object)new StringBuilder(String.valueOf(new StringBuilder().append((Object)new StringBuilder().append("LooseOne ").append(" ").append("0.1")).append(" | ").append(new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime())).append(" | Fps ").append(Minecraft.func_175610_ah())))).append(" | ").append(mc.func_71356_B() ? "localhost" : Watermark.mc.func_147104_D().field_78845_b.toLowerCase())))).append("  ")));
                Minecraft mc = Watermark.mc;
                String value3 = String.valueOf(obj);
                float n = Minecraft.func_71410_x().field_71466_p.func_78256_a(value3) + 6;
                int n2 = 20;
                int n3 = 2;
                int n4 = 2;
                RenderUtil.drawRect(2.0, 2.0, 2.0f + n + 2.0f, 22.0, new Color(5, 5, 5, 255).getRGB());
                RenderUtil.drawBorderedRect(2.5, 2.5, (double)(2.0f + n) + 1.5, 21.5, 0.5, new Color(40, 40, 40, 255).getRGB(), new Color(60, 60, 60, 255).getRGB(), true);
                RenderUtil.drawBorderedRect(4.0, 4.0, 2.0f + n, 20.0, 0.5, new Color(22, 22, 22, 255).getRGB(), new Color(60, 60, 60, 255).getRGB(), true);
                RenderUtil.drawRect(4.5, 4.5, (double)(2.0f + n) - 0.5, 6.5, new Color(9, 9, 9, 255).getRGB());
                RenderUtil.drawGradientSideways(4.0, 5.0, 4.0f + n / 3.0f, 6.0, new Color(81, 149, 219, 255).getRGB(), new Color(180, 49, 218, 255).getRGB());
                RenderUtil.drawGradientSideways(4.0f + n / 3.0f, 5.0, 4.0f + n / 3.0f * 2.0f, 6.0, new Color(180, 49, 218, 255).getRGB(), new Color(236, 93, 128, 255).getRGB());
                RenderUtil.drawGradientSideways(4.0f + n / 3.0f * 2.0f, 5.0, n / 3.0f * 3.0f + 1.0f, 6.0, new Color(236, 93, 128, 255).getRGB(), new Color(235, 255, 0, 255).getRGB());
                Minecraft.func_71410_x().field_71466_p.func_175063_a(value3, 6.0f, 9.0f, -1);
            } else if (Objects.equals(valString, "OnetapOLD")) {
                String value4 = String.valueOf(new StringBuilder().append("LooseOne | ").append(new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime())).append(" |  Fps ").append(Minecraft.func_175610_ah()));
                Gui.func_73734_a((int)5, (int)7, (int)(this.fr.func_78256_a(value4) + 25), (int)19, (int)new Color(37, 37, 37, 111).getRGB());
                Gui.func_73734_a((int)5, (int)6, (int)(this.fr.func_78256_a(value4) + 25), (int)8, (int)ColorUtils.astolfoColors((int)((double)Math.abs(System.currentTimeMillis() / 50L) / 100.0 + 0.16999999999999998), 5));
                Gui.func_73734_a((int)5, (int)9, (int)(this.fr.func_78256_a(value4) + 25), (int)9, (int)new Color(20, 20, 20, 87).getRGB());
                this.fr.func_175063_a(value4, 8.0f, 9.1f, -1);
            }
        }
    }

    public static int RGBtoHex(int n, int n2, int n3) {
        return n << 16 | n2 << 8 | n3;
    }

    public Watermark() {
        super("Watermark", Category.HUD);
        this.fr = Minecraft.func_71410_x().field_71466_p;
        Modes.add("Anim");
        Modes.add("Static");
        Modes.add("Skeet");
        Modes.add("OnetapOLD");
        BloodWare.instance.settingsManager.rSetting(new Setting("Mode", (Module)this, "Skeet", (ArrayList<String>)((ArrayList)Modes)));
    }

    public static int[] getRainbow(int n, float n2) {
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        float n6 = 6.0f * (float)((System.currentTimeMillis() - (long)Math.round(n2 * 1000.0f)) % (long)(n * 1000)) / (float)(n * 1000);
        int round = Math.round(255.0f * (n6 - (float)Math.floor(n6)));
        if (n6 < 1.0f) {
            n3 = 255;
            n4 = round;
        } else if (n6 < 2.0f) {
            n3 = 255 - round;
            n4 = 255;
        } else if (n6 < 3.0f) {
            n4 = 255;
            n5 = round;
        } else if (n6 < 4.0f) {
            n4 = 255 - round;
            n5 = 255;
        } else if (n6 < 5.0f) {
            n3 = round;
            n5 = 255;
        } else if (n6 < 6.0f) {
            n3 = 255;
            n5 = 255 - round;
        }
        return new int[]{n3, n4, n5};
    }
}
