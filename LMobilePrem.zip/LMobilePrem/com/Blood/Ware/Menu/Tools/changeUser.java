package com.Blood.Ware.Menu.Tools;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.Menu.MainMenu;
import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.awt.Color;
import java.io.IOException;
import java.net.Proxy;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.Session;
import org.lwjgl.opengl.GL11;

public class changeUser
extends GuiScreen {
    GuiTextField inputField;

    public void func_73866_w_() {
        int i = this.field_146295_m / 4 + 48;
        this.field_146292_n.clear();
        this.inputField = new GuiTextField(1, this.field_146289_q, this.field_146294_l / 2 - 100, i + 72 - 12, 200, 20);
        this.inputField.func_146180_a("");
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l / 2 - 100, i + 72 + 12, 200, 20, "Login"));
    }

    public static void changeName(String name) {
        YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
        YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication)service.createUserAuthentication(Agent.MINECRAFT);
        auth.logOut();
        Session session = new Session(name, name, "0", "legacy");
        try {
            BloodWare.setSession(session);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k == 1) {
            changeUser.changeName(this.inputField.func_146179_b());
        }
    }

    public void func_73876_c() {
        this.inputField.func_146178_a();
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        switch (keyCode) {
            case 1: {
                this.field_146297_k.func_147108_a((GuiScreen)new MainMenu());
                break;
            }
            default: {
                this.inputField.func_146201_a(typedChar, keyCode);
            }
        }
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        this.inputField.func_146192_a(mouseX, mouseY, mouseButton);
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.func_146276_q_();
        for (int i = 0; i < this.field_146292_n.size(); ++i) {
            ((GuiButton)this.field_146292_n.get(i)).func_191745_a(this.field_146297_k, mouseX, mouseY, partialTicks);
        }
        this.inputField.func_146194_f();
        this.field_146297_k.field_71466_p.func_175063_a("Your Username: " + this.field_146297_k.func_110432_I().func_111285_a(), (float)(this.field_146294_l / 2 - 100), (float)(this.field_146295_m / 4 + 48 + 110), Color.yellow.getRGB());
    }
}
