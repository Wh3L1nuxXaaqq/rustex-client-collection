package com.Blood.Ware.Menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class drawLogo {
    public static void drawString(double scale, String text, float x, float y, int color) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179139_a((double)scale, (double)scale, (double)scale);
        Minecraft.func_71410_x().field_71466_p.func_175063_a(text, x, y, color);
        GlStateManager.func_179121_F();
    }
}
