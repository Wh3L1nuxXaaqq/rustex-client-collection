package com.Blood.Ware.Menu;

import com.Blood.Ware.Menu.Tools.changeUser;
import com.Blood.Ware.Menu.drawLogo;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class MainMenu
extends GuiScreen {
    private static final ResourceLocation texture = new ResourceLocation("texture.png");

    public void func_73866_w_() {
        int i = this.field_146295_m / 4 + 48;
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiButton(0, this.field_146294_l / 2 - 100, i + 72 + 12, 98, 20, "Options"));
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l / 2 + 2, i + 72 + 12, 98, 20, "Quit"));
        this.field_146292_n.add(new GuiButton(2, this.field_146294_l / 2 + -100, i + 72 - 12, 200, 20, "Change User"));
        this.field_146292_n.add(new GuiButton(4, this.field_146294_l / 2 - 100, i + 72 - 34, 200, 20, "Multiplayer"));
        this.field_146292_n.add(new GuiButton(5, this.field_146294_l / 2 - 100, i + 72 - 58, 200, 20, "Singleplayer"));
    }

    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiOptions((GuiScreen)this, this.field_146297_k.field_71474_y));
        }
        if (button.field_146127_k == 1) {
            this.field_146297_k.func_71400_g();
        }
        if (button.field_146127_k == 2) {
            this.field_146297_k.func_147108_a((GuiScreen)new changeUser());
        }
        if (button.field_146127_k == 4) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayer((GuiScreen)this));
        }
        if (button.field_146127_k == 5) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiWorldSelection((GuiScreen)this));
        }
        super.func_146284_a(button);
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.func_146276_q_();
        this.field_146297_k.field_71446_o.func_110577_a(texture);
        Gui.func_152125_a((int)0, (int)0, (float)0.0f, (float)0.0f, (int)this.field_146294_l, (int)this.field_146295_m, (int)this.field_146294_l, (int)this.field_146295_m, (float)this.field_146294_l, (float)this.field_146295_m);
        drawLogo.drawString(5.0, "LooseOne Premium", this.field_146294_l / 10 - this.field_146289_q.func_78256_a("LooseOne Premium") / 2, this.field_146295_m / 20, new Color(3183152).getRGB());
        for (GuiButton guiButton : this.field_146292_n) {
            guiButton.func_191745_a(this.field_146297_k, mouseX, mouseY, partialTicks);
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
}
