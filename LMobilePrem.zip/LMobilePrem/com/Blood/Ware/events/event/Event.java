package com.Blood.Ware.events.event;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.events.event.ArrayHelper;
import com.Blood.Ware.events.event.Data;
import com.Blood.Ware.events.event.EventManager;
import java.lang.reflect.InvocationTargetException;

public abstract class Event {
    private boolean cancelled;

    public Event call() {
        this.cancelled = false;
        Event.call(this);
        return this;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    private static void call(Event event) {
        EventManager eventManager = BloodWare.eventManager;
        ArrayHelper<Data> dataList = EventManager.get(event.getClass());
        if (dataList != null) {
            for (Data data : dataList) {
                try {
                    data.target.invoke(data.source, event);
                }
                catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
                catch (InvocationTargetException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }
}
