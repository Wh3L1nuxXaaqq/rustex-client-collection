package com.Blood.Ware;

import Bobr.BobrGui;
import Castom.CastomGui;
import com.Blood.Ware.events.event.EventManager;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.notifications.Type;
import com.Blood.Ware.notifications.notifications;
import com.Blood.Ware.settings.SettingsManager;
import com.Blood.Ware.utils.ScaleUtils;
import com.Blood.Ware.utils.config.CommandCfg;
import com.Blood.Ware.utils.config.ConfigManager;
import java.awt.Color;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.util.Session;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

public class BloodWare {
    public static String name = "LooseOne Prem 1.12.2";
    public static String cName = "LooseOne Prem 1.12.2";
    public static String FULL_name = "LooseOne Prem 1.12.2";
    private static final BloodWare INSTANCE = new BloodWare();
    public static ScaleUtils scale = new ScaleUtils(2);
    public static ModuleManager moduleManager;
    public static EventManager eventManager;
    public static BloodWare instance;
    public SettingsManager settingsManager;
    public ConfigManager configManager;
    public static Color color;
    public static BobrGui bobrGui;
    public static CastomGui CastomGui;

    public static void startup() {
        Display.setTitle((String)name);
    }

    public static void setSession(Session s) {
        Class<?> mc = Minecraft.func_71410_x().getClass();
        try {
            Field session = null;
            for (Field f : mc.getDeclaredFields()) {
                if (!f.getType().isInstance(s)) continue;
                session = f;
            }
            if (session == null) {
                throw new IllegalStateException("Session Null");
            }
            session.setAccessible(true);
            session.set(Minecraft.func_71410_x(), s);
            session.setAccessible(false);
            name = "LooseOne Prem 1.12.2 | User: " + Minecraft.func_71410_x().func_110432_I().func_111285_a();
            Display.setTitle((String)name);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Minecraft mc() {
        return Minecraft.func_71410_x();
    }

    public void init() throws Exception {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.settingsManager = new SettingsManager();
        moduleManager = new ModuleManager();
        this.configManager = new ConfigManager();
        ClientCommandHandler.instance.func_71560_a((ICommand)new CommandCfg());
        bobrGui = new BobrGui();
        CastomGui = new CastomGui();
        notifications.add(String.valueOf(TextFormatting.RED), "successful injection!", Type.OK);
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if (Minecraft.func_71410_x().field_71441_e == null || Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        try {
            if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
                int keyCode = Keyboard.getEventKey();
                if (keyCode <= 0) {
                    return;
                }
                for (Module m : ModuleManager.modules) {
                    if (m.getKey() != keyCode || keyCode <= 0) continue;
                    m.toggle();
                }
            }
        }
        catch (Exception q) {
            q.printStackTrace();
        }
    }

    static {
        color = Color.red;
    }
}
