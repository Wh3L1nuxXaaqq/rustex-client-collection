package com.Blood.Ware.utils.search;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.render.BlockEsp;
import com.Blood.Ware.utils.search.Blockinfo;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Search
extends Thread {
    @Override
    public void run() {
        try {
            Logger lo = LogManager.getLogger();
            while (true) {
                String mode = BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("BlockESP"), "Mode").getValString();
                CopyOnWriteArrayList<Blockinfo> render = new CopyOnWriteArrayList<Blockinfo>();
                ArrayList rendered = new ArrayList();
                Minecraft mc = Minecraft.func_71410_x();
                int radius = mc.field_71474_y.field_151451_c << 4;
                int minX = mc.field_71439_g.func_180425_c().func_177958_n() - radius;
                int maxX = mc.field_71439_g.func_180425_c().func_177958_n() + radius;
                int minY = Math.max(60, mc.field_71439_g.func_180425_c().func_177956_o() - 92);
                int maxY = Math.min(130, mc.field_71439_g.func_180425_c().func_177956_o() + 72);
                int minZ = mc.field_71439_g.func_180425_c().func_177952_p() - radius;
                int maxZ = mc.field_71439_g.func_180425_c().func_177952_p() + radius;
                ArrayList<Block> blackList = new ArrayList<Block>(){
                    {
                        this.add(Blocks.field_150350_a);
                        this.add(Blocks.field_150357_h);
                        this.add(Blocks.field_150348_b);
                        this.add(Blocks.field_150349_c);
                        this.add(Blocks.field_150346_d);
                    }
                };
                for (int chunkX = minX >> 4; chunkX <= maxX >> 4; ++chunkX) {
                    int x = chunkX << 4;
                    int lowBoundX = x < minX ? minX - x : 0;
                    int highBoundX = x + 15 > maxX ? maxX - x : 15;
                    for (int chunkZ = minZ >> 4; chunkZ <= maxZ >> 4; ++chunkZ) {
                        Chunk chunk = mc.field_71441_e.func_72964_e(chunkX, chunkZ);
                        if (!chunk.func_177410_o()) continue;
                        ExtendedBlockStorage[] extendsList = chunk.func_76587_i();
                        int z = chunkZ << 4;
                        int lowBoundZ = z < minZ ? minZ - z : 0;
                        int highBoundZ = z + 15 > maxZ ? maxZ - z : 15;
                        for (int curExtend = minY >> 4; curExtend <= maxY >> 4; ++curExtend) {
                            ExtendedBlockStorage ebs = extendsList[curExtend];
                            if (ebs == null) continue;
                            int y = curExtend << 4;
                            int lowBoundY = y < minY ? minY - y : 0;
                            int highBoundY = y + 15 > maxY ? maxY - y : 15;
                            for (int i = lowBoundX; i <= highBoundX; ++i) {
                                for (int j = lowBoundY; j <= highBoundY; ++j) {
                                    for (int k = lowBoundZ; k <= highBoundZ; ++k) {
                                        IBlockState currentState;
                                        block24: {
                                            currentState = ebs.func_177485_a(i, j, k);
                                            if (blackList.contains(currentState.func_177230_c())) continue;
                                            if (mode.equalsIgnoreCase("ore")) {
                                                try {
                                                    Block block = ebs.func_177485_a(i, j - 1, k).func_177230_c();
                                                    if (block.equals(Blocks.field_150350_a)) continue;
                                                    Block block2 = ebs.func_177485_a(i, j + 1, k).func_177230_c();
                                                    if (mode.equalsIgnoreCase("ore") && !block2.equals(Blocks.field_150350_a)) {
                                                    }
                                                    break block24;
                                                }
                                                catch (Throwable throwable) {
                                                    BlockPos blockPos = new BlockPos(i + x, j + y - 1, k + z);
                                                    IBlockState v = mc.field_71441_e.func_180495_p(blockPos);
                                                    if (v.func_177230_c().equals(Blocks.field_150350_a)) continue;
                                                    BlockPos vo2 = new BlockPos(i + x, j + y + 1, k + z);
                                                    IBlockState v2 = mc.field_71441_e.func_180495_p(vo2);
                                                    if (!mode.equalsIgnoreCase("ore") || v2.func_177230_c().equals(Blocks.field_150350_a)) break block24;
                                                }
                                                continue;
                                            }
                                        }
                                        if (mode.equalsIgnoreCase("ore")) {
                                            if (currentState.func_177230_c().equals(Blocks.field_150366_p)) {
                                                render.add(new Blockinfo(x + i, y + j, z + k, 0.0f, 0.5f, 1.0f));
                                                continue;
                                            }
                                            if (currentState.func_177230_c().equals(Blocks.field_150482_ag)) {
                                                render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.0f, 0.0f));
                                                continue;
                                            }
                                            if (!currentState.func_177230_c().equals(Blocks.field_150352_o)) continue;
                                            render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.9f, 0.0f));
                                            continue;
                                        }
                                        if (mode.equalsIgnoreCase("cloth")) {
                                            try {
                                                if (!currentState.equals(CommandBase.func_190794_a((Block)Blocks.field_150329_H, (String)"2"))) continue;
                                                render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.4f, 0.0f));
                                            }
                                            catch (Exception exception) {
                                                BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                            }
                                            continue;
                                        }
                                        if (mode.equalsIgnoreCase("pumpking")) {
                                            try {
                                                if (!currentState.equals(CommandBase.func_190794_a((Block)Blocks.field_185773_cZ, (String)"3"))) continue;
                                                render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.4f, 0.0f));
                                            }
                                            catch (Exception exception) {
                                                BloodWare.moduleManager.getModule("BlockESP").setToggled(false);
                                            }
                                            continue;
                                        }
                                        for (IBlockState iBlockState : BlockEsp.search_blocks) {
                                            if (!currentState.equals(iBlockState)) continue;
                                            render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.0f, 0.0f));
                                        }
                                        for (Block block : BlockEsp.search_blocks1) {
                                            if (!currentState.func_177230_c().equals(block)) continue;
                                            render.add(new Blockinfo(x + i, y + j, z + k, 1.0f, 0.0f, 0.0f));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                BlockEsp.render.clear();
                BlockEsp.render = render;
                Thread.sleep((long)(BloodWare.instance.settingsManager.getSettingByName(BloodWare.moduleManager.getModule("BlockESP"), "UpdateTime").getValDouble() * 1000.0));
            }
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
