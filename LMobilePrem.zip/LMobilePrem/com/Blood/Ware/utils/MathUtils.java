package com.Blood.Ware.utils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class MathUtils {
    public static final float deg2Rad = (float)Math.PI / 180;
    private static final Random random = new Random();

    public static double[] directionSpeedNoForward(double n) {
        Minecraft getMinecraft = Minecraft.func_71410_x();
        float moveForward = 1.0f;
        if (getMinecraft.field_71474_y.field_74370_x.func_151468_f() || getMinecraft.field_71474_y.field_74366_z.func_151468_f() || getMinecraft.field_71474_y.field_74368_y.func_151468_f() || getMinecraft.field_71474_y.field_74351_w.func_151468_f()) {
            moveForward = getMinecraft.field_71439_g.field_71158_b.field_192832_b;
        }
        float moveStrafe = getMinecraft.field_71439_g.field_71158_b.field_78902_a;
        float n2 = getMinecraft.field_71439_g.field_70126_B + (getMinecraft.field_71439_g.field_70177_z - getMinecraft.field_71439_g.field_70126_B) * getMinecraft.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                n2 += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                n2 += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(n2 + 90.0f));
        double cos = Math.cos(Math.toRadians(n2 + 90.0f));
        return new double[]{(double)moveForward * n * cos + (double)moveStrafe * n * sin, (double)moveForward * n * sin - (double)moveStrafe * n * cos};
    }

    public static boolean isInteger(Double n) {
        return n == Math.floor(n) && !Double.isInfinite(n);
    }

    public static double roundToPlace(double val, int newScale) {
        if (newScale < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(val).setScale(newScale, RoundingMode.HALF_UP).doubleValue();
    }

    public static double[] directionSpeed(double n) {
        Minecraft getMinecraft = Minecraft.func_71410_x();
        float moveForward = getMinecraft.field_71439_g.field_71158_b.field_192832_b;
        float moveStrafe = getMinecraft.field_71439_g.field_71158_b.field_78902_a;
        float n2 = getMinecraft.field_71439_g.field_70126_B + (getMinecraft.field_71439_g.field_70177_z - getMinecraft.field_71439_g.field_70126_B) * getMinecraft.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                n2 += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                n2 += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(n2 + 90.0f));
        double cos = Math.cos(Math.toRadians(n2 + 90.0f));
        return new double[]{(double)moveForward * n * cos + (double)moveStrafe * n * sin, (double)moveForward * n * sin - (double)moveStrafe * n * cos};
    }

    public static float lerp(float n, float n2, float n3) {
        return n + n3 * (n2 - n);
    }

    public static void drawUnfilledCircle(float n, float n2, float n3, float n4, int n5) {
        float n6 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n7 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n8 = (float)(n5 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        GL11.glEnable((int)2848);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GlStateManager.func_179147_l();
        GL11.glColor4f((float)n6, (float)n7, (float)n8, (float)n9);
        GL11.glLineWidth((float)n4);
        GL11.glBegin((int)2);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)((double)n + Math.sin((double)i * Math.PI / 180.0) * (double)n3), (double)((double)n2 + Math.cos((double)i * Math.PI / 180.0) * (double)n3));
        }
        GL11.glEnd();
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
        GlStateManager.func_179084_k();
    }

    public static int getRandomInRange(int n, int n2) {
        return (int)((double)n2 + (double)(n - n2) * random.nextDouble());
    }

    public static BigDecimal round(float f, double n) {
        return new BigDecimal(Float.toString(f)).setScale((int)n, 4);
    }

    public static double[] getDirection(float n) {
        return new double[]{-Math.sin(Math.toRadians(n)), Math.cos(Math.toRadians(n))};
    }

    public static double randomize(double n, double n2) {
        double d;
        double n3 = new Random().nextDouble() * (n2 - n);
        if (n3 > n2) {
            n3 = n2;
        }
        double n4 = n3 + n;
        if (d > n2) {
            n4 = n2;
        }
        return n4;
    }

    public static int randomize(int n, int n2) {
        return -n2 + (int)(Math.random() * (double)(n - -n2 + 1));
    }

    public static double random(double n, double n2) {
        return Math.random() * (n2 - n) + n;
    }

    public static float sqrt_double(double a) {
        return (float)Math.sqrt(a);
    }

    public static double roundToDecimalPlace(double n, double n2) {
        double n3 = n2 / 2.0;
        double val = Math.floor(n / n2) * n2;
        if (n >= val + n3) {
            return new BigDecimal(Math.ceil(n / n2) * n2, MathContext.DECIMAL64).stripTrailingZeros().doubleValue();
        }
        return new BigDecimal(val, MathContext.DECIMAL64).stripTrailingZeros().doubleValue();
    }

    public static float clamp(float n, float n2, float n3) {
        if (n <= n2) {
            n = n2;
        }
        if (n >= n3) {
            n = n3;
        }
        return n;
    }

    public static double degToRad(double n) {
        return n * 0.01745329238474369;
    }

    public static Vec3d interpolateVec3d(Vec3d vec3d, Vec3d vec3d2, float n) {
        return vec3d.func_178788_d(vec3d2).func_186678_a((double)n).func_178787_e(vec3d2);
    }

    public static double preciseRound(double n, double b) {
        double pow = Math.pow(10.0, b);
        return (double)Math.round(n * pow) / pow;
    }

    public static Vec3d direction(float n) {
        return new Vec3d(Math.cos(MathUtils.degToRad(n + 90.0f)), 0.0, Math.sin(MathUtils.degToRad(n + 90.0f)));
    }

    public static double randomNumber(double n, double n2) {
        return Math.random() * (n - n2) + n2;
    }

    public static double getRandomInRange(double n, double n2) {
        return n2 + (n - n2) * random.nextDouble();
    }

    public static double getNormalDouble(double val) {
        return new BigDecimal(val).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
    }

    public static double getNormalDouble(double val, int newScale) {
        return new BigDecimal(val).setScale(newScale, RoundingMode.HALF_EVEN).doubleValue();
    }

    public static boolean isEven(int n) {
        return n % 2 == 0;
    }

    public static float wrapAngleTo180_float(float n) {
        if ((n %= 360.0f) >= 180.0f) {
            n -= 360.0f;
        }
        if (n < -180.0f) {
            n += 360.0f;
        }
        return n;
    }

    public static float random(float n, float n2) {
        return (float)(Math.random() * (double)(n2 - n) + (double)n);
    }

    public static Vec3d interpolateEntity(Entity entity) {
        double n = Minecraft.func_71410_x().func_184121_ak();
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * n, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * n, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * n);
    }

    public static float[] constrainAngle(float[] array) {
        array[0] = array[0] % 360.0f;
        array[1] = array[1] % 360.0f;
        while (array[0] <= -180.0f) {
            array[0] = array[0] + 360.0f;
        }
        while (array[1] <= -180.0f) {
            array[1] = array[1] + 360.0f;
        }
        while (array[0] > 180.0f) {
            array[0] = array[0] - 360.0f;
        }
        while (array[1] > 180.0f) {
            array[1] = array[1] - 360.0f;
        }
        return array;
    }

    public static double getIncremental(double n, double n2) {
        double n3 = 1.0 / n2;
        return (double)Math.round(n * n3) / n3;
    }
}
