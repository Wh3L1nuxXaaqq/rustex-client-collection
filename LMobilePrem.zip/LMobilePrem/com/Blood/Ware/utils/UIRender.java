package com.Blood.Ware.utils;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

public class UIRender {
    public static void drawRect(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            double j = top;
            top = bottom;
            bottom = j;
        }
        float f3 = (float)(color >> 24 & 0xFF) / 255.0f;
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f2 = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)f, (float)f1, (float)f2, (float)f3);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferbuilder.func_181662_b(left, bottom, 0.0).func_181675_d();
        bufferbuilder.func_181662_b(right, bottom, 0.0).func_181675_d();
        bufferbuilder.func_181662_b(right, top, 0.0).func_181675_d();
        bufferbuilder.func_181662_b(left, top, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void bind(float f, float f2, float f3, float f4, float f5, int id) {
        GL11.glPushMatrix();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)f5);
        GlStateManager.func_179144_i((int)id);
        UIRender.a(f, f2, 0.0f, 0.0f, f3, f4, f3, f4);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GL11.glPopMatrix();
    }

    public static void a(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        float f9 = 1.0f / f7;
        float f10 = 1.0f / f8;
        Tessellator bly2 = Tessellator.func_178181_a();
        BufferBuilder ali2 = bly2.func_178180_c();
        ali2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        ali2.func_181662_b((double)f, (double)(f2 + f6), 0.0).func_187315_a((double)(f3 * f9), (double)((f4 + f6) * f10)).func_181675_d();
        ali2.func_181662_b((double)(f + f5), (double)(f2 + f6), 0.0).func_187315_a((double)((f3 + f5) * f9), (double)((f4 + f6) * f10)).func_181675_d();
        ali2.func_181662_b((double)(f + f5), (double)f2, 0.0).func_187315_a((double)((f3 + f5) * f9), (double)(f4 * f10)).func_181675_d();
        ali2.func_181662_b((double)f, (double)f2, 0.0).func_187315_a((double)(f3 * f9), (double)(f4 * f10)).func_181675_d();
        bly2.func_78381_a();
    }

    public static void bindTexture(int x, int y, int width, int height, int id) {
        GlStateManager.func_179121_F();
        GlStateManager.func_179144_i((int)id);
        Gui.func_146110_a((int)x, (int)y, (float)0.0f, (float)0.0f, (int)width, (int)height, (float)width, (float)height);
        GlStateManager.func_179084_k();
        GlStateManager.func_179094_E();
    }

    public static void setColor(int color) {
        GL11.glColor4ub((byte)((byte)(color >> 16 & 0xFF)), (byte)((byte)(color >> 8 & 0xFF)), (byte)((byte)(color & 0xFF)), (byte)((byte)(color >> 24 & 0xFF)));
    }

    public static void prepareScissorBox(int factor, float height, float x, float y, float x2, float y2) {
        GL11.glScissor((int)((int)(x * (float)factor)), (int)((int)((height - y2) * (float)factor)), (int)((int)((x2 - x) * (float)factor)), (int)((int)((y2 - y) * (float)factor)));
    }

    public static void roundedBorder(float x, float y, float x2, float y2, float radius, int color) {
        float left = x;
        float top = y;
        float bottom = y2;
        float right = x2;
        UIRender.enableGL2D();
        UIRender.setColor(color);
        GlStateManager.func_187441_d((float)2.0f);
        GL11.glBegin((int)2);
        GL11.glVertex2d((double)left, (double)(top + radius));
        GL11.glVertex2f((float)(left + radius), (float)top);
        GL11.glVertex2f((float)(right - radius), (float)top);
        GL11.glVertex2f((float)right, (float)(top + radius));
        GL11.glVertex2f((float)right, (float)(bottom - radius));
        GL11.glVertex2f((float)(right - radius), (float)bottom);
        GL11.glVertex2f((float)(left + radius), (float)bottom);
        GL11.glVertex2f((float)left, (float)(bottom - radius));
        GL11.glEnd();
        UIRender.disableGL2D();
    }

    public static void roundedBorder(float x, float y, float x2, float y2, float radius, float line, int color) {
        float left = x;
        float top = y;
        float bottom = y2;
        float right = x2;
        UIRender.enableGL2D();
        UIRender.setColor(color);
        GlStateManager.func_187441_d((float)line);
        GL11.glBegin((int)2);
        GL11.glVertex2d((double)left, (double)(top + radius));
        GL11.glVertex2f((float)(left + radius), (float)top);
        GL11.glVertex2f((float)(right - radius), (float)top);
        GL11.glVertex2f((float)right, (float)(top + radius));
        GL11.glVertex2f((float)right, (float)(bottom - radius));
        GL11.glVertex2f((float)(right - radius), (float)bottom);
        GL11.glVertex2f((float)(left + radius), (float)bottom);
        GL11.glVertex2f((float)left, (float)(bottom - radius));
        GL11.glEnd();
        UIRender.disableGL2D();
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawCircle(float x, float y, float start, float end, float radius, boolean filled, Color color) {
        float sin;
        float cos;
        float i;
        GlStateManager.func_179131_c((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        if (start > end) {
            float endOffset = end;
            end = start;
            start = endOffset;
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        UIRender.setColor(color.getRGB());
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)2.0f);
        GL11.glBegin((int)3);
        for (i = end; i >= start; i -= 4.0f) {
            cos = (float)(Math.cos((double)i * Math.PI / 180.0) * (double)radius * 1.0);
            sin = (float)(Math.sin((double)i * Math.PI / 180.0) * (double)radius * 1.0);
            GL11.glVertex2f((float)(x + cos), (float)(y + sin));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)(filled ? 6 : 3));
        for (i = end; i >= start; i -= 4.0f) {
            cos = (float)Math.cos((double)i * Math.PI / 180.0) * radius;
            sin = (float)Math.sin((double)i * Math.PI / 180.0) * radius;
            GL11.glVertex2f((float)(x + cos), (float)(y + sin));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }
}
