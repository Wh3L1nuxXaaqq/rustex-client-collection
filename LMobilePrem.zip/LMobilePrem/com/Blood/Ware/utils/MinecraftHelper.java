package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;

public interface MinecraftHelper {
    public static final Minecraft mc = Minecraft.func_71410_x();
}
