package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class ChatUtils {
    private static final String prefix = TextFormatting.GRAY + "[" + TextFormatting.BLUE + "TemaTop" + TextFormatting.GRAY + "]: " + TextFormatting.WHITE;

    public static void message(String msg) {
        Minecraft.func_71410_x().field_71439_g.func_145747_a((ITextComponent)new TextComponentString(prefix + msg));
    }
}
