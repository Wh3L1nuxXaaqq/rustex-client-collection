package com.Blood.Ware.utils.config;

import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.ChatUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class ConfigManager {
    public final String path;

    public ConfigManager() {
        this.path = new File(Minecraft.func_71410_x().field_71412_D, "FluxxClient").getPath();
        File paste_dir = new File(this.path);
        if (!paste_dir.exists()) {
            paste_dir.mkdir();
        }
    }

    public void saveCFG(String name) {
        try {
            String json = this.getJson();
            File cfg = new File(this.path + File.separator + name + ".json");
            if (!cfg.exists()) {
                try {
                    if (cfg.createNewFile()) {
                        // empty if block
                    }
                    ChatUtils.message("Created " + name + ".json");
                    ChatUtils.message("Error");
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try (FileWriter writer = new FileWriter(cfg);){
                writer.write(json);
                ChatUtils.message("Saved " + name + ".json");
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            ChatUtils.message("Error");
        }
    }

    private String getJson() {
        StringBuilder json = new StringBuilder();
        for (Module module : BloodWare.moduleManager.getModuleList()) {
            String name = module.getName();
            json.append(name);
            json.append(":");
            String toggled = String.valueOf(module.isToggled());
            json.append(toggled);
            json.append(":");
            String key = String.valueOf(module.getKey());
            json.append(key);
            json.append(":");
            ArrayList<Setting> arrayList = BloodWare.instance.settingsManager.getSettingsByMod(module);
            if (arrayList != null) {
                for (Setting setting : arrayList) {
                    String settings = setting.isCheck() ? setting.getName() + "=" + setting.getValBoolean() : (setting.isSlider() ? setting.getName() + "=" + setting.getValDouble() : setting.getName() + "=" + setting.getValString());
                    json.append(settings);
                    json.append(":");
                }
            }
            json.append(";");
        }
        return json.toString();
    }

    public void loadCFG(String name) {
        try {
            String line;
            File cfg = new File(this.path, name + ".json");
            if (!cfg.exists()) {
                ChatUtils.message("Not Found");
                return;
            }
            BufferedReader reader = new BufferedReader(new FileReader(cfg.getPath()));
            String json = line = reader.readLine();
            for (String cfg_module : json.split(";")) {
                try {
                    String[] settings;
                    if (cfg_module == null || (settings = cfg_module.split(":")).length < 2) continue;
                    String module_name = settings[0];
                    boolean module_toggled = Boolean.parseBoolean(settings[1]);
                    int module_key = Integer.parseInt(settings[2]);
                    Module module = BloodWare.moduleManager.getModule(module_name);
                    module.setToggled(module_toggled);
                    module.setKey(module_key);
                    for (int n = 3; n < settings.length; ++n) {
                        String[] cfg_setting = settings[n].split("=");
                        String setting_name = cfg_setting[0];
                        Setting setting = BloodWare.instance.settingsManager.getSettingByName(module, setting_name);
                        if (setting.isCheck()) {
                            setting.setValBoolean(Boolean.parseBoolean(cfg_setting[1]));
                            continue;
                        }
                        if (setting.isSlider()) {
                            setting.setValDouble(Double.parseDouble(cfg_setting[1]));
                            continue;
                        }
                        setting.setValString(cfg_setting[1]);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
            ChatUtils.message(name + " Loaded");
        }
        catch (Exception e) {
            e.printStackTrace();
            ChatUtils.message("Error");
            throw new RuntimeException(e);
        }
    }
}
