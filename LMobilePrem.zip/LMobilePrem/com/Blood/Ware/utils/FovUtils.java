package com.Blood.Ware.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class FovUtils {
    public static boolean isInAttackFOV(Entity entity, int fov) {
        return FovUtils.getDistanceFromMouse(entity) <= fov;
    }

    public static int getDistanceFromMouse(Entity entity) {
        float[] neededRotations = FovUtils.getNeededRotations(entity);
        if (neededRotations != null) {
            float neededYaw = Minecraft.func_71410_x().field_71439_g.field_70177_z - neededRotations[0];
            float neededPitch = Minecraft.func_71410_x().field_71439_g.field_70125_A - neededRotations[1];
            float distanceFromMouse = MathHelper.func_76129_c((float)(neededYaw * neededYaw + neededPitch * neededPitch));
            return (int)distanceFromMouse;
        }
        return -1;
    }

    private static float[] getNeededRotations(Entity vec) {
        Vec3d eyesPos = FovUtils.getEyesPos();
        double diffX = vec.field_70165_t - eyesPos.field_72450_a;
        double diffY = vec.field_70163_u - eyesPos.field_72448_b;
        double diffZ = vec.field_70161_v - eyesPos.field_72449_c;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{Minecraft.func_71410_x().field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(yaw - Minecraft.func_71410_x().field_71439_g.field_70177_z)), Minecraft.func_71410_x().field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(pitch - Minecraft.func_71410_x().field_71439_g.field_70125_A))};
    }

    private static Vec3d getEyesPos() {
        return new Vec3d(Minecraft.func_71410_x().field_71439_g.field_70165_t, Minecraft.func_71410_x().field_71439_g.field_70163_u + (double)Minecraft.func_71410_x().field_71439_g.func_70047_e(), Minecraft.func_71410_x().field_71439_g.field_70161_v);
    }

    public static String getPlayerName(EntityPlayer player) {
        return player.func_146103_bH() != null ? player.func_146103_bH().getName() : "null";
    }
}
