package com.Blood.Ware.settings;

import com.Blood.Ware.module.Module;
import java.util.ArrayList;

public class Setting
extends Castom.setting.Setting {
    private String name;
    private Module parent;
    private String mode;
    private String sval;
    private ArrayList<String> options;
    private boolean bval;
    private double dval;
    private double min;
    private double max;
    private boolean onlyint = false;

    public Setting(String name, Module parent, String sval, ArrayList<String> options) {
        this.name = name;
        this.parent = parent;
        this.sval = sval;
        this.options = options;
        this.mode = "Combo";
    }

    public Setting(String name, Module parent, boolean bval) {
        this.name = name;
        this.parent = parent;
        this.bval = bval;
        this.mode = "Check";
    }

    public Setting(String name, Module parent, double dval, double min, double max, boolean onlyint) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.min = min;
        this.max = max;
        this.onlyint = onlyint;
        this.mode = "Slider";
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Module getParentMod() {
        return this.parent;
    }

    @Override
    public String getValString() {
        return this.sval;
    }

    @Override
    public void setValString(String in) {
        this.sval = in;
    }

    @Override
    public ArrayList<String> getOptions() {
        return this.options;
    }

    @Override
    public boolean getValBoolean() {
        return this.bval;
    }

    @Override
    public void setValBoolean(boolean in) {
        this.bval = in;
    }

    @Override
    public double getValDouble() {
        if (this.onlyint) {
            this.dval = (int)this.dval;
        }
        return this.dval;
    }

    @Override
    public void setValDouble(double in) {
        this.dval = in;
    }

    @Override
    public double getMin() {
        return this.min;
    }

    @Override
    public double getMax() {
        return this.max;
    }

    @Override
    public boolean isCombo() {
        return this.mode.equalsIgnoreCase("Combo");
    }

    @Override
    public boolean isCheck() {
        return this.mode.equalsIgnoreCase("Check");
    }

    @Override
    public boolean isSlider() {
        return this.mode.equalsIgnoreCase("Slider");
    }

    @Override
    public boolean onlyInt() {
        return this.onlyint;
    }
}
