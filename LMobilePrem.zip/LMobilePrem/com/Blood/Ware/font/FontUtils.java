package com.Blood.Ware.font;

import com.Blood.Ware.font.MinecraftFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class FontUtils {
    public static volatile int completed;
    public static MinecraftFontRenderer normal;
    private static Font normal_;

    private static Font getFont(Map<String, Font> locationMap, String location, int size) {
        Font font = null;
        try {
            if (locationMap.containsKey(location)) {
                font = locationMap.get(location).deriveFont(0, size);
            } else {
                InputStream is = Minecraft.func_71410_x().func_110442_L().func_110536_a(new ResourceLocation(location)).func_110527_b();
                font = Font.createFont(0, is);
                locationMap.put(location, font);
                font = font.deriveFont(0, size);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            font = new Font("default", 0, 10);
        }
        return font;
    }

    public static boolean hasLoaded() {
        return completed >= 3;
    }

    public static void bootstrap() {
        new Thread(() -> {
            HashMap<String, Font> locationMap = new HashMap<String, Font>();
            normal_ = FontUtils.getFont(locationMap, "font.otf", 10);
            ++completed;
        }).start();
        new Thread(() -> {
            HashMap locationMap = new HashMap();
            ++completed;
        }).start();
        new Thread(() -> {
            HashMap locationMap = new HashMap();
            ++completed;
        }).start();
        while (!FontUtils.hasLoaded()) {
            try {
                Thread.sleep(5L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        normal = new MinecraftFontRenderer(normal_, true, true);
    }
}
