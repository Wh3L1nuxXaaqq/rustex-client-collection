package Castom.setting;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class DrawHelper {
    private static int test;
    protected static float zLevel;
    private static int time;
    private static boolean anim;
    private static float alpheble;
    private static float animtest;
    private static final Frustum frustrum;
    private static Minecraft mc;

    private static boolean isInViewFrustrum(AxisAlignedBB axisAlignedBB) {
        Entity getRenderViewEntity = Minecraft.func_71410_x().func_175606_aa();
        frustrum.func_78547_a(getRenderViewEntity.field_70165_t, getRenderViewEntity.field_70163_u, getRenderViewEntity.field_70161_v);
        return frustrum.func_78546_a(axisAlignedBB);
    }

    public static int toRGBA(float n, float n2, float n3, float n4) {
        return DrawHelper.toRGBA((int)(n * 255.0f), (int)(n2 * 255.0f), (int)(n3 * 255.0f), (int)(n4 * 255.0f));
    }

    public static int reAlpha(int rgb, float a) {
        Color color = new Color(rgb);
        return new Color(0.003921569f * (float)color.getRed(), 0.003921569f * (float)color.getGreen(), 0.003921569f * (float)color.getBlue(), a).getRGB();
    }

    public static void enableSmoothLine(float n) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)n);
    }

    public static void startSmooth() {
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2881);
        GL11.glEnable((int)2832);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glHint((int)3153, (int)4354);
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static Color getGradientOffset(Color color, Color color2, double n) {
        if (n > 1.0) {
            double n2 = n % 1.0;
            n = (int)n % 2 == 0 ? n2 : 1.0 - n2;
        }
        double n3 = 1.0 - n;
        return new Color((int)((double)color.getRed() * n3 + (double)color2.getRed() * n), (int)((double)color.getGreen() * n3 + (double)color2.getGreen() * n), (int)((double)color.getBlue() * n3 + (double)color2.getBlue() * n));
    }

    public static int getColor(int n, int n2, int n3) {
        return DrawHelper.getColor(n, n2, n3, 255);
    }

    public static int getColor(int n, int n2) {
        return DrawHelper.getColor(n, n, n, n2);
    }

    public static void drawRect2(double n, double n2, double n3, double n4, int n5) {
        DrawHelper.drawRect(n, n2, n + n3, n2 + n4, n5);
    }

    public static double interpolate(double n, double n2, double n3) {
        return n2 + (n - n2) * n3;
    }

    public static int getTeamColor(Entity entity) {
        return entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405cR\u043f\u0457\u0405f]\u043f\u0457\u0405c").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(255, 60, 60).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u04059B\u043f\u0457\u0405f]\u043f\u0457\u04059").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(60, 60, 255).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405eY\u043f\u0457\u0405f]\u043f\u0457\u0405e").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(255, 255, 60).getRGB()) : (entity.func_145748_c_().func_150260_c().equalsIgnoreCase(String.valueOf(new StringBuilder().append("\u043f\u0457\u0405f[\u043f\u0457\u0405aG\u043f\u0457\u0405f]\u043f\u0457\u0405a").append(entity.func_70005_c_()))) ? DrawHelper.getColor(new Color(60, 255, 60).getRGB()) : DrawHelper.getColor(new Color(255, 255, 255).getRGB()))));
    }

    public static void drawRect(double n, double n2, double n3, double n4, int n5) {
        if (n < n3) {
            double n6 = n;
            n = n3;
            n3 = n6;
        }
        if (n2 < n4) {
            double n7 = n2;
            n2 = n4;
            n4 = n7;
        }
        float n8 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n10 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n11 = (float)(n5 & 0xFF) / 255.0f;
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179131_c((float)n9, (float)n10, (float)n11, (float)n8);
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b(n, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n2, 0.0).func_181675_d();
        getBuffer.func_181662_b(n, n2, 0.0).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static int getRandomColor() {
        char[] charArray = "012345678".toCharArray();
        String value = "0x";
        for (int i = 0; i < 6; ++i) {
            value = String.valueOf(new StringBuilder().append(value).append(charArray[new Random().nextInt(charArray.length)]));
        }
        return Integer.decode(value);
    }

    public static void drawSelectionBoundingBox(AxisAlignedBB axisAlignedBB) {
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getInstance.func_78381_a();
    }

    public static int astolfoColors5(float n, float n2, float saturation, float n3) {
        float n5;
        float n4 = 1800.0f;
        for (n5 = (float)(System.currentTimeMillis() % (long)((int)n4)) + (n2 - n) * n3; n5 > n4; n5 -= n4) {
        }
        float n6 = n5 / n4;
        if ((double)n6 > 0.5) {
            n6 = 0.5f - (n6 - 0.5f);
        }
        return Color.HSBtoRGB(n6 + 0.5f, saturation, 1.0f);
    }

    public static Color TwoColoreffect(Color color, Color color2, double n) {
        float clamp = MathHelper.func_76131_a((float)((float)Math.sin(Math.PI * 6 * (n / 4.0 % 1.0)) / 2.0f + 0.5f), (float)0.0f, (float)1.0f);
        return new Color(DrawHelper.lerp((float)color.getRed() / 255.0f, (float)color2.getRed() / 255.0f, clamp), DrawHelper.lerp((float)color.getGreen() / 255.0f, (float)color2.getGreen() / 255.0f, clamp), DrawHelper.lerp((float)color.getBlue() / 255.0f, (float)color2.getBlue() / 255.0f, clamp));
    }

    public static int[] getFractionIndicies(float[] array, float n) {
        int n2;
        int[] array2 = new int[2];
        for (n2 = 0; n2 < array.length && array[n2] <= n; ++n2) {
        }
        if (n2 >= array.length) {
            n2 = array.length - 1;
        }
        array2[0] = n2 - 1;
        array2[1] = n2;
        return array2;
    }

    public static Color rainbow2(int n, float s, float b) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + (long)n) / 16L) % 360.0 / 360.0), s, b);
    }

    public static void drawImage(ResourceLocation resourceLocation, int n, int n2, int n3, int n4, int color) {
        GL11.glPushMatrix();
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        DrawHelper.setColor(color);
        mc.func_110434_K().func_110577_a(resourceLocation);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        Gui.func_146110_a((int)n, (int)n2, (float)0.0f, (float)0.0f, (int)n3, (int)n4, (float)n3, (float)n4);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        GL11.glPopMatrix();
    }

    public static void prepareScissorBox(float n, float n2, float n3, float n4) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        int getScaleFactor = scaledResolution.func_78325_e();
        GL11.glScissor((int)((int)(n * (float)getScaleFactor)), (int)((int)(((float)scaledResolution.func_78328_b() - n4) * (float)getScaleFactor)), (int)((int)((n3 - n) * (float)getScaleFactor)), (int)((int)((n4 - n2) * (float)getScaleFactor)));
    }

    public static Color astolfoColor(int n, int n2) {
        float n4;
        float n3 = 2900.0f;
        for (n4 = (float)(System.currentTimeMillis() % (long)((int)n3)) + (float)((n2 - n) * 9); n4 > n3; n4 -= n3) {
        }
        float n5 = n4 / n3;
        if ((double)n5 > 0.5) {
            n5 = 0.5f - (n5 - 0.5f);
        }
        return new Color(n5 + 0.5f, 0.5f, 1.0f);
    }

    public static void drawFilledBox(AxisAlignedBB axisAlignedBB) {
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        getInstance.func_78381_a();
    }

    public static void drawOutline(AxisAlignedBB axisAlignedBB, float n, Color color) {
        GL11.glPushMatrix();
        GL11.glLineWidth((float)n);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getBuffer.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), 100).func_181675_d();
        getInstance.func_78381_a();
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glPopMatrix();
    }

    public static int getColor(int n, int n2, int n3, int n4) {
        return 0 | n4 << 24 | n << 16 | n2 << 8 | n3;
    }

    public static int rainbow(int n, float s, float b) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + (long)n) / 16L) % 360.0 / 360.0), s, b).getRGB();
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static Color getRainbow(int n, int n2) {
        return Color.getHSBColor((float)((System.currentTimeMillis() + (long)n) % (long)n2) / (float)n2, 0.7f, 1.0f);
    }

    public static float lerp(float n, float n2, float n3) {
        return n + n3 * (n2 - n);
    }

    public static void glColor(Color color, int n) {
        DrawHelper.glColor(color, (float)n / 255.0f);
    }

    public static void endSmooth() {
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2881);
        GL11.glEnable((int)2832);
    }

    public static void drawGradientSideways(double n, double n2, double n3, double n4, int n5, int n6) {
        float n7 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n10 = (float)(n5 & 0xFF) / 255.0f;
        float n11 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n12 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n13 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n14 = (float)(n6 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)n8, (float)n9, (float)n10, (float)n7);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glColor4f((float)n12, (float)n13, (float)n14, (float)n11);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawVGradientRect(float n, float n2, float n3, float n4, int n5, int n6) {
        float n7 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n10 = (float)(n5 & 0xFF) / 255.0f;
        float n11 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n12 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n13 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n14 = (float)(n6 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        getBuffer.func_181662_b((double)n3, (double)n2, 0.0).func_181666_a(n8, n9, n10, n7).func_181675_d();
        getBuffer.func_181662_b((double)n, (double)n2, 0.0).func_181666_a(n8, n9, n10, n7).func_181675_d();
        getBuffer.func_181662_b((double)n, (double)n4, 0.0).func_181666_a(n12, n13, n14, n11).func_181675_d();
        getBuffer.func_181662_b((double)n3, (double)n4, 0.0).func_181666_a(n12, n13, n14, n11).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int getColor(int n) {
        return DrawHelper.getColor(n, n, n, 255);
    }

    public static Color blend(Color color, Color color2, double n) {
        float n2 = (float)n;
        float n3 = 1.0f - n2;
        float[] compArray = new float[3];
        float[] compArray2 = new float[3];
        color.getColorComponents(compArray);
        color2.getColorComponents(compArray2);
        float r = compArray[0] * n2 + compArray2[0] * n3;
        float g = compArray[1] * n2 + compArray2[1] * n3;
        float b = compArray[2] * n2 + compArray2[2] * n3;
        if (r < 0.0f) {
            r = 0.0f;
        } else if (r > 255.0f) {
            r = 255.0f;
        }
        if (g < 0.0f) {
            g = 0.0f;
        } else if (g > 255.0f) {
            g = 255.0f;
        }
        if (b < 0.0f) {
            b = 0.0f;
        } else if (b > 255.0f) {
            b = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(r, g, b);
        }
        catch (IllegalArgumentException ex) {
            NumberFormat.getNumberInstance();
        }
        return color3;
    }

    public static void drawNewRect(double n, double n2, double n3, double n4, int n5) {
        if (n < n3) {
            double n6 = n;
            n = n3;
            n3 = n6;
        }
        if (n2 < n4) {
            double n7 = n2;
            n2 = n4;
            n4 = n7;
        }
        float n8 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n10 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n11 = (float)(n5 & 0xFF) / 255.0f;
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179131_c((float)n9, (float)n10, (float)n11, (float)n8);
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        getBuffer.func_181662_b(n, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n4, 0.0).func_181675_d();
        getBuffer.func_181662_b(n3, n2, 0.0).func_181675_d();
        getBuffer.func_181662_b(n, n2, 0.0).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void glColor(Color color, float n) {
        GlStateManager.func_179131_c((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)n);
    }

    public static Color fade(Color color, int n, int n2) {
        float[] hsbvals = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsbvals);
        hsbvals[2] = (0.5f + 0.5f * Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0f + (float)n / (float)n2 * 2.0f) % 2.0f - 1.0f)) % 2.0f;
        return new Color(Color.HSBtoRGB(hsbvals[0], hsbvals[1], hsbvals[2]));
    }

    public static int setColor(int n) {
        float n2 = (float)(n >> 24 & 0xFF) / 255.0f;
        GL11.glColor4f((float)((float)(n >> 16 & 0xFF) / 255.0f), (float)((float)(n >> 8 & 0xFF) / 255.0f), (float)((float)(n & 0xFF) / 255.0f), (float)(n2 == 0.0f ? 1.0f : n2));
        return n;
    }

    public static Color getHealthColor(EntityLivingBase entityLivingBase) {
        float getHealth = entityLivingBase.func_110143_aJ();
        float[] array = new float[]{0.0f, 0.15f, 0.55f, 0.7f, 0.9f};
        Color[] array2 = new Color[]{new Color(133, 0, 0), Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        float n = getHealth / entityLivingBase.func_110138_aP();
        return getHealth >= 0.0f ? DrawHelper.blendColors(array, array2, n).brighter() : array2[0];
    }

    public static void drawHead(ResourceLocation resourceLocation, int n, int n2, int n3, int n4) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        mc.func_110434_K().func_110577_a(resourceLocation);
        Gui.func_152125_a((int)n, (int)n2, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)n3, (int)n4, (float)64.0f, (float)64.0f);
    }

    public static void drawFilledCircle(int n, int n2, float n3, Color color) {
        int n4 = 50;
        double n5 = 0.12566370614359174;
        GL11.glPushAttrib((int)8192);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        for (int i = 0; i < 50; ++i) {
            float n6 = (float)((double)n3 * Math.sin((double)i * 0.12566370614359174));
            float n7 = (float)((double)n3 * Math.cos((double)i * 0.12566370614359174));
            GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            GL11.glVertex2f((float)((float)n + n6), (float)((float)n2 + n7));
        }
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glEnd();
        GL11.glPopAttrib();
    }

    public static void drawGradientRect(double n, double n2, double n3, double n4, int n5, int n6) {
        float n7 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n10 = (float)(n5 & 0xFF) / 255.0f;
        float n11 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n12 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n13 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n14 = (float)(n6 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        getBuffer.func_181662_b(n3, n2, (double)zLevel).func_181666_a(n8, n9, n10, n7).func_181675_d();
        getBuffer.func_181662_b(n, n2, (double)zLevel).func_181666_a(n8, n9, n10, n7).func_181675_d();
        getBuffer.func_181662_b(n, n4, (double)zLevel).func_181666_a(n12, n13, n14, n11).func_181675_d();
        getBuffer.func_181662_b(n3, n4, (double)zLevel).func_181666_a(n12, n13, n14, n11).func_181675_d();
        getInstance.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int astolfoColors4(float n, float n2, float saturation) {
        float n4;
        float n3 = 1800.0f;
        for (n4 = (float)(System.currentTimeMillis() % (long)((int)n3)) + (n2 - n) * 12.0f; n4 > n3; n4 -= n3) {
        }
        float n5 = n4 / n3;
        if ((double)n5 > 0.5) {
            n5 = 0.5f - (n5 - 0.5f);
        }
        return Color.HSBtoRGB(n5 + 0.5f, saturation, 1.0f);
    }

    public static Color setAlpha(Color color, int clamp) {
        clamp = MathHelper.func_76125_a((int)clamp, (int)0, (int)255);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), clamp);
    }

    public static void drawPolygonPart(double n, double n2, int n3, int n4, int n5, int n6) {
        float n7 = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float n8 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float n9 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float n10 = (float)(n5 & 0xFF) / 255.0f;
        float n11 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float n12 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float n13 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float n14 = (float)(n6 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator getInstance = Tessellator.func_178181_a();
        BufferBuilder getBuffer = getInstance.func_178180_c();
        getBuffer.func_181668_a(6, DefaultVertexFormats.field_181706_f);
        getBuffer.func_181662_b(n, n2, 0.0).func_181666_a(n8, n9, n10, n7).func_181675_d();
        for (int i = n4 * 90; i <= n4 * 90 + 90; ++i) {
            double n15 = Math.PI * 2 * (double)i / 360.0 + Math.toRadians(180.0);
            getBuffer.func_181662_b(n + Math.sin(n15) * (double)n3, n2 + Math.cos(n15) * (double)n3, 0.0).func_181666_a(n12, n13, n14, n11).func_181675_d();
        }
        getInstance.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static boolean isInViewFrustrum(Entity entity) {
        return DrawHelper.isInViewFrustrum(entity.func_174813_aQ()) || entity.field_70158_ak;
    }

    public static Color blendColors(float[] array, Color[] array2, float n) {
        if (array == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (array2 == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (array.length != array2.length) {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        int[] fractionIndicies = DrawHelper.getFractionIndicies(array, n);
        float[] array3 = new float[]{array[fractionIndicies[0]], array[fractionIndicies[1]]};
        Color[] array4 = new Color[]{array2[fractionIndicies[0]], array2[fractionIndicies[1]]};
        return DrawHelper.blend(array4[0], array4[1], 1.0f - (n - array3[0]) / (array3[1] - array3[0]));
    }

    public static int astolfoColors(int n, int n2) {
        float f;
        float n4;
        float n3 = 2900.0f;
        for (n4 = (float)(System.currentTimeMillis() % (long)((int)n3)) + (float)((n2 - n) * 9); n4 > n3; n4 -= n3) {
        }
        float n5 = n4 / n3;
        if ((double)f > 0.5) {
            n5 = 0.5f - (n5 - 0.5f);
        }
        return Color.HSBtoRGB(n5 + 0.5f, 0.5f, 1.0f);
    }

    public static final void drawSmoothRect(float n, float n2, float n3, float n4, int n5) {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        DrawHelper.drawRect(n, n2, n3, n4, n5);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        DrawHelper.drawRect(n * 2.0f - 1.0f, n2 * 2.0f, n * 2.0f, n4 * 2.0f - 1.0f, n5);
        DrawHelper.drawRect(n * 2.0f, n2 * 2.0f - 1.0f, n3 * 2.0f, n2 * 2.0f, n5);
        DrawHelper.drawRect(n3 * 2.0f, n2 * 2.0f, n3 * 2.0f + 1.0f, n4 * 2.0f - 1.0f, n5);
        DrawHelper.drawRect(n * 2.0f, n4 * 2.0f - 1.0f, n3 * 2.0f, n4 * 2.0f, n5);
        GL11.glDisable((int)3042);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
    }

    public static Color astolfoColors45(float n, float n2, float s, float n3) {
        float n5;
        float n4 = 1800.0f;
        for (n5 = (float)(System.currentTimeMillis() % (long)((int)n4)) + (n2 - n) * n3; n5 > n4; n5 -= n4) {
        }
        float n6 = n5 / n4;
        if ((double)n6 > 0.5) {
            n6 = 0.5f - (n6 - 0.5f);
        }
        return Color.getHSBColor(n6 + 0.5f, s, 1.0f);
    }

    public static int toRGBA(int n, int n2, int n3, int n4) {
        return (n << 16) + (n2 << 8) + (n3 << 0) + (n4 << 24);
    }

    public static final void color(double n, double n2, double n3, double n4) {
        GL11.glColor4d((double)n, (double)n2, (double)n3, (double)n4);
    }

    public static int color(int r, int g, int b, int a) {
        a = 255;
        return new Color(r, g, b, a).getRGB();
    }

    public static final void color(Color white) {
        if (white == null) {
            white = Color.white;
        }
        DrawHelper.color((float)white.getRed() / 255.0f, (float)white.getGreen() / 255.0f, (float)white.getBlue() / 255.0f, (float)white.getAlpha() / 255.0f);
    }

    public static void drawGlow(double n, double n2, double n3, double n4, int n5) {
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        DrawHelper.drawVGradientRect((int)n, (int)n2, (int)n3, (int)(n2 + (n4 - n2) / 2.0), DrawHelper.setAlpha(new Color(n5), 0).getRGB(), n5);
        DrawHelper.drawVGradientRect((int)n, (int)(n2 + (n4 - n2) / 2.0), (int)n3, (int)n4, n5, DrawHelper.setAlpha(new Color(n5), 0).getRGB());
        int n6 = (int)((n4 - n2) / 2.0);
        DrawHelper.drawPolygonPart(n, n2 + (n4 - n2) / 2.0, n6, 0, n5, DrawHelper.setAlpha(new Color(n5), 0).getRGB());
        DrawHelper.drawPolygonPart(n, n2 + (n4 - n2) / 2.0, n6, 1, n5, DrawHelper.setAlpha(new Color(n5), 0).getRGB());
        DrawHelper.drawPolygonPart(n3, n2 + (n4 - n2) / 2.0, n6, 2, n5, DrawHelper.setAlpha(new Color(n5), 0).getRGB());
        DrawHelper.drawPolygonPart(n3, n2 + (n4 - n2) / 2.0, n6, 3, n5, DrawHelper.setAlpha(new Color(n5), 0).getRGB());
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static int astolfo(int n, float n2) {
        float f;
        float abs;
        float n3 = 3000.0f;
        for (abs = Math.abs((float)(System.currentTimeMillis() % (long)n) + -n2 / 21.0f * 2.0f); abs > n3; abs -= n3) {
        }
        float n4 = abs / n3;
        if ((double)f > 0.5) {
            n4 = 0.5f - (n4 - 0.5f);
        }
        return Color.HSBtoRGB(n4 + 0.5f, 0.5f, 1.0f);
    }

    static {
        mc = Minecraft.func_71410_x();
        frustrum = new Frustum();
    }

    public static class Colors {
        public static final int RED;
        public static final int BLUE;
        public static final int BLACK;
        public static final int GRAY;
        public static final int DARK_RED;
        public static final int PURPLE;
        public static final int ORANGE;
        public static final int WHITE;
        public static final int YELLOW;
        public static final int GREEN;

        static {
            WHITE = DrawHelper.toRGBA(255, 255, 255, 255);
            BLACK = DrawHelper.toRGBA(0, 0, 0, 255);
            RED = DrawHelper.toRGBA(255, 0, 0, 255);
            GREEN = DrawHelper.toRGBA(0, 255, 0, 255);
            BLUE = DrawHelper.toRGBA(0, 0, 255, 255);
            ORANGE = DrawHelper.toRGBA(255, 128, 0, 255);
            PURPLE = DrawHelper.toRGBA(163, 73, 163, 255);
            GRAY = DrawHelper.toRGBA(127, 127, 127, 255);
            DARK_RED = DrawHelper.toRGBA(64, 0, 0, 255);
            YELLOW = DrawHelper.toRGBA(255, 255, 0, 255);
        }
    }
}
