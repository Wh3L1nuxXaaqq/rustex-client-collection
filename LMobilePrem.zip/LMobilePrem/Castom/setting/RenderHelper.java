package Castom.setting;

import Castom.setting.DrawHelper;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class RenderHelper {
    public static void customScaledObject2D(float n, float n2, float n3, float n4, float n5, float n6) {
        GL11.glTranslated((double)(n3 / 2.0f), (double)(n4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-n * n5 + n + n3 / 2.0f * -n5), (double)(-n2 * n6 + n2 + n4 / 2.0f * -n6), (double)1.0);
        GL11.glScaled((double)n5, (double)n6, (double)0.0);
    }

    public static void enableGL2D() {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
    }

    public static void disableGL2D() {
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawFullCircle(double n, double n2, double n3, int n4) {
        n3 *= 2.0;
        n *= 2.0;
        n2 *= 2.0;
        float n5 = (float)(n4 >> 24 & 0xFF) / 255.0f;
        float n6 = (float)(n4 >> 16 & 0xFF) / 255.0f;
        float n7 = (float)(n4 >> 8 & 0xFF) / 255.0f;
        float n8 = (float)(n4 & 0xFF) / 255.0f;
        RenderHelper.enableGL2D();
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        GL11.glColor4f((float)n6, (float)n7, (float)n8, (float)n5);
        GL11.glBegin((int)6);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)(n + Math.sin((double)i * Math.PI / 180.0) * n3), (double)(n2 + Math.cos((double)i * Math.PI / 180.0) * n3));
        }
        GL11.glEnd();
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        RenderHelper.disableGL2D();
    }

    public static void customScaledObject2D(float n, float n2, float n3, float n4, float n5) {
        GL11.glTranslated((double)(n3 / 2.0f), (double)(n4 / 2.0f), (double)1.0);
        GL11.glTranslated((double)(-n * n5 + n + n3 / 2.0f * -n5), (double)(-n2 * n5 + n2 + n4 / 2.0f * -n5), (double)1.0);
        GL11.glScaled((double)n5, (double)n5, (double)0.0);
    }

    public static void drawImage(ResourceLocation resourceLocation, float n, float n2, float n3, float n4, Color color) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        DrawHelper.setColor(color.getRGB());
        Gui.func_146110_a((int)((int)n), (int)((int)n2), (float)0.0f, (float)0.0f, (int)((int)n3), (int)((int)n4), (float)n3, (float)n4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }
}
