package Castom;

import Castom.comp.CheckBox;
import Castom.comp.Combo;
import Castom.comp.Comp;
import Castom.comp.Slider;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.MathUtils;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Mouse;

public class CastomGui
extends GuiScreen {
    private float curAlpha;
    public Category selectedCategory;
    public static boolean binding;
    public double field_146294_l;
    public ArrayList comps = new ArrayList();
    private static RenderItem itemRender;
    float anim = 0.0f;
    public int modeIndex;
    public double dragX;
    public double x;
    public double posX = this.getScaledRes().func_78326_a() / 2 - 150;
    public double posY = this.getScaledRes().func_78328_b() / 2 - 100;
    public double field_146295_m;
    public double dragY;
    public boolean dragging = false;
    public double y;
    private boolean editing;
    private Module selectedModule;
    public Module mod;

    public void setBinding(boolean binding) {
        CastomGui.binding = binding;
    }

    protected void func_73864_a(int n, int n2, int n3) throws IOException {
        super.func_73864_a(n, n2, n3);
        if (this.isInside(n, n2, this.posX, this.posY - 10.0, this.field_146294_l, this.posY) && n3 == 0) {
            this.dragging = true;
            this.dragX = (double)n - this.posX;
            this.dragY = (double)n2 - this.posY;
        }
        int n4 = 0;
        for (Category selectedCategory : Category.values()) {
            if (this.isInside(n, n2, this.posX, this.posY + 1.0 + (double)n4, this.posX + 60.0, this.posY + 15.0 + (double)n4) && n3 == 0) {
                this.selectedCategory = selectedCategory;
            }
            n4 += 15;
        }
        int n5 = 0;
        for (Module selectedModule : BloodWare.moduleManager.getModules(this.selectedCategory)) {
            if (this.isInside(n, n2, this.posX + 65.0, this.posY + 1.0 + (double)n5, this.posX + 125.0, this.posY + 15.0 + (double)n5)) {
                if (n3 == 0) {
                    selectedModule.toggle();
                }
                if (n3 == 1) {
                    int n6 = 3;
                    this.comps.clear();
                    if (BloodWare.instance.settingsManager.getSettingsByMod(selectedModule) != null) {
                        for (Setting setting : BloodWare.instance.settingsManager.getSettingsByMod(selectedModule)) {
                            this.selectedModule = selectedModule;
                            this.setBinding(true);
                            if (setting.isCombo()) {
                                this.comps.add(new Combo(275.0, n6, this, this.selectedModule, setting));
                                n6 += 15;
                            }
                            if (setting.isCheck()) {
                                this.comps.add(new CheckBox(275.0, n6, this, this.selectedModule, setting));
                                n6 += 13;
                            }
                            if (!setting.isSlider()) continue;
                            this.comps.add(new Slider(275.0, n6, this, this.selectedModule, setting));
                            n6 += 18;
                        }
                    }
                }
            }
            n5 += 15;
        }
        Iterator iterator3 = this.comps.iterator();
        while (iterator3.hasNext()) {
            ((Comp)iterator3.next()).mouseClicked(n, n2, n3);
        }
    }

    public boolean isInside(int n, int n2, double n3, double n4, double n5, double n6) {
        return (double)n > n3 && (double)n < n5 && (double)n2 > n4 && (double)n2 < n6;
    }

    public void func_73866_w_() {
        super.func_73866_w_();
        this.anim = 0.0f;
        this.dragging = false;
    }

    public void setEditing(boolean editing) {
        this.editing = editing;
    }

    public void func_73863_a(int n, int n2, float n3) {
        super.func_73863_a(n, n2, n3);
        if (this.dragging) {
            this.posX = (double)n - this.dragX;
            this.posY = (double)n2 - this.dragY;
        }
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m = this.posY + 380.0;
        float n4 = 255.0f;
        boolean n5 = true;
        if (this.curAlpha < 254.0f) {
            this.curAlpha += 1.0f;
        } else if (this.curAlpha > 254.0f && this.curAlpha != 255.0f) {
            this.curAlpha = 255.0f;
        } else if (this.curAlpha != 255.0f) {
            this.curAlpha = 255.0f;
        }
        this.anim = MathUtils.lerp(this.anim, 1.0f, 0.13f);
        RenderUtil.drawRect(this.posX - 1.0, this.posY - 6.0, this.field_146294_l + 1.0, this.field_146295_m + 1.0, ClickGUI.getColor());
        RenderUtil.drawRect(this.posX, this.posY, this.field_146294_l, this.field_146295_m, new Color(45, 45, 45, 249).getRGB());
        int n6 = 0;
        for (Category category : Category.values()) {
            RenderUtil.drawRect(this.posX, this.posY + 1.0 + (double)n6, this.posX + 60.0, this.posY + 15.0 + (double)n6, category.equals((Object)this.selectedCategory) ? new Color(46, 85, 243, 156).getRGB() : new Color(28, 28, 28, 250).getRGB());
            CastomFontUtils.fr3.drawString(category.name(), (int)this.posX + 2, (int)(this.posY + 5.0) + n6, new Color(170, 170, 170).getRGB());
            n6 += 15;
        }
        int n7 = 0;
        for (Module module : BloodWare.moduleManager.getModules(this.selectedCategory)) {
            RenderUtil.drawRect(this.posX + 65.0, this.posY + 1.0 + (double)n7, this.posX + 150.0, this.posY + 15.0 + (double)n7, module.isToggled() ? new Color(46, 85, 234, 155).getRGB() : new Color(28, 28, 28, 249).getRGB());
            CastomFontUtils.fr3.drawString(module.getName(), (int)this.posX + 67, (int)(this.posY + 5.0) + n7, new Color(170, 170, 170).getRGB());
            n7 += 15;
        }
        Gui.func_73734_a((int)((int)(this.posX + 455.0)), (int)((int)(this.posY + 360.0)), (int)((int)(this.posX + 323.0)), (int)((int)(this.posY + 320.5)), (int)new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr.drawStringWithShadow("LooseOne ", (float)(this.posX + 353.0), (float)(this.posY + 329.0), ClickGUI.getColor());
        Gui.func_73734_a((int)((int)(this.posX + 300.0)), (int)((int)(this.posY + 370.0)), (int)((int)(this.posX + 200.0)), (int)((int)(this.posY + 2.0)), (int)new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr.drawStringWithShadow("Name:" + this.field_146297_k.func_110432_I().func_111285_a(), (float)(this.posX + 353.0), (float)(this.posY + 339.5), Color.white.getRGB());
        try {
            this.field_146297_k.func_110434_K().func_110577_a(Objects.requireNonNull(this.field_146297_k.func_147114_u()).func_175102_a(this.field_146297_k.field_71439_g.func_110124_au()).func_178837_g());
            Gui.func_152125_a((int)((int)(this.posX + 328.0)), (int)((int)(this.posY + 330.0)), (float)8.0f, (float)8.0f, (int)8, (int)8, (int)22, (int)22, (float)64.0f, (float)64.0f);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        Iterator iterator2 = this.comps.iterator();
        while (iterator2.hasNext()) {
            ((Comp)iterator2.next()).drawScreen(n, n2);
        }
        this.drawinfo(n, n2);
        this.player();
    }

    public ScaledResolution getScaledRes() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    public boolean isEditing() {
        return this.editing;
    }

    public void player() {
        try {
            this.field_146297_k.func_110434_K().func_110577_a(Objects.requireNonNull(this.field_146297_k.func_147114_u()).func_175102_a(this.field_146297_k.field_71439_g.func_110124_au()).func_178837_g());
            RenderUtils.renderEntity((EntityLivingBase)this.field_146297_k.field_71439_g, 70, (int)(this.posX + 375.0), (int)(this.posY + 230.0));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void drawinfo(int mouseX, int mouseY) {
        int xpos = (int)(this.posX + 511.0);
        int ypos = (int)(this.posY + 18.0);
        int g = 5;
        RenderUtil.drawRect(this.posX + 636.0, this.posY - 6.0, this.field_146294_l + 29.0, this.field_146295_m + 1.0, ClickGUI.getColor());
        RenderUtil.drawRect(this.posX + 635.0, this.posY, this.field_146294_l + 30.0, this.field_146295_m, new Color(31, 31, 31, 250).getRGB());
        CastomFontUtils.fr2.drawStringWithShadow("Freands", (float)(this.posX + 540.0), (float)(this.posY + 10.0), Color.white.getRGB());
        for (String friends : FriendManager.FRIENDS) {
            int butX1 = 0 + xpos;
            int butX2 = 100 + xpos;
            int butY1 = g + ypos;
            int butY2 = g + this.field_146289_q.field_78288_b + ypos;
            if (mouseX > butX1 && mouseX < butX2 && mouseY > butY1 && mouseY < butY2) {
                CastomFontUtils.fr2.drawString(friends, xpos + 50 - this.field_146289_q.func_78256_a(friends) / 2, g + ypos, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(friends);
                    return;
                }
            } else {
                CastomFontUtils.fr2.drawString(friends, xpos + 50 - this.field_146289_q.func_78256_a(friends) / 2, g + ypos, Color.white.getRGB());
            }
            g += this.field_146289_q.field_78288_b;
        }
    }

    protected void func_146286_b(int n, int n2, int n3) {
        super.func_146286_b(n, n2, n3);
        this.dragging = false;
        Iterator iterator = this.comps.iterator();
        while (iterator.hasNext()) {
            ((Comp)iterator.next()).mouseReleased(n, n2, n3);
        }
    }

    protected void func_73869_a(char c, int n) throws IOException {
        super.func_73869_a(c, n);
        Iterator iterator = this.comps.iterator();
        while (iterator.hasNext()) {
            ((Comp)iterator.next()).keyTyped(c, n);
        }
    }

    public CastomGui() {
        this.field_146294_l = this.posX + 456.0;
        this.field_146295_m += 380.0;
        this.selectedCategory = Category.COMBAT;
        this.x = 100.0;
        this.y = 200.0;
    }

    static {
        itemRender = Minecraft.func_71410_x().func_175599_af();
    }
}
