package Castom.comp;

import Castom.CastomGui;
import Castom.comp.Comp;
import Castom.setting.Setting;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.utils.Font.CastomFontUtils;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;

public class CheckBox
extends Comp {
    @Override
    public void mouseClicked(int n, int n2, int n3) {
        super.mouseClicked(n, n2, n3);
        if (this.isInside(n, n2, this.parent.posX + this.x - 70.0, this.parent.posY + this.y, this.parent.posX + this.x + 10.0 - 70.0, this.parent.posY + this.y + 8.5) && n3 == 0) {
            this.setting.setValBoolean(!this.setting.getValBoolean());
        }
    }

    public CheckBox(double x, double y, CastomGui parent, Module module, Setting setting) {
        this.x = x;
        this.y = y;
        this.parent = parent;
        this.module = module;
        this.setting = setting;
    }

    @Override
    public void drawScreen(int n, int n2) {
        super.drawScreen(n, n2);
        RenderUtil.drawRect(this.parent.posX + this.x - 70.0, this.parent.posY + this.y, this.parent.posX + this.x + 10.0 - 70.0, this.parent.posY + this.y + 8.5, this.setting.getValBoolean() ? new Color(10, 179, 230).getRGB() : new Color(61, 61, 61).getRGB());
        CastomFontUtils.fr2.drawString(this.setting.getName(), (int)(this.parent.posX + this.x - 55.0), (int)(this.parent.posY + this.y + 0.5), new Color(200, 200, 200).getRGB());
    }
}
