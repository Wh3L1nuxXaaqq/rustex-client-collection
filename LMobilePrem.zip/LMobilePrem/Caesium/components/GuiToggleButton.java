package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.RenderUtil;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GuiToggleButton
implements GuiComponent {
    private String text;
    private boolean toggled;
    private int posX;
    private int posY;
    private ArrayList<ActionListener> clickListeners = new ArrayList();

    public GuiToggleButton(String text) {
        this.text = text;
    }

    @Override
    public void render(int posX, int posY, int width, int mouseX, int mouseY, int wheelY) {
        this.posX = posX;
        this.posY = posY;
        switch (Panel.theme) {
            case "Caesium": {
                this.renderCaesium(posX, posY);
            }
        }
    }

    private void renderCaesium(int posX, int posY) {
        RenderUtil.drawFilledCircle(posX + 8, posY + 7, 6.0f, new Color(ClickGUI.getColor()));
        if (!this.toggled) {
            RenderUtil.drawFilledCircle(posX + 8, posY + 7, 5.0f, new Color(Panel.grey40_240));
        }
        Panel.fR.func_175063_a(this.text, (float)(posX + 17), (float)(posY + 3), Panel.fontColor);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        int width = Panel.fR.func_78256_a(this.text) + 10;
        if (Caesium.util.RenderUtil.isHovered(this.posX, this.posY + 2, width, this.getHeight(), mouseX, mouseY)) {
            this.toggled = !this.toggled;
            for (ActionListener listener : this.clickListeners) {
                listener.actionPerformed(new ActionEvent(this, this.hashCode(), "click", System.currentTimeMillis(), 0));
            }
        }
    }

    @Override
    public void keyTyped(int keyCode, char typedChar) {
    }

    @Override
    public int getWidth() {
        return Panel.fR.func_78256_a(this.text) + 20;
    }

    @Override
    public int getHeight() {
        return Panel.fR.field_78288_b + 5;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public void setToggled(boolean toggled) {
        this.toggled = toggled;
    }

    public void addClickListener(ActionListener actionlistener) {
        this.clickListeners.add(actionlistener);
    }
}
