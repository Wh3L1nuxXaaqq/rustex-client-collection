package Caesium.components;

import Caesium.Panel;
import Caesium.components.GuiComponent;

public class GuiLabel
implements GuiComponent {
    private String text;

    public GuiLabel(String text) {
        this.text = text;
    }

    @Override
    public void render(int posX, int posY, int width, int mouseX, int mouseY, int wheelY) {
        Panel.fR.func_175063_a(this.text, (float)(posX + width / 2 - Panel.fR.func_78256_a(this.text) / 2), (float)(posY + 2), Panel.fontColor);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
    }

    @Override
    public void keyTyped(int keyCode, char typedChar) {
    }

    @Override
    public int getWidth() {
        return Panel.fR.func_78256_a(this.text) + 4;
    }

    @Override
    public int getHeight() {
        return Panel.fR.field_78288_b + 2;
    }

    @Override
    public boolean allowScroll() {
        return true;
    }
}
