package Bobr.buttons;

import Bobr.buttons.CSButton;
import Bobr.buttons.setting.CSSetting;
import Bobr.buttons.setting.settings.CSSettingCheck;
import Bobr.buttons.setting.settings.CSSettingCombo;
import Bobr.buttons.setting.settings.CSSettingDouble;
import Bobr.buttons.setting.settings.KeyBind;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.settings.Setting;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class CSModButton
extends CSButton {
    public static String old_name;
    public Module mod;
    public static boolean first;
    public static boolean binding;
    public ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
    public ArrayList<CSSetting> settings = new ArrayList();

    public CSModButton(int x, int y, int width, int height, int color, String displayString, Module mod) {
        super(x, y, width, height, color, displayString);
        this.mod = mod;
        this.initSettings();
    }

    private void initSettings() {
        int y = 110;
        int x = this.x + 100;
        for (int i = 0; i < BloodWare.instance.settingsManager.getSettings().size(); ++i) {
            Setting s = BloodWare.instance.settingsManager.getSettings().get(i);
            if (s.getParentMod() != this.mod) continue;
            if (s.isCheck()) {
                CSSettingCheck check = new CSSettingCheck(x, y, y, x, s);
                this.settings.add(check);
                y += 13;
            }
            if (s.isSlider()) {
                CSSettingDouble doubleset = new CSSettingDouble(x, y, 0, 0, s);
                this.settings.add(doubleset);
                y += 15;
            }
            if (s.isCombo()) {
                int yplus = y;
                CSSettingCombo combo = new CSSettingCombo(x, y, 70, this.mc.field_71466_p.field_78288_b + 2, s);
                this.settings.add(combo);
                for (int i1 = 0; i1 < s.getOptions().size(); ++i1) {
                    if ((y += this.fr.field_78288_b + 2) <= 100 + this.sr.func_78326_a() - 220) continue;
                    y = 0;
                    x += this.mc.field_71466_p.func_78256_a(s.getName()) + 50;
                }
                y += this.fr.field_78288_b + 5;
            }
            if (y <= 100 + this.sr.func_78326_a() - 220) continue;
            y = 0;
            x += this.mc.field_71466_p.func_78256_a(s.getName()) + 50;
        }
        KeyBind key = new KeyBind(x, y, 70, this.mc.field_71466_p.field_78288_b + 2, this.mod);
        this.settings.add(key);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int color;
        int n = color = this.isHovered(mouseX, mouseY) ? ClickGUI.getColor() : -1;
        if (this.mod.isToggled()) {
            color = ClickGUI.getColor();
        }
        if (this.isCurrentMod()) {
            color = ClickGUI.getColor();
        }
        this.fr.func_78276_b(this.displayString, this.x, this.y, color);
        for (CSSetting cs : this.settings) {
            if (!this.isCurrentMod()) continue;
            cs.drawScreen(mouseX, mouseY, partialTicks);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    public void setBinding(boolean binding) {
        CSModButton.binding = binding;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        block4: {
            block5: {
                if (!this.isHovered(mouseX, mouseY)) break block4;
                if (mouseButton != 0 || !this.isHovered(mouseX, mouseY)) break block5;
                if (BloodWare.bobrGui.currentCategory == null) break block5;
                if (BloodWare.bobrGui.currentCategory.category != this.mod.getCategory()) break block5;
                this.mod.toggle();
                break block4;
            }
            if (mouseButton != 2 || !this.isHovered(mouseX, mouseY)) ** GOTO lbl-1000
            if (BloodWare.bobrGui.currentCategory == null) ** GOTO lbl-1000
            if (BloodWare.bobrGui.currentCategory.category == this.mod.getCategory()) {
                this.setBinding(true);
            } else if (mouseButton == 1) {
                // empty if block
            }
        }
        for (CSSetting cs : this.settings) {
            if (!this.isCurrentMod()) continue;
            cs.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public boolean isHovered(int mouseX, int mouseY) {
        boolean hoveredx = mouseX > this.x && mouseX < this.x + this.width;
        boolean hoveredy = mouseY > this.y && mouseY < this.y + this.height;
        return hoveredx && hoveredy;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean isCurrentMod() {
        if (BloodWare.bobrGui.currentCategory == null) return false;
        if (BloodWare.bobrGui.currentCategory.currentMod == null) return false;
        if (BloodWare.bobrGui.currentCategory.currentMod != this) return false;
        return true;
    }

    @Override
    public void initButton() {
        this.initSettings();
        super.initButton();
    }

    static {
        first = false;
    }
}
