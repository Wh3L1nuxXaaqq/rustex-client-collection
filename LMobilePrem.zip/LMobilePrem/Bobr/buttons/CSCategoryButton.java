package Bobr.buttons;

import Bobr.buttons.CSButton;
import Bobr.buttons.CSModButton;
import com.Blood.Ware.BloodWare;
import com.Blood.Ware.manager.ModuleManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.Module;
import com.Blood.Ware.module.hud.ClickGUI;
import java.io.IOException;
import java.util.ArrayList;

public class CSCategoryButton
extends CSButton {
    public static boolean binding;
    public Category category;
    public CSModButton currentMod;
    public ArrayList<CSModButton> buttons = new ArrayList();

    public CSCategoryButton(int x, int y, int width, int height, int color, String displayString, Category category) {
        super(x, y, width, height, color, displayString);
        this.category = category;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (this.isHovered(mouseX, mouseY)) ** GOTO lbl-1000
        if (BloodWare.bobrGui.currentCategory == this) lbl-1000:
        // 2 sources

        {
            v0 = ClickGUI.getColor();
        } else {
            v0 = this.color;
        }
        color = v0;
        this.fr.func_78276_b(this.displayString, this.x, this.y, color);
        for (CSModButton csm : this.buttons) {
            if (BloodWare.bobrGui.currentCategory != this) continue;
            csm.drawScreen(mouseX, mouseY, partialTicks);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onKeyPress(int typedChar, int keyCode) {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        boolean hoveredx = mouseX > this.x && mouseX < this.x + this.width;
        boolean hoveredy = mouseY > this.y && mouseY < this.y + this.height;
        return hoveredx && hoveredy;
    }

    public void setBinding(boolean binding) {
        CSCategoryButton.binding = binding;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        for (CSModButton cmb : this.buttons) {
            cmb.mouseClicked(mouseX, mouseY, mouseButton);
            if (mouseButton == 1 && cmb.isHovered(mouseX, mouseY)) {
                this.currentMod = cmb;
            }
            if (mouseButton != 2 || !cmb.isHovered(mouseX, mouseY)) continue;
            this.setBinding(true);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void initButton() {
        this.buttons.clear();
        int x = this.x + 65;
        int y = 110;
        int i = 0;
        while (true) {
            if (i >= ModuleManager.modules.size()) break;
            Module m = ModuleManager.modules.get(i);
            if (m.getCategory() == this.category) {
                CSModButton csm = new CSModButton(x, y, this.fr.func_78256_a(m.getName()), this.fr.field_78288_b, -1, m.getName(), m);
                this.buttons.add(csm);
                y += 10;
            }
            ++i;
        }
        super.initButton();
    }

    private boolean isCurrentPanel() {
        return BloodWare.bobrGui.currentCategory == this;
    }
}
