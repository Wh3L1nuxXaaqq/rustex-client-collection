package Bobr;

import Bobr.buttons.CSCategoryButton;
import com.Blood.Ware.manager.FriendManager;
import com.Blood.Ware.module.Category;
import com.Blood.Ware.module.hud.ClickGUI;
import com.Blood.Ware.utils.RenderUtil;
import com.Blood.Ware.utils.RenderUtils;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class BobrGui
extends GuiScreen {
    private float curAlpha;
    private float anim;
    public ArrayList<CSCategoryButton> buttons = new ArrayList();
    public CSCategoryButton currentCategory;
    public int x = 100;
    public int y = 100;
    public int field_146294_l;
    public int field_146295_m;
    public ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());

    public BobrGui() {
        this.field_146294_l = this.sr.func_78326_a() - 100;
        this.field_146295_m = this.sr.func_78328_b() - 100;
        this.field_146294_l = this.sr.func_78326_a() - 100;
        this.field_146295_m = this.sr.func_78328_b() - 100;
    }

    private void initButtons() {
        this.buttons.clear();
        int x = 110;
        int y = 110;
        for (Category c : Category.values()) {
            String categoryname = c.name().substring(0, 1).toUpperCase() + c.name().substring(1, c.name().length()).toLowerCase();
            CSCategoryButton cscb = new CSCategoryButton(x, y, this.field_146297_k.field_71466_p.func_78256_a(categoryname), this.field_146297_k.field_71466_p.field_78288_b, -1, categoryname, c);
            this.buttons.add(cscb);
            y += 15;
        }
    }

    public ScaledResolution getScaledRes() {
        return new ScaledResolution(Minecraft.func_71410_x());
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        this.anim -= 1.0f;
        float alpha = 150.0f;
        int step = (int)(alpha / 100.0f);
        if (this.curAlpha < alpha - (float)step) {
            this.curAlpha += (float)step;
        } else if (this.curAlpha > alpha - (float)step && this.curAlpha != alpha) {
            this.curAlpha = (int)alpha;
        } else if (this.curAlpha != alpha) {
            this.curAlpha = (int)alpha;
        }
        Color none = new Color(0, 0, 0, 0);
        this.func_73733_a(0, 0, this.getScaledRes().func_78326_a(), this.getScaledRes().func_78328_b(), new Color(0, 0, 0, 0).getRGB(), ClickGUI.getColor());
        RenderUtils.drawImage(new ResourceLocation("kuriyama.png"), (float)this.sr.func_78326_a() + 200.0f, (float)this.sr.func_78328_b() - 75.0f, 345.0f, 380.0f);
        RenderUtil.drawNewRect(this.x, this.field_146295_m, this.field_146294_l, (double)this.field_146295_m + 0.5, ClickGUI.getColor());
        RenderUtil.drawNewRect(this.field_146294_l, this.y - this.field_146289_q.field_78288_b * 2, (double)this.field_146294_l + 0.5, this.field_146295_m, ClickGUI.getColor());
        Gui.func_73734_a((int)this.x, (int)(this.y - this.field_146289_q.field_78288_b * 2), (int)this.field_146294_l, (int)this.field_146295_m, (int)new Color(50, 50, 50, 190).getRGB());
        for (CSCategoryButton cb : this.buttons) {
            cb.drawScreen(mouseX, mouseY, partialTicks);
        }
        Gui.func_73734_a((int)(this.x + 65), (int)this.y, (int)(this.x + 67), (int)this.field_146295_m, (int)ClickGUI.getColor());
        Gui.func_73734_a((int)(this.x + 165), (int)this.y, (int)(this.x + 167), (int)this.field_146295_m, (int)ClickGUI.getColor());
        this.drawinfo(mouseX, mouseY);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    public boolean func_73868_f() {
        return false;
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        for (CSCategoryButton cb : this.buttons) {
            cb.keyTyped(typedChar, keyCode);
        }
        super.func_73869_a(typedChar, keyCode);
    }

    public void drawinfo(int mouseX, int mouseY) {
        int xpos = 600;
        int ypos = 100;
        int g = 0;
        this.field_146289_q.func_175063_a("Friends", (float)(xpos + this.field_146289_q.func_78256_a("Friends") / 2), (float)(ypos - this.field_146289_q.field_78288_b), ClickGUI.getColor());
        RenderUtil.drawRect(xpos, ypos, xpos + 100, ypos + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, new Color(50, 50, 50, 190).getRGB());
        RenderUtil.drawNewRect(xpos - 1, ypos, xpos, ypos + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor());
        RenderUtil.drawNewRect(xpos + 100 - 1, ypos, xpos + 100, ypos + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor());
        RenderUtil.drawGlow(xpos, ypos - 1, xpos + 100, ypos, ClickGUI.getColor(), 250.0);
        RenderUtil.drawGlow(xpos, ypos + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b - 1, xpos + 100, ypos + FriendManager.FRIENDS.size() * this.field_146289_q.field_78288_b, ClickGUI.getColor(), 250.0);
        for (String friends : FriendManager.FRIENDS) {
            int butX1 = 0 + xpos;
            int butX2 = 100 + xpos;
            int butY1 = g + ypos;
            int butY2 = g + this.field_146289_q.field_78288_b + ypos;
            if (mouseX > butX1 && mouseX < butX2 && mouseY > butY1 && mouseY < butY2) {
                this.field_146289_q.func_78276_b(friends, xpos + 50 - this.field_146289_q.func_78256_a(friends) / 2, g + ypos, ClickGUI.getColor());
                if (Mouse.isButtonDown((int)1)) {
                    FriendManager.toggleFriend(friends);
                    return;
                }
            } else {
                this.field_146289_q.func_78276_b(friends, xpos + 50 - this.field_146289_q.func_78256_a(friends) / 2, g + ypos, Color.white.getRGB());
            }
            g += this.field_146289_q.field_78288_b;
        }
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        boolean anyhovered = true;
        for (CSCategoryButton cb : this.buttons) {
            if (cb.isHovered(mouseX, mouseY) && mouseButton == 0) {
                anyhovered = true;
                this.currentCategory = cb;
            }
            cb.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    protected void func_146286_b(int mouseX, int mouseY, int state) {
        for (CSCategoryButton cb : this.buttons) {
            cb.mouseReleased(mouseX, mouseY, state);
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    public void func_73866_w_() {
        this.initButtons();
        this.anim = 0.0f;
        this.x = 100;
        this.y = 100;
        this.field_146294_l = 500;
        this.field_146295_m = 350;
        for (CSCategoryButton cb : this.buttons) {
            cb.initButton();
        }
        super.func_73866_w_();
    }
}
