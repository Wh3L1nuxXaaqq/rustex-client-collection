import com.Blood.Ware.BloodWare;
import com.Blood.Ware.Menu.onGuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

@Mod(modid="optifune", version="0.1", name="Solo")
public class Main {
    private Logger logger;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Display.setTitle((String)("Loading " + BloodWare.name));
        this.logger = event.getModLog();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) throws Exception {
        BloodWare.startup();
        MinecraftForge.EVENT_BUS.register((Object)new onGuiOpenEvent());
        BloodWare.instance = new BloodWare();
        BloodWare.instance.init();
    }
}
